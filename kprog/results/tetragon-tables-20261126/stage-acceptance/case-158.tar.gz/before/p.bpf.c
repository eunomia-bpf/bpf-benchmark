#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 296U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(5) M(6) M(8) M(10) M(11) M(13) M(14) M(23) M(24)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 config_map[] __ksym;
extern __u8 enforcer_data[] __ksym;
extern __u8 enforcer_missed_notifications[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 fdinstall_map[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 ima_hash_map[] __ksym;
extern __u8 lsm_calls[] __ksym;
extern __u8 override_tasks[] __ksym;
extern __u8 policy_conf[] __ksym;
extern __u8 policy_stats[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 ratelimit_heap[] __ksym;
extern __u8 ratelimit_map[] __ksym;
extern __u8 socktrack_map[] __ksym;
extern __u8 stack_trace_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_MEM_IMM, X86_OP_IMUL_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("lsm")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: sub    rsp,0x58 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 88ULL);
x86_l_a:
	/* 0xa: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d:
	/* 0xd: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_15:
	/* 0x15: mov    rdi,QWORD PTR [rip+0x79c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_1c:
	/* 0x1c: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21:
	/* 0x21: call   79e6 <do_action+0x7793> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26:
	/* 0x26: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28:
	/* 0x28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b:
	/* 0x2b: je     a7 <generic_lsm_actions+0xa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b, 0xa7, x86_l_a7);
x86_l_2d:
	/* 0x2d: mov    r15d,DWORD PTR [rax+0x5f04] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_34:
	/* 0x34: cmp    r15d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_38:
	/* 0x38: jl     a7 <generic_lsm_actions+0xa7> */
	X86_SIM_X86_JCC(X86_CC_L, 0x38, 0xa7, x86_l_a7);
x86_l_3a:
	/* 0x3a: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_40:
	/* 0x40: mov    rdi,QWORD PTR [rip+0x79c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_47:
	/* 0x47: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a:
	/* 0x4a: call   7a0f <do_action+0x77bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4f:
	/* 0x4f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52:
	/* 0x52: je     a7 <generic_lsm_actions+0xa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52, 0xa7, x86_l_a7);
x86_l_54:
	/* 0x54: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_57:
	/* 0x57: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_5d:
	/* 0x5d: add    r15d,DWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_61:
	/* 0x61: and    r15d,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_68:
	/* 0x68: add    r15,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rsp+0x4],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869185ULL);
x86_l_70:
	/* 0x70: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_78:
	/* 0x78: mov    rdi,QWORD PTR [rip+0x79c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_conf));
x86_l_7f:
	/* 0x7f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_84:
	/* 0x84: call   7a49 <do_action+0x77f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_89:
	/* 0x89: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c:
	/* 0x8c: je     1c9 <generic_lsm_actions+0x1c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c, 0x1c9, x86_l_1c9);
x86_l_92:
	/* 0x92: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95:
	/* 0x95: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_98:
	/* 0x98: cmp    DWORD PTR [r15],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_9c:
	/* 0x9c: jae    1d1 <generic_lsm_actions+0x1d1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x9c, 0x1d1, x86_l_1d1);
x86_l_a2:
	/* 0xa2: jmp    22b <generic_lsm_actions+0x22b> */
	X86_SIM_X86_JMP(0xa2, 0x22b, x86_l_22b);
x86_l_a7:
	/* 0xa7: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aa:
	/* 0xaa: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_b2:
	/* 0xb2: mov    rdi,QWORD PTR [rip+0x79c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_b9:
	/* 0xb9: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_be:
	/* 0xbe: call   7a83 <do_action+0x7830> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c3:
	/* 0xc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6:
	/* 0xc6: je     16a <generic_lsm_actions+0x16a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6, 0x16a, x86_l_16a);
x86_l_cc:
	/* 0xcc: mov    BYTE PTR [rax+0x5f08],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 24328ULL);
x86_l_d3:
	/* 0xd3: test   BYTE PTR [rax+0x1],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4294967304ULL);
x86_l_d7:
	/* 0xd7: je     165 <generic_lsm_actions+0x165> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7, 0x165, x86_l_165);
x86_l_dd:
	/* 0xdd: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_e0:
	/* 0xe0: je     165 <generic_lsm_actions+0x165> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe0, 0x165, x86_l_165);
x86_l_e6:
	/* 0xe6: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e9:
	/* 0xe9: call   7aaa <do_action+0x7857> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f3:
	/* 0xf3: mov    QWORD PTR [rsp+0x11],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 73014444032ULL);
x86_l_fc:
	/* 0xfc: mov    QWORD PTR [rsp+0x19],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 107374182400ULL);
x86_l_105:
	/* 0x105: mov    QWORD PTR [rsp+0x21],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 141733920768ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rsp+0x29],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176093659136ULL);
x86_l_117:
	/* 0x117: mov    QWORD PTR [rsp+0x31],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 210453397504ULL);
x86_l_120:
	/* 0x120: mov    QWORD PTR [rsp+0x39],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244813135872ULL);
x86_l_129:
	/* 0x129: mov    QWORD PTR [rsp+0x41],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 279172874240ULL);
x86_l_132:
	/* 0x132: mov    QWORD PTR [rsp+0x49],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 313532612608ULL);
x86_l_13b:
	/* 0x13b: mov    BYTE PTR [rsp+0x51],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 347892350976ULL);
x86_l_140:
	/* 0x140: mov    BYTE PTR [rsp+0x10],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476737ULL);
x86_l_145:
	/* 0x145: mov    rdi,QWORD PTR [rip+0x79bc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ima_hash_map));
x86_l_14c:
	/* 0x14c: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_151:
	/* 0x151: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_156:
	/* 0x156: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_158:
	/* 0x158: call   7b19 <do_action+0x78c6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_15d:
	/* 0x15d: movzx  r15d,BYTE PTR [r14+0x5f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 24328ULL);
x86_l_165:
	/* 0x165: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_168:
	/* 0x168: je     17b <generic_lsm_actions+0x17b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x168, 0x17b, x86_l_17b);
x86_l_16a:
	/* 0x16a: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_16c:
	/* 0x16c: add    rsp,0x58 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 88ULL);
x86_l_170:
	/* 0x170: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_171:
	/* 0x171: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_173:
	/* 0x173: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_176:
	/* 0x176: jmp    dc1 <do_action+0xb6e> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_17b:
	/* 0x17b: call   7b38 <do_action+0x78e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_180:
	/* 0x180: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_185:
	/* 0x185: mov    rdi,QWORD PTR [rip+0x79b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)override_tasks));
x86_l_18c:
	/* 0x18c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_191:
	/* 0x191: call   7b4e <do_action+0x78fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_196:
	/* 0x196: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_199:
	/* 0x199: je     1c5 <generic_lsm_actions+0x1c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x199, 0x1c5, x86_l_1c5);
x86_l_19b:
	/* 0x19b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19e:
	/* 0x19e: mov    rdi,QWORD PTR [rip+0x79b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)override_tasks));
x86_l_1a5:
	/* 0x1a5: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1aa:
	/* 0x1aa: call   7b67 <do_action+0x7914> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_1af:
	/* 0x1af: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b1:
	/* 0x1b1: lea    ecx,[rax-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b4:
	/* 0x1b4: mov    ebx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1b9:
	/* 0x1b9: cmp    ecx,0xfffff000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4294963200ULL);
x86_l_1bf:
	/* 0x1bf: jb     16a <generic_lsm_actions+0x16a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1bf, 0x16a, x86_l_16a);
x86_l_1c1:
	/* 0x1c1: mov    ebx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c3:
	/* 0x1c3: jmp    16a <generic_lsm_actions+0x16a> */
	X86_SIM_X86_JMP(0x1c3, 0x16a, x86_l_16a);
x86_l_1c5:
	/* 0x1c5: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c7:
	/* 0x1c7: jmp    16a <generic_lsm_actions+0x16a> */
	X86_SIM_X86_JMP(0x1c7, 0x16a, x86_l_16a);
x86_l_1c9:
	/* 0x1c9: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1cb:
	/* 0x1cb: cmp    DWORD PTR [r15],0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5ULL);
x86_l_1cf:
	/* 0x1cf: jb     22b <generic_lsm_actions+0x22b> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cf, 0x22b, x86_l_22b);
x86_l_1d1:
	/* 0x1d1: movzx  ebp,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1d4:
	/* 0x1d4: lea    rcx,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d9:
	/* 0x1d9: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1dc:
	/* 0x1dc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de:
	/* 0x1de: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1e1:
	/* 0x1e1: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1e4:
	/* 0x1e4: call   0 <generic_lsm_actions> */
	X86_SIM_X86_CALL(x86_l_253, 0x1e9ULL);
x86_l_1e9:
	/* 0x1e9: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_1f0:
	/* 0x1f0: cmp    ecx,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_1f3:
	/* 0x1f3: jae    22b <generic_lsm_actions+0x22b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1f3, 0x22b, x86_l_22b);
x86_l_1f5:
	/* 0x1f5: lea    rcx,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fa:
	/* 0x1fa: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1fd:
	/* 0x1fd: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1ff:
	/* 0x1ff: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_202:
	/* 0x202: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_205:
	/* 0x205: call   0 <generic_lsm_actions> */
	X86_SIM_X86_CALL(x86_l_253, 0x20aULL);
x86_l_20a:
	/* 0x20a: lea    ecx,[rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_211:
	/* 0x211: cmp    ecx,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_214:
	/* 0x214: jae    22b <generic_lsm_actions+0x22b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x214, 0x22b, x86_l_22b);
x86_l_216:
	/* 0x216: lea    rcx,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_21b:
	/* 0x21b: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_21e:
	/* 0x21e: mov    esi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_220:
	/* 0x220: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_223:
	/* 0x223: mov    r8d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_226:
	/* 0x226: call   0 <generic_lsm_actions> */
	X86_SIM_X86_CALL(x86_l_253, 0x22bULL);
x86_l_22b:
	/* 0x22b: movzx  r15d,BYTE PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_231:
	/* 0x231: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_234:
	/* 0x234: je     aa <generic_lsm_actions+0xaa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234, 0xaa, x86_l_aa);
x86_l_23a:
	/* 0x23a: mov    rsi,QWORD PTR [rip+0x79b8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)lsm_calls));
x86_l_241:
	/* 0x241: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_244:
	/* 0x244: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_249:
	/* 0x249: call   7c06 <do_action+0x79b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_24e:
	/* 0x24e: jmp    aa <generic_lsm_actions+0xaa> */
	X86_SIM_X86_JMP(0x24e, 0xaa, x86_l_aa);
x86_l_dc1:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_253 */
x86_l_253:
	/* 0x253: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_254:
	/* 0x254: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_256:
	/* 0x256: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_258:
	/* 0x258: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_25a:
	/* 0x25a: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_25c:
	/* 0x25c: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25d:
	/* 0x25d: sub    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 120ULL);
x86_l_261:
	/* 0x261: mov    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_264:
	/* 0x264: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_269:
	/* 0x269: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26c:
	/* 0x26c: mov    ebx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_26e:
	/* 0x26e: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_271:
	/* 0x271: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_273:
	/* 0x273: movsxd r12,DWORD PTR [rdx+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_RAX, 2, X86_WIDTH_32), 4ULL);
x86_l_278:
	/* 0x278: mov    DWORD PTR [rsp+0x64],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 429496729600ULL);
x86_l_280:
	/* 0x280: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_287:
	/* 0x287: lea    rsi,[rsp+0x64] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 100ULL);
x86_l_28c:
	/* 0x28c: call   2e31 <do_action+0x2bde> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_291:
	/* 0x291: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_294:
	/* 0x294: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_296:
	/* 0x296: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_299:
	/* 0x299: je     d7f <do_action+0xb2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x299, 0xd7f, x86_l_d7f);
x86_l_29f:
	/* 0x29f: cmp    r12d,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_2a3:
	/* 0x2a3: jg     2cd <do_action+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2a3, 0x2cd, x86_l_2cd);
x86_l_2a5:
	/* 0x2a5: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2a9:
	/* 0x2a9: jg     305 <do_action+0xb2> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2a9, 0x305, x86_l_305);
x86_l_2ab:
	/* 0x2ab: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2af:
	/* 0x2af: jg     434 <do_action+0x1e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2af, 0x434, x86_l_434);
x86_l_2b5:
	/* 0x2b5: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_2b8:
	/* 0x2b8: je     758 <do_action+0x505> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b8, 0x758, x86_l_758);
x86_l_2be:
	/* 0x2be: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2c2:
	/* 0x2c2: je     44d <do_action+0x1fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2c2, 0x44d, x86_l_44d);
x86_l_2c8:
	/* 0x2c8: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x2c8, 0xd77, x86_l_d77);
x86_l_2cd:
	/* 0x2cd: cmp    r12d,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_2d1:
	/* 0x2d1: jg     406 <do_action+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2d1, 0x406, x86_l_406);
x86_l_2d7:
	/* 0x2d7: lea    ecx,[r12-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_2dc:
	/* 0x2dc: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2df:
	/* 0x2df: jb     585 <do_action+0x332> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2df, 0x585, x86_l_585);
x86_l_2e5:
	/* 0x2e5: cmp    r12d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2e9:
	/* 0x2e9: je     666 <do_action+0x413> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2e9, 0x666, x86_l_666);
x86_l_2ef:
	/* 0x2ef: cmp    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2f3:
	/* 0x2f3: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2f3, 0xd77, x86_l_d77);
x86_l_2f9:
	/* 0x2f9: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2fb:
	/* 0x2fb: mov    edi,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_300:
	/* 0x300: jmp    637 <do_action+0x3e4> */
	X86_SIM_X86_SUB_JMP(0x300, 0x637, x86_l_637);
x86_l_305:
	/* 0x305: lea    eax,[r12-0x6] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551610ULL);
x86_l_30a:
	/* 0x30a: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_30d:
	/* 0x30d: jb     656 <do_action+0x403> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x30d, 0x656, x86_l_656);
x86_l_313:
	/* 0x313: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_317:
	/* 0x317: je     673 <do_action+0x420> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x317, 0x673, x86_l_673);
x86_l_31d:
	/* 0x31d: cmp    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_321:
	/* 0x321: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x321, 0xd77, x86_l_d77);
x86_l_327:
	/* 0x327: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_32a:
	/* 0x32a: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_32f:
	/* 0x32f: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_332:
	/* 0x332: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_335:
	/* 0x335: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_338:
	/* 0x338: ja     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x338, 0xd77, x86_l_d77);
x86_l_33e:
	/* 0x33e: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_347:
	/* 0x347: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x347, 0xd77, x86_l_d77);
x86_l_34d:
	/* 0x34d: mov    r15d,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_352:
	/* 0x352: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_35a:
	/* 0x35a: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_35f:
	/* 0x35f: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_367:
	/* 0x367: mov    eax,DWORD PTR [r14+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_36f:
	/* 0x36f: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_373:
	/* 0x373: call   2f18 <do_action+0x2cc5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_378:
	/* 0x378: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_37c:
	/* 0x37c: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_381:
	/* 0x381: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_388:
	/* 0x388: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38d:
	/* 0x38d: call   2f32 <do_action+0x2cdf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_392:
	/* 0x392: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_395:
	/* 0x395: je     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x395, 0xd77, x86_l_d77);
x86_l_39b:
	/* 0x39b: and    r15d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_39f:
	/* 0x39f: cmp    r15d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3a3:
	/* 0x3a3: ja     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x3a3, 0xd77, x86_l_d77);
x86_l_3a9:
	/* 0x3a9: cmp    DWORD PTR [r14+r15*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 2), 104041287778304ULL);
x86_l_3b2:
	/* 0x3b2: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x3b2, 0xd77, x86_l_d77);
x86_l_3b8:
	/* 0x3b8: mov    rcx,QWORD PTR [r14+r15*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 3), 24184ULL);
x86_l_3c0:
	/* 0x3c0: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_3c6:
	/* 0x3c6: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_3ce:
	/* 0x3ce: mov    ecx,DWORD PTR [r14+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_3d6:
	/* 0x3d6: mov    DWORD PTR [rsp+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3da:
	/* 0x3da: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dd:
	/* 0x3dd: call   2f82 <do_action+0x2d2f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_3e2:
	/* 0x3e2: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3e6:
	/* 0x3e6: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3eb:
	/* 0x3eb: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_3f2:
	/* 0x3f2: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f7:
	/* 0x3f7: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3fa:
	/* 0x3fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fc:
	/* 0x3fc: call   2fa1 <do_action+0x2d4e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_401:
	/* 0x401: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x401, 0xd77, x86_l_d77);
x86_l_406:
	/* 0x406: cmp    r12d,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_40a:
	/* 0x40a: je     7fb <do_action+0x5a8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x40a, 0x7fb, x86_l_7fb);
x86_l_410:
	/* 0x410: cmp    r12d,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_414:
	/* 0x414: je     6e8 <do_action+0x495> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x414, 0x6e8, x86_l_6e8);
x86_l_41a:
	/* 0x41a: cmp    r12d,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_41e:
	/* 0x41e: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x41e, 0xd77, x86_l_d77);
x86_l_424:
	/* 0x424: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_427:
	/* 0x427: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_42b:
	/* 0x42b: xor    r13,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 9ULL);
x86_l_42f:
	/* 0x42f: jmp    8c1 <do_action+0x66e> */
	X86_SIM_X86_SUB_JMP(0x42f, 0x8c1, x86_l_8c1);
x86_l_434:
	/* 0x434: mov    edi,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_439:
	/* 0x439: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_43d:
	/* 0x43d: je     637 <do_action+0x3e4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x43d, 0x637, x86_l_637);
x86_l_443:
	/* 0x443: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_447:
	/* 0x447: jne    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x447, 0xd77, x86_l_d77);
x86_l_44d:
	/* 0x44d: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_450:
	/* 0x450: mov    r13d,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_455:
	/* 0x455: add    ebx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_458:
	/* 0x458: mov    ebp,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_45d:
	/* 0x45d: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_465:
	/* 0x465: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap));
x86_l_46c:
	/* 0x46c: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_471:
	/* 0x471: call   3016 <do_action+0x2dc3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_476:
	/* 0x476: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_479:
	/* 0x479: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_47c:
	/* 0x47c: je     d70 <do_action+0xb1d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x47c, 0xd70, x86_l_d70);
x86_l_482:
	/* 0x482: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_485:
	/* 0x485: and    r13d,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_489:
	/* 0x489: cmp    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_48d:
	/* 0x48d: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_492:
	/* 0x492: ja     d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x492, 0xd72, x86_l_d72);
x86_l_498:
	/* 0x498: cmp    DWORD PTR [r14+r13*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 104041287778304ULL);
x86_l_4a1:
	/* 0x4a1: jne    d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4a1, 0xd72, x86_l_d72);
x86_l_4a7:
	/* 0x4a7: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4ac:
	/* 0x4ac: mov    rax,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_4b4:
	/* 0x4b4: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_4b9:
	/* 0x4b9: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_4c1:
	/* 0x4c1: mov    eax,DWORD PTR [r14+rax*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 144ULL);
x86_l_4c9:
	/* 0x4c9: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4cd:
	/* 0x4cd: call   3072 <do_action+0x2e1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_4d2:
	/* 0x4d2: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_4d6:
	/* 0x4d6: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4db:
	/* 0x4db: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_4df:
	/* 0x4df: jne    88a <do_action+0x637> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4df, 0x88a, x86_l_88a);
x86_l_4e5:
	/* 0x4e5: and    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_4e8:
	/* 0x4e8: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_4eb:
	/* 0x4eb: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4f0:
	/* 0x4f0: ja     d70 <do_action+0xb1d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4f0, 0xd70, x86_l_d70);
x86_l_4f6:
	/* 0x4f6: cmp    DWORD PTR [r14+rbp*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 104041287778304ULL);
x86_l_4ff:
	/* 0x4ff: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_504:
	/* 0x504: jne    d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x504, 0xd72, x86_l_d72);
x86_l_50a:
	/* 0x50a: mov    rcx,QWORD PTR [r14+rbp*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 3), 24184ULL);
x86_l_512:
	/* 0x512: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_518:
	/* 0x518: lea    rax,[r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_51c:
	/* 0x51c: add    rax,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_522:
	/* 0x522: mov    esi,DWORD PTR [r14+rcx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 144ULL);
x86_l_52a:
	/* 0x52a: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_52c:
	/* 0x52c: and    ecx,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_532:
	/* 0x532: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_536:
	/* 0x536: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_539:
	/* 0x539: jns    d39 <do_action+0xae6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x539, 0xd39, x86_l_d39);
x86_l_53f:
	/* 0x53f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_542:
	/* 0x542: jns    d48 <do_action+0xaf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x542, 0xd48, x86_l_d48);
x86_l_548:
	/* 0x548: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_54a:
	/* 0x54a: mov    r8,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_54d:
	/* 0x54d: mov    rdi,QWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_551:
	/* 0x551: mov    QWORD PTR [rdx+r8*1],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_555:
	/* 0x555: lea    rdi,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_559:
	/* 0x559: add    r8,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_55d:
	/* 0x55d: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_560:
	/* 0x560: jbe    54a <do_action+0x2f7> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x560, 0x54a, x86_l_54a);
x86_l_562:
	/* 0x562: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_566:
	/* 0x566: jne    d8e <do_action+0xb3b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x566, 0xd8e, x86_l_d8e);
x86_l_56c:
	/* 0x56c: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_570:
	/* 0x570: jne    da1 <do_action+0xb4e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x570, 0xda1, x86_l_da1);
x86_l_576:
	/* 0x576: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_57a:
	/* 0x57a: je     d5a <do_action+0xb07> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x57a, 0xd5a, x86_l_d5a);
x86_l_580:
	/* 0x580: jmp    db6 <do_action+0xb63> */
	X86_SIM_X86_SUB_JMP(0x580, 0xdb6, x86_l_db6);
x86_l_585:
	/* 0x585: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_587:
	/* 0x587: mov    ecx,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_58c:
	/* 0x58c: and    ecx,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_58f:
	/* 0x58f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_592:
	/* 0x592: cmp    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_595:
	/* 0x595: ja     d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x595, 0xd72, x86_l_d72);
x86_l_59b:
	/* 0x59b: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_5a4:
	/* 0x5a4: jne    d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x5a4, 0xd72, x86_l_d72);
x86_l_5aa:
	/* 0x5aa: mov    rcx,QWORD PTR [r14+rcx*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 3), 24184ULL);
x86_l_5b2:
	/* 0x5b2: and    ecx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_5b8:
	/* 0x5b8: mov    rcx,QWORD PTR [r14+rcx*1+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 184ULL);
x86_l_5c0:
	/* 0x5c0: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5c5:
	/* 0x5c5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5c8:
	/* 0x5c8: je     d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5c8, 0xd72, x86_l_d72);
x86_l_5ce:
	/* 0x5ce: cmp    r12d,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_5d2:
	/* 0x5d2: jne    8ed <do_action+0x69a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x5d2, 0x8ed, x86_l_8ed);
x86_l_5d8:
	/* 0x5d8: call   317d <do_action+0x2f2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_5dd:
	/* 0x5dd: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5e0:
	/* 0x5e0: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_5e4:
	/* 0x5e4: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5e8:
	/* 0x5e8: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_5ef:
	/* 0x5ef: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5f4:
	/* 0x5f4: call   3199 <do_action+0x2f46> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5f9:
	/* 0x5f9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5fc:
	/* 0x5fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ff:
	/* 0x5ff: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_604:
	/* 0x604: je     d72 <do_action+0xb1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x604, 0xd72, x86_l_d72);
x86_l_60a:
	/* 0x60a: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_60c:
	/* 0x60c: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_610:
	/* 0x610: mov    DWORD PTR [rsp+0xc],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_615:
	/* 0x615: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_619:
	/* 0x619: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_61e:
	/* 0x61e: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_625:
	/* 0x625: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_628:
	/* 0x628: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_62d:
	/* 0x62d: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_632:
	/* 0x632: jmp    d69 <do_action+0xb16> */
	X86_SIM_X86_SUB_JMP(0x632, 0xd69, x86_l_d69);
x86_l_637:
	/* 0x637: mov    r13d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_63d:
	/* 0x63d: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_640:
	/* 0x640: je     8c1 <do_action+0x66e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x640, 0x8c1, x86_l_8c1);
x86_l_646:
	/* 0x646: call   31eb <do_action+0x2f98> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_send_signal);
x86_l_64b:
	/* 0x64b: mov    r13d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_651:
	/* 0x651: jmp    8c1 <do_action+0x66e> */
	X86_SIM_X86_SUB_JMP(0x651, 0x8c1, x86_l_8c1);
x86_l_656:
	/* 0x656: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_658:
	/* 0x658: mov    eax,DWORD PTR [r15+rbx*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 4ULL);
x86_l_65d:
	/* 0x65d: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_661:
	/* 0x661: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x661, 0xd77, x86_l_d77);
x86_l_666:
	/* 0x666: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_66b:
	/* 0x66b: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_66e:
	/* 0x66e: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x66e, 0xd77, x86_l_d77);
x86_l_673:
	/* 0x673: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_675:
	/* 0x675: mov    r13d,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_67b:
	/* 0x67b: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_67e:
	/* 0x67e: je     8c1 <do_action+0x66e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x67e, 0x8c1, x86_l_8c1);
x86_l_684:
	/* 0x684: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_686:
	/* 0x686: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_68b:
	/* 0x68b: mov    DWORD PTR [rsp+0x3c],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_68f:
	/* 0x68f: call   3234 <do_action+0x2fe1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_694:
	/* 0x694: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_699:
	/* 0x699: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)override_tasks));
x86_l_6a0:
	/* 0x6a0: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6a5:
	/* 0x6a5: call   324a <do_action+0x2ff7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6aa:
	/* 0x6aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ad:
	/* 0x6ad: je     870 <do_action+0x61d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6ad, 0x870, x86_l_870);
x86_l_6b3:
	/* 0x6b3: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b6:
	/* 0x6b6: mov    DWORD PTR [rsp+0x8],0xe0011 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34360655889ULL);
x86_l_6be:
	/* 0x6be: mov    QWORD PTR [rsp+0xc],0x356 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 51539608406ULL);
x86_l_6c7:
	/* 0x6c7: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_6ce:
	/* 0x6ce: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6d3:
	/* 0x6d3: call   3278 <do_action+0x3025> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d8:
	/* 0x6d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6db:
	/* 0x6db: je     898 <do_action+0x645> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6db, 0x898, x86_l_898);
x86_l_6e1:
	/* 0x6e1: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_6e3:
	/* 0x6e3: jmp    8b8 <do_action+0x665> */
	X86_SIM_X86_SUB_JMP(0x6e3, 0x8b8, x86_l_8b8);
x86_l_6e8:
	/* 0x6e8: call   328d <do_action+0x303a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_6ed:
	/* 0x6ed: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f2:
	/* 0x6f2: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_6f9:
	/* 0x6f9: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6fe:
	/* 0x6fe: call   32a3 <do_action+0x3050> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_703:
	/* 0x703: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_706:
	/* 0x706: je     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x706, 0xd77, x86_l_d77);
x86_l_70c:
	/* 0x70c: mov    rax,QWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_710:
	/* 0x710: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_715:
	/* 0x715: mov    DWORD PTR [rsp+0x20],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953474ULL);
x86_l_71d:
	/* 0x71d: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_724:
	/* 0x724: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_729:
	/* 0x729: call   32ce <do_action+0x307b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_72e:
	/* 0x72e: mov    DWORD PTR [rsp+0x4c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 326417514497ULL);
x86_l_736:
	/* 0x736: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_739:
	/* 0x739: je     80b <do_action+0x5b8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x739, 0x80b, x86_l_80b);
x86_l_73f:
	/* 0x73f: lock inc DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_742:
	/* 0x742: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_data));
x86_l_749:
	/* 0x749: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_74e:
	/* 0x74e: call   32f3 <do_action+0x30a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_753:
	/* 0x753: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x753, 0xd77, x86_l_d77);
x86_l_758:
	/* 0x758: lea    eax,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_75b:
	/* 0x75b: mov    ebp,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_760:
	/* 0x760: lea    eax,[rbx+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_763:
	/* 0x763: mov    eax,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_768:
	/* 0x768: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_76c:
	/* 0x76c: call   3311 <do_action+0x30be> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_771:
	/* 0x771: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_776:
	/* 0x776: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_77e:
	/* 0x77e: mov    QWORD PTR [rsp+0x70],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_783:
	/* 0x783: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_786:
	/* 0x786: je     c7e <do_action+0xa2b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x786, 0xc7e, x86_l_c7e);
x86_l_78c:
	/* 0x78c: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_heap));
x86_l_793:
	/* 0x793: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_798:
	/* 0x798: call   333d <do_action+0x30ea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_79d:
	/* 0x79d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a0:
	/* 0x7a0: je     c7e <do_action+0xa2b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7a0, 0xc7e, x86_l_c7e);
x86_l_7a6:
	/* 0x7a6: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7ab:
	/* 0x7ab: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ae:
	/* 0x7ae: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_7b5:
	/* 0x7b5: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7ba:
	/* 0x7ba: call   335f <do_action+0x310c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7bf:
	/* 0x7bf: mov    rcx,QWORD PTR [r14+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_7c3:
	/* 0x7c3: mov    QWORD PTR [rbp+0x0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c7:
	/* 0x7c7: mov    rcx,QWORD PTR [r14+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_7cb:
	/* 0x7cb: mov    QWORD PTR [rsp+0x50],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7d0:
	/* 0x7d0: mov    QWORD PTR [rbp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d4:
	/* 0x7d4: mov    ecx,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7d8:
	/* 0x7d8: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7db:
	/* 0x7db: je     90c <do_action+0x6b9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7db, 0x90c, x86_l_90c);
x86_l_7e1:
	/* 0x7e1: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_7e4:
	/* 0x7e4: je     906 <do_action+0x6b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7e4, 0x906, x86_l_906);
x86_l_7ea:
	/* 0x7ea: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7ec:
	/* 0x7ec: jne    c7e <do_action+0xa2b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7ec, 0xc7e, x86_l_c7e);
x86_l_7f2:
	/* 0x7f2: mov    ecx,DWORD PTR [r14+0x7c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_7f6:
	/* 0x7f6: jmp    90e <do_action+0x6bb> */
	X86_SIM_X86_SUB_JMP(0x7f6, 0x90e, x86_l_90e);
x86_l_7fb:
	/* 0x7fb: add    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_7fe:
	/* 0x7fe: movzx  r13d,bpl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R13, X86_RBP, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_802:
	/* 0x802: xor    r13,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 7ULL);
x86_l_806:
	/* 0x806: jmp    8c1 <do_action+0x66e> */
	X86_SIM_X86_SUB_JMP(0x806, 0x8c1, x86_l_8c1);
x86_l_80b:
	/* 0x80b: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_812:
	/* 0x812: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_817:
	/* 0x817: lea    rdx,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_81c:
	/* 0x81c: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_821:
	/* 0x821: call   33c6 <do_action+0x3173> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_826:
	/* 0x826: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_829:
	/* 0x829: je     742 <do_action+0x4ef> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x829, 0x742, x86_l_742);
x86_l_82f:
	/* 0x82f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_832:
	/* 0x832: neg    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_834:
	/* 0x834: mov    WORD PTR [rsp+0x8],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_839:
	/* 0x839: mov    WORD PTR [rsp+0xa],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 42949672963ULL);
x86_l_840:
	/* 0x840: movabs rax,0x20000003b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 8589934651ULL);
x86_l_84a:
	/* 0x84a: mov    QWORD PTR [rsp+0xc],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_84f:
	/* 0x84f: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_856:
	/* 0x856: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_85b:
	/* 0x85b: call   3400 <do_action+0x31ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_860:
	/* 0x860: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_863:
	/* 0x863: je     cea <do_action+0xa97> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x863, 0xcea, x86_l_cea);
x86_l_869:
	/* 0x869: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_86b:
	/* 0x86b: jmp    d0a <do_action+0xab7> */
	X86_SIM_X86_SUB_JMP(0x86b, 0xd0a, x86_l_d0a);
x86_l_870:
	/* 0x870: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)override_tasks));
x86_l_877:
	/* 0x877: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_87c:
	/* 0x87c: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_881:
	/* 0x881: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_883:
	/* 0x883: call   3428 <do_action+0x31d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_888:
	/* 0x888: jmp    8bb <do_action+0x668> */
	X86_SIM_X86_SUB_JMP(0x888, 0x8bb, x86_l_8bb);
x86_l_88a:
	/* 0x88a: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_891:
	/* 0x891: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_896:
	/* 0x896: jmp    8f9 <do_action+0x6a6> */
	X86_SIM_X86_SUB_JMP(0x896, 0x8f9, x86_l_8f9);
x86_l_898:
	/* 0x898: mov    DWORD PTR [rsp+0x30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430209ULL);
x86_l_8a0:
	/* 0x8a0: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_8a7:
	/* 0x8a7: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8ac:
	/* 0x8ac: lea    rdx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8b1:
	/* 0x8b1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8b3:
	/* 0x8b3: call   3458 <do_action+0x3205> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_8b8:
	/* 0x8b8: mov    DWORD PTR [r15],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8bb:
	/* 0x8bb: mov    r13d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_8c1:
	/* 0x8c1: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_8c9:
	/* 0x8c9: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_stats));
x86_l_8d0:
	/* 0x8d0: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8d5:
	/* 0x8d5: call   347a <do_action+0x3227> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8da:
	/* 0x8da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8dd:
	/* 0x8dd: je     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8dd, 0xd77, x86_l_d77);
x86_l_8e3:
	/* 0x8e3: lock inc QWORD PTR [rax+r13*8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_R13, 3, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_8e8:
	/* 0x8e8: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0x8e8, 0xd77, x86_l_d77);
x86_l_8ed:
	/* 0x8ed: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)socktrack_map));
x86_l_8f4:
	/* 0x8f4: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8f9:
	/* 0x8f9: call   349e <do_action+0x324b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_8fe:
	/* 0x8fe: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_901:
	/* 0x901: jmp    d70 <do_action+0xb1d> */
	X86_SIM_X86_SUB_JMP(0x901, 0xd70, x86_l_d70);
x86_l_906:
	/* 0x906: mov    ecx,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_90a:
	/* 0x90a: jmp    90e <do_action+0x6bb> */
	X86_SIM_X86_SUB_JMP(0x90a, 0x90e, x86_l_90e);
x86_l_90c:
	/* 0x90c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_90e:
	/* 0x90e: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_910:
	/* 0x910: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_915:
	/* 0x915: mov    QWORD PTR [rdx+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_919:
	/* 0x919: mov    rdi,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_91e:
	/* 0x91e: add    rdi,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_922:
	/* 0x922: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_925:
	/* 0x925: mov    QWORD PTR [rsp+0x68],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_92a:
	/* 0x92a: mov    QWORD PTR [rsp+0x58],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_92f:
	/* 0x92f: jns    a4b <do_action+0x7f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x92f, 0xa4b, x86_l_a4b);
x86_l_935:
	/* 0x935: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_938:
	/* 0x938: jns    a5a <do_action+0x807> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x938, 0xa5a, x86_l_a5a);
x86_l_93e:
	/* 0x93e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_941:
	/* 0x941: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_946:
	/* 0x946: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_94a:
	/* 0x94a: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_94e:
	/* 0x94e: mov    QWORD PTR [rdx+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_952:
	/* 0x952: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_956:
	/* 0x956: mov    QWORD PTR [rdx+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_95a:
	/* 0x95a: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_95e:
	/* 0x95e: mov    QWORD PTR [rdx+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_962:
	/* 0x962: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_966:
	/* 0x966: mov    QWORD PTR [rdx+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_96a:
	/* 0x96a: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_96e:
	/* 0x96e: mov    QWORD PTR [rdx+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_972:
	/* 0x972: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_976:
	/* 0x976: mov    QWORD PTR [rdx+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_97a:
	/* 0x97a: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_97e:
	/* 0x97e: mov    QWORD PTR [rdx+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_982:
	/* 0x982: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_986:
	/* 0x986: mov    QWORD PTR [rdx+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_98a:
	/* 0x98a: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_98e:
	/* 0x98e: mov    QWORD PTR [rdx+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_992:
	/* 0x992: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_996:
	/* 0x996: mov    QWORD PTR [rdx+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_99a:
	/* 0x99a: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_99e:
	/* 0x99e: mov    QWORD PTR [rdx+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_9a2:
	/* 0x9a2: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_9a6:
	/* 0x9a6: mov    QWORD PTR [rdx+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_9aa:
	/* 0x9aa: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_9ae:
	/* 0x9ae: mov    QWORD PTR [rdx+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_9b5:
	/* 0x9b5: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_9b9:
	/* 0x9b9: mov    QWORD PTR [rdx+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_9c0:
	/* 0x9c0: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_9c4:
	/* 0x9c4: mov    QWORD PTR [rdx+0x90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_9cb:
	/* 0x9cb: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_9d2:
	/* 0x9d2: mov    QWORD PTR [rdx+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_9d9:
	/* 0x9d9: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_9e0:
	/* 0x9e0: mov    QWORD PTR [rdx+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_9e7:
	/* 0x9e7: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_9ee:
	/* 0x9ee: mov    QWORD PTR [rdx+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_9f5:
	/* 0x9f5: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_9fc:
	/* 0x9fc: mov    QWORD PTR [rdx+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_a03:
	/* 0xa03: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_a0a:
	/* 0xa0a: mov    QWORD PTR [rdx+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_a11:
	/* 0xa11: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_a18:
	/* 0xa18: mov    QWORD PTR [rdx+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_a1f:
	/* 0xa1f: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_a26:
	/* 0xa26: mov    QWORD PTR [rdx+0xc8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_a2d:
	/* 0xa2d: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_a34:
	/* 0xa34: mov    QWORD PTR [rdx+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_a3b:
	/* 0xa3b: mov    rax,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_a42:
	/* 0xa42: mov    QWORD PTR [rdx+0xd8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_a49:
	/* 0xa49: jmp    a66 <do_action+0x813> */
	X86_SIM_X86_SUB_JMP(0xa49, 0xa66, x86_l_a66);
x86_l_a4b:
	/* 0xa4b: mov    esi,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_a50:
	/* 0xa50: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a53:
	/* 0xa53: call   35f8 <do_action+0x33a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_a58:
	/* 0xa58: jmp    a66 <do_action+0x813> */
	X86_SIM_X86_SUB_JMP(0xa58, 0xa66, x86_l_a66);
x86_l_a5a:
	/* 0xa5a: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_a5f:
	/* 0xa5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a61:
	/* 0xa61: call   3606 <do_action+0x33b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_a66:
	/* 0xa66: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a69:
	/* 0xa69: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_a70:
	/* 0xa70: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_a78:
	/* 0xa78: jmp    aa6 <do_action+0x853> */
	X86_SIM_X86_SUB_JMP(0xa78, 0xaa6, x86_l_aa6);
x86_l_a7a:
	/* 0xa7a: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a7c:
	/* 0xa7c: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a81:
	/* 0xa81: call   3626 <do_action+0x33d3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_a86:
	/* 0xa86: mov    r8,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a8b:
	/* 0xa8b: add    ebp,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R8, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_a8e:
	/* 0xa8e: mov    DWORD PTR [rsp+0x28],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a92:
	/* 0xa92: mov    rbp,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_a99:
	/* 0xa99: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_a9c:
	/* 0xa9c: cmp    r13,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 5ULL);
x86_l_aa0:
	/* 0xaa0: je     c2e <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xaa0, 0xc2e, x86_l_c2e);
x86_l_aa6:
	/* 0xaa6: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_aae:
	/* 0xaae: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_ab1:
	/* 0xab1: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ab6:
	/* 0xab6: call   365b <do_action+0x3408> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_abb:
	/* 0xabb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_abe:
	/* 0xabe: je     c2e <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xabe, 0xc2e, x86_l_c2e);
x86_l_ac4:
	/* 0xac4: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_aca:
	/* 0xaca: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_ad1:
	/* 0xad1: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad4:
	/* 0xad4: call   3679 <do_action+0x3426> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad9:
	/* 0xad9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adc:
	/* 0xadc: je     c2e <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xadc, 0xc2e, x86_l_c2e);
x86_l_ae2:
	/* 0xae2: cmp    DWORD PTR [rax+r13*4+0x40],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 279172874239ULL);
x86_l_ae8:
	/* 0xae8: je     c2e <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xae8, 0xc2e, x86_l_c2e);
x86_l_aee:
	/* 0xaee: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_af6:
	/* 0xaf6: mov    eax,DWORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_afa:
	/* 0xafa: cmp    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_afd:
	/* 0xafd: jge    c2e <do_action+0x9db> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0xafd, 0xc2e, x86_l_c2e);
x86_l_b03:
	/* 0xb03: cmp    r13,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_b07:
	/* 0xb07: je     b61 <do_action+0x90e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb07, 0xb61, x86_l_b61);
x86_l_b09:
	/* 0xb09: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_b11:
	/* 0xb11: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b14:
	/* 0xb14: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b19:
	/* 0xb19: call   36be <do_action+0x346b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b1e:
	/* 0xb1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b21:
	/* 0xb21: je     b59 <do_action+0x906> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb21, 0xb59, x86_l_b59);
x86_l_b23:
	/* 0xb23: add    rax,0x5ef8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24312ULL);
x86_l_b29:
	/* 0xb29: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_b30:
	/* 0xb30: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b33:
	/* 0xb33: call   36d8 <do_action+0x3485> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b38:
	/* 0xb38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b3b:
	/* 0xb3b: je     b59 <do_action+0x906> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb3b, 0xb59, x86_l_b59);
x86_l_b3d:
	/* 0xb3d: cmp    DWORD PTR [rax+r13*4+0x44],0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 296352743423ULL);
x86_l_b43:
	/* 0xb43: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_b4b:
	/* 0xb4b: je     b61 <do_action+0x90e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb4b, 0xb61, x86_l_b61);
x86_l_b4d:
	/* 0xb4d: mov    ecx,DWORD PTR [r14+r13*8+0x5e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 3), 24192ULL);
x86_l_b55:
	/* 0xb55: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_b57:
	/* 0xb57: jmp    b6a <do_action+0x917> */
	X86_SIM_X86_SUB_JMP(0xb57, 0xb6a, x86_l_b6a);
x86_l_b59:
	/* 0xb59: mov    rdx,QWORD PTR [r14+r13*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 3), 24184ULL);
x86_l_b61:
	/* 0xb61: mov    ecx,DWORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b65:
	/* 0xb65: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_b67:
	/* 0xb67: add    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_b6a:
	/* 0xb6a: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b6c:
	/* 0xb6c: jle    a99 <do_action+0x846> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xb6c, 0xa99, x86_l_a99);
x86_l_b72:
	/* 0xb72: mov    ebp,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b74:
	/* 0xb74: cmp    ecx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_b77:
	/* 0xb77: jl     b7e <do_action+0x92b> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xb77, 0xb7e, x86_l_b7e);
x86_l_b79:
	/* 0xb79: mov    ebp,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_b7e:
	/* 0xb7e: add    edx,0x3ffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16380ULL);
x86_l_b84:
	/* 0xb84: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_b8a:
	/* 0xb8a: movzx  r8d,BYTE PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 40ULL);
x86_l_b90:
	/* 0xb90: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_b95:
	/* 0xb95: lea    rdi,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_b99:
	/* 0xb99: add    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b9c:
	/* 0xb9c: add    rdx,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_ba3:
	/* 0xba3: jns    a7a <do_action+0x827> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xba3, 0xa7a, x86_l_a7a);
x86_l_ba9:
	/* 0xba9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_bac:
	/* 0xbac: jns    be5 <do_action+0x992> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0xbac, 0xbe5, x86_l_be5);
x86_l_bae:
	/* 0xbae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bb0:
	/* 0xbb0: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_bb3:
	/* 0xbb3: jb     bcd <do_action+0x97a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbb3, 0xbcd, x86_l_bcd);
x86_l_bb5:
	/* 0xbb5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bb7:
	/* 0xbb7: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_bb9:
	/* 0xbb9: mov    rsi,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_bbd:
	/* 0xbbd: mov    QWORD PTR [rdi+rax*1],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_bc1:
	/* 0xbc1: lea    eax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bc4:
	/* 0xbc4: add    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_bc7:
	/* 0xbc7: cmp    ecx,ebp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_bc9:
	/* 0xbc9: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_bcb:
	/* 0xbcb: jbe    bb7 <do_action+0x964> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xbcb, 0xbb7, x86_l_bb7);
x86_l_bcd:
	/* 0xbcd: test   bpl,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_bd1:
	/* 0xbd1: jne    bf8 <do_action+0x9a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbd1, 0xbf8, x86_l_bf8);
x86_l_bd3:
	/* 0xbd3: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_bd7:
	/* 0xbd7: jne    c09 <do_action+0x9b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbd7, 0xc09, x86_l_c09);
x86_l_bd9:
	/* 0xbd9: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_bdd:
	/* 0xbdd: je     a8b <do_action+0x838> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbdd, 0xa8b, x86_l_a8b);
x86_l_be3:
	/* 0xbe3: jmp    c20 <do_action+0x9cd> */
	X86_SIM_X86_SUB_JMP(0xbe3, 0xc20, x86_l_c20);
x86_l_be5:
	/* 0xbe5: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_be7:
	/* 0xbe7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_be9:
	/* 0xbe9: mov    QWORD PTR [rsp+0x28],r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_bee:
	/* 0xbee: call   3793 <do_action+0x3540> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_bf3:
	/* 0xbf3: jmp    a86 <do_action+0x833> */
	X86_SIM_X86_SUB_JMP(0xbf3, 0xa86, x86_l_a86);
x86_l_bf8:
	/* 0xbf8: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_bfa:
	/* 0xbfa: mov    esi,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_bfd:
	/* 0xbfd: mov    DWORD PTR [rdi+rcx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_c00:
	/* 0xc00: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_c03:
	/* 0xc03: test   bpl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_c07:
	/* 0xc07: je     bd9 <do_action+0x986> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc07, 0xbd9, x86_l_bd9);
x86_l_c09:
	/* 0xc09: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c0b:
	/* 0xc0b: movzx  esi,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_c0f:
	/* 0xc0f: mov    WORD PTR [rdi+rcx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_c13:
	/* 0xc13: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_c16:
	/* 0xc16: test   bpl,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_c1a:
	/* 0xc1a: je     a8b <do_action+0x838> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc1a, 0xa8b, x86_l_a8b);
x86_l_c20:
	/* 0xc20: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c22:
	/* 0xc22: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_c26:
	/* 0xc26: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_c29:
	/* 0xc29: jmp    a8b <do_action+0x838> */
	X86_SIM_X86_SUB_JMP(0xc29, 0xa8b, x86_l_a8b);
x86_l_c2e:
	/* 0xc2e: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_c35:
	/* 0xc35: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c3a:
	/* 0xc3a: call   37df <do_action+0x358c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c3f:
	/* 0xc3f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c42:
	/* 0xc42: je     c61 <do_action+0xa0e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc42, 0xc61, x86_l_c61);
x86_l_c44:
	/* 0xc44: imul   rcx,QWORD PTR [rsp+0x70],0xfffffffffff0bdc0 */
	X86_SIM_RUN_OP(X86_OP_IMUL_MEM_IMM, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 485330304448ULL);
x86_l_c4d:
	/* 0xc4d: add    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_c52:
	/* 0xc52: cmp    QWORD PTR [rax],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c55:
	/* 0xc55: jbe    c61 <do_action+0xa0e> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xc55, 0xc61, x86_l_c61);
x86_l_c57:
	/* 0xc57: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c5c:
	/* 0xc5c: mov    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5f:
	/* 0xc5f: jmp    c79 <do_action+0xa26> */
	X86_SIM_X86_SUB_JMP(0xc5f, 0xc79, x86_l_c79);
x86_l_c61:
	/* 0xc61: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ratelimit_map));
x86_l_c68:
	/* 0xc68: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c6d:
	/* 0xc6d: mov    rsi,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c72:
	/* 0xc72: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c74:
	/* 0xc74: call   3819 <do_action+0x35c6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_c79:
	/* 0xc79: mov    r13,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_c7e:
	/* 0xc7e: lea    eax,[rbx+0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_c81:
	/* 0xc81: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_c87:
	/* 0xc87: je     ca6 <do_action+0xa53> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc87, 0xca6, x86_l_ca6);
x86_l_c89:
	/* 0xc89: or     BYTE PTR [r14+0x1],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967298ULL);
x86_l_c8e:
	/* 0xc8e: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_c95:
	/* 0xc95: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c98:
	/* 0xc98: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c9a:
	/* 0xc9a: call   383f <do_action+0x35ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_c9f:
	/* 0xc9f: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_ca6:
	/* 0xca6: lea    eax,[rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ca9:
	/* 0xca9: cmp    DWORD PTR [r15+rax*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 17179869184ULL);
x86_l_caf:
	/* 0xcaf: je     cd1 <do_action+0xa7e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcaf, 0xcd1, x86_l_cd1);
x86_l_cb1:
	/* 0xcb1: or     BYTE PTR [r14+0x1],0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967300ULL);
x86_l_cb6:
	/* 0xcb6: mov    rsi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_trace_map));
x86_l_cbd:
	/* 0xcbd: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_cc2:
	/* 0xcc2: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cc5:
	/* 0xcc5: call   386a <do_action+0x3617> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_cca:
	/* 0xcca: mov    QWORD PTR [r14+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_cd1:
	/* 0xcd1: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_cd4:
	/* 0xcd4: cmp    DWORD PTR [r15+rbx*4+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 17179869184ULL);
x86_l_cda:
	/* 0xcda: je     d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcda, 0xd77, x86_l_d77);
x86_l_ce0:
	/* 0xce0: or     BYTE PTR [r14+0x1],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4294967304ULL);
x86_l_ce5:
	/* 0xce5: jmp    d77 <do_action+0xb24> */
	X86_SIM_X86_SUB_JMP(0xce5, 0xd77, x86_l_d77);
x86_l_cea:
	/* 0xcea: mov    DWORD PTR [rsp+0x3c],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037761ULL);
x86_l_cf2:
	/* 0xcf2: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_cf9:
	/* 0xcf9: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cfe:
	/* 0xcfe: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_d03:
	/* 0xd03: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d05:
	/* 0xd05: call   38aa <do_action+0x3657> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_d0a:
	/* 0xd0a: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_d0d:
	/* 0xd0d: je     742 <do_action+0x4ef> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd0d, 0x742, x86_l_742);
x86_l_d13:
	/* 0xd13: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)enforcer_missed_notifications));
x86_l_d1a:
	/* 0xd1a: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d1f:
	/* 0xd1f: call   38c4 <do_action+0x3671> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d24:
	/* 0xd24: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d27:
	/* 0xd27: je     742 <do_action+0x4ef> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd27, 0x742, x86_l_742);
x86_l_d2d:
	/* 0xd2d: mov    ecx,DWORD PTR [rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_d31:
	/* 0xd31: lock add DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RAX, X86_RCX, (X86_WIDTH_32 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_d34:
	/* 0xd34: jmp    742 <do_action+0x4ef> */
	X86_SIM_X86_SUB_JMP(0xd34, 0x742, x86_l_742);
x86_l_d39:
	/* 0xd39: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d3c:
	/* 0xd3c: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d3e:
	/* 0xd3e: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d41:
	/* 0xd41: call   38e6 <do_action+0x3693> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d46:
	/* 0xd46: jmp    d55 <do_action+0xb02> */
	X86_SIM_X86_SUB_JMP(0xd46, 0xd55, x86_l_d55);
x86_l_d48:
	/* 0xd48: mov    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d4b:
	/* 0xd4b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d4d:
	/* 0xd4d: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d50:
	/* 0xd50: call   38f5 <do_action+0x36a2> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_d55:
	/* 0xd55: mov    rdx,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d5a:
	/* 0xd5a: mov    rdi,QWORD PTR [rip+0x2ba0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fdinstall_map));
x86_l_d61:
	/* 0xd61: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d64:
	/* 0xd64: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d69:
	/* 0xd69: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d6b:
	/* 0xd6b: call   3910 <do_action+0x36bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_d70:
	/* 0xd70: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d72:
	/* 0xd72: test   r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_d75:
	/* 0xd75: jne    d7f <do_action+0xb2c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd75, 0xd7f, x86_l_d7f);
x86_l_d77:
	/* 0xd77: mov    QWORD PTR [r14+0x70],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d7b:
	/* 0xd7b: inc    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d7d:
	/* 0xd7d: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_d7f:
	/* 0xd7f: add    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_d83:
	/* 0xd83: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d84:
	/* 0xd84: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d86:
	/* 0xd86: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d88:
	/* 0xd88: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d8a:
	/* 0xd8a: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d8c:
	/* 0xd8c: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d8d:
	/* 0xd8d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_d8d);
x86_l_d8e:
	/* 0xd8e: mov    ecx,DWORD PTR [rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_d91:
	/* 0xd91: mov    DWORD PTR [rdx+rdi*1],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_d94:
	/* 0xd94: add    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_d97:
	/* 0xd97: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_d9b:
	/* 0xd9b: je     576 <do_action+0x323> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xd9b, 0x576, x86_l_576);
x86_l_da1:
	/* 0xda1: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_da3:
	/* 0xda3: movzx  r8d,WORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_da8:
	/* 0xda8: mov    WORD PTR [rdx+rcx*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_dad:
	/* 0xdad: add    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_db0:
	/* 0xdb0: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_db4:
	/* 0xdb4: je     d5a <do_action+0xb07> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xdb4, 0xd5a, x86_l_d5a);
x86_l_db6:
	/* 0xdb6: mov    ecx,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_db8:
	/* 0xdb8: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_dbc:
	/* 0xdbc: mov    BYTE PTR [rdx+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_dbf:
	/* 0xdbf: jmp    d5a <do_action+0xb07> */
	X86_SIM_X86_SUB_JMP(0xdbf, 0xd5a, x86_l_d5a);

x86_sim_ret_dispatch_d8d:
	switch (__x86_sim_ret_addr) {
	case 0x1e9ULL: goto x86_l_1e9;
	case 0x20aULL: goto x86_l_20a;
	case 0x22bULL: goto x86_l_22b;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
