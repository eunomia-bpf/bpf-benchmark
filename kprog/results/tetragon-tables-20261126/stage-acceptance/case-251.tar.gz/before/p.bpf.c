#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(7) M(8) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(19) M(22) M(23) M(24)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/load_elf_phdrs")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 200ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xac],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_load_elf_phdrs+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x348e, x86_l_348e);
x86_l_3c:
	/* 0x3c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_load_elf_phdrs+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x348e, x86_l_348e);
x86_l_5c:
	/* 0x5c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9e:
	/* 0x9e: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a9:
	/* 0xa9: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b4:
	/* 0xb4: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bf:
	/* 0xbf: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ca:
	/* 0xca: call   cf <trace_load_elf_phdrs+0xcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f6:
	/* 0xf6: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_116:
	/* 0x116: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11e:
	/* 0x11e: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12e:
	/* 0x12e: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13e:
	/* 0x13e: call   143 <trace_load_elf_phdrs+0x143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_143:
	/* 0x143: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [rbp+0x70],0x2fc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337916ULL);
x86_l_154:
	/* 0x154: call   159 <trace_load_elf_phdrs+0x159> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d:
	/* 0x15d: call   162 <trace_load_elf_phdrs+0x162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_162:
	/* 0x162: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_166:
	/* 0x166: call   16b <trace_load_elf_phdrs+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16b:
	/* 0x16b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: jns    186 <trace_load_elf_phdrs+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175, 0x186, x86_l_186);
x86_l_177:
	/* 0x177: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17e:
	/* 0x17e: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_184:
	/* 0x184: jne    1c3 <trace_load_elf_phdrs+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184, 0x1c3, x86_l_1c3);
x86_l_186:
	/* 0x186: call   18b <trace_load_elf_phdrs+0x18b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18b:
	/* 0x18b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: call   193 <trace_load_elf_phdrs+0x193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_193:
	/* 0x193: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: jns    1aa <trace_load_elf_phdrs+0x1aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19a, 0x1aa, x86_l_1aa);
x86_l_19c:
	/* 0x19c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a3:
	/* 0x1a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     1b5 <trace_load_elf_phdrs+0x1b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a6, 0x1b5, x86_l_1b5);
x86_l_1a8:
	/* 0x1a8: jmp    1bf <trace_load_elf_phdrs+0x1bf> */
	X86_SIM_X86_JMP(0x1a8, 0x1bf, x86_l_1bf);
x86_l_1aa:
	/* 0x1aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac:
	/* 0x1ac: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1b0:
	/* 0x1b0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: jns    1bf <trace_load_elf_phdrs+0x1bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3, 0x1bf, x86_l_1bf);
x86_l_1b5:
	/* 0x1b5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7:
	/* 0x1b7: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b9:
	/* 0x1b9: jne    539 <trace_load_elf_phdrs+0x539> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b9, 0x539, x86_l_539);
x86_l_1bf:
	/* 0x1bf: mov    eax,DWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [r13+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1cb:
	/* 0x1cb: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1e1:
	/* 0x1e1: call   1e6 <trace_load_elf_phdrs+0x1e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e6:
	/* 0x1e6: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1eb:
	/* 0x1eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ee:
	/* 0x1ee: je     ac0 <trace_load_elf_phdrs+0xac0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee, 0xac0, x86_l_ac0);
x86_l_1f4:
	/* 0x1f4: mov    eax,DWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f8:
	/* 0x1f8: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_1ff:
	/* 0x1ff: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_206:
	/* 0x206: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_20e:
	/* 0x20e: call   213 <trace_load_elf_phdrs+0x213> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_213:
	/* 0x213: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_216:
	/* 0x216: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: mov    QWORD PTR [rsp+0x40],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_21e:
	/* 0x21e: mov    QWORD PTR [rsp+0x10],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_223:
	/* 0x223: mov    QWORD PTR [rsp+0x28],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_228:
	/* 0x228: je     b43 <trace_load_elf_phdrs+0xb43> */
	X86_SIM_X86_JCC(X86_CC_E, 0x228, 0xb43, x86_l_b43);
x86_l_22e:
	/* 0x22e: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_234:
	/* 0x234: jne    23d <trace_load_elf_phdrs+0x23d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x234, 0x23d, x86_l_23d);
x86_l_236:
	/* 0x236: call   23b <trace_load_elf_phdrs+0x23b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_23b:
	/* 0x23b: jmp    295 <trace_load_elf_phdrs+0x295> */
	X86_SIM_X86_JMP(0x23b, 0x295, x86_l_295);
x86_l_23d:
	/* 0x23d: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_242:
	/* 0x242: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_249:
	/* 0x249: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24c:
	/* 0x24c: jns    266 <trace_load_elf_phdrs+0x266> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24c, 0x266, x86_l_266);
x86_l_24e:
	/* 0x24e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_251:
	/* 0x251: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_254:
	/* 0x254: js     26d <trace_load_elf_phdrs+0x26d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x254, 0x26d, x86_l_26d);
x86_l_256:
	/* 0x256: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258:
	/* 0x258: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: js     275 <trace_load_elf_phdrs+0x275> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25b, 0x275, x86_l_275);
x86_l_25d:
	/* 0x25d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f:
	/* 0x25f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_262:
	/* 0x262: js     27d <trace_load_elf_phdrs+0x27d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x262, 0x27d, x86_l_27d);
x86_l_264:
	/* 0x264: jmp    293 <trace_load_elf_phdrs+0x293> */
	X86_SIM_X86_JMP(0x264, 0x293, x86_l_293);
x86_l_266:
	/* 0x266: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268:
	/* 0x268: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26b:
	/* 0x26b: jns    256 <trace_load_elf_phdrs+0x256> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26b, 0x256, x86_l_256);
x86_l_26d:
	/* 0x26d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_270:
	/* 0x270: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: jns    25d <trace_load_elf_phdrs+0x25d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x273, 0x25d, x86_l_25d);
x86_l_275:
	/* 0x275: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278:
	/* 0x278: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27b:
	/* 0x27b: jns    293 <trace_load_elf_phdrs+0x293> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27b, 0x293, x86_l_293);
x86_l_27d:
	/* 0x27d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280:
	/* 0x280: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_283:
	/* 0x283: je     293 <trace_load_elf_phdrs+0x293> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283, 0x293, x86_l_293);
x86_l_285:
	/* 0x285: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_289:
	/* 0x289: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28c:
	/* 0x28c: jns    293 <trace_load_elf_phdrs+0x293> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c, 0x293, x86_l_293);
x86_l_28e:
	/* 0x28e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_291:
	/* 0x291: jmp    295 <trace_load_elf_phdrs+0x295> */
	X86_SIM_X86_JMP(0x291, 0x295, x86_l_295);
x86_l_293:
	/* 0x293: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_295:
	/* 0x295: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_299:
	/* 0x299: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29d:
	/* 0x29d: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2a1:
	/* 0x2a1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_2a8:
	/* 0x2a8: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2ad:
	/* 0x2ad: call   2b2 <trace_load_elf_phdrs+0x2b2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b2:
	/* 0x2b2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b5:
	/* 0x2b5: je     2cd <trace_load_elf_phdrs+0x2cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b5, 0x2cd, x86_l_2cd);
x86_l_2b7:
	/* 0x2b7: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2ba:
	/* 0x2ba: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2c0:
	/* 0x2c0: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2c3:
	/* 0x2c3: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2c6:
	/* 0x2c6: jne    2cd <trace_load_elf_phdrs+0x2cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c6, 0x2cd, x86_l_2cd);
x86_l_2c8:
	/* 0x2c8: or     BYTE PTR [r13+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2cd:
	/* 0x2cd: movzx  eax,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2d2:
	/* 0x2d2: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2d8:
	/* 0x2d8: jne    be0 <trace_load_elf_phdrs+0xbe0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d8, 0xbe0, x86_l_be0);
x86_l_2de:
	/* 0x2de: mov    QWORD PTR [r13+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2e9:
	/* 0x2e9: mov    DWORD PTR [rsp+0x50],0x2fc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597384444ULL);
x86_l_2f1:
	/* 0x2f1: mov    WORD PTR [rsp+0x4c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_2f6:
	/* 0x2f6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_2fd:
	/* 0x2fd: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_302:
	/* 0x302: call   307 <trace_load_elf_phdrs+0x307> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_307:
	/* 0x307: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: je     375 <trace_load_elf_phdrs+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30a, 0x375, x86_l_375);
x86_l_30c:
	/* 0x30c: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_311:
	/* 0x311: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_314:
	/* 0x314: call   319 <trace_load_elf_phdrs+0x319> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_319:
	/* 0x319: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31c:
	/* 0x31c: je     375 <trace_load_elf_phdrs+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c, 0x375, x86_l_375);
x86_l_31e:
	/* 0x31e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_322:
	/* 0x322: mov    QWORD PTR [r13+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_329:
	/* 0x329: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32c:
	/* 0x32c: mov    QWORD PTR [r13+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_333:
	/* 0x333: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_337:
	/* 0x337: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33b:
	/* 0x33b: mov    QWORD PTR [r13+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_342:
	/* 0x342: mov    QWORD PTR [r13+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_349:
	/* 0x349: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_34d:
	/* 0x34d: mov    QWORD PTR [r13+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_354:
	/* 0x354: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_358:
	/* 0x358: mov    QWORD PTR [r13+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_35f:
	/* 0x35f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_363:
	/* 0x363: mov    QWORD PTR [r13+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_36a:
	/* 0x36a: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_36e:
	/* 0x36e: mov    QWORD PTR [r13+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_375:
	/* 0x375: mov    rax,QWORD PTR [r13+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_37c:
	/* 0x37c: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_383:
	/* 0x383: mov    r15,QWORD PTR [r14+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_387:
	/* 0x387: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_38f:
	/* 0x38f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_396:
	/* 0x396: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_39b:
	/* 0x39b: call   3a0 <trace_load_elf_phdrs+0x3a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a0:
	/* 0x3a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a3:
	/* 0x3a3: mov    QWORD PTR [rsp+0xb0],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3ab:
	/* 0x3ab: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3b0:
	/* 0x3b0: je     3d0 <trace_load_elf_phdrs+0x3d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b0, 0x3d0, x86_l_3d0);
x86_l_3b2:
	/* 0x3b2: mov    r9,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b5:
	/* 0x3b5: lea    rax,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3b9:
	/* 0x3b9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bc:
	/* 0x3bc: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3c1:
	/* 0x3c1: jns    3dd <trace_load_elf_phdrs+0x3dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c1, 0x3dd, x86_l_3dd);
x86_l_3c3:
	/* 0x3c3: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c6:
	/* 0x3c6: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3c9:
	/* 0x3c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3cc:
	/* 0x3cc: js     3e7 <trace_load_elf_phdrs+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3cc, 0x3e7, x86_l_3e7);
x86_l_3ce:
	/* 0x3ce: jmp    3f1 <trace_load_elf_phdrs+0x3f1> */
	X86_SIM_X86_JMP(0x3ce, 0x3f1, x86_l_3f1);
x86_l_3d0:
	/* 0x3d0: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d3:
	/* 0x3d3: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3d8:
	/* 0x3d8: jmp    2318 <trace_load_elf_phdrs+0x2318> */
	X86_SIM_X86_JMP(0x3d8, 0x2318, x86_l_2318);
x86_l_3dd:
	/* 0x3dd: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3df:
	/* 0x3df: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3e2:
	/* 0x3e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e5:
	/* 0x3e5: jns    3f1 <trace_load_elf_phdrs+0x3f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e5, 0x3f1, x86_l_3f1);
x86_l_3e7:
	/* 0x3e7: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e9:
	/* 0x3e9: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_3eb:
	/* 0x3eb: jne    556 <trace_load_elf_phdrs+0x556> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3eb, 0x556, x86_l_556);
x86_l_3f1:
	/* 0x3f1: lea    rax,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3f5:
	/* 0x3f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f8:
	/* 0x3f8: jns    3ff <trace_load_elf_phdrs+0x3ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f8, 0x3ff, x86_l_3ff);
x86_l_3fa:
	/* 0x3fa: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fd:
	/* 0x3fd: jmp    401 <trace_load_elf_phdrs+0x401> */
	X86_SIM_X86_JMP(0x3fd, 0x401, x86_l_401);
x86_l_3ff:
	/* 0x3ff: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_401:
	/* 0x401: lea    r10,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_405:
	/* 0x405: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_408:
	/* 0x408: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_40b:
	/* 0x40b: jns    42f <trace_load_elf_phdrs+0x42f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x40b, 0x42f, x86_l_42f);
x86_l_40d:
	/* 0x40d: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_410:
	/* 0x410: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_413:
	/* 0x413: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_416:
	/* 0x416: js     439 <trace_load_elf_phdrs+0x439> */
	X86_SIM_X86_JCC(X86_CC_S, 0x416, 0x439, x86_l_439);
x86_l_418:
	/* 0x418: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_41a:
	/* 0x41a: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_41e:
	/* 0x41e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_421:
	/* 0x421: js     445 <trace_load_elf_phdrs+0x445> */
	X86_SIM_X86_JCC(X86_CC_S, 0x421, 0x445, x86_l_445);
x86_l_423:
	/* 0x423: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_425:
	/* 0x425: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_428:
	/* 0x428: jne    451 <trace_load_elf_phdrs+0x451> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x428, 0x451, x86_l_451);
x86_l_42a:
	/* 0x42a: jmp    4f8 <trace_load_elf_phdrs+0x4f8> */
	X86_SIM_X86_JMP(0x42a, 0x4f8, x86_l_4f8);
x86_l_42f:
	/* 0x42f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_431:
	/* 0x431: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_434:
	/* 0x434: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_437:
	/* 0x437: jns    418 <trace_load_elf_phdrs+0x418> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x437, 0x418, x86_l_418);
x86_l_439:
	/* 0x439: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_43c:
	/* 0x43c: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_440:
	/* 0x440: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_443:
	/* 0x443: jns    423 <trace_load_elf_phdrs+0x423> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x443, 0x423, x86_l_423);
x86_l_445:
	/* 0x445: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_448:
	/* 0x448: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_44b:
	/* 0x44b: je     4f8 <trace_load_elf_phdrs+0x4f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44b, 0x4f8, x86_l_4f8);
x86_l_451:
	/* 0x451: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_454:
	/* 0x454: je     4f8 <trace_load_elf_phdrs+0x4f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x454, 0x4f8, x86_l_4f8);
x86_l_45a:
	/* 0x45a: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_45f:
	/* 0x45f: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_463:
	/* 0x463: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_466:
	/* 0x466: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_46c:
	/* 0x46c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_46f:
	/* 0x46f: jns    478 <trace_load_elf_phdrs+0x478> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x46f, 0x478, x86_l_478);
x86_l_471:
	/* 0x471: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_474:
	/* 0x474: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_478:
	/* 0x478: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_47c:
	/* 0x47c: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_47f:
	/* 0x47f: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_486:
	/* 0x486: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_489:
	/* 0x489: je     58d <trace_load_elf_phdrs+0x58d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x489, 0x58d, x86_l_58d);
x86_l_48f:
	/* 0x48f: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_492:
	/* 0x492: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_494:
	/* 0x494: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_49a:
	/* 0x49a: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_49f:
	/* 0x49f: mov    r12d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_4a5:
	/* 0x4a5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_4a8:
	/* 0x4a8: jns    1026 <trace_load_elf_phdrs+0x1026> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4a8, 0x1026, x86_l_1026);
x86_l_4ae:
	/* 0x4ae: mov    r12,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_4b1:
	/* 0x4b1: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4b4:
	/* 0x4b4: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_4b8:
	/* 0x4b8: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4bb:
	/* 0x4bb: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_4be:
	/* 0x4be: je     602 <trace_load_elf_phdrs+0x602> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4be, 0x602, x86_l_602);
x86_l_4c4:
	/* 0x4c4: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4c8:
	/* 0x4c8: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_4cd:
	/* 0x4cd: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_4d1:
	/* 0x4d1: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4d4:
	/* 0x4d4: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_4d7:
	/* 0x4d7: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4dc:
	/* 0x4dc: jne    4bb <trace_load_elf_phdrs+0x4bb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4dc, 0x4bb, x86_l_4bb);
x86_l_4de:
	/* 0x4de: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_4e1:
	/* 0x4e1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4e5:
	/* 0x4e5: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4e8:
	/* 0x4e8: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4ed:
	/* 0x4ed: jge    619 <trace_load_elf_phdrs+0x619> */
	X86_SIM_X86_JCC(X86_CC_GE, 0x4ed, 0x619, x86_l_619);
x86_l_4f3:
	/* 0x4f3: jmp    1048 <trace_load_elf_phdrs+0x1048> */
	X86_SIM_X86_JMP(0x4f3, 0x1048, x86_l_1048);
x86_l_4f8:
	/* 0x4f8: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4fb:
	/* 0x4fb: jne    1048 <trace_load_elf_phdrs+0x1048> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4fb, 0x1048, x86_l_1048);
x86_l_501:
	/* 0x501: cmp    r10,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_504:
	/* 0x504: je     1048 <trace_load_elf_phdrs+0x1048> */
	X86_SIM_X86_JCC(X86_CC_E, 0x504, 0x1048, x86_l_1048);
x86_l_50a:
	/* 0x50a: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_50e:
	/* 0x50e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_511:
	/* 0x511: jns    5bb <trace_load_elf_phdrs+0x5bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x511, 0x5bb, x86_l_5bb);
x86_l_517:
	/* 0x517: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51a:
	/* 0x51a: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_51d:
	/* 0x51d: js     5c6 <trace_load_elf_phdrs+0x5c6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x51d, 0x5c6, x86_l_5c6);
x86_l_523:
	/* 0x523: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_526:
	/* 0x526: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_529:
	/* 0x529: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_52c:
	/* 0x52c: js     5d5 <trace_load_elf_phdrs+0x5d5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x52c, 0x5d5, x86_l_5d5);
x86_l_532:
	/* 0x532: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_534:
	/* 0x534: jmp    5d8 <trace_load_elf_phdrs+0x5d8> */
	X86_SIM_X86_JMP(0x534, 0x5d8, x86_l_5d8);
x86_l_539:
	/* 0x539: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_540:
	/* 0x540: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_545:
	/* 0x545: call   54a <trace_load_elf_phdrs+0x54a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54a:
	/* 0x54a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54d:
	/* 0x54d: je     5b1 <trace_load_elf_phdrs+0x5b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54d, 0x5b1, x86_l_5b1);
x86_l_54f:
	/* 0x54f: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_551:
	/* 0x551: jmp    1c3 <trace_load_elf_phdrs+0x1c3> */
	X86_SIM_X86_JMP(0x551, 0x1c3, x86_l_1c3);
x86_l_556:
	/* 0x556: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_55d:
	/* 0x55d: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_560:
	/* 0x560: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_563:
	/* 0x563: jns    597 <trace_load_elf_phdrs+0x597> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x563, 0x597, x86_l_597);
x86_l_565:
	/* 0x565: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_567:
	/* 0x567: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_56c:
	/* 0x56c: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_573:
	/* 0x573: je     10ae <trace_load_elf_phdrs+0x10ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x573, 0x10ae, x86_l_10ae);
x86_l_579:
	/* 0x579: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_57d:
	/* 0x57d: mov    BYTE PTR [r9+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R9, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_581:
	/* 0x581: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_584:
	/* 0x584: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_586:
	/* 0x586: jne    56c <trace_load_elf_phdrs+0x56c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x586, 0x56c, x86_l_56c);
x86_l_588:
	/* 0x588: jmp    2306 <trace_load_elf_phdrs+0x2306> */
	X86_SIM_X86_JMP(0x588, 0x2306, x86_l_2306);
x86_l_58d:
	/* 0x58d: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_592:
	/* 0x592: jmp    1048 <trace_load_elf_phdrs+0x1048> */
	X86_SIM_X86_JMP(0x592, 0x1048, x86_l_1048);
x86_l_597:
	/* 0x597: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_59c:
	/* 0x59c: mov    rdi,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_59f:
	/* 0x59f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5a1:
	/* 0x5a1: mov    rbp,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_5a4:
	/* 0x5a4: call   5a9 <trace_load_elf_phdrs+0x5a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_5a9:
	/* 0x5a9: mov    r9,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5ac:
	/* 0x5ac: jmp    2301 <trace_load_elf_phdrs+0x2301> */
	X86_SIM_X86_JMP(0x5ac, 0x2301, x86_l_2301);
x86_l_5b1:
	/* 0x5b1: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_5b6:
	/* 0x5b6: jmp    1c3 <trace_load_elf_phdrs+0x1c3> */
	X86_SIM_X86_JMP(0x5b6, 0x1c3, x86_l_1c3);
x86_l_5bb:
	/* 0x5bb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5bd:
	/* 0x5bd: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_5c0:
	/* 0x5c0: jns    523 <trace_load_elf_phdrs+0x523> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5c0, 0x523, x86_l_523);
x86_l_5c6:
	/* 0x5c6: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c9:
	/* 0x5c9: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_5cc:
	/* 0x5cc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5cf:
	/* 0x5cf: jns    532 <trace_load_elf_phdrs+0x532> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5cf, 0x532, x86_l_532);
x86_l_5d5:
	/* 0x5d5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d8:
	/* 0x5d8: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5dc:
	/* 0x5dc: mov    r12d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_5e2:
	/* 0x5e2: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5e5:
	/* 0x5e5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_5e8:
	/* 0x5e8: jns    638 <trace_load_elf_phdrs+0x638> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5e8, 0x638, x86_l_638);
x86_l_5ea:
	/* 0x5ea: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ed:
	/* 0x5ed: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5f1:
	/* 0x5f1: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_5f4:
	/* 0x5f4: js     643 <trace_load_elf_phdrs+0x643> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5f4, 0x643, x86_l_643);
x86_l_5f6:
	/* 0x5f6: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5f8:
	/* 0x5f8: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_5fb:
	/* 0x5fb: jne    64f <trace_load_elf_phdrs+0x64f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5fb, 0x64f, x86_l_64f);
x86_l_5fd:
	/* 0x5fd: jmp    6e3 <trace_load_elf_phdrs+0x6e3> */
	X86_SIM_X86_JMP(0x5fd, 0x6e3, x86_l_6e3);
x86_l_602:
	/* 0x602: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_607:
	/* 0x607: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_60b:
	/* 0x60b: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_60e:
	/* 0x60e: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_613:
	/* 0x613: jl     1048 <trace_load_elf_phdrs+0x1048> */
	X86_SIM_X86_JCC(X86_CC_L, 0x613, 0x1048, x86_l_1048);
x86_l_619:
	/* 0x619: mov    r10,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_61c:
	/* 0x61c: mov    BYTE PTR [r9+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_624:
	/* 0x624: mov    r12d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_62a:
	/* 0x62a: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_62d:
	/* 0x62d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_630:
	/* 0x630: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_633:
	/* 0x633: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_636:
	/* 0x636: js     5ea <trace_load_elf_phdrs+0x5ea> */
	X86_SIM_X86_JCC(X86_CC_S, 0x636, 0x5ea, x86_l_5ea);
x86_l_638:
	/* 0x638: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_63a:
	/* 0x63a: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_63e:
	/* 0x63e: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_641:
	/* 0x641: jns    5f6 <trace_load_elf_phdrs+0x5f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x641, 0x5f6, x86_l_5f6);
x86_l_643:
	/* 0x643: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_646:
	/* 0x646: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_649:
	/* 0x649: je     6e3 <trace_load_elf_phdrs+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x649, 0x6e3, x86_l_6e3);
x86_l_64f:
	/* 0x64f: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_652:
	/* 0x652: je     6e3 <trace_load_elf_phdrs+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x652, 0x6e3, x86_l_6e3);
x86_l_658:
	/* 0x658: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_65d:
	/* 0x65d: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_661:
	/* 0x661: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_664:
	/* 0x664: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_66a:
	/* 0x66a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_66d:
	/* 0x66d: jns    676 <trace_load_elf_phdrs+0x676> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x66d, 0x676, x86_l_676);
x86_l_66f:
	/* 0x66f: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_672:
	/* 0x672: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_676:
	/* 0x676: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_67a:
	/* 0x67a: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_67d:
	/* 0x67d: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_684:
	/* 0x684: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_687:
	/* 0x687: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_68a:
	/* 0x68a: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x68a, 0x22e4, x86_l_22e4);
x86_l_690:
	/* 0x690: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_693:
	/* 0x693: je     1033 <trace_load_elf_phdrs+0x1033> */
	X86_SIM_X86_JCC(X86_CC_E, 0x693, 0x1033, x86_l_1033);
x86_l_699:
	/* 0x699: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_69f:
	/* 0x69f: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_6a4:
	/* 0x6a4: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_6a7:
	/* 0x6a7: jns    1023 <trace_load_elf_phdrs+0x1023> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6a7, 0x1023, x86_l_1023);
x86_l_6ad:
	/* 0x6ad: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_6b0:
	/* 0x6b0: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_6b5:
	/* 0x6b5: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6b8:
	/* 0x6b8: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_6bc:
	/* 0x6bc: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6bf:
	/* 0x6bf: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_6c2:
	/* 0x6c2: je     73d <trace_load_elf_phdrs+0x73d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c2, 0x73d, x86_l_73d);
x86_l_6c4:
	/* 0x6c4: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_6c8:
	/* 0x6c8: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_6cd:
	/* 0x6cd: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_6d1:
	/* 0x6d1: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6d4:
	/* 0x6d4: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_6d7:
	/* 0x6d7: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6dc:
	/* 0x6dc: jne    6bf <trace_load_elf_phdrs+0x6bf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6dc, 0x6bf, x86_l_6bf);
x86_l_6de:
	/* 0x6de: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_6e1:
	/* 0x6e1: jmp    742 <trace_load_elf_phdrs+0x742> */
	X86_SIM_X86_JMP(0x6e1, 0x742, x86_l_742);
x86_l_6e3:
	/* 0x6e3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_6e6:
	/* 0x6e6: jne    1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6e6, 0x1038, x86_l_1038);
x86_l_6ec:
	/* 0x6ec: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ef:
	/* 0x6ef: je     1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ef, 0x1038, x86_l_1038);
x86_l_6f5:
	/* 0x6f5: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6f9:
	/* 0x6f9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6fc:
	/* 0x6fc: jns    703 <trace_load_elf_phdrs+0x703> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6fc, 0x703, x86_l_703);
x86_l_6fe:
	/* 0x6fe: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_701:
	/* 0x701: jmp    705 <trace_load_elf_phdrs+0x705> */
	X86_SIM_X86_JMP(0x701, 0x705, x86_l_705);
x86_l_703:
	/* 0x703: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_705:
	/* 0x705: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_708:
	/* 0x708: jns    70f <trace_load_elf_phdrs+0x70f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x708, 0x70f, x86_l_70f);
x86_l_70a:
	/* 0x70a: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_70d:
	/* 0x70d: jmp    712 <trace_load_elf_phdrs+0x712> */
	X86_SIM_X86_JMP(0x70d, 0x712, x86_l_712);
x86_l_70f:
	/* 0x70f: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_712:
	/* 0x712: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_715:
	/* 0x715: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_718:
	/* 0x718: jns    71f <trace_load_elf_phdrs+0x71f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x718, 0x71f, x86_l_71f);
x86_l_71a:
	/* 0x71a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_71d:
	/* 0x71d: jmp    721 <trace_load_elf_phdrs+0x721> */
	X86_SIM_X86_JMP(0x71d, 0x721, x86_l_721);
x86_l_71f:
	/* 0x71f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_721:
	/* 0x721: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_725:
	/* 0x725: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_728:
	/* 0x728: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_72b:
	/* 0x72b: jns    777 <trace_load_elf_phdrs+0x777> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x72b, 0x777, x86_l_777);
x86_l_72d:
	/* 0x72d: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_730:
	/* 0x730: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_734:
	/* 0x734: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_737:
	/* 0x737: js     782 <trace_load_elf_phdrs+0x782> */
	X86_SIM_X86_JCC(X86_CC_S, 0x737, 0x782, x86_l_782);
x86_l_739:
	/* 0x739: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_73b:
	/* 0x73b: jmp    785 <trace_load_elf_phdrs+0x785> */
	X86_SIM_X86_JMP(0x73b, 0x785, x86_l_785);
x86_l_73d:
	/* 0x73d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_742:
	/* 0x742: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_746:
	/* 0x746: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_749:
	/* 0x749: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_74e:
	/* 0x74e: jl     1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_L, 0x74e, 0x1038, x86_l_1038);
x86_l_754:
	/* 0x754: mov    r10,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_757:
	/* 0x757: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_75c:
	/* 0x75c: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_762:
	/* 0x762: mov    BYTE PTR [r9+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_767:
	/* 0x767: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_76a:
	/* 0x76a: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_76f:
	/* 0x76f: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_772:
	/* 0x772: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_775:
	/* 0x775: js     72d <trace_load_elf_phdrs+0x72d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x775, 0x72d, x86_l_72d);
x86_l_777:
	/* 0x777: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_779:
	/* 0x779: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_77d:
	/* 0x77d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_780:
	/* 0x780: jns    739 <trace_load_elf_phdrs+0x739> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x780, 0x739, x86_l_739);
x86_l_782:
	/* 0x782: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_785:
	/* 0x785: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_788:
	/* 0x788: je     822 <trace_load_elf_phdrs+0x822> */
	X86_SIM_X86_JCC(X86_CC_E, 0x788, 0x822, x86_l_822);
x86_l_78e:
	/* 0x78e: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_791:
	/* 0x791: je     822 <trace_load_elf_phdrs+0x822> */
	X86_SIM_X86_JCC(X86_CC_E, 0x791, 0x822, x86_l_822);
x86_l_797:
	/* 0x797: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_79c:
	/* 0x79c: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a0:
	/* 0x7a0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7a3:
	/* 0x7a3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_7a9:
	/* 0x7a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_7ac:
	/* 0x7ac: jns    7b5 <trace_load_elf_phdrs+0x7b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ac, 0x7b5, x86_l_7b5);
x86_l_7ae:
	/* 0x7ae: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b1:
	/* 0x7b1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7b5:
	/* 0x7b5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_7b9:
	/* 0x7b9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_7bc:
	/* 0x7bc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_7c3:
	/* 0x7c3: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_7c6:
	/* 0x7c6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_7c9:
	/* 0x7c9: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7c9, 0x22e4, x86_l_22e4);
x86_l_7cf:
	/* 0x7cf: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_7d2:
	/* 0x7d2: je     1030 <trace_load_elf_phdrs+0x1030> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d2, 0x1030, x86_l_1030);
x86_l_7d8:
	/* 0x7d8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_7de:
	/* 0x7de: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_7e3:
	/* 0x7e3: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_7e6:
	/* 0x7e6: jns    1026 <trace_load_elf_phdrs+0x1026> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7e6, 0x1026, x86_l_1026);
x86_l_7ec:
	/* 0x7ec: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_7ef:
	/* 0x7ef: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7f4:
	/* 0x7f4: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7f7:
	/* 0x7f7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_7fb:
	/* 0x7fb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7fe:
	/* 0x7fe: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_801:
	/* 0x801: je     871 <trace_load_elf_phdrs+0x871> */
	X86_SIM_X86_JCC(X86_CC_E, 0x801, 0x871, x86_l_871);
x86_l_803:
	/* 0x803: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_807:
	/* 0x807: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_80c:
	/* 0x80c: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_810:
	/* 0x810: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_813:
	/* 0x813: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_816:
	/* 0x816: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_81b:
	/* 0x81b: jne    7fe <trace_load_elf_phdrs+0x7fe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x81b, 0x7fe, x86_l_7fe);
x86_l_81d:
	/* 0x81d: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_820:
	/* 0x820: jmp    876 <trace_load_elf_phdrs+0x876> */
	X86_SIM_X86_JMP(0x820, 0x876, x86_l_876);
x86_l_822:
	/* 0x822: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_825:
	/* 0x825: jne    14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x825, 0x14f2, x86_l_14f2);
x86_l_82b:
	/* 0x82b: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_82e:
	/* 0x82e: je     14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x82e, 0x14f2, x86_l_14f2);
x86_l_834:
	/* 0x834: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_838:
	/* 0x838: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_83b:
	/* 0x83b: jns    842 <trace_load_elf_phdrs+0x842> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83b, 0x842, x86_l_842);
x86_l_83d:
	/* 0x83d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_840:
	/* 0x840: jmp    844 <trace_load_elf_phdrs+0x844> */
	X86_SIM_X86_JMP(0x840, 0x844, x86_l_844);
x86_l_842:
	/* 0x842: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_844:
	/* 0x844: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_847:
	/* 0x847: jns    84e <trace_load_elf_phdrs+0x84e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x847, 0x84e, x86_l_84e);
x86_l_849:
	/* 0x849: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84c:
	/* 0x84c: jmp    851 <trace_load_elf_phdrs+0x851> */
	X86_SIM_X86_JMP(0x84c, 0x851, x86_l_851);
x86_l_84e:
	/* 0x84e: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_851:
	/* 0x851: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_854:
	/* 0x854: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_857:
	/* 0x857: jns    85e <trace_load_elf_phdrs+0x85e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x857, 0x85e, x86_l_85e);
x86_l_859:
	/* 0x859: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85c:
	/* 0x85c: jmp    860 <trace_load_elf_phdrs+0x860> */
	X86_SIM_X86_JMP(0x85c, 0x860, x86_l_860);
x86_l_85e:
	/* 0x85e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_860:
	/* 0x860: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_864:
	/* 0x864: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_867:
	/* 0x867: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_86a:
	/* 0x86a: jns    8ab <trace_load_elf_phdrs+0x8ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x86a, 0x8ab, x86_l_8ab);
x86_l_86c:
	/* 0x86c: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86f:
	/* 0x86f: jmp    8ad <trace_load_elf_phdrs+0x8ad> */
	X86_SIM_X86_JMP(0x86f, 0x8ad, x86_l_8ad);
x86_l_871:
	/* 0x871: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_876:
	/* 0x876: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_87a:
	/* 0x87a: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_87d:
	/* 0x87d: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_882:
	/* 0x882: jl     14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0x882, 0x14f2, x86_l_14f2);
x86_l_888:
	/* 0x888: mov    r10,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88b:
	/* 0x88b: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_890:
	/* 0x890: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_896:
	/* 0x896: mov    BYTE PTR [r9+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_89b:
	/* 0x89b: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_89e:
	/* 0x89e: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8a3:
	/* 0x8a3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_8a6:
	/* 0x8a6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8a9:
	/* 0x8a9: js     86c <trace_load_elf_phdrs+0x86c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8a9, 0x86c, x86_l_86c);
x86_l_8ab:
	/* 0x8ab: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8ad:
	/* 0x8ad: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8b1:
	/* 0x8b1: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_8b4:
	/* 0x8b4: jns    8bb <trace_load_elf_phdrs+0x8bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8b4, 0x8bb, x86_l_8bb);
x86_l_8b6:
	/* 0x8b6: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8b9:
	/* 0x8b9: jmp    8bd <trace_load_elf_phdrs+0x8bd> */
	X86_SIM_X86_JMP(0x8b9, 0x8bd, x86_l_8bd);
x86_l_8bb:
	/* 0x8bb: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8bd:
	/* 0x8bd: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8c0:
	/* 0x8c0: je     95a <trace_load_elf_phdrs+0x95a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c0, 0x95a, x86_l_95a);
x86_l_8c6:
	/* 0x8c6: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_8c9:
	/* 0x8c9: je     95a <trace_load_elf_phdrs+0x95a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8c9, 0x95a, x86_l_95a);
x86_l_8cf:
	/* 0x8cf: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8d4:
	/* 0x8d4: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8d8:
	/* 0x8d8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8db:
	/* 0x8db: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_8e1:
	/* 0x8e1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8e4:
	/* 0x8e4: jns    8ed <trace_load_elf_phdrs+0x8ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e4, 0x8ed, x86_l_8ed);
x86_l_8e6:
	/* 0x8e6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e9:
	/* 0x8e9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8ed:
	/* 0x8ed: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_8f1:
	/* 0x8f1: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_8f4:
	/* 0x8f4: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_8fb:
	/* 0x8fb: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_8fe:
	/* 0x8fe: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_901:
	/* 0x901: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x901, 0x22e4, x86_l_22e4);
x86_l_907:
	/* 0x907: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_90a:
	/* 0x90a: je     1033 <trace_load_elf_phdrs+0x1033> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90a, 0x1033, x86_l_1033);
x86_l_910:
	/* 0x910: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_916:
	/* 0x916: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_91b:
	/* 0x91b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_91e:
	/* 0x91e: jns    1023 <trace_load_elf_phdrs+0x1023> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x91e, 0x1023, x86_l_1023);
x86_l_924:
	/* 0x924: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_927:
	/* 0x927: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_92c:
	/* 0x92c: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_92f:
	/* 0x92f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_933:
	/* 0x933: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_936:
	/* 0x936: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_939:
	/* 0x939: je     9a9 <trace_load_elf_phdrs+0x9a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x939, 0x9a9, x86_l_9a9);
x86_l_93b:
	/* 0x93b: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_93f:
	/* 0x93f: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_944:
	/* 0x944: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_948:
	/* 0x948: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_94b:
	/* 0x94b: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_94e:
	/* 0x94e: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_953:
	/* 0x953: jne    936 <trace_load_elf_phdrs+0x936> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x953, 0x936, x86_l_936);
x86_l_955:
	/* 0x955: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_958:
	/* 0x958: jmp    9ae <trace_load_elf_phdrs+0x9ae> */
	X86_SIM_X86_JMP(0x958, 0x9ae, x86_l_9ae);
x86_l_95a:
	/* 0x95a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_95d:
	/* 0x95d: jne    1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x95d, 0x1038, x86_l_1038);
x86_l_963:
	/* 0x963: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_966:
	/* 0x966: je     1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_E, 0x966, 0x1038, x86_l_1038);
x86_l_96c:
	/* 0x96c: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_970:
	/* 0x970: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_973:
	/* 0x973: jns    97a <trace_load_elf_phdrs+0x97a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x973, 0x97a, x86_l_97a);
x86_l_975:
	/* 0x975: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_978:
	/* 0x978: jmp    97c <trace_load_elf_phdrs+0x97c> */
	X86_SIM_X86_JMP(0x978, 0x97c, x86_l_97c);
x86_l_97a:
	/* 0x97a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_97c:
	/* 0x97c: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_97f:
	/* 0x97f: jns    986 <trace_load_elf_phdrs+0x986> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x97f, 0x986, x86_l_986);
x86_l_981:
	/* 0x981: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_984:
	/* 0x984: jmp    989 <trace_load_elf_phdrs+0x989> */
	X86_SIM_X86_JMP(0x984, 0x989, x86_l_989);
x86_l_986:
	/* 0x986: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_989:
	/* 0x989: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_98c:
	/* 0x98c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_98f:
	/* 0x98f: jns    996 <trace_load_elf_phdrs+0x996> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x98f, 0x996, x86_l_996);
x86_l_991:
	/* 0x991: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_994:
	/* 0x994: jmp    998 <trace_load_elf_phdrs+0x998> */
	X86_SIM_X86_JMP(0x994, 0x998, x86_l_998);
x86_l_996:
	/* 0x996: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_998:
	/* 0x998: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_99c:
	/* 0x99c: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_99f:
	/* 0x99f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9a2:
	/* 0x9a2: jns    9e3 <trace_load_elf_phdrs+0x9e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9a2, 0x9e3, x86_l_9e3);
x86_l_9a4:
	/* 0x9a4: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9a7:
	/* 0x9a7: jmp    9e5 <trace_load_elf_phdrs+0x9e5> */
	X86_SIM_X86_JMP(0x9a7, 0x9e5, x86_l_9e5);
x86_l_9a9:
	/* 0x9a9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_9ae:
	/* 0x9ae: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_9b2:
	/* 0x9b2: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9b5:
	/* 0x9b5: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9ba:
	/* 0x9ba: jl     1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_L, 0x9ba, 0x1038, x86_l_1038);
x86_l_9c0:
	/* 0x9c0: mov    r10,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c3:
	/* 0x9c3: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_9c8:
	/* 0x9c8: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_9ce:
	/* 0x9ce: mov    BYTE PTR [r9+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_9d3:
	/* 0x9d3: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_9d6:
	/* 0x9d6: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_9db:
	/* 0x9db: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_9de:
	/* 0x9de: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9e1:
	/* 0x9e1: js     9a4 <trace_load_elf_phdrs+0x9a4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x9e1, 0x9a4, x86_l_9a4);
x86_l_9e3:
	/* 0x9e3: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9e5:
	/* 0x9e5: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9e9:
	/* 0x9e9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9ec:
	/* 0x9ec: jns    9f3 <trace_load_elf_phdrs+0x9f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9ec, 0x9f3, x86_l_9f3);
x86_l_9ee:
	/* 0x9ee: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9f1:
	/* 0x9f1: jmp    9f5 <trace_load_elf_phdrs+0x9f5> */
	X86_SIM_X86_JMP(0x9f1, 0x9f5, x86_l_9f5);
x86_l_9f3:
	/* 0x9f3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9f5:
	/* 0x9f5: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_9f8:
	/* 0x9f8: je     a99 <trace_load_elf_phdrs+0xa99> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f8, 0xa99, x86_l_a99);
x86_l_9fe:
	/* 0x9fe: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a01:
	/* 0xa01: je     a99 <trace_load_elf_phdrs+0xa99> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa01, 0xa99, x86_l_a99);
x86_l_a07:
	/* 0xa07: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a0c:
	/* 0xa0c: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a10:
	/* 0xa10: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a13:
	/* 0xa13: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_a19:
	/* 0xa19: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a1c:
	/* 0xa1c: jns    a25 <trace_load_elf_phdrs+0xa25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa1c, 0xa25, x86_l_a25);
x86_l_a1e:
	/* 0xa1e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a21:
	/* 0xa21: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a25:
	/* 0xa25: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_a29:
	/* 0xa29: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_a2c:
	/* 0xa2c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_a33:
	/* 0xa33: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_a36:
	/* 0xa36: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_a39:
	/* 0xa39: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa39, 0x22e4, x86_l_22e4);
x86_l_a3f:
	/* 0xa3f: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_a42:
	/* 0xa42: je     1030 <trace_load_elf_phdrs+0x1030> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa42, 0x1030, x86_l_1030);
x86_l_a48:
	/* 0xa48: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_a4e:
	/* 0xa4e: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_a53:
	/* 0xa53: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_a56:
	/* 0xa56: jns    1026 <trace_load_elf_phdrs+0x1026> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa56, 0x1026, x86_l_1026);
x86_l_a5c:
	/* 0xa5c: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_a5f:
	/* 0xa5f: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_a64:
	/* 0xa64: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a67:
	/* 0xa67: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_a6b:
	/* 0xa6b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a6e:
	/* 0xa6e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_a71:
	/* 0xa71: je     f3f <trace_load_elf_phdrs+0xf3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa71, 0xf3f, x86_l_f3f);
x86_l_a77:
	/* 0xa77: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_a7b:
	/* 0xa7b: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_a80:
	/* 0xa80: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_a84:
	/* 0xa84: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a87:
	/* 0xa87: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_a8a:
	/* 0xa8a: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a8f:
	/* 0xa8f: jne    a6e <trace_load_elf_phdrs+0xa6e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa8f, 0xa6e, x86_l_a6e);
x86_l_a91:
	/* 0xa91: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_a94:
	/* 0xa94: jmp    f44 <trace_load_elf_phdrs+0xf44> */
	X86_SIM_X86_JMP(0xa94, 0xf44, x86_l_f44);
x86_l_a99:
	/* 0xa99: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a9c:
	/* 0xa9c: jne    14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa9c, 0x14f2, x86_l_14f2);
x86_l_aa2:
	/* 0xaa2: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_aa5:
	/* 0xaa5: je     14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaa5, 0x14f2, x86_l_14f2);
x86_l_aab:
	/* 0xaab: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aaf:
	/* 0xaaf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ab2:
	/* 0xab2: jns    d8f <trace_load_elf_phdrs+0xd8f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xab2, 0xd8f, x86_l_d8f);
x86_l_ab8:
	/* 0xab8: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_abb:
	/* 0xabb: jmp    d91 <trace_load_elf_phdrs+0xd91> */
	X86_SIM_X86_JMP(0xabb, 0xd91, x86_l_d91);
x86_l_ac0:
	/* 0xac0: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_ac7:
	/* 0xac7: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_acb:
	/* 0xacb: mov    DWORD PTR [rsp+0x4c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 326417514496ULL);
x86_l_ad3:
	/* 0xad3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_ada:
	/* 0xada: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_adf:
	/* 0xadf: call   ae4 <trace_load_elf_phdrs+0xae4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ae4:
	/* 0xae4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae7:
	/* 0xae7: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae7, 0x348e, x86_l_348e);
x86_l_aed:
	/* 0xaed: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af0:
	/* 0xaf0: mov    eax,DWORD PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_af4:
	/* 0xaf4: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_af8:
	/* 0xaf8: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_afd:
	/* 0xafd: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b00:
	/* 0xb00: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b02:
	/* 0xb02: call   b07 <trace_load_elf_phdrs+0xb07> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_b07:
	/* 0xb07: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_b0e:
	/* 0xb0e: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b13:
	/* 0xb13: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b18:
	/* 0xb18: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b1b:
	/* 0xb1b: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b1e:
	/* 0xb1e: call   b23 <trace_load_elf_phdrs+0xb23> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_b23:
	/* 0xb23: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_b28:
	/* 0xb28: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b2b:
	/* 0xb2b: call   b30 <trace_load_elf_phdrs+0xb30> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b30:
	/* 0xb30: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b35:
	/* 0xb35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b38:
	/* 0xb38: jne    1f4 <trace_load_elf_phdrs+0x1f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb38, 0x1f4, x86_l_1f4);
x86_l_b3e:
	/* 0xb3e: jmp    348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JMP(0xb3e, 0x348e, x86_l_348e);
x86_l_b43:
	/* 0xb43: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_b4a:
	/* 0xb4a: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_b4e:
	/* 0xb4e: mov    DWORD PTR [rsp+0x4c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 326417514496ULL);
x86_l_b56:
	/* 0xb56: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_b5d:
	/* 0xb5d: lea    rsi,[rsp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_b62:
	/* 0xb62: call   b67 <trace_load_elf_phdrs+0xb67> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b67:
	/* 0xb67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b6a:
	/* 0xb6a: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb6a, 0x348e, x86_l_348e);
x86_l_b70:
	/* 0xb70: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b73:
	/* 0xb73: mov    eax,DWORD PTR [rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_b77:
	/* 0xb77: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b7b:
	/* 0xb7b: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_b80:
	/* 0xb80: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b83:
	/* 0xb83: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b85:
	/* 0xb85: call   b8a <trace_load_elf_phdrs+0xb8a> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_b8a:
	/* 0xb8a: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_b91:
	/* 0xb91: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b96:
	/* 0xb96: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b9b:
	/* 0xb9b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b9e:
	/* 0xb9e: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ba1:
	/* 0xba1: call   ba6 <trace_load_elf_phdrs+0xba6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_ba6:
	/* 0xba6: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_bab:
	/* 0xbab: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bae:
	/* 0xbae: call   bb3 <trace_load_elf_phdrs+0xbb3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bb3:
	/* 0xbb3: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_bb8:
	/* 0xbb8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbb:
	/* 0xbbb: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbbb, 0x348e, x86_l_348e);
x86_l_bc1:
	/* 0xbc1: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_bc8:
	/* 0xbc8: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_bcc:
	/* 0xbcc: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bcf:
	/* 0xbcf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_bd2:
	/* 0xbd2: jns    de0 <trace_load_elf_phdrs+0xde0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbd2, 0xde0, x86_l_de0);
x86_l_bd8:
	/* 0xbd8: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bdb:
	/* 0xbdb: jmp    de3 <trace_load_elf_phdrs+0xde3> */
	X86_SIM_X86_JMP(0xbdb, 0xde3, x86_l_de3);
x86_l_be0:
	/* 0xbe0: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_be3:
	/* 0xbe3: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_be7:
	/* 0xbe7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bea:
	/* 0xbea: jns    dc5 <trace_load_elf_phdrs+0xdc5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbea, 0xdc5, x86_l_dc5);
x86_l_bf0:
	/* 0xbf0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf3:
	/* 0xbf3: mov    QWORD PTR [r13+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_bfa:
	/* 0xbfa: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfe:
	/* 0xbfe: mov    QWORD PTR [r13+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_c05:
	/* 0xc05: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c09:
	/* 0xc09: mov    QWORD PTR [r13+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_c10:
	/* 0xc10: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c14:
	/* 0xc14: mov    QWORD PTR [r13+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_c1b:
	/* 0xc1b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c1f:
	/* 0xc1f: mov    QWORD PTR [r13+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_c26:
	/* 0xc26: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c2a:
	/* 0xc2a: mov    QWORD PTR [r13+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_c31:
	/* 0xc31: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c35:
	/* 0xc35: mov    QWORD PTR [r13+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_c3c:
	/* 0xc3c: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_c40:
	/* 0xc40: mov    QWORD PTR [r13+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_c47:
	/* 0xc47: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c4b:
	/* 0xc4b: mov    QWORD PTR [r13+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_c52:
	/* 0xc52: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_c56:
	/* 0xc56: mov    QWORD PTR [r13+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_c5d:
	/* 0xc5d: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c61:
	/* 0xc61: mov    QWORD PTR [r13+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_c68:
	/* 0xc68: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_c6c:
	/* 0xc6c: mov    QWORD PTR [r13+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_c73:
	/* 0xc73: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_c77:
	/* 0xc77: mov    QWORD PTR [r13+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c7e:
	/* 0xc7e: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_c82:
	/* 0xc82: mov    QWORD PTR [r13+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c89:
	/* 0xc89: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c8d:
	/* 0xc8d: mov    QWORD PTR [r13+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_c94:
	/* 0xc94: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_c98:
	/* 0xc98: mov    QWORD PTR [r13+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_c9f:
	/* 0xc9f: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_ca6:
	/* 0xca6: mov    QWORD PTR [r13+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_cad:
	/* 0xcad: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_cb4:
	/* 0xcb4: mov    QWORD PTR [r13+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_cbb:
	/* 0xcbb: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_cc2:
	/* 0xcc2: mov    QWORD PTR [r13+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_cc9:
	/* 0xcc9: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cd0:
	/* 0xcd0: mov    QWORD PTR [r13+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_cd7:
	/* 0xcd7: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_cde:
	/* 0xcde: mov    QWORD PTR [r13+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_ce5:
	/* 0xce5: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_cec:
	/* 0xcec: mov    QWORD PTR [r13+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_cf3:
	/* 0xcf3: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_cfa:
	/* 0xcfa: mov    QWORD PTR [r13+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_d01:
	/* 0xd01: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_d08:
	/* 0xd08: mov    QWORD PTR [r13+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_d0f:
	/* 0xd0f: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_d16:
	/* 0xd16: mov    QWORD PTR [r13+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_d1d:
	/* 0xd1d: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_d24:
	/* 0xd24: mov    QWORD PTR [r13+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_d2b:
	/* 0xd2b: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_d32:
	/* 0xd32: mov    QWORD PTR [r13+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_d39:
	/* 0xd39: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_d40:
	/* 0xd40: mov    QWORD PTR [r13+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_d47:
	/* 0xd47: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_d4e:
	/* 0xd4e: mov    QWORD PTR [r13+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_d55:
	/* 0xd55: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_d5c:
	/* 0xd5c: mov    QWORD PTR [r13+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_d63:
	/* 0xd63: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_d6a:
	/* 0xd6a: mov    QWORD PTR [r13+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_d71:
	/* 0xd71: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_d78:
	/* 0xd78: mov    QWORD PTR [r13+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_d7f:
	/* 0xd7f: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_d85:
	/* 0xd85: mov    WORD PTR [r13+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_d8a:
	/* 0xd8a: jmp    2de <trace_load_elf_phdrs+0x2de> */
	X86_SIM_X86_JMP(0xd8a, 0x2de, x86_l_2de);
x86_l_d8f:
	/* 0xd8f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d91:
	/* 0xd91: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_d94:
	/* 0xd94: jns    d9b <trace_load_elf_phdrs+0xd9b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd94, 0xd9b, x86_l_d9b);
x86_l_d96:
	/* 0xd96: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d99:
	/* 0xd99: jmp    d9e <trace_load_elf_phdrs+0xd9e> */
	X86_SIM_X86_JMP(0xd99, 0xd9e, x86_l_d9e);
x86_l_d9b:
	/* 0xd9b: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d9e:
	/* 0xd9e: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_da1:
	/* 0xda1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_da4:
	/* 0xda4: jns    dab <trace_load_elf_phdrs+0xdab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xda4, 0xdab, x86_l_dab);
x86_l_da6:
	/* 0xda6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_da9:
	/* 0xda9: jmp    dad <trace_load_elf_phdrs+0xdad> */
	X86_SIM_X86_JMP(0xda9, 0xdad, x86_l_dad);
x86_l_dab:
	/* 0xdab: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dad:
	/* 0xdad: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_db1:
	/* 0xdb1: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_db4:
	/* 0xdb4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_db7:
	/* 0xdb7: jns    f7d <trace_load_elf_phdrs+0xf7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdb7, 0xf7d, x86_l_f7d);
x86_l_dbd:
	/* 0xdbd: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dc0:
	/* 0xdc0: jmp    f7f <trace_load_elf_phdrs+0xf7f> */
	X86_SIM_X86_JMP(0xdc0, 0xf7f, x86_l_f7f);
x86_l_dc5:
	/* 0xdc5: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_dcc:
	/* 0xdcc: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_dd1:
	/* 0xdd1: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_dd4:
	/* 0xdd4: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd6:
	/* 0xdd6: call   ddb <trace_load_elf_phdrs+0xddb> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_ddb:
	/* 0xddb: jmp    348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JMP(0xddb, 0x348e, x86_l_348e);
x86_l_de0:
	/* 0xde0: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_de3:
	/* 0xde3: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_de7:
	/* 0xde7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dea:
	/* 0xdea: jns    df1 <trace_load_elf_phdrs+0xdf1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdea, 0xdf1, x86_l_df1);
x86_l_dec:
	/* 0xdec: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_def:
	/* 0xdef: jmp    df3 <trace_load_elf_phdrs+0xdf3> */
	X86_SIM_X86_JMP(0xdef, 0xdf3, x86_l_df3);
x86_l_df1:
	/* 0xdf1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_df3:
	/* 0xdf3: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_df6:
	/* 0xdf6: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_dfa:
	/* 0xdfa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dfc:
	/* 0xdfc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_dff:
	/* 0xdff: jns    e06 <trace_load_elf_phdrs+0xe06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdff, 0xe06, x86_l_e06);
x86_l_e01:
	/* 0xe01: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e04:
	/* 0xe04: jmp    e09 <trace_load_elf_phdrs+0xe09> */
	X86_SIM_X86_JMP(0xe04, 0xe09, x86_l_e09);
x86_l_e06:
	/* 0xe06: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e09:
	/* 0xe09: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_e0e:
	/* 0xe0e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e11:
	/* 0xe11: jns    e15 <trace_load_elf_phdrs+0xe15> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe11, 0xe15, x86_l_e15);
x86_l_e13:
	/* 0xe13: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e15:
	/* 0xe15: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e1a:
	/* 0xe1a: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_e1d:
	/* 0xe1d: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e21:
	/* 0xe21: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e24:
	/* 0xe24: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e26:
	/* 0xe26: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e29:
	/* 0xe29: jns    e30 <trace_load_elf_phdrs+0xe30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe29, 0xe30, x86_l_e30);
x86_l_e2b:
	/* 0xe2b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e2e:
	/* 0xe2e: jmp    e32 <trace_load_elf_phdrs+0xe32> */
	X86_SIM_X86_JMP(0xe2e, 0xe32, x86_l_e32);
x86_l_e30:
	/* 0xe30: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e32:
	/* 0xe32: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e35:
	/* 0xe35: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e38:
	/* 0xe38: jns    e3c <trace_load_elf_phdrs+0xe3c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe38, 0xe3c, x86_l_e3c);
x86_l_e3a:
	/* 0xe3a: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e3c:
	/* 0xe3c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_e3e:
	/* 0xe3e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_e42:
	/* 0xe42: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e45:
	/* 0xe45: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_e49:
	/* 0xe49: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e4b:
	/* 0xe4b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e4e:
	/* 0xe4e: jns    e52 <trace_load_elf_phdrs+0xe52> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe4e, 0xe52, x86_l_e52);
x86_l_e50:
	/* 0xe50: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e52:
	/* 0xe52: mov    rsi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e57:
	/* 0xe57: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_e5a:
	/* 0xe5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e5d:
	/* 0xe5d: jns    e64 <trace_load_elf_phdrs+0xe64> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe5d, 0xe64, x86_l_e64);
x86_l_e5f:
	/* 0xe5f: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e62:
	/* 0xe62: jmp    e66 <trace_load_elf_phdrs+0xe66> */
	X86_SIM_X86_JMP(0xe62, 0xe66, x86_l_e66);
x86_l_e64:
	/* 0xe64: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e66:
	/* 0xe66: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_e6a:
	/* 0xe6a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e6c:
	/* 0xe6c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e6f:
	/* 0xe6f: jns    e76 <trace_load_elf_phdrs+0xe76> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe6f, 0xe76, x86_l_e76);
x86_l_e71:
	/* 0xe71: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e74:
	/* 0xe74: jmp    e78 <trace_load_elf_phdrs+0xe78> */
	X86_SIM_X86_JMP(0xe74, 0xe78, x86_l_e78);
x86_l_e76:
	/* 0xe76: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e78:
	/* 0xe78: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e7b:
	/* 0xe7b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e7e:
	/* 0xe7e: jns    e82 <trace_load_elf_phdrs+0xe82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe7e, 0xe82, x86_l_e82);
x86_l_e80:
	/* 0xe80: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e82:
	/* 0xe82: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_e84:
	/* 0xe84: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_e88:
	/* 0xe88: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e8b:
	/* 0xe8b: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_e8f:
	/* 0xe8f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e91:
	/* 0xe91: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_e94:
	/* 0xe94: jns    e98 <trace_load_elf_phdrs+0xe98> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe94, 0xe98, x86_l_e98);
x86_l_e96:
	/* 0xe96: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e98:
	/* 0xe98: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e9d:
	/* 0xe9d: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ea0:
	/* 0xea0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ea2:
	/* 0xea2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ea5:
	/* 0xea5: jns    eac <trace_load_elf_phdrs+0xeac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xea5, 0xeac, x86_l_eac);
x86_l_ea7:
	/* 0xea7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eaa:
	/* 0xeaa: jmp    eae <trace_load_elf_phdrs+0xeae> */
	X86_SIM_X86_JMP(0xeaa, 0xeae, x86_l_eae);
x86_l_eac:
	/* 0xeac: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eae:
	/* 0xeae: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_eb1:
	/* 0xeb1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_eb4:
	/* 0xeb4: jns    eb8 <trace_load_elf_phdrs+0xeb8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeb4, 0xeb8, x86_l_eb8);
x86_l_eb6:
	/* 0xeb6: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eb8:
	/* 0xeb8: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_eba:
	/* 0xeba: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_ebe:
	/* 0xebe: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_ec1:
	/* 0xec1: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_ec5:
	/* 0xec5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ec7:
	/* 0xec7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_eca:
	/* 0xeca: jns    ed1 <trace_load_elf_phdrs+0xed1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeca, 0xed1, x86_l_ed1);
x86_l_ecc:
	/* 0xecc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ecf:
	/* 0xecf: jmp    ed3 <trace_load_elf_phdrs+0xed3> */
	X86_SIM_X86_JMP(0xecf, 0xed3, x86_l_ed3);
x86_l_ed1:
	/* 0xed1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ed3:
	/* 0xed3: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_ed7:
	/* 0xed7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_eda:
	/* 0xeda: jns    ede <trace_load_elf_phdrs+0xede> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeda, 0xede, x86_l_ede);
x86_l_edc:
	/* 0xedc: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ede:
	/* 0xede: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ee3:
	/* 0xee3: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ee6:
	/* 0xee6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ee8:
	/* 0xee8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_eeb:
	/* 0xeeb: jns    ef2 <trace_load_elf_phdrs+0xef2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeeb, 0xef2, x86_l_ef2);
x86_l_eed:
	/* 0xeed: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef0:
	/* 0xef0: jmp    ef4 <trace_load_elf_phdrs+0xef4> */
	X86_SIM_X86_JMP(0xef0, 0xef4, x86_l_ef4);
x86_l_ef2:
	/* 0xef2: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef4:
	/* 0xef4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ef7:
	/* 0xef7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_efa:
	/* 0xefa: jns    efe <trace_load_elf_phdrs+0xefe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xefa, 0xefe, x86_l_efe);
x86_l_efc:
	/* 0xefc: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_efe:
	/* 0xefe: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_f00:
	/* 0xf00: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_f04:
	/* 0xf04: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_f07:
	/* 0xf07: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_f0b:
	/* 0xf0b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f0d:
	/* 0xf0d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f10:
	/* 0xf10: jns    f17 <trace_load_elf_phdrs+0xf17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf10, 0xf17, x86_l_f17);
x86_l_f12:
	/* 0xf12: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f15:
	/* 0xf15: jmp    f19 <trace_load_elf_phdrs+0xf19> */
	X86_SIM_X86_JMP(0xf15, 0xf19, x86_l_f19);
x86_l_f17:
	/* 0xf17: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f19:
	/* 0xf19: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_f1d:
	/* 0xf1d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f20:
	/* 0xf20: jns    f24 <trace_load_elf_phdrs+0xf24> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf20, 0xf24, x86_l_f24);
x86_l_f22:
	/* 0xf22: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f24:
	/* 0xf24: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_f26:
	/* 0xf26: jne    113e <trace_load_elf_phdrs+0x113e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf26, 0x113e, x86_l_113e);
x86_l_f2c:
	/* 0xf2c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f2e:
	/* 0xf2e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f31:
	/* 0xf31: jns    1114 <trace_load_elf_phdrs+0x1114> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf31, 0x1114, x86_l_1114);
x86_l_f37:
	/* 0xf37: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3a:
	/* 0xf3a: jmp    1116 <trace_load_elf_phdrs+0x1116> */
	X86_SIM_X86_JMP(0xf3a, 0x1116, x86_l_1116);
x86_l_f3f:
	/* 0xf3f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f44:
	/* 0xf44: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f48:
	/* 0xf48: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f4b:
	/* 0xf4b: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f50:
	/* 0xf50: jl     14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf50, 0x14f2, x86_l_14f2);
x86_l_f56:
	/* 0xf56: mov    r10,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f59:
	/* 0xf59: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f5e:
	/* 0xf5e: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_f64:
	/* 0xf64: mov    BYTE PTR [r9+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_f69:
	/* 0xf69: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f6c:
	/* 0xf6c: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_f71:
	/* 0xf71: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f74:
	/* 0xf74: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f77:
	/* 0xf77: js     dbd <trace_load_elf_phdrs+0xdbd> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf77, 0xdbd, x86_l_dbd);
x86_l_f7d:
	/* 0xf7d: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f7f:
	/* 0xf7f: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f83:
	/* 0xf83: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f86:
	/* 0xf86: jns    f8d <trace_load_elf_phdrs+0xf8d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf86, 0xf8d, x86_l_f8d);
x86_l_f88:
	/* 0xf88: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f8b:
	/* 0xf8b: jmp    f8f <trace_load_elf_phdrs+0xf8f> */
	X86_SIM_X86_JMP(0xf8b, 0xf8f, x86_l_f8f);
x86_l_f8d:
	/* 0xf8d: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8f:
	/* 0xf8f: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f92:
	/* 0xf92: je     10be <trace_load_elf_phdrs+0x10be> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf92, 0x10be, x86_l_10be);
x86_l_f98:
	/* 0xf98: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f9b:
	/* 0xf9b: je     10be <trace_load_elf_phdrs+0x10be> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf9b, 0x10be, x86_l_10be);
x86_l_fa1:
	/* 0xfa1: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa6:
	/* 0xfa6: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_faa:
	/* 0xfaa: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fad:
	/* 0xfad: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_fb3:
	/* 0xfb3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fb6:
	/* 0xfb6: jns    fbf <trace_load_elf_phdrs+0xfbf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfb6, 0xfbf, x86_l_fbf);
x86_l_fb8:
	/* 0xfb8: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fbb:
	/* 0xfbb: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fbf:
	/* 0xfbf: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fc3:
	/* 0xfc3: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_fc6:
	/* 0xfc6: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fcd:
	/* 0xfcd: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_fd0:
	/* 0xfd0: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_fd3:
	/* 0xfd3: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0xfd3, 0x22e4, x86_l_22e4);
x86_l_fd9:
	/* 0xfd9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_fdc:
	/* 0xfdc: je     1033 <trace_load_elf_phdrs+0x1033> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfdc, 0x1033, x86_l_1033);
x86_l_fde:
	/* 0xfde: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_fe3:
	/* 0xfe3: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_fe9:
	/* 0xfe9: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_fee:
	/* 0xfee: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_ff1:
	/* 0xff1: jns    1023 <trace_load_elf_phdrs+0x1023> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xff1, 0x1023, x86_l_1023);
x86_l_ff3:
	/* 0xff3: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_ff6:
	/* 0xff6: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ffa:
	/* 0xffa: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ffd:
	/* 0xffd: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1000:
	/* 0x1000: je     13e3 <trace_load_elf_phdrs+0x13e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1000, 0x13e3, x86_l_13e3);
x86_l_1006:
	/* 0x1006: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_100a:
	/* 0x100a: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_100f:
	/* 0x100f: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1013:
	/* 0x1013: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1016:
	/* 0x1016: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1019:
	/* 0x1019: jne    ffd <trace_load_elf_phdrs+0xffd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1019, 0xffd, x86_l_ffd);
x86_l_101b:
	/* 0x101b: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_101e:
	/* 0x101e: jmp    13e8 <trace_load_elf_phdrs+0x13e8> */
	X86_SIM_X86_JMP(0x101e, 0x13e8, x86_l_13e8);
x86_l_1023:
	/* 0x1023: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1026:
	/* 0x1026: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1029:
	/* 0x1029: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_102b:
	/* 0x102b: call   1030 <trace_load_elf_phdrs+0x1030> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1030:
	/* 0x1030: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1033:
	/* 0x1033: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1038:
	/* 0x1038: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_103b:
	/* 0x103b: cmp    r12d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1042:
	/* 0x1042: jne    22e9 <trace_load_elf_phdrs+0x22e9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1042, 0x22e9, x86_l_22e9);
x86_l_1048:
	/* 0x1048: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_104c:
	/* 0x104c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_104f:
	/* 0x104f: jns    1080 <trace_load_elf_phdrs+0x1080> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x104f, 0x1080, x86_l_1080);
x86_l_1051:
	/* 0x1051: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1055:
	/* 0x1055: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1059:
	/* 0x1059: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_105c:
	/* 0x105c: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1061:
	/* 0x1061: js     108c <trace_load_elf_phdrs+0x108c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1061, 0x108c, x86_l_108c);
x86_l_1063:
	/* 0x1063: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1068:
	/* 0x1068: mov    rdi,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_106b:
	/* 0x106b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_106d:
	/* 0x106d: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1070:
	/* 0x1070: mov    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1073:
	/* 0x1073: call   1078 <trace_load_elf_phdrs+0x1078> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_1078:
	/* 0x1078: mov    r9,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_107b:
	/* 0x107b: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_107e:
	/* 0x107e: jmp    10b6 <trace_load_elf_phdrs+0x10b6> */
	X86_SIM_X86_JMP(0x107e, 0x10b6, x86_l_10b6);
x86_l_1080:
	/* 0x1080: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1082:
	/* 0x1082: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1085:
	/* 0x1085: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_108a:
	/* 0x108a: jns    1063 <trace_load_elf_phdrs+0x1063> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x108a, 0x1063, x86_l_1063);
x86_l_108c:
	/* 0x108c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108f:
	/* 0x108f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1091:
	/* 0x1091: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1098:
	/* 0x1098: je     10ae <trace_load_elf_phdrs+0x10ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1098, 0x10ae, x86_l_10ae);
x86_l_109a:
	/* 0x109a: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_109e:
	/* 0x109e: mov    BYTE PTR [r9+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R9, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_10a2:
	/* 0x10a2: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_10a5:
	/* 0x10a5: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_10a7:
	/* 0x10a7: jne    1091 <trace_load_elf_phdrs+0x1091> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10a7, 0x1091, x86_l_1091);
x86_l_10a9:
	/* 0x10a9: jmp    2306 <trace_load_elf_phdrs+0x2306> */
	X86_SIM_X86_JMP(0x10a9, 0x2306, x86_l_2306);
x86_l_10ae:
	/* 0x10ae: mov    BYTE PTR [r9+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_10b6:
	/* 0x10b6: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10b9:
	/* 0x10b9: jmp    2306 <trace_load_elf_phdrs+0x2306> */
	X86_SIM_X86_JMP(0x10b9, 0x2306, x86_l_2306);
x86_l_10be:
	/* 0x10be: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10c1:
	/* 0x10c1: jne    1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10c1, 0x1038, x86_l_1038);
x86_l_10c7:
	/* 0x10c7: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10ca:
	/* 0x10ca: je     1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10ca, 0x1038, x86_l_1038);
x86_l_10d0:
	/* 0x10d0: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10d4:
	/* 0x10d4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10d7:
	/* 0x10d7: jns    10de <trace_load_elf_phdrs+0x10de> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10d7, 0x10de, x86_l_10de);
x86_l_10d9:
	/* 0x10d9: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10dc:
	/* 0x10dc: jmp    10e0 <trace_load_elf_phdrs+0x10e0> */
	X86_SIM_X86_JMP(0x10dc, 0x10e0, x86_l_10e0);
x86_l_10de:
	/* 0x10de: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10e0:
	/* 0x10e0: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_10e3:
	/* 0x10e3: jns    10ea <trace_load_elf_phdrs+0x10ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10e3, 0x10ea, x86_l_10ea);
x86_l_10e5:
	/* 0x10e5: mov    r10,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e8:
	/* 0x10e8: jmp    10ed <trace_load_elf_phdrs+0x10ed> */
	X86_SIM_X86_JMP(0x10e8, 0x10ed, x86_l_10ed);
x86_l_10ea:
	/* 0x10ea: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ed:
	/* 0x10ed: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_10f0:
	/* 0x10f0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10f3:
	/* 0x10f3: jns    10fa <trace_load_elf_phdrs+0x10fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10f3, 0x10fa, x86_l_10fa);
x86_l_10f5:
	/* 0x10f5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10f8:
	/* 0x10f8: jmp    10fc <trace_load_elf_phdrs+0x10fc> */
	X86_SIM_X86_JMP(0x10f8, 0x10fc, x86_l_10fc);
x86_l_10fa:
	/* 0x10fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10fc:
	/* 0x10fc: lea    rsi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1100:
	/* 0x1100: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1103:
	/* 0x1103: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1106:
	/* 0x1106: jns    142d <trace_load_elf_phdrs+0x142d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1106, 0x142d, x86_l_142d);
x86_l_110c:
	/* 0x110c: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_110f:
	/* 0x110f: jmp    142f <trace_load_elf_phdrs+0x142f> */
	X86_SIM_X86_JMP(0x110f, 0x142f, x86_l_142f);
x86_l_1114:
	/* 0x1114: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1116:
	/* 0x1116: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1119:
	/* 0x1119: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_111c:
	/* 0x111c: jns    1120 <trace_load_elf_phdrs+0x1120> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x111c, 0x1120, x86_l_1120);
x86_l_111e:
	/* 0x111e: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1120:
	/* 0x1120: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1122:
	/* 0x1122: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1126:
	/* 0x1126: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1129:
	/* 0x1129: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_112d:
	/* 0x112d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_112f:
	/* 0x112f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1132:
	/* 0x1132: jns    1136 <trace_load_elf_phdrs+0x1136> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1132, 0x1136, x86_l_1136);
x86_l_1134:
	/* 0x1134: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1136:
	/* 0x1136: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_113b:
	/* 0x113b: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_113e:
	/* 0x113e: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1143:
	/* 0x1143: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1146:
	/* 0x1146: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_114d:
	/* 0x114d: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1150:
	/* 0x1150: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1153:
	/* 0x1153: jns    115a <trace_load_elf_phdrs+0x115a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1153, 0x115a, x86_l_115a);
x86_l_1155:
	/* 0x1155: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1158:
	/* 0x1158: jmp    115c <trace_load_elf_phdrs+0x115c> */
	X86_SIM_X86_JMP(0x1158, 0x115c, x86_l_115c);
x86_l_115a:
	/* 0x115a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_115c:
	/* 0x115c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1160:
	/* 0x1160: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1162:
	/* 0x1162: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1165:
	/* 0x1165: jns    116c <trace_load_elf_phdrs+0x116c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1165, 0x116c, x86_l_116c);
x86_l_1167:
	/* 0x1167: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_116a:
	/* 0x116a: jmp    116e <trace_load_elf_phdrs+0x116e> */
	X86_SIM_X86_JMP(0x116a, 0x116e, x86_l_116e);
x86_l_116c:
	/* 0x116c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116e:
	/* 0x116e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1171:
	/* 0x1171: jns    1175 <trace_load_elf_phdrs+0x1175> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1171, 0x1175, x86_l_1175);
x86_l_1173:
	/* 0x1173: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1175:
	/* 0x1175: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_117a:
	/* 0x117a: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_117e:
	/* 0x117e: call   1183 <trace_load_elf_phdrs+0x1183> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1183:
	/* 0x1183: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1187:
	/* 0x1187: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_118b:
	/* 0x118b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_118e:
	/* 0x118e: jns    1195 <trace_load_elf_phdrs+0x1195> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x118e, 0x1195, x86_l_1195);
x86_l_1190:
	/* 0x1190: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1193:
	/* 0x1193: jmp    1197 <trace_load_elf_phdrs+0x1197> */
	X86_SIM_X86_JMP(0x1193, 0x1197, x86_l_1197);
x86_l_1195:
	/* 0x1195: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1197:
	/* 0x1197: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_119c:
	/* 0x119c: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_119f:
	/* 0x119f: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_11a3:
	/* 0x11a3: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11a6:
	/* 0x11a6: jns    11ad <trace_load_elf_phdrs+0x11ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11a6, 0x11ad, x86_l_11ad);
x86_l_11a8:
	/* 0x11a8: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ab:
	/* 0x11ab: jmp    11af <trace_load_elf_phdrs+0x11af> */
	X86_SIM_X86_JMP(0x11ab, 0x11af, x86_l_11af);
x86_l_11ad:
	/* 0x11ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11af:
	/* 0x11af: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11b4:
	/* 0x11b4: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_11b8:
	/* 0x11b8: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_11bc:
	/* 0x11bc: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11bf:
	/* 0x11bf: jns    11c7 <trace_load_elf_phdrs+0x11c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11bf, 0x11c7, x86_l_11c7);
x86_l_11c1:
	/* 0x11c1: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11c5:
	/* 0x11c5: jmp    11c9 <trace_load_elf_phdrs+0x11c9> */
	X86_SIM_X86_JMP(0x11c5, 0x11c9, x86_l_11c9);
x86_l_11c7:
	/* 0x11c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c9:
	/* 0x11c9: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11ce:
	/* 0x11ce: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_11d1:
	/* 0x11d1: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11d6:
	/* 0x11d6: mov    QWORD PTR [r15+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_11da:
	/* 0x11da: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11dd:
	/* 0x11dd: jns    11ea <trace_load_elf_phdrs+0x11ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11dd, 0x11ea, x86_l_11ea);
x86_l_11df:
	/* 0x11df: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11e1:
	/* 0x11e1: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11e3:
	/* 0x11e3: je     11ea <trace_load_elf_phdrs+0x11ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11e3, 0x11ea, x86_l_11ea);
x86_l_11e5:
	/* 0x11e5: or     BYTE PTR [r15+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_11ea:
	/* 0x11ea: lea    rdi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_11ee:
	/* 0x11ee: mov    QWORD PTR [r15+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_11f6:
	/* 0x11f6: mov    QWORD PTR [r15+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_11fe:
	/* 0x11fe: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1203:
	/* 0x1203: call   1208 <trace_load_elf_phdrs+0x1208> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_1208:
	/* 0x1208: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_120b:
	/* 0x120b: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_120e:
	/* 0x120e: jns    1216 <trace_load_elf_phdrs+0x1216> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x120e, 0x1216, x86_l_1216);
x86_l_1210:
	/* 0x1210: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1214:
	/* 0x1214: jmp    1218 <trace_load_elf_phdrs+0x1218> */
	X86_SIM_X86_JMP(0x1214, 0x1218, x86_l_1218);
x86_l_1216:
	/* 0x1216: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1218:
	/* 0x1218: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_121d:
	/* 0x121d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1220:
	/* 0x1220: jns    1227 <trace_load_elf_phdrs+0x1227> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1220, 0x1227, x86_l_1227);
x86_l_1222:
	/* 0x1222: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1225:
	/* 0x1225: jmp    1229 <trace_load_elf_phdrs+0x1229> */
	X86_SIM_X86_JMP(0x1225, 0x1229, x86_l_1229);
x86_l_1227:
	/* 0x1227: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1229:
	/* 0x1229: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_122c:
	/* 0x122c: jns    127f <trace_load_elf_phdrs+0x127f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x122c, 0x127f, x86_l_127f);
x86_l_122e:
	/* 0x122e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1231:
	/* 0x1231: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1236:
	/* 0x1236: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_123a:
	/* 0x123a: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_123f:
	/* 0x123f: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1243:
	/* 0x1243: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1248:
	/* 0x1248: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_124c:
	/* 0x124c: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1251:
	/* 0x1251: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1255:
	/* 0x1255: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_125a:
	/* 0x125a: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_125e:
	/* 0x125e: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1263:
	/* 0x1263: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1267:
	/* 0x1267: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_126f:
	/* 0x126f: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1273:
	/* 0x1273: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_127b:
	/* 0x127b: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_127f:
	/* 0x127f: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1282:
	/* 0x1282: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_1286:
	/* 0x1286: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_128b:
	/* 0x128b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_128e:
	/* 0x128e: jns    13ae <trace_load_elf_phdrs+0x13ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x128e, 0x13ae, x86_l_13ae);
x86_l_1294:
	/* 0x1294: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1297:
	/* 0x1297: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1299:
	/* 0x1299: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_129b:
	/* 0x129b: je     13bd <trace_load_elf_phdrs+0x13bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x129b, 0x13bd, x86_l_13bd);
x86_l_12a1:
	/* 0x12a1: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_12a5:
	/* 0x12a5: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_12a8:
	/* 0x12a8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_12aa:
	/* 0x12aa: je     13bd <trace_load_elf_phdrs+0x13bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12aa, 0x13bd, x86_l_13bd);
x86_l_12b0:
	/* 0x12b0: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_12b4:
	/* 0x12b4: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_12b7:
	/* 0x12b7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_12b9:
	/* 0x12b9: je     13bd <trace_load_elf_phdrs+0x13bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12b9, 0x13bd, x86_l_13bd);
x86_l_12bf:
	/* 0x12bf: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_12c3:
	/* 0x12c3: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_12c6:
	/* 0x12c6: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_12c8:
	/* 0x12c8: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12c8, 0x13c7, x86_l_13c7);
x86_l_12ce:
	/* 0x12ce: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_12d2:
	/* 0x12d2: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12d7:
	/* 0x12d7: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12da:
	/* 0x12da: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_12dc:
	/* 0x12dc: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12dc, 0x13c7, x86_l_13c7);
x86_l_12e2:
	/* 0x12e2: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_12e6:
	/* 0x12e6: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12eb:
	/* 0x12eb: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_12ee:
	/* 0x12ee: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_12f0:
	/* 0x12f0: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f0, 0x13c7, x86_l_13c7);
x86_l_12f6:
	/* 0x12f6: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_12fa:
	/* 0x12fa: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12ff:
	/* 0x12ff: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_1302:
	/* 0x1302: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1304:
	/* 0x1304: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1304, 0x13c7, x86_l_13c7);
x86_l_130a:
	/* 0x130a: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_130e:
	/* 0x130e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1313:
	/* 0x1313: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_1316:
	/* 0x1316: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1318:
	/* 0x1318: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1318, 0x13c7, x86_l_13c7);
x86_l_131e:
	/* 0x131e: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1322:
	/* 0x1322: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1327:
	/* 0x1327: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_132a:
	/* 0x132a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_132c:
	/* 0x132c: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x132c, 0x13c7, x86_l_13c7);
x86_l_1332:
	/* 0x1332: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1336:
	/* 0x1336: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_133b:
	/* 0x133b: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_133e:
	/* 0x133e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1340:
	/* 0x1340: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1340, 0x13c7, x86_l_13c7);
x86_l_1346:
	/* 0x1346: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_134a:
	/* 0x134a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_134f:
	/* 0x134f: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1352:
	/* 0x1352: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1354:
	/* 0x1354: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1354, 0x13c7, x86_l_13c7);
x86_l_1356:
	/* 0x1356: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_135a:
	/* 0x135a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_135f:
	/* 0x135f: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1362:
	/* 0x1362: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1364:
	/* 0x1364: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1364, 0x13c7, x86_l_13c7);
x86_l_1366:
	/* 0x1366: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_136a:
	/* 0x136a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_136f:
	/* 0x136f: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1372:
	/* 0x1372: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1374:
	/* 0x1374: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1374, 0x13c7, x86_l_13c7);
x86_l_1376:
	/* 0x1376: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_137a:
	/* 0x137a: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_137f:
	/* 0x137f: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1382:
	/* 0x1382: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1384:
	/* 0x1384: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1384, 0x13c7, x86_l_13c7);
x86_l_1386:
	/* 0x1386: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_138a:
	/* 0x138a: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_138f:
	/* 0x138f: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1392:
	/* 0x1392: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1394:
	/* 0x1394: je     13c7 <trace_load_elf_phdrs+0x13c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1394, 0x13c7, x86_l_13c7);
x86_l_1396:
	/* 0x1396: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_139b:
	/* 0x139b: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_139f:
	/* 0x139f: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13a4:
	/* 0x13a4: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13a9:
	/* 0x13a9: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_13ac:
	/* 0x13ac: jmp    13bd <trace_load_elf_phdrs+0x13bd> */
	X86_SIM_X86_JMP(0x13ac, 0x13bd, x86_l_13bd);
x86_l_13ae:
	/* 0x13ae: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_13b6:
	/* 0x13b6: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13bd:
	/* 0x13bd: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13c2:
	/* 0x13c2: jmp    22e <trace_load_elf_phdrs+0x22e> */
	X86_SIM_X86_JMP(0x13c2, 0x22e, x86_l_22e);
x86_l_13c7:
	/* 0x13c7: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13cc:
	/* 0x13cc: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13d1:
	/* 0x13d1: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_13d4:
	/* 0x13d4: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13d9:
	/* 0x13d9: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_13de:
	/* 0x13de: jmp    22e <trace_load_elf_phdrs+0x22e> */
	X86_SIM_X86_JMP(0x13de, 0x22e, x86_l_22e);
x86_l_13e3:
	/* 0x13e3: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_13e8:
	/* 0x13e8: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_13ec:
	/* 0x13ec: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x13ec, 0x227b, x86_l_227b);
x86_l_13f2:
	/* 0x13f2: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_13f7:
	/* 0x13f7: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_13fd:
	/* 0x13fd: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1402:
	/* 0x1402: mov    BYTE PTR [r9+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1407:
	/* 0x1407: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_140a:
	/* 0x140a: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_140f:
	/* 0x140f: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1414:
	/* 0x1414: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1419:
	/* 0x1419: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_141e:
	/* 0x141e: mov    r10,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1421:
	/* 0x1421: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1424:
	/* 0x1424: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1427:
	/* 0x1427: js     110c <trace_load_elf_phdrs+0x110c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1427, 0x110c, x86_l_110c);
x86_l_142d:
	/* 0x142d: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_142f:
	/* 0x142f: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1433:
	/* 0x1433: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1436:
	/* 0x1436: jns    143d <trace_load_elf_phdrs+0x143d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1436, 0x143d, x86_l_143d);
x86_l_1438:
	/* 0x1438: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_143b:
	/* 0x143b: jmp    143f <trace_load_elf_phdrs+0x143f> */
	X86_SIM_X86_JMP(0x143b, 0x143f, x86_l_143f);
x86_l_143d:
	/* 0x143d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_143f:
	/* 0x143f: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1442:
	/* 0x1442: je     14d2 <trace_load_elf_phdrs+0x14d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1442, 0x14d2, x86_l_14d2);
x86_l_1448:
	/* 0x1448: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_144b:
	/* 0x144b: je     14d2 <trace_load_elf_phdrs+0x14d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x144b, 0x14d2, x86_l_14d2);
x86_l_1451:
	/* 0x1451: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1456:
	/* 0x1456: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_145a:
	/* 0x145a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_145d:
	/* 0x145d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1463:
	/* 0x1463: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1466:
	/* 0x1466: jns    146f <trace_load_elf_phdrs+0x146f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1466, 0x146f, x86_l_146f);
x86_l_1468:
	/* 0x1468: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_146b:
	/* 0x146b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_146f:
	/* 0x146f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1473:
	/* 0x1473: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1476:
	/* 0x1476: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_147d:
	/* 0x147d: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1480:
	/* 0x1480: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1483:
	/* 0x1483: jb     22e4 <trace_load_elf_phdrs+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1483, 0x22e4, x86_l_22e4);
x86_l_1489:
	/* 0x1489: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_148c:
	/* 0x148c: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x148c, 0x2278, x86_l_2278);
x86_l_1492:
	/* 0x1492: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1498:
	/* 0x1498: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_149d:
	/* 0x149d: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_14a0:
	/* 0x14a0: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14a0, 0x20c9, x86_l_20c9);
x86_l_14a6:
	/* 0x14a6: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_14a9:
	/* 0x14a9: mov    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14ac:
	/* 0x14ac: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_14b0:
	/* 0x14b0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14b3:
	/* 0x14b3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_14b6:
	/* 0x14b6: je     152c <trace_load_elf_phdrs+0x152c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14b6, 0x152c, x86_l_152c);
x86_l_14b8:
	/* 0x14b8: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_14bc:
	/* 0x14bc: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_14c1:
	/* 0x14c1: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_14c5:
	/* 0x14c5: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_14c8:
	/* 0x14c8: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_14cb:
	/* 0x14cb: jne    14b3 <trace_load_elf_phdrs+0x14b3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14cb, 0x14b3, x86_l_14b3);
x86_l_14cd:
	/* 0x14cd: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_14d0:
	/* 0x14d0: jmp    1531 <trace_load_elf_phdrs+0x1531> */
	X86_SIM_X86_JMP(0x14d0, 0x1531, x86_l_1531);
x86_l_14d2:
	/* 0x14d2: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14d5:
	/* 0x14d5: jne    14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14d5, 0x14f2, x86_l_14f2);
x86_l_14d7:
	/* 0x14d7: cmp    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14da:
	/* 0x14da: je     14f2 <trace_load_elf_phdrs+0x14f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14da, 0x14f2, x86_l_14f2);
x86_l_14dc:
	/* 0x14dc: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14e1:
	/* 0x14e1: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_14e4:
	/* 0x14e4: lea    rcx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14e8:
	/* 0x14e8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14eb:
	/* 0x14eb: jns    14fa <trace_load_elf_phdrs+0x14fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14eb, 0x14fa, x86_l_14fa);
x86_l_14ed:
	/* 0x14ed: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14f0:
	/* 0x14f0: jmp    14fc <trace_load_elf_phdrs+0x14fc> */
	X86_SIM_X86_JMP(0x14f0, 0x14fc, x86_l_14fc);
x86_l_14f2:
	/* 0x14f2: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_14f5:
	/* 0x14f5: jmp    1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JMP(0x14f5, 0x1038, x86_l_1038);
x86_l_14fa:
	/* 0x14fa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14fc:
	/* 0x14fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14ff:
	/* 0x14ff: jns    1509 <trace_load_elf_phdrs+0x1509> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14ff, 0x1509, x86_l_1509);
x86_l_1501:
	/* 0x1501: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1504:
	/* 0x1504: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1507:
	/* 0x1507: jmp    150b <trace_load_elf_phdrs+0x150b> */
	X86_SIM_X86_JMP(0x1507, 0x150b, x86_l_150b);
x86_l_1509:
	/* 0x1509: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_150b:
	/* 0x150b: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_150e:
	/* 0x150e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1511:
	/* 0x1511: jns    1518 <trace_load_elf_phdrs+0x1518> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1511, 0x1518, x86_l_1518);
x86_l_1513:
	/* 0x1513: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1516:
	/* 0x1516: jmp    151b <trace_load_elf_phdrs+0x151b> */
	X86_SIM_X86_JMP(0x1516, 0x151b, x86_l_151b);
x86_l_1518:
	/* 0x1518: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_151b:
	/* 0x151b: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_151f:
	/* 0x151f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1522:
	/* 0x1522: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1525:
	/* 0x1525: jns    155a <trace_load_elf_phdrs+0x155a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1525, 0x155a, x86_l_155a);
x86_l_1527:
	/* 0x1527: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_152a:
	/* 0x152a: jmp    155c <trace_load_elf_phdrs+0x155c> */
	X86_SIM_X86_JMP(0x152a, 0x155c, x86_l_155c);
x86_l_152c:
	/* 0x152c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1531:
	/* 0x1531: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1535:
	/* 0x1535: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1535, 0x2278, x86_l_2278);
x86_l_153b:
	/* 0x153b: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1540:
	/* 0x1540: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1546:
	/* 0x1546: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_154b:
	/* 0x154b: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_154f:
	/* 0x154f: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1552:
	/* 0x1552: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1555:
	/* 0x1555: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1558:
	/* 0x1558: js     1527 <trace_load_elf_phdrs+0x1527> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1558, 0x1527, x86_l_1527);
x86_l_155a:
	/* 0x155a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_155c:
	/* 0x155c: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1560:
	/* 0x1560: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1563:
	/* 0x1563: jns    156a <trace_load_elf_phdrs+0x156a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1563, 0x156a, x86_l_156a);
x86_l_1565:
	/* 0x1565: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1568:
	/* 0x1568: jmp    156c <trace_load_elf_phdrs+0x156c> */
	X86_SIM_X86_JMP(0x1568, 0x156c, x86_l_156c);
x86_l_156a:
	/* 0x156a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156c:
	/* 0x156c: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_156f:
	/* 0x156f: je     15ec <trace_load_elf_phdrs+0x15ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x156f, 0x15ec, x86_l_15ec);
x86_l_1571:
	/* 0x1571: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1574:
	/* 0x1574: je     15ec <trace_load_elf_phdrs+0x15ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1574, 0x15ec, x86_l_15ec);
x86_l_1576:
	/* 0x1576: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_157a:
	/* 0x157a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157d:
	/* 0x157d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1583:
	/* 0x1583: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1586:
	/* 0x1586: jns    158f <trace_load_elf_phdrs+0x158f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1586, 0x158f, x86_l_158f);
x86_l_1588:
	/* 0x1588: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158b:
	/* 0x158b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_158f:
	/* 0x158f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1593:
	/* 0x1593: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1596:
	/* 0x1596: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_159d:
	/* 0x159d: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_15a0:
	/* 0x15a0: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_15a3:
	/* 0x15a3: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15a3, 0x22d5, x86_l_22d5);
x86_l_15a9:
	/* 0x15a9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_15ac:
	/* 0x15ac: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15ac, 0x227b, x86_l_227b);
x86_l_15b2:
	/* 0x15b2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_15b8:
	/* 0x15b8: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_15bd:
	/* 0x15bd: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_15c0:
	/* 0x15c0: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c0, 0x20c6, x86_l_20c6);
x86_l_15c6:
	/* 0x15c6: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_15ca:
	/* 0x15ca: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15cd:
	/* 0x15cd: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_15d0:
	/* 0x15d0: je     1641 <trace_load_elf_phdrs+0x1641> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15d0, 0x1641, x86_l_1641);
x86_l_15d2:
	/* 0x15d2: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_15d6:
	/* 0x15d6: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_15db:
	/* 0x15db: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_15df:
	/* 0x15df: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15e2:
	/* 0x15e2: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_15e5:
	/* 0x15e5: jne    15cd <trace_load_elf_phdrs+0x15cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15e5, 0x15cd, x86_l_15cd);
x86_l_15e7:
	/* 0x15e7: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_15ea:
	/* 0x15ea: jmp    1646 <trace_load_elf_phdrs+0x1646> */
	X86_SIM_X86_JMP(0x15ea, 0x1646, x86_l_1646);
x86_l_15ec:
	/* 0x15ec: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15ef:
	/* 0x15ef: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15ef, 0x227b, x86_l_227b);
x86_l_15f5:
	/* 0x15f5: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_15f8:
	/* 0x15f8: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f8, 0x227b, x86_l_227b);
x86_l_15fe:
	/* 0x15fe: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1602:
	/* 0x1602: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1605:
	/* 0x1605: jns    160c <trace_load_elf_phdrs+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1605, 0x160c, x86_l_160c);
x86_l_1607:
	/* 0x1607: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160a:
	/* 0x160a: jmp    160e <trace_load_elf_phdrs+0x160e> */
	X86_SIM_X86_JMP(0x160a, 0x160e, x86_l_160e);
x86_l_160c:
	/* 0x160c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_160e:
	/* 0x160e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1611:
	/* 0x1611: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1614:
	/* 0x1614: jns    161e <trace_load_elf_phdrs+0x161e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1614, 0x161e, x86_l_161e);
x86_l_1616:
	/* 0x1616: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1619:
	/* 0x1619: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_161c:
	/* 0x161c: jmp    1620 <trace_load_elf_phdrs+0x1620> */
	X86_SIM_X86_JMP(0x161c, 0x1620, x86_l_1620);
x86_l_161e:
	/* 0x161e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1620:
	/* 0x1620: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1623:
	/* 0x1623: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1626:
	/* 0x1626: jns    162d <trace_load_elf_phdrs+0x162d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1626, 0x162d, x86_l_162d);
x86_l_1628:
	/* 0x1628: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162b:
	/* 0x162b: jmp    1630 <trace_load_elf_phdrs+0x1630> */
	X86_SIM_X86_JMP(0x162b, 0x1630, x86_l_1630);
x86_l_162d:
	/* 0x162d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1630:
	/* 0x1630: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1634:
	/* 0x1634: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1637:
	/* 0x1637: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_163a:
	/* 0x163a: jns    166f <trace_load_elf_phdrs+0x166f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x163a, 0x166f, x86_l_166f);
x86_l_163c:
	/* 0x163c: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_163f:
	/* 0x163f: jmp    1671 <trace_load_elf_phdrs+0x1671> */
	X86_SIM_X86_JMP(0x163f, 0x1671, x86_l_1671);
x86_l_1641:
	/* 0x1641: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1646:
	/* 0x1646: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_164a:
	/* 0x164a: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x164a, 0x227b, x86_l_227b);
x86_l_1650:
	/* 0x1650: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1655:
	/* 0x1655: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_165b:
	/* 0x165b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1660:
	/* 0x1660: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1664:
	/* 0x1664: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1667:
	/* 0x1667: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_166a:
	/* 0x166a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_166d:
	/* 0x166d: js     163c <trace_load_elf_phdrs+0x163c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x166d, 0x163c, x86_l_163c);
x86_l_166f:
	/* 0x166f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1671:
	/* 0x1671: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1675:
	/* 0x1675: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1678:
	/* 0x1678: jns    167f <trace_load_elf_phdrs+0x167f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1678, 0x167f, x86_l_167f);
x86_l_167a:
	/* 0x167a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_167d:
	/* 0x167d: jmp    1681 <trace_load_elf_phdrs+0x1681> */
	X86_SIM_X86_JMP(0x167d, 0x1681, x86_l_1681);
x86_l_167f:
	/* 0x167f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1681:
	/* 0x1681: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1684:
	/* 0x1684: je     1701 <trace_load_elf_phdrs+0x1701> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1684, 0x1701, x86_l_1701);
x86_l_1686:
	/* 0x1686: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1689:
	/* 0x1689: je     1701 <trace_load_elf_phdrs+0x1701> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1689, 0x1701, x86_l_1701);
x86_l_168b:
	/* 0x168b: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_168f:
	/* 0x168f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1692:
	/* 0x1692: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1698:
	/* 0x1698: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_169b:
	/* 0x169b: jns    16a4 <trace_load_elf_phdrs+0x16a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x169b, 0x16a4, x86_l_16a4);
x86_l_169d:
	/* 0x169d: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a0:
	/* 0x16a0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16a4:
	/* 0x16a4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_16a8:
	/* 0x16a8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_16ab:
	/* 0x16ab: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_16b2:
	/* 0x16b2: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_16b5:
	/* 0x16b5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16b8:
	/* 0x16b8: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16b8, 0x22d5, x86_l_22d5);
x86_l_16be:
	/* 0x16be: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_16c1:
	/* 0x16c1: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16c1, 0x2278, x86_l_2278);
x86_l_16c7:
	/* 0x16c7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_16cd:
	/* 0x16cd: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_16d2:
	/* 0x16d2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_16d5:
	/* 0x16d5: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16d5, 0x20c9, x86_l_20c9);
x86_l_16db:
	/* 0x16db: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_16df:
	/* 0x16df: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16e2:
	/* 0x16e2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_16e5:
	/* 0x16e5: je     1756 <trace_load_elf_phdrs+0x1756> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e5, 0x1756, x86_l_1756);
x86_l_16e7:
	/* 0x16e7: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_16eb:
	/* 0x16eb: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_16f0:
	/* 0x16f0: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_16f4:
	/* 0x16f4: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16f7:
	/* 0x16f7: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_16fa:
	/* 0x16fa: jne    16e2 <trace_load_elf_phdrs+0x16e2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16fa, 0x16e2, x86_l_16e2);
x86_l_16fc:
	/* 0x16fc: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_16ff:
	/* 0x16ff: jmp    175b <trace_load_elf_phdrs+0x175b> */
	X86_SIM_X86_JMP(0x16ff, 0x175b, x86_l_175b);
x86_l_1701:
	/* 0x1701: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1704:
	/* 0x1704: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1704, 0x2278, x86_l_2278);
x86_l_170a:
	/* 0x170a: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_170d:
	/* 0x170d: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170d, 0x2278, x86_l_2278);
x86_l_1713:
	/* 0x1713: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1717:
	/* 0x1717: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_171a:
	/* 0x171a: jns    1721 <trace_load_elf_phdrs+0x1721> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x171a, 0x1721, x86_l_1721);
x86_l_171c:
	/* 0x171c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_171f:
	/* 0x171f: jmp    1723 <trace_load_elf_phdrs+0x1723> */
	X86_SIM_X86_JMP(0x171f, 0x1723, x86_l_1723);
x86_l_1721:
	/* 0x1721: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1723:
	/* 0x1723: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1726:
	/* 0x1726: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1729:
	/* 0x1729: jns    1733 <trace_load_elf_phdrs+0x1733> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1729, 0x1733, x86_l_1733);
x86_l_172b:
	/* 0x172b: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_172e:
	/* 0x172e: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1731:
	/* 0x1731: jmp    1735 <trace_load_elf_phdrs+0x1735> */
	X86_SIM_X86_JMP(0x1731, 0x1735, x86_l_1735);
x86_l_1733:
	/* 0x1733: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1735:
	/* 0x1735: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1738:
	/* 0x1738: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_173b:
	/* 0x173b: jns    1742 <trace_load_elf_phdrs+0x1742> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x173b, 0x1742, x86_l_1742);
x86_l_173d:
	/* 0x173d: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1740:
	/* 0x1740: jmp    1745 <trace_load_elf_phdrs+0x1745> */
	X86_SIM_X86_JMP(0x1740, 0x1745, x86_l_1745);
x86_l_1742:
	/* 0x1742: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1745:
	/* 0x1745: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1749:
	/* 0x1749: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_174c:
	/* 0x174c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_174f:
	/* 0x174f: jns    1784 <trace_load_elf_phdrs+0x1784> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x174f, 0x1784, x86_l_1784);
x86_l_1751:
	/* 0x1751: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1754:
	/* 0x1754: jmp    1786 <trace_load_elf_phdrs+0x1786> */
	X86_SIM_X86_JMP(0x1754, 0x1786, x86_l_1786);
x86_l_1756:
	/* 0x1756: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_175b:
	/* 0x175b: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_175f:
	/* 0x175f: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x175f, 0x2278, x86_l_2278);
x86_l_1765:
	/* 0x1765: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_176a:
	/* 0x176a: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1770:
	/* 0x1770: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1775:
	/* 0x1775: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1779:
	/* 0x1779: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_177c:
	/* 0x177c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_177f:
	/* 0x177f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1782:
	/* 0x1782: js     1751 <trace_load_elf_phdrs+0x1751> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1782, 0x1751, x86_l_1751);
x86_l_1784:
	/* 0x1784: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1786:
	/* 0x1786: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_178a:
	/* 0x178a: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_178d:
	/* 0x178d: jns    1794 <trace_load_elf_phdrs+0x1794> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178d, 0x1794, x86_l_1794);
x86_l_178f:
	/* 0x178f: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1792:
	/* 0x1792: jmp    1796 <trace_load_elf_phdrs+0x1796> */
	X86_SIM_X86_JMP(0x1792, 0x1796, x86_l_1796);
x86_l_1794:
	/* 0x1794: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1796:
	/* 0x1796: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1799:
	/* 0x1799: je     1816 <trace_load_elf_phdrs+0x1816> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1799, 0x1816, x86_l_1816);
x86_l_179b:
	/* 0x179b: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_179e:
	/* 0x179e: je     1816 <trace_load_elf_phdrs+0x1816> */
	X86_SIM_X86_JCC(X86_CC_E, 0x179e, 0x1816, x86_l_1816);
x86_l_17a0:
	/* 0x17a0: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17a4:
	/* 0x17a4: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a7:
	/* 0x17a7: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_17ad:
	/* 0x17ad: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17b0:
	/* 0x17b0: jns    17b9 <trace_load_elf_phdrs+0x17b9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17b0, 0x17b9, x86_l_17b9);
x86_l_17b2:
	/* 0x17b2: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b5:
	/* 0x17b5: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17b9:
	/* 0x17b9: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_17bd:
	/* 0x17bd: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_17c0:
	/* 0x17c0: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_17c7:
	/* 0x17c7: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_17ca:
	/* 0x17ca: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_17cd:
	/* 0x17cd: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x17cd, 0x22d5, x86_l_22d5);
x86_l_17d3:
	/* 0x17d3: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_17d6:
	/* 0x17d6: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17d6, 0x227b, x86_l_227b);
x86_l_17dc:
	/* 0x17dc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_17e2:
	/* 0x17e2: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_17e7:
	/* 0x17e7: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_17ea:
	/* 0x17ea: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ea, 0x20c6, x86_l_20c6);
x86_l_17f0:
	/* 0x17f0: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_17f4:
	/* 0x17f4: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f7:
	/* 0x17f7: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_17fa:
	/* 0x17fa: je     186b <trace_load_elf_phdrs+0x186b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17fa, 0x186b, x86_l_186b);
x86_l_17fc:
	/* 0x17fc: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1800:
	/* 0x1800: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1805:
	/* 0x1805: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1809:
	/* 0x1809: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_180c:
	/* 0x180c: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_180f:
	/* 0x180f: jne    17f7 <trace_load_elf_phdrs+0x17f7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x180f, 0x17f7, x86_l_17f7);
x86_l_1811:
	/* 0x1811: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1814:
	/* 0x1814: jmp    1870 <trace_load_elf_phdrs+0x1870> */
	X86_SIM_X86_JMP(0x1814, 0x1870, x86_l_1870);
x86_l_1816:
	/* 0x1816: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1819:
	/* 0x1819: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1819, 0x227b, x86_l_227b);
x86_l_181f:
	/* 0x181f: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1822:
	/* 0x1822: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1822, 0x227b, x86_l_227b);
x86_l_1828:
	/* 0x1828: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_182c:
	/* 0x182c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_182f:
	/* 0x182f: jns    1836 <trace_load_elf_phdrs+0x1836> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x182f, 0x1836, x86_l_1836);
x86_l_1831:
	/* 0x1831: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1834:
	/* 0x1834: jmp    1838 <trace_load_elf_phdrs+0x1838> */
	X86_SIM_X86_JMP(0x1834, 0x1838, x86_l_1838);
x86_l_1836:
	/* 0x1836: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1838:
	/* 0x1838: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_183b:
	/* 0x183b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_183e:
	/* 0x183e: jns    1848 <trace_load_elf_phdrs+0x1848> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x183e, 0x1848, x86_l_1848);
x86_l_1840:
	/* 0x1840: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1843:
	/* 0x1843: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1846:
	/* 0x1846: jmp    184a <trace_load_elf_phdrs+0x184a> */
	X86_SIM_X86_JMP(0x1846, 0x184a, x86_l_184a);
x86_l_1848:
	/* 0x1848: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_184a:
	/* 0x184a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_184d:
	/* 0x184d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1850:
	/* 0x1850: jns    1857 <trace_load_elf_phdrs+0x1857> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1850, 0x1857, x86_l_1857);
x86_l_1852:
	/* 0x1852: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1855:
	/* 0x1855: jmp    185a <trace_load_elf_phdrs+0x185a> */
	X86_SIM_X86_JMP(0x1855, 0x185a, x86_l_185a);
x86_l_1857:
	/* 0x1857: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_185a:
	/* 0x185a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_185e:
	/* 0x185e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1861:
	/* 0x1861: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1864:
	/* 0x1864: jns    1899 <trace_load_elf_phdrs+0x1899> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1864, 0x1899, x86_l_1899);
x86_l_1866:
	/* 0x1866: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1869:
	/* 0x1869: jmp    189b <trace_load_elf_phdrs+0x189b> */
	X86_SIM_X86_JMP(0x1869, 0x189b, x86_l_189b);
x86_l_186b:
	/* 0x186b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1870:
	/* 0x1870: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1874:
	/* 0x1874: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1874, 0x227b, x86_l_227b);
x86_l_187a:
	/* 0x187a: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_187f:
	/* 0x187f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1885:
	/* 0x1885: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_188a:
	/* 0x188a: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_188e:
	/* 0x188e: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1891:
	/* 0x1891: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1894:
	/* 0x1894: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1897:
	/* 0x1897: js     1866 <trace_load_elf_phdrs+0x1866> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1897, 0x1866, x86_l_1866);
x86_l_1899:
	/* 0x1899: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_189b:
	/* 0x189b: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_189f:
	/* 0x189f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18a2:
	/* 0x18a2: jns    18a9 <trace_load_elf_phdrs+0x18a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18a2, 0x18a9, x86_l_18a9);
x86_l_18a4:
	/* 0x18a4: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18a7:
	/* 0x18a7: jmp    18ab <trace_load_elf_phdrs+0x18ab> */
	X86_SIM_X86_JMP(0x18a7, 0x18ab, x86_l_18ab);
x86_l_18a9:
	/* 0x18a9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18ab:
	/* 0x18ab: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_18ae:
	/* 0x18ae: je     192b <trace_load_elf_phdrs+0x192b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18ae, 0x192b, x86_l_192b);
x86_l_18b0:
	/* 0x18b0: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18b3:
	/* 0x18b3: je     192b <trace_load_elf_phdrs+0x192b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b3, 0x192b, x86_l_192b);
x86_l_18b5:
	/* 0x18b5: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18b9:
	/* 0x18b9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18bc:
	/* 0x18bc: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_18c2:
	/* 0x18c2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_18c5:
	/* 0x18c5: jns    18ce <trace_load_elf_phdrs+0x18ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c5, 0x18ce, x86_l_18ce);
x86_l_18c7:
	/* 0x18c7: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18ca:
	/* 0x18ca: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18ce:
	/* 0x18ce: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_18d2:
	/* 0x18d2: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_18d5:
	/* 0x18d5: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_18dc:
	/* 0x18dc: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_18df:
	/* 0x18df: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_18e2:
	/* 0x18e2: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x18e2, 0x22d5, x86_l_22d5);
x86_l_18e8:
	/* 0x18e8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_18eb:
	/* 0x18eb: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18eb, 0x2278, x86_l_2278);
x86_l_18f1:
	/* 0x18f1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_18f7:
	/* 0x18f7: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_18fc:
	/* 0x18fc: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_18ff:
	/* 0x18ff: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18ff, 0x20c9, x86_l_20c9);
x86_l_1905:
	/* 0x1905: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1909:
	/* 0x1909: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_190c:
	/* 0x190c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_190f:
	/* 0x190f: je     1980 <trace_load_elf_phdrs+0x1980> */
	X86_SIM_X86_JCC(X86_CC_E, 0x190f, 0x1980, x86_l_1980);
x86_l_1911:
	/* 0x1911: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1915:
	/* 0x1915: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_191a:
	/* 0x191a: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_191e:
	/* 0x191e: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1921:
	/* 0x1921: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1924:
	/* 0x1924: jne    190c <trace_load_elf_phdrs+0x190c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1924, 0x190c, x86_l_190c);
x86_l_1926:
	/* 0x1926: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1929:
	/* 0x1929: jmp    1985 <trace_load_elf_phdrs+0x1985> */
	X86_SIM_X86_JMP(0x1929, 0x1985, x86_l_1985);
x86_l_192b:
	/* 0x192b: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_192e:
	/* 0x192e: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x192e, 0x2278, x86_l_2278);
x86_l_1934:
	/* 0x1934: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1937:
	/* 0x1937: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1937, 0x2278, x86_l_2278);
x86_l_193d:
	/* 0x193d: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1941:
	/* 0x1941: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1944:
	/* 0x1944: jns    194b <trace_load_elf_phdrs+0x194b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1944, 0x194b, x86_l_194b);
x86_l_1946:
	/* 0x1946: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1949:
	/* 0x1949: jmp    194d <trace_load_elf_phdrs+0x194d> */
	X86_SIM_X86_JMP(0x1949, 0x194d, x86_l_194d);
x86_l_194b:
	/* 0x194b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_194d:
	/* 0x194d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1950:
	/* 0x1950: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1953:
	/* 0x1953: jns    195d <trace_load_elf_phdrs+0x195d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1953, 0x195d, x86_l_195d);
x86_l_1955:
	/* 0x1955: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1958:
	/* 0x1958: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_195b:
	/* 0x195b: jmp    195f <trace_load_elf_phdrs+0x195f> */
	X86_SIM_X86_JMP(0x195b, 0x195f, x86_l_195f);
x86_l_195d:
	/* 0x195d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_195f:
	/* 0x195f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1962:
	/* 0x1962: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1965:
	/* 0x1965: jns    196c <trace_load_elf_phdrs+0x196c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1965, 0x196c, x86_l_196c);
x86_l_1967:
	/* 0x1967: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_196a:
	/* 0x196a: jmp    196f <trace_load_elf_phdrs+0x196f> */
	X86_SIM_X86_JMP(0x196a, 0x196f, x86_l_196f);
x86_l_196c:
	/* 0x196c: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_196f:
	/* 0x196f: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1973:
	/* 0x1973: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1976:
	/* 0x1976: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1979:
	/* 0x1979: jns    19ae <trace_load_elf_phdrs+0x19ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1979, 0x19ae, x86_l_19ae);
x86_l_197b:
	/* 0x197b: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_197e:
	/* 0x197e: jmp    19b0 <trace_load_elf_phdrs+0x19b0> */
	X86_SIM_X86_JMP(0x197e, 0x19b0, x86_l_19b0);
x86_l_1980:
	/* 0x1980: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1985:
	/* 0x1985: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1989:
	/* 0x1989: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1989, 0x2278, x86_l_2278);
x86_l_198f:
	/* 0x198f: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1994:
	/* 0x1994: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_199a:
	/* 0x199a: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_199f:
	/* 0x199f: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_19a3:
	/* 0x19a3: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_19a6:
	/* 0x19a6: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_19a9:
	/* 0x19a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19ac:
	/* 0x19ac: js     197b <trace_load_elf_phdrs+0x197b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19ac, 0x197b, x86_l_197b);
x86_l_19ae:
	/* 0x19ae: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19b0:
	/* 0x19b0: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b4:
	/* 0x19b4: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_19b7:
	/* 0x19b7: jns    19be <trace_load_elf_phdrs+0x19be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19b7, 0x19be, x86_l_19be);
x86_l_19b9:
	/* 0x19b9: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19bc:
	/* 0x19bc: jmp    19c0 <trace_load_elf_phdrs+0x19c0> */
	X86_SIM_X86_JMP(0x19bc, 0x19c0, x86_l_19c0);
x86_l_19be:
	/* 0x19be: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19c0:
	/* 0x19c0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19c3:
	/* 0x19c3: je     1a40 <trace_load_elf_phdrs+0x1a40> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c3, 0x1a40, x86_l_1a40);
x86_l_19c5:
	/* 0x19c5: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_19c8:
	/* 0x19c8: je     1a40 <trace_load_elf_phdrs+0x1a40> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c8, 0x1a40, x86_l_1a40);
x86_l_19ca:
	/* 0x19ca: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19ce:
	/* 0x19ce: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19d1:
	/* 0x19d1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_19d7:
	/* 0x19d7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19da:
	/* 0x19da: jns    19e3 <trace_load_elf_phdrs+0x19e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19da, 0x19e3, x86_l_19e3);
x86_l_19dc:
	/* 0x19dc: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19df:
	/* 0x19df: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19e3:
	/* 0x19e3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_19e7:
	/* 0x19e7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_19ea:
	/* 0x19ea: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_19f1:
	/* 0x19f1: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_19f4:
	/* 0x19f4: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_19f7:
	/* 0x19f7: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x19f7, 0x22d5, x86_l_22d5);
x86_l_19fd:
	/* 0x19fd: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1a00:
	/* 0x1a00: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a00, 0x227b, x86_l_227b);
x86_l_1a06:
	/* 0x1a06: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1a0c:
	/* 0x1a0c: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1a11:
	/* 0x1a11: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1a14:
	/* 0x1a14: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a14, 0x20c6, x86_l_20c6);
x86_l_1a1a:
	/* 0x1a1a: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a1e:
	/* 0x1a1e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a21:
	/* 0x1a21: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1a24:
	/* 0x1a24: je     1a95 <trace_load_elf_phdrs+0x1a95> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a24, 0x1a95, x86_l_1a95);
x86_l_1a26:
	/* 0x1a26: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a2a:
	/* 0x1a2a: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1a2f:
	/* 0x1a2f: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1a33:
	/* 0x1a33: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a36:
	/* 0x1a36: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1a39:
	/* 0x1a39: jne    1a21 <trace_load_elf_phdrs+0x1a21> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a39, 0x1a21, x86_l_1a21);
x86_l_1a3b:
	/* 0x1a3b: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1a3e:
	/* 0x1a3e: jmp    1a9a <trace_load_elf_phdrs+0x1a9a> */
	X86_SIM_X86_JMP(0x1a3e, 0x1a9a, x86_l_1a9a);
x86_l_1a40:
	/* 0x1a40: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a43:
	/* 0x1a43: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a43, 0x227b, x86_l_227b);
x86_l_1a49:
	/* 0x1a49: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1a4c:
	/* 0x1a4c: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a4c, 0x227b, x86_l_227b);
x86_l_1a52:
	/* 0x1a52: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a56:
	/* 0x1a56: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a59:
	/* 0x1a59: jns    1a60 <trace_load_elf_phdrs+0x1a60> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a59, 0x1a60, x86_l_1a60);
x86_l_1a5b:
	/* 0x1a5b: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a5e:
	/* 0x1a5e: jmp    1a62 <trace_load_elf_phdrs+0x1a62> */
	X86_SIM_X86_JMP(0x1a5e, 0x1a62, x86_l_1a62);
x86_l_1a60:
	/* 0x1a60: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a62:
	/* 0x1a62: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a65:
	/* 0x1a65: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a68:
	/* 0x1a68: jns    1a72 <trace_load_elf_phdrs+0x1a72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a68, 0x1a72, x86_l_1a72);
x86_l_1a6a:
	/* 0x1a6a: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a6d:
	/* 0x1a6d: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a70:
	/* 0x1a70: jmp    1a74 <trace_load_elf_phdrs+0x1a74> */
	X86_SIM_X86_JMP(0x1a70, 0x1a74, x86_l_1a74);
x86_l_1a72:
	/* 0x1a72: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a74:
	/* 0x1a74: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a77:
	/* 0x1a77: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a7a:
	/* 0x1a7a: jns    1a81 <trace_load_elf_phdrs+0x1a81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a7a, 0x1a81, x86_l_1a81);
x86_l_1a7c:
	/* 0x1a7c: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a7f:
	/* 0x1a7f: jmp    1a84 <trace_load_elf_phdrs+0x1a84> */
	X86_SIM_X86_JMP(0x1a7f, 0x1a84, x86_l_1a84);
x86_l_1a81:
	/* 0x1a81: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a84:
	/* 0x1a84: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a88:
	/* 0x1a88: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a8b:
	/* 0x1a8b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a8e:
	/* 0x1a8e: jns    1ac3 <trace_load_elf_phdrs+0x1ac3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a8e, 0x1ac3, x86_l_1ac3);
x86_l_1a90:
	/* 0x1a90: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a93:
	/* 0x1a93: jmp    1ac5 <trace_load_elf_phdrs+0x1ac5> */
	X86_SIM_X86_JMP(0x1a93, 0x1ac5, x86_l_1ac5);
x86_l_1a95:
	/* 0x1a95: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a9a:
	/* 0x1a9a: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a9e:
	/* 0x1a9e: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a9e, 0x227b, x86_l_227b);
x86_l_1aa4:
	/* 0x1aa4: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1aa9:
	/* 0x1aa9: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1aaf:
	/* 0x1aaf: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ab4:
	/* 0x1ab4: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1ab8:
	/* 0x1ab8: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1abb:
	/* 0x1abb: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1abe:
	/* 0x1abe: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ac1:
	/* 0x1ac1: js     1a90 <trace_load_elf_phdrs+0x1a90> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ac1, 0x1a90, x86_l_1a90);
x86_l_1ac3:
	/* 0x1ac3: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac5:
	/* 0x1ac5: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ac9:
	/* 0x1ac9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1acc:
	/* 0x1acc: jns    1ad3 <trace_load_elf_phdrs+0x1ad3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1acc, 0x1ad3, x86_l_1ad3);
x86_l_1ace:
	/* 0x1ace: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ad1:
	/* 0x1ad1: jmp    1ad5 <trace_load_elf_phdrs+0x1ad5> */
	X86_SIM_X86_JMP(0x1ad1, 0x1ad5, x86_l_1ad5);
x86_l_1ad3:
	/* 0x1ad3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ad5:
	/* 0x1ad5: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ad8:
	/* 0x1ad8: je     1b55 <trace_load_elf_phdrs+0x1b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ad8, 0x1b55, x86_l_1b55);
x86_l_1ada:
	/* 0x1ada: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1add:
	/* 0x1add: je     1b55 <trace_load_elf_phdrs+0x1b55> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1add, 0x1b55, x86_l_1b55);
x86_l_1adf:
	/* 0x1adf: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ae3:
	/* 0x1ae3: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ae6:
	/* 0x1ae6: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1aec:
	/* 0x1aec: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1aef:
	/* 0x1aef: jns    1af8 <trace_load_elf_phdrs+0x1af8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aef, 0x1af8, x86_l_1af8);
x86_l_1af1:
	/* 0x1af1: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af4:
	/* 0x1af4: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1af8:
	/* 0x1af8: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1afc:
	/* 0x1afc: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1aff:
	/* 0x1aff: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b06:
	/* 0x1b06: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1b09:
	/* 0x1b09: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b0c:
	/* 0x1b0c: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b0c, 0x22d5, x86_l_22d5);
x86_l_1b12:
	/* 0x1b12: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1b15:
	/* 0x1b15: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b15, 0x2278, x86_l_2278);
x86_l_1b1b:
	/* 0x1b1b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b21:
	/* 0x1b21: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1b26:
	/* 0x1b26: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1b29:
	/* 0x1b29: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b29, 0x20c9, x86_l_20c9);
x86_l_1b2f:
	/* 0x1b2f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b33:
	/* 0x1b33: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b36:
	/* 0x1b36: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b39:
	/* 0x1b39: je     1baa <trace_load_elf_phdrs+0x1baa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b39, 0x1baa, x86_l_1baa);
x86_l_1b3b:
	/* 0x1b3b: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b3f:
	/* 0x1b3f: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b44:
	/* 0x1b44: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b48:
	/* 0x1b48: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b4b:
	/* 0x1b4b: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1b4e:
	/* 0x1b4e: jne    1b36 <trace_load_elf_phdrs+0x1b36> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b4e, 0x1b36, x86_l_1b36);
x86_l_1b50:
	/* 0x1b50: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1b53:
	/* 0x1b53: jmp    1baf <trace_load_elf_phdrs+0x1baf> */
	X86_SIM_X86_JMP(0x1b53, 0x1baf, x86_l_1baf);
x86_l_1b55:
	/* 0x1b55: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b58:
	/* 0x1b58: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b58, 0x2278, x86_l_2278);
x86_l_1b5e:
	/* 0x1b5e: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1b61:
	/* 0x1b61: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b61, 0x2278, x86_l_2278);
x86_l_1b67:
	/* 0x1b67: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b6b:
	/* 0x1b6b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b6e:
	/* 0x1b6e: jns    1b75 <trace_load_elf_phdrs+0x1b75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b6e, 0x1b75, x86_l_1b75);
x86_l_1b70:
	/* 0x1b70: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b73:
	/* 0x1b73: jmp    1b77 <trace_load_elf_phdrs+0x1b77> */
	X86_SIM_X86_JMP(0x1b73, 0x1b77, x86_l_1b77);
x86_l_1b75:
	/* 0x1b75: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b77:
	/* 0x1b77: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b7a:
	/* 0x1b7a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b7d:
	/* 0x1b7d: jns    1b87 <trace_load_elf_phdrs+0x1b87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b7d, 0x1b87, x86_l_1b87);
x86_l_1b7f:
	/* 0x1b7f: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b82:
	/* 0x1b82: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b85:
	/* 0x1b85: jmp    1b89 <trace_load_elf_phdrs+0x1b89> */
	X86_SIM_X86_JMP(0x1b85, 0x1b89, x86_l_1b89);
x86_l_1b87:
	/* 0x1b87: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b89:
	/* 0x1b89: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b8c:
	/* 0x1b8c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b8f:
	/* 0x1b8f: jns    1b96 <trace_load_elf_phdrs+0x1b96> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b8f, 0x1b96, x86_l_1b96);
x86_l_1b91:
	/* 0x1b91: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b94:
	/* 0x1b94: jmp    1b99 <trace_load_elf_phdrs+0x1b99> */
	X86_SIM_X86_JMP(0x1b94, 0x1b99, x86_l_1b99);
x86_l_1b96:
	/* 0x1b96: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b99:
	/* 0x1b99: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b9d:
	/* 0x1b9d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ba0:
	/* 0x1ba0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ba3:
	/* 0x1ba3: jns    1bd8 <trace_load_elf_phdrs+0x1bd8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba3, 0x1bd8, x86_l_1bd8);
x86_l_1ba5:
	/* 0x1ba5: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ba8:
	/* 0x1ba8: jmp    1bda <trace_load_elf_phdrs+0x1bda> */
	X86_SIM_X86_JMP(0x1ba8, 0x1bda, x86_l_1bda);
x86_l_1baa:
	/* 0x1baa: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1baf:
	/* 0x1baf: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bb3:
	/* 0x1bb3: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1bb3, 0x2278, x86_l_2278);
x86_l_1bb9:
	/* 0x1bb9: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bbe:
	/* 0x1bbe: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1bc4:
	/* 0x1bc4: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bc9:
	/* 0x1bc9: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1bcd:
	/* 0x1bcd: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1bd0:
	/* 0x1bd0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bd3:
	/* 0x1bd3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bd6:
	/* 0x1bd6: js     1ba5 <trace_load_elf_phdrs+0x1ba5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bd6, 0x1ba5, x86_l_1ba5);
x86_l_1bd8:
	/* 0x1bd8: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bda:
	/* 0x1bda: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bde:
	/* 0x1bde: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1be1:
	/* 0x1be1: jns    1be8 <trace_load_elf_phdrs+0x1be8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1be1, 0x1be8, x86_l_1be8);
x86_l_1be3:
	/* 0x1be3: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1be6:
	/* 0x1be6: jmp    1bea <trace_load_elf_phdrs+0x1bea> */
	X86_SIM_X86_JMP(0x1be6, 0x1bea, x86_l_1bea);
x86_l_1be8:
	/* 0x1be8: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bea:
	/* 0x1bea: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bed:
	/* 0x1bed: je     1c6a <trace_load_elf_phdrs+0x1c6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bed, 0x1c6a, x86_l_1c6a);
x86_l_1bef:
	/* 0x1bef: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1bf2:
	/* 0x1bf2: je     1c6a <trace_load_elf_phdrs+0x1c6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bf2, 0x1c6a, x86_l_1c6a);
x86_l_1bf4:
	/* 0x1bf4: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bf8:
	/* 0x1bf8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bfb:
	/* 0x1bfb: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c01:
	/* 0x1c01: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c04:
	/* 0x1c04: jns    1c0d <trace_load_elf_phdrs+0x1c0d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c04, 0x1c0d, x86_l_1c0d);
x86_l_1c06:
	/* 0x1c06: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c09:
	/* 0x1c09: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0d:
	/* 0x1c0d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c11:
	/* 0x1c11: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c14:
	/* 0x1c14: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c1b:
	/* 0x1c1b: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1c1e:
	/* 0x1c1e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c21:
	/* 0x1c21: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c21, 0x22d5, x86_l_22d5);
x86_l_1c27:
	/* 0x1c27: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1c2a:
	/* 0x1c2a: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c2a, 0x227b, x86_l_227b);
x86_l_1c30:
	/* 0x1c30: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c36:
	/* 0x1c36: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1c3b:
	/* 0x1c3b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c3e:
	/* 0x1c3e: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c3e, 0x20c6, x86_l_20c6);
x86_l_1c44:
	/* 0x1c44: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c48:
	/* 0x1c48: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c4b:
	/* 0x1c4b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c4e:
	/* 0x1c4e: je     1cbf <trace_load_elf_phdrs+0x1cbf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4e, 0x1cbf, x86_l_1cbf);
x86_l_1c50:
	/* 0x1c50: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c54:
	/* 0x1c54: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c59:
	/* 0x1c59: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c5d:
	/* 0x1c5d: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c60:
	/* 0x1c60: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1c63:
	/* 0x1c63: jne    1c4b <trace_load_elf_phdrs+0x1c4b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c63, 0x1c4b, x86_l_1c4b);
x86_l_1c65:
	/* 0x1c65: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1c68:
	/* 0x1c68: jmp    1cc4 <trace_load_elf_phdrs+0x1cc4> */
	X86_SIM_X86_JMP(0x1c68, 0x1cc4, x86_l_1cc4);
x86_l_1c6a:
	/* 0x1c6a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c6d:
	/* 0x1c6d: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c6d, 0x227b, x86_l_227b);
x86_l_1c73:
	/* 0x1c73: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c76:
	/* 0x1c76: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c76, 0x227b, x86_l_227b);
x86_l_1c7c:
	/* 0x1c7c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c80:
	/* 0x1c80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c83:
	/* 0x1c83: jns    1c8a <trace_load_elf_phdrs+0x1c8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c83, 0x1c8a, x86_l_1c8a);
x86_l_1c85:
	/* 0x1c85: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c88:
	/* 0x1c88: jmp    1c8c <trace_load_elf_phdrs+0x1c8c> */
	X86_SIM_X86_JMP(0x1c88, 0x1c8c, x86_l_1c8c);
x86_l_1c8a:
	/* 0x1c8a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c8c:
	/* 0x1c8c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c8f:
	/* 0x1c8f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c92:
	/* 0x1c92: jns    1c9c <trace_load_elf_phdrs+0x1c9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c92, 0x1c9c, x86_l_1c9c);
x86_l_1c94:
	/* 0x1c94: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c97:
	/* 0x1c97: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c9a:
	/* 0x1c9a: jmp    1c9e <trace_load_elf_phdrs+0x1c9e> */
	X86_SIM_X86_JMP(0x1c9a, 0x1c9e, x86_l_1c9e);
x86_l_1c9c:
	/* 0x1c9c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c9e:
	/* 0x1c9e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ca1:
	/* 0x1ca1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ca4:
	/* 0x1ca4: jns    1cab <trace_load_elf_phdrs+0x1cab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca4, 0x1cab, x86_l_1cab);
x86_l_1ca6:
	/* 0x1ca6: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca9:
	/* 0x1ca9: jmp    1cae <trace_load_elf_phdrs+0x1cae> */
	X86_SIM_X86_JMP(0x1ca9, 0x1cae, x86_l_1cae);
x86_l_1cab:
	/* 0x1cab: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cae:
	/* 0x1cae: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cb2:
	/* 0x1cb2: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cb5:
	/* 0x1cb5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cb8:
	/* 0x1cb8: jns    1ced <trace_load_elf_phdrs+0x1ced> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb8, 0x1ced, x86_l_1ced);
x86_l_1cba:
	/* 0x1cba: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cbd:
	/* 0x1cbd: jmp    1cef <trace_load_elf_phdrs+0x1cef> */
	X86_SIM_X86_JMP(0x1cbd, 0x1cef, x86_l_1cef);
x86_l_1cbf:
	/* 0x1cbf: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1cc4:
	/* 0x1cc4: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1cc8:
	/* 0x1cc8: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1cc8, 0x227b, x86_l_227b);
x86_l_1cce:
	/* 0x1cce: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1cd3:
	/* 0x1cd3: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1cd9:
	/* 0x1cd9: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cde:
	/* 0x1cde: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1ce2:
	/* 0x1ce2: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ce5:
	/* 0x1ce5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ce8:
	/* 0x1ce8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ceb:
	/* 0x1ceb: js     1cba <trace_load_elf_phdrs+0x1cba> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ceb, 0x1cba, x86_l_1cba);
x86_l_1ced:
	/* 0x1ced: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cef:
	/* 0x1cef: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cf3:
	/* 0x1cf3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1cf6:
	/* 0x1cf6: jns    1cfd <trace_load_elf_phdrs+0x1cfd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cf6, 0x1cfd, x86_l_1cfd);
x86_l_1cf8:
	/* 0x1cf8: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cfb:
	/* 0x1cfb: jmp    1cff <trace_load_elf_phdrs+0x1cff> */
	X86_SIM_X86_JMP(0x1cfb, 0x1cff, x86_l_1cff);
x86_l_1cfd:
	/* 0x1cfd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cff:
	/* 0x1cff: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d02:
	/* 0x1d02: je     1d7f <trace_load_elf_phdrs+0x1d7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d02, 0x1d7f, x86_l_1d7f);
x86_l_1d04:
	/* 0x1d04: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d07:
	/* 0x1d07: je     1d7f <trace_load_elf_phdrs+0x1d7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d07, 0x1d7f, x86_l_1d7f);
x86_l_1d09:
	/* 0x1d09: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d0d:
	/* 0x1d0d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d10:
	/* 0x1d10: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d16:
	/* 0x1d16: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d19:
	/* 0x1d19: jns    1d22 <trace_load_elf_phdrs+0x1d22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d19, 0x1d22, x86_l_1d22);
x86_l_1d1b:
	/* 0x1d1b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d1e:
	/* 0x1d1e: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d22:
	/* 0x1d22: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1d26:
	/* 0x1d26: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d29:
	/* 0x1d29: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d30:
	/* 0x1d30: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1d33:
	/* 0x1d33: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d36:
	/* 0x1d36: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d36, 0x22d5, x86_l_22d5);
x86_l_1d3c:
	/* 0x1d3c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1d3f:
	/* 0x1d3f: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d3f, 0x2278, x86_l_2278);
x86_l_1d45:
	/* 0x1d45: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d4b:
	/* 0x1d4b: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1d50:
	/* 0x1d50: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1d53:
	/* 0x1d53: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d53, 0x20c9, x86_l_20c9);
x86_l_1d59:
	/* 0x1d59: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d5d:
	/* 0x1d5d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d60:
	/* 0x1d60: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d63:
	/* 0x1d63: je     1dd4 <trace_load_elf_phdrs+0x1dd4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d63, 0x1dd4, x86_l_1dd4);
x86_l_1d65:
	/* 0x1d65: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d69:
	/* 0x1d69: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1d6e:
	/* 0x1d6e: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1d72:
	/* 0x1d72: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d75:
	/* 0x1d75: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1d78:
	/* 0x1d78: jne    1d60 <trace_load_elf_phdrs+0x1d60> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d78, 0x1d60, x86_l_1d60);
x86_l_1d7a:
	/* 0x1d7a: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d7d:
	/* 0x1d7d: jmp    1dd9 <trace_load_elf_phdrs+0x1dd9> */
	X86_SIM_X86_JMP(0x1d7d, 0x1dd9, x86_l_1dd9);
x86_l_1d7f:
	/* 0x1d7f: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d82:
	/* 0x1d82: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d82, 0x2278, x86_l_2278);
x86_l_1d88:
	/* 0x1d88: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1d8b:
	/* 0x1d8b: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d8b, 0x2278, x86_l_2278);
x86_l_1d91:
	/* 0x1d91: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d95:
	/* 0x1d95: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d98:
	/* 0x1d98: jns    1d9f <trace_load_elf_phdrs+0x1d9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d98, 0x1d9f, x86_l_1d9f);
x86_l_1d9a:
	/* 0x1d9a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d9d:
	/* 0x1d9d: jmp    1da1 <trace_load_elf_phdrs+0x1da1> */
	X86_SIM_X86_JMP(0x1d9d, 0x1da1, x86_l_1da1);
x86_l_1d9f:
	/* 0x1d9f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1da1:
	/* 0x1da1: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1da4:
	/* 0x1da4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1da7:
	/* 0x1da7: jns    1db1 <trace_load_elf_phdrs+0x1db1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1da7, 0x1db1, x86_l_1db1);
x86_l_1da9:
	/* 0x1da9: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dac:
	/* 0x1dac: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1daf:
	/* 0x1daf: jmp    1db3 <trace_load_elf_phdrs+0x1db3> */
	X86_SIM_X86_JMP(0x1daf, 0x1db3, x86_l_1db3);
x86_l_1db1:
	/* 0x1db1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1db3:
	/* 0x1db3: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1db6:
	/* 0x1db6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1db9:
	/* 0x1db9: jns    1dc0 <trace_load_elf_phdrs+0x1dc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1db9, 0x1dc0, x86_l_1dc0);
x86_l_1dbb:
	/* 0x1dbb: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dbe:
	/* 0x1dbe: jmp    1dc3 <trace_load_elf_phdrs+0x1dc3> */
	X86_SIM_X86_JMP(0x1dbe, 0x1dc3, x86_l_1dc3);
x86_l_1dc0:
	/* 0x1dc0: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc3:
	/* 0x1dc3: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dc7:
	/* 0x1dc7: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dca:
	/* 0x1dca: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1dcd:
	/* 0x1dcd: jns    1e02 <trace_load_elf_phdrs+0x1e02> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dcd, 0x1e02, x86_l_1e02);
x86_l_1dcf:
	/* 0x1dcf: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd2:
	/* 0x1dd2: jmp    1e04 <trace_load_elf_phdrs+0x1e04> */
	X86_SIM_X86_JMP(0x1dd2, 0x1e04, x86_l_1e04);
x86_l_1dd4:
	/* 0x1dd4: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1dd9:
	/* 0x1dd9: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ddd:
	/* 0x1ddd: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ddd, 0x2278, x86_l_2278);
x86_l_1de3:
	/* 0x1de3: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1de8:
	/* 0x1de8: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1dee:
	/* 0x1dee: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1df3:
	/* 0x1df3: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1df7:
	/* 0x1df7: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1dfa:
	/* 0x1dfa: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dfd:
	/* 0x1dfd: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e00:
	/* 0x1e00: js     1dcf <trace_load_elf_phdrs+0x1dcf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e00, 0x1dcf, x86_l_1dcf);
x86_l_1e02:
	/* 0x1e02: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e04:
	/* 0x1e04: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e08:
	/* 0x1e08: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e0b:
	/* 0x1e0b: jns    1e12 <trace_load_elf_phdrs+0x1e12> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e0b, 0x1e12, x86_l_1e12);
x86_l_1e0d:
	/* 0x1e0d: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e10:
	/* 0x1e10: jmp    1e14 <trace_load_elf_phdrs+0x1e14> */
	X86_SIM_X86_JMP(0x1e10, 0x1e14, x86_l_1e14);
x86_l_1e12:
	/* 0x1e12: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e14:
	/* 0x1e14: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e17:
	/* 0x1e17: je     1e94 <trace_load_elf_phdrs+0x1e94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e17, 0x1e94, x86_l_1e94);
x86_l_1e19:
	/* 0x1e19: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1e1c:
	/* 0x1e1c: je     1e94 <trace_load_elf_phdrs+0x1e94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e1c, 0x1e94, x86_l_1e94);
x86_l_1e1e:
	/* 0x1e1e: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e22:
	/* 0x1e22: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e25:
	/* 0x1e25: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1e2b:
	/* 0x1e2b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e2e:
	/* 0x1e2e: jns    1e37 <trace_load_elf_phdrs+0x1e37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e2e, 0x1e37, x86_l_1e37);
x86_l_1e30:
	/* 0x1e30: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e33:
	/* 0x1e33: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e37:
	/* 0x1e37: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e3b:
	/* 0x1e3b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e3e:
	/* 0x1e3e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e45:
	/* 0x1e45: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1e48:
	/* 0x1e48: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e4b:
	/* 0x1e4b: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e4b, 0x22d5, x86_l_22d5);
x86_l_1e51:
	/* 0x1e51: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1e54:
	/* 0x1e54: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e54, 0x227b, x86_l_227b);
x86_l_1e5a:
	/* 0x1e5a: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1e60:
	/* 0x1e60: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1e65:
	/* 0x1e65: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1e68:
	/* 0x1e68: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e68, 0x20c6, x86_l_20c6);
x86_l_1e6e:
	/* 0x1e6e: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e72:
	/* 0x1e72: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e75:
	/* 0x1e75: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1e78:
	/* 0x1e78: je     1ee9 <trace_load_elf_phdrs+0x1ee9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e78, 0x1ee9, x86_l_1ee9);
x86_l_1e7a:
	/* 0x1e7a: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e7e:
	/* 0x1e7e: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1e83:
	/* 0x1e83: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1e87:
	/* 0x1e87: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e8a:
	/* 0x1e8a: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1e8d:
	/* 0x1e8d: jne    1e75 <trace_load_elf_phdrs+0x1e75> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e8d, 0x1e75, x86_l_1e75);
x86_l_1e8f:
	/* 0x1e8f: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1e92:
	/* 0x1e92: jmp    1eee <trace_load_elf_phdrs+0x1eee> */
	X86_SIM_X86_JMP(0x1e92, 0x1eee, x86_l_1eee);
x86_l_1e94:
	/* 0x1e94: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e97:
	/* 0x1e97: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e97, 0x227b, x86_l_227b);
x86_l_1e9d:
	/* 0x1e9d: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1ea0:
	/* 0x1ea0: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea0, 0x227b, x86_l_227b);
x86_l_1ea6:
	/* 0x1ea6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eaa:
	/* 0x1eaa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ead:
	/* 0x1ead: jns    1eb4 <trace_load_elf_phdrs+0x1eb4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ead, 0x1eb4, x86_l_1eb4);
x86_l_1eaf:
	/* 0x1eaf: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb2:
	/* 0x1eb2: jmp    1eb6 <trace_load_elf_phdrs+0x1eb6> */
	X86_SIM_X86_JMP(0x1eb2, 0x1eb6, x86_l_1eb6);
x86_l_1eb4:
	/* 0x1eb4: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1eb6:
	/* 0x1eb6: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1eb9:
	/* 0x1eb9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ebc:
	/* 0x1ebc: jns    1ec6 <trace_load_elf_phdrs+0x1ec6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ebc, 0x1ec6, x86_l_1ec6);
x86_l_1ebe:
	/* 0x1ebe: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ec1:
	/* 0x1ec1: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ec4:
	/* 0x1ec4: jmp    1ec8 <trace_load_elf_phdrs+0x1ec8> */
	X86_SIM_X86_JMP(0x1ec4, 0x1ec8, x86_l_1ec8);
x86_l_1ec6:
	/* 0x1ec6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec8:
	/* 0x1ec8: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ecb:
	/* 0x1ecb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ece:
	/* 0x1ece: jns    1ed5 <trace_load_elf_phdrs+0x1ed5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ece, 0x1ed5, x86_l_1ed5);
x86_l_1ed0:
	/* 0x1ed0: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed3:
	/* 0x1ed3: jmp    1ed8 <trace_load_elf_phdrs+0x1ed8> */
	X86_SIM_X86_JMP(0x1ed3, 0x1ed8, x86_l_1ed8);
x86_l_1ed5:
	/* 0x1ed5: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ed8:
	/* 0x1ed8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1edc:
	/* 0x1edc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1edf:
	/* 0x1edf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ee2:
	/* 0x1ee2: jns    1f17 <trace_load_elf_phdrs+0x1f17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ee2, 0x1f17, x86_l_1f17);
x86_l_1ee4:
	/* 0x1ee4: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee7:
	/* 0x1ee7: jmp    1f19 <trace_load_elf_phdrs+0x1f19> */
	X86_SIM_X86_JMP(0x1ee7, 0x1f19, x86_l_1f19);
x86_l_1ee9:
	/* 0x1ee9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1eee:
	/* 0x1eee: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ef2:
	/* 0x1ef2: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ef2, 0x227b, x86_l_227b);
x86_l_1ef8:
	/* 0x1ef8: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1efd:
	/* 0x1efd: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f03:
	/* 0x1f03: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f08:
	/* 0x1f08: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1f0c:
	/* 0x1f0c: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f0f:
	/* 0x1f0f: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f12:
	/* 0x1f12: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f15:
	/* 0x1f15: js     1ee4 <trace_load_elf_phdrs+0x1ee4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f15, 0x1ee4, x86_l_1ee4);
x86_l_1f17:
	/* 0x1f17: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f19:
	/* 0x1f19: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f1d:
	/* 0x1f1d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f20:
	/* 0x1f20: jns    1f27 <trace_load_elf_phdrs+0x1f27> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f20, 0x1f27, x86_l_1f27);
x86_l_1f22:
	/* 0x1f22: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f25:
	/* 0x1f25: jmp    1f29 <trace_load_elf_phdrs+0x1f29> */
	X86_SIM_X86_JMP(0x1f25, 0x1f29, x86_l_1f29);
x86_l_1f27:
	/* 0x1f27: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f29:
	/* 0x1f29: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f2c:
	/* 0x1f2c: je     1fa9 <trace_load_elf_phdrs+0x1fa9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f2c, 0x1fa9, x86_l_1fa9);
x86_l_1f2e:
	/* 0x1f2e: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f31:
	/* 0x1f31: je     1fa9 <trace_load_elf_phdrs+0x1fa9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f31, 0x1fa9, x86_l_1fa9);
x86_l_1f33:
	/* 0x1f33: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f37:
	/* 0x1f37: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f3a:
	/* 0x1f3a: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f40:
	/* 0x1f40: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f43:
	/* 0x1f43: jns    1f4c <trace_load_elf_phdrs+0x1f4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f43, 0x1f4c, x86_l_1f4c);
x86_l_1f45:
	/* 0x1f45: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f48:
	/* 0x1f48: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f4c:
	/* 0x1f4c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f50:
	/* 0x1f50: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f53:
	/* 0x1f53: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f5a:
	/* 0x1f5a: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1f5d:
	/* 0x1f5d: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f60:
	/* 0x1f60: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f60, 0x22d5, x86_l_22d5);
x86_l_1f66:
	/* 0x1f66: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1f69:
	/* 0x1f69: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f69, 0x2278, x86_l_2278);
x86_l_1f6f:
	/* 0x1f6f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f75:
	/* 0x1f75: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_1f7a:
	/* 0x1f7a: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1f7d:
	/* 0x1f7d: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f7d, 0x20c9, x86_l_20c9);
x86_l_1f83:
	/* 0x1f83: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f87:
	/* 0x1f87: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8a:
	/* 0x1f8a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1f8d:
	/* 0x1f8d: je     1ffe <trace_load_elf_phdrs+0x1ffe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8d, 0x1ffe, x86_l_1ffe);
x86_l_1f8f:
	/* 0x1f8f: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f93:
	/* 0x1f93: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f98:
	/* 0x1f98: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f9c:
	/* 0x1f9c: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f9f:
	/* 0x1f9f: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_1fa2:
	/* 0x1fa2: jne    1f8a <trace_load_elf_phdrs+0x1f8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fa2, 0x1f8a, x86_l_1f8a);
x86_l_1fa4:
	/* 0x1fa4: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1fa7:
	/* 0x1fa7: jmp    2003 <trace_load_elf_phdrs+0x2003> */
	X86_SIM_X86_JMP(0x1fa7, 0x2003, x86_l_2003);
x86_l_1fa9:
	/* 0x1fa9: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fac:
	/* 0x1fac: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fac, 0x2278, x86_l_2278);
x86_l_1fb2:
	/* 0x1fb2: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1fb5:
	/* 0x1fb5: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb5, 0x2278, x86_l_2278);
x86_l_1fbb:
	/* 0x1fbb: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fbf:
	/* 0x1fbf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fc2:
	/* 0x1fc2: jns    1fc9 <trace_load_elf_phdrs+0x1fc9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc2, 0x1fc9, x86_l_1fc9);
x86_l_1fc4:
	/* 0x1fc4: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc7:
	/* 0x1fc7: jmp    1fcb <trace_load_elf_phdrs+0x1fcb> */
	X86_SIM_X86_JMP(0x1fc7, 0x1fcb, x86_l_1fcb);
x86_l_1fc9:
	/* 0x1fc9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fcb:
	/* 0x1fcb: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fce:
	/* 0x1fce: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fd1:
	/* 0x1fd1: jns    1fdb <trace_load_elf_phdrs+0x1fdb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd1, 0x1fdb, x86_l_1fdb);
x86_l_1fd3:
	/* 0x1fd3: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fd6:
	/* 0x1fd6: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fd9:
	/* 0x1fd9: jmp    1fdd <trace_load_elf_phdrs+0x1fdd> */
	X86_SIM_X86_JMP(0x1fd9, 0x1fdd, x86_l_1fdd);
x86_l_1fdb:
	/* 0x1fdb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fdd:
	/* 0x1fdd: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fe0:
	/* 0x1fe0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fe3:
	/* 0x1fe3: jns    1fea <trace_load_elf_phdrs+0x1fea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fe3, 0x1fea, x86_l_1fea);
x86_l_1fe5:
	/* 0x1fe5: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe8:
	/* 0x1fe8: jmp    1fed <trace_load_elf_phdrs+0x1fed> */
	X86_SIM_X86_JMP(0x1fe8, 0x1fed, x86_l_1fed);
x86_l_1fea:
	/* 0x1fea: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fed:
	/* 0x1fed: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ff1:
	/* 0x1ff1: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ff4:
	/* 0x1ff4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ff7:
	/* 0x1ff7: jns    202c <trace_load_elf_phdrs+0x202c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff7, 0x202c, x86_l_202c);
x86_l_1ff9:
	/* 0x1ff9: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ffc:
	/* 0x1ffc: jmp    202e <trace_load_elf_phdrs+0x202e> */
	X86_SIM_X86_JMP(0x1ffc, 0x202e, x86_l_202e);
x86_l_1ffe:
	/* 0x1ffe: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2003:
	/* 0x2003: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2007:
	/* 0x2007: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2007, 0x2278, x86_l_2278);
x86_l_200d:
	/* 0x200d: lea    edi,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2012:
	/* 0x2012: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2018:
	/* 0x2018: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_201d:
	/* 0x201d: mov    BYTE PTR [rcx+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2021:
	/* 0x2021: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2024:
	/* 0x2024: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2027:
	/* 0x2027: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_202a:
	/* 0x202a: js     1ff9 <trace_load_elf_phdrs+0x1ff9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x202a, 0x1ff9, x86_l_1ff9);
x86_l_202c:
	/* 0x202c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_202e:
	/* 0x202e: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2032:
	/* 0x2032: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2035:
	/* 0x2035: jns    203c <trace_load_elf_phdrs+0x203c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2035, 0x203c, x86_l_203c);
x86_l_2037:
	/* 0x2037: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203a:
	/* 0x203a: jmp    203e <trace_load_elf_phdrs+0x203e> */
	X86_SIM_X86_JMP(0x203a, 0x203e, x86_l_203e);
x86_l_203c:
	/* 0x203c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_203e:
	/* 0x203e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2041:
	/* 0x2041: je     20dd <trace_load_elf_phdrs+0x20dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2041, 0x20dd, x86_l_20dd);
x86_l_2047:
	/* 0x2047: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_204a:
	/* 0x204a: je     20dd <trace_load_elf_phdrs+0x20dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x204a, 0x20dd, x86_l_20dd);
x86_l_2050:
	/* 0x2050: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2054:
	/* 0x2054: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2057:
	/* 0x2057: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_205d:
	/* 0x205d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2060:
	/* 0x2060: jns    2069 <trace_load_elf_phdrs+0x2069> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2060, 0x2069, x86_l_2069);
x86_l_2062:
	/* 0x2062: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2065:
	/* 0x2065: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2069:
	/* 0x2069: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_206d:
	/* 0x206d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2070:
	/* 0x2070: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2077:
	/* 0x2077: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_207a:
	/* 0x207a: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_207d:
	/* 0x207d: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x207d, 0x22d5, x86_l_22d5);
x86_l_2083:
	/* 0x2083: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2086:
	/* 0x2086: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2086, 0x227b, x86_l_227b);
x86_l_208c:
	/* 0x208c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2092:
	/* 0x2092: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2097:
	/* 0x2097: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_209a:
	/* 0x209a: jns    20c6 <trace_load_elf_phdrs+0x20c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x209a, 0x20c6, x86_l_20c6);
x86_l_209c:
	/* 0x209c: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20a0:
	/* 0x20a0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20a3:
	/* 0x20a3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_20a6:
	/* 0x20a6: je     2132 <trace_load_elf_phdrs+0x2132> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a6, 0x2132, x86_l_2132);
x86_l_20ac:
	/* 0x20ac: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20b0:
	/* 0x20b0: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_20b5:
	/* 0x20b5: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_20b9:
	/* 0x20b9: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20bc:
	/* 0x20bc: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_20bf:
	/* 0x20bf: jne    20a3 <trace_load_elf_phdrs+0x20a3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20bf, 0x20a3, x86_l_20a3);
x86_l_20c1:
	/* 0x20c1: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20c4:
	/* 0x20c4: jmp    2137 <trace_load_elf_phdrs+0x2137> */
	X86_SIM_X86_JMP(0x20c4, 0x2137, x86_l_2137);
x86_l_20c6:
	/* 0x20c6: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_20c9:
	/* 0x20c9: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20ce:
	/* 0x20ce: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20d3:
	/* 0x20d3: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20d8:
	/* 0x20d8: jmp    1026 <trace_load_elf_phdrs+0x1026> */
	X86_SIM_X86_JMP(0x20d8, 0x1026, x86_l_1026);
x86_l_20dd:
	/* 0x20dd: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20e0:
	/* 0x20e0: jne    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20e0, 0x227b, x86_l_227b);
x86_l_20e6:
	/* 0x20e6: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_20e9:
	/* 0x20e9: je     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e9, 0x227b, x86_l_227b);
x86_l_20ef:
	/* 0x20ef: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20f3:
	/* 0x20f3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20f6:
	/* 0x20f6: jns    20fd <trace_load_elf_phdrs+0x20fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20f6, 0x20fd, x86_l_20fd);
x86_l_20f8:
	/* 0x20f8: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20fb:
	/* 0x20fb: jmp    20ff <trace_load_elf_phdrs+0x20ff> */
	X86_SIM_X86_JMP(0x20fb, 0x20ff, x86_l_20ff);
x86_l_20fd:
	/* 0x20fd: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20ff:
	/* 0x20ff: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2102:
	/* 0x2102: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2105:
	/* 0x2105: jns    210f <trace_load_elf_phdrs+0x210f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2105, 0x210f, x86_l_210f);
x86_l_2107:
	/* 0x2107: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_210a:
	/* 0x210a: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_210d:
	/* 0x210d: jmp    2111 <trace_load_elf_phdrs+0x2111> */
	X86_SIM_X86_JMP(0x210d, 0x2111, x86_l_2111);
x86_l_210f:
	/* 0x210f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2111:
	/* 0x2111: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2114:
	/* 0x2114: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2117:
	/* 0x2117: jns    211e <trace_load_elf_phdrs+0x211e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2117, 0x211e, x86_l_211e);
x86_l_2119:
	/* 0x2119: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_211c:
	/* 0x211c: jmp    2121 <trace_load_elf_phdrs+0x2121> */
	X86_SIM_X86_JMP(0x211c, 0x2121, x86_l_2121);
x86_l_211e:
	/* 0x211e: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2121:
	/* 0x2121: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2125:
	/* 0x2125: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2128:
	/* 0x2128: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_212b:
	/* 0x212b: jns    2160 <trace_load_elf_phdrs+0x2160> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x212b, 0x2160, x86_l_2160);
x86_l_212d:
	/* 0x212d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2130:
	/* 0x2130: jmp    2162 <trace_load_elf_phdrs+0x2162> */
	X86_SIM_X86_JMP(0x2130, 0x2162, x86_l_2162);
x86_l_2132:
	/* 0x2132: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2137:
	/* 0x2137: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_213b:
	/* 0x213b: jl     227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x213b, 0x227b, x86_l_227b);
x86_l_2141:
	/* 0x2141: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2146:
	/* 0x2146: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_214c:
	/* 0x214c: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2151:
	/* 0x2151: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2155:
	/* 0x2155: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2158:
	/* 0x2158: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_215b:
	/* 0x215b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_215e:
	/* 0x215e: js     212d <trace_load_elf_phdrs+0x212d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x215e, 0x212d, x86_l_212d);
x86_l_2160:
	/* 0x2160: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2162:
	/* 0x2162: lea    rdi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2166:
	/* 0x2166: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2169:
	/* 0x2169: jns    2170 <trace_load_elf_phdrs+0x2170> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2169, 0x2170, x86_l_2170);
x86_l_216b:
	/* 0x216b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216e:
	/* 0x216e: jmp    2173 <trace_load_elf_phdrs+0x2173> */
	X86_SIM_X86_JMP(0x216e, 0x2173, x86_l_2173);
x86_l_2170:
	/* 0x2170: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2173:
	/* 0x2173: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2176:
	/* 0x2176: je     21f2 <trace_load_elf_phdrs+0x21f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2176, 0x21f2, x86_l_21f2);
x86_l_2178:
	/* 0x2178: cmp    rbp,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_217b:
	/* 0x217b: je     21f2 <trace_load_elf_phdrs+0x21f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x217b, 0x21f2, x86_l_21f2);
x86_l_217d:
	/* 0x217d: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2181:
	/* 0x2181: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2184:
	/* 0x2184: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2189:
	/* 0x2189: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_218c:
	/* 0x218c: jns    2195 <trace_load_elf_phdrs+0x2195> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x218c, 0x2195, x86_l_2195);
x86_l_218e:
	/* 0x218e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2191:
	/* 0x2191: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2195:
	/* 0x2195: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2199:
	/* 0x2199: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_219c:
	/* 0x219c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_21a3:
	/* 0x21a3: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_21a6:
	/* 0x21a6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21a9:
	/* 0x21a9: jb     22d5 <trace_load_elf_phdrs+0x22d5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21a9, 0x22d5, x86_l_22d5);
x86_l_21af:
	/* 0x21af: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_21b2:
	/* 0x21b2: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b2, 0x2278, x86_l_2278);
x86_l_21b8:
	/* 0x21b8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_21be:
	/* 0x21be: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_21c3:
	/* 0x21c3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21c6:
	/* 0x21c6: jns    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21c6, 0x20c9, x86_l_20c9);
x86_l_21cc:
	/* 0x21cc: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21d0:
	/* 0x21d0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d3:
	/* 0x21d3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_21d6:
	/* 0x21d6: je     2241 <trace_load_elf_phdrs+0x2241> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21d6, 0x2241, x86_l_2241);
x86_l_21d8:
	/* 0x21d8: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_21dc:
	/* 0x21dc: movzx  r14d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_21e1:
	/* 0x21e1: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_21e5:
	/* 0x21e5: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21e8:
	/* 0x21e8: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_21eb:
	/* 0x21eb: jne    21d3 <trace_load_elf_phdrs+0x21d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21eb, 0x21d3, x86_l_21d3);
x86_l_21ed:
	/* 0x21ed: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21f0:
	/* 0x21f0: jmp    2246 <trace_load_elf_phdrs+0x2246> */
	X86_SIM_X86_JMP(0x21f0, 0x2246, x86_l_2246);
x86_l_21f2:
	/* 0x21f2: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21f5:
	/* 0x21f5: jne    2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21f5, 0x2278, x86_l_2278);
x86_l_21fb:
	/* 0x21fb: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_21fe:
	/* 0x21fe: je     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21fe, 0x2278, x86_l_2278);
x86_l_2200:
	/* 0x2200: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2204:
	/* 0x2204: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2207:
	/* 0x2207: jns    220e <trace_load_elf_phdrs+0x220e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2207, 0x220e, x86_l_220e);
x86_l_2209:
	/* 0x2209: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_220c:
	/* 0x220c: jmp    2211 <trace_load_elf_phdrs+0x2211> */
	X86_SIM_X86_JMP(0x220c, 0x2211, x86_l_2211);
x86_l_220e:
	/* 0x220e: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2211:
	/* 0x2211: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2214:
	/* 0x2214: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2217:
	/* 0x2217: jns    2221 <trace_load_elf_phdrs+0x2221> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2217, 0x2221, x86_l_2221);
x86_l_2219:
	/* 0x2219: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_221c:
	/* 0x221c: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_221f:
	/* 0x221f: jmp    2223 <trace_load_elf_phdrs+0x2223> */
	X86_SIM_X86_JMP(0x221f, 0x2223, x86_l_2223);
x86_l_2221:
	/* 0x2221: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2223:
	/* 0x2223: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2226:
	/* 0x2226: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2229:
	/* 0x2229: jns    2230 <trace_load_elf_phdrs+0x2230> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2229, 0x2230, x86_l_2230);
x86_l_222b:
	/* 0x222b: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222e:
	/* 0x222e: jmp    2233 <trace_load_elf_phdrs+0x2233> */
	X86_SIM_X86_JMP(0x222e, 0x2233, x86_l_2233);
x86_l_2230:
	/* 0x2230: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2233:
	/* 0x2233: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2237:
	/* 0x2237: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_223a:
	/* 0x223a: jns    2268 <trace_load_elf_phdrs+0x2268> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x223a, 0x2268, x86_l_2268);
x86_l_223c:
	/* 0x223c: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_223f:
	/* 0x223f: jmp    226a <trace_load_elf_phdrs+0x226a> */
	X86_SIM_X86_JMP(0x223f, 0x226a, x86_l_226a);
x86_l_2241:
	/* 0x2241: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2246:
	/* 0x2246: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_224a:
	/* 0x224a: jl     2278 <trace_load_elf_phdrs+0x2278> */
	X86_SIM_X86_JCC(X86_CC_L, 0x224a, 0x2278, x86_l_2278);
x86_l_224c:
	/* 0x224c: lea    edx,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2251:
	/* 0x2251: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2257:
	/* 0x2257: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_225c:
	/* 0x225c: mov    BYTE PTR [rcx+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2260:
	/* 0x2260: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2263:
	/* 0x2263: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2266:
	/* 0x2266: js     223c <trace_load_elf_phdrs+0x223c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2266, 0x223c, x86_l_223c);
x86_l_2268:
	/* 0x2268: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_226a:
	/* 0x226a: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_226e:
	/* 0x226e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2271:
	/* 0x2271: jns    228f <trace_load_elf_phdrs+0x228f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2271, 0x228f, x86_l_228f);
x86_l_2273:
	/* 0x2273: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2276:
	/* 0x2276: jmp    2291 <trace_load_elf_phdrs+0x2291> */
	X86_SIM_X86_JMP(0x2276, 0x2291, x86_l_2291);
x86_l_2278:
	/* 0x2278: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_227b:
	/* 0x227b: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2280:
	/* 0x2280: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2285:
	/* 0x2285: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_228a:
	/* 0x228a: jmp    1033 <trace_load_elf_phdrs+0x1033> */
	X86_SIM_X86_JMP(0x228a, 0x1033, x86_l_1033);
x86_l_228f:
	/* 0x228f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2291:
	/* 0x2291: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2294:
	/* 0x2294: je     34a6 <trace_load_elf_phdrs+0x34a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2294, 0x34a6, x86_l_34a6);
x86_l_229a:
	/* 0x229a: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_229d:
	/* 0x229d: je     34a6 <trace_load_elf_phdrs+0x34a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x229d, 0x34a6, x86_l_34a6);
x86_l_22a3:
	/* 0x22a3: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22a7:
	/* 0x22a7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22aa:
	/* 0x22aa: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_22af:
	/* 0x22af: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22b2:
	/* 0x22b2: jns    22bb <trace_load_elf_phdrs+0x22bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22b2, 0x22bb, x86_l_22bb);
x86_l_22b4:
	/* 0x22b4: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22b7:
	/* 0x22b7: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22bb:
	/* 0x22bb: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22bf:
	/* 0x22bf: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22c2:
	/* 0x22c2: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22c9:
	/* 0x22c9: mov    edi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_22cc:
	/* 0x22cc: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22cf:
	/* 0x22cf: jae    34c6 <trace_load_elf_phdrs+0x34c6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x22cf, 0x34c6, x86_l_34c6);
x86_l_22d5:
	/* 0x22d5: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22da:
	/* 0x22da: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22df:
	/* 0x22df: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22e4:
	/* 0x22e4: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e9:
	/* 0x22e9: dec    r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_22ec:
	/* 0x22ec: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_22ef:
	/* 0x22ef: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_22f4:
	/* 0x22f4: mov    BYTE PTR [r9+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_22f9:
	/* 0x22f9: mov    BYTE PTR [r9+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2301:
	/* 0x2301: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2306:
	/* 0x2306: and    r12d,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_230d:
	/* 0x230d: add    r9,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2310:
	/* 0x2310: mov    r12,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2318:
	/* 0x2318: lea    rax,[r14+0x118] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_231f:
	/* 0x231f: mov    rcx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2322:
	/* 0x2322: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2325:
	/* 0x2325: jns    2341 <trace_load_elf_phdrs+0x2341> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2325, 0x2341, x86_l_2341);
x86_l_2327:
	/* 0x2327: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2329:
	/* 0x2329: cmp    rdx,0x3f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 63ULL);
x86_l_232d:
	/* 0x232d: je     2382 <trace_load_elf_phdrs+0x2382> */
	X86_SIM_X86_JCC(X86_CC_E, 0x232d, 0x2382, x86_l_2382);
x86_l_232f:
	/* 0x232f: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_2333:
	/* 0x2333: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_2337:
	/* 0x2337: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_233a:
	/* 0x233a: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_233d:
	/* 0x233d: jne    2329 <trace_load_elf_phdrs+0x2329> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x233d, 0x2329, x86_l_2329);
x86_l_233f:
	/* 0x233f: jmp    238a <trace_load_elf_phdrs+0x238a> */
	X86_SIM_X86_JMP(0x233f, 0x238a, x86_l_238a);
x86_l_2341:
	/* 0x2341: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_2349:
	/* 0x2349: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2351:
	/* 0x2351: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2359:
	/* 0x2359: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2361:
	/* 0x2361: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2369:
	/* 0x2369: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2371:
	/* 0x2371: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2379:
	/* 0x2379: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2380:
	/* 0x2380: jmp    238a <trace_load_elf_phdrs+0x238a> */
	X86_SIM_X86_JMP(0x2380, 0x238a, x86_l_238a);
x86_l_2382:
	/* 0x2382: mov    BYTE PTR [r14+0x157],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1473173782528ULL);
x86_l_238a:
	/* 0x238a: add    r15,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_238e:
	/* 0x238e: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2391:
	/* 0x2391: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2394:
	/* 0x2394: jns    239b <trace_load_elf_phdrs+0x239b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2394, 0x239b, x86_l_239b);
x86_l_2396:
	/* 0x2396: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2399:
	/* 0x2399: jmp    239d <trace_load_elf_phdrs+0x239d> */
	X86_SIM_X86_JMP(0x2399, 0x239d, x86_l_239d);
x86_l_239b:
	/* 0x239b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_239d:
	/* 0x239d: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_23a1:
	/* 0x23a1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23a3:
	/* 0x23a3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23a6:
	/* 0x23a6: jns    23b2 <trace_load_elf_phdrs+0x23b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23a6, 0x23b2, x86_l_23b2);
x86_l_23a8:
	/* 0x23a8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ab:
	/* 0x23ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23ae:
	/* 0x23ae: js     23b9 <trace_load_elf_phdrs+0x23b9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23ae, 0x23b9, x86_l_23b9);
x86_l_23b0:
	/* 0x23b0: jmp    23bb <trace_load_elf_phdrs+0x23bb> */
	X86_SIM_X86_JMP(0x23b0, 0x23bb, x86_l_23bb);
x86_l_23b2:
	/* 0x23b2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b4:
	/* 0x23b4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23b7:
	/* 0x23b7: jns    23bb <trace_load_elf_phdrs+0x23bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23b7, 0x23bb, x86_l_23bb);
x86_l_23b9:
	/* 0x23b9: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23bb:
	/* 0x23bb: mov    DWORD PTR [r14+0x158],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_23c2:
	/* 0x23c2: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_23c5:
	/* 0x23c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23c8:
	/* 0x23c8: jns    23e8 <trace_load_elf_phdrs+0x23e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c8, 0x23e8, x86_l_23e8);
x86_l_23ca:
	/* 0x23ca: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23cd:
	/* 0x23cd: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_23d1:
	/* 0x23d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23d4:
	/* 0x23d4: js     23f3 <trace_load_elf_phdrs+0x23f3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23d4, 0x23f3, x86_l_23f3);
x86_l_23d6:
	/* 0x23d6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d8:
	/* 0x23d8: mov    QWORD PTR [r14+0x160],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_23df:
	/* 0x23df: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_23e2:
	/* 0x23e2: js     2402 <trace_load_elf_phdrs+0x2402> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23e2, 0x2402, x86_l_2402);
x86_l_23e4:
	/* 0x23e4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e6:
	/* 0x23e6: jmp    2405 <trace_load_elf_phdrs+0x2405> */
	X86_SIM_X86_JMP(0x23e6, 0x2405, x86_l_2405);
x86_l_23e8:
	/* 0x23e8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23ea:
	/* 0x23ea: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_23ee:
	/* 0x23ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23f1:
	/* 0x23f1: jns    23d6 <trace_load_elf_phdrs+0x23d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f1, 0x23d6, x86_l_23d6);
x86_l_23f3:
	/* 0x23f3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f6:
	/* 0x23f6: mov    QWORD PTR [r14+0x160],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 352ULL);
x86_l_23fd:
	/* 0x23fd: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2400:
	/* 0x2400: jns    23e4 <trace_load_elf_phdrs+0x23e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2400, 0x23e4, x86_l_23e4);
x86_l_2402:
	/* 0x2402: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2405:
	/* 0x2405: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_240e:
	/* 0x240e: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_2417:
	/* 0x2417: lea    rdx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_241b:
	/* 0x241b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_241d:
	/* 0x241d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2420:
	/* 0x2420: jns    2427 <trace_load_elf_phdrs+0x2427> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2420, 0x2427, x86_l_2427);
x86_l_2422:
	/* 0x2422: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2425:
	/* 0x2425: jmp    2429 <trace_load_elf_phdrs+0x2429> */
	X86_SIM_X86_JMP(0x2425, 0x2429, x86_l_2429);
x86_l_2427:
	/* 0x2427: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2429:
	/* 0x2429: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_242e:
	/* 0x242e: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2432:
	/* 0x2432: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2435:
	/* 0x2435: jns    2439 <trace_load_elf_phdrs+0x2439> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2435, 0x2439, x86_l_2439);
x86_l_2437:
	/* 0x2437: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2439:
	/* 0x2439: lea    rax,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_243d:
	/* 0x243d: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2445:
	/* 0x2445: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2447:
	/* 0x2447: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_244c:
	/* 0x244c: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2451:
	/* 0x2451: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2454:
	/* 0x2454: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2459:
	/* 0x2459: jns    2476 <trace_load_elf_phdrs+0x2476> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2459, 0x2476, x86_l_2476);
x86_l_245b:
	/* 0x245b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_245e:
	/* 0x245e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2461:
	/* 0x2461: js     2668 <trace_load_elf_phdrs+0x2668> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2461, 0x2668, x86_l_2668);
x86_l_2467:
	/* 0x2467: lea    rcx,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_246c:
	/* 0x246c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_246f:
	/* 0x246f: jns    2482 <trace_load_elf_phdrs+0x2482> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x246f, 0x2482, x86_l_2482);
x86_l_2471:
	/* 0x2471: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2474:
	/* 0x2474: jmp    2484 <trace_load_elf_phdrs+0x2484> */
	X86_SIM_X86_JMP(0x2474, 0x2484, x86_l_2484);
x86_l_2476:
	/* 0x2476: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2478:
	/* 0x2478: lea    rcx,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_247d:
	/* 0x247d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2480:
	/* 0x2480: js     2471 <trace_load_elf_phdrs+0x2471> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2480, 0x2471, x86_l_2471);
x86_l_2482:
	/* 0x2482: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2484:
	/* 0x2484: imul   rax,rax,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_248b:
	/* 0x248b: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_248e:
	/* 0x248e: mov    QWORD PTR [r14+0x168],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 360ULL);
x86_l_2495:
	/* 0x2495: lea    rdi,[rbx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2499:
	/* 0x2499: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_249e:
	/* 0x249e: call   24a3 <trace_load_elf_phdrs+0x24a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_24a3:
	/* 0x24a3: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24a7:
	/* 0x24a7: mov    rcx,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_24af:
	/* 0x24af: cmp    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_24b1:
	/* 0x24b1: jne    24cd <trace_load_elf_phdrs+0x24cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24b1, 0x24cd, x86_l_24cd);
x86_l_24b3:
	/* 0x24b3: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24b6:
	/* 0x24b6: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24bb:
	/* 0x24bb: and    QWORD PTR [r13+0x80],r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R13, X86_R12, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 128ULL);
x86_l_24c2:
	/* 0x24c2: jne    2d35 <trace_load_elf_phdrs+0x2d35> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24c2, 0x2d35, x86_l_2d35);
x86_l_24c8:
	/* 0x24c8: jmp    348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JMP(0x24c8, 0x348e, x86_l_348e);
x86_l_24cd:
	/* 0x24cd: mov    rax,QWORD PTR [r13+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_24d4:
	/* 0x24d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24d7:
	/* 0x24d7: je     266f <trace_load_elf_phdrs+0x266f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d7, 0x266f, x86_l_266f);
x86_l_24dd:
	/* 0x24dd: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_24e4:
	/* 0x24e4: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_24e7:
	/* 0x24e7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ea:
	/* 0x24ea: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_24ed:
	/* 0x24ed: sete   r12b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_24f1:
	/* 0x24f1: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_24f4:
	/* 0x24f4: neg    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_24f7:
	/* 0x24f7: xor    r12,QWORD PTR [r13+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_24fe:
	/* 0x24fe: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2501:
	/* 0x2501: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_2508:
	/* 0x2508: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_250b:
	/* 0x250b: je     252c <trace_load_elf_phdrs+0x252c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x250b, 0x252c, x86_l_252c);
x86_l_250d:
	/* 0x250d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_250f:
	/* 0x250f: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_2516:
	/* 0x2516: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2519:
	/* 0x2519: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_251c:
	/* 0x251c: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_251f:
	/* 0x251f: xor    rcx,QWORD PTR [r13+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_2526:
	/* 0x2526: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2529:
	/* 0x2529: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_252c:
	/* 0x252c: mov    rax,QWORD PTR [r13+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_2533:
	/* 0x2533: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2536:
	/* 0x2536: je     2552 <trace_load_elf_phdrs+0x2552> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2536, 0x2552, x86_l_2552);
x86_l_2538:
	/* 0x2538: mov    ecx,DWORD PTR [r13+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_253c:
	/* 0x253c: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_253f:
	/* 0x253f: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_2542:
	/* 0x2542: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_2545:
	/* 0x2545: xor    rcx,QWORD PTR [r13+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_254c:
	/* 0x254c: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_254f:
	/* 0x254f: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2552:
	/* 0x2552: mov    rax,QWORD PTR [r13+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_2559:
	/* 0x2559: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_255c:
	/* 0x255c: je     2575 <trace_load_elf_phdrs+0x2575> */
	X86_SIM_X86_JCC(X86_CC_E, 0x255c, 0x2575, x86_l_2575);
x86_l_255e:
	/* 0x255e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2561:
	/* 0x2561: movsx  rcx,BYTE PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2565:
	/* 0x2565: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_2568:
	/* 0x2568: xor    rcx,QWORD PTR [r13+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_256f:
	/* 0x256f: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2572:
	/* 0x2572: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2575:
	/* 0x2575: movzx  eax,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_257a:
	/* 0x257a: mov    rbx,QWORD PTR [r13+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_2581:
	/* 0x2581: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2584:
	/* 0x2584: mov    WORD PTR [rsp+0x38],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2589:
	/* 0x2589: je     26dc <trace_load_elf_phdrs+0x26dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2589, 0x26dc, x86_l_26dc);
x86_l_258f:
	/* 0x258f: mov    rcx,QWORD PTR [r13+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_2596:
	/* 0x2596: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_259e:
	/* 0x259e: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_25a1:
	/* 0x25a1: mov    r13,QWORD PTR [r13+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_25a8:
	/* 0x25a8: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_25af:
	/* 0x25af: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_25b7:
	/* 0x25b7: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_25bc:
	/* 0x25bc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_25c3:
	/* 0x25c3: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_25c8:
	/* 0x25c8: call   25cd <trace_load_elf_phdrs+0x25cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25cd:
	/* 0x25cd: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25d0:
	/* 0x25d0: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_25d4:
	/* 0x25d4: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_25d9:
	/* 0x25d9: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_25e0:
	/* 0x25e0: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_25e3:
	/* 0x25e3: je     2603 <trace_load_elf_phdrs+0x2603> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25e3, 0x2603, x86_l_2603);
x86_l_25e5:
	/* 0x25e5: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_25ea:
	/* 0x25ea: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_25ed:
	/* 0x25ed: call   25f2 <trace_load_elf_phdrs+0x25f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25f2:
	/* 0x25f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25f5:
	/* 0x25f5: je     2603 <trace_load_elf_phdrs+0x2603> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f5, 0x2603, x86_l_2603);
x86_l_25f7:
	/* 0x25f7: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25fa:
	/* 0x25fa: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25fe:
	/* 0x25fe: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2601:
	/* 0x2601: jmp    2606 <trace_load_elf_phdrs+0x2606> */
	X86_SIM_X86_JMP(0x2601, 0x2606, x86_l_2606);
x86_l_2603:
	/* 0x2603: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2606:
	/* 0x2606: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_260e:
	/* 0x260e: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2613:
	/* 0x2613: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_2616:
	/* 0x2616: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2619:
	/* 0x2619: jb     2631 <trace_load_elf_phdrs+0x2631> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2619, 0x2631, x86_l_2631);
x86_l_261b:
	/* 0x261b: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_261f:
	/* 0x261f: je     2626 <trace_load_elf_phdrs+0x2626> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261f, 0x2626, x86_l_2626);
x86_l_2621:
	/* 0x2621: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2624:
	/* 0x2624: jbe    2631 <trace_load_elf_phdrs+0x2631> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2624, 0x2631, x86_l_2631);
x86_l_2626:
	/* 0x2626: and    r14,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 184ULL);
x86_l_262e:
	/* 0x262e: or     r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2631:
	/* 0x2631: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2636:
	/* 0x2636: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2639:
	/* 0x2639: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_263e:
	/* 0x263e: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2645:
	/* 0x2645: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2648:
	/* 0x2648: je     268b <trace_load_elf_phdrs+0x268b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2648, 0x268b, x86_l_268b);
x86_l_264a:
	/* 0x264a: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_264f:
	/* 0x264f: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2652:
	/* 0x2652: call   2657 <trace_load_elf_phdrs+0x2657> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2657:
	/* 0x2657: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_265a:
	/* 0x265a: je     26b7 <trace_load_elf_phdrs+0x26b7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x265a, 0x26b7, x86_l_26b7);
x86_l_265c:
	/* 0x265c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_265f:
	/* 0x265f: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2663:
	/* 0x2663: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2666:
	/* 0x2666: jmp    26b9 <trace_load_elf_phdrs+0x26b9> */
	X86_SIM_X86_JMP(0x2666, 0x26b9, x86_l_26b9);
x86_l_2668:
	/* 0x2668: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_266a:
	/* 0x266a: jmp    248e <trace_load_elf_phdrs+0x248e> */
	X86_SIM_X86_JMP(0x266a, 0x248e, x86_l_248e);
x86_l_266f:
	/* 0x266f: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2676:
	/* 0x2676: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_267d:
	/* 0x267d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2680:
	/* 0x2680: jne    250d <trace_load_elf_phdrs+0x250d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2680, 0x250d, x86_l_250d);
x86_l_2686:
	/* 0x2686: jmp    252c <trace_load_elf_phdrs+0x252c> */
	X86_SIM_X86_JMP(0x2686, 0x252c, x86_l_252c);
x86_l_268b:
	/* 0x268b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268d:
	/* 0x268d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2690:
	/* 0x2690: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2695:
	/* 0x2695: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2698:
	/* 0x2698: jb     26ce <trace_load_elf_phdrs+0x26ce> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2698, 0x26ce, x86_l_26ce);
x86_l_269a:
	/* 0x269a: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_269e:
	/* 0x269e: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26a3:
	/* 0x26a3: je     26aa <trace_load_elf_phdrs+0x26aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a3, 0x26aa, x86_l_26aa);
x86_l_26a5:
	/* 0x26a5: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26a8:
	/* 0x26a8: jbe    26d3 <trace_load_elf_phdrs+0x26d3> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x26a8, 0x26d3, x86_l_26d3);
x86_l_26aa:
	/* 0x26aa: and    r14,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 184ULL);
x86_l_26b2:
	/* 0x26b2: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_26b5:
	/* 0x26b5: jmp    26d3 <trace_load_elf_phdrs+0x26d3> */
	X86_SIM_X86_JMP(0x26b5, 0x26d3, x86_l_26d3);
x86_l_26b7:
	/* 0x26b7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b9:
	/* 0x26b9: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_26c1:
	/* 0x26c1: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_26c4:
	/* 0x26c4: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_26c9:
	/* 0x26c9: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26cc:
	/* 0x26cc: jae    269a <trace_load_elf_phdrs+0x269a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x26cc, 0x269a, x86_l_269a);
x86_l_26ce:
	/* 0x26ce: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26d3:
	/* 0x26d3: or     r15,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_26d6:
	/* 0x26d6: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_26d9:
	/* 0x26d9: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_26dc:
	/* 0x26dc: cmp    QWORD PTR [r13+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_26e4:
	/* 0x26e4: je     2781 <trace_load_elf_phdrs+0x2781> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e4, 0x2781, x86_l_2781);
x86_l_26ea:
	/* 0x26ea: call   26ef <trace_load_elf_phdrs+0x26ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_26ef:
	/* 0x26ef: mov    DWORD PTR [r13+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_26f3:
	/* 0x26f3: mov    rbx,QWORD PTR [r13+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_26fa:
	/* 0x26fa: mov    rax,QWORD PTR [r13+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_2701:
	/* 0x2701: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2709:
	/* 0x2709: mov    rbp,QWORD PTR [r13+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_2710:
	/* 0x2710: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2713:
	/* 0x2713: mov    r13,QWORD PTR [r13+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_271a:
	/* 0x271a: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_271f:
	/* 0x271f: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2724:
	/* 0x2724: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_272b:
	/* 0x272b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2730:
	/* 0x2730: call   2735 <trace_load_elf_phdrs+0x2735> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2735:
	/* 0x2735: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2739:
	/* 0x2739: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_273e:
	/* 0x273e: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2745:
	/* 0x2745: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2748:
	/* 0x2748: je     2768 <trace_load_elf_phdrs+0x2768> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2748, 0x2768, x86_l_2768);
x86_l_274a:
	/* 0x274a: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_274f:
	/* 0x274f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2752:
	/* 0x2752: call   2757 <trace_load_elf_phdrs+0x2757> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2757:
	/* 0x2757: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_275a:
	/* 0x275a: je     2768 <trace_load_elf_phdrs+0x2768> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275a, 0x2768, x86_l_2768);
x86_l_275c:
	/* 0x275c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_275f:
	/* 0x275f: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2763:
	/* 0x2763: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2766:
	/* 0x2766: jmp    276a <trace_load_elf_phdrs+0x276a> */
	X86_SIM_X86_JMP(0x2766, 0x276a, x86_l_276a);
x86_l_2768:
	/* 0x2768: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_276a:
	/* 0x276a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_276d:
	/* 0x276d: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2772:
	/* 0x2772: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_2775:
	/* 0x2775: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2778:
	/* 0x2778: jae    2795 <trace_load_elf_phdrs+0x2795> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2778, 0x2795, x86_l_2795);
x86_l_277a:
	/* 0x277a: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_277f:
	/* 0x277f: jmp    27b0 <trace_load_elf_phdrs+0x27b0> */
	X86_SIM_X86_JMP(0x277f, 0x27b0, x86_l_27b0);
x86_l_2781:
	/* 0x2781: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2786:
	/* 0x2786: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_278e:
	/* 0x278e: jne    27c9 <trace_load_elf_phdrs+0x27c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x278e, 0x27c9, x86_l_27c9);
x86_l_2790:
	/* 0x2790: jmp    2866 <trace_load_elf_phdrs+0x2866> */
	X86_SIM_X86_JMP(0x2790, 0x2866, x86_l_2866);
x86_l_2795:
	/* 0x2795: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2799:
	/* 0x2799: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_279e:
	/* 0x279e: je     27a5 <trace_load_elf_phdrs+0x27a5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x279e, 0x27a5, x86_l_27a5);
x86_l_27a0:
	/* 0x27a0: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_27a3:
	/* 0x27a3: jbe    27b0 <trace_load_elf_phdrs+0x27b0> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x27a3, 0x27b0, x86_l_27b0);
x86_l_27a5:
	/* 0x27a5: and    r15,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 152ULL);
x86_l_27ad:
	/* 0x27ad: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_27b0:
	/* 0x27b0: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_27b3:
	/* 0x27b3: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_27b6:
	/* 0x27b6: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27bb:
	/* 0x27bb: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_27c3:
	/* 0x27c3: je     2866 <trace_load_elf_phdrs+0x2866> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c3, 0x2866, x86_l_2866);
x86_l_27c9:
	/* 0x27c9: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_27ce:
	/* 0x27ce: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_27d5:
	/* 0x27d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27d8:
	/* 0x27d8: jns    27df <trace_load_elf_phdrs+0x27df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27d8, 0x27df, x86_l_27df);
x86_l_27da:
	/* 0x27da: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27dd:
	/* 0x27dd: jmp    27e1 <trace_load_elf_phdrs+0x27e1> */
	X86_SIM_X86_JMP(0x27dd, 0x27e1, x86_l_27e1);
x86_l_27df:
	/* 0x27df: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27e1:
	/* 0x27e1: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_27e5:
	/* 0x27e5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27e7:
	/* 0x27e7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27ea:
	/* 0x27ea: jns    27f6 <trace_load_elf_phdrs+0x27f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ea, 0x27f6, x86_l_27f6);
x86_l_27ec:
	/* 0x27ec: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ef:
	/* 0x27ef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27f2:
	/* 0x27f2: js     27fd <trace_load_elf_phdrs+0x27fd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27f2, 0x27fd, x86_l_27fd);
x86_l_27f4:
	/* 0x27f4: jmp    27ff <trace_load_elf_phdrs+0x27ff> */
	X86_SIM_X86_JMP(0x27f4, 0x27ff, x86_l_27ff);
x86_l_27f6:
	/* 0x27f6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27f8:
	/* 0x27f8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27fb:
	/* 0x27fb: jns    27ff <trace_load_elf_phdrs+0x27ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27fb, 0x27ff, x86_l_27ff);
x86_l_27fd:
	/* 0x27fd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ff:
	/* 0x27ff: mov    DWORD PTR [r13+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2803:
	/* 0x2803: mov    rbx,QWORD PTR [r13+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_280a:
	/* 0x280a: mov    r15,QWORD PTR [r13+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_2811:
	/* 0x2811: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2814:
	/* 0x2814: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2819:
	/* 0x2819: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_281e:
	/* 0x281e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_2825:
	/* 0x2825: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_282a:
	/* 0x282a: call   282f <trace_load_elf_phdrs+0x282f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_282f:
	/* 0x282f: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2836:
	/* 0x2836: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2839:
	/* 0x2839: je     2858 <trace_load_elf_phdrs+0x2858> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2839, 0x2858, x86_l_2858);
x86_l_283b:
	/* 0x283b: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_283f:
	/* 0x283f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2842:
	/* 0x2842: call   2847 <trace_load_elf_phdrs+0x2847> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2847:
	/* 0x2847: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_284a:
	/* 0x284a: je     2858 <trace_load_elf_phdrs+0x2858> */
	X86_SIM_X86_JCC(X86_CC_E, 0x284a, 0x2858, x86_l_2858);
x86_l_284c:
	/* 0x284c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284f:
	/* 0x284f: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2853:
	/* 0x2853: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2856:
	/* 0x2856: jmp    285a <trace_load_elf_phdrs+0x285a> */
	X86_SIM_X86_JMP(0x2856, 0x285a, x86_l_285a);
x86_l_2858:
	/* 0x2858: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_285a:
	/* 0x285a: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_285d:
	/* 0x285d: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2860:
	/* 0x2860: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2863:
	/* 0x2863: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2866:
	/* 0x2866: cmp    QWORD PTR [r13+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_286e:
	/* 0x286e: je     2935 <trace_load_elf_phdrs+0x2935> */
	X86_SIM_X86_JCC(X86_CC_E, 0x286e, 0x2935, x86_l_2935);
x86_l_2874:
	/* 0x2874: mov    rcx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_287b:
	/* 0x287b: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_287f:
	/* 0x287f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2881:
	/* 0x2881: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2884:
	/* 0x2884: jns    2893 <trace_load_elf_phdrs+0x2893> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2884, 0x2893, x86_l_2893);
x86_l_2886:
	/* 0x2886: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2889:
	/* 0x2889: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_288c:
	/* 0x288c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_288f:
	/* 0x288f: js     289d <trace_load_elf_phdrs+0x289d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x288f, 0x289d, x86_l_289d);
x86_l_2891:
	/* 0x2891: jmp    289f <trace_load_elf_phdrs+0x289f> */
	X86_SIM_X86_JMP(0x2891, 0x289f, x86_l_289f);
x86_l_2893:
	/* 0x2893: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2895:
	/* 0x2895: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2898:
	/* 0x2898: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_289b:
	/* 0x289b: jns    289f <trace_load_elf_phdrs+0x289f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x289b, 0x289f, x86_l_289f);
x86_l_289d:
	/* 0x289d: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_289f:
	/* 0x289f: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28a1:
	/* 0x28a1: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_28a5:
	/* 0x28a5: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28a8:
	/* 0x28a8: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_28ac:
	/* 0x28ac: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ae:
	/* 0x28ae: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28b1:
	/* 0x28b1: jns    28c1 <trace_load_elf_phdrs+0x28c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b1, 0x28c1, x86_l_28c1);
x86_l_28b3:
	/* 0x28b3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b6:
	/* 0x28b6: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_28ba:
	/* 0x28ba: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28bd:
	/* 0x28bd: js     28cc <trace_load_elf_phdrs+0x28cc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28bd, 0x28cc, x86_l_28cc);
x86_l_28bf:
	/* 0x28bf: jmp    28ce <trace_load_elf_phdrs+0x28ce> */
	X86_SIM_X86_JMP(0x28bf, 0x28ce, x86_l_28ce);
x86_l_28c1:
	/* 0x28c1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c3:
	/* 0x28c3: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_28c7:
	/* 0x28c7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28ca:
	/* 0x28ca: jns    28ce <trace_load_elf_phdrs+0x28ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ca, 0x28ce, x86_l_28ce);
x86_l_28cc:
	/* 0x28cc: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ce:
	/* 0x28ce: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_28d2:
	/* 0x28d2: mov    rbx,QWORD PTR [r13+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_28d9:
	/* 0x28d9: mov    r15,QWORD PTR [r13+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_28e0:
	/* 0x28e0: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_28e3:
	/* 0x28e3: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_28e8:
	/* 0x28e8: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_28ed:
	/* 0x28ed: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_28f4:
	/* 0x28f4: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_28f9:
	/* 0x28f9: call   28fe <trace_load_elf_phdrs+0x28fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_28fe:
	/* 0x28fe: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2905:
	/* 0x2905: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2908:
	/* 0x2908: je     2927 <trace_load_elf_phdrs+0x2927> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2908, 0x2927, x86_l_2927);
x86_l_290a:
	/* 0x290a: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_290e:
	/* 0x290e: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2911:
	/* 0x2911: call   2916 <trace_load_elf_phdrs+0x2916> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2916:
	/* 0x2916: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2919:
	/* 0x2919: je     2927 <trace_load_elf_phdrs+0x2927> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2919, 0x2927, x86_l_2927);
x86_l_291b:
	/* 0x291b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_291e:
	/* 0x291e: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2922:
	/* 0x2922: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2925:
	/* 0x2925: jmp    2929 <trace_load_elf_phdrs+0x2929> */
	X86_SIM_X86_JMP(0x2925, 0x2929, x86_l_2929);
x86_l_2927:
	/* 0x2927: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2929:
	/* 0x2929: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_292c:
	/* 0x292c: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_292f:
	/* 0x292f: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2932:
	/* 0x2932: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2935:
	/* 0x2935: cmp    QWORD PTR [r13+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_293d:
	/* 0x293d: je     2b1f <trace_load_elf_phdrs+0x2b1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x293d, 0x2b1f, x86_l_2b1f);
x86_l_2943:
	/* 0x2943: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_2948:
	/* 0x2948: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_294f:
	/* 0x294f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2952:
	/* 0x2952: jns    2965 <trace_load_elf_phdrs+0x2965> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2952, 0x2965, x86_l_2965);
x86_l_2954:
	/* 0x2954: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2957:
	/* 0x2957: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_295a:
	/* 0x295a: js     296c <trace_load_elf_phdrs+0x296c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x295a, 0x296c, x86_l_296c);
x86_l_295c:
	/* 0x295c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_295e:
	/* 0x295e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2961:
	/* 0x2961: js     2974 <trace_load_elf_phdrs+0x2974> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2961, 0x2974, x86_l_2974);
x86_l_2963:
	/* 0x2963: jmp    29c5 <trace_load_elf_phdrs+0x29c5> */
	X86_SIM_X86_JMP(0x2963, 0x29c5, x86_l_29c5);
x86_l_2965:
	/* 0x2965: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2967:
	/* 0x2967: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_296a:
	/* 0x296a: jns    295c <trace_load_elf_phdrs+0x295c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296a, 0x295c, x86_l_295c);
x86_l_296c:
	/* 0x296c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_296f:
	/* 0x296f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2972:
	/* 0x2972: jns    29c5 <trace_load_elf_phdrs+0x29c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2972, 0x29c5, x86_l_29c5);
x86_l_2974:
	/* 0x2974: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2977:
	/* 0x2977: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_297c:
	/* 0x297c: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2980:
	/* 0x2980: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2985:
	/* 0x2985: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2989:
	/* 0x2989: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_298e:
	/* 0x298e: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2992:
	/* 0x2992: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2997:
	/* 0x2997: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_299b:
	/* 0x299b: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_29a0:
	/* 0x29a0: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_29a4:
	/* 0x29a4: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_29a9:
	/* 0x29a9: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29ad:
	/* 0x29ad: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_29b5:
	/* 0x29b5: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29b9:
	/* 0x29b9: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_29c1:
	/* 0x29c1: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_29c5:
	/* 0x29c5: add    rbp,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_29c9:
	/* 0x29c9: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_29ce:
	/* 0x29ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29d1:
	/* 0x29d1: jns    2aa8 <trace_load_elf_phdrs+0x2aa8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d1, 0x2aa8, x86_l_2aa8);
x86_l_29d7:
	/* 0x29d7: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_29da:
	/* 0x29da: mov    BYTE PTR [rbp+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29dd:
	/* 0x29dd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_29df:
	/* 0x29df: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29df, 0x2ab8, x86_l_2ab8);
x86_l_29e5:
	/* 0x29e5: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_29e9:
	/* 0x29e9: mov    BYTE PTR [r13+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_29ed:
	/* 0x29ed: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_29ef:
	/* 0x29ef: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29ef, 0x2ab8, x86_l_2ab8);
x86_l_29f5:
	/* 0x29f5: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_29f9:
	/* 0x29f9: mov    BYTE PTR [r13+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_29fd:
	/* 0x29fd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_29ff:
	/* 0x29ff: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29ff, 0x2ab8, x86_l_2ab8);
x86_l_2a05:
	/* 0x2a05: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2a09:
	/* 0x2a09: mov    BYTE PTR [r13+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2a0d:
	/* 0x2a0d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a0f:
	/* 0x2a0f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a0f, 0x2ab8, x86_l_2ab8);
x86_l_2a15:
	/* 0x2a15: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2a19:
	/* 0x2a19: mov    BYTE PTR [r13+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2a1d:
	/* 0x2a1d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a1f:
	/* 0x2a1f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a1f, 0x2ab8, x86_l_2ab8);
x86_l_2a25:
	/* 0x2a25: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2a29:
	/* 0x2a29: mov    BYTE PTR [r13+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2a2d:
	/* 0x2a2d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a2f:
	/* 0x2a2f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a2f, 0x2ab8, x86_l_2ab8);
x86_l_2a35:
	/* 0x2a35: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2a39:
	/* 0x2a39: mov    BYTE PTR [r13+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2a3d:
	/* 0x2a3d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a3f:
	/* 0x2a3f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a3f, 0x2ab8, x86_l_2ab8);
x86_l_2a41:
	/* 0x2a41: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2a45:
	/* 0x2a45: mov    BYTE PTR [r13+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_2a49:
	/* 0x2a49: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a4b:
	/* 0x2a4b: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a4b, 0x2ab8, x86_l_2ab8);
x86_l_2a4d:
	/* 0x2a4d: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2a51:
	/* 0x2a51: mov    BYTE PTR [r13+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_2a55:
	/* 0x2a55: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a57:
	/* 0x2a57: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a57, 0x2ab8, x86_l_2ab8);
x86_l_2a59:
	/* 0x2a59: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2a5d:
	/* 0x2a5d: mov    BYTE PTR [r13+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_2a61:
	/* 0x2a61: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a63:
	/* 0x2a63: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a63, 0x2ab8, x86_l_2ab8);
x86_l_2a65:
	/* 0x2a65: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2a69:
	/* 0x2a69: mov    BYTE PTR [r13+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_2a6d:
	/* 0x2a6d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a6f:
	/* 0x2a6f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6f, 0x2ab8, x86_l_2ab8);
x86_l_2a71:
	/* 0x2a71: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2a75:
	/* 0x2a75: mov    BYTE PTR [r13+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_2a79:
	/* 0x2a79: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a7b:
	/* 0x2a7b: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a7b, 0x2ab8, x86_l_2ab8);
x86_l_2a7d:
	/* 0x2a7d: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2a81:
	/* 0x2a81: mov    BYTE PTR [r13+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2a85:
	/* 0x2a85: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a87:
	/* 0x2a87: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a87, 0x2ab8, x86_l_2ab8);
x86_l_2a89:
	/* 0x2a89: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2a8d:
	/* 0x2a8d: mov    BYTE PTR [r13+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_2a91:
	/* 0x2a91: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2a93:
	/* 0x2a93: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a93, 0x2ab8, x86_l_2ab8);
x86_l_2a95:
	/* 0x2a95: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2a99:
	/* 0x2a99: mov    BYTE PTR [r13+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_2a9d:
	/* 0x2a9d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2a9f:
	/* 0x2a9f: je     2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a9f, 0x2ab8, x86_l_2ab8);
x86_l_2aa1:
	/* 0x2aa1: mov    BYTE PTR [r13+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_2aa6:
	/* 0x2aa6: jmp    2ab8 <trace_load_elf_phdrs+0x2ab8> */
	X86_SIM_X86_JMP(0x2aa6, 0x2ab8, x86_l_2ab8);
x86_l_2aa8:
	/* 0x2aa8: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2ab0:
	/* 0x2ab0: mov    QWORD PTR [rbp+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab8:
	/* 0x2ab8: mov    rbx,QWORD PTR [r13+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_2abf:
	/* 0x2abf: mov    r15,QWORD PTR [r13+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_2ac6:
	/* 0x2ac6: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2ac9:
	/* 0x2ac9: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2ace:
	/* 0x2ace: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ad3:
	/* 0x2ad3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_2ada:
	/* 0x2ada: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2adf:
	/* 0x2adf: call   2ae4 <trace_load_elf_phdrs+0x2ae4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ae4:
	/* 0x2ae4: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2aeb:
	/* 0x2aeb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aee:
	/* 0x2aee: je     2b0c <trace_load_elf_phdrs+0x2b0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aee, 0x2b0c, x86_l_2b0c);
x86_l_2af0:
	/* 0x2af0: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af3:
	/* 0x2af3: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2af6:
	/* 0x2af6: call   2afb <trace_load_elf_phdrs+0x2afb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2afb:
	/* 0x2afb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2afe:
	/* 0x2afe: je     2b0c <trace_load_elf_phdrs+0x2b0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2afe, 0x2b0c, x86_l_2b0c);
x86_l_2b00:
	/* 0x2b00: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b03:
	/* 0x2b03: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b07:
	/* 0x2b07: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2b0a:
	/* 0x2b0a: jmp    2b0e <trace_load_elf_phdrs+0x2b0e> */
	X86_SIM_X86_JMP(0x2b0a, 0x2b0e, x86_l_2b0e);
x86_l_2b0c:
	/* 0x2b0c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b0e:
	/* 0x2b0e: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b13:
	/* 0x2b13: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2b16:
	/* 0x2b16: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2b19:
	/* 0x2b19: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2b1c:
	/* 0x2b1c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2b1f:
	/* 0x2b1f: cmp    QWORD PTR [r13+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_2b27:
	/* 0x2b27: je     2ba1 <trace_load_elf_phdrs+0x2ba1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b27, 0x2ba1, x86_l_2ba1);
x86_l_2b29:
	/* 0x2b29: add    rbp,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 60ULL);
x86_l_2b2d:
	/* 0x2b2d: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2b30:
	/* 0x2b30: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2b35:
	/* 0x2b35: call   2b3a <trace_load_elf_phdrs+0x2b3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_2b3a:
	/* 0x2b3a: mov    rbx,QWORD PTR [r13+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_2b41:
	/* 0x2b41: mov    r15,QWORD PTR [r13+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_2b48:
	/* 0x2b48: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2b4b:
	/* 0x2b4b: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2b50:
	/* 0x2b50: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b55:
	/* 0x2b55: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_2b5c:
	/* 0x2b5c: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b61:
	/* 0x2b61: call   2b66 <trace_load_elf_phdrs+0x2b66> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b66:
	/* 0x2b66: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2b6d:
	/* 0x2b6d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b70:
	/* 0x2b70: je     2b8e <trace_load_elf_phdrs+0x2b8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b70, 0x2b8e, x86_l_2b8e);
x86_l_2b72:
	/* 0x2b72: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b75:
	/* 0x2b75: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2b78:
	/* 0x2b78: call   2b7d <trace_load_elf_phdrs+0x2b7d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b7d:
	/* 0x2b7d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b80:
	/* 0x2b80: je     2b8e <trace_load_elf_phdrs+0x2b8e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b80, 0x2b8e, x86_l_2b8e);
x86_l_2b82:
	/* 0x2b82: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b85:
	/* 0x2b85: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b89:
	/* 0x2b89: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2b8c:
	/* 0x2b8c: jmp    2b90 <trace_load_elf_phdrs+0x2b90> */
	X86_SIM_X86_JMP(0x2b8c, 0x2b90, x86_l_2b90);
x86_l_2b8e:
	/* 0x2b8e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b90:
	/* 0x2b90: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b95:
	/* 0x2b95: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2b98:
	/* 0x2b98: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2b9b:
	/* 0x2b9b: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2b9e:
	/* 0x2b9e: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2ba1:
	/* 0x2ba1: mov    rbx,QWORD PTR [r13+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_2ba8:
	/* 0x2ba8: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2bab:
	/* 0x2bab: je     2c12 <trace_load_elf_phdrs+0x2c12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bab, 0x2c12, x86_l_2c12);
x86_l_2bad:
	/* 0x2bad: mov    eax,DWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bb1:
	/* 0x2bb1: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2bb5:
	/* 0x2bb5: mov    r15,QWORD PTR [r13+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_2bbc:
	/* 0x2bbc: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2bbf:
	/* 0x2bbf: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2bc4:
	/* 0x2bc4: mov    WORD PTR [rsp+0x34],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2bc9:
	/* 0x2bc9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_2bd0:
	/* 0x2bd0: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2bd5:
	/* 0x2bd5: call   2bda <trace_load_elf_phdrs+0x2bda> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2bda:
	/* 0x2bda: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2be1:
	/* 0x2be1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2be4:
	/* 0x2be4: je     2c04 <trace_load_elf_phdrs+0x2c04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2be4, 0x2c04, x86_l_2c04);
x86_l_2be6:
	/* 0x2be6: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2beb:
	/* 0x2beb: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bee:
	/* 0x2bee: call   2bf3 <trace_load_elf_phdrs+0x2bf3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2bf3:
	/* 0x2bf3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bf6:
	/* 0x2bf6: je     2c04 <trace_load_elf_phdrs+0x2c04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bf6, 0x2c04, x86_l_2c04);
x86_l_2bf8:
	/* 0x2bf8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bfb:
	/* 0x2bfb: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bff:
	/* 0x2bff: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2c02:
	/* 0x2c02: jmp    2c06 <trace_load_elf_phdrs+0x2c06> */
	X86_SIM_X86_JMP(0x2c02, 0x2c06, x86_l_2c06);
x86_l_2c04:
	/* 0x2c04: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c06:
	/* 0x2c06: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2c09:
	/* 0x2c09: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2c0c:
	/* 0x2c0c: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2c0f:
	/* 0x2c0f: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2c12:
	/* 0x2c12: mov    rbx,QWORD PTR [r13+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_2c19:
	/* 0x2c19: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c1c:
	/* 0x2c1c: je     2c7e <trace_load_elf_phdrs+0x2c7e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c1c, 0x2c7e, x86_l_2c7e);
x86_l_2c1e:
	/* 0x2c1e: mov    r15,QWORD PTR [r13+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_2c25:
	/* 0x2c25: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2c28:
	/* 0x2c28: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2c2d:
	/* 0x2c2d: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2c32:
	/* 0x2c32: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_2c39:
	/* 0x2c39: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2c3e:
	/* 0x2c3e: call   2c43 <trace_load_elf_phdrs+0x2c43> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c43:
	/* 0x2c43: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2c4a:
	/* 0x2c4a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c4d:
	/* 0x2c4d: je     2c70 <trace_load_elf_phdrs+0x2c70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c4d, 0x2c70, x86_l_2c70);
x86_l_2c4f:
	/* 0x2c4f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c52:
	/* 0x2c52: mov    rsi,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2c5a:
	/* 0x2c5a: call   2c5f <trace_load_elf_phdrs+0x2c5f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c5f:
	/* 0x2c5f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c62:
	/* 0x2c62: je     2c70 <trace_load_elf_phdrs+0x2c70> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c62, 0x2c70, x86_l_2c70);
x86_l_2c64:
	/* 0x2c64: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c67:
	/* 0x2c67: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c6b:
	/* 0x2c6b: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2c6e:
	/* 0x2c6e: jmp    2c72 <trace_load_elf_phdrs+0x2c72> */
	X86_SIM_X86_JMP(0x2c6e, 0x2c72, x86_l_2c72);
x86_l_2c70:
	/* 0x2c70: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c72:
	/* 0x2c72: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2c75:
	/* 0x2c75: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2c78:
	/* 0x2c78: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2c7b:
	/* 0x2c7b: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2c7e:
	/* 0x2c7e: mov    rbx,QWORD PTR [r13+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_2c85:
	/* 0x2c85: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c88:
	/* 0x2c88: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c8d:
	/* 0x2c8d: je     2d09 <trace_load_elf_phdrs+0x2d09> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c8d, 0x2d09, x86_l_2d09);
x86_l_2c8f:
	/* 0x2c8f: mov    r13,QWORD PTR [r13+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_2c96:
	/* 0x2c96: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2c99:
	/* 0x2c99: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_2c9e:
	/* 0x2c9e: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ca3:
	/* 0x2ca3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_2caa:
	/* 0x2caa: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2caf:
	/* 0x2caf: call   2cb4 <trace_load_elf_phdrs+0x2cb4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2cb4:
	/* 0x2cb4: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2cbb:
	/* 0x2cbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cbe:
	/* 0x2cbe: je     2cf1 <trace_load_elf_phdrs+0x2cf1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cbe, 0x2cf1, x86_l_2cf1);
x86_l_2cc0:
	/* 0x2cc0: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cc3:
	/* 0x2cc3: lea    rsi,[r14+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2cc7:
	/* 0x2cc7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cca:
	/* 0x2cca: call   2ccf <trace_load_elf_phdrs+0x2ccf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ccf:
	/* 0x2ccf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cd2:
	/* 0x2cd2: jne    2ce5 <trace_load_elf_phdrs+0x2ce5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cd2, 0x2ce5, x86_l_2ce5);
x86_l_2cd4:
	/* 0x2cd4: lea    rsi,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2cd8:
	/* 0x2cd8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2cdb:
	/* 0x2cdb: call   2ce0 <trace_load_elf_phdrs+0x2ce0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ce0:
	/* 0x2ce0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ce3:
	/* 0x2ce3: je     2cf1 <trace_load_elf_phdrs+0x2cf1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ce3, 0x2cf1, x86_l_2cf1);
x86_l_2ce5:
	/* 0x2ce5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ce8:
	/* 0x2ce8: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cec:
	/* 0x2cec: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2cef:
	/* 0x2cef: jmp    2cf3 <trace_load_elf_phdrs+0x2cf3> */
	X86_SIM_X86_JMP(0x2cef, 0x2cf3, x86_l_2cf3);
x86_l_2cf1:
	/* 0x2cf1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cf3:
	/* 0x2cf3: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2cf6:
	/* 0x2cf6: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2cf9:
	/* 0x2cf9: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2cfc:
	/* 0x2cfc: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2cff:
	/* 0x2cff: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d04:
	/* 0x2d04: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d09:
	/* 0x2d09: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d0e:
	/* 0x2d0e: mov    rax,QWORD PTR [r13+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_2d15:
	/* 0x2d15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d18:
	/* 0x2d18: je     2d21 <trace_load_elf_phdrs+0x2d21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d18, 0x2d21, x86_l_2d21);
x86_l_2d1a:
	/* 0x2d1a: and    rax,QWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_2d1e:
	/* 0x2d1e: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2d21:
	/* 0x2d21: and    r12,QWORD PTR [r13+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_2d28:
	/* 0x2d28: and    QWORD PTR [r13+0x80],r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_R13, X86_R12, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 128ULL);
x86_l_2d2f:
	/* 0x2d2f: je     348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d2f, 0x348e, x86_l_348e);
x86_l_2d35:
	/* 0x2d35: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d3d:
	/* 0x2d3d: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2d43:
	/* 0x2d43: ja     2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d43, 0x2e1a, x86_l_2e1a);
x86_l_2d49:
	/* 0x2d49: mov    BYTE PTR [r13+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_2d52:
	/* 0x2d52: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d5a:
	/* 0x2d5a: mov    WORD PTR [r13+0x7d8c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2d62:
	/* 0x2d62: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2d68:
	/* 0x2d68: ja     2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d68, 0x2e1a, x86_l_2e1a);
x86_l_2d6e:
	/* 0x2d6e: lea    rdi,[rax+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2d72:
	/* 0x2d72: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2d79:
	/* 0x2d79: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2d7c:
	/* 0x2d7c: jns    2da4 <trace_load_elf_phdrs+0x2da4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d7c, 0x2da4, x86_l_2da4);
x86_l_2d7e:
	/* 0x2d7e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2d81:
	/* 0x2d81: jns    2dea <trace_load_elf_phdrs+0x2dea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d81, 0x2dea, x86_l_2dea);
x86_l_2d83:
	/* 0x2d83: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d85:
	/* 0x2d85: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2d8c:
	/* 0x2d8c: je     2df8 <trace_load_elf_phdrs+0x2df8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d8c, 0x2df8, x86_l_2df8);
x86_l_2d8e:
	/* 0x2d8e: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d92:
	/* 0x2d92: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2d96:
	/* 0x2d96: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2d9a:
	/* 0x2d9a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d9d:
	/* 0x2d9d: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_2da0:
	/* 0x2da0: jne    2d85 <trace_load_elf_phdrs+0x2d85> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2da0, 0x2d85, x86_l_2d85);
x86_l_2da2:
	/* 0x2da2: jmp    2dae <trace_load_elf_phdrs+0x2dae> */
	X86_SIM_X86_JMP(0x2da2, 0x2dae, x86_l_2dae);
x86_l_2da4:
	/* 0x2da4: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2da9:
	/* 0x2da9: call   2dae <trace_load_elf_phdrs+0x2dae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2dae:
	/* 0x2dae: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2db1:
	/* 0x2db1: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2db3:
	/* 0x2db3: jle    2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2db3, 0x2e1a, x86_l_2e1a);
x86_l_2db5:
	/* 0x2db5: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2dbd:
	/* 0x2dbd: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2dc4:
	/* 0x2dc4: ja     2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dc4, 0x2e1a, x86_l_2e1a);
x86_l_2dc6:
	/* 0x2dc6: mov    DWORD PTR [rdx+r13*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 138ULL);
x86_l_2dce:
	/* 0x2dce: add    cx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2dd6:
	/* 0x2dd6: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2dd9:
	/* 0x2dd9: mov    WORD PTR [r13+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2de1:
	/* 0x2de1: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2de8:
	/* 0x2de8: jmp    2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JMP(0x2de8, 0x2e1a, x86_l_2e1a);
x86_l_2dea:
	/* 0x2dea: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2def:
	/* 0x2def: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2df1:
	/* 0x2df1: call   2df6 <trace_load_elf_phdrs+0x2df6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2df6:
	/* 0x2df6: jmp    2e1a <trace_load_elf_phdrs+0x2e1a> */
	X86_SIM_X86_JMP(0x2df6, 0x2e1a, x86_l_2e1a);
x86_l_2df8:
	/* 0x2df8: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2dff:
	/* 0x2dff: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2e04:
	/* 0x2e04: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2e09:
	/* 0x2e09: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e11:
	/* 0x2e11: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2e18:
	/* 0x2e18: jbe    2dc6 <trace_load_elf_phdrs+0x2dc6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2e18, 0x2dc6, x86_l_2dc6);
x86_l_2e1a:
	/* 0x2e1a: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e22:
	/* 0x2e22: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e29:
	/* 0x2e29: ja     2e80 <trace_load_elf_phdrs+0x2e80> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e29, 0x2e80, x86_l_2e80);
x86_l_2e2b:
	/* 0x2e2b: mov    BYTE PTR [r13+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_2e34:
	/* 0x2e34: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2e3a:
	/* 0x2e3a: ja     2e80 <trace_load_elf_phdrs+0x2e80> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e3a, 0x2e80, x86_l_2e80);
x86_l_2e3c:
	/* 0x2e3c: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2e3f:
	/* 0x2e3f: add    rdx,0x158 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 344ULL);
x86_l_2e46:
	/* 0x2e46: lea    rdi,[rbx+rbp*1+0x8a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 138ULL);
x86_l_2e4e:
	/* 0x2e4e: jns    2e5f <trace_load_elf_phdrs+0x2e5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e4e, 0x2e5f, x86_l_2e5f);
x86_l_2e50:
	/* 0x2e50: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e53:
	/* 0x2e53: jns    2ee6 <trace_load_elf_phdrs+0x2ee6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e53, 0x2ee6, x86_l_2ee6);
x86_l_2e59:
	/* 0x2e59: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e5b:
	/* 0x2e5b: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e5d:
	/* 0x2e5d: jmp    2e6e <trace_load_elf_phdrs+0x2e6e> */
	X86_SIM_X86_JMP(0x2e5d, 0x2e6e, x86_l_2e6e);
x86_l_2e5f:
	/* 0x2e5f: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2e64:
	/* 0x2e64: call   2e69 <trace_load_elf_phdrs+0x2e69> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e69:
	/* 0x2e69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e6c:
	/* 0x2e6c: js     2e80 <trace_load_elf_phdrs+0x2e80> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e6c, 0x2e80, x86_l_2e80);
x86_l_2e6e:
	/* 0x2e6e: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e71:
	/* 0x2e71: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e79:
	/* 0x2e79: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e80:
	/* 0x2e80: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e88:
	/* 0x2e88: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e8f:
	/* 0x2e8f: ja     2f06 <trace_load_elf_phdrs+0x2f06> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e8f, 0x2f06, x86_l_2f06);
x86_l_2e91:
	/* 0x2e91: mov    BYTE PTR [r13+rbx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519554ULL);
x86_l_2e9a:
	/* 0x2e9a: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2ea0:
	/* 0x2ea0: ja     2f06 <trace_load_elf_phdrs+0x2f06> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ea0, 0x2f06, x86_l_2f06);
x86_l_2ea2:
	/* 0x2ea2: add    r14,0x160 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 352ULL);
x86_l_2ea9:
	/* 0x2ea9: lea    rdi,[rbx+rbp*1+0x8a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 138ULL);
x86_l_2eb1:
	/* 0x2eb1: jns    2ec0 <trace_load_elf_phdrs+0x2ec0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb1, 0x2ec0, x86_l_2ec0);
x86_l_2eb3:
	/* 0x2eb3: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2eb6:
	/* 0x2eb6: jns    2eff <trace_load_elf_phdrs+0x2eff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb6, 0x2eff, x86_l_2eff);
x86_l_2eb8:
	/* 0x2eb8: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ebb:
	/* 0x2ebb: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ebe:
	/* 0x2ebe: jmp    2ed2 <trace_load_elf_phdrs+0x2ed2> */
	X86_SIM_X86_JMP(0x2ebe, 0x2ed2, x86_l_2ed2);
x86_l_2ec0:
	/* 0x2ec0: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2ec5:
	/* 0x2ec5: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2ec8:
	/* 0x2ec8: call   2ecd <trace_load_elf_phdrs+0x2ecd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ecd:
	/* 0x2ecd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ed0:
	/* 0x2ed0: js     2f06 <trace_load_elf_phdrs+0x2f06> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ed0, 0x2f06, x86_l_2f06);
x86_l_2ed2:
	/* 0x2ed2: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2ed5:
	/* 0x2ed5: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2edd:
	/* 0x2edd: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2ee4:
	/* 0x2ee4: jmp    2f06 <trace_load_elf_phdrs+0x2f06> */
	X86_SIM_X86_JMP(0x2ee4, 0x2f06, x86_l_2f06);
x86_l_2ee6:
	/* 0x2ee6: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eec:
	/* 0x2eec: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2ef4:
	/* 0x2ef4: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2efb:
	/* 0x2efb: jbe    2e91 <trace_load_elf_phdrs+0x2e91> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2efb, 0x2e91, x86_l_2e91);
x86_l_2efd:
	/* 0x2efd: jmp    2f06 <trace_load_elf_phdrs+0x2f06> */
	X86_SIM_X86_JMP(0x2efd, 0x2f06, x86_l_2f06);
x86_l_2eff:
	/* 0x2eff: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f06:
	/* 0x2f06: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2f0d:
	/* 0x2f0d: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2f11:
	/* 0x2f11: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f14:
	/* 0x2f14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f17:
	/* 0x2f17: jns    2f29 <trace_load_elf_phdrs+0x2f29> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f17, 0x2f29, x86_l_2f29);
x86_l_2f19:
	/* 0x2f19: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f1c:
	/* 0x2f1c: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f20:
	/* 0x2f20: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f23:
	/* 0x2f23: js     2f35 <trace_load_elf_phdrs+0x2f35> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f23, 0x2f35, x86_l_2f35);
x86_l_2f25:
	/* 0x2f25: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f27:
	/* 0x2f27: jmp    2f38 <trace_load_elf_phdrs+0x2f38> */
	X86_SIM_X86_JMP(0x2f27, 0x2f38, x86_l_2f38);
x86_l_2f29:
	/* 0x2f29: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f2c:
	/* 0x2f2c: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f30:
	/* 0x2f30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f33:
	/* 0x2f33: jns    2f25 <trace_load_elf_phdrs+0x2f25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f33, 0x2f25, x86_l_2f25);
x86_l_2f35:
	/* 0x2f35: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f38:
	/* 0x2f38: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2f3c:
	/* 0x2f3c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f3e:
	/* 0x2f3e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f41:
	/* 0x2f41: jns    2f52 <trace_load_elf_phdrs+0x2f52> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f41, 0x2f52, x86_l_2f52);
x86_l_2f43:
	/* 0x2f43: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f46:
	/* 0x2f46: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2f4b:
	/* 0x2f4b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f4e:
	/* 0x2f4e: js     2f5f <trace_load_elf_phdrs+0x2f5f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f4e, 0x2f5f, x86_l_2f5f);
x86_l_2f50:
	/* 0x2f50: jmp    2f61 <trace_load_elf_phdrs+0x2f61> */
	X86_SIM_X86_JMP(0x2f50, 0x2f61, x86_l_2f61);
x86_l_2f52:
	/* 0x2f52: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f55:
	/* 0x2f55: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2f5a:
	/* 0x2f5a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f5d:
	/* 0x2f5d: jns    2f61 <trace_load_elf_phdrs+0x2f61> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f5d, 0x2f61, x86_l_2f61);
x86_l_2f5f:
	/* 0x2f5f: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f61:
	/* 0x2f61: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2f65:
	/* 0x2f65: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f69:
	/* 0x2f69: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f6c:
	/* 0x2f6c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f6e:
	/* 0x2f6e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f71:
	/* 0x2f71: jns    2f80 <trace_load_elf_phdrs+0x2f80> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f71, 0x2f80, x86_l_2f80);
x86_l_2f73:
	/* 0x2f73: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f76:
	/* 0x2f76: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f79:
	/* 0x2f79: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f7c:
	/* 0x2f7c: js     2f8a <trace_load_elf_phdrs+0x2f8a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f7c, 0x2f8a, x86_l_2f8a);
x86_l_2f7e:
	/* 0x2f7e: jmp    2f8c <trace_load_elf_phdrs+0x2f8c> */
	X86_SIM_X86_JMP(0x2f7e, 0x2f8c, x86_l_2f8c);
x86_l_2f80:
	/* 0x2f80: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f82:
	/* 0x2f82: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f85:
	/* 0x2f85: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f88:
	/* 0x2f88: jns    2f8c <trace_load_elf_phdrs+0x2f8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f88, 0x2f8c, x86_l_2f8c);
x86_l_2f8a:
	/* 0x2f8a: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f8c:
	/* 0x2f8c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f8e:
	/* 0x2f8e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f92:
	/* 0x2f92: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f95:
	/* 0x2f95: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f99:
	/* 0x2f99: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f9b:
	/* 0x2f9b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f9e:
	/* 0x2f9e: jns    2fa2 <trace_load_elf_phdrs+0x2fa2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f9e, 0x2fa2, x86_l_2fa2);
x86_l_2fa0:
	/* 0x2fa0: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fa2:
	/* 0x2fa2: mov    DWORD PTR [r13+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2fa6:
	/* 0x2fa6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fa9:
	/* 0x2fa9: jns    2fb0 <trace_load_elf_phdrs+0x2fb0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fa9, 0x2fb0, x86_l_2fb0);
x86_l_2fab:
	/* 0x2fab: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fae:
	/* 0x2fae: jmp    2fb2 <trace_load_elf_phdrs+0x2fb2> */
	X86_SIM_X86_JMP(0x2fae, 0x2fb2, x86_l_2fb2);
x86_l_2fb0:
	/* 0x2fb0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fb2:
	/* 0x2fb2: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2fb6:
	/* 0x2fb6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fb8:
	/* 0x2fb8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fbb:
	/* 0x2fbb: jns    2fca <trace_load_elf_phdrs+0x2fca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fbb, 0x2fca, x86_l_2fca);
x86_l_2fbd:
	/* 0x2fbd: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc0:
	/* 0x2fc0: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fc3:
	/* 0x2fc3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fc6:
	/* 0x2fc6: js     2fd4 <trace_load_elf_phdrs+0x2fd4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2fc6, 0x2fd4, x86_l_2fd4);
x86_l_2fc8:
	/* 0x2fc8: jmp    2fd6 <trace_load_elf_phdrs+0x2fd6> */
	X86_SIM_X86_JMP(0x2fc8, 0x2fd6, x86_l_2fd6);
x86_l_2fca:
	/* 0x2fca: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fcc:
	/* 0x2fcc: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fcf:
	/* 0x2fcf: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fd2:
	/* 0x2fd2: jns    2fd6 <trace_load_elf_phdrs+0x2fd6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd2, 0x2fd6, x86_l_2fd6);
x86_l_2fd4:
	/* 0x2fd4: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd6:
	/* 0x2fd6: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2fd8:
	/* 0x2fd8: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2fdc:
	/* 0x2fdc: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2fdf:
	/* 0x2fdf: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2fe3:
	/* 0x2fe3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fe5:
	/* 0x2fe5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fe8:
	/* 0x2fe8: jns    2fec <trace_load_elf_phdrs+0x2fec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fe8, 0x2fec, x86_l_2fec);
x86_l_2fea:
	/* 0x2fea: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fec:
	/* 0x2fec: mov    DWORD PTR [r13+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ff0:
	/* 0x2ff0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ff2:
	/* 0x2ff2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ff5:
	/* 0x2ff5: jns    3004 <trace_load_elf_phdrs+0x3004> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ff5, 0x3004, x86_l_3004);
x86_l_2ff7:
	/* 0x2ff7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ffa:
	/* 0x2ffa: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ffd:
	/* 0x2ffd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3000:
	/* 0x3000: js     300e <trace_load_elf_phdrs+0x300e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3000, 0x300e, x86_l_300e);
x86_l_3002:
	/* 0x3002: jmp    3010 <trace_load_elf_phdrs+0x3010> */
	X86_SIM_X86_JMP(0x3002, 0x3010, x86_l_3010);
x86_l_3004:
	/* 0x3004: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3006:
	/* 0x3006: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3009:
	/* 0x3009: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_300c:
	/* 0x300c: jns    3010 <trace_load_elf_phdrs+0x3010> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x300c, 0x3010, x86_l_3010);
x86_l_300e:
	/* 0x300e: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3010:
	/* 0x3010: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3012:
	/* 0x3012: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3016:
	/* 0x3016: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3019:
	/* 0x3019: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_301d:
	/* 0x301d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_301f:
	/* 0x301f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3022:
	/* 0x3022: jns    3032 <trace_load_elf_phdrs+0x3032> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3022, 0x3032, x86_l_3032);
x86_l_3024:
	/* 0x3024: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3027:
	/* 0x3027: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_302b:
	/* 0x302b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_302e:
	/* 0x302e: js     303d <trace_load_elf_phdrs+0x303d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x302e, 0x303d, x86_l_303d);
x86_l_3030:
	/* 0x3030: jmp    303f <trace_load_elf_phdrs+0x303f> */
	X86_SIM_X86_JMP(0x3030, 0x303f, x86_l_303f);
x86_l_3032:
	/* 0x3032: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3034:
	/* 0x3034: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3038:
	/* 0x3038: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_303b:
	/* 0x303b: jns    303f <trace_load_elf_phdrs+0x303f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x303b, 0x303f, x86_l_303f);
x86_l_303d:
	/* 0x303d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_303f:
	/* 0x303f: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3044:
	/* 0x3044: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3047:
	/* 0x3047: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3049:
	/* 0x3049: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_304c:
	/* 0x304c: jns    305b <trace_load_elf_phdrs+0x305b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x304c, 0x305b, x86_l_305b);
x86_l_304e:
	/* 0x304e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3051:
	/* 0x3051: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3054:
	/* 0x3054: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3057:
	/* 0x3057: js     3065 <trace_load_elf_phdrs+0x3065> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3057, 0x3065, x86_l_3065);
x86_l_3059:
	/* 0x3059: jmp    3067 <trace_load_elf_phdrs+0x3067> */
	X86_SIM_X86_JMP(0x3059, 0x3067, x86_l_3067);
x86_l_305b:
	/* 0x305b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_305d:
	/* 0x305d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3060:
	/* 0x3060: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3063:
	/* 0x3063: jns    3067 <trace_load_elf_phdrs+0x3067> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3063, 0x3067, x86_l_3067);
x86_l_3065:
	/* 0x3065: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3067:
	/* 0x3067: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3069:
	/* 0x3069: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_306d:
	/* 0x306d: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3070:
	/* 0x3070: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3074:
	/* 0x3074: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3076:
	/* 0x3076: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3079:
	/* 0x3079: jns    3089 <trace_load_elf_phdrs+0x3089> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3079, 0x3089, x86_l_3089);
x86_l_307b:
	/* 0x307b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307e:
	/* 0x307e: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3082:
	/* 0x3082: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3085:
	/* 0x3085: js     3094 <trace_load_elf_phdrs+0x3094> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3085, 0x3094, x86_l_3094);
x86_l_3087:
	/* 0x3087: jmp    3096 <trace_load_elf_phdrs+0x3096> */
	X86_SIM_X86_JMP(0x3087, 0x3096, x86_l_3096);
x86_l_3089:
	/* 0x3089: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_308b:
	/* 0x308b: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_308f:
	/* 0x308f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3092:
	/* 0x3092: jns    3096 <trace_load_elf_phdrs+0x3096> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3092, 0x3096, x86_l_3096);
x86_l_3094:
	/* 0x3094: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3096:
	/* 0x3096: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3098:
	/* 0x3098: jne    30d4 <trace_load_elf_phdrs+0x30d4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3098, 0x30d4, x86_l_30d4);
x86_l_309a:
	/* 0x309a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_309c:
	/* 0x309c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_309f:
	/* 0x309f: jns    30ae <trace_load_elf_phdrs+0x30ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x309f, 0x30ae, x86_l_30ae);
x86_l_30a1:
	/* 0x30a1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30a4:
	/* 0x30a4: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30a7:
	/* 0x30a7: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_30aa:
	/* 0x30aa: js     30b8 <trace_load_elf_phdrs+0x30b8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30aa, 0x30b8, x86_l_30b8);
x86_l_30ac:
	/* 0x30ac: jmp    30ba <trace_load_elf_phdrs+0x30ba> */
	X86_SIM_X86_JMP(0x30ac, 0x30ba, x86_l_30ba);
x86_l_30ae:
	/* 0x30ae: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30b0:
	/* 0x30b0: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30b3:
	/* 0x30b3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_30b6:
	/* 0x30b6: jns    30ba <trace_load_elf_phdrs+0x30ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30b6, 0x30ba, x86_l_30ba);
x86_l_30b8:
	/* 0x30b8: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ba:
	/* 0x30ba: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_30bc:
	/* 0x30bc: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_30c0:
	/* 0x30c0: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_30c3:
	/* 0x30c3: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_30c7:
	/* 0x30c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30c9:
	/* 0x30c9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_30cc:
	/* 0x30cc: jns    30d0 <trace_load_elf_phdrs+0x30d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30cc, 0x30d0, x86_l_30d0);
x86_l_30ce:
	/* 0x30ce: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d0:
	/* 0x30d0: mov    DWORD PTR [r13+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30d4:
	/* 0x30d4: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30d8:
	/* 0x30d8: lea    rbp,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_30df:
	/* 0x30df: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_30e2:
	/* 0x30e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30e5:
	/* 0x30e5: jns    30ec <trace_load_elf_phdrs+0x30ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30e5, 0x30ec, x86_l_30ec);
x86_l_30e7:
	/* 0x30e7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ea:
	/* 0x30ea: jmp    30ee <trace_load_elf_phdrs+0x30ee> */
	X86_SIM_X86_JMP(0x30ea, 0x30ee, x86_l_30ee);
x86_l_30ec:
	/* 0x30ec: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30ee:
	/* 0x30ee: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_30f2:
	/* 0x30f2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30f4:
	/* 0x30f4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30f7:
	/* 0x30f7: jns    3103 <trace_load_elf_phdrs+0x3103> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30f7, 0x3103, x86_l_3103);
x86_l_30f9:
	/* 0x30f9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30fc:
	/* 0x30fc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30ff:
	/* 0x30ff: js     310a <trace_load_elf_phdrs+0x310a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30ff, 0x310a, x86_l_310a);
x86_l_3101:
	/* 0x3101: jmp    310c <trace_load_elf_phdrs+0x310c> */
	X86_SIM_X86_JMP(0x3101, 0x310c, x86_l_310c);
x86_l_3103:
	/* 0x3103: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3105:
	/* 0x3105: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3108:
	/* 0x3108: jns    310c <trace_load_elf_phdrs+0x310c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3108, 0x310c, x86_l_310c);
x86_l_310a:
	/* 0x310a: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_310c:
	/* 0x310c: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3111:
	/* 0x3111: lea    r13,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3115:
	/* 0x3115: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_311a:
	/* 0x311a: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_311e:
	/* 0x311e: call   3123 <trace_load_elf_phdrs+0x3123> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_3123:
	/* 0x3123: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3127:
	/* 0x3127: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_312b:
	/* 0x312b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_312e:
	/* 0x312e: jns    3135 <trace_load_elf_phdrs+0x3135> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x312e, 0x3135, x86_l_3135);
x86_l_3130:
	/* 0x3130: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3133:
	/* 0x3133: jmp    3137 <trace_load_elf_phdrs+0x3137> */
	X86_SIM_X86_JMP(0x3133, 0x3137, x86_l_3137);
x86_l_3135:
	/* 0x3135: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3137:
	/* 0x3137: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_313b:
	/* 0x313b: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_313f:
	/* 0x313f: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3142:
	/* 0x3142: jns    3149 <trace_load_elf_phdrs+0x3149> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3142, 0x3149, x86_l_3149);
x86_l_3144:
	/* 0x3144: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3147:
	/* 0x3147: jmp    314b <trace_load_elf_phdrs+0x314b> */
	X86_SIM_X86_JMP(0x3147, 0x314b, x86_l_314b);
x86_l_3149:
	/* 0x3149: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_314b:
	/* 0x314b: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3150:
	/* 0x3150: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3154:
	/* 0x3154: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3158:
	/* 0x3158: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_315b:
	/* 0x315b: jns    3163 <trace_load_elf_phdrs+0x3163> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x315b, 0x3163, x86_l_3163);
x86_l_315d:
	/* 0x315d: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3161:
	/* 0x3161: jmp    3165 <trace_load_elf_phdrs+0x3165> */
	X86_SIM_X86_JMP(0x3161, 0x3165, x86_l_3165);
x86_l_3163:
	/* 0x3163: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3165:
	/* 0x3165: mov    r14,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_316a:
	/* 0x316a: mov    r15,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3172:
	/* 0x3172: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3177:
	/* 0x3177: mov    QWORD PTR [rcx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_317b:
	/* 0x317b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_317e:
	/* 0x317e: jns    318a <trace_load_elf_phdrs+0x318a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x317e, 0x318a, x86_l_318a);
x86_l_3180:
	/* 0x3180: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3182:
	/* 0x3182: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3184:
	/* 0x3184: je     318a <trace_load_elf_phdrs+0x318a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3184, 0x318a, x86_l_318a);
x86_l_3186:
	/* 0x3186: or     BYTE PTR [rcx+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_318a:
	/* 0x318a: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_318f:
	/* 0x318f: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_3193:
	/* 0x3193: mov    QWORD PTR [rcx+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_319b:
	/* 0x319b: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_31a3:
	/* 0x31a3: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_31a8:
	/* 0x31a8: call   31ad <trace_load_elf_phdrs+0x31ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_31ad:
	/* 0x31ad: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_31b0:
	/* 0x31b0: jns    31b8 <trace_load_elf_phdrs+0x31b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31b0, 0x31b8, x86_l_31b8);
x86_l_31b2:
	/* 0x31b2: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31b6:
	/* 0x31b6: jmp    31ba <trace_load_elf_phdrs+0x31ba> */
	X86_SIM_X86_JMP(0x31b6, 0x31ba, x86_l_31ba);
x86_l_31b8:
	/* 0x31b8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31ba:
	/* 0x31ba: mov    rsi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31bf:
	/* 0x31bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31c2:
	/* 0x31c2: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31c7:
	/* 0x31c7: jns    31d3 <trace_load_elf_phdrs+0x31d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31c7, 0x31d3, x86_l_31d3);
x86_l_31c9:
	/* 0x31c9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31cc:
	/* 0x31cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31cf:
	/* 0x31cf: js     31da <trace_load_elf_phdrs+0x31da> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31cf, 0x31da, x86_l_31da);
x86_l_31d1:
	/* 0x31d1: jmp    321b <trace_load_elf_phdrs+0x321b> */
	X86_SIM_X86_JMP(0x31d1, 0x321b, x86_l_321b);
x86_l_31d3:
	/* 0x31d3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31d5:
	/* 0x31d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31d8:
	/* 0x31d8: jns    321b <trace_load_elf_phdrs+0x321b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31d8, 0x321b, x86_l_321b);
x86_l_31da:
	/* 0x31da: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31dd:
	/* 0x31dd: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_31e2:
	/* 0x31e2: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31e6:
	/* 0x31e6: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_31eb:
	/* 0x31eb: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31ef:
	/* 0x31ef: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_31f4:
	/* 0x31f4: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31f8:
	/* 0x31f8: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_31fd:
	/* 0x31fd: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3201:
	/* 0x3201: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_3206:
	/* 0x3206: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_320a:
	/* 0x320a: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_320f:
	/* 0x320f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3213:
	/* 0x3213: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3217:
	/* 0x3217: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_321b:
	/* 0x321b: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_321f:
	/* 0x321f: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3224:
	/* 0x3224: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3227:
	/* 0x3227: jns    3341 <trace_load_elf_phdrs+0x3341> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3227, 0x3341, x86_l_3341);
x86_l_322d:
	/* 0x322d: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_3230:
	/* 0x3230: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3232:
	/* 0x3232: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3234:
	/* 0x3234: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3234, 0x3350, x86_l_3350);
x86_l_323a:
	/* 0x323a: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_323e:
	/* 0x323e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3243:
	/* 0x3243: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_3246:
	/* 0x3246: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3248:
	/* 0x3248: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3248, 0x3350, x86_l_3350);
x86_l_324e:
	/* 0x324e: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_3252:
	/* 0x3252: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3257:
	/* 0x3257: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_325a:
	/* 0x325a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_325c:
	/* 0x325c: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x325c, 0x3350, x86_l_3350);
x86_l_3262:
	/* 0x3262: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_3266:
	/* 0x3266: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_326b:
	/* 0x326b: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_326e:
	/* 0x326e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3270:
	/* 0x3270: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3270, 0x3350, x86_l_3350);
x86_l_3276:
	/* 0x3276: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_327a:
	/* 0x327a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_327f:
	/* 0x327f: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3282:
	/* 0x3282: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3284:
	/* 0x3284: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3284, 0x3350, x86_l_3350);
x86_l_328a:
	/* 0x328a: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_328e:
	/* 0x328e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3293:
	/* 0x3293: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_3296:
	/* 0x3296: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3298:
	/* 0x3298: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3298, 0x3350, x86_l_3350);
x86_l_329e:
	/* 0x329e: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_32a2:
	/* 0x32a2: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32a7:
	/* 0x32a7: mov    BYTE PTR [rdx+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_32aa:
	/* 0x32aa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32ac:
	/* 0x32ac: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32ac, 0x3350, x86_l_3350);
x86_l_32b2:
	/* 0x32b2: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_32b6:
	/* 0x32b6: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32bb:
	/* 0x32bb: mov    BYTE PTR [rdx+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_32be:
	/* 0x32be: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32c0:
	/* 0x32c0: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32c0, 0x3350, x86_l_3350);
x86_l_32c6:
	/* 0x32c6: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_32ca:
	/* 0x32ca: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32cf:
	/* 0x32cf: mov    BYTE PTR [rdx+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_32d2:
	/* 0x32d2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32d4:
	/* 0x32d4: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32d4, 0x3350, x86_l_3350);
x86_l_32d6:
	/* 0x32d6: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_32da:
	/* 0x32da: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32df:
	/* 0x32df: mov    BYTE PTR [rdx+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_32e2:
	/* 0x32e2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32e4:
	/* 0x32e4: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32e4, 0x3350, x86_l_3350);
x86_l_32e6:
	/* 0x32e6: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_32ea:
	/* 0x32ea: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32ef:
	/* 0x32ef: mov    BYTE PTR [rdx+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_32f2:
	/* 0x32f2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32f4:
	/* 0x32f4: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f4, 0x3350, x86_l_3350);
x86_l_32f6:
	/* 0x32f6: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_32fa:
	/* 0x32fa: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32ff:
	/* 0x32ff: mov    BYTE PTR [rdx+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_3302:
	/* 0x3302: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3304:
	/* 0x3304: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3304, 0x3350, x86_l_3350);
x86_l_3306:
	/* 0x3306: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_330a:
	/* 0x330a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_330f:
	/* 0x330f: mov    BYTE PTR [rdx+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3312:
	/* 0x3312: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3314:
	/* 0x3314: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3314, 0x3350, x86_l_3350);
x86_l_3316:
	/* 0x3316: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_331a:
	/* 0x331a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_331f:
	/* 0x331f: mov    BYTE PTR [rdx+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_3322:
	/* 0x3322: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3324:
	/* 0x3324: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3324, 0x3350, x86_l_3350);
x86_l_3326:
	/* 0x3326: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_332a:
	/* 0x332a: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_332f:
	/* 0x332f: mov    BYTE PTR [rcx+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_3332:
	/* 0x3332: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_3334:
	/* 0x3334: je     3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3334, 0x3350, x86_l_3350);
x86_l_3336:
	/* 0x3336: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_333b:
	/* 0x333b: mov    BYTE PTR [rax+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_333f:
	/* 0x333f: jmp    3350 <trace_load_elf_phdrs+0x3350> */
	X86_SIM_X86_JMP(0x333f, 0x3350, x86_l_3350);
x86_l_3341:
	/* 0x3341: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3349:
	/* 0x3349: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3350:
	/* 0x3350: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3353:
	/* 0x3353: jns    33cd <trace_load_elf_phdrs+0x33cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3353, 0x33cd, x86_l_33cd);
x86_l_3355:
	/* 0x3355: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3359:
	/* 0x3359: mov    QWORD PTR [rsi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_335c:
	/* 0x335c: mov    rax,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3360:
	/* 0x3360: mov    QWORD PTR [rsi+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3364:
	/* 0x3364: mov    rax,QWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3368:
	/* 0x3368: mov    QWORD PTR [rsi+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_336c:
	/* 0x336c: mov    rax,QWORD PTR [r13+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3370:
	/* 0x3370: mov    QWORD PTR [rsi+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3374:
	/* 0x3374: mov    rax,QWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3378:
	/* 0x3378: mov    QWORD PTR [rsi+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_337c:
	/* 0x337c: mov    rax,QWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3380:
	/* 0x3380: mov    QWORD PTR [rsi+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3384:
	/* 0x3384: mov    rax,QWORD PTR [r13+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3388:
	/* 0x3388: mov    QWORD PTR [rsi+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_338c:
	/* 0x338c: mov    rax,QWORD PTR [r13+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3390:
	/* 0x3390: mov    QWORD PTR [rsi+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3394:
	/* 0x3394: mov    rax,QWORD PTR [r13+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3398:
	/* 0x3398: mov    QWORD PTR [rsi+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_339c:
	/* 0x339c: mov    rax,QWORD PTR [r13+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_33a0:
	/* 0x33a0: mov    QWORD PTR [rsi+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_33a4:
	/* 0x33a4: mov    rax,QWORD PTR [r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_33a8:
	/* 0x33a8: mov    QWORD PTR [rsi+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_33ac:
	/* 0x33ac: mov    rax,QWORD PTR [r13+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_33b0:
	/* 0x33b0: mov    QWORD PTR [rsi+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_33b4:
	/* 0x33b4: mov    rax,QWORD PTR [r13+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_33b8:
	/* 0x33b8: mov    QWORD PTR [rsi+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_33bc:
	/* 0x33bc: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33c1:
	/* 0x33c1: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_33c6:
	/* 0x33c6: jne    3440 <trace_load_elf_phdrs+0x3440> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33c6, 0x3440, x86_l_3440);
x86_l_33c8:
	/* 0x33c8: jmp    345b <trace_load_elf_phdrs+0x345b> */
	X86_SIM_X86_JMP(0x33c8, 0x345b, x86_l_345b);
x86_l_33cd:
	/* 0x33cd: mov    QWORD PTR [rsi+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_33d5:
	/* 0x33d5: mov    QWORD PTR [rsi+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_33dd:
	/* 0x33dd: mov    QWORD PTR [rsi+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_33e5:
	/* 0x33e5: mov    QWORD PTR [rsi+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_33ed:
	/* 0x33ed: mov    QWORD PTR [rsi+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_33f5:
	/* 0x33f5: mov    QWORD PTR [rsi+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_33fd:
	/* 0x33fd: mov    QWORD PTR [rsi+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3405:
	/* 0x3405: mov    QWORD PTR [rsi+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_340d:
	/* 0x340d: mov    QWORD PTR [rsi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_3415:
	/* 0x3415: mov    QWORD PTR [rsi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_341d:
	/* 0x341d: mov    QWORD PTR [rsi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3425:
	/* 0x3425: mov    QWORD PTR [rsi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_342d:
	/* 0x342d: mov    QWORD PTR [rsi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3434:
	/* 0x3434: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3439:
	/* 0x3439: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_343e:
	/* 0x343e: je     345b <trace_load_elf_phdrs+0x345b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x343e, 0x345b, x86_l_345b);
x86_l_3440:
	/* 0x3440: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_3447:
	/* 0x3447: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_344c:
	/* 0x344c: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_344f:
	/* 0x344f: call   3454 <trace_load_elf_phdrs+0x3454> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_3454:
	/* 0x3454: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3456:
	/* 0x3456: js     345b <trace_load_elf_phdrs+0x345b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3456, 0x345b, x86_l_345b);
x86_l_3458:
	/* 0x3458: mov    DWORD PTR [rbx+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_345b:
	/* 0x345b: movzx  eax,WORD PTR [rbx+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_3462:
	/* 0x3462: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_3467:
	/* 0x3467: jb     346e <trace_load_elf_phdrs+0x346e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3467, 0x346e, x86_l_346e);
x86_l_3469:
	/* 0x3469: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_346e:
	/* 0x346e: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_3473:
	/* 0x3473: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_3477:
	/* 0x3477: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_347e:
	/* 0x347e: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_3483:
	/* 0x3483: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3486:
	/* 0x3486: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3489:
	/* 0x3489: call   348e <trace_load_elf_phdrs+0x348e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_348e:
	/* 0x348e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3490:
	/* 0x3490: add    rsp,0xc8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 200ULL);
x86_l_3497:
	/* 0x3497: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3498:
	/* 0x3498: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_349a:
	/* 0x349a: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_349c:
	/* 0x349c: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_349e:
	/* 0x349e: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34a0:
	/* 0x34a0: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34a1:
	/* 0x34a1: jmp    356e <trace_load_elf_phdrs+0x356e> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_34a6:
	/* 0x34a6: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_34a9:
	/* 0x34a9: jne    3566 <trace_load_elf_phdrs+0x3566> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34a9, 0x3566, x86_l_3566);
x86_l_34af:
	/* 0x34af: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_34b2:
	/* 0x34b2: je     3566 <trace_load_elf_phdrs+0x3566> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34b2, 0x3566, x86_l_3566);
x86_l_34b8:
	/* 0x34b8: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34bc:
	/* 0x34bc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_34bf:
	/* 0x34bf: jns    3504 <trace_load_elf_phdrs+0x3504> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34bf, 0x3504, x86_l_3504);
x86_l_34c1:
	/* 0x34c1: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34c4:
	/* 0x34c4: jmp    3506 <trace_load_elf_phdrs+0x3506> */
	X86_SIM_X86_JMP(0x34c4, 0x3506, x86_l_3506);
x86_l_34c6:
	/* 0x34c6: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_34c9:
	/* 0x34c9: je     3566 <trace_load_elf_phdrs+0x3566> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34c9, 0x3566, x86_l_3566);
x86_l_34cf:
	/* 0x34cf: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_34d5:
	/* 0x34d5: add    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_34da:
	/* 0x34da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_34dd:
	/* 0x34dd: jns    3529 <trace_load_elf_phdrs+0x3529> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34dd, 0x3529, x86_l_3529);
x86_l_34df:
	/* 0x34df: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_34e3:
	/* 0x34e3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_34e5:
	/* 0x34e5: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_34e8:
	/* 0x34e8: je     3531 <trace_load_elf_phdrs+0x3531> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34e8, 0x3531, x86_l_3531);
x86_l_34ea:
	/* 0x34ea: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_34ee:
	/* 0x34ee: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_34f3:
	/* 0x34f3: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_34f7:
	/* 0x34f7: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_34fa:
	/* 0x34fa: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_34fd:
	/* 0x34fd: jne    34e5 <trace_load_elf_phdrs+0x34e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34fd, 0x34e5, x86_l_34e5);
x86_l_34ff:
	/* 0x34ff: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_3502:
	/* 0x3502: jmp    3535 <trace_load_elf_phdrs+0x3535> */
	X86_SIM_X86_JMP(0x3502, 0x3535, x86_l_3535);
x86_l_3504:
	/* 0x3504: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3506:
	/* 0x3506: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3509:
	/* 0x3509: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_350c:
	/* 0x350c: jns    3516 <trace_load_elf_phdrs+0x3516> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x350c, 0x3516, x86_l_3516);
x86_l_350e:
	/* 0x350e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3511:
	/* 0x3511: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3514:
	/* 0x3514: jmp    3518 <trace_load_elf_phdrs+0x3518> */
	X86_SIM_X86_JMP(0x3514, 0x3518, x86_l_3518);
x86_l_3516:
	/* 0x3516: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3518:
	/* 0x3518: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_351b:
	/* 0x351b: jns    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x351b, 0x227b, x86_l_227b);
x86_l_3521:
	/* 0x3521: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3524:
	/* 0x3524: jmp    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JMP(0x3524, 0x227b, x86_l_227b);
x86_l_3529:
	/* 0x3529: mov    rbp,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_352c:
	/* 0x352c: jmp    20c9 <trace_load_elf_phdrs+0x20c9> */
	X86_SIM_X86_JMP(0x352c, 0x20c9, x86_l_20c9);
x86_l_3531:
	/* 0x3531: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3535:
	/* 0x3535: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3539:
	/* 0x3539: jl     3566 <trace_load_elf_phdrs+0x3566> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3539, 0x3566, x86_l_3566);
x86_l_353b:
	/* 0x353b: lea    eax,[r12-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3540:
	/* 0x3540: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3545:
	/* 0x3545: mov    r9,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_354a:
	/* 0x354a: mov    BYTE PTR [r9+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_354f:
	/* 0x354f: sub    r12d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3552:
	/* 0x3552: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3557:
	/* 0x3557: mov    rbx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_355c:
	/* 0x355c: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3561:
	/* 0x3561: jmp    1038 <trace_load_elf_phdrs+0x1038> */
	X86_SIM_X86_JMP(0x3561, 0x1038, x86_l_1038);
x86_l_3566:
	/* 0x3566: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3569:
	/* 0x3569: jmp    227b <trace_load_elf_phdrs+0x227b> */
	X86_SIM_X86_JMP(0x3569, 0x227b, x86_l_227b);
x86_l_356e:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
