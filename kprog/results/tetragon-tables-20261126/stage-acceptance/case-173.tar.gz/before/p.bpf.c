#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 execve_map[] __ksym;
extern __u8 policy_stats[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("uprobe.multi")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_b:
	/* 0xb: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_16:
	/* 0x16: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_1d:
	/* 0x1d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22:
	/* 0x22: call   8017 <generic_usdt_output+0x8017> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27:
	/* 0x27: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a:
	/* 0x2a: je     2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a, 0x2f2, x86_l_2f2);
x86_l_30:
	/* 0x30: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33:
	/* 0x33: cmp    QWORD PTR [rax+0x5ee8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104350525423616ULL);
x86_l_3b:
	/* 0x3b: je     195 <generic_usdt_output+0x195> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b, 0x195, x86_l_195);
x86_l_41:
	/* 0x41: call   8036 <generic_usdt_output+0x8036> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_46:
	/* 0x46: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_49:
	/* 0x49: shr    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_4d:
	/* 0x4d: call   8042 <generic_usdt_output+0x8042> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_52:
	/* 0x52: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_55:
	/* 0x55: mov    DWORD PTR [rsp+0xc],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_5a:
	/* 0x5a: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_61:
	/* 0x61: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_66:
	/* 0x66: call   805b <generic_usdt_output+0x805b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6b:
	/* 0x6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e:
	/* 0x6e: je     195 <generic_usdt_output+0x195> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6e, 0x195, x86_l_195);
x86_l_74:
	/* 0x74: lea    rdi,[rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_78:
	/* 0x78: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_7b:
	/* 0x7b: je     a0 <generic_usdt_output+0xa0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b, 0xa0, x86_l_a0);
x86_l_7d:
	/* 0x7d: mov    rdx,QWORD PTR [r15+0xd70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3440ULL);
x86_l_84:
	/* 0x84: mov    rcx,QWORD PTR [r15+0xa78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2680ULL);
x86_l_8b:
	/* 0x8b: mov    rsi,QWORD PTR [r15+0xb58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2904ULL);
x86_l_92:
	/* 0x92: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_95:
	/* 0x95: je     a4 <generic_usdt_output+0xa4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95, 0xa4, x86_l_a4);
x86_l_97:
	/* 0x97: mov    rcx,QWORD PTR [rcx+0x5a0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1440ULL);
x86_l_9e:
	/* 0x9e: jmp    a6 <generic_usdt_output+0xa6> */
	X86_SIM_X86_JMP(0x9e, 0xa6, x86_l_a6);
x86_l_a0:
	/* 0xa0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a2:
	/* 0xa2: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a4:
	/* 0xa4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a6:
	/* 0xa6: mov    QWORD PTR [rdi+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_ae:
	/* 0xae: mov    QWORD PTR [rdi+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_b6:
	/* 0xb6: mov    QWORD PTR [rdi+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_be:
	/* 0xbe: mov    QWORD PTR [rdi+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_c6:
	/* 0xc6: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd:
	/* 0xcd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d0:
	/* 0xd0: je     195 <generic_usdt_output+0x195> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd0, 0x195, x86_l_195);
x86_l_d6:
	/* 0xd6: mov    r8,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_da:
	/* 0xda: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_dd:
	/* 0xdd: je     e9 <generic_usdt_output+0xe9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdd, 0xe9, x86_l_e9);
x86_l_df:
	/* 0xdf: mov    r8d,DWORD PTR [r8+0x218] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 536ULL);
x86_l_e6:
	/* 0xe6: mov    DWORD PTR [rdi],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e9:
	/* 0xe9: mov    rdi,QWORD PTR [rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ed:
	/* 0xed: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f0:
	/* 0xf0: je     fb <generic_usdt_output+0xfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0, 0xfb, x86_l_fb);
x86_l_f2:
	/* 0xf2: mov    edi,DWORD PTR [rdi+0x4d8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1240ULL);
x86_l_f8:
	/* 0xf8: mov    DWORD PTR [rax+0x2c],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_fb:
	/* 0xfb: mov    rdi,QWORD PTR [rdx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ff:
	/* 0xff: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_102:
	/* 0x102: je     10a <generic_usdt_output+0x10a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102, 0x10a, x86_l_10a);
x86_l_104:
	/* 0x104: mov    edi,DWORD PTR [rdi+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_107:
	/* 0x107: mov    DWORD PTR [rax+0x30],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10a:
	/* 0x10a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10d:
	/* 0x10d: je     130 <generic_usdt_output+0x130> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10d, 0x130, x86_l_130);
x86_l_10f:
	/* 0x10f: mov    edi,DWORD PTR [rsi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_112:
	/* 0x112: test   edi,edi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_114:
	/* 0x114: js     130 <generic_usdt_output+0x130> */
	X86_SIM_X86_JCC(X86_CC_S, 0x114, 0x130, x86_l_130);
x86_l_116:
	/* 0x116: shl    rdi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_11a:
	/* 0x11a: mov    rsi,QWORD PTR [rsi+rdi*1+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 136ULL);
x86_l_122:
	/* 0x122: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_125:
	/* 0x125: je     130 <generic_usdt_output+0x130> */
	X86_SIM_X86_JCC(X86_CC_E, 0x125, 0x130, x86_l_130);
x86_l_127:
	/* 0x127: mov    esi,DWORD PTR [rsi+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_12d:
	/* 0x12d: mov    DWORD PTR [rax+0x34],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_130:
	/* 0x130: mov    rsi,QWORD PTR [rdx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_134:
	/* 0x134: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: je     142 <generic_usdt_output+0x142> */
	X86_SIM_X86_JCC(X86_CC_E, 0x137, 0x142, x86_l_142);
x86_l_139:
	/* 0x139: mov    esi,DWORD PTR [rsi+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_13f:
	/* 0x13f: mov    DWORD PTR [rax+0x38],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_142:
	/* 0x142: mov    rsi,QWORD PTR [rdx+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_149:
	/* 0x149: je     154 <generic_usdt_output+0x154> */
	X86_SIM_X86_JCC(X86_CC_E, 0x149, 0x154, x86_l_154);
x86_l_14b:
	/* 0x14b: mov    esi,DWORD PTR [rsi+0x118] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 280ULL);
x86_l_151:
	/* 0x151: mov    DWORD PTR [rax+0x3c],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_154:
	/* 0x154: mov    rsi,QWORD PTR [rdx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_158:
	/* 0x158: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15b:
	/* 0x15b: je     166 <generic_usdt_output+0x166> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15b, 0x166, x86_l_166);
x86_l_15d:
	/* 0x15d: mov    esi,DWORD PTR [rsi+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_163:
	/* 0x163: mov    DWORD PTR [rax+0x40],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_166:
	/* 0x166: mov    rsi,QWORD PTR [rdx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_16a:
	/* 0x16a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16d:
	/* 0x16d: je     178 <generic_usdt_output+0x178> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d, 0x178, x86_l_178);
x86_l_16f:
	/* 0x16f: mov    esi,DWORD PTR [rsi+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_175:
	/* 0x175: mov    DWORD PTR [rax+0x44],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_178:
	/* 0x178: mov    rdx,QWORD PTR [rdx+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_17c:
	/* 0x17c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: je     187 <generic_usdt_output+0x187> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17f, 0x187, x86_l_187);
x86_l_181:
	/* 0x181: mov    edx,DWORD PTR [rdx+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_184:
	/* 0x184: mov    DWORD PTR [rax+0x48],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_187:
	/* 0x187: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18a:
	/* 0x18a: je     195 <generic_usdt_output+0x195> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18a, 0x195, x86_l_195);
x86_l_18c:
	/* 0x18c: mov    ecx,DWORD PTR [rcx+0x158] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 344ULL);
x86_l_192:
	/* 0x192: mov    DWORD PTR [rax+0x4c],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_195:
	/* 0x195: cmp    QWORD PTR [r14+0x5ef0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104384885161984ULL);
x86_l_19d:
	/* 0x19d: je     20b <generic_usdt_output+0x20b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d, 0x20b, x86_l_20b);
x86_l_19f:
	/* 0x19f: call   8194 <generic_usdt_output+0x8194> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1a4:
	/* 0x1a4: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a7:
	/* 0x1a7: shr    r12,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1ab:
	/* 0x1ab: call   81a0 <generic_usdt_output+0x81a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_1b0:
	/* 0x1b0: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: mov    DWORD PTR [rsp+0xc],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1b8:
	/* 0x1b8: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_1bf:
	/* 0x1bf: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c4:
	/* 0x1c4: call   81b9 <generic_usdt_output+0x81b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c9:
	/* 0x1c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc:
	/* 0x1cc: je     20b <generic_usdt_output+0x20b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc, 0x20b, x86_l_20b);
x86_l_1ce:
	/* 0x1ce: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1d1:
	/* 0x1d1: je     1f5 <generic_usdt_output+0x1f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d1, 0x1f5, x86_l_1f5);
x86_l_1d3:
	/* 0x1d3: mov    rcx,QWORD PTR [r15+0xd00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3328ULL);
x86_l_1da:
	/* 0x1da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dd:
	/* 0x1dd: je     1f5 <generic_usdt_output+0x1f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dd, 0x1f5, x86_l_1f5);
x86_l_1df:
	/* 0x1df: mov    rdx,QWORD PTR [rcx+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e3:
	/* 0x1e3: mov    QWORD PTR [rax+0x58],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1e7:
	/* 0x1e7: mov    rdx,QWORD PTR [rcx+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1eb:
	/* 0x1eb: mov    QWORD PTR [rax+0x60],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1ef:
	/* 0x1ef: mov    rcx,QWORD PTR [rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1f3:
	/* 0x1f3: jmp    207 <generic_usdt_output+0x207> */
	X86_SIM_X86_JMP(0x1f3, 0x207, x86_l_207);
x86_l_1f5:
	/* 0x1f5: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1fd:
	/* 0x1fd: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_205:
	/* 0x205: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_207:
	/* 0x207: mov    QWORD PTR [rax+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_20b:
	/* 0x20b: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_210:
	/* 0x210: add    eax,DWORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 4ULL);
x86_l_214:
	/* 0x214: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_219:
	/* 0x219: cmp    eax,0x2328 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9000ULL);
x86_l_21e:
	/* 0x21e: mov    r15d,0x2328 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 9000ULL);
x86_l_224:
	/* 0x224: cmovb  r15d,eax */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_RAX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_228:
	/* 0x228: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_230:
	/* 0x230: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_237:
	/* 0x237: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23c:
	/* 0x23c: call   8231 <generic_usdt_output+0x8231> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_241:
	/* 0x241: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_244:
	/* 0x244: je     2b6 <generic_usdt_output+0x2b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x244, 0x2b6, x86_l_2b6);
x86_l_246:
	/* 0x246: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_24a:
	/* 0x24a: je     2b6 <generic_usdt_output+0x2b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24a, 0x2b6, x86_l_2b6);
x86_l_24c:
	/* 0x24c: mov    rsi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_253:
	/* 0x253: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_258:
	/* 0x258: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_25e:
	/* 0x25e: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_261:
	/* 0x261: call   8256 <generic_usdt_output+0x8256> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_266:
	/* 0x266: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: jns    2cf <generic_usdt_output+0x2cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x269, 0x2cf, x86_l_2cf);
x86_l_26b:
	/* 0x26b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26e:
	/* 0x26e: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_276:
	/* 0x276: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_27d:
	/* 0x27d: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_282:
	/* 0x282: call   8277 <generic_usdt_output+0x8277> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_287:
	/* 0x287: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a:
	/* 0x28a: je     2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a, 0x2f2, x86_l_2f2);
x86_l_28c:
	/* 0x28c: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_290:
	/* 0x290: jg     36b <generic_usdt_output+0x36b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x290, 0x36b, x86_l_36b);
x86_l_296:
	/* 0x296: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_29a:
	/* 0x29a: je     38c <generic_usdt_output+0x38c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29a, 0x38c, x86_l_38c);
x86_l_2a0:
	/* 0x2a0: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2a4:
	/* 0x2a4: jne    33b <generic_usdt_output+0x33b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a4, 0x33b, x86_l_33b);
x86_l_2aa:
	/* 0x2aa: add    rax,0x640 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1600ULL);
x86_l_2b0:
	/* 0x2b0: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2b4:
	/* 0x2b4: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x2b4, 0x2f2, x86_l_2f2);
x86_l_2b6:
	/* 0x2b6: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_2bd:
	/* 0x2bd: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2c0:
	/* 0x2c0: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2c3:
	/* 0x2c3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c5:
	/* 0x2c5: call   82ba <generic_usdt_output+0x82ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_2ca:
	/* 0x2ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cd:
	/* 0x2cd: js     304 <generic_usdt_output+0x304> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2cd, 0x304, x86_l_304);
x86_l_2cf:
	/* 0x2cf: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2d7:
	/* 0x2d7: mov    rdi,QWORD PTR [rip+0x7ff0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)policy_stats));
x86_l_2de:
	/* 0x2de: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2e3:
	/* 0x2e3: call   82d8 <generic_usdt_output+0x82d8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2e8:
	/* 0x2e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eb:
	/* 0x2eb: je     2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2eb, 0x2f2, x86_l_2f2);
x86_l_2ed:
	/* 0x2ed: lock inc QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 8ULL);
x86_l_2f2:
	/* 0x2f2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f4:
	/* 0x2f4: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2f8:
	/* 0x2f8: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fb:
	/* 0x2fb: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fd:
	/* 0x2fd: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2ff:
	/* 0x2ff: jmp    3b9 <generic_usdt_output+0x3b9> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_304:
	/* 0x304: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_307:
	/* 0x307: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_30f:
	/* 0x30f: mov    rdi,QWORD PTR [rip+0x7fec] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_316:
	/* 0x316: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_31b:
	/* 0x31b: call   830c <generic_usdt_output+0x830c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_320:
	/* 0x320: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_323:
	/* 0x323: je     2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x323, 0x2f2, x86_l_2f2);
x86_l_325:
	/* 0x325: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_329:
	/* 0x329: jg     34d <generic_usdt_output+0x34d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x329, 0x34d, x86_l_34d);
x86_l_32b:
	/* 0x32b: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_32f:
	/* 0x32f: je     38c <generic_usdt_output+0x38c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f, 0x38c, x86_l_38c);
x86_l_331:
	/* 0x331: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_335:
	/* 0x335: je     2aa <generic_usdt_output+0x2aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x335, 0x2aa, x86_l_2aa);
x86_l_33b:
	/* 0x33b: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_33f:
	/* 0x33f: jne    37d <generic_usdt_output+0x37d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33f, 0x37d, x86_l_37d);
x86_l_341:
	/* 0x341: add    rax,0x638 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1592ULL);
x86_l_347:
	/* 0x347: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_34b:
	/* 0x34b: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x34b, 0x2f2, x86_l_2f2);
x86_l_34d:
	/* 0x34d: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_351:
	/* 0x351: je     39b <generic_usdt_output+0x39b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x351, 0x39b, x86_l_39b);
x86_l_353:
	/* 0x353: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_357:
	/* 0x357: je     3aa <generic_usdt_output+0x3aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x357, 0x3aa, x86_l_3aa);
x86_l_359:
	/* 0x359: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_35d:
	/* 0x35d: jne    37d <generic_usdt_output+0x37d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x35d, 0x37d, x86_l_37d);
x86_l_35f:
	/* 0x35f: add    rax,0x628 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1576ULL);
x86_l_365:
	/* 0x365: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_369:
	/* 0x369: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x369, 0x2f2, x86_l_2f2);
x86_l_36b:
	/* 0x36b: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_36f:
	/* 0x36f: je     39b <generic_usdt_output+0x39b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36f, 0x39b, x86_l_39b);
x86_l_371:
	/* 0x371: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_375:
	/* 0x375: je     3aa <generic_usdt_output+0x3aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x375, 0x3aa, x86_l_3aa);
x86_l_377:
	/* 0x377: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_37b:
	/* 0x37b: je     35f <generic_usdt_output+0x35f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37b, 0x35f, x86_l_35f);
x86_l_37d:
	/* 0x37d: add    rax,0x620 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1568ULL);
x86_l_383:
	/* 0x383: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_387:
	/* 0x387: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x387, 0x2f2, x86_l_2f2);
x86_l_38c:
	/* 0x38c: add    rax,0x648 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1608ULL);
x86_l_392:
	/* 0x392: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_396:
	/* 0x396: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x396, 0x2f2, x86_l_2f2);
x86_l_39b:
	/* 0x39b: add    rax,0x650 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1616ULL);
x86_l_3a1:
	/* 0x3a1: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3a5:
	/* 0x3a5: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x3a5, 0x2f2, x86_l_2f2);
x86_l_3aa:
	/* 0x3aa: add    rax,0x630 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1584ULL);
x86_l_3b0:
	/* 0x3b0: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3b4:
	/* 0x3b4: jmp    2f2 <generic_usdt_output+0x2f2> */
	X86_SIM_X86_JMP(0x3b4, 0x2f2, x86_l_2f2);
x86_l_3b9:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
