#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 24U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_5:
	/* 0x5: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_c:
	/* 0xc: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e:
	/* 0xe: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_14:
	/* 0x14: ja     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14, 0xb8, x86_l_b8);
x86_l_1a:
	/* 0x1a: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d:
	/* 0x1d: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20:
	/* 0x20: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_24:
	/* 0x24: jns    3a <filter_file_type+0x3a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24, 0x3a, x86_l_3a);
x86_l_26:
	/* 0x26: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29:
	/* 0x29: jns    60 <filter_file_type+0x60> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29, 0x60, x86_l_60);
x86_l_2b:
	/* 0x2b: movzx  ecx,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2e:
	/* 0x2e: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31:
	/* 0x31: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_33:
	/* 0x33: jne    69 <filter_file_type+0x69> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33, 0x69, x86_l_69);
x86_l_35:
	/* 0x35: jmp    b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JMP(0x35, 0xb8, x86_l_b8);
x86_l_3a:
	/* 0x3a: lea    rax,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_3f:
	/* 0x3f: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_42:
	/* 0x42: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45:
	/* 0x45: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4a:
	/* 0x4a: call   28bc <filter_file_type+0x28bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4f:
	/* 0x4f: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_52:
	/* 0x52: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_57:
	/* 0x57: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5a:
	/* 0x5a: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_5c:
	/* 0x5c: jne    69 <filter_file_type+0x69> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c, 0x69, x86_l_69);
x86_l_5e:
	/* 0x5e: jmp    b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JMP(0x5e, 0xb8, x86_l_b8);
x86_l_60:
	/* 0x60: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_62:
	/* 0x62: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_65:
	/* 0x65: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_67:
	/* 0x67: je     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x67, 0xb8, x86_l_b8);
x86_l_69:
	/* 0x69: and    ecx,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_6f:
	/* 0x6f: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_74:
	/* 0x74: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_76:
	/* 0x76: je     ba <filter_file_type+0xba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76, 0xba, x86_l_ba);
x86_l_78:
	/* 0x78: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7b:
	/* 0x7b: cmp    edx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_7e:
	/* 0x7e: jbe    b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x7e, 0xb8, x86_l_b8);
x86_l_80:
	/* 0x80: mov    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_83:
	/* 0x83: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_85:
	/* 0x85: je     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85, 0xb8, x86_l_b8);
x86_l_87:
	/* 0x87: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_89:
	/* 0x89: je     ba <filter_file_type+0xba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x89, 0xba, x86_l_ba);
x86_l_8b:
	/* 0x8b: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_8e:
	/* 0x8e: jb     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8e, 0xb8, x86_l_b8);
x86_l_90:
	/* 0x90: mov    esi,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_93:
	/* 0x93: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_95:
	/* 0x95: je     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x95, 0xb8, x86_l_b8);
x86_l_97:
	/* 0x97: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_99:
	/* 0x99: je     ba <filter_file_type+0xba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99, 0xba, x86_l_ba);
x86_l_9b:
	/* 0x9b: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_9e:
	/* 0x9e: jb     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x9e, 0xb8, x86_l_b8);
x86_l_a0:
	/* 0xa0: mov    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_a3:
	/* 0xa3: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_a5:
	/* 0xa5: je     b8 <filter_file_type+0xb8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5, 0xb8, x86_l_b8);
x86_l_a7:
	/* 0xa7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a9:
	/* 0xa9: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_ab:
	/* 0xab: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_ae:
	/* 0xae: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_b2:
	/* 0xb2: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b3:
	/* 0xb3: jmp    c4 <filter_file_type+0xc4> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_b8:
	/* 0xb8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ba:
	/* 0xba: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_be:
	/* 0xbe: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_bf:
	/* 0xbf: jmp    c4 <filter_file_type+0xc4> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_c4:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
