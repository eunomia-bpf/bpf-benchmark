#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 152U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(10) M(11)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: sub    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_b:
	/* 0xb: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_14:
	/* 0x14: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1d:
	/* 0x1d: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_26:
	/* 0x26: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2f:
	/* 0x2f: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_38:
	/* 0x38: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f:
	/* 0x3f: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_47:
	/* 0x47: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_4a:
	/* 0x4a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c:
	/* 0x4c: cmp    edx,0x27 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 39ULL);
x86_l_4f:
	/* 0x4f: jg     67 <filter_inet+0x67> */
	X86_SIM_X86_JCC(X86_CC_G, 0x4f, 0x67, x86_l_67);
x86_l_51:
	/* 0x51: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_54:
	/* 0x54: je     ec <filter_inet+0xec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54, 0xec, x86_l_ec);
x86_l_5a:
	/* 0x5a: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5d:
	/* 0x5d: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_60:
	/* 0x60: je     78 <filter_inet+0x78> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60, 0x78, x86_l_78);
x86_l_62:
	/* 0x62: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x62, 0x2f4, x86_l_2f4);
x86_l_67:
	/* 0x67: cmp    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_6a:
	/* 0x6a: je     c4 <filter_inet+0xc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a, 0xc4, x86_l_c4);
x86_l_6c:
	/* 0x6c: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_6f:
	/* 0x6f: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_72:
	/* 0x72: jne    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x72, 0x2f4, x86_l_2f4);
x86_l_78:
	/* 0x78: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7b:
	/* 0x7b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d:
	/* 0x7d: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_80:
	/* 0x80: jle    f9 <filter_inet+0xf9> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x80, 0xf9, x86_l_f9);
x86_l_82:
	/* 0x82: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_85:
	/* 0x85: jg     a4 <filter_inet+0xa4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x85, 0xa4, x86_l_a4);
x86_l_87:
	/* 0x87: lea    edx,[rcx-0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_8a:
	/* 0x8a: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_8d:
	/* 0x8d: jb     14a <filter_inet+0x14a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x8d, 0x14a, x86_l_14a);
x86_l_93:
	/* 0x93: lea    edx,[rcx-0x16] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_96:
	/* 0x96: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_99:
	/* 0x99: jb     144 <filter_inet+0x144> */
	X86_SIM_X86_JCC(X86_CC_B, 0x99, 0x144, x86_l_144);
x86_l_9f:
	/* 0x9f: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x9f, 0x2f4, x86_l_2f4);
x86_l_a4:
	/* 0xa4: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_a7:
	/* 0xa7: jg     187 <filter_inet+0x187> */
	X86_SIM_X86_JCC(X86_CC_G, 0xa7, 0x187, x86_l_187);
x86_l_ad:
	/* 0xad: cmp    ecx,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_b0:
	/* 0xb0: je     1ba <filter_inet+0x1ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb0, 0x1ba, x86_l_1ba);
x86_l_b6:
	/* 0xb6: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_b9:
	/* 0xb9: je     1b0 <filter_inet+0x1b0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb9, 0x1b0, x86_l_1b0);
x86_l_bf:
	/* 0xbf: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0xbf, 0x2f4, x86_l_2f4);
x86_l_c4:
	/* 0xc4: movzx  eax,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_c7:
	/* 0xc7: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_cc:
	/* 0xcc: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_d0:
	/* 0xd0: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d5:
	/* 0xd5: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d9:
	/* 0xd9: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_de:
	/* 0xde: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e2:
	/* 0xe2: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e7:
	/* 0xe7: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ec:
	/* 0xec: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef:
	/* 0xef: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f2:
	/* 0xf2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f4:
	/* 0xf4: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_f7:
	/* 0xf7: jg     82 <filter_inet+0x82> */
	X86_SIM_X86_JCC(X86_CC_G, 0xf7, 0x82, x86_l_82);
x86_l_f9:
	/* 0xf9: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_fc:
	/* 0xfc: jle    11a <filter_inet+0x11a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xfc, 0x11a, x86_l_11a);
x86_l_fe:
	/* 0xfe: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_101:
	/* 0x101: jg     136 <filter_inet+0x136> */
	X86_SIM_X86_JCC(X86_CC_G, 0x101, 0x136, x86_l_136);
x86_l_103:
	/* 0x103: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_106:
	/* 0x106: je     144 <filter_inet+0x144> */
	X86_SIM_X86_JCC(X86_CC_E, 0x106, 0x144, x86_l_144);
x86_l_108:
	/* 0x108: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_10b:
	/* 0x10b: jne    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10b, 0x2f4, x86_l_2f4);
x86_l_111:
	/* 0x111: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_115:
	/* 0x115: jmp    2e9 <filter_inet+0x2e9> */
	X86_SIM_X86_JMP(0x115, 0x2e9, x86_l_2e9);
x86_l_11a:
	/* 0x11a: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_11d:
	/* 0x11d: je     1ba <filter_inet+0x1ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11d, 0x1ba, x86_l_1ba);
x86_l_123:
	/* 0x123: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_126:
	/* 0x126: je     1b0 <filter_inet+0x1b0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x126, 0x1b0, x86_l_1b0);
x86_l_12c:
	/* 0x12c: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_12f:
	/* 0x12f: je     14a <filter_inet+0x14a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f, 0x14a, x86_l_14a);
x86_l_131:
	/* 0x131: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x131, 0x2f4, x86_l_2f4);
x86_l_136:
	/* 0x136: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_139:
	/* 0x139: je     14a <filter_inet+0x14a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x139, 0x14a, x86_l_14a);
x86_l_13b:
	/* 0x13b: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_13e:
	/* 0x13e: jne    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13e, 0x2f4, x86_l_2f4);
x86_l_144:
	/* 0x144: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_148:
	/* 0x148: jmp    14e <filter_inet+0x14e> */
	X86_SIM_X86_JMP(0x148, 0x14e, x86_l_14e);
x86_l_14a:
	/* 0x14a: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_14e:
	/* 0x14e: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_152:
	/* 0x152: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_154:
	/* 0x154: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157:
	/* 0x157: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a:
	/* 0x15a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c:
	/* 0x15c: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_15f:
	/* 0x15f: jg     1d1 <filter_inet+0x1d1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x15f, 0x1d1, x86_l_1d1);
x86_l_161:
	/* 0x161: lea    edx,[rcx-0xd] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_164:
	/* 0x164: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_167:
	/* 0x167: jb     1f8 <filter_inet+0x1f8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x167, 0x1f8, x86_l_1f8);
x86_l_16d:
	/* 0x16d: lea    edx,[rcx-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_170:
	/* 0x170: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_173:
	/* 0x173: jb     248 <filter_inet+0x248> */
	X86_SIM_X86_JCC(X86_CC_B, 0x173, 0x248, x86_l_248);
x86_l_179:
	/* 0x179: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_17c:
	/* 0x17c: je     2ec <filter_inet+0x2ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17c, 0x2ec, x86_l_2ec);
x86_l_182:
	/* 0x182: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x182, 0x2f4, x86_l_2f4);
x86_l_187:
	/* 0x187: cmp    ecx,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_18a:
	/* 0x18a: je     2e5 <filter_inet+0x2e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18a, 0x2e5, x86_l_2e5);
x86_l_190:
	/* 0x190: cmp    ecx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_193:
	/* 0x193: jne    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x193, 0x2f4, x86_l_2f4);
x86_l_199:
	/* 0x199: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_19c:
	/* 0x19c: jne    31c <filter_inet+0x31c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19c, 0x31c, x86_l_31c);
x86_l_1a2:
	/* 0x1a2: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1a5:
	/* 0x1a5: jne    326 <filter_inet+0x326> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a5, 0x326, x86_l_326);
x86_l_1ab:
	/* 0x1ab: jmp    2ec <filter_inet+0x2ec> */
	X86_SIM_X86_JMP(0x1ab, 0x2ec, x86_l_2ec);
x86_l_1b0:
	/* 0x1b0: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b4:
	/* 0x1b4: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b8:
	/* 0x1b8: jmp    1c1 <filter_inet+0x1c1> */
	X86_SIM_X86_JMP(0x1b8, 0x1c1, x86_l_1c1);
x86_l_1ba:
	/* 0x1ba: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bd:
	/* 0x1bd: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c1:
	/* 0x1c1: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c4:
	/* 0x1c4: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c8:
	/* 0x1c8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ca:
	/* 0x1ca: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cc:
	/* 0x1cc: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1cf:
	/* 0x1cf: jle    161 <filter_inet+0x161> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1cf, 0x161, x86_l_161);
x86_l_1d1:
	/* 0x1d1: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1d4:
	/* 0x1d4: ja     23c <filter_inet+0x23c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d4, 0x23c, x86_l_23c);
x86_l_1d6:
	/* 0x1d6: mov    r8d,0x500000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 5242880ULL);
x86_l_1dc:
	/* 0x1dc: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1e0:
	/* 0x1e0: jb     252 <filter_inet+0x252> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e0, 0x252, x86_l_252);
x86_l_1e2:
	/* 0x1e2: mov    r8d,0xa00000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 10485760ULL);
x86_l_1e8:
	/* 0x1e8: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1ec:
	/* 0x1ec: jb     262 <filter_inet+0x262> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ec, 0x262, x86_l_262);
x86_l_1ee:
	/* 0x1ee: mov    edx,0x3000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 50331648ULL);
x86_l_1f3:
	/* 0x1f3: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1f6:
	/* 0x1f6: jae    23c <filter_inet+0x23c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1f6, 0x23c, x86_l_23c);
x86_l_1f8:
	/* 0x1f8: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_1fc:
	/* 0x1fc: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1ff:
	/* 0x1ff: je     272 <filter_inet+0x272> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ff, 0x272, x86_l_272);
x86_l_201:
	/* 0x201: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_204:
	/* 0x204: jne    2de <filter_inet+0x2de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x204, 0x2de, x86_l_2de);
x86_l_20a:
	/* 0x20a: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20d:
	/* 0x20d: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_210:
	/* 0x210: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_214:
	/* 0x214: mov    rdi,QWORD PTR [rip+0x1d00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr4lpm_maps));
x86_l_21b:
	/* 0x21b: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_220:
	/* 0x220: call   1f25 <filter_32ty_map+0x1be9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_225:
	/* 0x225: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: je     304 <filter_inet+0x304> */
	X86_SIM_X86_JCC(X86_CC_E, 0x228, 0x304, x86_l_304);
x86_l_22e:
	/* 0x22e: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_236:
	/* 0x236: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23a:
	/* 0x23a: jmp    2b1 <filter_inet+0x2b1> */
	X86_SIM_X86_JMP(0x23a, 0x2b1, x86_l_2b1);
x86_l_23c:
	/* 0x23c: add    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_23f:
	/* 0x23f: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_242:
	/* 0x242: jae    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x242, 0x2f4, x86_l_2f4);
x86_l_248:
	/* 0x248: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24d:
	/* 0x24d: jmp    2ef <filter_inet+0x2ef> */
	X86_SIM_X86_JMP(0x24d, 0x2ef, x86_l_2ef);
x86_l_252:
	/* 0x252: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_254:
	/* 0x254: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_25a:
	/* 0x25a: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_25d:
	/* 0x25d: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x25d, 0x2f4, x86_l_2f4);
x86_l_262:
	/* 0x262: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_264:
	/* 0x264: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_26a:
	/* 0x26a: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_26d:
	/* 0x26d: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x26d, 0x2f4, x86_l_2f4);
x86_l_272:
	/* 0x272: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_275:
	/* 0x275: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_278:
	/* 0x278: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27c:
	/* 0x27c: mov    rdi,QWORD PTR [rip+0x1d00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr6lpm_maps));
x86_l_283:
	/* 0x283: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_288:
	/* 0x288: call   1f8d <filter_32ty_map+0x1c51> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_28d:
	/* 0x28d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_290:
	/* 0x290: je     304 <filter_inet+0x304> */
	X86_SIM_X86_JCC(X86_CC_E, 0x290, 0x304, x86_l_304);
x86_l_292:
	/* 0x292: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_29a:
	/* 0x29a: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29e:
	/* 0x29e: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2a3:
	/* 0x2a3: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a8:
	/* 0x2a8: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2ac:
	/* 0x2ac: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2b1:
	/* 0x2b1: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2b6:
	/* 0x2b6: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b9:
	/* 0x2b9: call   1fbe <filter_32ty_map+0x1c82> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2be:
	/* 0x2be: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c3:
	/* 0x2c3: lea    edx,[rcx-0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_2c6:
	/* 0x2c6: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c9:
	/* 0x2c9: jb     311 <filter_inet+0x311> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c9, 0x311, x86_l_311);
x86_l_2cb:
	/* 0x2cb: add    ecx,0xfffffff3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_2ce:
	/* 0x2ce: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2d1:
	/* 0x2d1: ja     2de <filter_inet+0x2de> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d1, 0x2de, x86_l_2de);
x86_l_2d3:
	/* 0x2d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d6:
	/* 0x2d6: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2d9:
	/* 0x2d9: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2dc:
	/* 0x2dc: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x2dc, 0x2f4, x86_l_2f4);
x86_l_2de:
	/* 0x2de: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e0:
	/* 0x2e0: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2e3:
	/* 0x2e3: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x2e3, 0x2f4, x86_l_2f4);
x86_l_2e5:
	/* 0x2e5: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_2e9:
	/* 0x2e9: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ec:
	/* 0x2ec: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_2ef:
	/* 0x2ef: call   33c <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_33c, 0x2f4ULL);
x86_l_2f4:
	/* 0x2f4: add    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_2f8:
	/* 0x2f8: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2f9:
	/* 0x2f9: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fb:
	/* 0x2fb: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fd:
	/* 0x2fd: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2ff:
	/* 0x2ff: jmp    3bd <filter_32ty_map+0x81> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_304:
	/* 0x304: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_309:
	/* 0x309: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_30c:
	/* 0x30c: cmp    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_30f:
	/* 0x30f: jmp    314 <filter_inet+0x314> */
	X86_SIM_X86_JMP(0x30f, 0x314, x86_l_314);
x86_l_311:
	/* 0x311: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_314:
	/* 0x314: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_317:
	/* 0x317: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_31a:
	/* 0x31a: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x31a, 0x2f4, x86_l_2f4);
x86_l_31c:
	/* 0x31c: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_31f:
	/* 0x31f: jne    32e <filter_inet+0x32e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31f, 0x32e, x86_l_32e);
x86_l_321:
	/* 0x321: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_324:
	/* 0x324: je     32e <filter_inet+0x32e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x324, 0x32e, x86_l_32e);
x86_l_326:
	/* 0x326: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_32b:
	/* 0x32b: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32e:
	/* 0x32e: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_331:
	/* 0x331: je     2ec <filter_inet+0x2ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x331, 0x2ec, x86_l_2ec);
x86_l_333:
	/* 0x333: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_336:
	/* 0x336: je     2ec <filter_inet+0x2ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x336, 0x2ec, x86_l_2ec);
x86_l_338:
	/* 0x338: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33a:
	/* 0x33a: jmp    2f4 <filter_inet+0x2f4> */
	X86_SIM_X86_JMP(0x33a, 0x2f4, x86_l_2f4);
x86_l_3bd:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_33c */
x86_l_33c:
	/* 0x33c: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_33e:
	/* 0x33e: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33f:
	/* 0x33f: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_343:
	/* 0x343: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_346:
	/* 0x346: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_349:
	/* 0x349: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_34d:
	/* 0x34d: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_351:
	/* 0x351: mov    rdi,QWORD PTR [rip+0x1050] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_358:
	/* 0x358: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_35d:
	/* 0x35d: call   13b2 <filter_32ty_map+0x1076> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_362:
	/* 0x362: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_365:
	/* 0x365: je     398 <filter_32ty_map+0x5c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x365, 0x398, x86_l_398);
x86_l_367:
	/* 0x367: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36a:
	/* 0x36a: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36f:
	/* 0x36f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_374:
	/* 0x374: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_377:
	/* 0x377: call   13cc <filter_32ty_map+0x1090> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_37c:
	/* 0x37c: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_37f:
	/* 0x37f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_381:
	/* 0x381: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_384:
	/* 0x384: ja     3b2 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x384, 0x3b2, x86_l_3b2);
x86_l_386:
	/* 0x386: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_38b:
	/* 0x38b: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_38e:
	/* 0x38e: jae    3a2 <filter_32ty_map+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x38e, 0x3a2, x86_l_3a2);
x86_l_390:
	/* 0x390: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_393:
	/* 0x393: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_396:
	/* 0x396: jmp    3b2 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JMP(0x396, 0x3b2, x86_l_3b2);
x86_l_398:
	/* 0x398: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39a:
	/* 0x39a: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_39e:
	/* 0x39e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_39f:
	/* 0x39f: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3a1:
	/* 0x3a1: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_3a1);
x86_l_3a2:
	/* 0x3a2: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_3a7:
	/* 0x3a7: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3aa:
	/* 0x3aa: jae    3b2 <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x3aa, 0x3b2, x86_l_3b2);
x86_l_3ac:
	/* 0x3ac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3af:
	/* 0x3af: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3b2:
	/* 0x3b2: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_3b5:
	/* 0x3b5: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_3b9:
	/* 0x3b9: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3ba:
	/* 0x3ba: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3bc:
	/* 0x3bc: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_3a1);

x86_sim_ret_dispatch_3a1:
	switch (__x86_sim_ret_addr) {
	case 0x2f4ULL: goto x86_l_2f4;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
