#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 88U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(4)
#include "../x86_sim_local_bpf.h"

extern __u8 execve_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_cgrps_msg_heap[] __ksym;
extern __u8 tg_cgrps_tracking_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_errmetrics_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_REP_MOVS, X86_OP_REP_MOVS)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/cgroup_rmdir")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_e:
	/* 0xe: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_16:
	/* 0x16: mov    r14,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19:
	/* 0x19: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c:
	/* 0x1c: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c, 0x28d, x86_l_28d);
x86_l_22:
	/* 0x22: lea    rax,[r14+0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_29:
	/* 0x29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c:
	/* 0x2c: jns    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c, 0x28d, x86_l_28d);
x86_l_32:
	/* 0x32: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35:
	/* 0x35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38, 0x28d, x86_l_28d);
x86_l_3e:
	/* 0x3e: add    rax,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_42:
	/* 0x42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_45:
	/* 0x45: jns    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45, 0x28d, x86_l_28d);
x86_l_4b:
	/* 0x4b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e:
	/* 0x4e: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x28d, x86_l_28d);
x86_l_5c:
	/* 0x5c: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_cgrps_tracking_map));
x86_l_66:
	/* 0x66: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b:
	/* 0x6b: call   70 <tg_tp_cgrp_rmdir+0x70> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_70:
	/* 0x70: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73:
	/* 0x73: je     1e5 <tg_tp_cgrp_rmdir+0x1e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73, 0x1e5, x86_l_1e5);
x86_l_79:
	/* 0x79: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c:
	/* 0x7c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_cgrps_tracking_map));
x86_l_83:
	/* 0x83: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_88:
	/* 0x88: call   8d <tg_tp_cgrp_rmdir+0x8d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_8d:
	/* 0x8d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_94:
	/* 0x94: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_99:
	/* 0x99: call   9e <tg_tp_cgrp_rmdir+0x9e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9e:
	/* 0x9e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a1:
	/* 0xa1: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa1, 0x28d, x86_l_28d);
x86_l_a7:
	/* 0xa7: cmp    DWORD PTR [rax],0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 6ULL);
x86_l_aa:
	/* 0xaa: jne    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaa, 0x28d, x86_l_28d);
x86_l_b0:
	/* 0xb0: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b5:
	/* 0xb5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ba:
	/* 0xba: mov    DWORD PTR [rsp+0x1c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_c2:
	/* 0xc2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_cgrps_msg_heap));
x86_l_c9:
	/* 0xc9: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_ce:
	/* 0xce: call   d3 <tg_tp_cgrp_rmdir+0xd3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d3:
	/* 0xd3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d6:
	/* 0xd6: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd6, 0x28d, x86_l_28d);
x86_l_dc:
	/* 0xdc: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_df:
	/* 0xdf: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e2:
	/* 0xe2: mov    BYTE PTR [r15],0x19 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 25ULL);
x86_l_e6:
	/* 0xe6: mov    DWORD PTR [r15+0x4],0x10d8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179873496ULL);
x86_l_ee:
	/* 0xee: mov    r12,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f2:
	/* 0xf2: call   f7 <tg_tp_cgrp_rmdir+0xf7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_f7:
	/* 0xf7: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fa:
	/* 0xfa: shr    r13,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fe:
	/* 0xfe: mov    DWORD PTR [rsp],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_102:
	/* 0x102: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_109:
	/* 0x109: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_10c:
	/* 0x10c: call   111 <tg_tp_cgrp_rmdir+0x111> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_111:
	/* 0x111: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_114:
	/* 0x114: je     13d <tg_tp_cgrp_rmdir+0x13d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x114, 0x13d, x86_l_13d);
x86_l_116:
	/* 0x116: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11a:
	/* 0x11a: mov    QWORD PTR [r14+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11e:
	/* 0x11e: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_122:
	/* 0x122: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [r14+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12a:
	/* 0x12a: mov    QWORD PTR [r14+0x18],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12e:
	/* 0x12e: mov    ecx,DWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_131:
	/* 0x131: mov    DWORD PTR [r14+0x2c],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_135:
	/* 0x135: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_139:
	/* 0x139: mov    QWORD PTR [r14+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13d:
	/* 0x13d: mov    DWORD PTR [r14+0x20],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953474ULL);
x86_l_145:
	/* 0x145: mov    DWORD PTR [r14+0x24],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_149:
	/* 0x149: call   14e <tg_tp_cgrp_rmdir+0x14e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_14e:
	/* 0x14e: add    rax,0x60 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 96ULL);
x86_l_152:
	/* 0x152: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_154:
	/* 0x154: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_157:
	/* 0x157: jns    188 <tg_tp_cgrp_rmdir+0x188> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157, 0x188, x86_l_188);
x86_l_159:
	/* 0x159: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15c:
	/* 0x15c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15f:
	/* 0x15f: je     188 <tg_tp_cgrp_rmdir+0x188> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f, 0x188, x86_l_188);
x86_l_161:
	/* 0x161: lea    rdx,[rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_165:
	/* 0x165: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_168:
	/* 0x168: jns    188 <tg_tp_cgrp_rmdir+0x188> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x168, 0x188, x86_l_188);
x86_l_16a:
	/* 0x16a: mov    edx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16c:
	/* 0x16c: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_16e:
	/* 0x16e: je     188 <tg_tp_cgrp_rmdir+0x188> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e, 0x188, x86_l_188);
x86_l_170:
	/* 0x170: shl    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_173:
	/* 0x173: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_176:
	/* 0x176: add    rax,0x80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 128ULL);
x86_l_17c:
	/* 0x17c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: jns    188 <tg_tp_cgrp_rmdir+0x188> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17f, 0x188, x86_l_188);
x86_l_181:
	/* 0x181: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_184:
	/* 0x184: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_188:
	/* 0x188: mov    DWORD PTR [r14+0x28],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_18c:
	/* 0x18c: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_191:
	/* 0x191: mov    QWORD PTR [r14+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_195:
	/* 0x195: mov    QWORD PTR [r14+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_199:
	/* 0x199: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_19c:
	/* 0x19c: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [r14+0x48],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1a3:
	/* 0x1a3: mov    eax,DWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a6:
	/* 0x1a6: mov    DWORD PTR [r14+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1aa:
	/* 0x1aa: mov    eax,DWORD PTR [rbp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ad:
	/* 0x1ad: mov    DWORD PTR [r14+0x4c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_1b1:
	/* 0x1b1: lea    rdi,[r15+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1b5:
	/* 0x1b5: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1b9:
	/* 0x1b9: mov    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_1be:
	/* 0x1be: rep movs DWORD PTR es:[rdi],DWORD PTR ds:[rsi] */
	X86_SIM_RUN_OP(X86_OP_REP_MOVS, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c0:
	/* 0x1c0: add    r15,0xd8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 216ULL);
x86_l_1c7:
	/* 0x1c7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1ca:
	/* 0x1ca: js     2a2 <tg_tp_cgrp_rmdir+0x2a2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ca, 0x2a2, x86_l_2a2);
x86_l_1d0:
	/* 0x1d0: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1d3:
	/* 0x1d3: mov    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_1d8:
	/* 0x1d8: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1db:
	/* 0x1db: call   1e0 <tg_tp_cgrp_rmdir+0x1e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_1e0:
	/* 0x1e0: jmp    2dc <tg_tp_cgrp_rmdir+0x2dc> */
	X86_SIM_X86_JMP(0x1e0, 0x2dc, x86_l_2dc);
x86_l_1e5:
	/* 0x1e5: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ec:
	/* 0x1ec: lea    rax,[r14+0xd8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1f3:
	/* 0x1f3: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f5:
	/* 0x1f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f8:
	/* 0x1f8: jns    1fc <tg_tp_cgrp_rmdir+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f8, 0x1fc, x86_l_1fc);
x86_l_1fa:
	/* 0x1fa: mov    ebx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc:
	/* 0x1fc: add    r14,0x2d0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 720ULL);
x86_l_203:
	/* 0x203: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_206:
	/* 0x206: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_209:
	/* 0x209: jns    210 <tg_tp_cgrp_rmdir+0x210> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x209, 0x210, x86_l_210);
x86_l_20b:
	/* 0x20b: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e:
	/* 0x20e: jmp    212 <tg_tp_cgrp_rmdir+0x212> */
	X86_SIM_X86_JMP(0x20e, 0x212, x86_l_212);
x86_l_210:
	/* 0x210: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212:
	/* 0x212: add    rax,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_216:
	/* 0x216: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: jns    21e <tg_tp_cgrp_rmdir+0x21e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x219, 0x21e, x86_l_21e);
x86_l_21b:
	/* 0x21b: mov    r15d,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e:
	/* 0x21e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_225:
	/* 0x225: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: call   22d <tg_tp_cgrp_rmdir+0x22d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22d:
	/* 0x22d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_230:
	/* 0x230: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x230, 0x28d, x86_l_28d);
x86_l_232:
	/* 0x232: mov    ecx,DWORD PTR [rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_235:
	/* 0x235: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_237:
	/* 0x237: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x237, 0x28d, x86_l_28d);
x86_l_239:
	/* 0x239: cmp    DWORD PTR [rax+0xc],r15d */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_23d:
	/* 0x23d: jne    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23d, 0x28d, x86_l_28d);
x86_l_23f:
	/* 0x23f: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_241:
	/* 0x241: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x241, 0x28d, x86_l_28d);
x86_l_243:
	/* 0x243: cmp    ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_245:
	/* 0x245: ja     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x245, 0x28d, x86_l_28d);
x86_l_247:
	/* 0x247: mov    DWORD PTR [rsp],0xd0002 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 851970ULL);
x86_l_24e:
	/* 0x24e: mov    QWORD PTR [rsp+0x4],0x27 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17179869223ULL);
x86_l_257:
	/* 0x257: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_25e:
	/* 0x25e: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_261:
	/* 0x261: call   266 <tg_tp_cgrp_rmdir+0x266> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_266:
	/* 0x266: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: je     26f <tg_tp_cgrp_rmdir+0x26f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x269, 0x26f, x86_l_26f);
x86_l_26b:
	/* 0x26b: inc    DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_26d:
	/* 0x26d: jmp    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JMP(0x26d, 0x28d, x86_l_28d);
x86_l_26f:
	/* 0x26f: mov    DWORD PTR [rsp+0xc],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607553ULL);
x86_l_277:
	/* 0x277: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_errmetrics_map));
x86_l_27e:
	/* 0x27e: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_281:
	/* 0x281: lea    rdx,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_286:
	/* 0x286: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_288:
	/* 0x288: call   28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_28d:
	/* 0x28d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28f:
	/* 0x28f: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_293:
	/* 0x293: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_294:
	/* 0x294: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_296:
	/* 0x296: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_298:
	/* 0x298: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29c:
	/* 0x29c: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29d:
	/* 0x29d: jmp    421 <tg_tp_cgrp_rmdir+0x421> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2a2:
	/* 0x2a2: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a5:
	/* 0x2a5: jns    2c3 <tg_tp_cgrp_rmdir+0x2c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a5, 0x2c3, x86_l_2c3);
x86_l_2a7:
	/* 0x2a7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a9:
	/* 0x2a9: cmp    rax,0xffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4094ULL);
x86_l_2af:
	/* 0x2af: je     2d4 <tg_tp_cgrp_rmdir+0x2d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2af, 0x2d4, x86_l_2d4);
x86_l_2b1:
	/* 0x2b1: movzx  ecx,BYTE PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_2b6:
	/* 0x2b6: mov    BYTE PTR [r15+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2ba:
	/* 0x2ba: inc    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_2bd:
	/* 0x2bd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2bf:
	/* 0x2bf: jne    2a9 <tg_tp_cgrp_rmdir+0x2a9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bf, 0x2a9, x86_l_2a9);
x86_l_2c1:
	/* 0x2c1: jmp    2dc <tg_tp_cgrp_rmdir+0x2dc> */
	X86_SIM_X86_JMP(0x2c1, 0x2dc, x86_l_2dc);
x86_l_2c3:
	/* 0x2c3: mov    edx,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_2c8:
	/* 0x2c8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2cb:
	/* 0x2cb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cd:
	/* 0x2cd: call   2d2 <tg_tp_cgrp_rmdir+0x2d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2d2:
	/* 0x2d2: jmp    2dc <tg_tp_cgrp_rmdir+0x2dc> */
	X86_SIM_X86_JMP(0x2d2, 0x2dc, x86_l_2dc);
x86_l_2d4:
	/* 0x2d4: mov    BYTE PTR [r14+0x10d6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18511309045760ULL);
x86_l_2dc:
	/* 0x2dc: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_2e4:
	/* 0x2e4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_2eb:
	/* 0x2eb: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2f0:
	/* 0x2f0: call   2f5 <tg_tp_cgrp_rmdir+0x2f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f5:
	/* 0x2f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f8:
	/* 0x2f8: je     36d <tg_tp_cgrp_rmdir+0x36d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f8, 0x36d, x86_l_36d);
x86_l_2fa:
	/* 0x2fa: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2fe:
	/* 0x2fe: je     36d <tg_tp_cgrp_rmdir+0x36d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fe, 0x36d, x86_l_36d);
x86_l_300:
	/* 0x300: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_307:
	/* 0x307: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_30c:
	/* 0x30c: mov    r8d,0x10d8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 4312ULL);
x86_l_312:
	/* 0x312: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_315:
	/* 0x315: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_318:
	/* 0x318: call   31d <tg_tp_cgrp_rmdir+0x31d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_31d:
	/* 0x31d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_320:
	/* 0x320: jns    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x320, 0x28d, x86_l_28d);
x86_l_326:
	/* 0x326: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_329:
	/* 0x329: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_330:
	/* 0x330: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_337:
	/* 0x337: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_33a:
	/* 0x33a: call   33f <tg_tp_cgrp_rmdir+0x33f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33f:
	/* 0x33f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_342:
	/* 0x342: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x342, 0x28d, x86_l_28d);
x86_l_348:
	/* 0x348: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_34c:
	/* 0x34c: jg     3e8 <tg_tp_cgrp_rmdir+0x3e8> */
	X86_SIM_X86_JCC(X86_CC_G, 0x34c, 0x3e8, x86_l_3e8);
x86_l_352:
	/* 0x352: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_356:
	/* 0x356: je     402 <tg_tp_cgrp_rmdir+0x402> */
	X86_SIM_X86_JCC(X86_CC_E, 0x356, 0x402, x86_l_402);
x86_l_35c:
	/* 0x35c: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_360:
	/* 0x360: jne    3c0 <tg_tp_cgrp_rmdir+0x3c0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x360, 0x3c0, x86_l_3c0);
x86_l_362:
	/* 0x362: add    rax,0x598 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1432ULL);
x86_l_368:
	/* 0x368: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x368, 0x418, x86_l_418);
x86_l_36d:
	/* 0x36d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_374:
	/* 0x374: mov    edx,0x10d8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4312ULL);
x86_l_379:
	/* 0x379: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_37c:
	/* 0x37c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37e:
	/* 0x37e: call   383 <tg_tp_cgrp_rmdir+0x383> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_383:
	/* 0x383: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_386:
	/* 0x386: jns    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x386, 0x28d, x86_l_28d);
x86_l_38c:
	/* 0x38c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38f:
	/* 0x38f: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_396:
	/* 0x396: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_39d:
	/* 0x39d: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_3a0:
	/* 0x3a0: call   3a5 <tg_tp_cgrp_rmdir+0x3a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3a5:
	/* 0x3a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a8:
	/* 0x3a8: je     28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a8, 0x28d, x86_l_28d);
x86_l_3ae:
	/* 0x3ae: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_3b2:
	/* 0x3b2: jg     3ce <tg_tp_cgrp_rmdir+0x3ce> */
	X86_SIM_X86_JCC(X86_CC_G, 0x3b2, 0x3ce, x86_l_3ce);
x86_l_3b4:
	/* 0x3b4: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_3b8:
	/* 0x3b8: je     402 <tg_tp_cgrp_rmdir+0x402> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b8, 0x402, x86_l_402);
x86_l_3ba:
	/* 0x3ba: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_3be:
	/* 0x3be: je     362 <tg_tp_cgrp_rmdir+0x362> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3be, 0x362, x86_l_362);
x86_l_3c0:
	/* 0x3c0: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_3c4:
	/* 0x3c4: jne    3fa <tg_tp_cgrp_rmdir+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c4, 0x3fa, x86_l_3fa);
x86_l_3c6:
	/* 0x3c6: add    rax,0x590 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1424ULL);
x86_l_3cc:
	/* 0x3cc: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x3cc, 0x418, x86_l_418);
x86_l_3ce:
	/* 0x3ce: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_3d2:
	/* 0x3d2: je     40a <tg_tp_cgrp_rmdir+0x40a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d2, 0x40a, x86_l_40a);
x86_l_3d4:
	/* 0x3d4: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_3d8:
	/* 0x3d8: je     412 <tg_tp_cgrp_rmdir+0x412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d8, 0x412, x86_l_412);
x86_l_3da:
	/* 0x3da: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_3de:
	/* 0x3de: jne    3fa <tg_tp_cgrp_rmdir+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3de, 0x3fa, x86_l_3fa);
x86_l_3e0:
	/* 0x3e0: add    rax,0x580 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1408ULL);
x86_l_3e6:
	/* 0x3e6: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x3e6, 0x418, x86_l_418);
x86_l_3e8:
	/* 0x3e8: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_3ec:
	/* 0x3ec: je     40a <tg_tp_cgrp_rmdir+0x40a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3ec, 0x40a, x86_l_40a);
x86_l_3ee:
	/* 0x3ee: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_3f2:
	/* 0x3f2: je     412 <tg_tp_cgrp_rmdir+0x412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f2, 0x412, x86_l_412);
x86_l_3f4:
	/* 0x3f4: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_3f8:
	/* 0x3f8: je     3e0 <tg_tp_cgrp_rmdir+0x3e0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f8, 0x3e0, x86_l_3e0);
x86_l_3fa:
	/* 0x3fa: add    rax,0x578 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1400ULL);
x86_l_400:
	/* 0x400: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x400, 0x418, x86_l_418);
x86_l_402:
	/* 0x402: add    rax,0x5a0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1440ULL);
x86_l_408:
	/* 0x408: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x408, 0x418, x86_l_418);
x86_l_40a:
	/* 0x40a: add    rax,0x5a8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1448ULL);
x86_l_410:
	/* 0x410: jmp    418 <tg_tp_cgrp_rmdir+0x418> */
	X86_SIM_X86_JMP(0x410, 0x418, x86_l_418);
x86_l_412:
	/* 0x412: add    rax,0x588 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1416ULL);
x86_l_418:
	/* 0x418: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_41c:
	/* 0x41c: jmp    28d <tg_tp_cgrp_rmdir+0x28d> */
	X86_SIM_X86_JMP(0x41c, 0x28d, x86_l_28d);
x86_l_421:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
