#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(10) M(11) M(12) M(14) M(21) M(22) M(23) M(24)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 fexit_calls[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ANDN_MEM, X86_OP_ANDN_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_REG, X86_OP_TEST_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("fexit/generic_fexit_tail")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25:
	/* 0x25: call   2a <generic_fexit_filter_arg+0x2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     375 <generic_fexit_filter_arg+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x375, x86_l_375);
x86_l_33:
	/* 0x33: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: mov    r12d,DWORD PTR [rax+0x5f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_3d:
	/* 0x3d: lea    rsi,[rax+0x5ef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_4b:
	/* 0x4b: call   50 <generic_fexit_filter_arg+0x50> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_50:
	/* 0x50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: je     361 <generic_fexit_filter_arg+0x361> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53, 0x361, x86_l_361);
x86_l_59:
	/* 0x59: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_61:
	/* 0x61: je     361 <generic_fexit_filter_arg+0x361> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61, 0x361, x86_l_361);
x86_l_67:
	/* 0x67: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6a:
	/* 0x6a: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_6d:
	/* 0x6d: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_70:
	/* 0x70: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_79:
	/* 0x79: je     b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x79, 0xb3, x86_l_b3);
x86_l_7b:
	/* 0x7b: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_7d:
	/* 0x7d: mov    ecx,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_82:
	/* 0x82: lea    r13,[rcx+rax*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_86:
	/* 0x86: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_8a:
	/* 0x8a: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_8d:
	/* 0x8d: mov    QWORD PTR [rsp+0x10],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_92:
	/* 0x92: and    r13d,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_99:
	/* 0x99: cmp    DWORD PTR [r15+r13*1],0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 25ULL);
x86_l_9e:
	/* 0x9e: jae    108 <generic_fexit_filter_arg+0x108> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x9e, 0x108, x86_l_108);
x86_l_a0:
	/* 0xa0: cmp    r13,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_a4:
	/* 0xa4: je     361 <generic_fexit_filter_arg+0x361> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa4, 0x361, x86_l_361);
x86_l_aa:
	/* 0xaa: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_ad:
	/* 0xad: jne    346 <generic_fexit_filter_arg+0x346> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xad, 0x346, x86_l_346);
x86_l_b3:
	/* 0xb3: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b7:
	/* 0xb7: jg     d8 <generic_fexit_filter_arg+0xd8> */
	X86_SIM_X86_JCC(X86_CC_G, 0xb7, 0xd8, x86_l_d8);
x86_l_b9:
	/* 0xb9: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_bd:
	/* 0xbd: je     38a <generic_fexit_filter_arg+0x38a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd, 0x38a, x86_l_38a);
x86_l_c3:
	/* 0xc3: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_c6:
	/* 0xc6: je     397 <generic_fexit_filter_arg+0x397> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6, 0x397, x86_l_397);
x86_l_cc:
	/* 0xcc: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d0:
	/* 0xd0: je     3a7 <generic_fexit_filter_arg+0x3a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd0, 0x3a7, x86_l_3a7);
x86_l_d6:
	/* 0xd6: jmp    f6 <generic_fexit_filter_arg+0xf6> */
	X86_SIM_X86_JMP(0xd6, 0xf6, x86_l_f6);
x86_l_d8:
	/* 0xd8: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_dc:
	/* 0xdc: je     3b7 <generic_fexit_filter_arg+0x3b7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdc, 0x3b7, x86_l_3b7);
x86_l_e2:
	/* 0xe2: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_e6:
	/* 0xe6: je     3c7 <generic_fexit_filter_arg+0x3c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe6, 0x3c7, x86_l_3c7);
x86_l_ec:
	/* 0xec: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_f0:
	/* 0xf0: je     3d7 <generic_fexit_filter_arg+0x3d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0, 0x3d7, x86_l_3d7);
x86_l_f6:
	/* 0xf6: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_fa:
	/* 0xfa: jg     402 <generic_fexit_filter_arg+0x402> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfa, 0x402, x86_l_402);
x86_l_100:
	/* 0x100: inc    r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_103:
	/* 0x103: jmp    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JMP(0x103, 0x3e7, x86_l_3e7);
x86_l_108:
	/* 0x108: lea    rax,[r15+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_10c:
	/* 0x10c: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_111:
	/* 0x111: mov    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_116:
	/* 0x116: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11b:
	/* 0x11b: mov    edi,DWORD PTR [rax+rbp*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 2), 0ULL);
x86_l_11e:
	/* 0x11e: test   edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 1023ULL);
x86_l_124:
	/* 0x124: je     a0 <generic_fexit_filter_arg+0xa0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x124, 0xa0, x86_l_a0);
x86_l_12a:
	/* 0x12a: add    edi,DWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_12e:
	/* 0x12e: and    edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_134:
	/* 0x134: mov    ecx,DWORD PTR [r15+rdi*1+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 4ULL);
x86_l_139:
	/* 0x139: cmp    ecx,0x23 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_13c:
	/* 0x13c: je     b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c, 0xb3, x86_l_b3);
x86_l_142:
	/* 0x142: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_145:
	/* 0x145: mov    eax,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_147:
	/* 0x147: cmp    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_14b:
	/* 0x14b: ja     b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14b, 0xb3, x86_l_b3);
x86_l_151:
	/* 0x151: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_15a:
	/* 0x15a: jne    b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15a, 0xb3, x86_l_b3);
x86_l_160:
	/* 0x160: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_168:
	/* 0x168: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_16d:
	/* 0x16d: lea    rsi,[r14+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_171:
	/* 0x171: add    rsi,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_178:
	/* 0x178: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_17b:
	/* 0x17b: cmp    eax,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_17e:
	/* 0x17e: jle    19f <generic_fexit_filter_arg+0x19f> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x17e, 0x19f, x86_l_19f);
x86_l_180:
	/* 0x180: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_183:
	/* 0x183: jg     1cf <generic_fexit_filter_arg+0x1cf> */
	X86_SIM_X86_JCC(X86_CC_G, 0x183, 0x1cf, x86_l_1cf);
x86_l_185:
	/* 0x185: lea    edx,[rax-0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_188:
	/* 0x188: cmp    edx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_18b:
	/* 0x18b: jb     215 <generic_fexit_filter_arg+0x215> */
	X86_SIM_X86_JCC(X86_CC_B, 0x18b, 0x215, x86_l_215);
x86_l_191:
	/* 0x191: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_194:
	/* 0x194: je     2f8 <generic_fexit_filter_arg+0x2f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194, 0x2f8, x86_l_2f8);
x86_l_19a:
	/* 0x19a: jmp    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JMP(0x19a, 0x334, x86_l_334);
x86_l_19f:
	/* 0x19f: cmp    eax,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1a2:
	/* 0x1a2: jle    1f5 <generic_fexit_filter_arg+0x1f5> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1a2, 0x1f5, x86_l_1f5);
x86_l_1a4:
	/* 0x1a4: lea    edx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_1a7:
	/* 0x1a7: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1aa:
	/* 0x1aa: jb     215 <generic_fexit_filter_arg+0x215> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1aa, 0x215, x86_l_215);
x86_l_1ac:
	/* 0x1ac: lea    ecx,[rax-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_1af:
	/* 0x1af: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b2:
	/* 0x1b2: jb     2f8 <generic_fexit_filter_arg+0x2f8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b2, 0x2f8, x86_l_2f8);
x86_l_1b8:
	/* 0x1b8: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1bb:
	/* 0x1bb: jne    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bb, 0x334, x86_l_334);
x86_l_1c1:
	/* 0x1c1: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1c5:
	/* 0x1c5: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_445, 0x1caULL);
x86_l_1ca:
	/* 0x1ca: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x1ca, 0x32b, x86_l_32b);
x86_l_1cf:
	/* 0x1cf: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_1d2:
	/* 0x1d2: jg     2e7 <generic_fexit_filter_arg+0x2e7> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1d2, 0x2e7, x86_l_2e7);
x86_l_1d8:
	/* 0x1d8: lea    ecx,[rax-0x26] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_1db:
	/* 0x1db: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1de:
	/* 0x1de: jb     2a2 <generic_fexit_filter_arg+0x2a2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1de, 0x2a2, x86_l_2a2);
x86_l_1e4:
	/* 0x1e4: add    eax,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967256ULL);
x86_l_1e7:
	/* 0x1e7: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ea:
	/* 0x1ea: jb     298 <generic_fexit_filter_arg+0x298> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ea, 0x298, x86_l_298);
x86_l_1f0:
	/* 0x1f0: jmp    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JMP(0x1f0, 0x334, x86_l_334);
x86_l_1f5:
	/* 0x1f5: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1f8:
	/* 0x1f8: jg     285 <generic_fexit_filter_arg+0x285> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1f8, 0x285, x86_l_285);
x86_l_1fe:
	/* 0x1fe: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_201:
	/* 0x201: je     215 <generic_fexit_filter_arg+0x215> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201, 0x215, x86_l_215);
x86_l_203:
	/* 0x203: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_206:
	/* 0x206: je     315 <generic_fexit_filter_arg+0x315> */
	X86_SIM_X86_JCC(X86_CC_E, 0x206, 0x315, x86_l_315);
x86_l_20c:
	/* 0x20c: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_20f:
	/* 0x20f: jne    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20f, 0x334, x86_l_334);
x86_l_215:
	/* 0x215: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_218:
	/* 0x218: jle    262 <generic_fexit_filter_arg+0x262> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x218, 0x262, x86_l_262);
x86_l_21a:
	/* 0x21a: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_21d:
	/* 0x21d: ja     2ff <generic_fexit_filter_arg+0x2ff> */
	X86_SIM_X86_JCC(X86_CC_A, 0x21d, 0x2ff, x86_l_2ff);
x86_l_223:
	/* 0x223: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_225:
	/* 0x225: movabs r8,0x1e00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 128849018880ULL);
x86_l_22f:
	/* 0x22f: bt     r8,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_233:
	/* 0x233: jb     2a9 <generic_fexit_filter_arg+0x2a9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x233, 0x2a9, x86_l_2a9);
x86_l_235:
	/* 0x235: mov    ecx,0x60000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1610612736ULL);
x86_l_23a:
	/* 0x23a: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23e:
	/* 0x23e: jb     30e <generic_fexit_filter_arg+0x30e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x23e, 0x30e, x86_l_30e);
x86_l_244:
	/* 0x244: movabs rcx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_24e:
	/* 0x24e: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_252:
	/* 0x252: jae    2ff <generic_fexit_filter_arg+0x2ff> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x252, 0x2ff, x86_l_2ff);
x86_l_258:
	/* 0x258: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_508, 0x25dULL);
x86_l_25d:
	/* 0x25d: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x25d, 0x32b, x86_l_32b);
x86_l_262:
	/* 0x262: lea    ecx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_265:
	/* 0x265: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_268:
	/* 0x268: jb     326 <generic_fexit_filter_arg+0x326> */
	X86_SIM_X86_JCC(X86_CC_B, 0x268, 0x326, x86_l_326);
x86_l_26e:
	/* 0x26e: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_271:
	/* 0x271: je     307 <generic_fexit_filter_arg+0x307> */
	X86_SIM_X86_JCC(X86_CC_E, 0x271, 0x307, x86_l_307);
x86_l_277:
	/* 0x277: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_27a:
	/* 0x27a: je     307 <generic_fexit_filter_arg+0x307> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a, 0x307, x86_l_307);
x86_l_280:
	/* 0x280: jmp    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JMP(0x280, 0x334, x86_l_334);
x86_l_285:
	/* 0x285: cmp    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_288:
	/* 0x288: je     298 <generic_fexit_filter_arg+0x298> */
	X86_SIM_X86_JCC(X86_CC_E, 0x288, 0x298, x86_l_298);
x86_l_28a:
	/* 0x28a: cmp    eax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_28d:
	/* 0x28d: je     2a2 <generic_fexit_filter_arg+0x2a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28d, 0x2a2, x86_l_2a2);
x86_l_28f:
	/* 0x28f: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_292:
	/* 0x292: jne    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x292, 0x334, x86_l_334);
x86_l_298:
	/* 0x298: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_54f, 0x29dULL);
x86_l_29d:
	/* 0x29d: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x29d, 0x32b, x86_l_32b);
x86_l_2a2:
	/* 0x2a2: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2a7:
	/* 0x2a7: jmp    31a <generic_fexit_filter_arg+0x31a> */
	X86_SIM_X86_JMP(0x2a7, 0x31a, x86_l_31a);
x86_l_2a9:
	/* 0x2a9: cmp    ecx,0x1e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_2ac:
	/* 0x2ac: jne    326 <generic_fexit_filter_arg+0x326> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ac, 0x326, x86_l_326);
x86_l_2ae:
	/* 0x2ae: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b1:
	/* 0x2b1: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_2b4:
	/* 0x2b4: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2b6:
	/* 0x2b6: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_2bf:
	/* 0x2bf: jne    b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bf, 0xb3, x86_l_b3);
x86_l_2c5:
	/* 0x2c5: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8:
	/* 0x2c8: mov    rdx,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_2d0:
	/* 0x2d0: and    edx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_2d6:
	/* 0x2d6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d8:
	/* 0x2d8: andn   rcx,rcx,QWORD PTR [r14+rdx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_ANDN_MEM, X86_RCX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 618475290624ULL);
x86_l_2e2:
	/* 0x2e2: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2e5:
	/* 0x2e5: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x2e5, 0x32b, x86_l_32b);
x86_l_2e7:
	/* 0x2e7: cmp    eax,0x2a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 42ULL);
x86_l_2ea:
	/* 0x2ea: je     2f8 <generic_fexit_filter_arg+0x2f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ea, 0x2f8, x86_l_2f8);
x86_l_2ec:
	/* 0x2ec: cmp    eax,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_2ef:
	/* 0x2ef: jne    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ef, 0x334, x86_l_334);
x86_l_2f1:
	/* 0x2f1: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_887, 0x2f6ULL);
x86_l_2f6:
	/* 0x2f6: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x2f6, 0x32b, x86_l_32b);
x86_l_2f8:
	/* 0x2f8: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_445, 0x2fdULL);
x86_l_2fd:
	/* 0x2fd: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x2fd, 0x32b, x86_l_32b);
x86_l_2ff:
	/* 0x2ff: lea    ecx,[rax-0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_302:
	/* 0x302: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_305:
	/* 0x305: jae    321 <generic_fexit_filter_arg+0x321> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x305, 0x321, x86_l_321);
x86_l_307:
	/* 0x307: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_932, 0x30cULL);
x86_l_30c:
	/* 0x30c: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x30c, 0x32b, x86_l_32b);
x86_l_30e:
	/* 0x30e: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_979, 0x313ULL);
x86_l_313:
	/* 0x313: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x313, 0x32b, x86_l_32b);
x86_l_315:
	/* 0x315: mov    edx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_31a:
	/* 0x31a: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_9c0, 0x31fULL);
x86_l_31f:
	/* 0x31f: jmp    32b <generic_fexit_filter_arg+0x32b> */
	X86_SIM_X86_JMP(0x31f, 0x32b, x86_l_32b);
x86_l_321:
	/* 0x321: cmp    eax,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_324:
	/* 0x324: jne    334 <generic_fexit_filter_arg+0x334> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x324, 0x334, x86_l_334);
x86_l_326:
	/* 0x326: call   0 <generic_fexit_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a63, 0x32bULL);
x86_l_32b:
	/* 0x32b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32e:
	/* 0x32e: je     b3 <generic_fexit_filter_arg+0xb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32e, 0xb3, x86_l_b3);
x86_l_334:
	/* 0x334: inc    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_337:
	/* 0x337: cmp    rbp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 6ULL);
x86_l_33b:
	/* 0x33b: jne    116 <generic_fexit_filter_arg+0x116> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33b, 0x116, x86_l_116);
x86_l_341:
	/* 0x341: jmp    a0 <generic_fexit_filter_arg+0xa0> */
	X86_SIM_X86_JMP(0x341, 0xa0, x86_l_a0);
x86_l_346:
	/* 0x346: mov    DWORD PTR [r14+0x5f04],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_34d:
	/* 0x34d: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fexit_calls));
x86_l_354:
	/* 0x354: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_357:
	/* 0x357: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_35c:
	/* 0x35c: call   361 <generic_fexit_filter_arg+0x361> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_361:
	/* 0x361: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fexit_calls));
x86_l_368:
	/* 0x368: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_36b:
	/* 0x36b: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_370:
	/* 0x370: call   375 <generic_fexit_filter_arg+0x375> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_375:
	/* 0x375: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_377:
	/* 0x377: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_37b:
	/* 0x37b: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_37c:
	/* 0x37c: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_37e:
	/* 0x37e: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_380:
	/* 0x380: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_382:
	/* 0x382: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_384:
	/* 0x384: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_385:
	/* 0x385: jmp    2637 <filter_file_type+0xb9> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_38a:
	/* 0x38a: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38d:
	/* 0x38d: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_395:
	/* 0x395: jne    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x395, 0x3e7, x86_l_3e7);
x86_l_397:
	/* 0x397: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_39d:
	/* 0x39d: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_3a5:
	/* 0x3a5: jne    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a5, 0x3e7, x86_l_3e7);
x86_l_3a7:
	/* 0x3a7: mov    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3ad:
	/* 0x3ad: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_3b5:
	/* 0x3b5: jne    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b5, 0x3e7, x86_l_3e7);
x86_l_3b7:
	/* 0x3b7: mov    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_3bd:
	/* 0x3bd: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_3c5:
	/* 0x3c5: jne    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c5, 0x3e7, x86_l_3e7);
x86_l_3c7:
	/* 0x3c7: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3cd:
	/* 0x3cd: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_3d5:
	/* 0x3d5: jne    3e7 <generic_fexit_filter_arg+0x3e7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d5, 0x3e7, x86_l_3e7);
x86_l_3d7:
	/* 0x3d7: mov    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3dd:
	/* 0x3dd: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_3e5:
	/* 0x3e5: je     402 <generic_fexit_filter_arg+0x402> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e5, 0x402, x86_l_402);
x86_l_3e7:
	/* 0x3e7: mov    DWORD PTR [r14+0x5f00],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_3ee:
	/* 0x3ee: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fexit_calls));
x86_l_3f5:
	/* 0x3f5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3f8:
	/* 0x3f8: mov    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_3fd:
	/* 0x3fd: call   402 <generic_fexit_filter_arg+0x402> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_402:
	/* 0x402: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_406:
	/* 0x406: call   40b <generic_fexit_filter_arg+0x40b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_40b:
	/* 0x40b: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_410:
	/* 0x410: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_415:
	/* 0x415: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_41c:
	/* 0x41c: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_421:
	/* 0x421: call   426 <generic_fexit_filter_arg+0x426> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_426:
	/* 0x426: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_429:
	/* 0x429: je     375 <generic_fexit_filter_arg+0x375> */
	X86_SIM_X86_JCC(X86_CC_E, 0x429, 0x375, x86_l_375);
x86_l_42f:
	/* 0x42f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_436:
	/* 0x436: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_43b:
	/* 0x43b: call   440 <generic_fexit_filter_arg+0x440> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_440:
	/* 0x440: jmp    375 <generic_fexit_filter_arg+0x375> */
	X86_SIM_X86_JMP(0x440, 0x375, x86_l_375);
x86_l_2637:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_445 */
x86_l_445:
	/* 0x445: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_446:
	/* 0x446: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_449:
	/* 0x449: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44b:
	/* 0x44b: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_44e:
	/* 0x44e: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_450:
	/* 0x450: jne    460 <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x450, 0x460, x86_l_460);
x86_l_452:
	/* 0x452: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_454:
	/* 0x454: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_457:
	/* 0x457: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_45a:
	/* 0x45a: je     460 <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x45a, 0x460, x86_l_460);
x86_l_45c:
	/* 0x45c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_45e:
	/* 0x45e: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_45f:
	/* 0x45f: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_45f);
x86_l_460:
	/* 0x460: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_463:
	/* 0x463: ja     49f <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x463, 0x49f, x86_l_49f);
x86_l_465:
	/* 0x465: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_467:
	/* 0x467: mov    edi,0x4000100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 67109120ULL);
x86_l_46c:
	/* 0x46c: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_470:
	/* 0x470: jb     4d3 <filter_file_buf+0x8e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x470, 0x4d3, x86_l_4d3);
x86_l_472:
	/* 0x472: mov    edi,0x8000200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 134218240ULL);
x86_l_477:
	/* 0x477: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_47b:
	/* 0x47b: jb     4bd <filter_file_buf+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x47b, 0x4bd, x86_l_4bd);
x86_l_47d:
	/* 0x47d: movabs rdi,0x3000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, 206158430208ULL);
x86_l_487:
	/* 0x487: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_48b:
	/* 0x48b: jae    49f <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x48b, 0x49f, x86_l_49f);
x86_l_48d:
	/* 0x48d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_490:
	/* 0x490: call   257e <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_257e, 0x495ULL);
x86_l_495:
	/* 0x495: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_498:
	/* 0x498: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_49b:
	/* 0x49b: jbe    4f0 <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x49b, 0x4f0, x86_l_4f0);
x86_l_49d:
	/* 0x49d: jmp    506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x49d, 0x506, x86_l_506);
x86_l_49f:
	/* 0x49f: lea    eax,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_4a2:
	/* 0x4a2: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_4a5:
	/* 0x4a5: jae    4e9 <filter_file_buf+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x4a5, 0x4e9, x86_l_4e9);
x86_l_4a7:
	/* 0x4a7: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4ab:
	/* 0x4ab: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: call   1191 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1191, 0x4b3ULL);
x86_l_4b3:
	/* 0x4b3: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4b6:
	/* 0x4b6: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4b9:
	/* 0x4b9: jbe    4f0 <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4b9, 0x4f0, x86_l_4f0);
x86_l_4bb:
	/* 0x4bb: jmp    506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x4bb, 0x506, x86_l_506);
x86_l_4bd:
	/* 0x4bd: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4c1:
	/* 0x4c1: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4c4:
	/* 0x4c4: call   f2b <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_f2b, 0x4c9ULL);
x86_l_4c9:
	/* 0x4c9: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4cc:
	/* 0x4cc: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4cf:
	/* 0x4cf: jbe    4f0 <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4cf, 0x4f0, x86_l_4f0);
x86_l_4d1:
	/* 0x4d1: jmp    506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x4d1, 0x506, x86_l_506);
x86_l_4d3:
	/* 0x4d3: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_4d7:
	/* 0x4d7: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4da:
	/* 0x4da: call   106e <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_106e, 0x4dfULL);
x86_l_4df:
	/* 0x4df: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4e2:
	/* 0x4e2: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4e5:
	/* 0x4e5: jbe    4f0 <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x4e5, 0x4f0, x86_l_4f0);
x86_l_4e7:
	/* 0x4e7: jmp    506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x4e7, 0x506, x86_l_506);
x86_l_4e9:
	/* 0x4e9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4eb:
	/* 0x4eb: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4ee:
	/* 0x4ee: ja     506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4ee, 0x506, x86_l_506);
x86_l_4f0:
	/* 0x4f0: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4f2:
	/* 0x4f2: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_4fc:
	/* 0x4fc: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_500:
	/* 0x500: jae    506 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x500, 0x506, x86_l_506);
x86_l_502:
	/* 0x502: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_506:
	/* 0x506: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_507:
	/* 0x507: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_45f);

	/* native subroutine native_link_sub_508 */
x86_l_508:
	/* 0x508: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_509:
	/* 0x509: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_50c:
	/* 0x50c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_50e:
	/* 0x50e: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_512:
	/* 0x512: ja     54d <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x512, 0x54d, x86_l_54d);
x86_l_514:
	/* 0x514: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_519:
	/* 0x519: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_51d:
	/* 0x51d: jae    526 <filter_8ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x51d, 0x526, x86_l_526);
x86_l_51f:
	/* 0x51f: call   212a <filter_8ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_212a, 0x524ULL);
x86_l_524:
	/* 0x524: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_525:
	/* 0x525: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_525);
x86_l_526:
	/* 0x526: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_52b:
	/* 0x52b: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_52f:
	/* 0x52f: jb     548 <filter_8ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x52f, 0x548, x86_l_548);
x86_l_531:
	/* 0x531: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_53b:
	/* 0x53b: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_53f:
	/* 0x53f: jae    54d <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x53f, 0x54d, x86_l_54d);
x86_l_541:
	/* 0x541: call   2344 <filter_8ty_range> */
	X86_SIM_X86_CALL(x86_l_2344, 0x546ULL);
x86_l_546:
	/* 0x546: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_547:
	/* 0x547: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_525);
x86_l_548:
	/* 0x548: call   24fc <filter_8ty_map> */
	X86_SIM_X86_CALL(x86_l_24fc, 0x54dULL);
x86_l_54d:
	/* 0x54d: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_54e:
	/* 0x54e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_525);

	/* native subroutine native_link_sub_54f */
x86_l_54f:
	/* 0x54f: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_551:
	/* 0x551: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_553:
	/* 0x553: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_555:
	/* 0x555: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_556:
	/* 0x556: sub    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_55a:
	/* 0x55a: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_563:
	/* 0x563: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_56c:
	/* 0x56c: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_575:
	/* 0x575: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_57e:
	/* 0x57e: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_587:
	/* 0x587: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_58e:
	/* 0x58e: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_596:
	/* 0x596: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_599:
	/* 0x599: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_59b:
	/* 0x59b: cmp    edx,0x27 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 39ULL);
x86_l_59e:
	/* 0x59e: jg     5b6 <filter_inet+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x59e, 0x5b6, x86_l_5b6);
x86_l_5a0:
	/* 0x5a0: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_5a3:
	/* 0x5a3: je     63b <filter_inet+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5a3, 0x63b, x86_l_63b);
x86_l_5a9:
	/* 0x5a9: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5ac:
	/* 0x5ac: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_5af:
	/* 0x5af: je     5c7 <filter_inet+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5af, 0x5c7, x86_l_5c7);
x86_l_5b1:
	/* 0x5b1: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x5b1, 0x843, x86_l_843);
x86_l_5b6:
	/* 0x5b6: cmp    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_5b9:
	/* 0x5b9: je     613 <filter_inet+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5b9, 0x613, x86_l_613);
x86_l_5bb:
	/* 0x5bb: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_5be:
	/* 0x5be: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_5c1:
	/* 0x5c1: jne    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x5c1, 0x843, x86_l_843);
x86_l_5c7:
	/* 0x5c7: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5ca:
	/* 0x5ca: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5cc:
	/* 0x5cc: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_5cf:
	/* 0x5cf: jle    648 <filter_inet+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x5cf, 0x648, x86_l_648);
x86_l_5d1:
	/* 0x5d1: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_5d4:
	/* 0x5d4: jg     5f3 <filter_inet+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x5d4, 0x5f3, x86_l_5f3);
x86_l_5d6:
	/* 0x5d6: lea    edx,[rcx-0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_5d9:
	/* 0x5d9: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5dc:
	/* 0x5dc: jb     699 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x5dc, 0x699, x86_l_699);
x86_l_5e2:
	/* 0x5e2: lea    edx,[rcx-0x16] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_5e5:
	/* 0x5e5: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5e8:
	/* 0x5e8: jb     693 <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x5e8, 0x693, x86_l_693);
x86_l_5ee:
	/* 0x5ee: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x5ee, 0x843, x86_l_843);
x86_l_5f3:
	/* 0x5f3: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_5f6:
	/* 0x5f6: jg     6d6 <filter_inet+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x5f6, 0x6d6, x86_l_6d6);
x86_l_5fc:
	/* 0x5fc: cmp    ecx,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_5ff:
	/* 0x5ff: je     709 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x5ff, 0x709, x86_l_709);
x86_l_605:
	/* 0x605: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_608:
	/* 0x608: je     6ff <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x608, 0x6ff, x86_l_6ff);
x86_l_60e:
	/* 0x60e: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x60e, 0x843, x86_l_843);
x86_l_613:
	/* 0x613: movzx  eax,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_616:
	/* 0x616: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_61b:
	/* 0x61b: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_61f:
	/* 0x61f: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_624:
	/* 0x624: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_628:
	/* 0x628: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_62d:
	/* 0x62d: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_631:
	/* 0x631: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_636:
	/* 0x636: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_63b:
	/* 0x63b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_63e:
	/* 0x63e: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_641:
	/* 0x641: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_643:
	/* 0x643: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_646:
	/* 0x646: jg     5d1 <filter_inet+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x646, 0x5d1, x86_l_5d1);
x86_l_648:
	/* 0x648: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_64b:
	/* 0x64b: jle    669 <filter_inet+0x11a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x64b, 0x669, x86_l_669);
x86_l_64d:
	/* 0x64d: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_650:
	/* 0x650: jg     685 <filter_inet+0x136> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x650, 0x685, x86_l_685);
x86_l_652:
	/* 0x652: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_655:
	/* 0x655: je     693 <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x655, 0x693, x86_l_693);
x86_l_657:
	/* 0x657: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_65a:
	/* 0x65a: jne    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x65a, 0x843, x86_l_843);
x86_l_660:
	/* 0x660: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_664:
	/* 0x664: jmp    838 <filter_inet+0x2e9> */
	X86_SIM_X86_SUB_JMP(0x664, 0x838, x86_l_838);
x86_l_669:
	/* 0x669: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_66c:
	/* 0x66c: je     709 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x66c, 0x709, x86_l_709);
x86_l_672:
	/* 0x672: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_675:
	/* 0x675: je     6ff <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x675, 0x6ff, x86_l_6ff);
x86_l_67b:
	/* 0x67b: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_67e:
	/* 0x67e: je     699 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x67e, 0x699, x86_l_699);
x86_l_680:
	/* 0x680: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x680, 0x843, x86_l_843);
x86_l_685:
	/* 0x685: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_688:
	/* 0x688: je     699 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x688, 0x699, x86_l_699);
x86_l_68a:
	/* 0x68a: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_68d:
	/* 0x68d: jne    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x68d, 0x843, x86_l_843);
x86_l_693:
	/* 0x693: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_697:
	/* 0x697: jmp    69d <filter_inet+0x14e> */
	X86_SIM_X86_SUB_JMP(0x697, 0x69d, x86_l_69d);
x86_l_699:
	/* 0x699: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_69d:
	/* 0x69d: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_6a1:
	/* 0x6a1: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a3:
	/* 0x6a3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a6:
	/* 0x6a6: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6a9:
	/* 0x6a9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ab:
	/* 0x6ab: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6ae:
	/* 0x6ae: jg     720 <filter_inet+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6ae, 0x720, x86_l_720);
x86_l_6b0:
	/* 0x6b0: lea    edx,[rcx-0xd] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_6b3:
	/* 0x6b3: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_6b6:
	/* 0x6b6: jb     747 <filter_inet+0x1f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x6b6, 0x747, x86_l_747);
x86_l_6bc:
	/* 0x6bc: lea    edx,[rcx-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_6bf:
	/* 0x6bf: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_6c2:
	/* 0x6c2: jb     797 <filter_inet+0x248> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x6c2, 0x797, x86_l_797);
x86_l_6c8:
	/* 0x6c8: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6cb:
	/* 0x6cb: je     83b <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6cb, 0x83b, x86_l_83b);
x86_l_6d1:
	/* 0x6d1: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x6d1, 0x843, x86_l_843);
x86_l_6d6:
	/* 0x6d6: cmp    ecx,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_6d9:
	/* 0x6d9: je     834 <filter_inet+0x2e5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6d9, 0x834, x86_l_834);
x86_l_6df:
	/* 0x6df: cmp    ecx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_6e2:
	/* 0x6e2: jne    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6e2, 0x843, x86_l_843);
x86_l_6e8:
	/* 0x6e8: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_6eb:
	/* 0x6eb: jne    867 <filter_inet+0x318> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6eb, 0x867, x86_l_867);
x86_l_6f1:
	/* 0x6f1: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_6f4:
	/* 0x6f4: jne    871 <filter_inet+0x322> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6f4, 0x871, x86_l_871);
x86_l_6fa:
	/* 0x6fa: jmp    83b <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JMP(0x6fa, 0x83b, x86_l_83b);
x86_l_6ff:
	/* 0x6ff: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_703:
	/* 0x703: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_707:
	/* 0x707: jmp    710 <filter_inet+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x707, 0x710, x86_l_710);
x86_l_709:
	/* 0x709: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_70c:
	/* 0x70c: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_710:
	/* 0x710: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_713:
	/* 0x713: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_717:
	/* 0x717: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_719:
	/* 0x719: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71b:
	/* 0x71b: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_71e:
	/* 0x71e: jle    6b0 <filter_inet+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x71e, 0x6b0, x86_l_6b0);
x86_l_720:
	/* 0x720: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_723:
	/* 0x723: ja     78b <filter_inet+0x23c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x723, 0x78b, x86_l_78b);
x86_l_725:
	/* 0x725: mov    r8d,0x500000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 5242880ULL);
x86_l_72b:
	/* 0x72b: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_72f:
	/* 0x72f: jb     7a1 <filter_inet+0x252> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x72f, 0x7a1, x86_l_7a1);
x86_l_731:
	/* 0x731: mov    r8d,0xa00000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 10485760ULL);
x86_l_737:
	/* 0x737: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_73b:
	/* 0x73b: jb     7b1 <filter_inet+0x262> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x73b, 0x7b1, x86_l_7b1);
x86_l_73d:
	/* 0x73d: mov    edx,0x3000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 50331648ULL);
x86_l_742:
	/* 0x742: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_745:
	/* 0x745: jae    78b <filter_inet+0x23c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x745, 0x78b, x86_l_78b);
x86_l_747:
	/* 0x747: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_74b:
	/* 0x74b: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_74e:
	/* 0x74e: je     7c1 <filter_inet+0x272> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x74e, 0x7c1, x86_l_7c1);
x86_l_750:
	/* 0x750: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_753:
	/* 0x753: jne    82d <filter_inet+0x2de> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x753, 0x82d, x86_l_82d);
x86_l_759:
	/* 0x759: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_75c:
	/* 0x75c: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75f:
	/* 0x75f: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_763:
	/* 0x763: mov    rdi,QWORD PTR [rip+0x17f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr4lpm_maps));
x86_l_76a:
	/* 0x76a: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_76f:
	/* 0x76f: call   1f64 <filter_32ty_range+0x71> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_774:
	/* 0x774: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_777:
	/* 0x777: je     84f <filter_inet+0x300> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x777, 0x84f, x86_l_84f);
x86_l_77d:
	/* 0x77d: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_785:
	/* 0x785: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_789:
	/* 0x789: jmp    800 <filter_inet+0x2b1> */
	X86_SIM_X86_SUB_JMP(0x789, 0x800, x86_l_800);
x86_l_78b:
	/* 0x78b: add    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_78e:
	/* 0x78e: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_791:
	/* 0x791: jae    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x791, 0x843, x86_l_843);
x86_l_797:
	/* 0x797: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_79c:
	/* 0x79c: jmp    83e <filter_inet+0x2ef> */
	X86_SIM_X86_SUB_JMP(0x79c, 0x83e, x86_l_83e);
x86_l_7a1:
	/* 0x7a1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7a3:
	/* 0x7a3: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_7a9:
	/* 0x7a9: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_7ac:
	/* 0x7ac: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x7ac, 0x843, x86_l_843);
x86_l_7b1:
	/* 0x7b1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7b3:
	/* 0x7b3: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_7b9:
	/* 0x7b9: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_7bc:
	/* 0x7bc: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x7bc, 0x843, x86_l_843);
x86_l_7c1:
	/* 0x7c1: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_7c4:
	/* 0x7c4: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7c7:
	/* 0x7c7: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7cb:
	/* 0x7cb: mov    rdi,QWORD PTR [rip+0x17f0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr6lpm_maps));
x86_l_7d2:
	/* 0x7d2: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d7:
	/* 0x7d7: call   1fcc <filter_32ty_range+0xd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7dc:
	/* 0x7dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7df:
	/* 0x7df: je     84f <filter_inet+0x300> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7df, 0x84f, x86_l_84f);
x86_l_7e1:
	/* 0x7e1: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_7e9:
	/* 0x7e9: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7ed:
	/* 0x7ed: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7f2:
	/* 0x7f2: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7f7:
	/* 0x7f7: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_7fb:
	/* 0x7fb: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_800:
	/* 0x800: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_805:
	/* 0x805: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_808:
	/* 0x808: call   1ffd <filter_32ty_range+0x10a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_80d:
	/* 0x80d: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_812:
	/* 0x812: lea    edx,[rcx-0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_815:
	/* 0x815: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_818:
	/* 0x818: jb     85c <filter_inet+0x30d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x818, 0x85c, x86_l_85c);
x86_l_81a:
	/* 0x81a: add    ecx,0xfffffff3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_81d:
	/* 0x81d: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_820:
	/* 0x820: ja     82d <filter_inet+0x2de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x820, 0x82d, x86_l_82d);
x86_l_822:
	/* 0x822: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_825:
	/* 0x825: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_828:
	/* 0x828: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_82b:
	/* 0x82b: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x82b, 0x843, x86_l_843);
x86_l_82d:
	/* 0x82d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82f:
	/* 0x82f: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_832:
	/* 0x832: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x832, 0x843, x86_l_843);
x86_l_834:
	/* 0x834: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_838:
	/* 0x838: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_83b:
	/* 0x83b: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_83e:
	/* 0x83e: call   20a9 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20a9, 0x843ULL);
x86_l_843:
	/* 0x843: add    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_847:
	/* 0x847: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_848:
	/* 0x848: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_84a:
	/* 0x84a: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_84c:
	/* 0x84c: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_84e:
	/* 0x84e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_84e);
x86_l_84f:
	/* 0x84f: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_854:
	/* 0x854: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_857:
	/* 0x857: cmp    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_85a:
	/* 0x85a: jmp    85f <filter_inet+0x310> */
	X86_SIM_X86_SUB_JMP(0x85a, 0x85f, x86_l_85f);
x86_l_85c:
	/* 0x85c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85f:
	/* 0x85f: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_862:
	/* 0x862: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_865:
	/* 0x865: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x865, 0x843, x86_l_843);
x86_l_867:
	/* 0x867: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_86a:
	/* 0x86a: jne    879 <filter_inet+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x86a, 0x879, x86_l_879);
x86_l_86c:
	/* 0x86c: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_86f:
	/* 0x86f: je     879 <filter_inet+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x86f, 0x879, x86_l_879);
x86_l_871:
	/* 0x871: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_876:
	/* 0x876: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_879:
	/* 0x879: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_87c:
	/* 0x87c: je     83b <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x87c, 0x83b, x86_l_83b);
x86_l_87e:
	/* 0x87e: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_881:
	/* 0x881: je     83b <filter_inet+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x881, 0x83b, x86_l_83b);
x86_l_883:
	/* 0x883: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_885:
	/* 0x885: jmp    843 <filter_inet+0x2f4> */
	X86_SIM_X86_SUB_JMP(0x885, 0x843, x86_l_843);

	/* native subroutine native_link_sub_887 */
x86_l_887:
	/* 0x887: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_888:
	/* 0x888: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_88c:
	/* 0x88c: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_88f:
	/* 0x88f: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_893:
	/* 0x893: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_897:
	/* 0x897: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_89b:
	/* 0x89b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_89d:
	/* 0x89d: cmp    r8d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_8a1:
	/* 0x8a1: jg     8d7 <filter_sockaddr_un+0x50> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x8a1, 0x8d7, x86_l_8d7);
x86_l_8a3:
	/* 0x8a3: lea    ecx,[r8-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_8a7:
	/* 0x8a7: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_8aa:
	/* 0x8aa: jae    8e5 <filter_sockaddr_un+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x8aa, 0x8e5, x86_l_8e5);
x86_l_8ac:
	/* 0x8ac: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8af:
	/* 0x8af: call   1191 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1191, 0x8b4ULL);
x86_l_8b4:
	/* 0x8b4: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8b7:
	/* 0x8b7: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_8bb:
	/* 0x8bb: ja     8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x8bb, 0x8d1, x86_l_8d1);
x86_l_8bd:
	/* 0x8bd: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_8c7:
	/* 0x8c7: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8cb:
	/* 0x8cb: jae    8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x8cb, 0x8d1, x86_l_8d1);
x86_l_8cd:
	/* 0x8cd: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_8d1:
	/* 0x8d1: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_8d5:
	/* 0x8d5: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8d6:
	/* 0x8d6: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8d6);
x86_l_8d7:
	/* 0x8d7: cmp    r8d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_8db:
	/* 0x8db: je     91b <filter_sockaddr_un+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8db, 0x91b, x86_l_91b);
x86_l_8dd:
	/* 0x8dd: cmp    r8d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_8e1:
	/* 0x8e1: je     8eb <filter_sockaddr_un+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8e1, 0x8eb, x86_l_8eb);
x86_l_8e3:
	/* 0x8e3: jmp    8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JMP(0x8e3, 0x8d1, x86_l_8d1);
x86_l_8e5:
	/* 0x8e5: cmp    r8d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_8e9:
	/* 0x8e9: jne    8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x8e9, 0x8d1, x86_l_8d1);
x86_l_8eb:
	/* 0x8eb: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8ee:
	/* 0x8ee: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_8f1:
	/* 0x8f1: mov    edi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_8f3:
	/* 0x8f3: call   106e <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_106e, 0x8f8ULL);
x86_l_8f8:
	/* 0x8f8: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8fb:
	/* 0x8fb: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_8ff:
	/* 0x8ff: ja     8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x8ff, 0x8d1, x86_l_8d1);
x86_l_901:
	/* 0x901: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_90b:
	/* 0x90b: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_90f:
	/* 0x90f: jae    8d1 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x90f, 0x8d1, x86_l_8d1);
x86_l_911:
	/* 0x911: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_915:
	/* 0x915: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_919:
	/* 0x919: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_91a:
	/* 0x91a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8d6);
x86_l_91b:
	/* 0x91b: movzx  eax,WORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_91e:
	/* 0x91e: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_922:
	/* 0x922: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_927:
	/* 0x927: call   20a9 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20a9, 0x92cULL);
x86_l_92c:
	/* 0x92c: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_930:
	/* 0x930: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_931:
	/* 0x931: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8d6);

	/* native subroutine native_link_sub_932 */
x86_l_932:
	/* 0x932: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_933:
	/* 0x933: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_936:
	/* 0x936: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_938:
	/* 0x938: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_93c:
	/* 0x93c: ja     977 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x93c, 0x977, x86_l_977);
x86_l_93e:
	/* 0x93e: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_943:
	/* 0x943: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_947:
	/* 0x947: jae    950 <filter_32ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x947, 0x950, x86_l_950);
x86_l_949:
	/* 0x949: call   1cdf <filter_32ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1cdf, 0x94eULL);
x86_l_94e:
	/* 0x94e: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_94f:
	/* 0x94f: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_94f);
x86_l_950:
	/* 0x950: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_955:
	/* 0x955: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_959:
	/* 0x959: jb     972 <filter_32ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x959, 0x972, x86_l_972);
x86_l_95b:
	/* 0x95b: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_965:
	/* 0x965: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_969:
	/* 0x969: jae    977 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x969, 0x977, x86_l_977);
x86_l_96b:
	/* 0x96b: call   1ef3 <filter_32ty_range> */
	X86_SIM_X86_CALL(x86_l_1ef3, 0x970ULL);
x86_l_970:
	/* 0x970: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_971:
	/* 0x971: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_94f);
x86_l_972:
	/* 0x972: call   20a9 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_20a9, 0x977ULL);
x86_l_977:
	/* 0x977: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_978:
	/* 0x978: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_94f);

	/* native subroutine native_link_sub_979 */
x86_l_979:
	/* 0x979: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_97a:
	/* 0x97a: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_97d:
	/* 0x97d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_97f:
	/* 0x97f: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_983:
	/* 0x983: ja     9be <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x983, 0x9be, x86_l_9be);
x86_l_985:
	/* 0x985: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_98a:
	/* 0x98a: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_98e:
	/* 0x98e: jae    997 <filter_16ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x98e, 0x997, x86_l_997);
x86_l_990:
	/* 0x990: call   188b <filter_16ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_188b, 0x995ULL);
x86_l_995:
	/* 0x995: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_996:
	/* 0x996: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_996);
x86_l_997:
	/* 0x997: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_99c:
	/* 0x99c: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9a0:
	/* 0x9a0: jb     9b9 <filter_16ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9a0, 0x9b9, x86_l_9b9);
x86_l_9a2:
	/* 0x9a2: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_9ac:
	/* 0x9ac: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9b0:
	/* 0x9b0: jae    9be <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9b0, 0x9be, x86_l_9be);
x86_l_9b2:
	/* 0x9b2: call   1aa5 <filter_16ty_range> */
	X86_SIM_X86_CALL(x86_l_1aa5, 0x9b7ULL);
x86_l_9b7:
	/* 0x9b7: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9b8:
	/* 0x9b8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_996);
x86_l_9b9:
	/* 0x9b9: call   1c5d <filter_16ty_map> */
	X86_SIM_X86_CALL(x86_l_1c5d, 0x9beULL);
x86_l_9be:
	/* 0x9be: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9bf:
	/* 0x9bf: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_996);

	/* native subroutine native_link_sub_9c0 */
x86_l_9c0:
	/* 0x9c0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9c1:
	/* 0x9c1: mov    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_9c4:
	/* 0x9c4: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_9c7:
	/* 0x9c7: movsxd rcx,edx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_9ca:
	/* 0x9ca: mov    edx,DWORD PTR [rsi+rcx*1-0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 18446744073709551612ULL);
x86_l_9ce:
	/* 0x9ce: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_9d0:
	/* 0x9d0: add    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_9d3:
	/* 0x9d3: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9d6:
	/* 0x9d6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9d8:
	/* 0x9d8: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_9db:
	/* 0x9db: jg     9f1 <filter_char_buf+0x31> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x9db, 0x9f1, x86_l_9f1);
x86_l_9dd:
	/* 0x9dd: lea    edi,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_9e0:
	/* 0x9e0: cmp    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_9e3:
	/* 0x9e3: jb     a28 <filter_char_buf+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9e3, 0xa28, x86_l_a28);
x86_l_9e5:
	/* 0x9e5: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_9e8:
	/* 0x9e8: je     a1e <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9e8, 0xa1e, x86_l_a1e);
x86_l_9ea:
	/* 0x9ea: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_9ed:
	/* 0x9ed: je     a00 <filter_char_buf+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9ed, 0xa00, x86_l_a00);
x86_l_9ef:
	/* 0x9ef: jmp    a3f <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JMP(0x9ef, 0xa3f, x86_l_a3f);
x86_l_9f1:
	/* 0x9f1: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_9f4:
	/* 0x9f4: jg     a0a <filter_char_buf+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x9f4, 0xa0a, x86_l_a0a);
x86_l_9f6:
	/* 0x9f6: cmp    ecx,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_9f9:
	/* 0x9f9: je     a1e <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x9f9, 0xa1e, x86_l_a1e);
x86_l_9fb:
	/* 0x9fb: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_9fe:
	/* 0x9fe: jne    a3f <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x9fe, 0xa3f, x86_l_a3f);
x86_l_a00:
	/* 0xa00: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a03:
	/* 0xa03: call   f2b <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_f2b, 0xa08ULL);
x86_l_a08:
	/* 0xa08: jmp    a3c <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa08, 0xa3c, x86_l_a3c);
x86_l_a0a:
	/* 0xa0a: cmp    ecx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_a0d:
	/* 0xa0d: je     a32 <filter_char_buf+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa0d, 0xa32, x86_l_a32);
x86_l_a0f:
	/* 0xa0f: cmp    ecx,0x22 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_a12:
	/* 0xa12: jne    a3f <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xa12, 0xa3f, x86_l_a3f);
x86_l_a14:
	/* 0xa14: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a17:
	/* 0xa17: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_a1c:
	/* 0xa1c: jmp    a37 <filter_char_buf+0x77> */
	X86_SIM_X86_SUB_JMP(0xa1c, 0xa37, x86_l_a37);
x86_l_a1e:
	/* 0xa1e: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a21:
	/* 0xa21: call   106e <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_106e, 0xa26ULL);
x86_l_a26:
	/* 0xa26: jmp    a3c <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa26, 0xa3c, x86_l_a3c);
x86_l_a28:
	/* 0xa28: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a2b:
	/* 0xa2b: call   1191 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1191, 0xa30ULL);
x86_l_a30:
	/* 0xa30: jmp    a3c <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa30, 0xa3c, x86_l_a3c);
x86_l_a32:
	/* 0xa32: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a35:
	/* 0xa35: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a37:
	/* 0xa37: call   167a <filter_char_substring> */
	X86_SIM_X86_CALL(x86_l_167a, 0xa3cULL);
x86_l_a3c:
	/* 0xa3c: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a3f:
	/* 0xa3f: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_a42:
	/* 0xa42: ja     a61 <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa42, 0xa61, x86_l_a61);
x86_l_a44:
	/* 0xa44: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a46:
	/* 0xa46: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_a50:
	/* 0xa50: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a54:
	/* 0xa54: jae    a61 <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa54, 0xa61, x86_l_a61);
x86_l_a56:
	/* 0xa56: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a58:
	/* 0xa58: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a5b:
	/* 0xa5b: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_a5e:
	/* 0xa5e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a61:
	/* 0xa61: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a62:
	/* 0xa62: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a62);

	/* native subroutine native_link_sub_a63 */
x86_l_a63:
	/* 0xa63: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a64:
	/* 0xa64: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a67:
	/* 0xa67: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a69:
	/* 0xa69: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_a6d:
	/* 0xa6d: ja     aa8 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa6d, 0xaa8, x86_l_aa8);
x86_l_a6f:
	/* 0xa6f: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_a74:
	/* 0xa74: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a78:
	/* 0xa78: jae    a81 <filter_64ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa78, 0xa81, x86_l_a81);
x86_l_a7a:
	/* 0xa7a: call   aaa <filter_64ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_aaa, 0xa7fULL);
x86_l_a7f:
	/* 0xa7f: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a80:
	/* 0xa80: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a80);
x86_l_a81:
	/* 0xa81: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_a86:
	/* 0xa86: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a8a:
	/* 0xa8a: jb     aa3 <filter_64ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa8a, 0xaa3, x86_l_aa3);
x86_l_a8c:
	/* 0xa8c: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_a96:
	/* 0xa96: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a9a:
	/* 0xa9a: jae    aa8 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa9a, 0xaa8, x86_l_aa8);
x86_l_a9c:
	/* 0xa9c: call   cdc <filter_64ty_range> */
	X86_SIM_X86_CALL(x86_l_cdc, 0xaa1ULL);
x86_l_aa1:
	/* 0xaa1: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_aa2:
	/* 0xaa2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a80);
x86_l_aa3:
	/* 0xaa3: call   eb7 <filter_64ty_map> */
	X86_SIM_X86_CALL(x86_l_eb7, 0xaa8ULL);
x86_l_aa8:
	/* 0xaa8: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_aa9:
	/* 0xaa9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a80);

	/* native subroutine native_link_sub_aaa */
x86_l_aaa:
	/* 0xaaa: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_aad:
	/* 0xaad: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_ab2:
	/* 0xab2: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_ab6:
	/* 0xab6: ja     b2e <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xab6, 0xb2e, x86_l_b2e);
x86_l_ab8:
	/* 0xab8: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_ac2:
	/* 0xac2: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ac6:
	/* 0xac6: jae    ac9 <filter_64ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xac6, 0xac9, x86_l_ac9);
x86_l_ac8:
	/* 0xac8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_ac8);
x86_l_ac9:
	/* 0xac9: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_ace:
	/* 0xace: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ad2:
	/* 0xad2: jae    aea <filter_64ty_selector_val+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xad2, 0xaea, x86_l_aea);
x86_l_ad4:
	/* 0xad4: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ad7:
	/* 0xad7: cmp    rdx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_adb:
	/* 0xadb: jne    c0c <filter_64ty_selector_val+0x162> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xadb, 0xc0c, x86_l_c0c);
x86_l_ae1:
	/* 0xae1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ae3:
	/* 0xae3: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_ae6:
	/* 0xae6: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_ae9:
	/* 0xae9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_ac8);
x86_l_aea:
	/* 0xaea: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_aee:
	/* 0xaee: jne    b2e <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xaee, 0xb2e, x86_l_b2e);
x86_l_af0:
	/* 0xaf0: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af3:
	/* 0xaf3: test   QWORD PTR [rdi+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_af7:
	/* 0xaf7: jne    ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xaf7, 0xac8, x86_l_ac8);
x86_l_af9:
	/* 0xaf9: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_afc:
	/* 0xafc: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_aff:
	/* 0xaff: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xaff, 0xcd9, x86_l_cd9);
x86_l_b05:
	/* 0xb05: test   QWORD PTR [rdi+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_b09:
	/* 0xb09: jne    ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb09, 0xac8, x86_l_ac8);
x86_l_b0b:
	/* 0xb0b: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_b0e:
	/* 0xb0e: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb0e, 0xcd9, x86_l_cd9);
x86_l_b14:
	/* 0xb14: test   QWORD PTR [rdi+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_b18:
	/* 0xb18: jne    ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb18, 0xac8, x86_l_ac8);
x86_l_b1a:
	/* 0xb1a: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_b1d:
	/* 0xb1d: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb1d, 0xcd9, x86_l_cd9);
x86_l_b23:
	/* 0xb23: test   QWORD PTR [rdi+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_b27:
	/* 0xb27: jne    ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb27, 0xac8, x86_l_ac8);
x86_l_b29:
	/* 0xb29: jmp    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xb29, 0xcd9, x86_l_cd9);
x86_l_b2e:
	/* 0xb2e: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b31:
	/* 0xb31: je     ba4 <filter_64ty_selector_val+0xfa> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xb31, 0xba4, x86_l_ba4);
x86_l_b33:
	/* 0xb33: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_b36:
	/* 0xb36: jne    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb36, 0xcd9, x86_l_cd9);
x86_l_b3c:
	/* 0xb3c: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_b3f:
	/* 0xb3f: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_b42:
	/* 0xb42: ja     c9c <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb42, 0xc9c, x86_l_c9c);
x86_l_b48:
	/* 0xb48: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_b4d:
	/* 0xb4d: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_b50:
	/* 0xb50: jae    c9c <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb50, 0xc9c, x86_l_c9c);
x86_l_b56:
	/* 0xb56: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b59:
	/* 0xb59: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_b5d:
	/* 0xb5d: jl     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xb5d, 0xac8, x86_l_ac8);
x86_l_b63:
	/* 0xb63: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b66:
	/* 0xb66: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_b69:
	/* 0xb69: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb69, 0xcd9, x86_l_cd9);
x86_l_b6f:
	/* 0xb6f: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_b73:
	/* 0xb73: jl     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xb73, 0xac8, x86_l_ac8);
x86_l_b79:
	/* 0xb79: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_b7c:
	/* 0xb7c: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb7c, 0xcd9, x86_l_cd9);
x86_l_b82:
	/* 0xb82: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_b86:
	/* 0xb86: jl     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xb86, 0xac8, x86_l_ac8);
x86_l_b8c:
	/* 0xb8c: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_b8f:
	/* 0xb8f: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb8f, 0xcd9, x86_l_cd9);
x86_l_b95:
	/* 0xb95: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_b99:
	/* 0xb99: jl     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xb99, 0xac8, x86_l_ac8);
x86_l_b9f:
	/* 0xb9f: jmp    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xb9f, 0xcd9, x86_l_cd9);
x86_l_ba4:
	/* 0xba4: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ba7:
	/* 0xba7: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_baa:
	/* 0xbaa: ja     c5d <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xbaa, 0xc5d, x86_l_c5d);
x86_l_bb0:
	/* 0xbb0: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_bb5:
	/* 0xbb5: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_bb8:
	/* 0xbb8: jae    c5d <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xbb8, 0xc5d, x86_l_c5d);
x86_l_bbe:
	/* 0xbbe: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bc1:
	/* 0xbc1: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_bc5:
	/* 0xbc5: jg     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xbc5, 0xac8, x86_l_ac8);
x86_l_bcb:
	/* 0xbcb: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bce:
	/* 0xbce: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_bd1:
	/* 0xbd1: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbd1, 0xcd9, x86_l_cd9);
x86_l_bd7:
	/* 0xbd7: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_bdb:
	/* 0xbdb: jg     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xbdb, 0xac8, x86_l_ac8);
x86_l_be1:
	/* 0xbe1: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_be4:
	/* 0xbe4: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbe4, 0xcd9, x86_l_cd9);
x86_l_bea:
	/* 0xbea: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_bee:
	/* 0xbee: jg     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xbee, 0xac8, x86_l_ac8);
x86_l_bf4:
	/* 0xbf4: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_bf7:
	/* 0xbf7: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbf7, 0xcd9, x86_l_cd9);
x86_l_bfd:
	/* 0xbfd: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c01:
	/* 0xc01: jg     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc01, 0xac8, x86_l_ac8);
x86_l_c07:
	/* 0xc07: jmp    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc07, 0xcd9, x86_l_cd9);
x86_l_c0c:
	/* 0xc0c: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c0f:
	/* 0xc0f: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c12:
	/* 0xc12: jb     c3c <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc12, 0xc3c, x86_l_c3c);
x86_l_c14:
	/* 0xc14: cmp    rdx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c18:
	/* 0xc18: je     ae1 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc18, 0xae1, x86_l_ae1);
x86_l_c1e:
	/* 0xc1e: cmp    esi,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_c21:
	/* 0xc21: jb     c3c <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc21, 0xc3c, x86_l_c3c);
x86_l_c23:
	/* 0xc23: cmp    rdx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c27:
	/* 0xc27: je     ae1 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc27, 0xae1, x86_l_ae1);
x86_l_c2d:
	/* 0xc2d: cmp    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c30:
	/* 0xc30: jb     c3c <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc30, 0xc3c, x86_l_c3c);
x86_l_c32:
	/* 0xc32: cmp    rdx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c36:
	/* 0xc36: je     ae1 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc36, 0xae1, x86_l_ae1);
x86_l_c3c:
	/* 0xc3c: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_c3f:
	/* 0xc3f: ja     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc3f, 0xcd9, x86_l_cd9);
x86_l_c45:
	/* 0xc45: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c47:
	/* 0xc47: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_c51:
	/* 0xc51: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c55:
	/* 0xc55: jb     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc55, 0xac8, x86_l_ac8);
x86_l_c5b:
	/* 0xc5b: jmp    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc5b, 0xcd9, x86_l_cd9);
x86_l_c5d:
	/* 0xc5d: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c60:
	/* 0xc60: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c64:
	/* 0xc64: ja     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc64, 0xac8, x86_l_ac8);
x86_l_c6a:
	/* 0xc6a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c6d:
	/* 0xc6d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c70:
	/* 0xc70: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc70, 0xcd9, x86_l_cd9);
x86_l_c72:
	/* 0xc72: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c76:
	/* 0xc76: ja     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc76, 0xac8, x86_l_ac8);
x86_l_c7c:
	/* 0xc7c: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_c7f:
	/* 0xc7f: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc7f, 0xcd9, x86_l_cd9);
x86_l_c81:
	/* 0xc81: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c85:
	/* 0xc85: ja     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc85, 0xac8, x86_l_ac8);
x86_l_c8b:
	/* 0xc8b: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c8e:
	/* 0xc8e: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc8e, 0xcd9, x86_l_cd9);
x86_l_c90:
	/* 0xc90: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c94:
	/* 0xc94: ja     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc94, 0xac8, x86_l_ac8);
x86_l_c9a:
	/* 0xc9a: jmp    cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc9a, 0xcd9, x86_l_cd9);
x86_l_c9c:
	/* 0xc9c: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9f:
	/* 0xc9f: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_ca3:
	/* 0xca3: jb     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xca3, 0xac8, x86_l_ac8);
x86_l_ca9:
	/* 0xca9: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cac:
	/* 0xcac: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_caf:
	/* 0xcaf: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcaf, 0xcd9, x86_l_cd9);
x86_l_cb1:
	/* 0xcb1: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_cb5:
	/* 0xcb5: jb     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcb5, 0xac8, x86_l_ac8);
x86_l_cbb:
	/* 0xcbb: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_cbe:
	/* 0xcbe: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcbe, 0xcd9, x86_l_cd9);
x86_l_cc0:
	/* 0xcc0: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_cc4:
	/* 0xcc4: jb     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcc4, 0xac8, x86_l_ac8);
x86_l_cca:
	/* 0xcca: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_ccd:
	/* 0xccd: jb     cd9 <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xccd, 0xcd9, x86_l_cd9);
x86_l_ccf:
	/* 0xccf: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_cd3:
	/* 0xcd3: jb     ac8 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcd3, 0xac8, x86_l_ac8);
x86_l_cd9:
	/* 0xcd9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cdb:
	/* 0xcdb: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_ac8);

	/* native subroutine native_link_sub_cdc */
x86_l_cdc:
	/* 0xcdc: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_cdf:
	/* 0xcdf: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ce2:
	/* 0xce2: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_ce5:
	/* 0xce5: ja     ddf <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xce5, 0xddf, x86_l_ddf);
x86_l_ceb:
	/* 0xceb: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_cf0:
	/* 0xcf0: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_cf3:
	/* 0xcf3: jae    ddf <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xcf3, 0xddf, x86_l_ddf);
x86_l_cf9:
	/* 0xcf9: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cfc:
	/* 0xcfc: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_cff:
	/* 0xcff: jne    d6f <filter_64ty_range+0x93> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xcff, 0xd6f, x86_l_d6f);
x86_l_d01:
	/* 0xd01: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d06:
	/* 0xd06: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d0a:
	/* 0xd0a: jg     d16 <filter_64ty_range+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd0a, 0xd16, x86_l_d16);
x86_l_d0c:
	/* 0xd0c: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d10:
	/* 0xd10: jle    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd10, 0xdf8, x86_l_df8);
x86_l_d16:
	/* 0xd16: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d19:
	/* 0xd19: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d1c:
	/* 0xd1c: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd1c, 0xea6, x86_l_ea6);
x86_l_d22:
	/* 0xd22: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d26:
	/* 0xd26: jg     d32 <filter_64ty_range+0x56> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd26, 0xd32, x86_l_d32);
x86_l_d28:
	/* 0xd28: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d2c:
	/* 0xd2c: jle    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd2c, 0xdf8, x86_l_df8);
x86_l_d32:
	/* 0xd32: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_d35:
	/* 0xd35: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd35, 0xea6, x86_l_ea6);
x86_l_d3b:
	/* 0xd3b: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d3f:
	/* 0xd3f: jg     d4b <filter_64ty_range+0x6f> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd3f, 0xd4b, x86_l_d4b);
x86_l_d41:
	/* 0xd41: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_d45:
	/* 0xd45: jle    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd45, 0xdf8, x86_l_df8);
x86_l_d4b:
	/* 0xd4b: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_d4e:
	/* 0xd4e: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd4e, 0xea6, x86_l_ea6);
x86_l_d54:
	/* 0xd54: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d56:
	/* 0xd56: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d5a:
	/* 0xd5a: jg     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd5a, 0xea8, x86_l_ea8);
x86_l_d60:
	/* 0xd60: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_d64:
	/* 0xd64: jle    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd64, 0xdf8, x86_l_df8);
x86_l_d6a:
	/* 0xd6a: jmp    ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xd6a, 0xea8, x86_l_ea8);
x86_l_d6f:
	/* 0xd6f: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d72:
	/* 0xd72: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d76:
	/* 0xd76: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_d7a:
	/* 0xd7a: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d7e:
	/* 0xd7e: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_d81:
	/* 0xd81: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_d84:
	/* 0xd84: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d87:
	/* 0xd87: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd87, 0xea8, x86_l_ea8);
x86_l_d8d:
	/* 0xd8d: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d91:
	/* 0xd91: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_d95:
	/* 0xd95: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d99:
	/* 0xd99: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_d9d:
	/* 0xd9d: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_da0:
	/* 0xda0: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_da3:
	/* 0xda3: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_da6:
	/* 0xda6: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xda6, 0xea8, x86_l_ea8);
x86_l_dac:
	/* 0xdac: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_db0:
	/* 0xdb0: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_db4:
	/* 0xdb4: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_db8:
	/* 0xdb8: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_dbc:
	/* 0xdbc: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_dbf:
	/* 0xdbf: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_dc2:
	/* 0xdc2: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_dc5:
	/* 0xdc5: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdc5, 0xea8, x86_l_ea8);
x86_l_dcb:
	/* 0xdcb: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_dcf:
	/* 0xdcf: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_dd2:
	/* 0xdd2: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_dd6:
	/* 0xdd6: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_dda:
	/* 0xdda: jmp    e5c <filter_64ty_range+0x180> */
	X86_SIM_X86_SUB_JMP(0xdda, 0xe5c, x86_l_e5c);
x86_l_ddf:
	/* 0xddf: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de2:
	/* 0xde2: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_de5:
	/* 0xde5: jne    df9 <filter_64ty_range+0x11d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xde5, 0xdf9, x86_l_df9);
x86_l_de7:
	/* 0xde7: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_dec:
	/* 0xdec: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_df0:
	/* 0xdf0: ja     e64 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdf0, 0xe64, x86_l_e64);
x86_l_df2:
	/* 0xdf2: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_df6:
	/* 0xdf6: ja     e64 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xdf6, 0xe64, x86_l_e64);
x86_l_df8:
	/* 0xdf8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_df8);
x86_l_df9:
	/* 0xdf9: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dfc:
	/* 0xdfc: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e00:
	/* 0xe00: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e04:
	/* 0xe04: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e08:
	/* 0xe08: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e0b:
	/* 0xe0b: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e0e:
	/* 0xe0e: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_e11:
	/* 0xe11: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe11, 0xea8, x86_l_ea8);
x86_l_e17:
	/* 0xe17: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e1b:
	/* 0xe1b: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e1f:
	/* 0xe1f: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e23:
	/* 0xe23: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e27:
	/* 0xe27: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e2a:
	/* 0xe2a: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e2d:
	/* 0xe2d: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_e30:
	/* 0xe30: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe30, 0xea8, x86_l_ea8);
x86_l_e32:
	/* 0xe32: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e36:
	/* 0xe36: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e3a:
	/* 0xe3a: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e3e:
	/* 0xe3e: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e42:
	/* 0xe42: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e45:
	/* 0xe45: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e48:
	/* 0xe48: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_e4b:
	/* 0xe4b: jb     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe4b, 0xea8, x86_l_ea8);
x86_l_e4d:
	/* 0xe4d: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e51:
	/* 0xe51: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e54:
	/* 0xe54: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e58:
	/* 0xe58: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e5c:
	/* 0xe5c: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e5f:
	/* 0xe5f: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e62:
	/* 0xe62: jmp    ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xe62, 0xea8, x86_l_ea8);
x86_l_e64:
	/* 0xe64: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e67:
	/* 0xe67: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_e6a:
	/* 0xe6a: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe6a, 0xea6, x86_l_ea6);
x86_l_e6c:
	/* 0xe6c: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e70:
	/* 0xe70: ja     e78 <filter_64ty_range+0x19c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe70, 0xe78, x86_l_e78);
x86_l_e72:
	/* 0xe72: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e76:
	/* 0xe76: jbe    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xe76, 0xdf8, x86_l_df8);
x86_l_e78:
	/* 0xe78: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_e7b:
	/* 0xe7b: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe7b, 0xea6, x86_l_ea6);
x86_l_e7d:
	/* 0xe7d: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e81:
	/* 0xe81: ja     e8d <filter_64ty_range+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe81, 0xe8d, x86_l_e8d);
x86_l_e83:
	/* 0xe83: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e87:
	/* 0xe87: jbe    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xe87, 0xdf8, x86_l_df8);
x86_l_e8d:
	/* 0xe8d: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_e90:
	/* 0xe90: jb     ea6 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe90, 0xea6, x86_l_ea6);
x86_l_e92:
	/* 0xe92: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e94:
	/* 0xe94: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e98:
	/* 0xe98: ja     ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe98, 0xea8, x86_l_ea8);
x86_l_e9a:
	/* 0xe9a: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e9e:
	/* 0xe9e: jbe    df8 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xe9e, 0xdf8, x86_l_df8);
x86_l_ea4:
	/* 0xea4: jmp    ea8 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xea4, 0xea8, x86_l_ea8);
x86_l_ea6:
	/* 0xea6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ea8:
	/* 0xea8: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_eab:
	/* 0xeab: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_eae:
	/* 0xeae: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_eb1:
	/* 0xeb1: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_eb3:
	/* 0xeb3: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_eb6:
	/* 0xeb6: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_df8);

	/* native subroutine native_link_sub_eb7 */
x86_l_eb7:
	/* 0xeb7: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_eb9:
	/* 0xeb9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_eba:
	/* 0xeba: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_ebe:
	/* 0xebe: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ec1:
	/* 0xec1: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ec4:
	/* 0xec4: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_ec8:
	/* 0xec8: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ecc:
	/* 0xecc: mov    rdi,QWORD PTR [rip+0x6c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_ed3:
	/* 0xed3: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ed8:
	/* 0xed8: call   159d <filter_char_buf_equal+0x40c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_edd:
	/* 0xedd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ee0:
	/* 0xee0: je     f0c <filter_64ty_map+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xee0, 0xf0c, x86_l_f0c);
x86_l_ee2:
	/* 0xee2: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee5:
	/* 0xee5: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eea:
	/* 0xeea: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eef:
	/* 0xeef: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ef2:
	/* 0xef2: call   15b7 <filter_char_buf_equal+0x426> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ef7:
	/* 0xef7: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_efa:
	/* 0xefa: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_efd:
	/* 0xefd: je     f16 <filter_64ty_map+0x5f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xefd, 0xf16, x86_l_f16);
x86_l_eff:
	/* 0xeff: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_f02:
	/* 0xf02: jne    f1e <filter_64ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xf02, 0xf1e, x86_l_f1e);
x86_l_f04:
	/* 0xf04: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f07:
	/* 0xf07: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_f0a:
	/* 0xf0a: jmp    f20 <filter_64ty_map+0x69> */
	X86_SIM_X86_SUB_JMP(0xf0a, 0xf20, x86_l_f20);
x86_l_f0c:
	/* 0xf0c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f0e:
	/* 0xf0e: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f12:
	/* 0xf12: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f13:
	/* 0xf13: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f15:
	/* 0xf15: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f15);
x86_l_f16:
	/* 0xf16: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f19:
	/* 0xf19: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_f1c:
	/* 0xf1c: jmp    f20 <filter_64ty_map+0x69> */
	X86_SIM_X86_SUB_JMP(0xf1c, 0xf20, x86_l_f20);
x86_l_f1e:
	/* 0xf1e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f20:
	/* 0xf20: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_f23:
	/* 0xf23: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f27:
	/* 0xf27: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f28:
	/* 0xf28: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f2a:
	/* 0xf2a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f15);

	/* native subroutine native_link_sub_f2b */
x86_l_f2b:
	/* 0xf2b: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f2d:
	/* 0xf2d: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f2f:
	/* 0xf2f: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f30:
	/* 0xf30: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_f34:
	/* 0xf34: mov    ebx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_f36:
	/* 0xf36: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f39:
	/* 0xf39: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f3d:
	/* 0xf3d: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_f45:
	/* 0xf45: mov    rdi,QWORD PTR [rip+0x2210] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps));
x86_l_f4c:
	/* 0xf4c: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f51:
	/* 0xf51: call   3166 <filter_file_type+0xbe8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f56:
	/* 0xf56: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f59:
	/* 0xf59: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f5b:
	/* 0xf5b: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_f5d:
	/* 0xf5d: je     1064 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf5d, 0x1064, x86_l_1064);
x86_l_f63:
	/* 0xf63: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f66:
	/* 0xf66: je     1064 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf66, 0x1064, x86_l_1064);
x86_l_f6c:
	/* 0xf6c: mov    rdi,QWORD PTR [rip+0x2210] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_f73:
	/* 0xf73: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f78:
	/* 0xf78: call   318d <filter_file_type+0xc0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f7d:
	/* 0xf7d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f80:
	/* 0xf80: je     1062 <filter_char_buf_postfix+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf80, 0x1062, x86_l_1062);
x86_l_f86:
	/* 0xf86: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_f88:
	/* 0xf88: cmp    ebx,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_f8b:
	/* 0xf8b: jb     f92 <filter_char_buf_postfix+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf8b, 0xf92, x86_l_f92);
x86_l_f8d:
	/* 0xf8d: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_f92:
	/* 0xf92: shl    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_f95:
	/* 0xf95: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f97:
	/* 0xf97: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_f99:
	/* 0xf99: lea    edx,[rbx-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_f9c:
	/* 0xf9c: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f9f:
	/* 0xf9f: add    rsi,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_fa3:
	/* 0xfa3: lea    edi,[rbx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_fa6:
	/* 0xfa6: lea    r8d,[rbx-0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_faa:
	/* 0xfaa: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_fac:
	/* 0xfac: mov    r9,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_fb3:
	/* 0xfb3: lea    r10d,[rbx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_fb7:
	/* 0xfb7: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_fbb:
	/* 0xfbb: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fc2:
	/* 0xfc2: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_fc7:
	/* 0xfc7: mov    BYTE PTR [rsi-0x3],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_fcb:
	/* 0xfcb: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_fcf:
	/* 0xfcf: cmp    r10,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_fd3:
	/* 0xfd3: je     104a <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfd3, 0x104a, x86_l_104a);
x86_l_fd5:
	/* 0xfd5: lea    r11d,[r8+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_fd9:
	/* 0xfd9: add    r11d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_fdd:
	/* 0xfdd: and    r11d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fe4:
	/* 0xfe4: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_fe9:
	/* 0xfe9: mov    BYTE PTR [rsi-0x2],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_fed:
	/* 0xfed: cmp    r10,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ff1:
	/* 0xff1: je     104a <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xff1, 0x104a, x86_l_104a);
x86_l_ff3:
	/* 0xff3: lea    r10d,[rdi+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_ff7:
	/* 0xff7: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_ffb:
	/* 0xffb: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1002:
	/* 0x1002: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_1007:
	/* 0x1007: mov    BYTE PTR [rsi-0x1],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_100b:
	/* 0x100b: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_100e:
	/* 0x100e: add    r10,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1011:
	/* 0x1011: je     104a <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1011, 0x104a, x86_l_104a);
x86_l_1013:
	/* 0x1013: cmp    r9,0xffffffffffffff81 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551489ULL);
x86_l_1017:
	/* 0x1017: je     104a <filter_char_buf_postfix+0x11f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1017, 0x104a, x86_l_104a);
x86_l_1019:
	/* 0x1019: lea    r10d,[rdx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_101d:
	/* 0x101d: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1021:
	/* 0x1021: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1028:
	/* 0x1028: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_102d:
	/* 0x102d: mov    BYTE PTR [rsi],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1030:
	/* 0x1030: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1034:
	/* 0x1034: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1038:
	/* 0x1038: add    r10,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_103c:
	/* 0x103c: add    r9,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_1040:
	/* 0x1040: cmp    r10,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_1044:
	/* 0x1044: jne    fb3 <filter_char_buf_postfix+0x88> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1044, 0xfb3, x86_l_fb3);
x86_l_104a:
	/* 0x104a: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_104d:
	/* 0x104d: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1050:
	/* 0x1050: call   326d <filter_file_type+0xcef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1055:
	/* 0x1055: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1058:
	/* 0x1058: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_105a:
	/* 0x105a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_105d:
	/* 0x105d: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1060:
	/* 0x1060: jmp    1064 <filter_char_buf_postfix+0x139> */
	X86_SIM_X86_SUB_JMP(0x1060, 0x1064, x86_l_1064);
x86_l_1062:
	/* 0x1062: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1064:
	/* 0x1064: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1068:
	/* 0x1068: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1069:
	/* 0x1069: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_106b:
	/* 0x106b: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_106d:
	/* 0x106d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_106d);

	/* native subroutine native_link_sub_106e */
x86_l_106e:
	/* 0x106e: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_106f:
	/* 0x106f: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1071:
	/* 0x1071: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1073:
	/* 0x1073: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1074:
	/* 0x1074: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1075:
	/* 0x1075: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1077:
	/* 0x1077: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_107a:
	/* 0x107a: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_107e:
	/* 0x107e: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1085:
	/* 0x1085: mov    rdi,QWORD PTR [rip+0x20e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps));
x86_l_108c:
	/* 0x108c: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1091:
	/* 0x1091: call   3176 <filter_file_type+0xbf8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1096:
	/* 0x1096: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1099:
	/* 0x1099: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_109b:
	/* 0x109b: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_109d:
	/* 0x109d: je     1186 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x109d, 0x1186, x86_l_1186);
x86_l_10a3:
	/* 0x10a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10a6:
	/* 0x10a6: je     1186 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10a6, 0x1186, x86_l_1186);
x86_l_10ac:
	/* 0x10ac: mov    rdi,QWORD PTR [rip+0x20e0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_10b3:
	/* 0x10b3: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_10b6:
	/* 0x10b6: call   319b <filter_file_type+0xc1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10bb:
	/* 0x10bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10be:
	/* 0x10be: je     1121 <filter_char_buf_prefix+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x10be, 0x1121, x86_l_1121);
x86_l_10c0:
	/* 0x10c0: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10c3:
	/* 0x10c3: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_10c5:
	/* 0x10c5: cmp    ebp,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_10cb:
	/* 0x10cb: jb     10d2 <filter_char_buf_prefix+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x10cb, 0x10d2, x86_l_10d2);
x86_l_10cd:
	/* 0x10cd: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_10d2:
	/* 0x10d2: lea    ecx,[rsi*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_10d9:
	/* 0x10d9: mov    DWORD PTR [r15],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10dc:
	/* 0x10dc: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_10e0:
	/* 0x10e0: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_10e3:
	/* 0x10e3: jns    1125 <filter_char_buf_prefix+0xb7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x10e3, 0x1125, x86_l_1125);
x86_l_10e5:
	/* 0x10e5: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_10e8:
	/* 0x10e8: jns    1132 <filter_char_buf_prefix+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x10e8, 0x1132, x86_l_1132);
x86_l_10ea:
	/* 0x10ea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ec:
	/* 0x10ec: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_10ef:
	/* 0x10ef: jb     110d <filter_char_buf_prefix+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x10ef, 0x110d, x86_l_110d);
x86_l_10f1:
	/* 0x10f1: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_10f3:
	/* 0x10f3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10f5:
	/* 0x10f5: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10f8:
	/* 0x10f8: mov    rcx,QWORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_10fc:
	/* 0x10fc: mov    QWORD PTR [rax+rdi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_1100:
	/* 0x1100: lea    rcx,[rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1104:
	/* 0x1104: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1108:
	/* 0x1108: cmp    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_110b:
	/* 0x110b: jbe    10f5 <filter_char_buf_prefix+0x87> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x110b, 0x10f5, x86_l_10f5);
x86_l_110d:
	/* 0x110d: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1111:
	/* 0x1111: jne    1140 <filter_char_buf_prefix+0xd2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1111, 0x1140, x86_l_1140);
x86_l_1113:
	/* 0x1113: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1117:
	/* 0x1117: jne    1152 <filter_char_buf_prefix+0xe4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1117, 0x1152, x86_l_1152);
x86_l_1119:
	/* 0x1119: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_111d:
	/* 0x111d: jne    1166 <filter_char_buf_prefix+0xf8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x111d, 0x1166, x86_l_1166);
x86_l_111f:
	/* 0x111f: jmp    1170 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x111f, 0x1170, x86_l_1170);
x86_l_1121:
	/* 0x1121: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1123:
	/* 0x1123: jmp    1186 <filter_char_buf_prefix+0x118> */
	X86_SIM_X86_SUB_JMP(0x1123, 0x1186, x86_l_1186);
x86_l_1125:
	/* 0x1125: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1128:
	/* 0x1128: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_112b:
	/* 0x112b: call   3219 <filter_file_type+0xc9b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1130:
	/* 0x1130: jmp    1170 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x1130, 0x1170, x86_l_1170);
x86_l_1132:
	/* 0x1132: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1134:
	/* 0x1134: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1137:
	/* 0x1137: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1139:
	/* 0x1139: call   3227 <filter_file_type+0xca9> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_113e:
	/* 0x113e: jmp    1170 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JMP(0x113e, 0x1170, x86_l_1170);
x86_l_1140:
	/* 0x1140: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1142:
	/* 0x1142: mov    edi,DWORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1146:
	/* 0x1146: mov    DWORD PTR [rax+rdx*1],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1149:
	/* 0x1149: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_114c:
	/* 0x114c: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1150:
	/* 0x1150: je     1119 <filter_char_buf_prefix+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1150, 0x1119, x86_l_1119);
x86_l_1152:
	/* 0x1152: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1154:
	/* 0x1154: movzx  edi,WORD PTR [r14+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_1159:
	/* 0x1159: mov    WORD PTR [rax+rdx*1],di */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_115d:
	/* 0x115d: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1160:
	/* 0x1160: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1164:
	/* 0x1164: je     1170 <filter_char_buf_prefix+0x102> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1164, 0x1170, x86_l_1170);
x86_l_1166:
	/* 0x1166: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1168:
	/* 0x1168: movzx  edx,BYTE PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_116d:
	/* 0x116d: mov    BYTE PTR [rax+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1170:
	/* 0x1170: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1173:
	/* 0x1173: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1176:
	/* 0x1176: call   3264 <filter_file_type+0xce6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_117b:
	/* 0x117b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_117e:
	/* 0x117e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1180:
	/* 0x1180: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1183:
	/* 0x1183: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1186:
	/* 0x1186: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_118a:
	/* 0x118a: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_118b:
	/* 0x118b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_118d:
	/* 0x118d: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_118f:
	/* 0x118f: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1190:
	/* 0x1190: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1190);

	/* native subroutine native_link_sub_1191 */
x86_l_1191:
	/* 0x1191: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1192:
	/* 0x1192: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1194:
	/* 0x1194: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1196:
	/* 0x1196: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1198:
	/* 0x1198: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_119a:
	/* 0x119a: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_119b:
	/* 0x119b: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_119c:
	/* 0x119c: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11a3:
	/* 0x11a3: cmp    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_11a9:
	/* 0x11a9: ja     1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x11a9, 0x1572, x86_l_1572);
x86_l_11af:
	/* 0x11af: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_11b2:
	/* 0x11b2: cmp    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_11b7:
	/* 0x11b7: ja     1207 <filter_char_buf_equal+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x11b7, 0x1207, x86_l_1207);
x86_l_11b9:
	/* 0x11b9: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11bc:
	/* 0x11bc: imul   ecx,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_11c2:
	/* 0x11c2: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_11c5:
	/* 0x11c5: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_11c8:
	/* 0x11c8: lea    ecx,[rcx+rcx*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_11cb:
	/* 0x11cb: sub    al,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB, 0);
x86_l_11cd:
	/* 0x11cd: test   dx,dx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_16, 0, 0);
x86_l_11d0:
	/* 0x11d0: je     11db <filter_char_buf_equal+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11d0, 0x11db, x86_l_11db);
x86_l_11d2:
	/* 0x11d2: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_11d4:
	/* 0x11d4: mov    r15d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_11d7:
	/* 0x11d7: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_11d9:
	/* 0x11d9: je     11f4 <filter_char_buf_equal+0x63> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11d9, 0x11f4, x86_l_11f4);
x86_l_11db:
	/* 0x11db: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11de:
	/* 0x11de: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_11e0:
	/* 0x11e0: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_11e2:
	/* 0x11e2: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_11e4:
	/* 0x11e4: add    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_11e7:
	/* 0x11e7: movzx  r15d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_11eb:
	/* 0x11eb: cmp    cx,0x78 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, 0, 120ULL);
x86_l_11ef:
	/* 0x11ef: ja     1245 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x11ef, 0x1245, x86_l_1245);
x86_l_11f1:
	/* 0x11f1: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_11f4:
	/* 0x11f4: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11f7:
	/* 0x11f7: imul   ebp,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_11fd:
	/* 0x11fd: shr    ebp,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_1200:
	/* 0x1200: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1202:
	/* 0x1202: jmp    128b <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1202, 0x128b, x86_l_128b);
x86_l_1207:
	/* 0x1207: mov    r15d,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_120d:
	/* 0x120d: cmp    eax,0x101 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 257ULL);
x86_l_1212:
	/* 0x1212: jb     1245 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1212, 0x1245, x86_l_1245);
x86_l_1214:
	/* 0x1214: mov    r15d,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_121a:
	/* 0x121a: cmp    eax,0x201 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 513ULL);
x86_l_121f:
	/* 0x121f: jb     1245 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x121f, 0x1245, x86_l_1245);
x86_l_1221:
	/* 0x1221: mov    r15d,0x400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_1227:
	/* 0x1227: cmp    eax,0x401 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1025ULL);
x86_l_122c:
	/* 0x122c: jb     1245 <filter_char_buf_equal+0xb4> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x122c, 0x1245, x86_l_1245);
x86_l_122e:
	/* 0x122e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1231:
	/* 0x1231: cmp    eax,0x801 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2049ULL);
x86_l_1236:
	/* 0x1236: setae  r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_123a:
	/* 0x123a: shl    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_123e:
	/* 0x123e: add    r15d,0x800 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_1245:
	/* 0x1245: lea    eax,[r15-0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_124c:
	/* 0x124c: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_1252:
	/* 0x1252: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1255:
	/* 0x1255: jg     1267 <filter_char_buf_equal+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1255, 0x1267, x86_l_1267);
x86_l_1257:
	/* 0x1257: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1259:
	/* 0x1259: je     127f <filter_char_buf_equal+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1259, 0x127f, x86_l_127f);
x86_l_125b:
	/* 0x125b: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_125e:
	/* 0x125e: jne    1278 <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x125e, 0x1278, x86_l_1278);
x86_l_1260:
	/* 0x1260: mov    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1265:
	/* 0x1265: jmp    128b <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1265, 0x128b, x86_l_128b);
x86_l_1267:
	/* 0x1267: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_126a:
	/* 0x126a: je     1286 <filter_char_buf_equal+0xf5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x126a, 0x1286, x86_l_1286);
x86_l_126c:
	/* 0x126c: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_126f:
	/* 0x126f: jne    1278 <filter_char_buf_equal+0xe7> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x126f, 0x1278, x86_l_1278);
x86_l_1271:
	/* 0x1271: mov    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1276:
	/* 0x1276: jmp    128b <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1276, 0x128b, x86_l_128b);
x86_l_1278:
	/* 0x1278: mov    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_127d:
	/* 0x127d: jmp    128b <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x127d, 0x128b, x86_l_128b);
x86_l_127f:
	/* 0x127f: mov    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1284:
	/* 0x1284: jmp    128b <filter_char_buf_equal+0xfa> */
	X86_SIM_X86_SUB_JMP(0x1284, 0x128b, x86_l_128b);
x86_l_1286:
	/* 0x1286: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_128b:
	/* 0x128b: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_128d:
	/* 0x128d: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1290:
	/* 0x1290: mov    r12d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_1295:
	/* 0x1295: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1299:
	/* 0x1299: je     1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1299, 0x1572, x86_l_1572);
x86_l_129f:
	/* 0x129f: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_12a2:
	/* 0x12a2: mov    r13d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_12a5:
	/* 0x12a5: mov    rdi,QWORD PTR [rip+0x1be0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_heap));
x86_l_12ac:
	/* 0x12ac: mov    r14,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_12af:
	/* 0x12af: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12b2:
	/* 0x12b2: call   2e97 <filter_file_type+0x919> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12b7:
	/* 0x12b7: mov    rdi,QWORD PTR [rip+0x1be0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_12be:
	/* 0x12be: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12c1:
	/* 0x12c1: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12c4:
	/* 0x12c4: call   2ea9 <filter_file_type+0x92b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12c9:
	/* 0x12c9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12cb:
	/* 0x12cb: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_12ce:
	/* 0x12ce: je     1574 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12ce, 0x1574, x86_l_1574);
x86_l_12d4:
	/* 0x12d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d7:
	/* 0x12d7: je     1574 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12d7, 0x1574, x86_l_1574);
x86_l_12dd:
	/* 0x12dd: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_12e0:
	/* 0x12e0: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_12e3:
	/* 0x12e3: jg     1342 <filter_char_buf_equal+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x12e3, 0x1342, x86_l_1342);
x86_l_12e5:
	/* 0x12e5: mov    BYTE PTR [r14],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12e8:
	/* 0x12e8: lea    rdi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12ec:
	/* 0x12ec: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12ef:
	/* 0x12ef: jns    1398 <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x12ef, 0x1398, x86_l_1398);
x86_l_12f5:
	/* 0x12f5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12f8:
	/* 0x12f8: jns    13a5 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x12f8, 0x13a5, x86_l_13a5);
x86_l_12fe:
	/* 0x12fe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1300:
	/* 0x1300: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1303:
	/* 0x1303: jb     1323 <filter_char_buf_equal+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1303, 0x1323, x86_l_1323);
x86_l_1305:
	/* 0x1305: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1308:
	/* 0x1308: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_130b:
	/* 0x130b: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_130f:
	/* 0x130f: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1313:
	/* 0x1313: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1317:
	/* 0x1317: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_131b:
	/* 0x131b: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_131e:
	/* 0x131e: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1321:
	/* 0x1321: jbe    1308 <filter_char_buf_equal+0x177> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1321, 0x1308, x86_l_1308);
x86_l_1323:
	/* 0x1323: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1327:
	/* 0x1327: jne    1586 <filter_char_buf_equal+0x3f5> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1327, 0x1586, x86_l_1586);
x86_l_132d:
	/* 0x132d: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1331:
	/* 0x1331: jne    159e <filter_char_buf_equal+0x40d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1331, 0x159e, x86_l_159e);
x86_l_1337:
	/* 0x1337: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_133b:
	/* 0x133b: je     13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x133b, 0x13b7, x86_l_13b7);
x86_l_133d:
	/* 0x133d: jmp    15b8 <filter_char_buf_equal+0x427> */
	X86_SIM_X86_SUB_JMP(0x133d, 0x15b8, x86_l_15b8);
x86_l_1342:
	/* 0x1342: mov    WORD PTR [r14],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1346:
	/* 0x1346: lea    rdi,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_134a:
	/* 0x134a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_134d:
	/* 0x134d: jns    1398 <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x134d, 0x1398, x86_l_1398);
x86_l_134f:
	/* 0x134f: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1352:
	/* 0x1352: jns    13a5 <filter_char_buf_equal+0x214> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1352, 0x13a5, x86_l_13a5);
x86_l_1354:
	/* 0x1354: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1356:
	/* 0x1356: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1359:
	/* 0x1359: jb     1379 <filter_char_buf_equal+0x1e8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1359, 0x1379, x86_l_1379);
x86_l_135b:
	/* 0x135b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_135e:
	/* 0x135e: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1361:
	/* 0x1361: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1365:
	/* 0x1365: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1369:
	/* 0x1369: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_136d:
	/* 0x136d: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_1371:
	/* 0x1371: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1374:
	/* 0x1374: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1377:
	/* 0x1377: jbe    135e <filter_char_buf_equal+0x1cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1377, 0x135e, x86_l_135e);
x86_l_1379:
	/* 0x1379: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_137d:
	/* 0x137d: jne    15c6 <filter_char_buf_equal+0x435> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x137d, 0x15c6, x86_l_15c6);
x86_l_1383:
	/* 0x1383: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1387:
	/* 0x1387: jne    15de <filter_char_buf_equal+0x44d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1387, 0x15de, x86_l_15de);
x86_l_138d:
	/* 0x138d: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1391:
	/* 0x1391: je     13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1391, 0x13b7, x86_l_13b7);
x86_l_1393:
	/* 0x1393: jmp    15f8 <filter_char_buf_equal+0x467> */
	X86_SIM_X86_SUB_JMP(0x1393, 0x15f8, x86_l_15f8);
x86_l_1398:
	/* 0x1398: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_139b:
	/* 0x139b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_139e:
	/* 0x139e: call   2f96 <filter_file_type+0xa18> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_13a3:
	/* 0x13a3: jmp    13b1 <filter_char_buf_equal+0x220> */
	X86_SIM_X86_SUB_JMP(0x13a3, 0x13b1, x86_l_13b1);
x86_l_13a5:
	/* 0x13a5: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13a7:
	/* 0x13a7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13a9:
	/* 0x13a9: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13ac:
	/* 0x13ac: call   2fa4 <filter_file_type+0xa26> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_13b1:
	/* 0x13b1: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_13b4:
	/* 0x13b4: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13b7:
	/* 0x13b7: sub    r15d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_13ba:
	/* 0x13ba: jle    1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x13ba, 0x1490, x86_l_1490);
x86_l_13c0:
	/* 0x13c0: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13c2:
	/* 0x13c2: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_13c5:
	/* 0x13c5: add    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_13c8:
	/* 0x13c8: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_13cb:
	/* 0x13cb: and    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_13d1:
	/* 0x13d1: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_13d4:
	/* 0x13d4: jg     142d <filter_char_buf_equal+0x29c> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x13d4, 0x142d, x86_l_142d);
x86_l_13d6:
	/* 0x13d6: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_13d9:
	/* 0x13d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13dc:
	/* 0x13dc: jns    147d <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13dc, 0x147d, x86_l_147d);
x86_l_13e2:
	/* 0x13e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13e5:
	/* 0x13e5: jns    1487 <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13e5, 0x1487, x86_l_1487);
x86_l_13eb:
	/* 0x13eb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13ed:
	/* 0x13ed: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_13f0:
	/* 0x13f0: jb     140e <filter_char_buf_equal+0x27d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x13f0, 0x140e, x86_l_140e);
x86_l_13f2:
	/* 0x13f2: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13f4:
	/* 0x13f4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13f6:
	/* 0x13f6: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13f9:
	/* 0x13f9: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_13fd:
	/* 0x13fd: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1401:
	/* 0x1401: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1405:
	/* 0x1405: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1409:
	/* 0x1409: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_140c:
	/* 0x140c: jbe    13f6 <filter_char_buf_equal+0x265> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x140c, 0x13f6, x86_l_13f6);
x86_l_140e:
	/* 0x140e: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1412:
	/* 0x1412: jne    1606 <filter_char_buf_equal+0x475> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1412, 0x1606, x86_l_1606);
x86_l_1418:
	/* 0x1418: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_141c:
	/* 0x141c: jne    161b <filter_char_buf_equal+0x48a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x141c, 0x161b, x86_l_161b);
x86_l_1422:
	/* 0x1422: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1426:
	/* 0x1426: je     1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1426, 0x1490, x86_l_1490);
x86_l_1428:
	/* 0x1428: jmp    1632 <filter_char_buf_equal+0x4a1> */
	X86_SIM_X86_SUB_JMP(0x1428, 0x1632, x86_l_1632);
x86_l_142d:
	/* 0x142d: add    rdi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1431:
	/* 0x1431: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1434:
	/* 0x1434: jns    147d <filter_char_buf_equal+0x2ec> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1434, 0x147d, x86_l_147d);
x86_l_1436:
	/* 0x1436: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1439:
	/* 0x1439: jns    1487 <filter_char_buf_equal+0x2f6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1439, 0x1487, x86_l_1487);
x86_l_143b:
	/* 0x143b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_143d:
	/* 0x143d: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1440:
	/* 0x1440: jb     145e <filter_char_buf_equal+0x2cd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1440, 0x145e, x86_l_145e);
x86_l_1442:
	/* 0x1442: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1444:
	/* 0x1444: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1446:
	/* 0x1446: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1449:
	/* 0x1449: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_144d:
	/* 0x144d: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1451:
	/* 0x1451: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1455:
	/* 0x1455: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1459:
	/* 0x1459: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_145c:
	/* 0x145c: jbe    1446 <filter_char_buf_equal+0x2b5> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x145c, 0x1446, x86_l_1446);
x86_l_145e:
	/* 0x145e: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1462:
	/* 0x1462: jne    1640 <filter_char_buf_equal+0x4af> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1462, 0x1640, x86_l_1640);
x86_l_1468:
	/* 0x1468: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_146c:
	/* 0x146c: jne    1655 <filter_char_buf_equal+0x4c4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x146c, 0x1655, x86_l_1655);
x86_l_1472:
	/* 0x1472: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1476:
	/* 0x1476: je     1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1476, 0x1490, x86_l_1490);
x86_l_1478:
	/* 0x1478: jmp    166c <filter_char_buf_equal+0x4db> */
	X86_SIM_X86_SUB_JMP(0x1478, 0x166c, x86_l_166c);
x86_l_147d:
	/* 0x147d: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1480:
	/* 0x1480: call   3078 <filter_file_type+0xafa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1485:
	/* 0x1485: jmp    1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x1485, 0x1490, x86_l_1490);
x86_l_1487:
	/* 0x1487: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1489:
	/* 0x1489: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_148b:
	/* 0x148b: call   3083 <filter_file_type+0xb05> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1490:
	/* 0x1490: mov    DWORD PTR [rsp+0x4],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1495:
	/* 0x1495: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1498:
	/* 0x1498: jle    14c2 <filter_char_buf_equal+0x331> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1498, 0x14c2, x86_l_14c2);
x86_l_149a:
	/* 0x149a: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_149d:
	/* 0x149d: jg     14e3 <filter_char_buf_equal+0x352> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x149d, 0x14e3, x86_l_14e3);
x86_l_149f:
	/* 0x149f: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_14a2:
	/* 0x14a2: je     153e <filter_char_buf_equal+0x3ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14a2, 0x153e, x86_l_153e);
x86_l_14a8:
	/* 0x14a8: cmp    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_14ab:
	/* 0x14ab: je     1523 <filter_char_buf_equal+0x392> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14ab, 0x1523, x86_l_1523);
x86_l_14ad:
	/* 0x14ad: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_14b0:
	/* 0x14b0: jne    1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14b0, 0x1572, x86_l_1572);
x86_l_14b6:
	/* 0x14b6: mov    rdi,QWORD PTR [rip+0x1bf3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_7));
x86_l_14bd:
	/* 0x14bd: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x14bd, 0x154e, x86_l_154e);
x86_l_14c2:
	/* 0x14c2: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_14c5:
	/* 0x14c5: jle    14ff <filter_char_buf_equal+0x36e> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x14c5, 0x14ff, x86_l_14ff);
x86_l_14c7:
	/* 0x14c7: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_14ca:
	/* 0x14ca: je     1535 <filter_char_buf_equal+0x3a4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14ca, 0x1535, x86_l_1535);
x86_l_14cc:
	/* 0x14cc: cmp    ebp,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_14cf:
	/* 0x14cf: je     151a <filter_char_buf_equal+0x389> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14cf, 0x151a, x86_l_151a);
x86_l_14d1:
	/* 0x14d1: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14d4:
	/* 0x14d4: jne    1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14d4, 0x1572, x86_l_1572);
x86_l_14da:
	/* 0x14da: mov    rdi,QWORD PTR [rip+0x1bf3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_4));
x86_l_14e1:
	/* 0x14e1: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x14e1, 0x154e, x86_l_154e);
x86_l_14e3:
	/* 0x14e3: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_14e6:
	/* 0x14e6: je     1547 <filter_char_buf_equal+0x3b6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14e6, 0x1547, x86_l_1547);
x86_l_14e8:
	/* 0x14e8: cmp    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_14eb:
	/* 0x14eb: je     152c <filter_char_buf_equal+0x39b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14eb, 0x152c, x86_l_152c);
x86_l_14ed:
	/* 0x14ed: cmp    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_14f0:
	/* 0x14f0: jne    1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14f0, 0x1572, x86_l_1572);
x86_l_14f6:
	/* 0x14f6: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_10));
x86_l_14fd:
	/* 0x14fd: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x14fd, 0x154e, x86_l_154e);
x86_l_14ff:
	/* 0x14ff: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1501:
	/* 0x1501: je     1511 <filter_char_buf_equal+0x380> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1501, 0x1511, x86_l_1511);
x86_l_1503:
	/* 0x1503: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1506:
	/* 0x1506: jne    1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1506, 0x1572, x86_l_1572);
x86_l_1508:
	/* 0x1508: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_1));
x86_l_150f:
	/* 0x150f: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x150f, 0x154e, x86_l_154e);
x86_l_1511:
	/* 0x1511: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_0));
x86_l_1518:
	/* 0x1518: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1518, 0x154e, x86_l_154e);
x86_l_151a:
	/* 0x151a: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_3));
x86_l_1521:
	/* 0x1521: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1521, 0x154e, x86_l_154e);
x86_l_1523:
	/* 0x1523: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_6));
x86_l_152a:
	/* 0x152a: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x152a, 0x154e, x86_l_154e);
x86_l_152c:
	/* 0x152c: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_9));
x86_l_1533:
	/* 0x1533: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1533, 0x154e, x86_l_154e);
x86_l_1535:
	/* 0x1535: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_2));
x86_l_153c:
	/* 0x153c: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x153c, 0x154e, x86_l_154e);
x86_l_153e:
	/* 0x153e: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_5));
x86_l_1545:
	/* 0x1545: jmp    154e <filter_char_buf_equal+0x3bd> */
	X86_SIM_X86_SUB_JMP(0x1545, 0x154e, x86_l_154e);
x86_l_1547:
	/* 0x1547: mov    rdi,QWORD PTR [rip+0x1bef] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_8));
x86_l_154e:
	/* 0x154e: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1553:
	/* 0x1553: call   3147 <filter_file_type+0xbc9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1558:
	/* 0x1558: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_155b:
	/* 0x155b: je     1572 <filter_char_buf_equal+0x3e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x155b, 0x1572, x86_l_1572);
x86_l_155d:
	/* 0x155d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1560:
	/* 0x1560: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1563:
	/* 0x1563: call   3157 <filter_file_type+0xbd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1568:
	/* 0x1568: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156a:
	/* 0x156a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_156d:
	/* 0x156d: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1570:
	/* 0x1570: jmp    1574 <filter_char_buf_equal+0x3e3> */
	X86_SIM_X86_SUB_JMP(0x1570, 0x1574, x86_l_1574);
x86_l_1572:
	/* 0x1572: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1574:
	/* 0x1574: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1577:
	/* 0x1577: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_157b:
	/* 0x157b: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_157c:
	/* 0x157c: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1580:
	/* 0x1580: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1582:
	/* 0x1582: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1584:
	/* 0x1584: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1585:
	/* 0x1585: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1585);
x86_l_1586:
	/* 0x1586: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1589:
	/* 0x1589: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_158d:
	/* 0x158d: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1591:
	/* 0x1591: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1594:
	/* 0x1594: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1598:
	/* 0x1598: je     1337 <filter_char_buf_equal+0x1a6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1598, 0x1337, x86_l_1337);
x86_l_159e:
	/* 0x159e: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15a1:
	/* 0x15a1: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_15a6:
	/* 0x15a6: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15ab:
	/* 0x15ab: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_15ae:
	/* 0x15ae: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_15b2:
	/* 0x15b2: je     13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15b2, 0x13b7, x86_l_13b7);
x86_l_15b8:
	/* 0x15b8: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15ba:
	/* 0x15ba: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_15be:
	/* 0x15be: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_15c1:
	/* 0x15c1: jmp    13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x15c1, 0x13b7, x86_l_13b7);
x86_l_15c6:
	/* 0x15c6: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15c9:
	/* 0x15c9: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15cd:
	/* 0x15cd: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15d1:
	/* 0x15d1: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_15d4:
	/* 0x15d4: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_15d8:
	/* 0x15d8: je     138d <filter_char_buf_equal+0x1fc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15d8, 0x138d, x86_l_138d);
x86_l_15de:
	/* 0x15de: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15e1:
	/* 0x15e1: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_15e6:
	/* 0x15e6: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_15eb:
	/* 0x15eb: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_15ee:
	/* 0x15ee: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_15f2:
	/* 0x15f2: je     13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15f2, 0x13b7, x86_l_13b7);
x86_l_15f8:
	/* 0x15f8: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_15fa:
	/* 0x15fa: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_15fe:
	/* 0x15fe: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1601:
	/* 0x1601: jmp    13b7 <filter_char_buf_equal+0x226> */
	X86_SIM_X86_SUB_JMP(0x1601, 0x13b7, x86_l_13b7);
x86_l_1606:
	/* 0x1606: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1608:
	/* 0x1608: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_160b:
	/* 0x160b: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_160e:
	/* 0x160e: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1611:
	/* 0x1611: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1615:
	/* 0x1615: je     1422 <filter_char_buf_equal+0x291> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1615, 0x1422, x86_l_1422);
x86_l_161b:
	/* 0x161b: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_161d:
	/* 0x161d: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_1621:
	/* 0x1621: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1625:
	/* 0x1625: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1628:
	/* 0x1628: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_162c:
	/* 0x162c: je     1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x162c, 0x1490, x86_l_1490);
x86_l_1632:
	/* 0x1632: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1634:
	/* 0x1634: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1638:
	/* 0x1638: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_163b:
	/* 0x163b: jmp    1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x163b, 0x1490, x86_l_1490);
x86_l_1640:
	/* 0x1640: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1642:
	/* 0x1642: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1645:
	/* 0x1645: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1648:
	/* 0x1648: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_164b:
	/* 0x164b: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_164f:
	/* 0x164f: je     1472 <filter_char_buf_equal+0x2e1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x164f, 0x1472, x86_l_1472);
x86_l_1655:
	/* 0x1655: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1657:
	/* 0x1657: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_165b:
	/* 0x165b: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_165f:
	/* 0x165f: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1662:
	/* 0x1662: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1666:
	/* 0x1666: je     1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1666, 0x1490, x86_l_1490);
x86_l_166c:
	/* 0x166c: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_166e:
	/* 0x166e: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1672:
	/* 0x1672: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1675:
	/* 0x1675: jmp    1490 <filter_char_buf_equal+0x2ff> */
	X86_SIM_X86_SUB_JMP(0x1675, 0x1490, x86_l_1490);

	/* native subroutine native_link_sub_167a */
x86_l_167a:
	/* 0x167a: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_167b:
	/* 0x167b: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_167d:
	/* 0x167d: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_167f:
	/* 0x167f: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1681:
	/* 0x1681: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1683:
	/* 0x1683: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1684:
	/* 0x1684: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1685:
	/* 0x1685: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1688:
	/* 0x1688: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_168b:
	/* 0x168b: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_168d:
	/* 0x168d: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_168f:
	/* 0x168f: je     175c <filter_char_substring+0xe2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x168f, 0x175c, x86_l_175c);
x86_l_1695:
	/* 0x1695: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1697:
	/* 0x1697: je     17f3 <filter_char_substring+0x179> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1697, 0x17f3, x86_l_17f3);
x86_l_169d:
	/* 0x169d: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16a2:
	/* 0x16a2: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a4:
	/* 0x16a4: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a7:
	/* 0x16a7: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_16ac:
	/* 0x16ac: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_16b0:
	/* 0x16b0: mov    rdi,QWORD PTR [rip+0x2423] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_16b7:
	/* 0x16b7: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_16ba:
	/* 0x16ba: call   3ae2 <filter_file_type+0x1564> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16bf:
	/* 0x16bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16c2:
	/* 0x16c2: je     1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16c2, 0x1873, x86_l_1873);
x86_l_16c8:
	/* 0x16c8: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_16cb:
	/* 0x16cb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16cd:
	/* 0x16cd: jmp    16da <filter_char_substring+0x60> */
	X86_SIM_X86_SUB_JMP(0x16cd, 0x16da, x86_l_16da);
x86_l_16cf:
	/* 0x16cf: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16d2:
	/* 0x16d2: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16d5:
	/* 0x16d5: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_16d8:
	/* 0x16d8: je     1737 <filter_char_substring+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16d8, 0x1737, x86_l_1737);
x86_l_16da:
	/* 0x16da: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16dc:
	/* 0x16dc: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_16e0:
	/* 0x16e0: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_16e3:
	/* 0x16e3: jae    16cf <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x16e3, 0x16cf, x86_l_16cf);
x86_l_16e5:
	/* 0x16e5: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_16e9:
	/* 0x16e9: test   edi,edi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_16eb:
	/* 0x16eb: je     172f <filter_char_substring+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16eb, 0x172f, x86_l_172f);
x86_l_16ed:
	/* 0x16ed: movsx  r8d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_16f2:
	/* 0x16f2: lea    r9d,[r8-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_16f6:
	/* 0x16f6: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_16fa:
	/* 0x16fa: jb     170e <filter_char_substring+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x16fa, 0x170e, x86_l_170e);
x86_l_16fc:
	/* 0x16fc: lea    r9d,[rdi-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_1700:
	/* 0x1700: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_1704:
	/* 0x1704: jb     171c <filter_char_substring+0xa2> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1704, 0x171c, x86_l_171c);
x86_l_1706:
	/* 0x1706: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_170a:
	/* 0x170a: jbe    1725 <filter_char_substring+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x170a, 0x1725, x86_l_1725);
x86_l_170c:
	/* 0x170c: jmp    16cf <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JMP(0x170c, 0x16cf, x86_l_16cf);
x86_l_170e:
	/* 0x170e: or     r8d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_1712:
	/* 0x1712: lea    r9d,[rdi-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_1716:
	/* 0x1716: cmp    r9d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_171a:
	/* 0x171a: jae    1706 <filter_char_substring+0x8c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x171a, 0x1706, x86_l_1706);
x86_l_171c:
	/* 0x171c: or     edi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_171f:
	/* 0x171f: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_1723:
	/* 0x1723: ja     16cf <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1723, 0x16cf, x86_l_16cf);
x86_l_1725:
	/* 0x1725: inc    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1728:
	/* 0x1728: cmp    r8d,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_172b:
	/* 0x172b: je     16dc <filter_char_substring+0x62> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x172b, 0x16dc, x86_l_16dc);
x86_l_172d:
	/* 0x172d: jmp    16cf <filter_char_substring+0x55> */
	X86_SIM_X86_SUB_JMP(0x172d, 0x16cf, x86_l_16cf);
x86_l_172f:
	/* 0x172f: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1731:
	/* 0x1731: jns    1884 <filter_char_substring+0x20a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1731, 0x1884, x86_l_1884);
x86_l_1737:
	/* 0x1737: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_173c:
	/* 0x173c: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1740:
	/* 0x1740: jae    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1740, 0x1873, x86_l_1873);
x86_l_1746:
	/* 0x1746: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_174a:
	/* 0x174a: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_174d:
	/* 0x174d: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_1751:
	/* 0x1751: jne    16a7 <filter_char_substring+0x2d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1751, 0x16a7, x86_l_16a7);
x86_l_1757:
	/* 0x1757: jmp    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x1757, 0x1873, x86_l_1873);
x86_l_175c:
	/* 0x175c: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_175e:
	/* 0x175e: je     1834 <filter_char_substring+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x175e, 0x1834, x86_l_1834);
x86_l_1764:
	/* 0x1764: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1769:
	/* 0x1769: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_176b:
	/* 0x176b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_176e:
	/* 0x176e: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1773:
	/* 0x1773: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1777:
	/* 0x1777: mov    rdi,QWORD PTR [rip+0x244c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_177e:
	/* 0x177e: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1781:
	/* 0x1781: call   3bd2 <filter_file_type+0x1654> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1786:
	/* 0x1786: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1789:
	/* 0x1789: je     1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1789, 0x1873, x86_l_1873);
x86_l_178f:
	/* 0x178f: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1792:
	/* 0x1792: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1794:
	/* 0x1794: jmp    17a1 <filter_char_substring+0x127> */
	X86_SIM_X86_SUB_JMP(0x1794, 0x17a1, x86_l_17a1);
x86_l_1796:
	/* 0x1796: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1799:
	/* 0x1799: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_179c:
	/* 0x179c: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_179f:
	/* 0x179f: je     17d2 <filter_char_substring+0x158> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x179f, 0x17d2, x86_l_17d2);
x86_l_17a1:
	/* 0x17a1: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a3:
	/* 0x17a3: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_17a7:
	/* 0x17a7: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_17aa:
	/* 0x17aa: jae    1796 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x17aa, 0x1796, x86_l_1796);
x86_l_17ac:
	/* 0x17ac: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_17b0:
	/* 0x17b0: test   dil,dil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8, 0, 0);
x86_l_17b3:
	/* 0x17b3: je     17ca <filter_char_substring+0x150> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17b3, 0x17ca, x86_l_17ca);
x86_l_17b5:
	/* 0x17b5: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_17b9:
	/* 0x17b9: ja     1796 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x17b9, 0x1796, x86_l_1796);
x86_l_17bb:
	/* 0x17bb: lea    r8,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17bf:
	/* 0x17bf: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_17c3:
	/* 0x17c3: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_17c6:
	/* 0x17c6: je     17a3 <filter_char_substring+0x129> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17c6, 0x17a3, x86_l_17a3);
x86_l_17c8:
	/* 0x17c8: jmp    1796 <filter_char_substring+0x11c> */
	X86_SIM_X86_SUB_JMP(0x17c8, 0x1796, x86_l_1796);
x86_l_17ca:
	/* 0x17ca: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_17cc:
	/* 0x17cc: jns    1884 <filter_char_substring+0x20a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x17cc, 0x1884, x86_l_1884);
x86_l_17d2:
	/* 0x17d2: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_17d7:
	/* 0x17d7: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_17db:
	/* 0x17db: jae    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x17db, 0x1873, x86_l_1873);
x86_l_17e1:
	/* 0x17e1: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_17e5:
	/* 0x17e5: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17e8:
	/* 0x17e8: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_17ec:
	/* 0x17ec: jne    176e <filter_char_substring+0xf4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x17ec, 0x176e, x86_l_176e);
x86_l_17ee:
	/* 0x17ee: jmp    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x17ee, 0x1873, x86_l_1873);
x86_l_17f3:
	/* 0x17f3: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_17f8:
	/* 0x17f8: mov    r15,QWORD PTR [rip+0x2464] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_17ff:
	/* 0x17ff: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1804:
	/* 0x1804: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1808:
	/* 0x1808: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_180c:
	/* 0x180c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_180f:
	/* 0x180f: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1812:
	/* 0x1812: call   3c7d <filter_file_type+0x16ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1817:
	/* 0x1817: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_181a:
	/* 0x181a: je     1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x181a, 0x1873, x86_l_1873);
x86_l_181c:
	/* 0x181c: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1820:
	/* 0x1820: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1823:
	/* 0x1823: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1827:
	/* 0x1827: jae    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1827, 0x1873, x86_l_1873);
x86_l_1829:
	/* 0x1829: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_1830:
	/* 0x1830: jne    1804 <filter_char_substring+0x18a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1830, 0x1804, x86_l_1804);
x86_l_1832:
	/* 0x1832: jmp    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JMP(0x1832, 0x1873, x86_l_1873);
x86_l_1834:
	/* 0x1834: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1839:
	/* 0x1839: mov    r15,QWORD PTR [rip+0x2466] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_1840:
	/* 0x1840: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1845:
	/* 0x1845: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1849:
	/* 0x1849: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_184d:
	/* 0x184d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1850:
	/* 0x1850: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1853:
	/* 0x1853: call   3ccd <filter_file_type+0x174f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1858:
	/* 0x1858: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_185b:
	/* 0x185b: je     1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x185b, 0x1873, x86_l_1873);
x86_l_185d:
	/* 0x185d: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1861:
	/* 0x1861: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_1864:
	/* 0x1864: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1868:
	/* 0x1868: jae    1873 <filter_char_substring+0x1f9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1868, 0x1873, x86_l_1873);
x86_l_186a:
	/* 0x186a: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_1871:
	/* 0x1871: jne    1845 <filter_char_substring+0x1cb> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1871, 0x1845, x86_l_1845);
x86_l_1873:
	/* 0x1873: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1875:
	/* 0x1875: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1879:
	/* 0x1879: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_187a:
	/* 0x187a: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_187c:
	/* 0x187c: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_187e:
	/* 0x187e: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1880:
	/* 0x1880: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1882:
	/* 0x1882: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1883:
	/* 0x1883: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1883);
x86_l_1884:
	/* 0x1884: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1889:
	/* 0x1889: jmp    1875 <filter_char_substring+0x1fb> */
	X86_SIM_X86_SUB_JMP(0x1889, 0x1875, x86_l_1875);

	/* native subroutine native_link_sub_188b */
x86_l_188b:
	/* 0x188b: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_188e:
	/* 0x188e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1893:
	/* 0x1893: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_1897:
	/* 0x1897: ja     190a <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1897, 0x190a, x86_l_190a);
x86_l_1899:
	/* 0x1899: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_18a3:
	/* 0x18a3: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18a7:
	/* 0x18a7: jae    18aa <filter_16ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18a7, 0x18aa, x86_l_18aa);
x86_l_18a9:
	/* 0x18a9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_18a9);
x86_l_18aa:
	/* 0x18aa: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_18af:
	/* 0x18af: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18b3:
	/* 0x18b3: jae    18ca <filter_16ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18b3, 0x18ca, x86_l_18ca);
x86_l_18b5:
	/* 0x18b5: movzx  edx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_18b8:
	/* 0x18b8: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18bb:
	/* 0x18bb: jne    19e0 <filter_16ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18bb, 0x19e0, x86_l_19e0);
x86_l_18c1:
	/* 0x18c1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c3:
	/* 0x18c3: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_18c6:
	/* 0x18c6: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_18c9:
	/* 0x18c9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_18a9);
x86_l_18ca:
	/* 0x18ca: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_18ce:
	/* 0x18ce: jne    190a <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18ce, 0x190a, x86_l_190a);
x86_l_18d0:
	/* 0x18d0: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_18d3:
	/* 0x18d3: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_18d6:
	/* 0x18d6: jne    18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18d6, 0x18a9, x86_l_18a9);
x86_l_18d8:
	/* 0x18d8: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18db:
	/* 0x18db: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_18de:
	/* 0x18de: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18de, 0x1aa2, x86_l_1aa2);
x86_l_18e4:
	/* 0x18e4: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_18e7:
	/* 0x18e7: jne    18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18e7, 0x18a9, x86_l_18a9);
x86_l_18e9:
	/* 0x18e9: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_18ec:
	/* 0x18ec: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18ec, 0x1aa2, x86_l_1aa2);
x86_l_18f2:
	/* 0x18f2: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_18f5:
	/* 0x18f5: jne    18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x18f5, 0x18a9, x86_l_18a9);
x86_l_18f7:
	/* 0x18f7: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_18fa:
	/* 0x18fa: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x18fa, 0x1aa2, x86_l_1aa2);
x86_l_1900:
	/* 0x1900: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1903:
	/* 0x1903: jne    18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1903, 0x18a9, x86_l_18a9);
x86_l_1905:
	/* 0x1905: jmp    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1905, 0x1aa2, x86_l_1aa2);
x86_l_190a:
	/* 0x190a: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_190d:
	/* 0x190d: je     197c <filter_16ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x190d, 0x197c, x86_l_197c);
x86_l_190f:
	/* 0x190f: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1912:
	/* 0x1912: jne    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1912, 0x1aa2, x86_l_1aa2);
x86_l_1918:
	/* 0x1918: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_191b:
	/* 0x191b: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_191e:
	/* 0x191e: ja     1a69 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x191e, 0x1a69, x86_l_1a69);
x86_l_1924:
	/* 0x1924: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1929:
	/* 0x1929: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_192c:
	/* 0x192c: jae    1a69 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x192c, 0x1a69, x86_l_1a69);
x86_l_1932:
	/* 0x1932: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1935:
	/* 0x1935: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1938:
	/* 0x1938: jg     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1938, 0x18a9, x86_l_18a9);
x86_l_193e:
	/* 0x193e: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1941:
	/* 0x1941: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1944:
	/* 0x1944: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1944, 0x1aa2, x86_l_1aa2);
x86_l_194a:
	/* 0x194a: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_194d:
	/* 0x194d: jg     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x194d, 0x18a9, x86_l_18a9);
x86_l_1953:
	/* 0x1953: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1956:
	/* 0x1956: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1956, 0x1aa2, x86_l_1aa2);
x86_l_195c:
	/* 0x195c: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_195f:
	/* 0x195f: jg     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x195f, 0x18a9, x86_l_18a9);
x86_l_1965:
	/* 0x1965: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1968:
	/* 0x1968: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1968, 0x1aa2, x86_l_1aa2);
x86_l_196e:
	/* 0x196e: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1971:
	/* 0x1971: jg     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1971, 0x18a9, x86_l_18a9);
x86_l_1977:
	/* 0x1977: jmp    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1977, 0x1aa2, x86_l_1aa2);
x86_l_197c:
	/* 0x197c: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_197f:
	/* 0x197f: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1982:
	/* 0x1982: ja     1a2e <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1982, 0x1a2e, x86_l_1a2e);
x86_l_1988:
	/* 0x1988: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_198d:
	/* 0x198d: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1990:
	/* 0x1990: jae    1a2e <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1990, 0x1a2e, x86_l_1a2e);
x86_l_1996:
	/* 0x1996: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1999:
	/* 0x1999: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_199c:
	/* 0x199c: jl     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x199c, 0x18a9, x86_l_18a9);
x86_l_19a2:
	/* 0x19a2: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19a5:
	/* 0x19a5: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_19a8:
	/* 0x19a8: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19a8, 0x1aa2, x86_l_1aa2);
x86_l_19ae:
	/* 0x19ae: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19b1:
	/* 0x19b1: jl     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19b1, 0x18a9, x86_l_18a9);
x86_l_19b7:
	/* 0x19b7: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_19ba:
	/* 0x19ba: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19ba, 0x1aa2, x86_l_1aa2);
x86_l_19c0:
	/* 0x19c0: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19c3:
	/* 0x19c3: jl     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19c3, 0x18a9, x86_l_18a9);
x86_l_19c9:
	/* 0x19c9: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_19cc:
	/* 0x19cc: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19cc, 0x1aa2, x86_l_1aa2);
x86_l_19d2:
	/* 0x19d2: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_19d5:
	/* 0x19d5: jl     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x19d5, 0x18a9, x86_l_18a9);
x86_l_19db:
	/* 0x19db: jmp    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x19db, 0x1aa2, x86_l_1aa2);
x86_l_19e0:
	/* 0x19e0: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19e3:
	/* 0x19e3: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_19e6:
	/* 0x19e6: jb     1a0d <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19e6, 0x1a0d, x86_l_1a0d);
x86_l_19e8:
	/* 0x19e8: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_19eb:
	/* 0x19eb: je     18c1 <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19eb, 0x18c1, x86_l_18c1);
x86_l_19f1:
	/* 0x19f1: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_19f4:
	/* 0x19f4: jb     1a0d <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x19f4, 0x1a0d, x86_l_1a0d);
x86_l_19f6:
	/* 0x19f6: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19f9:
	/* 0x19f9: je     18c1 <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x19f9, 0x18c1, x86_l_18c1);
x86_l_19ff:
	/* 0x19ff: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a02:
	/* 0x1a02: jb     1a0d <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a02, 0x1a0d, x86_l_1a0d);
x86_l_1a04:
	/* 0x1a04: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a07:
	/* 0x1a07: je     18c1 <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a07, 0x18c1, x86_l_18c1);
x86_l_1a0d:
	/* 0x1a0d: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1a10:
	/* 0x1a10: ja     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a10, 0x1aa2, x86_l_1aa2);
x86_l_1a16:
	/* 0x1a16: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1a18:
	/* 0x1a18: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1a22:
	/* 0x1a22: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a26:
	/* 0x1a26: jb     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a26, 0x18a9, x86_l_18a9);
x86_l_1a2c:
	/* 0x1a2c: jmp    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1a2c, 0x1aa2, x86_l_1aa2);
x86_l_1a2e:
	/* 0x1a2e: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a31:
	/* 0x1a31: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a34:
	/* 0x1a34: jb     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a34, 0x18a9, x86_l_18a9);
x86_l_1a3a:
	/* 0x1a3a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3d:
	/* 0x1a3d: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a40:
	/* 0x1a40: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a40, 0x1aa2, x86_l_1aa2);
x86_l_1a42:
	/* 0x1a42: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a45:
	/* 0x1a45: jb     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a45, 0x18a9, x86_l_18a9);
x86_l_1a4b:
	/* 0x1a4b: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a4e:
	/* 0x1a4e: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a4e, 0x1aa2, x86_l_1aa2);
x86_l_1a50:
	/* 0x1a50: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a53:
	/* 0x1a53: jb     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a53, 0x18a9, x86_l_18a9);
x86_l_1a59:
	/* 0x1a59: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a5c:
	/* 0x1a5c: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a5c, 0x1aa2, x86_l_1aa2);
x86_l_1a5e:
	/* 0x1a5e: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a61:
	/* 0x1a61: jb     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a61, 0x18a9, x86_l_18a9);
x86_l_1a67:
	/* 0x1a67: jmp    1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1a67, 0x1aa2, x86_l_1aa2);
x86_l_1a69:
	/* 0x1a69: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a6c:
	/* 0x1a6c: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a6f:
	/* 0x1a6f: ja     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a6f, 0x18a9, x86_l_18a9);
x86_l_1a75:
	/* 0x1a75: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a78:
	/* 0x1a78: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a7b:
	/* 0x1a7b: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a7b, 0x1aa2, x86_l_1aa2);
x86_l_1a7d:
	/* 0x1a7d: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a80:
	/* 0x1a80: ja     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a80, 0x18a9, x86_l_18a9);
x86_l_1a86:
	/* 0x1a86: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a89:
	/* 0x1a89: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a89, 0x1aa2, x86_l_1aa2);
x86_l_1a8b:
	/* 0x1a8b: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a8e:
	/* 0x1a8e: ja     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a8e, 0x18a9, x86_l_18a9);
x86_l_1a94:
	/* 0x1a94: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a97:
	/* 0x1a97: jb     1aa2 <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a97, 0x1aa2, x86_l_1aa2);
x86_l_1a99:
	/* 0x1a99: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a9c:
	/* 0x1a9c: ja     18a9 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a9c, 0x18a9, x86_l_18a9);
x86_l_1aa2:
	/* 0x1aa2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aa4:
	/* 0x1aa4: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_18a9);

	/* native subroutine native_link_sub_1aa5 */
x86_l_1aa5:
	/* 0x1aa5: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1aa8:
	/* 0x1aa8: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1aab:
	/* 0x1aab: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1aae:
	/* 0x1aae: ja     1b95 <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1aae, 0x1b95, x86_l_1b95);
x86_l_1ab4:
	/* 0x1ab4: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1ab9:
	/* 0x1ab9: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1abc:
	/* 0x1abc: jae    1b95 <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1abc, 0x1b95, x86_l_1b95);
x86_l_1ac2:
	/* 0x1ac2: movsx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ac5:
	/* 0x1ac5: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1ac8:
	/* 0x1ac8: jne    1b30 <filter_16ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1ac8, 0x1b30, x86_l_1b30);
x86_l_1aca:
	/* 0x1aca: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1acf:
	/* 0x1acf: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ad2:
	/* 0x1ad2: jg     1add <filter_16ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ad2, 0x1add, x86_l_1add);
x86_l_1ad4:
	/* 0x1ad4: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1ad7:
	/* 0x1ad7: jge    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1ad7, 0x1bac, x86_l_1bac);
x86_l_1add:
	/* 0x1add: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ae0:
	/* 0x1ae0: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ae3:
	/* 0x1ae3: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ae3, 0x1c4c, x86_l_1c4c);
x86_l_1ae9:
	/* 0x1ae9: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1aec:
	/* 0x1aec: jg     1af7 <filter_16ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1aec, 0x1af7, x86_l_1af7);
x86_l_1aee:
	/* 0x1aee: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1af1:
	/* 0x1af1: jge    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1af1, 0x1bac, x86_l_1bac);
x86_l_1af7:
	/* 0x1af7: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1afa:
	/* 0x1afa: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1afa, 0x1c4c, x86_l_1c4c);
x86_l_1b00:
	/* 0x1b00: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b03:
	/* 0x1b03: jg     1b0e <filter_16ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b03, 0x1b0e, x86_l_1b0e);
x86_l_1b05:
	/* 0x1b05: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b08:
	/* 0x1b08: jge    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b08, 0x1bac, x86_l_1bac);
x86_l_1b0e:
	/* 0x1b0e: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1b11:
	/* 0x1b11: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b11, 0x1c4c, x86_l_1c4c);
x86_l_1b17:
	/* 0x1b17: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b19:
	/* 0x1b19: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b1c:
	/* 0x1b1c: jg     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1b1c, 0x1c4e, x86_l_1c4e);
x86_l_1b22:
	/* 0x1b22: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b25:
	/* 0x1b25: jge    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1b25, 0x1bac, x86_l_1bac);
x86_l_1b2b:
	/* 0x1b2b: jmp    1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1b2b, 0x1c4e, x86_l_1c4e);
x86_l_1b30:
	/* 0x1b30: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b33:
	/* 0x1b33: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b36:
	/* 0x1b36: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1b3a:
	/* 0x1b3a: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b3d:
	/* 0x1b3d: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1b40:
	/* 0x1b40: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1b43:
	/* 0x1b43: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1b46:
	/* 0x1b46: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b46, 0x1c4e, x86_l_1c4e);
x86_l_1b4c:
	/* 0x1b4c: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b4f:
	/* 0x1b4f: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1b53:
	/* 0x1b53: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b56:
	/* 0x1b56: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1b5a:
	/* 0x1b5a: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1b5d:
	/* 0x1b5d: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1b60:
	/* 0x1b60: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1b63:
	/* 0x1b63: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b63, 0x1c4e, x86_l_1c4e);
x86_l_1b69:
	/* 0x1b69: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b6c:
	/* 0x1b6c: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1b70:
	/* 0x1b70: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1b73:
	/* 0x1b73: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1b77:
	/* 0x1b77: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1b7a:
	/* 0x1b7a: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1b7d:
	/* 0x1b7d: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1b80:
	/* 0x1b80: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b80, 0x1c4e, x86_l_1c4e);
x86_l_1b86:
	/* 0x1b86: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1b89:
	/* 0x1b89: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1b8c:
	/* 0x1b8c: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1b8f:
	/* 0x1b8f: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1b93:
	/* 0x1b93: jmp    1c08 <filter_16ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x1b93, 0x1c08, x86_l_1c08);
x86_l_1b95:
	/* 0x1b95: movzx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b98:
	/* 0x1b98: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1b9b:
	/* 0x1b9b: jne    1bad <filter_16ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1b9b, 0x1bad, x86_l_1bad);
x86_l_1b9d:
	/* 0x1b9d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ba2:
	/* 0x1ba2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ba5:
	/* 0x1ba5: ja     1c10 <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ba5, 0x1c10, x86_l_1c10);
x86_l_1ba7:
	/* 0x1ba7: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1baa:
	/* 0x1baa: jb     1c10 <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1baa, 0x1c10, x86_l_1c10);
x86_l_1bac:
	/* 0x1bac: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1bac);
x86_l_1bad:
	/* 0x1bad: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bb0:
	/* 0x1bb0: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bb3:
	/* 0x1bb3: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1bb7:
	/* 0x1bb7: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1bba:
	/* 0x1bba: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1bbd:
	/* 0x1bbd: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1bc0:
	/* 0x1bc0: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1bc3:
	/* 0x1bc3: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bc3, 0x1c4e, x86_l_1c4e);
x86_l_1bc9:
	/* 0x1bc9: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bcc:
	/* 0x1bcc: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1bd0:
	/* 0x1bd0: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1bd3:
	/* 0x1bd3: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1bd7:
	/* 0x1bd7: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1bda:
	/* 0x1bda: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1bdd:
	/* 0x1bdd: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1be0:
	/* 0x1be0: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1be0, 0x1c4e, x86_l_1c4e);
x86_l_1be2:
	/* 0x1be2: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1be5:
	/* 0x1be5: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1be9:
	/* 0x1be9: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1bec:
	/* 0x1bec: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1bf0:
	/* 0x1bf0: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1bf3:
	/* 0x1bf3: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1bf6:
	/* 0x1bf6: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1bf9:
	/* 0x1bf9: jb     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bf9, 0x1c4e, x86_l_1c4e);
x86_l_1bfb:
	/* 0x1bfb: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1bfe:
	/* 0x1bfe: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1c01:
	/* 0x1c01: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c04:
	/* 0x1c04: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1c08:
	/* 0x1c08: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c0b:
	/* 0x1c0b: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1c0e:
	/* 0x1c0e: jmp    1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1c0e, 0x1c4e, x86_l_1c4e);
x86_l_1c10:
	/* 0x1c10: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c13:
	/* 0x1c13: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1c16:
	/* 0x1c16: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c16, 0x1c4c, x86_l_1c4c);
x86_l_1c18:
	/* 0x1c18: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c1b:
	/* 0x1c1b: ja     1c22 <filter_16ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c1b, 0x1c22, x86_l_1c22);
x86_l_1c1d:
	/* 0x1c1d: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c20:
	/* 0x1c20: jae    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c20, 0x1bac, x86_l_1bac);
x86_l_1c22:
	/* 0x1c22: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1c25:
	/* 0x1c25: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c25, 0x1c4c, x86_l_1c4c);
x86_l_1c27:
	/* 0x1c27: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c2a:
	/* 0x1c2a: ja     1c35 <filter_16ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c2a, 0x1c35, x86_l_1c35);
x86_l_1c2c:
	/* 0x1c2c: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c2f:
	/* 0x1c2f: jae    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c2f, 0x1bac, x86_l_1bac);
x86_l_1c35:
	/* 0x1c35: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1c38:
	/* 0x1c38: jb     1c4c <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c38, 0x1c4c, x86_l_1c4c);
x86_l_1c3a:
	/* 0x1c3a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c3c:
	/* 0x1c3c: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c3f:
	/* 0x1c3f: ja     1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1c3f, 0x1c4e, x86_l_1c4e);
x86_l_1c41:
	/* 0x1c41: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c44:
	/* 0x1c44: jae    1bac <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1c44, 0x1bac, x86_l_1bac);
x86_l_1c4a:
	/* 0x1c4a: jmp    1c4e <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1c4a, 0x1c4e, x86_l_1c4e);
x86_l_1c4c:
	/* 0x1c4c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c4e:
	/* 0x1c4e: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_1c51:
	/* 0x1c51: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1c54:
	/* 0x1c54: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1c57:
	/* 0x1c57: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c59:
	/* 0x1c59: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1c5c:
	/* 0x1c5c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1bac);

	/* native subroutine native_link_sub_1c5d */
x86_l_1c5d:
	/* 0x1c5d: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c5f:
	/* 0x1c5f: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c60:
	/* 0x1c60: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1c64:
	/* 0x1c64: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c67:
	/* 0x1c67: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c6a:
	/* 0x1c6a: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1c6e:
	/* 0x1c6e: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c72:
	/* 0x1c72: mov    rdi,QWORD PTR [rip+0xfb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_1c79:
	/* 0x1c79: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1c7e:
	/* 0x1c7e: call   2c33 <filter_file_type+0x6b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c83:
	/* 0x1c83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c86:
	/* 0x1c86: je     1cba <filter_16ty_map+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1c86, 0x1cba, x86_l_1cba);
x86_l_1c88:
	/* 0x1c88: movzx  ecx,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1c8c:
	/* 0x1c8c: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c91:
	/* 0x1c91: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c96:
	/* 0x1c96: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c99:
	/* 0x1c99: call   2c4e <filter_file_type+0x6d0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c9e:
	/* 0x1c9e: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ca1:
	/* 0x1ca1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ca3:
	/* 0x1ca3: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_1ca6:
	/* 0x1ca6: ja     1cd4 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ca6, 0x1cd4, x86_l_1cd4);
x86_l_1ca8:
	/* 0x1ca8: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_1cad:
	/* 0x1cad: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1cb0:
	/* 0x1cb0: jae    1cc4 <filter_16ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cb0, 0x1cc4, x86_l_1cc4);
x86_l_1cb2:
	/* 0x1cb2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb5:
	/* 0x1cb5: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1cb8:
	/* 0x1cb8: jmp    1cd4 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JMP(0x1cb8, 0x1cd4, x86_l_1cd4);
x86_l_1cba:
	/* 0x1cba: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cbc:
	/* 0x1cbc: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1cc0:
	/* 0x1cc0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cc1:
	/* 0x1cc1: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cc3:
	/* 0x1cc3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cc3);
x86_l_1cc4:
	/* 0x1cc4: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_1cc9:
	/* 0x1cc9: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1ccc:
	/* 0x1ccc: jae    1cd4 <filter_16ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1ccc, 0x1cd4, x86_l_1cd4);
x86_l_1cce:
	/* 0x1cce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cd1:
	/* 0x1cd1: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1cd4:
	/* 0x1cd4: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1cd7:
	/* 0x1cd7: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1cdb:
	/* 0x1cdb: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cdc:
	/* 0x1cdc: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cde:
	/* 0x1cde: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cc3);

	/* native subroutine native_link_sub_1cdf */
x86_l_1cdf:
	/* 0x1cdf: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ce2:
	/* 0x1ce2: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ce7:
	/* 0x1ce7: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_1ceb:
	/* 0x1ceb: ja     1d5c <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ceb, 0x1d5c, x86_l_1d5c);
x86_l_1ced:
	/* 0x1ced: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_1cf7:
	/* 0x1cf7: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cfb:
	/* 0x1cfb: jae    1cfe <filter_32ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1cfb, 0x1cfe, x86_l_1cfe);
x86_l_1cfd:
	/* 0x1cfd: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cfd);
x86_l_1cfe:
	/* 0x1cfe: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_1d03:
	/* 0x1d03: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d07:
	/* 0x1d07: jae    1d1d <filter_32ty_selector_val+0x3e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d07, 0x1d1d, x86_l_1d1d);
x86_l_1d09:
	/* 0x1d09: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d0b:
	/* 0x1d0b: cmp    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d0e:
	/* 0x1d0e: jne    1e30 <filter_32ty_selector_val+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d0e, 0x1e30, x86_l_1e30);
x86_l_1d14:
	/* 0x1d14: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d16:
	/* 0x1d16: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1d19:
	/* 0x1d19: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d1c:
	/* 0x1d1c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cfd);
x86_l_1d1d:
	/* 0x1d1d: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_1d21:
	/* 0x1d21: jne    1d5c <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d21, 0x1d5c, x86_l_1d5c);
x86_l_1d23:
	/* 0x1d23: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d25:
	/* 0x1d25: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1d28:
	/* 0x1d28: jne    1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d28, 0x1cfd, x86_l_1cfd);
x86_l_1d2a:
	/* 0x1d2a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d2d:
	/* 0x1d2d: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1d30:
	/* 0x1d30: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d30, 0x1ef0, x86_l_1ef0);
x86_l_1d36:
	/* 0x1d36: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1d39:
	/* 0x1d39: jne    1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d39, 0x1cfd, x86_l_1cfd);
x86_l_1d3b:
	/* 0x1d3b: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1d3e:
	/* 0x1d3e: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d3e, 0x1ef0, x86_l_1ef0);
x86_l_1d44:
	/* 0x1d44: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1d47:
	/* 0x1d47: jne    1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d47, 0x1cfd, x86_l_1cfd);
x86_l_1d49:
	/* 0x1d49: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1d4c:
	/* 0x1d4c: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d4c, 0x1ef0, x86_l_1ef0);
x86_l_1d52:
	/* 0x1d52: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1d55:
	/* 0x1d55: jne    1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d55, 0x1cfd, x86_l_1cfd);
x86_l_1d57:
	/* 0x1d57: jmp    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1d57, 0x1ef0, x86_l_1ef0);
x86_l_1d5c:
	/* 0x1d5c: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1d5f:
	/* 0x1d5f: je     1dcd <filter_32ty_selector_val+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1d5f, 0x1dcd, x86_l_1dcd);
x86_l_1d61:
	/* 0x1d61: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d64:
	/* 0x1d64: jne    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1d64, 0x1ef0, x86_l_1ef0);
x86_l_1d6a:
	/* 0x1d6a: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d6d:
	/* 0x1d6d: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1d70:
	/* 0x1d70: ja     1eb8 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d70, 0x1eb8, x86_l_1eb8);
x86_l_1d76:
	/* 0x1d76: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1d7b:
	/* 0x1d7b: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1d7e:
	/* 0x1d7e: jae    1eb8 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d7e, 0x1eb8, x86_l_1eb8);
x86_l_1d84:
	/* 0x1d84: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d86:
	/* 0x1d86: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d89:
	/* 0x1d89: jl     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d89, 0x1cfd, x86_l_1cfd);
x86_l_1d8f:
	/* 0x1d8f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d92:
	/* 0x1d92: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1d95:
	/* 0x1d95: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d95, 0x1ef0, x86_l_1ef0);
x86_l_1d9b:
	/* 0x1d9b: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1d9e:
	/* 0x1d9e: jl     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1d9e, 0x1cfd, x86_l_1cfd);
x86_l_1da4:
	/* 0x1da4: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1da7:
	/* 0x1da7: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1da7, 0x1ef0, x86_l_1ef0);
x86_l_1dad:
	/* 0x1dad: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1db0:
	/* 0x1db0: jl     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1db0, 0x1cfd, x86_l_1cfd);
x86_l_1db6:
	/* 0x1db6: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1db9:
	/* 0x1db9: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1db9, 0x1ef0, x86_l_1ef0);
x86_l_1dbf:
	/* 0x1dbf: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1dc2:
	/* 0x1dc2: jl     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1dc2, 0x1cfd, x86_l_1cfd);
x86_l_1dc8:
	/* 0x1dc8: jmp    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1dc8, 0x1ef0, x86_l_1ef0);
x86_l_1dcd:
	/* 0x1dcd: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1dd0:
	/* 0x1dd0: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1dd3:
	/* 0x1dd3: ja     1e7e <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1dd3, 0x1e7e, x86_l_1e7e);
x86_l_1dd9:
	/* 0x1dd9: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1dde:
	/* 0x1dde: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1de1:
	/* 0x1de1: jae    1e7e <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1de1, 0x1e7e, x86_l_1e7e);
x86_l_1de7:
	/* 0x1de7: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1de9:
	/* 0x1de9: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1dec:
	/* 0x1dec: jg     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1dec, 0x1cfd, x86_l_1cfd);
x86_l_1df2:
	/* 0x1df2: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1df5:
	/* 0x1df5: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1df8:
	/* 0x1df8: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1df8, 0x1ef0, x86_l_1ef0);
x86_l_1dfe:
	/* 0x1dfe: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e01:
	/* 0x1e01: jg     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e01, 0x1cfd, x86_l_1cfd);
x86_l_1e07:
	/* 0x1e07: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e0a:
	/* 0x1e0a: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e0a, 0x1ef0, x86_l_1ef0);
x86_l_1e10:
	/* 0x1e10: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e13:
	/* 0x1e13: jg     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e13, 0x1cfd, x86_l_1cfd);
x86_l_1e19:
	/* 0x1e19: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1e1c:
	/* 0x1e1c: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e1c, 0x1ef0, x86_l_1ef0);
x86_l_1e22:
	/* 0x1e22: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e25:
	/* 0x1e25: jg     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e25, 0x1cfd, x86_l_1cfd);
x86_l_1e2b:
	/* 0x1e2b: jmp    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1e2b, 0x1ef0, x86_l_1ef0);
x86_l_1e30:
	/* 0x1e30: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e33:
	/* 0x1e33: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e36:
	/* 0x1e36: jb     1e5d <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e36, 0x1e5d, x86_l_1e5d);
x86_l_1e38:
	/* 0x1e38: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e3b:
	/* 0x1e3b: je     1d14 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e3b, 0x1d14, x86_l_1d14);
x86_l_1e41:
	/* 0x1e41: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e44:
	/* 0x1e44: jb     1e5d <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e44, 0x1e5d, x86_l_1e5d);
x86_l_1e46:
	/* 0x1e46: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1e49:
	/* 0x1e49: je     1d14 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e49, 0x1d14, x86_l_1d14);
x86_l_1e4f:
	/* 0x1e4f: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1e52:
	/* 0x1e52: jb     1e5d <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e52, 0x1e5d, x86_l_1e5d);
x86_l_1e54:
	/* 0x1e54: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e57:
	/* 0x1e57: je     1d14 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e57, 0x1d14, x86_l_1d14);
x86_l_1e5d:
	/* 0x1e5d: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1e60:
	/* 0x1e60: ja     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e60, 0x1ef0, x86_l_1ef0);
x86_l_1e66:
	/* 0x1e66: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1e68:
	/* 0x1e68: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1e72:
	/* 0x1e72: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e76:
	/* 0x1e76: jb     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e76, 0x1cfd, x86_l_1cfd);
x86_l_1e7c:
	/* 0x1e7c: jmp    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1e7c, 0x1ef0, x86_l_1ef0);
x86_l_1e7e:
	/* 0x1e7e: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e80:
	/* 0x1e80: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e83:
	/* 0x1e83: ja     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e83, 0x1cfd, x86_l_1cfd);
x86_l_1e89:
	/* 0x1e89: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e8c:
	/* 0x1e8c: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e8f:
	/* 0x1e8f: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e8f, 0x1ef0, x86_l_1ef0);
x86_l_1e91:
	/* 0x1e91: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e94:
	/* 0x1e94: ja     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e94, 0x1cfd, x86_l_1cfd);
x86_l_1e9a:
	/* 0x1e9a: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e9d:
	/* 0x1e9d: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e9d, 0x1ef0, x86_l_1ef0);
x86_l_1e9f:
	/* 0x1e9f: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1ea2:
	/* 0x1ea2: ja     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ea2, 0x1cfd, x86_l_1cfd);
x86_l_1ea8:
	/* 0x1ea8: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1eab:
	/* 0x1eab: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eab, 0x1ef0, x86_l_1ef0);
x86_l_1ead:
	/* 0x1ead: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1eb0:
	/* 0x1eb0: ja     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1eb0, 0x1cfd, x86_l_1cfd);
x86_l_1eb6:
	/* 0x1eb6: jmp    1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1eb6, 0x1ef0, x86_l_1ef0);
x86_l_1eb8:
	/* 0x1eb8: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eba:
	/* 0x1eba: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1ebd:
	/* 0x1ebd: jb     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ebd, 0x1cfd, x86_l_1cfd);
x86_l_1ec3:
	/* 0x1ec3: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ec6:
	/* 0x1ec6: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ec9:
	/* 0x1ec9: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ec9, 0x1ef0, x86_l_1ef0);
x86_l_1ecb:
	/* 0x1ecb: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ece:
	/* 0x1ece: jb     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ece, 0x1cfd, x86_l_1cfd);
x86_l_1ed4:
	/* 0x1ed4: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ed7:
	/* 0x1ed7: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ed7, 0x1ef0, x86_l_1ef0);
x86_l_1ed9:
	/* 0x1ed9: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1edc:
	/* 0x1edc: jb     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1edc, 0x1cfd, x86_l_1cfd);
x86_l_1ee2:
	/* 0x1ee2: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1ee5:
	/* 0x1ee5: jb     1ef0 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ee5, 0x1ef0, x86_l_1ef0);
x86_l_1ee7:
	/* 0x1ee7: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1eea:
	/* 0x1eea: jb     1cfd <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1eea, 0x1cfd, x86_l_1cfd);
x86_l_1ef0:
	/* 0x1ef0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ef2:
	/* 0x1ef2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cfd);

	/* native subroutine native_link_sub_1ef3 */
x86_l_1ef3:
	/* 0x1ef3: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ef6:
	/* 0x1ef6: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1ef9:
	/* 0x1ef9: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1efc:
	/* 0x1efc: ja     1fe2 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1efc, 0x1fe2, x86_l_1fe2);
x86_l_1f02:
	/* 0x1f02: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1f07:
	/* 0x1f07: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f0a:
	/* 0x1f0a: jae    1fe2 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1f0a, 0x1fe2, x86_l_1fe2);
x86_l_1f10:
	/* 0x1f10: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f12:
	/* 0x1f12: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1f15:
	/* 0x1f15: jne    1f7d <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1f15, 0x1f7d, x86_l_1f7d);
x86_l_1f17:
	/* 0x1f17: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f1c:
	/* 0x1f1c: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f1f:
	/* 0x1f1f: jg     1f2a <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f1f, 0x1f2a, x86_l_1f2a);
x86_l_1f21:
	/* 0x1f21: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f24:
	/* 0x1f24: jle    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f24, 0x1ff8, x86_l_1ff8);
x86_l_1f2a:
	/* 0x1f2a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f2d:
	/* 0x1f2d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f30:
	/* 0x1f30: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f30, 0x2098, x86_l_2098);
x86_l_1f36:
	/* 0x1f36: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f39:
	/* 0x1f39: jg     1f44 <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f39, 0x1f44, x86_l_1f44);
x86_l_1f3b:
	/* 0x1f3b: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f3e:
	/* 0x1f3e: jle    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f3e, 0x1ff8, x86_l_1ff8);
x86_l_1f44:
	/* 0x1f44: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1f47:
	/* 0x1f47: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f47, 0x2098, x86_l_2098);
x86_l_1f4d:
	/* 0x1f4d: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f50:
	/* 0x1f50: jg     1f5b <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f50, 0x1f5b, x86_l_1f5b);
x86_l_1f52:
	/* 0x1f52: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1f55:
	/* 0x1f55: jle    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f55, 0x1ff8, x86_l_1ff8);
x86_l_1f5b:
	/* 0x1f5b: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1f5e:
	/* 0x1f5e: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f5e, 0x2098, x86_l_2098);
x86_l_1f64:
	/* 0x1f64: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f66:
	/* 0x1f66: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f69:
	/* 0x1f69: jg     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f69, 0x209a, x86_l_209a);
x86_l_1f6f:
	/* 0x1f6f: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1f72:
	/* 0x1f72: jle    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1f72, 0x1ff8, x86_l_1ff8);
x86_l_1f78:
	/* 0x1f78: jmp    209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x1f78, 0x209a, x86_l_209a);
x86_l_1f7d:
	/* 0x1f7d: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f80:
	/* 0x1f80: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f83:
	/* 0x1f83: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1f87:
	/* 0x1f87: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f8a:
	/* 0x1f8a: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1f8d:
	/* 0x1f8d: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1f90:
	/* 0x1f90: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f93:
	/* 0x1f93: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f93, 0x209a, x86_l_209a);
x86_l_1f99:
	/* 0x1f99: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f9c:
	/* 0x1f9c: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fa0:
	/* 0x1fa0: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1fa3:
	/* 0x1fa3: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fa7:
	/* 0x1fa7: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1faa:
	/* 0x1faa: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1fad:
	/* 0x1fad: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1fb0:
	/* 0x1fb0: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fb0, 0x209a, x86_l_209a);
x86_l_1fb6:
	/* 0x1fb6: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1fb9:
	/* 0x1fb9: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fbd:
	/* 0x1fbd: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1fc0:
	/* 0x1fc0: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fc4:
	/* 0x1fc4: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1fc7:
	/* 0x1fc7: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1fca:
	/* 0x1fca: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1fcd:
	/* 0x1fcd: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fcd, 0x209a, x86_l_209a);
x86_l_1fd3:
	/* 0x1fd3: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fd6:
	/* 0x1fd6: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fd9:
	/* 0x1fd9: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1fdc:
	/* 0x1fdc: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1fe0:
	/* 0x1fe0: jmp    2054 <filter_32ty_range+0x161> */
	X86_SIM_X86_SUB_JMP(0x1fe0, 0x2054, x86_l_2054);
x86_l_1fe2:
	/* 0x1fe2: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe4:
	/* 0x1fe4: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1fe7:
	/* 0x1fe7: jne    1ff9 <filter_32ty_range+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1fe7, 0x1ff9, x86_l_1ff9);
x86_l_1fe9:
	/* 0x1fe9: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1fee:
	/* 0x1fee: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ff1:
	/* 0x1ff1: ja     205c <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ff1, 0x205c, x86_l_205c);
x86_l_1ff3:
	/* 0x1ff3: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ff6:
	/* 0x1ff6: ja     205c <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ff6, 0x205c, x86_l_205c);
x86_l_1ff8:
	/* 0x1ff8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1ff8);
x86_l_1ff9:
	/* 0x1ff9: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ffc:
	/* 0x1ffc: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fff:
	/* 0x1fff: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2003:
	/* 0x2003: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2006:
	/* 0x2006: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2009:
	/* 0x2009: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_200c:
	/* 0x200c: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_200f:
	/* 0x200f: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x200f, 0x209a, x86_l_209a);
x86_l_2015:
	/* 0x2015: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2018:
	/* 0x2018: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_201c:
	/* 0x201c: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_201f:
	/* 0x201f: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2023:
	/* 0x2023: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2026:
	/* 0x2026: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2029:
	/* 0x2029: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_202c:
	/* 0x202c: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x202c, 0x209a, x86_l_209a);
x86_l_202e:
	/* 0x202e: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2031:
	/* 0x2031: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2035:
	/* 0x2035: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2038:
	/* 0x2038: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_203c:
	/* 0x203c: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_203f:
	/* 0x203f: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2042:
	/* 0x2042: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2045:
	/* 0x2045: jb     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2045, 0x209a, x86_l_209a);
x86_l_2047:
	/* 0x2047: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_204a:
	/* 0x204a: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_204d:
	/* 0x204d: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_2050:
	/* 0x2050: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2054:
	/* 0x2054: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2057:
	/* 0x2057: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_205a:
	/* 0x205a: jmp    209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x205a, 0x209a, x86_l_209a);
x86_l_205c:
	/* 0x205c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_205f:
	/* 0x205f: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2062:
	/* 0x2062: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2062, 0x2098, x86_l_2098);
x86_l_2064:
	/* 0x2064: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2067:
	/* 0x2067: ja     206e <filter_32ty_range+0x17b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2067, 0x206e, x86_l_206e);
x86_l_2069:
	/* 0x2069: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_206c:
	/* 0x206c: jbe    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x206c, 0x1ff8, x86_l_1ff8);
x86_l_206e:
	/* 0x206e: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2071:
	/* 0x2071: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2071, 0x2098, x86_l_2098);
x86_l_2073:
	/* 0x2073: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2076:
	/* 0x2076: ja     2081 <filter_32ty_range+0x18e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2076, 0x2081, x86_l_2081);
x86_l_2078:
	/* 0x2078: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_207b:
	/* 0x207b: jbe    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x207b, 0x1ff8, x86_l_1ff8);
x86_l_2081:
	/* 0x2081: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2084:
	/* 0x2084: jb     2098 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2084, 0x2098, x86_l_2098);
x86_l_2086:
	/* 0x2086: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2088:
	/* 0x2088: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_208b:
	/* 0x208b: ja     209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x208b, 0x209a, x86_l_209a);
x86_l_208d:
	/* 0x208d: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_2090:
	/* 0x2090: jbe    1ff8 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x2090, 0x1ff8, x86_l_1ff8);
x86_l_2096:
	/* 0x2096: jmp    209a <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x2096, 0x209a, x86_l_209a);
x86_l_2098:
	/* 0x2098: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_209a:
	/* 0x209a: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_209d:
	/* 0x209d: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_20a0:
	/* 0x20a0: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_20a3:
	/* 0x20a3: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_20a5:
	/* 0x20a5: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_20a8:
	/* 0x20a8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1ff8);

	/* native subroutine native_link_sub_20a9 */
x86_l_20a9:
	/* 0x20a9: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_20ab:
	/* 0x20ab: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20ac:
	/* 0x20ac: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_20b0:
	/* 0x20b0: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20b3:
	/* 0x20b3: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20b6:
	/* 0x20b6: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_20ba:
	/* 0x20ba: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_20be:
	/* 0x20be: mov    rdi,QWORD PTR [rip+0xb40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_20c5:
	/* 0x20c5: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_20ca:
	/* 0x20ca: call   2c0f <filter_file_type+0x691> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20cf:
	/* 0x20cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20d2:
	/* 0x20d2: je     2105 <filter_32ty_map+0x5c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x20d2, 0x2105, x86_l_2105);
x86_l_20d4:
	/* 0x20d4: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20d7:
	/* 0x20d7: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20dc:
	/* 0x20dc: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20e1:
	/* 0x20e1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20e4:
	/* 0x20e4: call   2c29 <filter_file_type+0x6ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20e9:
	/* 0x20e9: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_20ec:
	/* 0x20ec: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20ee:
	/* 0x20ee: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_20f1:
	/* 0x20f1: ja     211f <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20f1, 0x211f, x86_l_211f);
x86_l_20f3:
	/* 0x20f3: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_20f8:
	/* 0x20f8: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_20fb:
	/* 0x20fb: jae    210f <filter_32ty_map+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x20fb, 0x210f, x86_l_210f);
x86_l_20fd:
	/* 0x20fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2100:
	/* 0x2100: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2103:
	/* 0x2103: jmp    211f <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JMP(0x2103, 0x211f, x86_l_211f);
x86_l_2105:
	/* 0x2105: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2107:
	/* 0x2107: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_210b:
	/* 0x210b: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_210c:
	/* 0x210c: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_210e:
	/* 0x210e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_210e);
x86_l_210f:
	/* 0x210f: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_2114:
	/* 0x2114: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2117:
	/* 0x2117: jae    211f <filter_32ty_map+0x76> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2117, 0x211f, x86_l_211f);
x86_l_2119:
	/* 0x2119: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_211c:
	/* 0x211c: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_211f:
	/* 0x211f: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2122:
	/* 0x2122: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2126:
	/* 0x2126: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2127:
	/* 0x2127: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2129:
	/* 0x2129: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_210e);

	/* native subroutine native_link_sub_212a */
x86_l_212a:
	/* 0x212a: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_212d:
	/* 0x212d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2132:
	/* 0x2132: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_2136:
	/* 0x2136: ja     21a9 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2136, 0x21a9, x86_l_21a9);
x86_l_2138:
	/* 0x2138: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_2142:
	/* 0x2142: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2146:
	/* 0x2146: jae    2149 <filter_8ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2146, 0x2149, x86_l_2149);
x86_l_2148:
	/* 0x2148: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2148);
x86_l_2149:
	/* 0x2149: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_214e:
	/* 0x214e: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2152:
	/* 0x2152: jae    2169 <filter_8ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2152, 0x2169, x86_l_2169);
x86_l_2154:
	/* 0x2154: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2157:
	/* 0x2157: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_215a:
	/* 0x215a: jne    227f <filter_8ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x215a, 0x227f, x86_l_227f);
x86_l_2160:
	/* 0x2160: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2162:
	/* 0x2162: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2165:
	/* 0x2165: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2168:
	/* 0x2168: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2148);
x86_l_2169:
	/* 0x2169: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_216d:
	/* 0x216d: jne    21a9 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x216d, 0x21a9, x86_l_21a9);
x86_l_216f:
	/* 0x216f: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2172:
	/* 0x2172: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2175:
	/* 0x2175: jne    2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2175, 0x2148, x86_l_2148);
x86_l_2177:
	/* 0x2177: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_217a:
	/* 0x217a: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_217d:
	/* 0x217d: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x217d, 0x2341, x86_l_2341);
x86_l_2183:
	/* 0x2183: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2186:
	/* 0x2186: jne    2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2186, 0x2148, x86_l_2148);
x86_l_2188:
	/* 0x2188: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_218b:
	/* 0x218b: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x218b, 0x2341, x86_l_2341);
x86_l_2191:
	/* 0x2191: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2194:
	/* 0x2194: jne    2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2194, 0x2148, x86_l_2148);
x86_l_2196:
	/* 0x2196: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2199:
	/* 0x2199: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2199, 0x2341, x86_l_2341);
x86_l_219f:
	/* 0x219f: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_21a2:
	/* 0x21a2: jne    2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21a2, 0x2148, x86_l_2148);
x86_l_21a4:
	/* 0x21a4: jmp    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x21a4, 0x2341, x86_l_2341);
x86_l_21a9:
	/* 0x21a9: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_21ac:
	/* 0x21ac: je     221b <filter_8ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x21ac, 0x221b, x86_l_221b);
x86_l_21ae:
	/* 0x21ae: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_21b1:
	/* 0x21b1: jne    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x21b1, 0x2341, x86_l_2341);
x86_l_21b7:
	/* 0x21b7: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_21ba:
	/* 0x21ba: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_21bd:
	/* 0x21bd: ja     2308 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21bd, 0x2308, x86_l_2308);
x86_l_21c3:
	/* 0x21c3: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_21c8:
	/* 0x21c8: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_21cb:
	/* 0x21cb: jae    2308 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x21cb, 0x2308, x86_l_2308);
x86_l_21d1:
	/* 0x21d1: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21d4:
	/* 0x21d4: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21d7:
	/* 0x21d7: jg     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21d7, 0x2148, x86_l_2148);
x86_l_21dd:
	/* 0x21dd: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21e0:
	/* 0x21e0: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_21e3:
	/* 0x21e3: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21e3, 0x2341, x86_l_2341);
x86_l_21e9:
	/* 0x21e9: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_21ec:
	/* 0x21ec: jg     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21ec, 0x2148, x86_l_2148);
x86_l_21f2:
	/* 0x21f2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_21f5:
	/* 0x21f5: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f5, 0x2341, x86_l_2341);
x86_l_21fb:
	/* 0x21fb: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21fe:
	/* 0x21fe: jg     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x21fe, 0x2148, x86_l_2148);
x86_l_2204:
	/* 0x2204: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2207:
	/* 0x2207: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2207, 0x2341, x86_l_2341);
x86_l_220d:
	/* 0x220d: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2210:
	/* 0x2210: jg     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2210, 0x2148, x86_l_2148);
x86_l_2216:
	/* 0x2216: jmp    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2216, 0x2341, x86_l_2341);
x86_l_221b:
	/* 0x221b: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_221e:
	/* 0x221e: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2221:
	/* 0x2221: ja     22cd <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2221, 0x22cd, x86_l_22cd);
x86_l_2227:
	/* 0x2227: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_222c:
	/* 0x222c: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_222f:
	/* 0x222f: jae    22cd <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x222f, 0x22cd, x86_l_22cd);
x86_l_2235:
	/* 0x2235: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2238:
	/* 0x2238: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_223b:
	/* 0x223b: jl     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x223b, 0x2148, x86_l_2148);
x86_l_2241:
	/* 0x2241: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2244:
	/* 0x2244: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2247:
	/* 0x2247: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2247, 0x2341, x86_l_2341);
x86_l_224d:
	/* 0x224d: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2250:
	/* 0x2250: jl     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2250, 0x2148, x86_l_2148);
x86_l_2256:
	/* 0x2256: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2259:
	/* 0x2259: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2259, 0x2341, x86_l_2341);
x86_l_225f:
	/* 0x225f: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2262:
	/* 0x2262: jl     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2262, 0x2148, x86_l_2148);
x86_l_2268:
	/* 0x2268: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_226b:
	/* 0x226b: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x226b, 0x2341, x86_l_2341);
x86_l_2271:
	/* 0x2271: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2274:
	/* 0x2274: jl     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2274, 0x2148, x86_l_2148);
x86_l_227a:
	/* 0x227a: jmp    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x227a, 0x2341, x86_l_2341);
x86_l_227f:
	/* 0x227f: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2282:
	/* 0x2282: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2285:
	/* 0x2285: jb     22ac <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2285, 0x22ac, x86_l_22ac);
x86_l_2287:
	/* 0x2287: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_228a:
	/* 0x228a: je     2160 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x228a, 0x2160, x86_l_2160);
x86_l_2290:
	/* 0x2290: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2293:
	/* 0x2293: jb     22ac <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2293, 0x22ac, x86_l_22ac);
x86_l_2295:
	/* 0x2295: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2298:
	/* 0x2298: je     2160 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2298, 0x2160, x86_l_2160);
x86_l_229e:
	/* 0x229e: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_22a1:
	/* 0x22a1: jb     22ac <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22a1, 0x22ac, x86_l_22ac);
x86_l_22a3:
	/* 0x22a3: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22a6:
	/* 0x22a6: je     2160 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22a6, 0x2160, x86_l_2160);
x86_l_22ac:
	/* 0x22ac: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_22af:
	/* 0x22af: ja     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x22af, 0x2341, x86_l_2341);
x86_l_22b5:
	/* 0x22b5: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_22b7:
	/* 0x22b7: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_22c1:
	/* 0x22c1: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22c5:
	/* 0x22c5: jb     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22c5, 0x2148, x86_l_2148);
x86_l_22cb:
	/* 0x22cb: jmp    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x22cb, 0x2341, x86_l_2341);
x86_l_22cd:
	/* 0x22cd: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_22d0:
	/* 0x22d0: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22d3:
	/* 0x22d3: jb     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22d3, 0x2148, x86_l_2148);
x86_l_22d9:
	/* 0x22d9: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22dc:
	/* 0x22dc: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_22df:
	/* 0x22df: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22df, 0x2341, x86_l_2341);
x86_l_22e1:
	/* 0x22e1: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_22e4:
	/* 0x22e4: jb     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22e4, 0x2148, x86_l_2148);
x86_l_22ea:
	/* 0x22ea: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_22ed:
	/* 0x22ed: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22ed, 0x2341, x86_l_2341);
x86_l_22ef:
	/* 0x22ef: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22f2:
	/* 0x22f2: jb     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22f2, 0x2148, x86_l_2148);
x86_l_22f8:
	/* 0x22f8: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_22fb:
	/* 0x22fb: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22fb, 0x2341, x86_l_2341);
x86_l_22fd:
	/* 0x22fd: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2300:
	/* 0x2300: jb     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2300, 0x2148, x86_l_2148);
x86_l_2306:
	/* 0x2306: jmp    2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2306, 0x2341, x86_l_2341);
x86_l_2308:
	/* 0x2308: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_230b:
	/* 0x230b: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_230e:
	/* 0x230e: ja     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x230e, 0x2148, x86_l_2148);
x86_l_2314:
	/* 0x2314: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2317:
	/* 0x2317: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_231a:
	/* 0x231a: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x231a, 0x2341, x86_l_2341);
x86_l_231c:
	/* 0x231c: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_231f:
	/* 0x231f: ja     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x231f, 0x2148, x86_l_2148);
x86_l_2325:
	/* 0x2325: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2328:
	/* 0x2328: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2328, 0x2341, x86_l_2341);
x86_l_232a:
	/* 0x232a: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_232d:
	/* 0x232d: ja     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x232d, 0x2148, x86_l_2148);
x86_l_2333:
	/* 0x2333: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2336:
	/* 0x2336: jb     2341 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2336, 0x2341, x86_l_2341);
x86_l_2338:
	/* 0x2338: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_233b:
	/* 0x233b: ja     2148 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x233b, 0x2148, x86_l_2148);
x86_l_2341:
	/* 0x2341: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2343:
	/* 0x2343: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2148);

	/* native subroutine native_link_sub_2344 */
x86_l_2344:
	/* 0x2344: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2347:
	/* 0x2347: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_234a:
	/* 0x234a: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_234d:
	/* 0x234d: ja     2434 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x234d, 0x2434, x86_l_2434);
x86_l_2353:
	/* 0x2353: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_2358:
	/* 0x2358: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_235b:
	/* 0x235b: jae    2434 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x235b, 0x2434, x86_l_2434);
x86_l_2361:
	/* 0x2361: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2364:
	/* 0x2364: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2367:
	/* 0x2367: jne    23cf <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2367, 0x23cf, x86_l_23cf);
x86_l_2369:
	/* 0x2369: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_236e:
	/* 0x236e: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2371:
	/* 0x2371: jg     237c <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2371, 0x237c, x86_l_237c);
x86_l_2373:
	/* 0x2373: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2376:
	/* 0x2376: jge    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2376, 0x244b, x86_l_244b);
x86_l_237c:
	/* 0x237c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_237f:
	/* 0x237f: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2382:
	/* 0x2382: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2382, 0x24eb, x86_l_24eb);
x86_l_2388:
	/* 0x2388: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_238b:
	/* 0x238b: jg     2396 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x238b, 0x2396, x86_l_2396);
x86_l_238d:
	/* 0x238d: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2390:
	/* 0x2390: jge    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2390, 0x244b, x86_l_244b);
x86_l_2396:
	/* 0x2396: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2399:
	/* 0x2399: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2399, 0x24eb, x86_l_24eb);
x86_l_239f:
	/* 0x239f: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23a2:
	/* 0x23a2: jg     23ad <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23a2, 0x23ad, x86_l_23ad);
x86_l_23a4:
	/* 0x23a4: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_23a7:
	/* 0x23a7: jge    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23a7, 0x244b, x86_l_244b);
x86_l_23ad:
	/* 0x23ad: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_23b0:
	/* 0x23b0: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23b0, 0x24eb, x86_l_24eb);
x86_l_23b6:
	/* 0x23b6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b8:
	/* 0x23b8: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23bb:
	/* 0x23bb: jg     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x23bb, 0x24ed, x86_l_24ed);
x86_l_23c1:
	/* 0x23c1: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_23c4:
	/* 0x23c4: jge    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x23c4, 0x244b, x86_l_244b);
x86_l_23ca:
	/* 0x23ca: jmp    24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x23ca, 0x24ed, x86_l_24ed);
x86_l_23cf:
	/* 0x23cf: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23d2:
	/* 0x23d2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23d5:
	/* 0x23d5: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_23d9:
	/* 0x23d9: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23dc:
	/* 0x23dc: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_23df:
	/* 0x23df: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_23e2:
	/* 0x23e2: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_23e5:
	/* 0x23e5: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23e5, 0x24ed, x86_l_24ed);
x86_l_23eb:
	/* 0x23eb: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23ee:
	/* 0x23ee: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_23f2:
	/* 0x23f2: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23f5:
	/* 0x23f5: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_23f9:
	/* 0x23f9: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_23fc:
	/* 0x23fc: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_23ff:
	/* 0x23ff: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2402:
	/* 0x2402: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2402, 0x24ed, x86_l_24ed);
x86_l_2408:
	/* 0x2408: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_240b:
	/* 0x240b: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_240f:
	/* 0x240f: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2412:
	/* 0x2412: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2416:
	/* 0x2416: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2419:
	/* 0x2419: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_241c:
	/* 0x241c: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_241f:
	/* 0x241f: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x241f, 0x24ed, x86_l_24ed);
x86_l_2425:
	/* 0x2425: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2428:
	/* 0x2428: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_242b:
	/* 0x242b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_242e:
	/* 0x242e: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2432:
	/* 0x2432: jmp    24a7 <filter_8ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x2432, 0x24a7, x86_l_24a7);
x86_l_2434:
	/* 0x2434: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2437:
	/* 0x2437: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_243a:
	/* 0x243a: jne    244c <filter_8ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x243a, 0x244c, x86_l_244c);
x86_l_243c:
	/* 0x243c: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2441:
	/* 0x2441: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2444:
	/* 0x2444: ja     24af <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2444, 0x24af, x86_l_24af);
x86_l_2446:
	/* 0x2446: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2449:
	/* 0x2449: jb     24af <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2449, 0x24af, x86_l_24af);
x86_l_244b:
	/* 0x244b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_244b);
x86_l_244c:
	/* 0x244c: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_244f:
	/* 0x244f: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2452:
	/* 0x2452: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2456:
	/* 0x2456: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2459:
	/* 0x2459: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_245c:
	/* 0x245c: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_245f:
	/* 0x245f: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2462:
	/* 0x2462: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2462, 0x24ed, x86_l_24ed);
x86_l_2468:
	/* 0x2468: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_246b:
	/* 0x246b: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_246f:
	/* 0x246f: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2472:
	/* 0x2472: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_2476:
	/* 0x2476: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2479:
	/* 0x2479: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_247c:
	/* 0x247c: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_247f:
	/* 0x247f: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x247f, 0x24ed, x86_l_24ed);
x86_l_2481:
	/* 0x2481: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2484:
	/* 0x2484: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2488:
	/* 0x2488: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_248b:
	/* 0x248b: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_248f:
	/* 0x248f: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2492:
	/* 0x2492: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2495:
	/* 0x2495: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2498:
	/* 0x2498: jb     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2498, 0x24ed, x86_l_24ed);
x86_l_249a:
	/* 0x249a: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_249d:
	/* 0x249d: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_24a0:
	/* 0x24a0: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24a3:
	/* 0x24a3: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_24a7:
	/* 0x24a7: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_24aa:
	/* 0x24aa: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_24ad:
	/* 0x24ad: jmp    24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x24ad, 0x24ed, x86_l_24ed);
x86_l_24af:
	/* 0x24af: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b2:
	/* 0x24b2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_24b5:
	/* 0x24b5: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24b5, 0x24eb, x86_l_24eb);
x86_l_24b7:
	/* 0x24b7: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24ba:
	/* 0x24ba: ja     24c1 <filter_8ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24ba, 0x24c1, x86_l_24c1);
x86_l_24bc:
	/* 0x24bc: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24bf:
	/* 0x24bf: jae    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24bf, 0x244b, x86_l_244b);
x86_l_24c1:
	/* 0x24c1: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_24c4:
	/* 0x24c4: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24c4, 0x24eb, x86_l_24eb);
x86_l_24c6:
	/* 0x24c6: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24c9:
	/* 0x24c9: ja     24d4 <filter_8ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24c9, 0x24d4, x86_l_24d4);
x86_l_24cb:
	/* 0x24cb: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_24ce:
	/* 0x24ce: jae    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24ce, 0x244b, x86_l_244b);
x86_l_24d4:
	/* 0x24d4: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_24d7:
	/* 0x24d7: jb     24eb <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24d7, 0x24eb, x86_l_24eb);
x86_l_24d9:
	/* 0x24d9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24db:
	/* 0x24db: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24de:
	/* 0x24de: ja     24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x24de, 0x24ed, x86_l_24ed);
x86_l_24e0:
	/* 0x24e0: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24e3:
	/* 0x24e3: jae    244b <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x24e3, 0x244b, x86_l_244b);
x86_l_24e9:
	/* 0x24e9: jmp    24ed <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x24e9, 0x24ed, x86_l_24ed);
x86_l_24eb:
	/* 0x24eb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ed:
	/* 0x24ed: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_24f0:
	/* 0x24f0: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_24f3:
	/* 0x24f3: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_24f6:
	/* 0x24f6: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_24f8:
	/* 0x24f8: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_24fb:
	/* 0x24fb: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_244b);

	/* native subroutine native_link_sub_24fc */
x86_l_24fc:
	/* 0x24fc: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_24fe:
	/* 0x24fe: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24ff:
	/* 0x24ff: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_2503:
	/* 0x2503: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2506:
	/* 0x2506: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2509:
	/* 0x2509: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_250d:
	/* 0x250d: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2511:
	/* 0x2511: mov    rdi,QWORD PTR [rip+0x1420] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_2518:
	/* 0x2518: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_251d:
	/* 0x251d: call   3942 <filter_file_type+0x13c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2522:
	/* 0x2522: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2525:
	/* 0x2525: je     2559 <filter_8ty_map+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2525, 0x2559, x86_l_2559);
x86_l_2527:
	/* 0x2527: movzx  ecx,BYTE PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_252b:
	/* 0x252b: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2530:
	/* 0x2530: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2535:
	/* 0x2535: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2538:
	/* 0x2538: call   395d <filter_file_type+0x13df> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_253d:
	/* 0x253d: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2540:
	/* 0x2540: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2542:
	/* 0x2542: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_2545:
	/* 0x2545: ja     2573 <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2545, 0x2573, x86_l_2573);
x86_l_2547:
	/* 0x2547: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_254c:
	/* 0x254c: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_254f:
	/* 0x254f: jae    2563 <filter_8ty_map+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x254f, 0x2563, x86_l_2563);
x86_l_2551:
	/* 0x2551: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2554:
	/* 0x2554: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2557:
	/* 0x2557: jmp    2573 <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JMP(0x2557, 0x2573, x86_l_2573);
x86_l_2559:
	/* 0x2559: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_255b:
	/* 0x255b: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_255f:
	/* 0x255f: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2560:
	/* 0x2560: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2562:
	/* 0x2562: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2562);
x86_l_2563:
	/* 0x2563: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_2568:
	/* 0x2568: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_256b:
	/* 0x256b: jae    2573 <filter_8ty_map+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x256b, 0x2573, x86_l_2573);
x86_l_256d:
	/* 0x256d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2570:
	/* 0x2570: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2573:
	/* 0x2573: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2576:
	/* 0x2576: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_257a:
	/* 0x257a: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_257b:
	/* 0x257b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_257d:
	/* 0x257d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2562);

	/* native subroutine native_link_sub_257e */
x86_l_257e:
	/* 0x257e: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_257f:
	/* 0x257f: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_2583:
	/* 0x2583: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_258a:
	/* 0x258a: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_258c:
	/* 0x258c: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2592:
	/* 0x2592: ja     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2592, 0x262f, x86_l_262f);
x86_l_2598:
	/* 0x2598: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_259b:
	/* 0x259b: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_259e:
	/* 0x259e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_25a2:
	/* 0x25a2: jns    25b5 <filter_file_type+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x25a2, 0x25b5, x86_l_25b5);
x86_l_25a4:
	/* 0x25a4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25a7:
	/* 0x25a7: jns    25db <filter_file_type+0x5d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x25a7, 0x25db, x86_l_25db);
x86_l_25a9:
	/* 0x25a9: movzx  ecx,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_25ac:
	/* 0x25ac: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25af:
	/* 0x25af: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_25b1:
	/* 0x25b1: jne    25e4 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x25b1, 0x25e4, x86_l_25e4);
x86_l_25b3:
	/* 0x25b3: jmp    262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x25b3, 0x262f, x86_l_262f);
x86_l_25b5:
	/* 0x25b5: lea    rax,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_25ba:
	/* 0x25ba: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25bd:
	/* 0x25bd: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25c0:
	/* 0x25c0: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_25c5:
	/* 0x25c5: call   492a <filter_file_type+0x23ac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_25ca:
	/* 0x25ca: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25cd:
	/* 0x25cd: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_25d2:
	/* 0x25d2: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25d5:
	/* 0x25d5: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_25d7:
	/* 0x25d7: jne    25e4 <filter_file_type+0x66> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x25d7, 0x25e4, x86_l_25e4);
x86_l_25d9:
	/* 0x25d9: jmp    262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JMP(0x25d9, 0x262f, x86_l_262f);
x86_l_25db:
	/* 0x25db: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25dd:
	/* 0x25dd: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25e0:
	/* 0x25e0: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_25e2:
	/* 0x25e2: je     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x25e2, 0x262f, x86_l_262f);
x86_l_25e4:
	/* 0x25e4: and    ecx,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_25ea:
	/* 0x25ea: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_25ef:
	/* 0x25ef: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_25f1:
	/* 0x25f1: je     2631 <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x25f1, 0x2631, x86_l_2631);
x86_l_25f3:
	/* 0x25f3: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25f6:
	/* 0x25f6: cmp    edx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_25f9:
	/* 0x25f9: jbe    262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x25f9, 0x262f, x86_l_262f);
x86_l_25fb:
	/* 0x25fb: mov    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_25fe:
	/* 0x25fe: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2600:
	/* 0x2600: je     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2600, 0x262f, x86_l_262f);
x86_l_2602:
	/* 0x2602: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2604:
	/* 0x2604: je     2631 <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2604, 0x2631, x86_l_2631);
x86_l_2606:
	/* 0x2606: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2609:
	/* 0x2609: jb     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2609, 0x262f, x86_l_262f);
x86_l_260b:
	/* 0x260b: mov    esi,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_260e:
	/* 0x260e: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2610:
	/* 0x2610: je     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2610, 0x262f, x86_l_262f);
x86_l_2612:
	/* 0x2612: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2614:
	/* 0x2614: je     2631 <filter_file_type+0xb3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2614, 0x2631, x86_l_2631);
x86_l_2616:
	/* 0x2616: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2619:
	/* 0x2619: jb     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2619, 0x262f, x86_l_262f);
x86_l_261b:
	/* 0x261b: mov    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_261e:
	/* 0x261e: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2620:
	/* 0x2620: je     262f <filter_file_type+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2620, 0x262f, x86_l_262f);
x86_l_2622:
	/* 0x2622: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2624:
	/* 0x2624: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2626:
	/* 0x2626: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2629:
	/* 0x2629: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_262d:
	/* 0x262d: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_262e:
	/* 0x262e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_262e);
x86_l_262f:
	/* 0x262f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2631:
	/* 0x2631: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2635:
	/* 0x2635: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2636:
	/* 0x2636: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_262e);

x86_sim_ret_dispatch_45f:
	switch (__x86_sim_ret_addr) {
	case 0x1caULL: goto x86_l_1ca;
	case 0x2fdULL: goto x86_l_2fd;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_525:
	switch (__x86_sim_ret_addr) {
	case 0x25dULL: goto x86_l_25d;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_84e:
	switch (__x86_sim_ret_addr) {
	case 0x29dULL: goto x86_l_29d;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_8d6:
	switch (__x86_sim_ret_addr) {
	case 0x2f6ULL: goto x86_l_2f6;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_94f:
	switch (__x86_sim_ret_addr) {
	case 0x30cULL: goto x86_l_30c;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_996:
	switch (__x86_sim_ret_addr) {
	case 0x313ULL: goto x86_l_313;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_a62:
	switch (__x86_sim_ret_addr) {
	case 0x31fULL: goto x86_l_31f;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_a80:
	switch (__x86_sim_ret_addr) {
	case 0x32bULL: goto x86_l_32b;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_ac8:
	switch (__x86_sim_ret_addr) {
	case 0xa7fULL: goto x86_l_a7f;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_df8:
	switch (__x86_sim_ret_addr) {
	case 0xaa1ULL: goto x86_l_aa1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_f15:
	switch (__x86_sim_ret_addr) {
	case 0xaa8ULL: goto x86_l_aa8;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_106d:
	switch (__x86_sim_ret_addr) {
	case 0x4c9ULL: goto x86_l_4c9;
	case 0xa08ULL: goto x86_l_a08;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1190:
	switch (__x86_sim_ret_addr) {
	case 0x4dfULL: goto x86_l_4df;
	case 0x8f8ULL: goto x86_l_8f8;
	case 0xa26ULL: goto x86_l_a26;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1585:
	switch (__x86_sim_ret_addr) {
	case 0x4b3ULL: goto x86_l_4b3;
	case 0x8b4ULL: goto x86_l_8b4;
	case 0xa30ULL: goto x86_l_a30;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1883:
	switch (__x86_sim_ret_addr) {
	case 0xa3cULL: goto x86_l_a3c;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_18a9:
	switch (__x86_sim_ret_addr) {
	case 0x995ULL: goto x86_l_995;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1bac:
	switch (__x86_sim_ret_addr) {
	case 0x9b7ULL: goto x86_l_9b7;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1cc3:
	switch (__x86_sim_ret_addr) {
	case 0x9beULL: goto x86_l_9be;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1cfd:
	switch (__x86_sim_ret_addr) {
	case 0x94eULL: goto x86_l_94e;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1ff8:
	switch (__x86_sim_ret_addr) {
	case 0x970ULL: goto x86_l_970;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_210e:
	switch (__x86_sim_ret_addr) {
	case 0x843ULL: goto x86_l_843;
	case 0x92cULL: goto x86_l_92c;
	case 0x977ULL: goto x86_l_977;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2148:
	switch (__x86_sim_ret_addr) {
	case 0x524ULL: goto x86_l_524;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_244b:
	switch (__x86_sim_ret_addr) {
	case 0x546ULL: goto x86_l_546;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2562:
	switch (__x86_sim_ret_addr) {
	case 0x54dULL: goto x86_l_54d;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_262e:
	switch (__x86_sim_ret_addr) {
	case 0x495ULL: goto x86_l_495;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
