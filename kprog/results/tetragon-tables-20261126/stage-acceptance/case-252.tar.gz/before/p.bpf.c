#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 328U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(15) M(16) M(17) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(33) M(34)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/security_mmap_addr")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x118 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 280ULL);
x86_l_11:
	/* 0x11: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xa0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 687194767360ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_mmap_alert+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x1a1d, x86_l_1a1d);
x86_l_3c:
	/* 0x3c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_mmap_alert+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x1a1d, x86_l_1a1d);
x86_l_5c:
	/* 0x5c: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    QWORD PTR [rsp+0x110],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_67:
	/* 0x67: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6a:
	/* 0x6a: mov    WORD PTR [r13+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_74:
	/* 0x74: mov    BYTE PTR [r13+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_7c:
	/* 0x7c: mov    QWORD PTR [r13+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_87:
	/* 0x87: mov    QWORD PTR [r13+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_92:
	/* 0x92: mov    QWORD PTR [r13+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_9d:
	/* 0x9d: mov    QWORD PTR [r13+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_a8:
	/* 0xa8: mov    QWORD PTR [r13+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_b3:
	/* 0xb3: mov    QWORD PTR [r13+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_be:
	/* 0xbe: mov    QWORD PTR [r13+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_c9:
	/* 0xc9: mov    QWORD PTR [r13+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_d4:
	/* 0xd4: call   d9 <trace_mmap_alert+0xd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_d9:
	/* 0xd9: mov    QWORD PTR [r13+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_e0:
	/* 0xe0: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e8:
	/* 0xe8: mov    QWORD PTR [r13+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_f0:
	/* 0xf0: mov    QWORD PTR [r13+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_f8:
	/* 0xf8: mov    QWORD PTR [r13+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_100:
	/* 0x100: mov    QWORD PTR [r13+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_108:
	/* 0x108: mov    QWORD PTR [r13+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_110:
	/* 0x110: mov    QWORD PTR [r13+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_118:
	/* 0x118: mov    QWORD PTR [r13+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_120:
	/* 0x120: mov    QWORD PTR [r13+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_128:
	/* 0x128: mov    QWORD PTR [r13+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_130:
	/* 0x130: mov    QWORD PTR [r13+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_138:
	/* 0x138: mov    QWORD PTR [r13+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_140:
	/* 0x140: mov    QWORD PTR [r13+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_148:
	/* 0x148: call   14d <trace_mmap_alert+0x14d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_151:
	/* 0x151: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_155:
	/* 0x155: mov    DWORD PTR [r13+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_159:
	/* 0x159: mov    DWORD PTR [r13+0x70],0x2d4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337876ULL);
x86_l_161:
	/* 0x161: call   166 <trace_mmap_alert+0x166> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_166:
	/* 0x166: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a:
	/* 0x16a: call   16f <trace_mmap_alert+0x16f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_16f:
	/* 0x16f: mov    WORD PTR [r13+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_174:
	/* 0x174: call   179 <trace_mmap_alert+0x179> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_179:
	/* 0x179: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17c:
	/* 0x17c: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_180:
	/* 0x180: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_183:
	/* 0x183: jns    194 <trace_mmap_alert+0x194> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x183, 0x194, x86_l_194);
x86_l_185:
	/* 0x185: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_187:
	/* 0x187: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_18c:
	/* 0x18c: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_192:
	/* 0x192: jne    1d1 <trace_mmap_alert+0x1d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x192, 0x1d1, x86_l_1d1);
x86_l_194:
	/* 0x194: call   199 <trace_mmap_alert+0x199> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_199:
	/* 0x199: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19c:
	/* 0x19c: call   1a1 <trace_mmap_alert+0x1a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_1a1:
	/* 0x1a1: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_1a5:
	/* 0x1a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a8:
	/* 0x1a8: jns    1b8 <trace_mmap_alert+0x1b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a8, 0x1b8, x86_l_1b8);
x86_l_1aa:
	/* 0x1aa: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ad:
	/* 0x1ad: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b1:
	/* 0x1b1: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b4:
	/* 0x1b4: js     1c3 <trace_mmap_alert+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b4, 0x1c3, x86_l_1c3);
x86_l_1b6:
	/* 0x1b6: jmp    1cd <trace_mmap_alert+0x1cd> */
	X86_SIM_X86_JMP(0x1b6, 0x1cd, x86_l_1cd);
x86_l_1b8:
	/* 0x1b8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ba:
	/* 0x1ba: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1be:
	/* 0x1be: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c1:
	/* 0x1c1: jns    1cd <trace_mmap_alert+0x1cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c1, 0x1cd, x86_l_1cd);
x86_l_1c3:
	/* 0x1c3: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c5:
	/* 0x1c5: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c7:
	/* 0x1c7: jne    55d <trace_mmap_alert+0x55d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c7, 0x55d, x86_l_55d);
x86_l_1cd:
	/* 0x1cd: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d1:
	/* 0x1d1: mov    DWORD PTR [rbp+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1d4:
	/* 0x1d4: mov    eax,DWORD PTR [rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d7:
	/* 0x1d7: mov    DWORD PTR [rsp+0x98],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1de:
	/* 0x1de: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1e5:
	/* 0x1e5: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1ed:
	/* 0x1ed: call   1f2 <trace_mmap_alert+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f2:
	/* 0x1f2: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1fa:
	/* 0x1fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fd:
	/* 0x1fd: mov    QWORD PTR [rsp+0x8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_202:
	/* 0x202: je     1b7d <trace_mmap_alert+0x1b7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x202, 0x1b7d, x86_l_1b7d);
x86_l_208:
	/* 0x208: mov    eax,DWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20b:
	/* 0x20b: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_20f:
	/* 0x20f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_216:
	/* 0x216: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21b:
	/* 0x21b: call   220 <trace_mmap_alert+0x220> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_220:
	/* 0x220: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_223:
	/* 0x223: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_226:
	/* 0x226: mov    QWORD PTR [rsp+0x10],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22b:
	/* 0x22b: mov    QWORD PTR [rsp+0x20],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_230:
	/* 0x230: je     1c17 <trace_mmap_alert+0x1c17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x230, 0x1c17, x86_l_1c17);
x86_l_236:
	/* 0x236: test   BYTE PTR [r14+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_23b:
	/* 0x23b: jne    244 <trace_mmap_alert+0x244> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23b, 0x244, x86_l_244);
x86_l_23d:
	/* 0x23d: call   242 <trace_mmap_alert+0x242> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_242:
	/* 0x242: jmp    29c <trace_mmap_alert+0x29c> */
	X86_SIM_X86_JMP(0x242, 0x29c, x86_l_29c);
x86_l_244:
	/* 0x244: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_249:
	/* 0x249: add    rax,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_250:
	/* 0x250: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_253:
	/* 0x253: jns    26d <trace_mmap_alert+0x26d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x253, 0x26d, x86_l_26d);
x86_l_255:
	/* 0x255: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_258:
	/* 0x258: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: js     274 <trace_mmap_alert+0x274> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25b, 0x274, x86_l_274);
x86_l_25d:
	/* 0x25d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f:
	/* 0x25f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_262:
	/* 0x262: js     27c <trace_mmap_alert+0x27c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x262, 0x27c, x86_l_27c);
x86_l_264:
	/* 0x264: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_266:
	/* 0x266: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_269:
	/* 0x269: js     284 <trace_mmap_alert+0x284> */
	X86_SIM_X86_JCC(X86_CC_S, 0x269, 0x284, x86_l_284);
x86_l_26b:
	/* 0x26b: jmp    29a <trace_mmap_alert+0x29a> */
	X86_SIM_X86_JMP(0x26b, 0x29a, x86_l_29a);
x86_l_26d:
	/* 0x26d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26f:
	/* 0x26f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_272:
	/* 0x272: jns    25d <trace_mmap_alert+0x25d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x272, 0x25d, x86_l_25d);
x86_l_274:
	/* 0x274: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277:
	/* 0x277: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27a:
	/* 0x27a: jns    264 <trace_mmap_alert+0x264> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a, 0x264, x86_l_264);
x86_l_27c:
	/* 0x27c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27f:
	/* 0x27f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_282:
	/* 0x282: jns    29a <trace_mmap_alert+0x29a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x282, 0x29a, x86_l_29a);
x86_l_284:
	/* 0x284: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_287:
	/* 0x287: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a:
	/* 0x28a: je     29a <trace_mmap_alert+0x29a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a, 0x29a, x86_l_29a);
x86_l_28c:
	/* 0x28c: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_290:
	/* 0x290: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_293:
	/* 0x293: jns    29a <trace_mmap_alert+0x29a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x293, 0x29a, x86_l_29a);
x86_l_295:
	/* 0x295: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_298:
	/* 0x298: jmp    29c <trace_mmap_alert+0x29c> */
	X86_SIM_X86_JMP(0x298, 0x29c, x86_l_29c);
x86_l_29a:
	/* 0x29a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c:
	/* 0x29c: mov    QWORD PTR [rbp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a0:
	/* 0x2a0: mov    QWORD PTR [r15+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a4:
	/* 0x2a4: mov    DWORD PTR [rsp+0xc0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2ab:
	/* 0x2ab: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_2b2:
	/* 0x2b2: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2ba:
	/* 0x2ba: call   2bf <trace_mmap_alert+0x2bf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2bf:
	/* 0x2bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c2:
	/* 0x2c2: je     2da <trace_mmap_alert+0x2da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c2, 0x2da, x86_l_2da);
x86_l_2c4:
	/* 0x2c4: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2c7:
	/* 0x2c7: mov    BYTE PTR [r15+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2ce:
	/* 0x2ce: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2d1:
	/* 0x2d1: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2d4:
	/* 0x2d4: jne    2da <trace_mmap_alert+0x2da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d4, 0x2da, x86_l_2da);
x86_l_2d6:
	/* 0x2d6: or     BYTE PTR [rbp+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2da:
	/* 0x2da: movzx  eax,WORD PTR [rbp+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2de:
	/* 0x2de: cmp    ax,WORD PTR [r14+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2e3:
	/* 0x2e3: jne    1cc0 <trace_mmap_alert+0x1cc0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e3, 0x1cc0, x86_l_1cc0);
x86_l_2e9:
	/* 0x2e9: mov    QWORD PTR [rbp+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2f4:
	/* 0x2f4: mov    DWORD PTR [rsp+0x30],0x2d4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430932ULL);
x86_l_2fc:
	/* 0x2fc: mov    WORD PTR [rsp+0xa8],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_304:
	/* 0x304: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_30b:
	/* 0x30b: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_313:
	/* 0x313: call   318 <trace_mmap_alert+0x318> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_318:
	/* 0x318: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31b:
	/* 0x31b: je     386 <trace_mmap_alert+0x386> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31b, 0x386, x86_l_386);
x86_l_31d:
	/* 0x31d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_322:
	/* 0x322: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_325:
	/* 0x325: call   32a <trace_mmap_alert+0x32a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_32a:
	/* 0x32a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32d:
	/* 0x32d: je     386 <trace_mmap_alert+0x386> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32d, 0x386, x86_l_386);
x86_l_32f:
	/* 0x32f: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_333:
	/* 0x333: mov    QWORD PTR [rbp+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_33a:
	/* 0x33a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33d:
	/* 0x33d: mov    QWORD PTR [rbp+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_344:
	/* 0x344: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_348:
	/* 0x348: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_34c:
	/* 0x34c: mov    QWORD PTR [rbp+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_353:
	/* 0x353: mov    QWORD PTR [rbp+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_35a:
	/* 0x35a: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_35e:
	/* 0x35e: mov    QWORD PTR [rbp+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_365:
	/* 0x365: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_369:
	/* 0x369: mov    QWORD PTR [rbp+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_370:
	/* 0x370: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_374:
	/* 0x374: mov    QWORD PTR [rbp+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_37b:
	/* 0x37b: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_37f:
	/* 0x37f: mov    QWORD PTR [rbp+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_386:
	/* 0x386: mov    rax,QWORD PTR [rbp+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_38d:
	/* 0x38d: mov    QWORD PTR [rbp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_394:
	/* 0x394: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_397:
	/* 0x397: cmp    ecx,DWORD PTR [rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_39a:
	/* 0x39a: mov    QWORD PTR [rsp+0x18],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_39f:
	/* 0x39f: jne    3b9 <trace_mmap_alert+0x3b9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39f, 0x3b9, x86_l_3b9);
x86_l_3a1:
	/* 0x3a1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a4:
	/* 0x3a4: and    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3a7:
	/* 0x3a7: mov    QWORD PTR [rbp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3ae:
	/* 0x3ae: jne    c34 <trace_mmap_alert+0xc34> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ae, 0xc34, x86_l_c34);
x86_l_3b4:
	/* 0x3b4: jmp    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JMP(0x3b4, 0x1a1d, x86_l_1a1d);
x86_l_3b9:
	/* 0x3b9: mov    rax,QWORD PTR [rbp+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_3c0:
	/* 0x3c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c3:
	/* 0x3c3: je     57e <trace_mmap_alert+0x57e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c3, 0x57e, x86_l_57e);
x86_l_3c9:
	/* 0x3c9: movzx  ecx,BYTE PTR [r15+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_3d1:
	/* 0x3d1: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_3d4:
	/* 0x3d4: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d7:
	/* 0x3d7: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3da:
	/* 0x3da: sete   r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3de:
	/* 0x3de: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3e1:
	/* 0x3e1: neg    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3e4:
	/* 0x3e4: xor    r15,QWORD PTR [rbp+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_3eb:
	/* 0x3eb: or     r15,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3ee:
	/* 0x3ee: mov    rax,QWORD PTR [rbp+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_3f5:
	/* 0x3f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f8:
	/* 0x3f8: je     41e <trace_mmap_alert+0x41e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f8, 0x41e, x86_l_41e);
x86_l_3fa:
	/* 0x3fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fc:
	/* 0x3fc: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_401:
	/* 0x401: cmp    BYTE PTR [rdx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_408:
	/* 0x408: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_40b:
	/* 0x40b: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_40e:
	/* 0x40e: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_411:
	/* 0x411: xor    rcx,QWORD PTR [rbp+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_418:
	/* 0x418: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_41b:
	/* 0x41b: and    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_41e:
	/* 0x41e: mov    rax,QWORD PTR [rbp+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_425:
	/* 0x425: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_428:
	/* 0x428: je     443 <trace_mmap_alert+0x443> */
	X86_SIM_X86_JCC(X86_CC_E, 0x428, 0x443, x86_l_443);
x86_l_42a:
	/* 0x42a: mov    ecx,DWORD PTR [rbp+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_42d:
	/* 0x42d: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_430:
	/* 0x430: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_433:
	/* 0x433: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_436:
	/* 0x436: xor    rcx,QWORD PTR [rbp+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_43d:
	/* 0x43d: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_440:
	/* 0x440: and    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_443:
	/* 0x443: mov    rax,QWORD PTR [rbp+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_44a:
	/* 0x44a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44d:
	/* 0x44d: je     46e <trace_mmap_alert+0x46e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44d, 0x46e, x86_l_46e);
x86_l_44f:
	/* 0x44f: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_452:
	/* 0x452: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_45a:
	/* 0x45a: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_45e:
	/* 0x45e: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_461:
	/* 0x461: xor    rcx,QWORD PTR [rbp+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_468:
	/* 0x468: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_46b:
	/* 0x46b: and    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_46e:
	/* 0x46e: movzx  r14d,WORD PTR [rbp+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_473:
	/* 0x473: mov    r13,QWORD PTR [rbp+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_47a:
	/* 0x47a: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_47d:
	/* 0x47d: mov    WORD PTR [rsp],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_482:
	/* 0x482: je     5eb <trace_mmap_alert+0x5eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x482, 0x5eb, x86_l_5eb);
x86_l_488:
	/* 0x488: mov    rax,QWORD PTR [rbp+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_48f:
	/* 0x48f: mov    QWORD PTR [rsp+0x108],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 264ULL);
x86_l_497:
	/* 0x497: mov    r12,QWORD PTR [rbp+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_49e:
	/* 0x49e: mov    rax,QWORD PTR [rbp+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_4a5:
	/* 0x4a5: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_4ad:
	/* 0x4ad: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4b3:
	/* 0x4b3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_4ba:
	/* 0x4ba: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4bf:
	/* 0x4bf: call   4c4 <trace_mmap_alert+0x4c4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4c4:
	/* 0x4c4: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c7:
	/* 0x4c7: mov    eax,DWORD PTR [rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4ca:
	/* 0x4ca: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4cf:
	/* 0x4cf: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4d6:
	/* 0x4d6: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4d9:
	/* 0x4d9: je     4f9 <trace_mmap_alert+0x4f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d9, 0x4f9, x86_l_4f9);
x86_l_4db:
	/* 0x4db: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4e0:
	/* 0x4e0: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4e3:
	/* 0x4e3: call   4e8 <trace_mmap_alert+0x4e8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4e8:
	/* 0x4e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4eb:
	/* 0x4eb: je     4f9 <trace_mmap_alert+0x4f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4eb, 0x4f9, x86_l_4f9);
x86_l_4ed:
	/* 0x4ed: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f0:
	/* 0x4f0: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4f4:
	/* 0x4f4: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4f7:
	/* 0x4f7: jmp    4fb <trace_mmap_alert+0x4fb> */
	X86_SIM_X86_JMP(0x4f7, 0x4fb, x86_l_4fb);
x86_l_4f9:
	/* 0x4f9: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4fb:
	/* 0x4fb: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_503:
	/* 0x503: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_508:
	/* 0x508: dec    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_50b:
	/* 0x50b: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_50e:
	/* 0x50e: jb     526 <trace_mmap_alert+0x526> */
	X86_SIM_X86_JCC(X86_CC_B, 0x50e, 0x526, x86_l_526);
x86_l_510:
	/* 0x510: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_514:
	/* 0x514: je     51b <trace_mmap_alert+0x51b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x514, 0x51b, x86_l_51b);
x86_l_516:
	/* 0x516: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_519:
	/* 0x519: jbe    526 <trace_mmap_alert+0x526> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x519, 0x526, x86_l_526);
x86_l_51b:
	/* 0x51b: and    r14,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 264ULL);
x86_l_523:
	/* 0x523: or     rbp,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_526:
	/* 0x526: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_52b:
	/* 0x52b: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_52e:
	/* 0x52e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_533:
	/* 0x533: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_53a:
	/* 0x53a: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_53d:
	/* 0x53d: je     59a <trace_mmap_alert+0x59a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53d, 0x59a, x86_l_59a);
x86_l_53f:
	/* 0x53f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_544:
	/* 0x544: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_547:
	/* 0x547: call   54c <trace_mmap_alert+0x54c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54c:
	/* 0x54c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54f:
	/* 0x54f: je     5ab <trace_mmap_alert+0x5ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54f, 0x5ab, x86_l_5ab);
x86_l_551:
	/* 0x551: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_554:
	/* 0x554: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_558:
	/* 0x558: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_55b:
	/* 0x55b: jmp    5ad <trace_mmap_alert+0x5ad> */
	X86_SIM_X86_JMP(0x55b, 0x5ad, x86_l_5ad);
x86_l_55d:
	/* 0x55d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_564:
	/* 0x564: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_569:
	/* 0x569: call   56e <trace_mmap_alert+0x56e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56e:
	/* 0x56e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_571:
	/* 0x571: je     db2 <trace_mmap_alert+0xdb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x571, 0xdb2, x86_l_db2);
x86_l_577:
	/* 0x577: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_579:
	/* 0x579: jmp    1d1 <trace_mmap_alert+0x1d1> */
	X86_SIM_X86_JMP(0x579, 0x1d1, x86_l_1d1);
x86_l_57e:
	/* 0x57e: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_585:
	/* 0x585: mov    rax,QWORD PTR [rbp+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_58c:
	/* 0x58c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58f:
	/* 0x58f: jne    3fa <trace_mmap_alert+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x58f, 0x3fa, x86_l_3fa);
x86_l_595:
	/* 0x595: jmp    41e <trace_mmap_alert+0x41e> */
	X86_SIM_X86_JMP(0x595, 0x41e, x86_l_41e);
x86_l_59a:
	/* 0x59a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_59c:
	/* 0x59c: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_59f:
	/* 0x59f: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5a4:
	/* 0x5a4: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a7:
	/* 0x5a7: jae    5c2 <trace_mmap_alert+0x5c2> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5a7, 0x5c2, x86_l_5c2);
x86_l_5a9:
	/* 0x5a9: jmp    5d8 <trace_mmap_alert+0x5d8> */
	X86_SIM_X86_JMP(0x5a9, 0x5d8, x86_l_5d8);
x86_l_5ab:
	/* 0x5ab: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5ad:
	/* 0x5ad: mov    rdx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_5b5:
	/* 0x5b5: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5b8:
	/* 0x5b8: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5bd:
	/* 0x5bd: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c0:
	/* 0x5c0: jb     5d8 <trace_mmap_alert+0x5d8> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5c0, 0x5d8, x86_l_5d8);
x86_l_5c2:
	/* 0x5c2: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5c6:
	/* 0x5c6: je     5cd <trace_mmap_alert+0x5cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5c6, 0x5cd, x86_l_5cd);
x86_l_5c8:
	/* 0x5c8: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5cb:
	/* 0x5cb: jbe    5d8 <trace_mmap_alert+0x5d8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5cb, 0x5d8, x86_l_5d8);
x86_l_5cd:
	/* 0x5cd: and    r14,QWORD PTR [rsp+0x108] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 264ULL);
x86_l_5d5:
	/* 0x5d5: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5d8:
	/* 0x5d8: or     rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5db:
	/* 0x5db: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5de:
	/* 0x5de: and    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_5e1:
	/* 0x5e1: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e6:
	/* 0x5e6: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_5eb:
	/* 0x5eb: cmp    QWORD PTR [rbp+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_5f3:
	/* 0x5f3: je     6b3 <trace_mmap_alert+0x6b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f3, 0x6b3, x86_l_6b3);
x86_l_5f9:
	/* 0x5f9: call   5fe <trace_mmap_alert+0x5fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_5fe:
	/* 0x5fe: mov    DWORD PTR [rbp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_601:
	/* 0x601: mov    rbx,QWORD PTR [rbp+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_608:
	/* 0x608: mov    rax,QWORD PTR [rbp+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_60f:
	/* 0x60f: mov    QWORD PTR [rsp+0x88],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_617:
	/* 0x617: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_61a:
	/* 0x61a: mov    r14,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_61d:
	/* 0x61d: mov    rbp,QWORD PTR [rbp+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_624:
	/* 0x624: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_62b:
	/* 0x62b: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_630:
	/* 0x630: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_637:
	/* 0x637: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_63c:
	/* 0x63c: call   641 <trace_mmap_alert+0x641> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_641:
	/* 0x641: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_645:
	/* 0x645: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_64a:
	/* 0x64a: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_651:
	/* 0x651: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_654:
	/* 0x654: je     674 <trace_mmap_alert+0x674> */
	X86_SIM_X86_JCC(X86_CC_E, 0x654, 0x674, x86_l_674);
x86_l_656:
	/* 0x656: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_65b:
	/* 0x65b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65e:
	/* 0x65e: call   663 <trace_mmap_alert+0x663> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_663:
	/* 0x663: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_666:
	/* 0x666: je     674 <trace_mmap_alert+0x674> */
	X86_SIM_X86_JCC(X86_CC_E, 0x666, 0x674, x86_l_674);
x86_l_668:
	/* 0x668: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_66b:
	/* 0x66b: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_66f:
	/* 0x66f: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_672:
	/* 0x672: jmp    676 <trace_mmap_alert+0x676> */
	X86_SIM_X86_JMP(0x672, 0x676, x86_l_676);
x86_l_674:
	/* 0x674: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_676:
	/* 0x676: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_67b:
	/* 0x67b: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_67e:
	/* 0x67e: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_683:
	/* 0x683: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_686:
	/* 0x686: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_689:
	/* 0x689: jae    692 <trace_mmap_alert+0x692> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x689, 0x692, x86_l_692);
x86_l_68b:
	/* 0x68b: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_690:
	/* 0x690: jmp    6ad <trace_mmap_alert+0x6ad> */
	X86_SIM_X86_JMP(0x690, 0x6ad, x86_l_6ad);
x86_l_692:
	/* 0x692: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_696:
	/* 0x696: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_69b:
	/* 0x69b: je     6a2 <trace_mmap_alert+0x6a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69b, 0x6a2, x86_l_6a2);
x86_l_69d:
	/* 0x69d: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6a0:
	/* 0x6a0: jbe    6ad <trace_mmap_alert+0x6ad> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x6a0, 0x6ad, x86_l_6ad);
x86_l_6a2:
	/* 0x6a2: and    r12,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 136ULL);
x86_l_6aa:
	/* 0x6aa: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6ad:
	/* 0x6ad: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6b0:
	/* 0x6b0: and    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_6b3:
	/* 0x6b3: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6b8:
	/* 0x6b8: cmp    QWORD PTR [rbp+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6c0:
	/* 0x6c0: je     763 <trace_mmap_alert+0x763> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c0, 0x763, x86_l_763);
x86_l_6c6:
	/* 0x6c6: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6cb:
	/* 0x6cb: add    rax,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6d2:
	/* 0x6d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d5:
	/* 0x6d5: jns    6dc <trace_mmap_alert+0x6dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6d5, 0x6dc, x86_l_6dc);
x86_l_6d7:
	/* 0x6d7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6da:
	/* 0x6da: jmp    6de <trace_mmap_alert+0x6de> */
	X86_SIM_X86_JMP(0x6da, 0x6de, x86_l_6de);
x86_l_6dc:
	/* 0x6dc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6de:
	/* 0x6de: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6e2:
	/* 0x6e2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e4:
	/* 0x6e4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6e7:
	/* 0x6e7: jns    6f3 <trace_mmap_alert+0x6f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6e7, 0x6f3, x86_l_6f3);
x86_l_6e9:
	/* 0x6e9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6ec:
	/* 0x6ec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ef:
	/* 0x6ef: js     6fa <trace_mmap_alert+0x6fa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x6ef, 0x6fa, x86_l_6fa);
x86_l_6f1:
	/* 0x6f1: jmp    6fc <trace_mmap_alert+0x6fc> */
	X86_SIM_X86_JMP(0x6f1, 0x6fc, x86_l_6fc);
x86_l_6f3:
	/* 0x6f3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f5:
	/* 0x6f5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6f8:
	/* 0x6f8: jns    6fc <trace_mmap_alert+0x6fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6f8, 0x6fc, x86_l_6fc);
x86_l_6fa:
	/* 0x6fa: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6fc:
	/* 0x6fc: mov    DWORD PTR [rbp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_6ff:
	/* 0x6ff: mov    rbx,QWORD PTR [rbp+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_706:
	/* 0x706: mov    r12,QWORD PTR [rbp+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_70d:
	/* 0x70d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_710:
	/* 0x710: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_716:
	/* 0x716: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_71d:
	/* 0x71d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_722:
	/* 0x722: call   727 <trace_mmap_alert+0x727> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_727:
	/* 0x727: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_72e:
	/* 0x72e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_731:
	/* 0x731: je     750 <trace_mmap_alert+0x750> */
	X86_SIM_X86_JCC(X86_CC_E, 0x731, 0x750, x86_l_750);
x86_l_733:
	/* 0x733: lea    rsi,[r13+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_737:
	/* 0x737: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_73a:
	/* 0x73a: call   73f <trace_mmap_alert+0x73f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_73f:
	/* 0x73f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_742:
	/* 0x742: je     750 <trace_mmap_alert+0x750> */
	X86_SIM_X86_JCC(X86_CC_E, 0x742, 0x750, x86_l_750);
x86_l_744:
	/* 0x744: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_747:
	/* 0x747: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_74b:
	/* 0x74b: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_74e:
	/* 0x74e: jmp    752 <trace_mmap_alert+0x752> */
	X86_SIM_X86_JMP(0x74e, 0x752, x86_l_752);
x86_l_750:
	/* 0x750: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_752:
	/* 0x752: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_755:
	/* 0x755: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_758:
	/* 0x758: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_75b:
	/* 0x75b: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_75e:
	/* 0x75e: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_763:
	/* 0x763: cmp    QWORD PTR [rbp+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_76b:
	/* 0x76b: je     832 <trace_mmap_alert+0x832> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76b, 0x832, x86_l_832);
x86_l_771:
	/* 0x771: mov    rcx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_778:
	/* 0x778: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_77c:
	/* 0x77c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77e:
	/* 0x77e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_781:
	/* 0x781: jns    790 <trace_mmap_alert+0x790> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x781, 0x790, x86_l_790);
x86_l_783:
	/* 0x783: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_786:
	/* 0x786: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_789:
	/* 0x789: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_78c:
	/* 0x78c: js     79a <trace_mmap_alert+0x79a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x78c, 0x79a, x86_l_79a);
x86_l_78e:
	/* 0x78e: jmp    79c <trace_mmap_alert+0x79c> */
	X86_SIM_X86_JMP(0x78e, 0x79c, x86_l_79c);
x86_l_790:
	/* 0x790: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_792:
	/* 0x792: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_795:
	/* 0x795: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_798:
	/* 0x798: jns    79c <trace_mmap_alert+0x79c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x798, 0x79c, x86_l_79c);
x86_l_79a:
	/* 0x79a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_79c:
	/* 0x79c: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_79e:
	/* 0x79e: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_7a2:
	/* 0x7a2: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7a5:
	/* 0x7a5: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7a9:
	/* 0x7a9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ab:
	/* 0x7ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7ae:
	/* 0x7ae: jns    7be <trace_mmap_alert+0x7be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ae, 0x7be, x86_l_7be);
x86_l_7b0:
	/* 0x7b0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b3:
	/* 0x7b3: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7b7:
	/* 0x7b7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7ba:
	/* 0x7ba: js     7c9 <trace_mmap_alert+0x7c9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7ba, 0x7c9, x86_l_7c9);
x86_l_7bc:
	/* 0x7bc: jmp    7cb <trace_mmap_alert+0x7cb> */
	X86_SIM_X86_JMP(0x7bc, 0x7cb, x86_l_7cb);
x86_l_7be:
	/* 0x7be: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c0:
	/* 0x7c0: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7c4:
	/* 0x7c4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7c7:
	/* 0x7c7: jns    7cb <trace_mmap_alert+0x7cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7c7, 0x7cb, x86_l_7cb);
x86_l_7c9:
	/* 0x7c9: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7cb:
	/* 0x7cb: mov    DWORD PTR [rbp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7ce:
	/* 0x7ce: mov    rbx,QWORD PTR [rbp+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_7d5:
	/* 0x7d5: mov    r12,QWORD PTR [rbp+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_7dc:
	/* 0x7dc: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7df:
	/* 0x7df: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7e5:
	/* 0x7e5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_7ec:
	/* 0x7ec: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7f1:
	/* 0x7f1: call   7f6 <trace_mmap_alert+0x7f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f6:
	/* 0x7f6: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7fd:
	/* 0x7fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_800:
	/* 0x800: je     81f <trace_mmap_alert+0x81f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x800, 0x81f, x86_l_81f);
x86_l_802:
	/* 0x802: lea    rsi,[r13+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_806:
	/* 0x806: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_809:
	/* 0x809: call   80e <trace_mmap_alert+0x80e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_80e:
	/* 0x80e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_811:
	/* 0x811: je     81f <trace_mmap_alert+0x81f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x811, 0x81f, x86_l_81f);
x86_l_813:
	/* 0x813: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_816:
	/* 0x816: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_81a:
	/* 0x81a: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_81d:
	/* 0x81d: jmp    821 <trace_mmap_alert+0x821> */
	X86_SIM_X86_JMP(0x81d, 0x821, x86_l_821);
x86_l_81f:
	/* 0x81f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_821:
	/* 0x821: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_824:
	/* 0x824: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_827:
	/* 0x827: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_82a:
	/* 0x82a: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_82d:
	/* 0x82d: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_832:
	/* 0x832: cmp    QWORD PTR [rbp+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_83a:
	/* 0x83a: je     a02 <trace_mmap_alert+0xa02> */
	X86_SIM_X86_JCC(X86_CC_E, 0x83a, 0xa02, x86_l_a02);
x86_l_840:
	/* 0x840: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_845:
	/* 0x845: add    rax,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_84c:
	/* 0x84c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_84f:
	/* 0x84f: jns    862 <trace_mmap_alert+0x862> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x84f, 0x862, x86_l_862);
x86_l_851:
	/* 0x851: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_854:
	/* 0x854: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_857:
	/* 0x857: js     869 <trace_mmap_alert+0x869> */
	X86_SIM_X86_JCC(X86_CC_S, 0x857, 0x869, x86_l_869);
x86_l_859:
	/* 0x859: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85b:
	/* 0x85b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85e:
	/* 0x85e: js     871 <trace_mmap_alert+0x871> */
	X86_SIM_X86_JCC(X86_CC_S, 0x85e, 0x871, x86_l_871);
x86_l_860:
	/* 0x860: jmp    8bc <trace_mmap_alert+0x8bc> */
	X86_SIM_X86_JMP(0x860, 0x8bc, x86_l_8bc);
x86_l_862:
	/* 0x862: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_864:
	/* 0x864: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_867:
	/* 0x867: jns    859 <trace_mmap_alert+0x859> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x867, 0x859, x86_l_859);
x86_l_869:
	/* 0x869: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86c:
	/* 0x86c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86f:
	/* 0x86f: jns    8bc <trace_mmap_alert+0x8bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x86f, 0x8bc, x86_l_8bc);
x86_l_871:
	/* 0x871: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_874:
	/* 0x874: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_879:
	/* 0x879: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_87d:
	/* 0x87d: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_882:
	/* 0x882: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_886:
	/* 0x886: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_88b:
	/* 0x88b: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_88f:
	/* 0x88f: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_894:
	/* 0x894: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_898:
	/* 0x898: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_89d:
	/* 0x89d: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8a1:
	/* 0x8a1: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_8a6:
	/* 0x8a6: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8aa:
	/* 0x8aa: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8af:
	/* 0x8af: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8b3:
	/* 0x8b3: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8b8:
	/* 0x8b8: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_8bc:
	/* 0x8bc: lea    rbx,[r13+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_8c0:
	/* 0x8c0: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8c5:
	/* 0x8c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c8:
	/* 0x8c8: jns    98b <trace_mmap_alert+0x98b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c8, 0x98b, x86_l_98b);
x86_l_8ce:
	/* 0x8ce: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8d1:
	/* 0x8d1: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8d3:
	/* 0x8d3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8d5:
	/* 0x8d5: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8d5, 0x99a, x86_l_99a);
x86_l_8db:
	/* 0x8db: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_8df:
	/* 0x8df: mov    BYTE PTR [rbp+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_8e2:
	/* 0x8e2: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8e4:
	/* 0x8e4: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e4, 0x99a, x86_l_99a);
x86_l_8ea:
	/* 0x8ea: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_8ee:
	/* 0x8ee: mov    BYTE PTR [rbp+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_8f1:
	/* 0x8f1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8f3:
	/* 0x8f3: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f3, 0x99a, x86_l_99a);
x86_l_8f9:
	/* 0x8f9: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_8fd:
	/* 0x8fd: mov    BYTE PTR [rbp+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_900:
	/* 0x900: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_902:
	/* 0x902: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x902, 0x99a, x86_l_99a);
x86_l_908:
	/* 0x908: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_90c:
	/* 0x90c: mov    BYTE PTR [rbp+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_90f:
	/* 0x90f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_911:
	/* 0x911: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x911, 0x99a, x86_l_99a);
x86_l_917:
	/* 0x917: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_91b:
	/* 0x91b: mov    BYTE PTR [rbp+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_91e:
	/* 0x91e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_920:
	/* 0x920: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x920, 0x99a, x86_l_99a);
x86_l_922:
	/* 0x922: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_926:
	/* 0x926: mov    BYTE PTR [rbp+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_929:
	/* 0x929: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_92b:
	/* 0x92b: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x92b, 0x99a, x86_l_99a);
x86_l_92d:
	/* 0x92d: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_931:
	/* 0x931: mov    BYTE PTR [rbp+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_934:
	/* 0x934: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_936:
	/* 0x936: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x936, 0x99a, x86_l_99a);
x86_l_938:
	/* 0x938: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_93c:
	/* 0x93c: mov    BYTE PTR [rbp+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_93f:
	/* 0x93f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_941:
	/* 0x941: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x941, 0x99a, x86_l_99a);
x86_l_943:
	/* 0x943: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_947:
	/* 0x947: mov    BYTE PTR [rbp+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_94a:
	/* 0x94a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_94c:
	/* 0x94c: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94c, 0x99a, x86_l_99a);
x86_l_94e:
	/* 0x94e: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_952:
	/* 0x952: mov    BYTE PTR [rbp+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_955:
	/* 0x955: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_957:
	/* 0x957: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x957, 0x99a, x86_l_99a);
x86_l_959:
	/* 0x959: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_95d:
	/* 0x95d: mov    BYTE PTR [rbp+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_960:
	/* 0x960: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_962:
	/* 0x962: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x962, 0x99a, x86_l_99a);
x86_l_964:
	/* 0x964: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_968:
	/* 0x968: mov    BYTE PTR [rbp+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_96b:
	/* 0x96b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_96d:
	/* 0x96d: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x96d, 0x99a, x86_l_99a);
x86_l_96f:
	/* 0x96f: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_973:
	/* 0x973: mov    BYTE PTR [rbp+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_976:
	/* 0x976: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_978:
	/* 0x978: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x978, 0x99a, x86_l_99a);
x86_l_97a:
	/* 0x97a: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_97e:
	/* 0x97e: mov    BYTE PTR [rbp+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_981:
	/* 0x981: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_983:
	/* 0x983: je     99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x983, 0x99a, x86_l_99a);
x86_l_985:
	/* 0x985: mov    BYTE PTR [rbp+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_989:
	/* 0x989: jmp    99a <trace_mmap_alert+0x99a> */
	X86_SIM_X86_JMP(0x989, 0x99a, x86_l_99a);
x86_l_98b:
	/* 0x98b: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_993:
	/* 0x993: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_99a:
	/* 0x99a: mov    r12,QWORD PTR [rbp+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_9a1:
	/* 0x9a1: mov    r13,QWORD PTR [rbp+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_9a8:
	/* 0x9a8: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9ab:
	/* 0x9ab: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_9b1:
	/* 0x9b1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_9b8:
	/* 0x9b8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_9bd:
	/* 0x9bd: call   9c2 <trace_mmap_alert+0x9c2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9c2:
	/* 0x9c2: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9c9:
	/* 0x9c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9cc:
	/* 0x9cc: je     9ea <trace_mmap_alert+0x9ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cc, 0x9ea, x86_l_9ea);
x86_l_9ce:
	/* 0x9ce: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d1:
	/* 0x9d1: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9d4:
	/* 0x9d4: call   9d9 <trace_mmap_alert+0x9d9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9d9:
	/* 0x9d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9dc:
	/* 0x9dc: je     9ea <trace_mmap_alert+0x9ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9dc, 0x9ea, x86_l_9ea);
x86_l_9de:
	/* 0x9de: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9e1:
	/* 0x9e1: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9e5:
	/* 0x9e5: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9e8:
	/* 0x9e8: jmp    9ec <trace_mmap_alert+0x9ec> */
	X86_SIM_X86_JMP(0x9e8, 0x9ec, x86_l_9ec);
x86_l_9ea:
	/* 0x9ea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9ec:
	/* 0x9ec: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9ef:
	/* 0x9ef: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9f2:
	/* 0x9f2: or     r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9f5:
	/* 0x9f5: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9f8:
	/* 0x9f8: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9fd:
	/* 0x9fd: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_a02:
	/* 0xa02: cmp    QWORD PTR [rbp+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a0a:
	/* 0xa0a: je     a85 <trace_mmap_alert+0xa85> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa0a, 0xa85, x86_l_a85);
x86_l_a0c:
	/* 0xa0c: lea    rbx,[r13+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a10:
	/* 0xa10: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a13:
	/* 0xa13: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a18:
	/* 0xa18: call   a1d <trace_mmap_alert+0xa1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_a1d:
	/* 0xa1d: mov    r12,QWORD PTR [rbp+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_a24:
	/* 0xa24: mov    r13,QWORD PTR [rbp+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_a2b:
	/* 0xa2b: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a2e:
	/* 0xa2e: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a34:
	/* 0xa34: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_a3b:
	/* 0xa3b: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a40:
	/* 0xa40: call   a45 <trace_mmap_alert+0xa45> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a45:
	/* 0xa45: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a4c:
	/* 0xa4c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a4f:
	/* 0xa4f: je     a6d <trace_mmap_alert+0xa6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa4f, 0xa6d, x86_l_a6d);
x86_l_a51:
	/* 0xa51: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a54:
	/* 0xa54: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a57:
	/* 0xa57: call   a5c <trace_mmap_alert+0xa5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a5c:
	/* 0xa5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a5f:
	/* 0xa5f: je     a6d <trace_mmap_alert+0xa6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5f, 0xa6d, x86_l_a6d);
x86_l_a61:
	/* 0xa61: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a64:
	/* 0xa64: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a68:
	/* 0xa68: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a6b:
	/* 0xa6b: jmp    a6f <trace_mmap_alert+0xa6f> */
	X86_SIM_X86_JMP(0xa6b, 0xa6f, x86_l_a6f);
x86_l_a6d:
	/* 0xa6d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a6f:
	/* 0xa6f: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a72:
	/* 0xa72: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a75:
	/* 0xa75: or     r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a78:
	/* 0xa78: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a7b:
	/* 0xa7b: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a80:
	/* 0xa80: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_a85:
	/* 0xa85: mov    rbx,QWORD PTR [rbp+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_a8c:
	/* 0xa8c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a8f:
	/* 0xa8f: je     afc <trace_mmap_alert+0xafc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa8f, 0xafc, x86_l_afc);
x86_l_a91:
	/* 0xa91: mov    eax,DWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a94:
	/* 0xa94: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a98:
	/* 0xa98: mov    r12,QWORD PTR [rbp+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_a9f:
	/* 0xa9f: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_aa2:
	/* 0xaa2: mov    WORD PTR [rsp+0xc0],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_aab:
	/* 0xaab: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_ab2:
	/* 0xab2: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_aba:
	/* 0xaba: call   abf <trace_mmap_alert+0xabf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_abf:
	/* 0xabf: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ac6:
	/* 0xac6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac9:
	/* 0xac9: je     ae9 <trace_mmap_alert+0xae9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac9, 0xae9, x86_l_ae9);
x86_l_acb:
	/* 0xacb: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ad0:
	/* 0xad0: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad3:
	/* 0xad3: call   ad8 <trace_mmap_alert+0xad8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad8:
	/* 0xad8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adb:
	/* 0xadb: je     ae9 <trace_mmap_alert+0xae9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xadb, 0xae9, x86_l_ae9);
x86_l_add:
	/* 0xadd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ae0:
	/* 0xae0: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ae4:
	/* 0xae4: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ae7:
	/* 0xae7: jmp    aeb <trace_mmap_alert+0xaeb> */
	X86_SIM_X86_JMP(0xae7, 0xaeb, x86_l_aeb);
x86_l_ae9:
	/* 0xae9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aeb:
	/* 0xaeb: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_aee:
	/* 0xaee: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_af1:
	/* 0xaf1: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_af4:
	/* 0xaf4: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_af7:
	/* 0xaf7: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_afc:
	/* 0xafc: mov    rbx,QWORD PTR [rbp+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b03:
	/* 0xb03: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b06:
	/* 0xb06: je     b65 <trace_mmap_alert+0xb65> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb06, 0xb65, x86_l_b65);
x86_l_b08:
	/* 0xb08: mov    r12,QWORD PTR [rbp+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_b0f:
	/* 0xb0f: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b12:
	/* 0xb12: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b18:
	/* 0xb18: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_b1f:
	/* 0xb1f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b24:
	/* 0xb24: call   b29 <trace_mmap_alert+0xb29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b29:
	/* 0xb29: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b30:
	/* 0xb30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b33:
	/* 0xb33: je     b52 <trace_mmap_alert+0xb52> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb33, 0xb52, x86_l_b52);
x86_l_b35:
	/* 0xb35: lea    rsi,[r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_b39:
	/* 0xb39: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b3c:
	/* 0xb3c: call   b41 <trace_mmap_alert+0xb41> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b41:
	/* 0xb41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b44:
	/* 0xb44: je     b52 <trace_mmap_alert+0xb52> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb44, 0xb52, x86_l_b52);
x86_l_b46:
	/* 0xb46: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b49:
	/* 0xb49: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b4d:
	/* 0xb4d: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b50:
	/* 0xb50: jmp    b54 <trace_mmap_alert+0xb54> */
	X86_SIM_X86_JMP(0xb50, 0xb54, x86_l_b54);
x86_l_b52:
	/* 0xb52: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b54:
	/* 0xb54: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b57:
	/* 0xb57: and    r14,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b5a:
	/* 0xb5a: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b5d:
	/* 0xb5d: and    r15,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b60:
	/* 0xb60: movzx  r14d,WORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_b65:
	/* 0xb65: mov    r12,QWORD PTR [rbp+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_b6c:
	/* 0xb6c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_b6f:
	/* 0xb6f: je     bfb <trace_mmap_alert+0xbfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb6f, 0xbfb, x86_l_bfb);
x86_l_b75:
	/* 0xb75: mov    r13,QWORD PTR [rbp+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_b7c:
	/* 0xb7c: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b7f:
	/* 0xb7f: mov    WORD PTR [rsp+0x30],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b85:
	/* 0xb85: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_b8c:
	/* 0xb8c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b91:
	/* 0xb91: call   b96 <trace_mmap_alert+0xb96> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b96:
	/* 0xb96: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b9d:
	/* 0xb9d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba0:
	/* 0xba0: je     be3 <trace_mmap_alert+0xbe3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xba0, 0xbe3, x86_l_be3);
x86_l_ba2:
	/* 0xba2: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba5:
	/* 0xba5: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_bad:
	/* 0xbad: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_bb1:
	/* 0xbb1: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bb4:
	/* 0xbb4: call   bb9 <trace_mmap_alert+0xbb9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bb9:
	/* 0xbb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbc:
	/* 0xbbc: jne    bd7 <trace_mmap_alert+0xbd7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbbc, 0xbd7, x86_l_bd7);
x86_l_bbe:
	/* 0xbbe: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_bc6:
	/* 0xbc6: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bca:
	/* 0xbca: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bcd:
	/* 0xbcd: call   bd2 <trace_mmap_alert+0xbd2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bd2:
	/* 0xbd2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd5:
	/* 0xbd5: je     be3 <trace_mmap_alert+0xbe3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd5, 0xbe3, x86_l_be3);
x86_l_bd7:
	/* 0xbd7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bda:
	/* 0xbda: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bde:
	/* 0xbde: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_be1:
	/* 0xbe1: jmp    be5 <trace_mmap_alert+0xbe5> */
	X86_SIM_X86_JMP(0xbe1, 0xbe5, x86_l_be5);
x86_l_be3:
	/* 0xbe3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_be5:
	/* 0xbe5: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_be8:
	/* 0xbe8: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_beb:
	/* 0xbeb: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bee:
	/* 0xbee: and    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bf1:
	/* 0xbf1: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bf6:
	/* 0xbf6: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfb:
	/* 0xbfb: mov    rax,QWORD PTR [rbp+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c02:
	/* 0xc02: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c05:
	/* 0xc05: je     c16 <trace_mmap_alert+0xc16> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc05, 0xc16, x86_l_c16);
x86_l_c07:
	/* 0xc07: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_c0f:
	/* 0xc0f: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_c13:
	/* 0xc13: or     r15,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c16:
	/* 0xc16: and    r15,QWORD PTR [rbp+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_c1d:
	/* 0xc1d: mov    rax,QWORD PTR [rbp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c24:
	/* 0xc24: and    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c27:
	/* 0xc27: mov    QWORD PTR [rbp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c2e:
	/* 0xc2e: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc2e, 0x1a1d, x86_l_1a1d);
x86_l_c34:
	/* 0xc34: cmp    DWORD PTR [rbp+0x74],0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 498216206345ULL);
x86_l_c38:
	/* 0xc38: jne    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc38, 0x1a1d, x86_l_1a1d);
x86_l_c3e:
	/* 0xc3e: call   c43 <trace_mmap_alert+0xc43> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_c43:
	/* 0xc43: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c46:
	/* 0xc46: call   c4b <trace_mmap_alert+0xc4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_c4b:
	/* 0xc4b: mov    rcx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_c52:
	/* 0xc52: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c55:
	/* 0xc55: jns    c62 <trace_mmap_alert+0xc62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc55, 0xc62, x86_l_c62);
x86_l_c57:
	/* 0xc57: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c59:
	/* 0xc59: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_c5c:
	/* 0xc5c: jne    d8e <trace_mmap_alert+0xd8e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc5c, 0xd8e, x86_l_d8e);
x86_l_c62:
	/* 0xc62: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_c66:
	/* 0xc66: mov    DWORD PTR [rsp+0x28],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c6a:
	/* 0xc6a: not    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_c6c:
	/* 0xc6c: test   cl,0x6 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_c6f:
	/* 0xc6f: jne    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc6f, 0x1a1d, x86_l_1a1d);
x86_l_c75:
	/* 0xc75: mov    DWORD PTR [rsp+0x94],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 635655159809ULL);
x86_l_c80:
	/* 0xc80: mov    rcx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_c87:
	/* 0xc87: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c8a:
	/* 0xc8a: jns    c97 <trace_mmap_alert+0xc97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc8a, 0xc97, x86_l_c97);
x86_l_c8c:
	/* 0xc8c: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c8e:
	/* 0xc8e: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_c91:
	/* 0xc91: jne    dbc <trace_mmap_alert+0xdbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc91, 0xdbc, x86_l_dbc);
x86_l_c97:
	/* 0xc97: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c9b:
	/* 0xc9b: mov    QWORD PTR [rsp+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_ca3:
	/* 0xca3: mov    rcx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_caa:
	/* 0xcaa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cad:
	/* 0xcad: jns    cba <trace_mmap_alert+0xcba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcad, 0xcba, x86_l_cba);
x86_l_caf:
	/* 0xcaf: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cb1:
	/* 0xcb1: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_cb4:
	/* 0xcb4: jne    dd1 <trace_mmap_alert+0xdd1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcb4, 0xdd1, x86_l_dd1);
x86_l_cba:
	/* 0xcba: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_cbe:
	/* 0xcbe: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_cc6:
	/* 0xcc6: mov    rcx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_ccd:
	/* 0xccd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cd0:
	/* 0xcd0: jns    cdd <trace_mmap_alert+0xcdd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd0, 0xcdd, x86_l_cdd);
x86_l_cd2:
	/* 0xcd2: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd4:
	/* 0xcd4: test   cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_cd7:
	/* 0xcd7: jne    de6 <trace_mmap_alert+0xde6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcd7, 0xde6, x86_l_de6);
x86_l_cdd:
	/* 0xcdd: mov    rbx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_ce1:
	/* 0xce1: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_ce9:
	/* 0xce9: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_cf5:
	/* 0xcf5: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_cfe:
	/* 0xcfe: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_d07:
	/* 0xd07: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_d10:
	/* 0xd10: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_d19:
	/* 0xd19: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_d22:
	/* 0xd22: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_d2b:
	/* 0xd2b: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_d34:
	/* 0xd34: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_d3d:
	/* 0xd3d: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_d46:
	/* 0xd46: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_d4f:
	/* 0xd4f: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_d51:
	/* 0xd51: js     1033 <trace_mmap_alert+0x1033> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd51, 0x1033, x86_l_1033);
x86_l_d57:
	/* 0xd57: call   d5c <trace_mmap_alert+0xd5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_d5c:
	/* 0xd5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d5f:
	/* 0xd5f: je     f5d <trace_mmap_alert+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd5f, 0xf5d, x86_l_f5d);
x86_l_d65:
	/* 0xd65: sub    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_d69:
	/* 0xd69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d6c:
	/* 0xd6c: jns    dfb <trace_mmap_alert+0xdfb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd6c, 0xdfb, x86_l_dfb);
x86_l_d72:
	/* 0xd72: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d75:
	/* 0xd75: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d78:
	/* 0xd78: js     e06 <trace_mmap_alert+0xe06> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd78, 0xe06, x86_l_e06);
x86_l_d7e:
	/* 0xd7e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d80:
	/* 0xd80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d83:
	/* 0xd83: js     e12 <trace_mmap_alert+0xe12> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd83, 0xe12, x86_l_e12);
x86_l_d89:
	/* 0xd89: jmp    f5d <trace_mmap_alert+0xf5d> */
	X86_SIM_X86_JMP(0xd89, 0xf5d, x86_l_f5d);
x86_l_d8e:
	/* 0xd8e: lea    rcx,[rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_d92:
	/* 0xd92: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d95:
	/* 0xd95: jns    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd95, 0x1a1d, x86_l_1a1d);
x86_l_d9b:
	/* 0xd9b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d9e:
	/* 0xd9e: mov    DWORD PTR [rsp+0x28],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_da2:
	/* 0xda2: not    ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NOT, 0);
x86_l_da4:
	/* 0xda4: test   cl,0x6 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_da7:
	/* 0xda7: je     c75 <trace_mmap_alert+0xc75> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda7, 0xc75, x86_l_c75);
x86_l_dad:
	/* 0xdad: jmp    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JMP(0xdad, 0x1a1d, x86_l_1a1d);
x86_l_db2:
	/* 0xdb2: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_db7:
	/* 0xdb7: jmp    1d1 <trace_mmap_alert+0x1d1> */
	X86_SIM_X86_JMP(0xdb7, 0x1d1, x86_l_1d1);
x86_l_dbc:
	/* 0xdbc: lea    rcx,[rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_dc0:
	/* 0xdc0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dc3:
	/* 0xdc3: jns    ed1 <trace_mmap_alert+0xed1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdc3, 0xed1, x86_l_ed1);
x86_l_dc9:
	/* 0xdc9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dcc:
	/* 0xdcc: jmp    c9b <trace_mmap_alert+0xc9b> */
	X86_SIM_X86_JMP(0xdcc, 0xc9b, x86_l_c9b);
x86_l_dd1:
	/* 0xdd1: lea    rcx,[rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_dd5:
	/* 0xdd5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dd8:
	/* 0xdd8: jns    ed8 <trace_mmap_alert+0xed8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdd8, 0xed8, x86_l_ed8);
x86_l_dde:
	/* 0xdde: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de1:
	/* 0xde1: jmp    cbe <trace_mmap_alert+0xcbe> */
	X86_SIM_X86_JMP(0xde1, 0xcbe, x86_l_cbe);
x86_l_de6:
	/* 0xde6: add    rax,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_dea:
	/* 0xdea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ded:
	/* 0xded: jns    edf <trace_mmap_alert+0xedf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xded, 0xedf, x86_l_edf);
x86_l_df3:
	/* 0xdf3: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_df6:
	/* 0xdf6: jmp    ce1 <trace_mmap_alert+0xce1> */
	X86_SIM_X86_JMP(0xdf6, 0xce1, x86_l_ce1);
x86_l_dfb:
	/* 0xdfb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dfd:
	/* 0xdfd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e00:
	/* 0xe00: jns    d7e <trace_mmap_alert+0xd7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe00, 0xd7e, x86_l_d7e);
x86_l_e06:
	/* 0xe06: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e09:
	/* 0xe09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e0c:
	/* 0xe0c: jns    f5d <trace_mmap_alert+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe0c, 0xf5d, x86_l_f5d);
x86_l_e12:
	/* 0xe12: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e15:
	/* 0xe15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e18:
	/* 0xe18: je     f5d <trace_mmap_alert+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe18, 0xf5d, x86_l_f5d);
x86_l_e1e:
	/* 0xe1e: and    ebx,0x7fffffff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2147483647ULL);
x86_l_e24:
	/* 0xe24: lea    rax,[rax+rbx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBX, 3), 0ULL);
x86_l_e28:
	/* 0xe28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e2b:
	/* 0xe2b: jns    f5d <trace_mmap_alert+0xf5d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe2b, 0xf5d, x86_l_f5d);
x86_l_e31:
	/* 0xe31: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e34:
	/* 0xe34: mov    QWORD PTR [rsp+0xf0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1030792151040ULL);
x86_l_e40:
	/* 0xe40: mov    QWORD PTR [rsp+0xe8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 996432412672ULL);
x86_l_e4c:
	/* 0xe4c: mov    QWORD PTR [rsp+0xe0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 962072674304ULL);
x86_l_e58:
	/* 0xe58: mov    QWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_e64:
	/* 0xe64: mov    QWORD PTR [rsp+0xd0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 893353197568ULL);
x86_l_e70:
	/* 0xe70: mov    QWORD PTR [rsp+0xc8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 858993459200ULL);
x86_l_e7c:
	/* 0xe7c: mov    QWORD PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_e88:
	/* 0xe88: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e8b:
	/* 0xe8b: je     fb1 <trace_mmap_alert+0xfb1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8b, 0xfb1, x86_l_fb1);
x86_l_e91:
	/* 0xe91: mov    DWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_e9c:
	/* 0xe9c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_ea3:
	/* 0xea3: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_eab:
	/* 0xeab: call   eb0 <trace_mmap_alert+0xeb0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_eb0:
	/* 0xeb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_eb3:
	/* 0xeb3: je     1a35 <trace_mmap_alert+0x1a35> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeb3, 0x1a35, x86_l_1a35);
x86_l_eb9:
	/* 0xeb9: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ebc:
	/* 0xebc: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ec0:
	/* 0xec0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ec3:
	/* 0xec3: jns    1a3d <trace_mmap_alert+0x1a3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xec3, 0x1a3d, x86_l_1a3d);
x86_l_ec9:
	/* 0xec9: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ecc:
	/* 0xecc: jmp    1a3f <trace_mmap_alert+0x1a3f> */
	X86_SIM_X86_JMP(0xecc, 0x1a3f, x86_l_1a3f);
x86_l_ed1:
	/* 0xed1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ed3:
	/* 0xed3: jmp    c9b <trace_mmap_alert+0xc9b> */
	X86_SIM_X86_JMP(0xed3, 0xc9b, x86_l_c9b);
x86_l_ed8:
	/* 0xed8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eda:
	/* 0xeda: jmp    cbe <trace_mmap_alert+0xcbe> */
	X86_SIM_X86_JMP(0xeda, 0xcbe, x86_l_cbe);
x86_l_edf:
	/* 0xedf: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_ee7:
	/* 0xee7: mov    QWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_ef3:
	/* 0xef3: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_efc:
	/* 0xefc: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_f05:
	/* 0xf05: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_f0e:
	/* 0xf0e: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_f17:
	/* 0xf17: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_f20:
	/* 0xf20: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_f29:
	/* 0xf29: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_f32:
	/* 0xf32: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_f3b:
	/* 0xf3b: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_f44:
	/* 0xf44: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_f4d:
	/* 0xf4d: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f4f:
	/* 0xf4f: call   f54 <trace_mmap_alert+0xf54> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_f54:
	/* 0xf54: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f57:
	/* 0xf57: jne    d65 <trace_mmap_alert+0xd65> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf57, 0xd65, x86_l_d65);
x86_l_f5d:
	/* 0xf5d: mov    QWORD PTR [rsp+0xf0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1030792151040ULL);
x86_l_f69:
	/* 0xf69: mov    QWORD PTR [rsp+0xe8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 996432412672ULL);
x86_l_f75:
	/* 0xf75: mov    QWORD PTR [rsp+0xe0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 962072674304ULL);
x86_l_f81:
	/* 0xf81: mov    QWORD PTR [rsp+0xd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 927712935936ULL);
x86_l_f8d:
	/* 0xf8d: mov    QWORD PTR [rsp+0xd0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 893353197568ULL);
x86_l_f99:
	/* 0xf99: mov    QWORD PTR [rsp+0xc8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 858993459200ULL);
x86_l_fa5:
	/* 0xfa5: mov    QWORD PTR [rsp+0xc0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 824633720832ULL);
x86_l_fb1:
	/* 0xfb1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb3:
	/* 0xfb3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb5:
	/* 0xfb5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fb7:
	/* 0xfb7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fba:
	/* 0xfba: mov    QWORD PTR [rsp+0x30],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fbf:
	/* 0xfbf: mov    rsi,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_fc7:
	/* 0xfc7: mov    rdi,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_fcf:
	/* 0xfcf: mov    QWORD PTR [rsp+0x38],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_fd4:
	/* 0xfd4: mov    QWORD PTR [rsp+0x40],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fd9:
	/* 0xfd9: mov    rsi,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_fe1:
	/* 0xfe1: mov    QWORD PTR [rsp+0x48],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_fe6:
	/* 0xfe6: mov    rsi,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_fee:
	/* 0xfee: mov    QWORD PTR [rsp+0x50],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ff3:
	/* 0xff3: mov    rsi,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_ffb:
	/* 0xffb: mov    QWORD PTR [rsp+0x58],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1000:
	/* 0x1000: mov    rsi,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1008:
	/* 0x1008: mov    QWORD PTR [rsp+0x60],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_100d:
	/* 0x100d: mov    rsi,QWORD PTR [rsp+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1015:
	/* 0x1015: mov    QWORD PTR [rsp+0x68],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_101a:
	/* 0x101a: mov    DWORD PTR [rsp+0x70],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_101e:
	/* 0x101e: mov    DWORD PTR [rsp+0x74],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 498216206336ULL);
x86_l_1026:
	/* 0x1026: mov    QWORD PTR [rsp+0x78],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_102b:
	/* 0x102b: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1033:
	/* 0x1033: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_103a:
	/* 0x103a: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1041:
	/* 0x1041: ja     10a5 <trace_mmap_alert+0x10a5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1041, 0x10a5, x86_l_10a5);
x86_l_1043:
	/* 0x1043: mov    BYTE PTR [rbp+rbx*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519552ULL);
x86_l_104b:
	/* 0x104b: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_1051:
	/* 0x1051: ja     10a5 <trace_mmap_alert+0x10a5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1051, 0x10a5, x86_l_10a5);
x86_l_1053:
	/* 0x1053: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1057:
	/* 0x1057: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_105e:
	/* 0x105e: lea    rax,[rsp+0x94] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_1066:
	/* 0x1066: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1069:
	/* 0x1069: jns    1076 <trace_mmap_alert+0x1076> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1069, 0x1076, x86_l_1076);
x86_l_106b:
	/* 0x106b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_106e:
	/* 0x106e: jns    109f <trace_mmap_alert+0x109f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x106e, 0x109f, x86_l_109f);
x86_l_1070:
	/* 0x1070: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1072:
	/* 0x1072: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1074:
	/* 0x1074: jmp    108d <trace_mmap_alert+0x108d> */
	X86_SIM_X86_JMP(0x1074, 0x108d, x86_l_108d);
x86_l_1076:
	/* 0x1076: lea    rdx,[rsp+0x94] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_107e:
	/* 0x107e: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1083:
	/* 0x1083: call   1088 <trace_mmap_alert+0x1088> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1088:
	/* 0x1088: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_108b:
	/* 0x108b: js     10a5 <trace_mmap_alert+0x10a5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x108b, 0x10a5, x86_l_10a5);
x86_l_108d:
	/* 0x108d: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1090:
	/* 0x1090: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1097:
	/* 0x1097: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_109d:
	/* 0x109d: jmp    10a5 <trace_mmap_alert+0x10a5> */
	X86_SIM_X86_JMP(0x109d, 0x10a5, x86_l_10a5);
x86_l_109f:
	/* 0x109f: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10a5:
	/* 0x10a5: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_10ac:
	/* 0x10ac: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_10b3:
	/* 0x10b3: ja     111a <trace_mmap_alert+0x111a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10b3, 0x111a, x86_l_111a);
x86_l_10b5:
	/* 0x10b5: mov    BYTE PTR [rbp+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_10bd:
	/* 0x10bd: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_10c3:
	/* 0x10c3: ja     111a <trace_mmap_alert+0x111a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10c3, 0x111a, x86_l_111a);
x86_l_10c5:
	/* 0x10c5: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_10c9:
	/* 0x10c9: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_10d0:
	/* 0x10d0: lea    rax,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_10d8:
	/* 0x10d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10db:
	/* 0x10db: jns    10ea <trace_mmap_alert+0x10ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10db, 0x10ea, x86_l_10ea);
x86_l_10dd:
	/* 0x10dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e0:
	/* 0x10e0: jns    1113 <trace_mmap_alert+0x1113> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10e0, 0x1113, x86_l_1113);
x86_l_10e2:
	/* 0x10e2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e5:
	/* 0x10e5: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10e8:
	/* 0x10e8: jmp    1101 <trace_mmap_alert+0x1101> */
	X86_SIM_X86_JMP(0x10e8, 0x1101, x86_l_1101);
x86_l_10ea:
	/* 0x10ea: lea    rdx,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_10f2:
	/* 0x10f2: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_10f7:
	/* 0x10f7: call   10fc <trace_mmap_alert+0x10fc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_10fc:
	/* 0x10fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10ff:
	/* 0x10ff: js     111a <trace_mmap_alert+0x111a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10ff, 0x111a, x86_l_111a);
x86_l_1101:
	/* 0x1101: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_1104:
	/* 0x1104: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_110b:
	/* 0x110b: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1111:
	/* 0x1111: jmp    111a <trace_mmap_alert+0x111a> */
	X86_SIM_X86_JMP(0x1111, 0x111a, x86_l_111a);
x86_l_1113:
	/* 0x1113: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_111a:
	/* 0x111a: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1121:
	/* 0x1121: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1128:
	/* 0x1128: ja     118f <trace_mmap_alert+0x118f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1128, 0x118f, x86_l_118f);
x86_l_112a:
	/* 0x112a: mov    BYTE PTR [rbp+rbx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519554ULL);
x86_l_1132:
	/* 0x1132: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_1138:
	/* 0x1138: ja     118f <trace_mmap_alert+0x118f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1138, 0x118f, x86_l_118f);
x86_l_113a:
	/* 0x113a: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_113e:
	/* 0x113e: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1145:
	/* 0x1145: lea    rax,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_114d:
	/* 0x114d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1150:
	/* 0x1150: jns    115f <trace_mmap_alert+0x115f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1150, 0x115f, x86_l_115f);
x86_l_1152:
	/* 0x1152: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1155:
	/* 0x1155: jns    1188 <trace_mmap_alert+0x1188> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1155, 0x1188, x86_l_1188);
x86_l_1157:
	/* 0x1157: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_115a:
	/* 0x115a: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_115d:
	/* 0x115d: jmp    1176 <trace_mmap_alert+0x1176> */
	X86_SIM_X86_JMP(0x115d, 0x1176, x86_l_1176);
x86_l_115f:
	/* 0x115f: lea    rdx,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1167:
	/* 0x1167: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_116c:
	/* 0x116c: call   1171 <trace_mmap_alert+0x1171> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1171:
	/* 0x1171: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1174:
	/* 0x1174: js     118f <trace_mmap_alert+0x118f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1174, 0x118f, x86_l_118f);
x86_l_1176:
	/* 0x1176: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_1179:
	/* 0x1179: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1180:
	/* 0x1180: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1186:
	/* 0x1186: jmp    118f <trace_mmap_alert+0x118f> */
	X86_SIM_X86_JMP(0x1186, 0x118f, x86_l_118f);
x86_l_1188:
	/* 0x1188: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_118f:
	/* 0x118f: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1196:
	/* 0x1196: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_119d:
	/* 0x119d: ja     11fb <trace_mmap_alert+0x11fb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x119d, 0x11fb, x86_l_11fb);
x86_l_119f:
	/* 0x119f: mov    BYTE PTR [rbp+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_11a7:
	/* 0x11a7: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_11ad:
	/* 0x11ad: ja     11fb <trace_mmap_alert+0x11fb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x11ad, 0x11fb, x86_l_11fb);
x86_l_11af:
	/* 0x11af: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_11b3:
	/* 0x11b3: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_11ba:
	/* 0x11ba: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11bf:
	/* 0x11bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11c2:
	/* 0x11c2: jns    11cf <trace_mmap_alert+0x11cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11c2, 0x11cf, x86_l_11cf);
x86_l_11c4:
	/* 0x11c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11c7:
	/* 0x11c7: jns    11f5 <trace_mmap_alert+0x11f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11c7, 0x11f5, x86_l_11f5);
x86_l_11c9:
	/* 0x11c9: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11cb:
	/* 0x11cb: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11cd:
	/* 0x11cd: jmp    11e3 <trace_mmap_alert+0x11e3> */
	X86_SIM_X86_JMP(0x11cd, 0x11e3, x86_l_11e3);
x86_l_11cf:
	/* 0x11cf: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11d4:
	/* 0x11d4: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_11d9:
	/* 0x11d9: call   11de <trace_mmap_alert+0x11de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_11de:
	/* 0x11de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11e1:
	/* 0x11e1: js     11fb <trace_mmap_alert+0x11fb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11e1, 0x11fb, x86_l_11fb);
x86_l_11e3:
	/* 0x11e3: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_11e6:
	/* 0x11e6: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_11ed:
	/* 0x11ed: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_11f3:
	/* 0x11f3: jmp    11fb <trace_mmap_alert+0x11fb> */
	X86_SIM_X86_JMP(0x11f3, 0x11fb, x86_l_11fb);
x86_l_11f5:
	/* 0x11f5: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11fb:
	/* 0x11fb: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1202:
	/* 0x1202: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1209:
	/* 0x1209: ja     1267 <trace_mmap_alert+0x1267> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1209, 0x1267, x86_l_1267);
x86_l_120b:
	/* 0x120b: mov    BYTE PTR [rbp+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_1213:
	/* 0x1213: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_1219:
	/* 0x1219: ja     1267 <trace_mmap_alert+0x1267> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1219, 0x1267, x86_l_1267);
x86_l_121b:
	/* 0x121b: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_121f:
	/* 0x121f: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1226:
	/* 0x1226: lea    rax,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_122b:
	/* 0x122b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_122e:
	/* 0x122e: jns    123b <trace_mmap_alert+0x123b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x122e, 0x123b, x86_l_123b);
x86_l_1230:
	/* 0x1230: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1233:
	/* 0x1233: jns    1261 <trace_mmap_alert+0x1261> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1233, 0x1261, x86_l_1261);
x86_l_1235:
	/* 0x1235: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1237:
	/* 0x1237: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1239:
	/* 0x1239: jmp    124f <trace_mmap_alert+0x124f> */
	X86_SIM_X86_JMP(0x1239, 0x124f, x86_l_124f);
x86_l_123b:
	/* 0x123b: lea    rdx,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1240:
	/* 0x1240: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1245:
	/* 0x1245: call   124a <trace_mmap_alert+0x124a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_124a:
	/* 0x124a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_124d:
	/* 0x124d: js     1267 <trace_mmap_alert+0x1267> */
	X86_SIM_X86_JCC(X86_CC_S, 0x124d, 0x1267, x86_l_1267);
x86_l_124f:
	/* 0x124f: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1252:
	/* 0x1252: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1259:
	/* 0x1259: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_125f:
	/* 0x125f: jmp    1267 <trace_mmap_alert+0x1267> */
	X86_SIM_X86_JMP(0x125f, 0x1267, x86_l_1267);
x86_l_1261:
	/* 0x1261: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1267:
	/* 0x1267: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_126c:
	/* 0x126c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_126f:
	/* 0x126f: je     147e <trace_mmap_alert+0x147e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x126f, 0x147e, x86_l_147e);
x86_l_1275:
	/* 0x1275: movzx  eax,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_127c:
	/* 0x127c: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_1282:
	/* 0x1282: ja     1340 <trace_mmap_alert+0x1340> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1282, 0x1340, x86_l_1340);
x86_l_1288:
	/* 0x1288: mov    BYTE PTR [rbp+rax*1+0x89],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519557ULL);
x86_l_1290:
	/* 0x1290: movzx  eax,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1297:
	/* 0x1297: mov    WORD PTR [rbp+0x7d96],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32150ULL);
x86_l_129e:
	/* 0x129e: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_12a4:
	/* 0x12a4: ja     1340 <trace_mmap_alert+0x1340> */
	X86_SIM_X86_JCC(X86_CC_A, 0x12a4, 0x1340, x86_l_1340);
x86_l_12aa:
	/* 0x12aa: lea    rdi,[rax+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_12ae:
	/* 0x12ae: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_12b5:
	/* 0x12b5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12b8:
	/* 0x12b8: jns    12e0 <trace_mmap_alert+0x12e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12b8, 0x12e0, x86_l_12e0);
x86_l_12ba:
	/* 0x12ba: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12bd:
	/* 0x12bd: jns    12f3 <trace_mmap_alert+0x12f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12bd, 0x12f3, x86_l_12f3);
x86_l_12bf:
	/* 0x12bf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12c1:
	/* 0x12c1: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_12c8:
	/* 0x12c8: je     1301 <trace_mmap_alert+0x1301> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12c8, 0x1301, x86_l_1301);
x86_l_12ca:
	/* 0x12ca: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12ce:
	/* 0x12ce: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_12d2:
	/* 0x12d2: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_12d6:
	/* 0x12d6: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d9:
	/* 0x12d9: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_12dc:
	/* 0x12dc: jne    12c1 <trace_mmap_alert+0x12c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12dc, 0x12c1, x86_l_12c1);
x86_l_12de:
	/* 0x12de: jmp    12ea <trace_mmap_alert+0x12ea> */
	X86_SIM_X86_JMP(0x12de, 0x12ea, x86_l_12ea);
x86_l_12e0:
	/* 0x12e0: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_12e5:
	/* 0x12e5: call   12ea <trace_mmap_alert+0x12ea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_12ea:
	/* 0x12ea: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ed:
	/* 0x12ed: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_12ef:
	/* 0x12ef: jg     1312 <trace_mmap_alert+0x1312> */
	X86_SIM_X86_JCC(X86_CC_G, 0x12ef, 0x1312, x86_l_1312);
x86_l_12f1:
	/* 0x12f1: jmp    1340 <trace_mmap_alert+0x1340> */
	X86_SIM_X86_JMP(0x12f1, 0x1340, x86_l_1340);
x86_l_12f3:
	/* 0x12f3: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_12f8:
	/* 0x12f8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12fa:
	/* 0x12fa: call   12ff <trace_mmap_alert+0x12ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_12ff:
	/* 0x12ff: jmp    1340 <trace_mmap_alert+0x1340> */
	X86_SIM_X86_JMP(0x12ff, 0x1340, x86_l_1340);
x86_l_1301:
	/* 0x1301: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_1308:
	/* 0x1308: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_130d:
	/* 0x130d: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1312:
	/* 0x1312: movzx  edx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1319:
	/* 0x1319: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_1320:
	/* 0x1320: ja     1340 <trace_mmap_alert+0x1340> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1320, 0x1340, x86_l_1340);
x86_l_1322:
	/* 0x1322: mov    DWORD PTR [rdx+rbp*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RBP, 0), 138ULL);
x86_l_1329:
	/* 0x1329: add    cx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RBP, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_1330:
	/* 0x1330: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1333:
	/* 0x1333: mov    WORD PTR [rbp+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_133a:
	/* 0x133a: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1340:
	/* 0x1340: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1347:
	/* 0x1347: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_134e:
	/* 0x134e: ja     13a7 <trace_mmap_alert+0x13a7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x134e, 0x13a7, x86_l_13a7);
x86_l_1350:
	/* 0x1350: mov    BYTE PTR [rbp+rbx*1+0x89],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519558ULL);
x86_l_1358:
	/* 0x1358: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_135e:
	/* 0x135e: ja     13a7 <trace_mmap_alert+0x13a7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x135e, 0x13a7, x86_l_13a7);
x86_l_1360:
	/* 0x1360: lea    rdx,[rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1365:
	/* 0x1365: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1369:
	/* 0x1369: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1370:
	/* 0x1370: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1373:
	/* 0x1373: jns    1380 <trace_mmap_alert+0x1380> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1373, 0x1380, x86_l_1380);
x86_l_1375:
	/* 0x1375: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1378:
	/* 0x1378: jns    13a1 <trace_mmap_alert+0x13a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1378, 0x13a1, x86_l_13a1);
x86_l_137a:
	/* 0x137a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137c:
	/* 0x137c: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137e:
	/* 0x137e: jmp    138f <trace_mmap_alert+0x138f> */
	X86_SIM_X86_JMP(0x137e, 0x138f, x86_l_138f);
x86_l_1380:
	/* 0x1380: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1385:
	/* 0x1385: call   138a <trace_mmap_alert+0x138a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_138a:
	/* 0x138a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_138d:
	/* 0x138d: js     13a7 <trace_mmap_alert+0x13a7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x138d, 0x13a7, x86_l_13a7);
x86_l_138f:
	/* 0x138f: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1392:
	/* 0x1392: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1399:
	/* 0x1399: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_139f:
	/* 0x139f: jmp    13a7 <trace_mmap_alert+0x13a7> */
	X86_SIM_X86_JMP(0x139f, 0x13a7, x86_l_13a7);
x86_l_13a1:
	/* 0x13a1: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13a7:
	/* 0x13a7: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_13ae:
	/* 0x13ae: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_13b5:
	/* 0x13b5: ja     1411 <trace_mmap_alert+0x1411> */
	X86_SIM_X86_JCC(X86_CC_A, 0x13b5, 0x1411, x86_l_1411);
x86_l_13b7:
	/* 0x13b7: mov    BYTE PTR [rbp+rbx*1+0x89],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519559ULL);
x86_l_13bf:
	/* 0x13bf: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_13c5:
	/* 0x13c5: ja     1411 <trace_mmap_alert+0x1411> */
	X86_SIM_X86_JCC(X86_CC_A, 0x13c5, 0x1411, x86_l_1411);
x86_l_13c7:
	/* 0x13c7: lea    rdx,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_13cc:
	/* 0x13cc: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_13d0:
	/* 0x13d0: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_13d7:
	/* 0x13d7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13da:
	/* 0x13da: jns    13e9 <trace_mmap_alert+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13da, 0x13e9, x86_l_13e9);
x86_l_13dc:
	/* 0x13dc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13df:
	/* 0x13df: jns    140a <trace_mmap_alert+0x140a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13df, 0x140a, x86_l_140a);
x86_l_13e1:
	/* 0x13e1: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e4:
	/* 0x13e4: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e7:
	/* 0x13e7: jmp    13f8 <trace_mmap_alert+0x13f8> */
	X86_SIM_X86_JMP(0x13e7, 0x13f8, x86_l_13f8);
x86_l_13e9:
	/* 0x13e9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_13ee:
	/* 0x13ee: call   13f3 <trace_mmap_alert+0x13f3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_13f3:
	/* 0x13f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13f6:
	/* 0x13f6: js     1411 <trace_mmap_alert+0x1411> */
	X86_SIM_X86_JCC(X86_CC_S, 0x13f6, 0x1411, x86_l_1411);
x86_l_13f8:
	/* 0x13f8: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_13fb:
	/* 0x13fb: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1402:
	/* 0x1402: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1408:
	/* 0x1408: jmp    1411 <trace_mmap_alert+0x1411> */
	X86_SIM_X86_JMP(0x1408, 0x1411, x86_l_1411);
x86_l_140a:
	/* 0x140a: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1411:
	/* 0x1411: movzx  ebx,WORD PTR [rbp+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1418:
	/* 0x1418: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_141f:
	/* 0x141f: ja     147e <trace_mmap_alert+0x147e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x141f, 0x147e, x86_l_147e);
x86_l_1421:
	/* 0x1421: mov    BYTE PTR [rbp+rbx*1+0x89],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519560ULL);
x86_l_1429:
	/* 0x1429: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_142f:
	/* 0x142f: ja     147e <trace_mmap_alert+0x147e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x142f, 0x147e, x86_l_147e);
x86_l_1431:
	/* 0x1431: lea    rdx,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1439:
	/* 0x1439: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_143d:
	/* 0x143d: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1444:
	/* 0x1444: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1447:
	/* 0x1447: jns    1456 <trace_mmap_alert+0x1456> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1447, 0x1456, x86_l_1456);
x86_l_1449:
	/* 0x1449: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_144c:
	/* 0x144c: jns    1477 <trace_mmap_alert+0x1477> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x144c, 0x1477, x86_l_1477);
x86_l_144e:
	/* 0x144e: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1451:
	/* 0x1451: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1454:
	/* 0x1454: jmp    1465 <trace_mmap_alert+0x1465> */
	X86_SIM_X86_JMP(0x1454, 0x1465, x86_l_1465);
x86_l_1456:
	/* 0x1456: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_145b:
	/* 0x145b: call   1460 <trace_mmap_alert+0x1460> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1460:
	/* 0x1460: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1463:
	/* 0x1463: js     147e <trace_mmap_alert+0x147e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1463, 0x147e, x86_l_147e);
x86_l_1465:
	/* 0x1465: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_1468:
	/* 0x1468: mov    WORD PTR [rbp+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_146f:
	/* 0x146f: inc    BYTE PTR [rbp+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RBP, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1475:
	/* 0x1475: jmp    147e <trace_mmap_alert+0x147e> */
	X86_SIM_X86_JMP(0x1475, 0x147e, x86_l_147e);
x86_l_1477:
	/* 0x1477: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_147e:
	/* 0x147e: mov    rbx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_1485:
	/* 0x1485: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1489:
	/* 0x1489: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_148c:
	/* 0x148c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_148f:
	/* 0x148f: jns    14a1 <trace_mmap_alert+0x14a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148f, 0x14a1, x86_l_14a1);
x86_l_1491:
	/* 0x1491: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1494:
	/* 0x1494: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1498:
	/* 0x1498: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_149b:
	/* 0x149b: js     14ad <trace_mmap_alert+0x14ad> */
	X86_SIM_X86_JCC(X86_CC_S, 0x149b, 0x14ad, x86_l_14ad);
x86_l_149d:
	/* 0x149d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_149f:
	/* 0x149f: jmp    14b0 <trace_mmap_alert+0x14b0> */
	X86_SIM_X86_JMP(0x149f, 0x14b0, x86_l_14b0);
x86_l_14a1:
	/* 0x14a1: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14a4:
	/* 0x14a4: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14a8:
	/* 0x14a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14ab:
	/* 0x14ab: jns    149d <trace_mmap_alert+0x149d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14ab, 0x149d, x86_l_149d);
x86_l_14ad:
	/* 0x14ad: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14b0:
	/* 0x14b0: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_14b4:
	/* 0x14b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14b6:
	/* 0x14b6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14b9:
	/* 0x14b9: jns    14ca <trace_mmap_alert+0x14ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14b9, 0x14ca, x86_l_14ca);
x86_l_14bb:
	/* 0x14bb: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14be:
	/* 0x14be: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_14c3:
	/* 0x14c3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14c6:
	/* 0x14c6: js     14d7 <trace_mmap_alert+0x14d7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14c6, 0x14d7, x86_l_14d7);
x86_l_14c8:
	/* 0x14c8: jmp    14d9 <trace_mmap_alert+0x14d9> */
	X86_SIM_X86_JMP(0x14c8, 0x14d9, x86_l_14d9);
x86_l_14ca:
	/* 0x14ca: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14cd:
	/* 0x14cd: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_14d2:
	/* 0x14d2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14d5:
	/* 0x14d5: jns    14d9 <trace_mmap_alert+0x14d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14d5, 0x14d9, x86_l_14d9);
x86_l_14d7:
	/* 0x14d7: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14d9:
	/* 0x14d9: mov    DWORD PTR [rbp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_14dc:
	/* 0x14dc: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14e0:
	/* 0x14e0: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e3:
	/* 0x14e3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e5:
	/* 0x14e5: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14e8:
	/* 0x14e8: jns    14f7 <trace_mmap_alert+0x14f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14e8, 0x14f7, x86_l_14f7);
x86_l_14ea:
	/* 0x14ea: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ed:
	/* 0x14ed: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14f0:
	/* 0x14f0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14f3:
	/* 0x14f3: js     1501 <trace_mmap_alert+0x1501> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14f3, 0x1501, x86_l_1501);
x86_l_14f5:
	/* 0x14f5: jmp    1503 <trace_mmap_alert+0x1503> */
	X86_SIM_X86_JMP(0x14f5, 0x1503, x86_l_1503);
x86_l_14f7:
	/* 0x14f7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14f9:
	/* 0x14f9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14fc:
	/* 0x14fc: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14ff:
	/* 0x14ff: jns    1503 <trace_mmap_alert+0x1503> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14ff, 0x1503, x86_l_1503);
x86_l_1501:
	/* 0x1501: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1503:
	/* 0x1503: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1505:
	/* 0x1505: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1509:
	/* 0x1509: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_150c:
	/* 0x150c: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1510:
	/* 0x1510: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1512:
	/* 0x1512: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1515:
	/* 0x1515: jns    1519 <trace_mmap_alert+0x1519> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1515, 0x1519, x86_l_1519);
x86_l_1517:
	/* 0x1517: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1519:
	/* 0x1519: mov    DWORD PTR [rbp+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_151c:
	/* 0x151c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_151f:
	/* 0x151f: jns    1526 <trace_mmap_alert+0x1526> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x151f, 0x1526, x86_l_1526);
x86_l_1521:
	/* 0x1521: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1524:
	/* 0x1524: jmp    1528 <trace_mmap_alert+0x1528> */
	X86_SIM_X86_JMP(0x1524, 0x1528, x86_l_1528);
x86_l_1526:
	/* 0x1526: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1528:
	/* 0x1528: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_152c:
	/* 0x152c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_152e:
	/* 0x152e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1531:
	/* 0x1531: jns    1540 <trace_mmap_alert+0x1540> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1531, 0x1540, x86_l_1540);
x86_l_1533:
	/* 0x1533: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1536:
	/* 0x1536: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1539:
	/* 0x1539: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_153c:
	/* 0x153c: js     154a <trace_mmap_alert+0x154a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x153c, 0x154a, x86_l_154a);
x86_l_153e:
	/* 0x153e: jmp    154c <trace_mmap_alert+0x154c> */
	X86_SIM_X86_JMP(0x153e, 0x154c, x86_l_154c);
x86_l_1540:
	/* 0x1540: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1542:
	/* 0x1542: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1545:
	/* 0x1545: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1548:
	/* 0x1548: jns    154c <trace_mmap_alert+0x154c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1548, 0x154c, x86_l_154c);
x86_l_154a:
	/* 0x154a: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154c:
	/* 0x154c: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_154e:
	/* 0x154e: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1552:
	/* 0x1552: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1555:
	/* 0x1555: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1559:
	/* 0x1559: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_155b:
	/* 0x155b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_155e:
	/* 0x155e: jns    1562 <trace_mmap_alert+0x1562> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x155e, 0x1562, x86_l_1562);
x86_l_1560:
	/* 0x1560: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1562:
	/* 0x1562: mov    DWORD PTR [rbp+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1565:
	/* 0x1565: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1567:
	/* 0x1567: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_156a:
	/* 0x156a: jns    1579 <trace_mmap_alert+0x1579> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156a, 0x1579, x86_l_1579);
x86_l_156c:
	/* 0x156c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_156f:
	/* 0x156f: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1572:
	/* 0x1572: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1575:
	/* 0x1575: js     1583 <trace_mmap_alert+0x1583> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1575, 0x1583, x86_l_1583);
x86_l_1577:
	/* 0x1577: jmp    1585 <trace_mmap_alert+0x1585> */
	X86_SIM_X86_JMP(0x1577, 0x1585, x86_l_1585);
x86_l_1579:
	/* 0x1579: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157b:
	/* 0x157b: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1581:
	/* 0x1581: jns    1585 <trace_mmap_alert+0x1585> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1581, 0x1585, x86_l_1585);
x86_l_1583:
	/* 0x1583: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1585:
	/* 0x1585: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1587:
	/* 0x1587: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_158b:
	/* 0x158b: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_158e:
	/* 0x158e: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1592:
	/* 0x1592: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1594:
	/* 0x1594: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1597:
	/* 0x1597: jns    15a7 <trace_mmap_alert+0x15a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1597, 0x15a7, x86_l_15a7);
x86_l_1599:
	/* 0x1599: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_159c:
	/* 0x159c: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_15a0:
	/* 0x15a0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15a3:
	/* 0x15a3: js     15b2 <trace_mmap_alert+0x15b2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15a3, 0x15b2, x86_l_15b2);
x86_l_15a5:
	/* 0x15a5: jmp    15b4 <trace_mmap_alert+0x15b4> */
	X86_SIM_X86_JMP(0x15a5, 0x15b4, x86_l_15b4);
x86_l_15a7:
	/* 0x15a7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a9:
	/* 0x15a9: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_15ad:
	/* 0x15ad: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15b0:
	/* 0x15b0: jns    15b4 <trace_mmap_alert+0x15b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15b0, 0x15b4, x86_l_15b4);
x86_l_15b2:
	/* 0x15b2: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b4:
	/* 0x15b4: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15b9:
	/* 0x15b9: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15bc:
	/* 0x15bc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15be:
	/* 0x15be: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15c1:
	/* 0x15c1: jns    15d0 <trace_mmap_alert+0x15d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c1, 0x15d0, x86_l_15d0);
x86_l_15c3:
	/* 0x15c3: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15c6:
	/* 0x15c6: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15c9:
	/* 0x15c9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15cc:
	/* 0x15cc: js     15da <trace_mmap_alert+0x15da> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15cc, 0x15da, x86_l_15da);
x86_l_15ce:
	/* 0x15ce: jmp    15dc <trace_mmap_alert+0x15dc> */
	X86_SIM_X86_JMP(0x15ce, 0x15dc, x86_l_15dc);
x86_l_15d0:
	/* 0x15d0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15d2:
	/* 0x15d2: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15d5:
	/* 0x15d5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15d8:
	/* 0x15d8: jns    15dc <trace_mmap_alert+0x15dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15d8, 0x15dc, x86_l_15dc);
x86_l_15da:
	/* 0x15da: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15dc:
	/* 0x15dc: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_15de:
	/* 0x15de: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15e2:
	/* 0x15e2: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15e5:
	/* 0x15e5: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15e9:
	/* 0x15e9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15eb:
	/* 0x15eb: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15ee:
	/* 0x15ee: jns    15fe <trace_mmap_alert+0x15fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ee, 0x15fe, x86_l_15fe);
x86_l_15f0:
	/* 0x15f0: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15f3:
	/* 0x15f3: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_15f7:
	/* 0x15f7: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: js     1609 <trace_mmap_alert+0x1609> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15fa, 0x1609, x86_l_1609);
x86_l_15fc:
	/* 0x15fc: jmp    160b <trace_mmap_alert+0x160b> */
	X86_SIM_X86_JMP(0x15fc, 0x160b, x86_l_160b);
x86_l_15fe:
	/* 0x15fe: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1600:
	/* 0x1600: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1604:
	/* 0x1604: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1607:
	/* 0x1607: jns    160b <trace_mmap_alert+0x160b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1607, 0x160b, x86_l_160b);
x86_l_1609:
	/* 0x1609: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160b:
	/* 0x160b: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_160d:
	/* 0x160d: jne    1640 <trace_mmap_alert+0x1640> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x160d, 0x1640, x86_l_1640);
x86_l_160f:
	/* 0x160f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1611:
	/* 0x1611: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1614:
	/* 0x1614: jns    161b <trace_mmap_alert+0x161b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1614, 0x161b, x86_l_161b);
x86_l_1616:
	/* 0x1616: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1619:
	/* 0x1619: jmp    161d <trace_mmap_alert+0x161d> */
	X86_SIM_X86_JMP(0x1619, 0x161d, x86_l_161d);
x86_l_161b:
	/* 0x161b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_161d:
	/* 0x161d: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1620:
	/* 0x1620: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1623:
	/* 0x1623: jns    1627 <trace_mmap_alert+0x1627> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1623, 0x1627, x86_l_1627);
x86_l_1625:
	/* 0x1625: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1627:
	/* 0x1627: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1629:
	/* 0x1629: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_162d:
	/* 0x162d: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1630:
	/* 0x1630: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1634:
	/* 0x1634: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1636:
	/* 0x1636: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1639:
	/* 0x1639: jns    163d <trace_mmap_alert+0x163d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1639, 0x163d, x86_l_163d);
x86_l_163b:
	/* 0x163b: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_163d:
	/* 0x163d: mov    DWORD PTR [rbp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1640:
	/* 0x1640: mov    DWORD PTR [rbp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1643:
	/* 0x1643: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_164a:
	/* 0x164a: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_164d:
	/* 0x164d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1650:
	/* 0x1650: jns    1657 <trace_mmap_alert+0x1657> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1650, 0x1657, x86_l_1657);
x86_l_1652:
	/* 0x1652: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1655:
	/* 0x1655: jmp    1659 <trace_mmap_alert+0x1659> */
	X86_SIM_X86_JMP(0x1655, 0x1659, x86_l_1659);
x86_l_1657:
	/* 0x1657: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1659:
	/* 0x1659: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_165d:
	/* 0x165d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_165f:
	/* 0x165f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1662:
	/* 0x1662: jns    166e <trace_mmap_alert+0x166e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1662, 0x166e, x86_l_166e);
x86_l_1664:
	/* 0x1664: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1667:
	/* 0x1667: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_166a:
	/* 0x166a: js     1675 <trace_mmap_alert+0x1675> */
	X86_SIM_X86_JCC(X86_CC_S, 0x166a, 0x1675, x86_l_1675);
x86_l_166c:
	/* 0x166c: jmp    1677 <trace_mmap_alert+0x1677> */
	X86_SIM_X86_JMP(0x166c, 0x1677, x86_l_1677);
x86_l_166e:
	/* 0x166e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1670:
	/* 0x1670: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1673:
	/* 0x1673: jns    1677 <trace_mmap_alert+0x1677> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1673, 0x1677, x86_l_1677);
x86_l_1675:
	/* 0x1675: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1677:
	/* 0x1677: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_167c:
	/* 0x167c: lea    rbp,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1680:
	/* 0x1680: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1685:
	/* 0x1685: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1689:
	/* 0x1689: call   168e <trace_mmap_alert+0x168e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_168e:
	/* 0x168e: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1692:
	/* 0x1692: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1696:
	/* 0x1696: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1699:
	/* 0x1699: jns    16a0 <trace_mmap_alert+0x16a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1699, 0x16a0, x86_l_16a0);
x86_l_169b:
	/* 0x169b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_169e:
	/* 0x169e: jmp    16a2 <trace_mmap_alert+0x16a2> */
	X86_SIM_X86_JMP(0x169e, 0x16a2, x86_l_16a2);
x86_l_16a0:
	/* 0x16a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a2:
	/* 0x16a2: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a6:
	/* 0x16a6: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_16aa:
	/* 0x16aa: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_16ad:
	/* 0x16ad: jns    16b4 <trace_mmap_alert+0x16b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ad, 0x16b4, x86_l_16b4);
x86_l_16af:
	/* 0x16af: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16b2:
	/* 0x16b2: jmp    16b6 <trace_mmap_alert+0x16b6> */
	X86_SIM_X86_JMP(0x16b2, 0x16b6, x86_l_16b6);
x86_l_16b4:
	/* 0x16b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16b6:
	/* 0x16b6: mov    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_16bb:
	/* 0x16bb: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16c0:
	/* 0x16c0: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_16c4:
	/* 0x16c4: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_16c8:
	/* 0x16c8: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_16cb:
	/* 0x16cb: jns    16d3 <trace_mmap_alert+0x16d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16cb, 0x16d3, x86_l_16d3);
x86_l_16cd:
	/* 0x16cd: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16d1:
	/* 0x16d1: jmp    16d5 <trace_mmap_alert+0x16d5> */
	X86_SIM_X86_JMP(0x16d1, 0x16d5, x86_l_16d5);
x86_l_16d3:
	/* 0x16d3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d5:
	/* 0x16d5: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16da:
	/* 0x16da: mov    QWORD PTR [rcx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_16de:
	/* 0x16de: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_16e1:
	/* 0x16e1: jns    16ed <trace_mmap_alert+0x16ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e1, 0x16ed, x86_l_16ed);
x86_l_16e3:
	/* 0x16e3: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e5:
	/* 0x16e5: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_16e7:
	/* 0x16e7: je     16ed <trace_mmap_alert+0x16ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e7, 0x16ed, x86_l_16ed);
x86_l_16e9:
	/* 0x16e9: or     BYTE PTR [rcx+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_16ed:
	/* 0x16ed: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16f2:
	/* 0x16f2: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_16f6:
	/* 0x16f6: mov    QWORD PTR [rcx+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_16fe:
	/* 0x16fe: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_1706:
	/* 0x1706: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_170b:
	/* 0x170b: call   1710 <trace_mmap_alert+0x1710> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_1710:
	/* 0x1710: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1713:
	/* 0x1713: jns    171b <trace_mmap_alert+0x171b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1713, 0x171b, x86_l_171b);
x86_l_1715:
	/* 0x1715: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1719:
	/* 0x1719: jmp    171d <trace_mmap_alert+0x171d> */
	X86_SIM_X86_JMP(0x1719, 0x171d, x86_l_171d);
x86_l_171b:
	/* 0x171b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_171d:
	/* 0x171d: mov    rbx,QWORD PTR [rsp+0x110] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 272ULL);
x86_l_1725:
	/* 0x1725: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1728:
	/* 0x1728: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_172d:
	/* 0x172d: jns    1739 <trace_mmap_alert+0x1739> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x172d, 0x1739, x86_l_1739);
x86_l_172f:
	/* 0x172f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1732:
	/* 0x1732: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1735:
	/* 0x1735: js     1740 <trace_mmap_alert+0x1740> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1735, 0x1740, x86_l_1740);
x86_l_1737:
	/* 0x1737: jmp    1793 <trace_mmap_alert+0x1793> */
	X86_SIM_X86_JMP(0x1737, 0x1793, x86_l_1793);
x86_l_1739:
	/* 0x1739: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_173b:
	/* 0x173b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_173e:
	/* 0x173e: jns    1793 <trace_mmap_alert+0x1793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x173e, 0x1793, x86_l_1793);
x86_l_1740:
	/* 0x1740: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1743:
	/* 0x1743: mov    QWORD PTR [rsp+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_174b:
	/* 0x174b: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_174f:
	/* 0x174f: mov    QWORD PTR [rsp+0xc8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1757:
	/* 0x1757: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_175b:
	/* 0x175b: mov    QWORD PTR [rsp+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1763:
	/* 0x1763: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1767:
	/* 0x1767: mov    QWORD PTR [rsp+0xd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_176f:
	/* 0x176f: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1773:
	/* 0x1773: mov    QWORD PTR [rsp+0xe0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_177b:
	/* 0x177b: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_177f:
	/* 0x177f: mov    QWORD PTR [rsp+0xe8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1787:
	/* 0x1787: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_178b:
	/* 0x178b: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_178f:
	/* 0x178f: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1793:
	/* 0x1793: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_1797:
	/* 0x1797: lea    rax,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_179f:
	/* 0x179f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17a2:
	/* 0x17a2: jns    18bc <trace_mmap_alert+0x18bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17a2, 0x18bc, x86_l_18bc);
x86_l_17a8:
	/* 0x17a8: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_17ab:
	/* 0x17ab: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ad:
	/* 0x17ad: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_17af:
	/* 0x17af: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17af, 0x18cb, x86_l_18cb);
x86_l_17b5:
	/* 0x17b5: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_17b9:
	/* 0x17b9: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17be:
	/* 0x17be: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_17c1:
	/* 0x17c1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_17c3:
	/* 0x17c3: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17c3, 0x18cb, x86_l_18cb);
x86_l_17c9:
	/* 0x17c9: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_17cd:
	/* 0x17cd: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d2:
	/* 0x17d2: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_17d5:
	/* 0x17d5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_17d7:
	/* 0x17d7: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17d7, 0x18cb, x86_l_18cb);
x86_l_17dd:
	/* 0x17dd: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_17e1:
	/* 0x17e1: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17e6:
	/* 0x17e6: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_17e9:
	/* 0x17e9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_17eb:
	/* 0x17eb: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17eb, 0x18cb, x86_l_18cb);
x86_l_17f1:
	/* 0x17f1: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_17f5:
	/* 0x17f5: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17fa:
	/* 0x17fa: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_17fd:
	/* 0x17fd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_17ff:
	/* 0x17ff: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ff, 0x18cb, x86_l_18cb);
x86_l_1805:
	/* 0x1805: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1809:
	/* 0x1809: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_180e:
	/* 0x180e: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1811:
	/* 0x1811: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1813:
	/* 0x1813: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1813, 0x18cb, x86_l_18cb);
x86_l_1819:
	/* 0x1819: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_181d:
	/* 0x181d: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1822:
	/* 0x1822: mov    BYTE PTR [rdx+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1825:
	/* 0x1825: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1827:
	/* 0x1827: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1827, 0x18cb, x86_l_18cb);
x86_l_182d:
	/* 0x182d: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_1831:
	/* 0x1831: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1836:
	/* 0x1836: mov    BYTE PTR [rdx+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_1839:
	/* 0x1839: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_183b:
	/* 0x183b: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x183b, 0x18cb, x86_l_18cb);
x86_l_1841:
	/* 0x1841: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1845:
	/* 0x1845: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_184a:
	/* 0x184a: mov    BYTE PTR [rdx+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_184d:
	/* 0x184d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_184f:
	/* 0x184f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x184f, 0x18cb, x86_l_18cb);
x86_l_1851:
	/* 0x1851: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1855:
	/* 0x1855: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_185a:
	/* 0x185a: mov    BYTE PTR [rdx+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_185d:
	/* 0x185d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_185f:
	/* 0x185f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x185f, 0x18cb, x86_l_18cb);
x86_l_1861:
	/* 0x1861: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_1865:
	/* 0x1865: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_186a:
	/* 0x186a: mov    BYTE PTR [rdx+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_186d:
	/* 0x186d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_186f:
	/* 0x186f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x186f, 0x18cb, x86_l_18cb);
x86_l_1871:
	/* 0x1871: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1875:
	/* 0x1875: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_187a:
	/* 0x187a: mov    BYTE PTR [rdx+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_187d:
	/* 0x187d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_187f:
	/* 0x187f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x187f, 0x18cb, x86_l_18cb);
x86_l_1881:
	/* 0x1881: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1885:
	/* 0x1885: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_188a:
	/* 0x188a: mov    BYTE PTR [rdx+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_188d:
	/* 0x188d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_188f:
	/* 0x188f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x188f, 0x18cb, x86_l_18cb);
x86_l_1891:
	/* 0x1891: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1895:
	/* 0x1895: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_189a:
	/* 0x189a: mov    BYTE PTR [rdx+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_189d:
	/* 0x189d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_189f:
	/* 0x189f: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x189f, 0x18cb, x86_l_18cb);
x86_l_18a1:
	/* 0x18a1: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_18a5:
	/* 0x18a5: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18aa:
	/* 0x18aa: mov    BYTE PTR [rcx+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_18ad:
	/* 0x18ad: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_18af:
	/* 0x18af: je     18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18af, 0x18cb, x86_l_18cb);
x86_l_18b1:
	/* 0x18b1: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18b6:
	/* 0x18b6: mov    BYTE PTR [rax+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_18ba:
	/* 0x18ba: jmp    18cb <trace_mmap_alert+0x18cb> */
	X86_SIM_X86_JMP(0x18ba, 0x18cb, x86_l_18cb);
x86_l_18bc:
	/* 0x18bc: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_18c4:
	/* 0x18c4: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18cb:
	/* 0x18cb: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_18ce:
	/* 0x18ce: jns    1955 <trace_mmap_alert+0x1955> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18ce, 0x1955, x86_l_1955);
x86_l_18d4:
	/* 0x18d4: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d8:
	/* 0x18d8: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18dd:
	/* 0x18dd: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18e0:
	/* 0x18e0: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18e4:
	/* 0x18e4: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18e8:
	/* 0x18e8: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18ec:
	/* 0x18ec: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18f0:
	/* 0x18f0: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18f4:
	/* 0x18f4: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18f8:
	/* 0x18f8: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18fc:
	/* 0x18fc: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1900:
	/* 0x1900: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1904:
	/* 0x1904: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1908:
	/* 0x1908: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_190c:
	/* 0x190c: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1910:
	/* 0x1910: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1914:
	/* 0x1914: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1918:
	/* 0x1918: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_191c:
	/* 0x191c: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1920:
	/* 0x1920: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1924:
	/* 0x1924: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1928:
	/* 0x1928: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_192c:
	/* 0x192c: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1930:
	/* 0x1930: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1934:
	/* 0x1934: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1938:
	/* 0x1938: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_193c:
	/* 0x193c: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1940:
	/* 0x1940: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1945:
	/* 0x1945: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_194a:
	/* 0x194a: jne    19cd <trace_mmap_alert+0x19cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x194a, 0x19cd, x86_l_19cd);
x86_l_1950:
	/* 0x1950: jmp    19e9 <trace_mmap_alert+0x19e9> */
	X86_SIM_X86_JMP(0x1950, 0x19e9, x86_l_19e9);
x86_l_1955:
	/* 0x1955: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_195a:
	/* 0x195a: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1962:
	/* 0x1962: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_196a:
	/* 0x196a: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1972:
	/* 0x1972: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_197a:
	/* 0x197a: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1982:
	/* 0x1982: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_198a:
	/* 0x198a: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1992:
	/* 0x1992: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_199a:
	/* 0x199a: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_19a2:
	/* 0x19a2: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_19aa:
	/* 0x19aa: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_19b2:
	/* 0x19b2: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_19ba:
	/* 0x19ba: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19c1:
	/* 0x19c1: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19c6:
	/* 0x19c6: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_19cb:
	/* 0x19cb: je     19e9 <trace_mmap_alert+0x19e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19cb, 0x19e9, x86_l_19e9);
x86_l_19cd:
	/* 0x19cd: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_19d4:
	/* 0x19d4: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_19d9:
	/* 0x19d9: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19dc:
	/* 0x19dc: call   19e1 <trace_mmap_alert+0x19e1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_19e1:
	/* 0x19e1: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_19e3:
	/* 0x19e3: js     19e9 <trace_mmap_alert+0x19e9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19e3, 0x19e9, x86_l_19e9);
x86_l_19e5:
	/* 0x19e5: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_19e9:
	/* 0x19e9: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_19f1:
	/* 0x19f1: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_19f6:
	/* 0x19f6: jb     19fd <trace_mmap_alert+0x19fd> */
	X86_SIM_X86_JCC(X86_CC_B, 0x19f6, 0x19fd, x86_l_19fd);
x86_l_19f8:
	/* 0x19f8: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_19fd:
	/* 0x19fd: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_1a02:
	/* 0x1a02: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1a06:
	/* 0x1a06: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_1a0d:
	/* 0x1a0d: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1a12:
	/* 0x1a12: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a15:
	/* 0x1a15: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1a18:
	/* 0x1a18: call   1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_1a1d:
	/* 0x1a1d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a1f:
	/* 0x1a1f: add    rsp,0x118 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 280ULL);
x86_l_1a26:
	/* 0x1a26: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a27:
	/* 0x1a27: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a29:
	/* 0x1a29: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a2b:
	/* 0x1a2b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a2d:
	/* 0x1a2d: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a2f:
	/* 0x1a2f: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1a30:
	/* 0x1a30: jmp    3954 <trace_mmap_alert+0x3954> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1a35:
	/* 0x1a35: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a38:
	/* 0x1a38: jmp    37b1 <trace_mmap_alert+0x37b1> */
	X86_SIM_X86_JMP(0x1a38, 0x37b1, x86_l_37b1);
x86_l_1a3d:
	/* 0x1a3d: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a3f:
	/* 0x1a3f: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a42:
	/* 0x1a42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a45:
	/* 0x1a45: jns    1a51 <trace_mmap_alert+0x1a51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a45, 0x1a51, x86_l_1a51);
x86_l_1a47:
	/* 0x1a47: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a49:
	/* 0x1a49: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_1a4b:
	/* 0x1a4b: jne    1b42 <trace_mmap_alert+0x1b42> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a4b, 0x1b42, x86_l_1b42);
x86_l_1a51:
	/* 0x1a51: lea    rax,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a55:
	/* 0x1a55: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a58:
	/* 0x1a58: jns    1a5f <trace_mmap_alert+0x1a5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a58, 0x1a5f, x86_l_1a5f);
x86_l_1a5a:
	/* 0x1a5a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a5d:
	/* 0x1a5d: jmp    1a61 <trace_mmap_alert+0x1a61> */
	X86_SIM_X86_JMP(0x1a5d, 0x1a61, x86_l_1a61);
x86_l_1a5f:
	/* 0x1a5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a61:
	/* 0x1a61: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_1a65:
	/* 0x1a65: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a68:
	/* 0x1a68: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a6b:
	/* 0x1a6b: jns    1a72 <trace_mmap_alert+0x1a72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a6b, 0x1a72, x86_l_1a72);
x86_l_1a6d:
	/* 0x1a6d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a70:
	/* 0x1a70: jmp    1a74 <trace_mmap_alert+0x1a74> */
	X86_SIM_X86_JMP(0x1a70, 0x1a74, x86_l_1a74);
x86_l_1a72:
	/* 0x1a72: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a74:
	/* 0x1a74: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a77:
	/* 0x1a77: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a7a:
	/* 0x1a7a: jns    1a81 <trace_mmap_alert+0x1a81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a7a, 0x1a81, x86_l_1a81);
x86_l_1a7c:
	/* 0x1a7c: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a7f:
	/* 0x1a7f: jmp    1a83 <trace_mmap_alert+0x1a83> */
	X86_SIM_X86_JMP(0x1a7f, 0x1a83, x86_l_1a83);
x86_l_1a81:
	/* 0x1a81: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a83:
	/* 0x1a83: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a87:
	/* 0x1a87: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a8a:
	/* 0x1a8a: jns    1a91 <trace_mmap_alert+0x1a91> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a8a, 0x1a91, x86_l_1a91);
x86_l_1a8c:
	/* 0x1a8c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a8f:
	/* 0x1a8f: jmp    1a93 <trace_mmap_alert+0x1a93> */
	X86_SIM_X86_JMP(0x1a8f, 0x1a93, x86_l_1a93);
x86_l_1a91:
	/* 0x1a91: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a93:
	/* 0x1a93: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a96:
	/* 0x1a96: je     1b1b <trace_mmap_alert+0x1b1b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a96, 0x1b1b, x86_l_1b1b);
x86_l_1a9c:
	/* 0x1a9c: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a9f:
	/* 0x1a9f: je     1b1b <trace_mmap_alert+0x1b1b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a9f, 0x1b1b, x86_l_1b1b);
x86_l_1aa1:
	/* 0x1aa1: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1aa5:
	/* 0x1aa5: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aa8:
	/* 0x1aa8: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1aae:
	/* 0x1aae: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ab1:
	/* 0x1ab1: jns    1aba <trace_mmap_alert+0x1aba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ab1, 0x1aba, x86_l_1aba);
x86_l_1ab3:
	/* 0x1ab3: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab6:
	/* 0x1ab6: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aba:
	/* 0x1aba: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1abe:
	/* 0x1abe: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1ac1:
	/* 0x1ac1: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1ac8:
	/* 0x1ac8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1acb:
	/* 0x1acb: je     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1acb, 0x36d6, x86_l_36d6);
x86_l_1ad1:
	/* 0x1ad1: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1ad4:
	/* 0x1ad4: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_1ad6:
	/* 0x1ad6: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1adc:
	/* 0x1adc: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1adf:
	/* 0x1adf: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1ae5:
	/* 0x1ae5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1ae8:
	/* 0x1ae8: jns    3501 <trace_mmap_alert+0x3501> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ae8, 0x3501, x86_l_3501);
x86_l_1aee:
	/* 0x1aee: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1af2:
	/* 0x1af2: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1af5:
	/* 0x1af5: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1af8:
	/* 0x1af8: je     2024 <trace_mmap_alert+0x2024> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1af8, 0x2024, x86_l_2024);
x86_l_1afe:
	/* 0x1afe: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b02:
	/* 0x1b02: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b07:
	/* 0x1b07: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b0b:
	/* 0x1b0b: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1b0e:
	/* 0x1b0e: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_1b11:
	/* 0x1b11: jne    1af5 <trace_mmap_alert+0x1af5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b11, 0x1af5, x86_l_1af5);
x86_l_1b13:
	/* 0x1b13: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b16:
	/* 0x1b16: jmp    2029 <trace_mmap_alert+0x2029> */
	X86_SIM_X86_JMP(0x1b16, 0x2029, x86_l_2029);
x86_l_1b1b:
	/* 0x1b1b: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b1e:
	/* 0x1b1e: jne    36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b1e, 0x36d6, x86_l_36d6);
x86_l_1b24:
	/* 0x1b24: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b27:
	/* 0x1b27: je     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b27, 0x36d6, x86_l_36d6);
x86_l_1b2d:
	/* 0x1b2d: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_1b31:
	/* 0x1b31: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b34:
	/* 0x1b34: jns    1e81 <trace_mmap_alert+0x1e81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b34, 0x1e81, x86_l_1e81);
x86_l_1b3a:
	/* 0x1b3a: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b3d:
	/* 0x1b3d: jmp    1e83 <trace_mmap_alert+0x1e83> */
	X86_SIM_X86_JMP(0x1b3d, 0x1e83, x86_l_1e83);
x86_l_1b42:
	/* 0x1b42: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1b49:
	/* 0x1b49: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b4c:
	/* 0x1b4c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b4f:
	/* 0x1b4f: jns    1e6d <trace_mmap_alert+0x1e6d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b4f, 0x1e6d, x86_l_1e6d);
x86_l_1b55:
	/* 0x1b55: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b57:
	/* 0x1b57: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b5c:
	/* 0x1b5c: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1b63:
	/* 0x1b63: je     372b <trace_mmap_alert+0x372b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b63, 0x372b, x86_l_372b);
x86_l_1b69:
	/* 0x1b69: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1b6d:
	/* 0x1b6d: mov    BYTE PTR [r12+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1b71:
	/* 0x1b71: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1b74:
	/* 0x1b74: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1b76:
	/* 0x1b76: jne    1b5c <trace_mmap_alert+0x1b5c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b76, 0x1b5c, x86_l_1b5c);
x86_l_1b78:
	/* 0x1b78: jmp    37a7 <trace_mmap_alert+0x37a7> */
	X86_SIM_X86_JMP(0x1b78, 0x37a7, x86_l_37a7);
x86_l_1b7d:
	/* 0x1b7d: mov    eax,DWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1b84:
	/* 0x1b84: mov    DWORD PTR [rsp+0xc0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1b8b:
	/* 0x1b8b: mov    DWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_1b96:
	/* 0x1b96: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1b9d:
	/* 0x1b9d: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1ba5:
	/* 0x1ba5: call   1baa <trace_mmap_alert+0x1baa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1baa:
	/* 0x1baa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bad:
	/* 0x1bad: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bad, 0x1a1d, x86_l_1a1d);
x86_l_1bb3:
	/* 0x1bb3: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bb6:
	/* 0x1bb6: mov    eax,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1bbd:
	/* 0x1bbd: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bc1:
	/* 0x1bc1: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1bc6:
	/* 0x1bc6: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bc9:
	/* 0x1bc9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bcb:
	/* 0x1bcb: call   1bd0 <trace_mmap_alert+0x1bd0> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_1bd0:
	/* 0x1bd0: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1bd7:
	/* 0x1bd7: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bdc:
	/* 0x1bdc: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1be1:
	/* 0x1be1: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1be4:
	/* 0x1be4: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1be7:
	/* 0x1be7: call   1bec <trace_mmap_alert+0x1bec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1bec:
	/* 0x1bec: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1bf4:
	/* 0x1bf4: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1bf7:
	/* 0x1bf7: call   1bfc <trace_mmap_alert+0x1bfc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1bfc:
	/* 0x1bfc: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1c04:
	/* 0x1c04: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c07:
	/* 0x1c07: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0c:
	/* 0x1c0c: jne    208 <trace_mmap_alert+0x208> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c0c, 0x208, x86_l_208);
x86_l_1c12:
	/* 0x1c12: jmp    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JMP(0x1c12, 0x1a1d, x86_l_1a1d);
x86_l_1c17:
	/* 0x1c17: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c1b:
	/* 0x1c1b: mov    DWORD PTR [rsp+0xc0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1c22:
	/* 0x1c22: mov    DWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_1c2d:
	/* 0x1c2d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1c34:
	/* 0x1c34: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1c3c:
	/* 0x1c3c: call   1c41 <trace_mmap_alert+0x1c41> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c41:
	/* 0x1c41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c44:
	/* 0x1c44: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c44, 0x1a1d, x86_l_1a1d);
x86_l_1c4a:
	/* 0x1c4a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c4d:
	/* 0x1c4d: mov    eax,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1c54:
	/* 0x1c54: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c58:
	/* 0x1c58: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_1c5d:
	/* 0x1c5d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c60:
	/* 0x1c60: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c62:
	/* 0x1c62: call   1c67 <trace_mmap_alert+0x1c67> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_1c67:
	/* 0x1c67: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_1c6e:
	/* 0x1c6e: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c73:
	/* 0x1c73: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1c78:
	/* 0x1c78: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c7b:
	/* 0x1c7b: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c7e:
	/* 0x1c7e: call   1c83 <trace_mmap_alert+0x1c83> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1c83:
	/* 0x1c83: lea    rsi,[rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1c8b:
	/* 0x1c8b: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c8e:
	/* 0x1c8e: call   1c93 <trace_mmap_alert+0x1c93> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c93:
	/* 0x1c93: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c96:
	/* 0x1c96: je     1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c96, 0x1a1d, x86_l_1a1d);
x86_l_1c9c:
	/* 0x1c9c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ca1:
	/* 0x1ca1: mov    rbx,QWORD PTR [rbp+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_1ca8:
	/* 0x1ca8: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1cac:
	/* 0x1cac: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1caf:
	/* 0x1caf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cb2:
	/* 0x1cb2: jns    1ec8 <trace_mmap_alert+0x1ec8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb2, 0x1ec8, x86_l_1ec8);
x86_l_1cb8:
	/* 0x1cb8: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cbb:
	/* 0x1cbb: jmp    1ecb <trace_mmap_alert+0x1ecb> */
	X86_SIM_X86_JMP(0x1cbb, 0x1ecb, x86_l_1ecb);
x86_l_1cc0:
	/* 0x1cc0: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1cc3:
	/* 0x1cc3: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1cc7:
	/* 0x1cc7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cca:
	/* 0x1cca: jns    1ead <trace_mmap_alert+0x1ead> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cca, 0x1ead, x86_l_1ead);
x86_l_1cd0:
	/* 0x1cd0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd3:
	/* 0x1cd3: mov    QWORD PTR [rbp+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1cda:
	/* 0x1cda: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cde:
	/* 0x1cde: mov    QWORD PTR [rbp+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1ce5:
	/* 0x1ce5: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ce9:
	/* 0x1ce9: mov    QWORD PTR [rbp+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1cf0:
	/* 0x1cf0: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cf4:
	/* 0x1cf4: mov    QWORD PTR [rbp+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1cfb:
	/* 0x1cfb: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1cff:
	/* 0x1cff: mov    QWORD PTR [rbp+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_1d06:
	/* 0x1d06: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d0a:
	/* 0x1d0a: mov    QWORD PTR [rbp+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1d11:
	/* 0x1d11: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d15:
	/* 0x1d15: mov    QWORD PTR [rbp+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1d1c:
	/* 0x1d1c: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1d20:
	/* 0x1d20: mov    QWORD PTR [rbp+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_1d27:
	/* 0x1d27: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1d2b:
	/* 0x1d2b: mov    QWORD PTR [rbp+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1d32:
	/* 0x1d32: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1d36:
	/* 0x1d36: mov    QWORD PTR [rbp+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1d3d:
	/* 0x1d3d: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1d41:
	/* 0x1d41: mov    QWORD PTR [rbp+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_1d48:
	/* 0x1d48: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1d4c:
	/* 0x1d4c: mov    QWORD PTR [rbp+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1d53:
	/* 0x1d53: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1d57:
	/* 0x1d57: mov    QWORD PTR [rbp+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_1d5e:
	/* 0x1d5e: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1d62:
	/* 0x1d62: mov    QWORD PTR [rbp+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1d69:
	/* 0x1d69: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1d6d:
	/* 0x1d6d: mov    QWORD PTR [rbp+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1d74:
	/* 0x1d74: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1d78:
	/* 0x1d78: mov    QWORD PTR [rbp+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_1d7f:
	/* 0x1d7f: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1d86:
	/* 0x1d86: mov    QWORD PTR [rbp+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_1d8d:
	/* 0x1d8d: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1d94:
	/* 0x1d94: mov    QWORD PTR [rbp+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1d9b:
	/* 0x1d9b: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1da2:
	/* 0x1da2: mov    QWORD PTR [rbp+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_1da9:
	/* 0x1da9: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1db0:
	/* 0x1db0: mov    QWORD PTR [rbp+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1db7:
	/* 0x1db7: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1dbe:
	/* 0x1dbe: mov    QWORD PTR [rbp+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1dc5:
	/* 0x1dc5: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1dcc:
	/* 0x1dcc: mov    QWORD PTR [rbp+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1dd3:
	/* 0x1dd3: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1dda:
	/* 0x1dda: mov    QWORD PTR [rbp+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1de1:
	/* 0x1de1: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1de8:
	/* 0x1de8: mov    QWORD PTR [rbp+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1def:
	/* 0x1def: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1df6:
	/* 0x1df6: mov    QWORD PTR [rbp+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1dfd:
	/* 0x1dfd: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1e04:
	/* 0x1e04: mov    QWORD PTR [rbp+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1e0b:
	/* 0x1e0b: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1e12:
	/* 0x1e12: mov    QWORD PTR [rbp+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_1e19:
	/* 0x1e19: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1e20:
	/* 0x1e20: mov    QWORD PTR [rbp+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_1e27:
	/* 0x1e27: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1e2e:
	/* 0x1e2e: mov    QWORD PTR [rbp+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1e35:
	/* 0x1e35: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1e3c:
	/* 0x1e3c: mov    QWORD PTR [rbp+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1e43:
	/* 0x1e43: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1e4a:
	/* 0x1e4a: mov    QWORD PTR [rbp+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1e51:
	/* 0x1e51: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1e58:
	/* 0x1e58: mov    QWORD PTR [rbp+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_1e5f:
	/* 0x1e5f: movzx  eax,WORD PTR [r14+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1e64:
	/* 0x1e64: mov    WORD PTR [rbp+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1e68:
	/* 0x1e68: jmp    2e9 <trace_mmap_alert+0x2e9> */
	X86_SIM_X86_JMP(0x1e68, 0x2e9, x86_l_2e9);
x86_l_1e6d:
	/* 0x1e6d: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1e72:
	/* 0x1e72: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e75:
	/* 0x1e75: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e77:
	/* 0x1e77: call   1e7c <trace_mmap_alert+0x1e7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_1e7c:
	/* 0x1e7c: jmp    37a2 <trace_mmap_alert+0x37a2> */
	X86_SIM_X86_JMP(0x1e7c, 0x37a2, x86_l_37a2);
x86_l_1e81:
	/* 0x1e81: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e83:
	/* 0x1e83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e86:
	/* 0x1e86: jns    1e8d <trace_mmap_alert+0x1e8d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e86, 0x1e8d, x86_l_1e8d);
x86_l_1e88:
	/* 0x1e88: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8b:
	/* 0x1e8b: jmp    1e8f <trace_mmap_alert+0x1e8f> */
	X86_SIM_X86_JMP(0x1e8b, 0x1e8f, x86_l_1e8f);
x86_l_1e8d:
	/* 0x1e8d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e8f:
	/* 0x1e8f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e92:
	/* 0x1e92: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e95:
	/* 0x1e95: jns    1e9c <trace_mmap_alert+0x1e9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e95, 0x1e9c, x86_l_1e9c);
x86_l_1e97:
	/* 0x1e97: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e9a:
	/* 0x1e9a: jmp    1e9e <trace_mmap_alert+0x1e9e> */
	X86_SIM_X86_JMP(0x1e9a, 0x1e9e, x86_l_1e9e);
x86_l_1e9c:
	/* 0x1e9c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e9e:
	/* 0x1e9e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ea2:
	/* 0x1ea2: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1ea8:
	/* 0x1ea8: jmp    2045 <trace_mmap_alert+0x2045> */
	X86_SIM_X86_JMP(0x1ea8, 0x2045, x86_l_2045);
x86_l_1ead:
	/* 0x1ead: add    r13,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1eb4:
	/* 0x1eb4: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1eb9:
	/* 0x1eb9: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1ebc:
	/* 0x1ebc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ebe:
	/* 0x1ebe: call   1ec3 <trace_mmap_alert+0x1ec3> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1ec3:
	/* 0x1ec3: jmp    1a1d <trace_mmap_alert+0x1a1d> */
	X86_SIM_X86_JMP(0x1ec3, 0x1a1d, x86_l_1a1d);
x86_l_1ec8:
	/* 0x1ec8: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ecb:
	/* 0x1ecb: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ecf:
	/* 0x1ecf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ed2:
	/* 0x1ed2: jns    1ed9 <trace_mmap_alert+0x1ed9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ed2, 0x1ed9, x86_l_1ed9);
x86_l_1ed4:
	/* 0x1ed4: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed7:
	/* 0x1ed7: jmp    1edb <trace_mmap_alert+0x1edb> */
	X86_SIM_X86_JMP(0x1ed7, 0x1edb, x86_l_1edb);
x86_l_1ed9:
	/* 0x1ed9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1edb:
	/* 0x1edb: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1edf:
	/* 0x1edf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ee1:
	/* 0x1ee1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ee4:
	/* 0x1ee4: jns    1eeb <trace_mmap_alert+0x1eeb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ee4, 0x1eeb, x86_l_1eeb);
x86_l_1ee6:
	/* 0x1ee6: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee9:
	/* 0x1ee9: jmp    1eee <trace_mmap_alert+0x1eee> */
	X86_SIM_X86_JMP(0x1ee9, 0x1eee, x86_l_1eee);
x86_l_1eeb:
	/* 0x1eeb: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1eee:
	/* 0x1eee: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1ef3:
	/* 0x1ef3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ef6:
	/* 0x1ef6: jns    1efa <trace_mmap_alert+0x1efa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ef6, 0x1efa, x86_l_1efa);
x86_l_1ef8:
	/* 0x1ef8: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1efa:
	/* 0x1efa: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1eff:
	/* 0x1eff: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1f02:
	/* 0x1f02: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f06:
	/* 0x1f06: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f09:
	/* 0x1f09: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f0b:
	/* 0x1f0b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f0e:
	/* 0x1f0e: jns    1f15 <trace_mmap_alert+0x1f15> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f0e, 0x1f15, x86_l_1f15);
x86_l_1f10:
	/* 0x1f10: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f13:
	/* 0x1f13: jmp    1f17 <trace_mmap_alert+0x1f17> */
	X86_SIM_X86_JMP(0x1f13, 0x1f17, x86_l_1f17);
x86_l_1f15:
	/* 0x1f15: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f17:
	/* 0x1f17: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f1a:
	/* 0x1f1a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f1d:
	/* 0x1f1d: jns    1f21 <trace_mmap_alert+0x1f21> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f1d, 0x1f21, x86_l_1f21);
x86_l_1f1f:
	/* 0x1f1f: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f21:
	/* 0x1f21: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1f23:
	/* 0x1f23: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1f27:
	/* 0x1f27: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f2a:
	/* 0x1f2a: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1f2e:
	/* 0x1f2e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f30:
	/* 0x1f30: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f33:
	/* 0x1f33: jns    1f37 <trace_mmap_alert+0x1f37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f33, 0x1f37, x86_l_1f37);
x86_l_1f35:
	/* 0x1f35: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f37:
	/* 0x1f37: mov    rsi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f3c:
	/* 0x1f3c: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1f3f:
	/* 0x1f3f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f42:
	/* 0x1f42: jns    1f49 <trace_mmap_alert+0x1f49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f42, 0x1f49, x86_l_1f49);
x86_l_1f44:
	/* 0x1f44: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f47:
	/* 0x1f47: jmp    1f4b <trace_mmap_alert+0x1f4b> */
	X86_SIM_X86_JMP(0x1f47, 0x1f4b, x86_l_1f4b);
x86_l_1f49:
	/* 0x1f49: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4b:
	/* 0x1f4b: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1f4f:
	/* 0x1f4f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f51:
	/* 0x1f51: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f54:
	/* 0x1f54: jns    1f5b <trace_mmap_alert+0x1f5b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f54, 0x1f5b, x86_l_1f5b);
x86_l_1f56:
	/* 0x1f56: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f59:
	/* 0x1f59: jmp    1f5d <trace_mmap_alert+0x1f5d> */
	X86_SIM_X86_JMP(0x1f59, 0x1f5d, x86_l_1f5d);
x86_l_1f5b:
	/* 0x1f5b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f5d:
	/* 0x1f5d: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f60:
	/* 0x1f60: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f63:
	/* 0x1f63: jns    1f67 <trace_mmap_alert+0x1f67> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f63, 0x1f67, x86_l_1f67);
x86_l_1f65:
	/* 0x1f65: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f67:
	/* 0x1f67: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f69:
	/* 0x1f69: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1f6d:
	/* 0x1f6d: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f70:
	/* 0x1f70: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1f74:
	/* 0x1f74: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f76:
	/* 0x1f76: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f79:
	/* 0x1f79: jns    1f7d <trace_mmap_alert+0x1f7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f79, 0x1f7d, x86_l_1f7d);
x86_l_1f7b:
	/* 0x1f7b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f7d:
	/* 0x1f7d: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f82:
	/* 0x1f82: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f85:
	/* 0x1f85: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f87:
	/* 0x1f87: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f8a:
	/* 0x1f8a: jns    1f91 <trace_mmap_alert+0x1f91> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f8a, 0x1f91, x86_l_1f91);
x86_l_1f8c:
	/* 0x1f8c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f8f:
	/* 0x1f8f: jmp    1f93 <trace_mmap_alert+0x1f93> */
	X86_SIM_X86_JMP(0x1f8f, 0x1f93, x86_l_1f93);
x86_l_1f91:
	/* 0x1f91: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f93:
	/* 0x1f93: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f96:
	/* 0x1f96: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f99:
	/* 0x1f99: jns    1f9d <trace_mmap_alert+0x1f9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f99, 0x1f9d, x86_l_1f9d);
x86_l_1f9b:
	/* 0x1f9b: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f9d:
	/* 0x1f9d: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1f9f:
	/* 0x1f9f: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1fa3:
	/* 0x1fa3: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fa6:
	/* 0x1fa6: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1faa:
	/* 0x1faa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fac:
	/* 0x1fac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1faf:
	/* 0x1faf: jns    1fb6 <trace_mmap_alert+0x1fb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1faf, 0x1fb6, x86_l_1fb6);
x86_l_1fb1:
	/* 0x1fb1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb4:
	/* 0x1fb4: jmp    1fb8 <trace_mmap_alert+0x1fb8> */
	X86_SIM_X86_JMP(0x1fb4, 0x1fb8, x86_l_1fb8);
x86_l_1fb6:
	/* 0x1fb6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fb8:
	/* 0x1fb8: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1fbc:
	/* 0x1fbc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fbf:
	/* 0x1fbf: jns    1fc3 <trace_mmap_alert+0x1fc3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fbf, 0x1fc3, x86_l_1fc3);
x86_l_1fc1:
	/* 0x1fc1: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc3:
	/* 0x1fc3: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fc8:
	/* 0x1fc8: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fcb:
	/* 0x1fcb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fcd:
	/* 0x1fcd: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fd0:
	/* 0x1fd0: jns    1fd7 <trace_mmap_alert+0x1fd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd0, 0x1fd7, x86_l_1fd7);
x86_l_1fd2:
	/* 0x1fd2: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fd5:
	/* 0x1fd5: jmp    1fd9 <trace_mmap_alert+0x1fd9> */
	X86_SIM_X86_JMP(0x1fd5, 0x1fd9, x86_l_1fd9);
x86_l_1fd7:
	/* 0x1fd7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fd9:
	/* 0x1fd9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fdc:
	/* 0x1fdc: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fdf:
	/* 0x1fdf: jns    1fe3 <trace_mmap_alert+0x1fe3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fdf, 0x1fe3, x86_l_1fe3);
x86_l_1fe1:
	/* 0x1fe1: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe3:
	/* 0x1fe3: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1fe5:
	/* 0x1fe5: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1fe9:
	/* 0x1fe9: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fec:
	/* 0x1fec: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1ff0:
	/* 0x1ff0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ff2:
	/* 0x1ff2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ff5:
	/* 0x1ff5: jns    1ffc <trace_mmap_alert+0x1ffc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff5, 0x1ffc, x86_l_1ffc);
x86_l_1ff7:
	/* 0x1ff7: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ffa:
	/* 0x1ffa: jmp    1ffe <trace_mmap_alert+0x1ffe> */
	X86_SIM_X86_JMP(0x1ffa, 0x1ffe, x86_l_1ffe);
x86_l_1ffc:
	/* 0x1ffc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ffe:
	/* 0x1ffe: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2002:
	/* 0x2002: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2005:
	/* 0x2005: jns    2009 <trace_mmap_alert+0x2009> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2005, 0x2009, x86_l_2009);
x86_l_2007:
	/* 0x2007: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2009:
	/* 0x2009: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_200b:
	/* 0x200b: jne    2146 <trace_mmap_alert+0x2146> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x200b, 0x2146, x86_l_2146);
x86_l_2011:
	/* 0x2011: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2013:
	/* 0x2013: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2016:
	/* 0x2016: jns    211c <trace_mmap_alert+0x211c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2016, 0x211c, x86_l_211c);
x86_l_201c:
	/* 0x201c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_201f:
	/* 0x201f: jmp    211e <trace_mmap_alert+0x211e> */
	X86_SIM_X86_JMP(0x201f, 0x211e, x86_l_211e);
x86_l_2024:
	/* 0x2024: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2029:
	/* 0x2029: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_202d:
	/* 0x202d: jl     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_L, 0x202d, 0x36d6, x86_l_36d6);
x86_l_2033:
	/* 0x2033: mov    BYTE PTR [r12+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_203c:
	/* 0x203c: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_2042:
	/* 0x2042: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2045:
	/* 0x2045: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2048:
	/* 0x2048: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_204b:
	/* 0x204b: jns    2052 <trace_mmap_alert+0x2052> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x204b, 0x2052, x86_l_2052);
x86_l_204d:
	/* 0x204d: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2050:
	/* 0x2050: jmp    2054 <trace_mmap_alert+0x2054> */
	X86_SIM_X86_JMP(0x2050, 0x2054, x86_l_2054);
x86_l_2052:
	/* 0x2052: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2054:
	/* 0x2054: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2058:
	/* 0x2058: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_205b:
	/* 0x205b: jns    2062 <trace_mmap_alert+0x2062> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x205b, 0x2062, x86_l_2062);
x86_l_205d:
	/* 0x205d: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2060:
	/* 0x2060: jmp    2064 <trace_mmap_alert+0x2064> */
	X86_SIM_X86_JMP(0x2060, 0x2064, x86_l_2064);
x86_l_2062:
	/* 0x2062: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2064:
	/* 0x2064: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2067:
	/* 0x2067: je     20f5 <trace_mmap_alert+0x20f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2067, 0x20f5, x86_l_20f5);
x86_l_206d:
	/* 0x206d: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2070:
	/* 0x2070: je     20f5 <trace_mmap_alert+0x20f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2070, 0x20f5, x86_l_20f5);
x86_l_2076:
	/* 0x2076: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_207a:
	/* 0x207a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_207d:
	/* 0x207d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2083:
	/* 0x2083: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2086:
	/* 0x2086: jns    208f <trace_mmap_alert+0x208f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2086, 0x208f, x86_l_208f);
x86_l_2088:
	/* 0x2088: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_208b:
	/* 0x208b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_208f:
	/* 0x208f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2093:
	/* 0x2093: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2096:
	/* 0x2096: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_209d:
	/* 0x209d: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_20a0:
	/* 0x20a0: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20a3:
	/* 0x20a3: jb     3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20a3, 0x3789, x86_l_3789);
x86_l_20a9:
	/* 0x20a9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_20ac:
	/* 0x20ac: je     36c6 <trace_mmap_alert+0x36c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ac, 0x36c6, x86_l_36c6);
x86_l_20b2:
	/* 0x20b2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20b8:
	/* 0x20b8: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20bb:
	/* 0x20bb: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_20be:
	/* 0x20be: jns    2415 <trace_mmap_alert+0x2415> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20be, 0x2415, x86_l_2415);
x86_l_20c4:
	/* 0x20c4: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c8:
	/* 0x20c8: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20cc:
	/* 0x20cc: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20cf:
	/* 0x20cf: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_20d2:
	/* 0x20d2: je     241d <trace_mmap_alert+0x241d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20d2, 0x241d, x86_l_241d);
x86_l_20d8:
	/* 0x20d8: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20dc:
	/* 0x20dc: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_20e1:
	/* 0x20e1: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_20e5:
	/* 0x20e5: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_20e8:
	/* 0x20e8: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_20eb:
	/* 0x20eb: jne    20cf <trace_mmap_alert+0x20cf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20eb, 0x20cf, x86_l_20cf);
x86_l_20ed:
	/* 0x20ed: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_20f0:
	/* 0x20f0: jmp    2422 <trace_mmap_alert+0x2422> */
	X86_SIM_X86_JMP(0x20f0, 0x2422, x86_l_2422);
x86_l_20f5:
	/* 0x20f5: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20f8:
	/* 0x20f8: jne    36c6 <trace_mmap_alert+0x36c6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20f8, 0x36c6, x86_l_36c6);
x86_l_20fe:
	/* 0x20fe: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2101:
	/* 0x2101: je     36c6 <trace_mmap_alert+0x36c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2101, 0x36c6, x86_l_36c6);
x86_l_2107:
	/* 0x2107: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_210b:
	/* 0x210b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_210e:
	/* 0x210e: jns    23ce <trace_mmap_alert+0x23ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x210e, 0x23ce, x86_l_23ce);
x86_l_2114:
	/* 0x2114: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2117:
	/* 0x2117: jmp    23d0 <trace_mmap_alert+0x23d0> */
	X86_SIM_X86_JMP(0x2117, 0x23d0, x86_l_23d0);
x86_l_211c:
	/* 0x211c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_211e:
	/* 0x211e: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2121:
	/* 0x2121: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2124:
	/* 0x2124: jns    2128 <trace_mmap_alert+0x2128> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2124, 0x2128, x86_l_2128);
x86_l_2126:
	/* 0x2126: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2128:
	/* 0x2128: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_212a:
	/* 0x212a: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_212e:
	/* 0x212e: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2131:
	/* 0x2131: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2135:
	/* 0x2135: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2137:
	/* 0x2137: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_213a:
	/* 0x213a: jns    213e <trace_mmap_alert+0x213e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x213a, 0x213e, x86_l_213e);
x86_l_213c:
	/* 0x213c: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213e:
	/* 0x213e: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2143:
	/* 0x2143: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2146:
	/* 0x2146: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_214b:
	/* 0x214b: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_214e:
	/* 0x214e: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2155:
	/* 0x2155: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2158:
	/* 0x2158: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_215b:
	/* 0x215b: jns    2162 <trace_mmap_alert+0x2162> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x215b, 0x2162, x86_l_2162);
x86_l_215d:
	/* 0x215d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2160:
	/* 0x2160: jmp    2164 <trace_mmap_alert+0x2164> */
	X86_SIM_X86_JMP(0x2160, 0x2164, x86_l_2164);
x86_l_2162:
	/* 0x2162: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2164:
	/* 0x2164: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2168:
	/* 0x2168: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_216a:
	/* 0x216a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_216d:
	/* 0x216d: jns    2174 <trace_mmap_alert+0x2174> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x216d, 0x2174, x86_l_2174);
x86_l_216f:
	/* 0x216f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2172:
	/* 0x2172: jmp    2176 <trace_mmap_alert+0x2176> */
	X86_SIM_X86_JMP(0x2172, 0x2176, x86_l_2176);
x86_l_2174:
	/* 0x2174: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2176:
	/* 0x2176: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2179:
	/* 0x2179: jns    217d <trace_mmap_alert+0x217d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2179, 0x217d, x86_l_217d);
x86_l_217b:
	/* 0x217b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217d:
	/* 0x217d: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2182:
	/* 0x2182: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2186:
	/* 0x2186: call   218b <trace_mmap_alert+0x218b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_218b:
	/* 0x218b: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_218f:
	/* 0x218f: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2193:
	/* 0x2193: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2196:
	/* 0x2196: jns    219d <trace_mmap_alert+0x219d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2196, 0x219d, x86_l_219d);
x86_l_2198:
	/* 0x2198: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_219b:
	/* 0x219b: jmp    219f <trace_mmap_alert+0x219f> */
	X86_SIM_X86_JMP(0x219b, 0x219f, x86_l_219f);
x86_l_219d:
	/* 0x219d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_219f:
	/* 0x219f: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21a4:
	/* 0x21a4: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21a7:
	/* 0x21a7: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_21ab:
	/* 0x21ab: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_21ae:
	/* 0x21ae: jns    21b5 <trace_mmap_alert+0x21b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21ae, 0x21b5, x86_l_21b5);
x86_l_21b0:
	/* 0x21b0: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b3:
	/* 0x21b3: jmp    21b7 <trace_mmap_alert+0x21b7> */
	X86_SIM_X86_JMP(0x21b3, 0x21b7, x86_l_21b7);
x86_l_21b5:
	/* 0x21b5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b7:
	/* 0x21b7: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21bc:
	/* 0x21bc: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21c1:
	/* 0x21c1: mov    QWORD PTR [r15+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_21c5:
	/* 0x21c5: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_21c9:
	/* 0x21c9: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_21cc:
	/* 0x21cc: jns    21d4 <trace_mmap_alert+0x21d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21cc, 0x21d4, x86_l_21d4);
x86_l_21ce:
	/* 0x21ce: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21d2:
	/* 0x21d2: jmp    21d6 <trace_mmap_alert+0x21d6> */
	X86_SIM_X86_JMP(0x21d2, 0x21d6, x86_l_21d6);
x86_l_21d4:
	/* 0x21d4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d6:
	/* 0x21d6: mov    QWORD PTR [r15+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_21da:
	/* 0x21da: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21dd:
	/* 0x21dd: jns    21ea <trace_mmap_alert+0x21ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21dd, 0x21ea, x86_l_21ea);
x86_l_21df:
	/* 0x21df: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e1:
	/* 0x21e1: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_21e3:
	/* 0x21e3: je     21ea <trace_mmap_alert+0x21ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e3, 0x21ea, x86_l_21ea);
x86_l_21e5:
	/* 0x21e5: or     BYTE PTR [r15+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_21ea:
	/* 0x21ea: lea    rdi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_21ee:
	/* 0x21ee: mov    QWORD PTR [r15+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_21f6:
	/* 0x21f6: mov    QWORD PTR [r15+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_21fe:
	/* 0x21fe: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2203:
	/* 0x2203: call   2208 <trace_mmap_alert+0x2208> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_2208:
	/* 0x2208: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_220b:
	/* 0x220b: jns    2213 <trace_mmap_alert+0x2213> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x220b, 0x2213, x86_l_2213);
x86_l_220d:
	/* 0x220d: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2211:
	/* 0x2211: jmp    2215 <trace_mmap_alert+0x2215> */
	X86_SIM_X86_JMP(0x2211, 0x2215, x86_l_2215);
x86_l_2213:
	/* 0x2213: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2215:
	/* 0x2215: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_221a:
	/* 0x221a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_221d:
	/* 0x221d: jns    2224 <trace_mmap_alert+0x2224> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x221d, 0x2224, x86_l_2224);
x86_l_221f:
	/* 0x221f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2222:
	/* 0x2222: jmp    2226 <trace_mmap_alert+0x2226> */
	X86_SIM_X86_JMP(0x2222, 0x2226, x86_l_2226);
x86_l_2224:
	/* 0x2224: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2226:
	/* 0x2226: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2229:
	/* 0x2229: jns    2276 <trace_mmap_alert+0x2276> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2229, 0x2276, x86_l_2276);
x86_l_222b:
	/* 0x222b: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222e:
	/* 0x222e: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2233:
	/* 0x2233: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2237:
	/* 0x2237: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_223c:
	/* 0x223c: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2240:
	/* 0x2240: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2245:
	/* 0x2245: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2249:
	/* 0x2249: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_224e:
	/* 0x224e: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2252:
	/* 0x2252: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2257:
	/* 0x2257: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_225b:
	/* 0x225b: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2260:
	/* 0x2260: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2264:
	/* 0x2264: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2269:
	/* 0x2269: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_226d:
	/* 0x226d: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2272:
	/* 0x2272: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2276:
	/* 0x2276: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2279:
	/* 0x2279: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_227d:
	/* 0x227d: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2282:
	/* 0x2282: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2285:
	/* 0x2285: jns    23ba <trace_mmap_alert+0x23ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2285, 0x23ba, x86_l_23ba);
x86_l_228b:
	/* 0x228b: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_228e:
	/* 0x228e: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2290:
	/* 0x2290: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2292:
	/* 0x2292: je     236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2292, 0x236, x86_l_236);
x86_l_2298:
	/* 0x2298: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_229c:
	/* 0x229c: mov    BYTE PTR [r15+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_22a0:
	/* 0x22a0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22a2:
	/* 0x22a2: je     236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22a2, 0x236, x86_l_236);
x86_l_22a8:
	/* 0x22a8: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_22ac:
	/* 0x22ac: mov    BYTE PTR [r15+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_22b0:
	/* 0x22b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22b2:
	/* 0x22b2: je     236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b2, 0x236, x86_l_236);
x86_l_22b8:
	/* 0x22b8: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_22bc:
	/* 0x22bc: mov    BYTE PTR [r15+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_22c0:
	/* 0x22c0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22c2:
	/* 0x22c2: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c2, 0x23fc, x86_l_23fc);
x86_l_22c8:
	/* 0x22c8: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_22cc:
	/* 0x22cc: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22d1:
	/* 0x22d1: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_22d4:
	/* 0x22d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22d6:
	/* 0x22d6: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22d6, 0x23fc, x86_l_23fc);
x86_l_22dc:
	/* 0x22dc: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_22e0:
	/* 0x22e0: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22e5:
	/* 0x22e5: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_22e8:
	/* 0x22e8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22ea:
	/* 0x22ea: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22ea, 0x23fc, x86_l_23fc);
x86_l_22f0:
	/* 0x22f0: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_22f4:
	/* 0x22f4: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22f9:
	/* 0x22f9: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_22fc:
	/* 0x22fc: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_22fe:
	/* 0x22fe: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22fe, 0x23fc, x86_l_23fc);
x86_l_2304:
	/* 0x2304: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2308:
	/* 0x2308: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_230d:
	/* 0x230d: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_2310:
	/* 0x2310: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2312:
	/* 0x2312: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2312, 0x23fc, x86_l_23fc);
x86_l_2318:
	/* 0x2318: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_231c:
	/* 0x231c: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2321:
	/* 0x2321: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_2324:
	/* 0x2324: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2326:
	/* 0x2326: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2326, 0x23fc, x86_l_23fc);
x86_l_232c:
	/* 0x232c: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2330:
	/* 0x2330: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2335:
	/* 0x2335: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_2338:
	/* 0x2338: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_233a:
	/* 0x233a: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x233a, 0x23fc, x86_l_23fc);
x86_l_2340:
	/* 0x2340: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2344:
	/* 0x2344: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2349:
	/* 0x2349: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_234c:
	/* 0x234c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_234e:
	/* 0x234e: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234e, 0x23fc, x86_l_23fc);
x86_l_2354:
	/* 0x2354: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2358:
	/* 0x2358: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_235d:
	/* 0x235d: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2360:
	/* 0x2360: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2362:
	/* 0x2362: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2362, 0x23fc, x86_l_23fc);
x86_l_2368:
	/* 0x2368: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_236c:
	/* 0x236c: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2371:
	/* 0x2371: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2374:
	/* 0x2374: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2376:
	/* 0x2376: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2376, 0x23fc, x86_l_23fc);
x86_l_237c:
	/* 0x237c: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2380:
	/* 0x2380: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2385:
	/* 0x2385: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2388:
	/* 0x2388: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_238a:
	/* 0x238a: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x238a, 0x23fc, x86_l_23fc);
x86_l_238c:
	/* 0x238c: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2390:
	/* 0x2390: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2395:
	/* 0x2395: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2398:
	/* 0x2398: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_239a:
	/* 0x239a: je     23fc <trace_mmap_alert+0x23fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x239a, 0x23fc, x86_l_23fc);
x86_l_239c:
	/* 0x239c: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23a1:
	/* 0x23a1: mov    BYTE PTR [r15+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_23a6:
	/* 0x23a6: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23ab:
	/* 0x23ab: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_23b0:
	/* 0x23b0: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23b5:
	/* 0x23b5: jmp    236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JMP(0x23b5, 0x236, x86_l_236);
x86_l_23ba:
	/* 0x23ba: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_23c2:
	/* 0x23c2: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23c9:
	/* 0x23c9: jmp    236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JMP(0x23c9, 0x236, x86_l_236);
x86_l_23ce:
	/* 0x23ce: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d0:
	/* 0x23d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23d3:
	/* 0x23d3: jns    23da <trace_mmap_alert+0x23da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23d3, 0x23da, x86_l_23da);
x86_l_23d5:
	/* 0x23d5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d8:
	/* 0x23d8: jmp    23dc <trace_mmap_alert+0x23dc> */
	X86_SIM_X86_JMP(0x23d8, 0x23dc, x86_l_23dc);
x86_l_23da:
	/* 0x23da: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23dc:
	/* 0x23dc: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23df:
	/* 0x23df: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23e2:
	/* 0x23e2: jns    23e9 <trace_mmap_alert+0x23e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23e2, 0x23e9, x86_l_23e9);
x86_l_23e4:
	/* 0x23e4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e7:
	/* 0x23e7: jmp    23eb <trace_mmap_alert+0x23eb> */
	X86_SIM_X86_JMP(0x23e7, 0x23eb, x86_l_23eb);
x86_l_23e9:
	/* 0x23e9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23eb:
	/* 0x23eb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23ef:
	/* 0x23ef: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23f2:
	/* 0x23f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23f5:
	/* 0x23f5: jns    244f <trace_mmap_alert+0x244f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23f5, 0x244f, x86_l_244f);
x86_l_23f7:
	/* 0x23f7: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fa:
	/* 0x23fa: jmp    2451 <trace_mmap_alert+0x2451> */
	X86_SIM_X86_JMP(0x23fa, 0x2451, x86_l_2451);
x86_l_23fc:
	/* 0x23fc: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2401:
	/* 0x2401: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2406:
	/* 0x2406: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_240b:
	/* 0x240b: mov    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2410:
	/* 0x2410: jmp    236 <trace_mmap_alert+0x236> */
	X86_SIM_X86_JMP(0x2410, 0x236, x86_l_236);
x86_l_2415:
	/* 0x2415: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2418:
	/* 0x2418: jmp    3501 <trace_mmap_alert+0x3501> */
	X86_SIM_X86_JMP(0x2418, 0x3501, x86_l_3501);
x86_l_241d:
	/* 0x241d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2422:
	/* 0x2422: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2426:
	/* 0x2426: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2426, 0x36bd, x86_l_36bd);
x86_l_242c:
	/* 0x242c: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2430:
	/* 0x2430: lea    edx,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2434:
	/* 0x2434: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_243a:
	/* 0x243a: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_243f:
	/* 0x243f: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2442:
	/* 0x2442: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2447:
	/* 0x2447: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_244a:
	/* 0x244a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_244d:
	/* 0x244d: js     23f7 <trace_mmap_alert+0x23f7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x244d, 0x23f7, x86_l_23f7);
x86_l_244f:
	/* 0x244f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2451:
	/* 0x2451: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2455:
	/* 0x2455: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2458:
	/* 0x2458: jns    245f <trace_mmap_alert+0x245f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2458, 0x245f, x86_l_245f);
x86_l_245a:
	/* 0x245a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_245d:
	/* 0x245d: jmp    2461 <trace_mmap_alert+0x2461> */
	X86_SIM_X86_JMP(0x245d, 0x2461, x86_l_2461);
x86_l_245f:
	/* 0x245f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2461:
	/* 0x2461: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2464:
	/* 0x2464: je     24a4 <trace_mmap_alert+0x24a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2464, 0x24a4, x86_l_24a4);
x86_l_2466:
	/* 0x2466: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2469:
	/* 0x2469: je     24a4 <trace_mmap_alert+0x24a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2469, 0x24a4, x86_l_24a4);
x86_l_246b:
	/* 0x246b: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_246f:
	/* 0x246f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2472:
	/* 0x2472: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2478:
	/* 0x2478: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_247b:
	/* 0x247b: jns    2484 <trace_mmap_alert+0x2484> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x247b, 0x2484, x86_l_2484);
x86_l_247d:
	/* 0x247d: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2480:
	/* 0x2480: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2484:
	/* 0x2484: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2488:
	/* 0x2488: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_248b:
	/* 0x248b: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2492:
	/* 0x2492: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2495:
	/* 0x2495: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2498:
	/* 0x2498: jae    24c4 <trace_mmap_alert+0x24c4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2498, 0x24c4, x86_l_24c4);
x86_l_249a:
	/* 0x249a: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_249f:
	/* 0x249f: jmp    3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JMP(0x249f, 0x3789, x86_l_3789);
x86_l_24a4:
	/* 0x24a4: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24a7:
	/* 0x24a7: jne    2509 <trace_mmap_alert+0x2509> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24a7, 0x2509, x86_l_2509);
x86_l_24a9:
	/* 0x24a9: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24ad:
	/* 0x24ad: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24b0:
	/* 0x24b0: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24b0, 0x36ba, x86_l_36ba);
x86_l_24b6:
	/* 0x24b6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ba:
	/* 0x24ba: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24bd:
	/* 0x24bd: jns    2521 <trace_mmap_alert+0x2521> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24bd, 0x2521, x86_l_2521);
x86_l_24bf:
	/* 0x24bf: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c2:
	/* 0x24c2: jmp    2523 <trace_mmap_alert+0x2523> */
	X86_SIM_X86_JMP(0x24c2, 0x2523, x86_l_2523);
x86_l_24c4:
	/* 0x24c4: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c8:
	/* 0x24c8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_24cb:
	/* 0x24cb: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24cb, 0x36ba, x86_l_36ba);
x86_l_24d1:
	/* 0x24d1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_24d7:
	/* 0x24d7: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_24da:
	/* 0x24da: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_24dd:
	/* 0x24dd: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24dd, 0x34f8, x86_l_34f8);
x86_l_24e3:
	/* 0x24e3: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24e7:
	/* 0x24e7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ea:
	/* 0x24ea: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_24ed:
	/* 0x24ed: je     254f <trace_mmap_alert+0x254f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24ed, 0x254f, x86_l_254f);
x86_l_24ef:
	/* 0x24ef: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_24f3:
	/* 0x24f3: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_24f8:
	/* 0x24f8: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_24fc:
	/* 0x24fc: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_24ff:
	/* 0x24ff: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2502:
	/* 0x2502: jne    24ea <trace_mmap_alert+0x24ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2502, 0x24ea, x86_l_24ea);
x86_l_2504:
	/* 0x2504: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2507:
	/* 0x2507: jmp    2554 <trace_mmap_alert+0x2554> */
	X86_SIM_X86_JMP(0x2507, 0x2554, x86_l_2554);
x86_l_2509:
	/* 0x2509: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_250c:
	/* 0x250c: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_250f:
	/* 0x250f: cmp    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_2516:
	/* 0x2516: je     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2516, 0x36d6, x86_l_36d6);
x86_l_251c:
	/* 0x251c: jmp    3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JMP(0x251c, 0x3789, x86_l_3789);
x86_l_2521:
	/* 0x2521: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2523:
	/* 0x2523: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2526:
	/* 0x2526: jns    252d <trace_mmap_alert+0x252d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2526, 0x252d, x86_l_252d);
x86_l_2528:
	/* 0x2528: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_252b:
	/* 0x252b: jmp    252f <trace_mmap_alert+0x252f> */
	X86_SIM_X86_JMP(0x252b, 0x252f, x86_l_252f);
x86_l_252d:
	/* 0x252d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_252f:
	/* 0x252f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2532:
	/* 0x2532: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2535:
	/* 0x2535: jns    253c <trace_mmap_alert+0x253c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2535, 0x253c, x86_l_253c);
x86_l_2537:
	/* 0x2537: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_253a:
	/* 0x253a: jmp    253e <trace_mmap_alert+0x253e> */
	X86_SIM_X86_JMP(0x253a, 0x253e, x86_l_253e);
x86_l_253c:
	/* 0x253c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_253e:
	/* 0x253e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2542:
	/* 0x2542: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2545:
	/* 0x2545: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2548:
	/* 0x2548: jns    2580 <trace_mmap_alert+0x2580> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2548, 0x2580, x86_l_2580);
x86_l_254a:
	/* 0x254a: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_254d:
	/* 0x254d: jmp    2582 <trace_mmap_alert+0x2582> */
	X86_SIM_X86_JMP(0x254d, 0x2582, x86_l_2582);
x86_l_254f:
	/* 0x254f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2554:
	/* 0x2554: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2558:
	/* 0x2558: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2558, 0x36ba, x86_l_36ba);
x86_l_255e:
	/* 0x255e: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2562:
	/* 0x2562: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2566:
	/* 0x2566: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_256c:
	/* 0x256c: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2571:
	/* 0x2571: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2574:
	/* 0x2574: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2578:
	/* 0x2578: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_257b:
	/* 0x257b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_257e:
	/* 0x257e: js     254a <trace_mmap_alert+0x254a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x257e, 0x254a, x86_l_254a);
x86_l_2580:
	/* 0x2580: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2582:
	/* 0x2582: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2586:
	/* 0x2586: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2589:
	/* 0x2589: jns    2590 <trace_mmap_alert+0x2590> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2589, 0x2590, x86_l_2590);
x86_l_258b:
	/* 0x258b: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_258e:
	/* 0x258e: jmp    2592 <trace_mmap_alert+0x2592> */
	X86_SIM_X86_JMP(0x258e, 0x2592, x86_l_2592);
x86_l_2590:
	/* 0x2590: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2592:
	/* 0x2592: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2595:
	/* 0x2595: je     2611 <trace_mmap_alert+0x2611> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2595, 0x2611, x86_l_2611);
x86_l_2597:
	/* 0x2597: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_259a:
	/* 0x259a: je     2611 <trace_mmap_alert+0x2611> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259a, 0x2611, x86_l_2611);
x86_l_259c:
	/* 0x259c: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a0:
	/* 0x25a0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25a3:
	/* 0x25a3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_25a9:
	/* 0x25a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25ac:
	/* 0x25ac: jns    25b5 <trace_mmap_alert+0x25b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ac, 0x25b5, x86_l_25b5);
x86_l_25ae:
	/* 0x25ae: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b1:
	/* 0x25b1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25b5:
	/* 0x25b5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_25b9:
	/* 0x25b9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_25bc:
	/* 0x25bc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_25c3:
	/* 0x25c3: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25c7:
	/* 0x25c7: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25ca:
	/* 0x25ca: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x25ca, 0x3780, x86_l_3780);
x86_l_25d0:
	/* 0x25d0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_25d3:
	/* 0x25d3: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25d3, 0x36bd, x86_l_36bd);
x86_l_25d9:
	/* 0x25d9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_25df:
	/* 0x25df: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25e2:
	/* 0x25e2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_25e5:
	/* 0x25e5: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e5, 0x34f5, x86_l_34f5);
x86_l_25eb:
	/* 0x25eb: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25ef:
	/* 0x25ef: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f2:
	/* 0x25f2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_25f5:
	/* 0x25f5: je     265f <trace_mmap_alert+0x265f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f5, 0x265f, x86_l_265f);
x86_l_25f7:
	/* 0x25f7: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25fb:
	/* 0x25fb: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2600:
	/* 0x2600: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2604:
	/* 0x2604: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2607:
	/* 0x2607: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_260a:
	/* 0x260a: jne    25f2 <trace_mmap_alert+0x25f2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x260a, 0x25f2, x86_l_25f2);
x86_l_260c:
	/* 0x260c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_260f:
	/* 0x260f: jmp    2664 <trace_mmap_alert+0x2664> */
	X86_SIM_X86_JMP(0x260f, 0x2664, x86_l_2664);
x86_l_2611:
	/* 0x2611: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2614:
	/* 0x2614: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2614, 0x36bd, x86_l_36bd);
x86_l_261a:
	/* 0x261a: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_261d:
	/* 0x261d: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261d, 0x36bd, x86_l_36bd);
x86_l_2623:
	/* 0x2623: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2627:
	/* 0x2627: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_262a:
	/* 0x262a: jns    2631 <trace_mmap_alert+0x2631> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x262a, 0x2631, x86_l_2631);
x86_l_262c:
	/* 0x262c: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_262f:
	/* 0x262f: jmp    2633 <trace_mmap_alert+0x2633> */
	X86_SIM_X86_JMP(0x262f, 0x2633, x86_l_2633);
x86_l_2631:
	/* 0x2631: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2633:
	/* 0x2633: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2636:
	/* 0x2636: jns    263d <trace_mmap_alert+0x263d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2636, 0x263d, x86_l_263d);
x86_l_2638:
	/* 0x2638: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_263b:
	/* 0x263b: jmp    263f <trace_mmap_alert+0x263f> */
	X86_SIM_X86_JMP(0x263b, 0x263f, x86_l_263f);
x86_l_263d:
	/* 0x263d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_263f:
	/* 0x263f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2642:
	/* 0x2642: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2645:
	/* 0x2645: jns    264c <trace_mmap_alert+0x264c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2645, 0x264c, x86_l_264c);
x86_l_2647:
	/* 0x2647: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264a:
	/* 0x264a: jmp    264e <trace_mmap_alert+0x264e> */
	X86_SIM_X86_JMP(0x264a, 0x264e, x86_l_264e);
x86_l_264c:
	/* 0x264c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_264e:
	/* 0x264e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2652:
	/* 0x2652: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2655:
	/* 0x2655: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2658:
	/* 0x2658: jns    268f <trace_mmap_alert+0x268f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2658, 0x268f, x86_l_268f);
x86_l_265a:
	/* 0x265a: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_265d:
	/* 0x265d: jmp    2691 <trace_mmap_alert+0x2691> */
	X86_SIM_X86_JMP(0x265d, 0x2691, x86_l_2691);
x86_l_265f:
	/* 0x265f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2664:
	/* 0x2664: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2668:
	/* 0x2668: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2668, 0x36bd, x86_l_36bd);
x86_l_266e:
	/* 0x266e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2672:
	/* 0x2672: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2675:
	/* 0x2675: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_267b:
	/* 0x267b: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2680:
	/* 0x2680: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2683:
	/* 0x2683: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2687:
	/* 0x2687: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_268a:
	/* 0x268a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_268d:
	/* 0x268d: js     265a <trace_mmap_alert+0x265a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x268d, 0x265a, x86_l_265a);
x86_l_268f:
	/* 0x268f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2691:
	/* 0x2691: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2695:
	/* 0x2695: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2698:
	/* 0x2698: jns    269f <trace_mmap_alert+0x269f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2698, 0x269f, x86_l_269f);
x86_l_269a:
	/* 0x269a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_269d:
	/* 0x269d: jmp    26a1 <trace_mmap_alert+0x26a1> */
	X86_SIM_X86_JMP(0x269d, 0x26a1, x86_l_26a1);
x86_l_269f:
	/* 0x269f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26a1:
	/* 0x26a1: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26a4:
	/* 0x26a4: je     2720 <trace_mmap_alert+0x2720> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a4, 0x2720, x86_l_2720);
x86_l_26a6:
	/* 0x26a6: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26a9:
	/* 0x26a9: je     2720 <trace_mmap_alert+0x2720> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a9, 0x2720, x86_l_2720);
x86_l_26ab:
	/* 0x26ab: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26af:
	/* 0x26af: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b2:
	/* 0x26b2: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_26b8:
	/* 0x26b8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26bb:
	/* 0x26bb: jns    26c4 <trace_mmap_alert+0x26c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26bb, 0x26c4, x86_l_26c4);
x86_l_26bd:
	/* 0x26bd: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c0:
	/* 0x26c0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26c4:
	/* 0x26c4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26c8:
	/* 0x26c8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_26cb:
	/* 0x26cb: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_26d2:
	/* 0x26d2: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26d6:
	/* 0x26d6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26d9:
	/* 0x26d9: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26d9, 0x3780, x86_l_3780);
x86_l_26df:
	/* 0x26df: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_26e2:
	/* 0x26e2: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e2, 0x36ba, x86_l_36ba);
x86_l_26e8:
	/* 0x26e8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_26ee:
	/* 0x26ee: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26f1:
	/* 0x26f1: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_26f4:
	/* 0x26f4: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f4, 0x34f8, x86_l_34f8);
x86_l_26fa:
	/* 0x26fa: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26fe:
	/* 0x26fe: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2701:
	/* 0x2701: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2704:
	/* 0x2704: je     276e <trace_mmap_alert+0x276e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2704, 0x276e, x86_l_276e);
x86_l_2706:
	/* 0x2706: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_270a:
	/* 0x270a: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_270f:
	/* 0x270f: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2713:
	/* 0x2713: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2716:
	/* 0x2716: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2719:
	/* 0x2719: jne    2701 <trace_mmap_alert+0x2701> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2719, 0x2701, x86_l_2701);
x86_l_271b:
	/* 0x271b: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_271e:
	/* 0x271e: jmp    2773 <trace_mmap_alert+0x2773> */
	X86_SIM_X86_JMP(0x271e, 0x2773, x86_l_2773);
x86_l_2720:
	/* 0x2720: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2723:
	/* 0x2723: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2723, 0x36ba, x86_l_36ba);
x86_l_2729:
	/* 0x2729: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_272c:
	/* 0x272c: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x272c, 0x36ba, x86_l_36ba);
x86_l_2732:
	/* 0x2732: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2736:
	/* 0x2736: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2739:
	/* 0x2739: jns    2740 <trace_mmap_alert+0x2740> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2739, 0x2740, x86_l_2740);
x86_l_273b:
	/* 0x273b: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_273e:
	/* 0x273e: jmp    2742 <trace_mmap_alert+0x2742> */
	X86_SIM_X86_JMP(0x273e, 0x2742, x86_l_2742);
x86_l_2740:
	/* 0x2740: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2742:
	/* 0x2742: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2745:
	/* 0x2745: jns    274c <trace_mmap_alert+0x274c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2745, 0x274c, x86_l_274c);
x86_l_2747:
	/* 0x2747: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274a:
	/* 0x274a: jmp    274e <trace_mmap_alert+0x274e> */
	X86_SIM_X86_JMP(0x274a, 0x274e, x86_l_274e);
x86_l_274c:
	/* 0x274c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_274e:
	/* 0x274e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2751:
	/* 0x2751: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2754:
	/* 0x2754: jns    275b <trace_mmap_alert+0x275b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2754, 0x275b, x86_l_275b);
x86_l_2756:
	/* 0x2756: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2759:
	/* 0x2759: jmp    275d <trace_mmap_alert+0x275d> */
	X86_SIM_X86_JMP(0x2759, 0x275d, x86_l_275d);
x86_l_275b:
	/* 0x275b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_275d:
	/* 0x275d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2761:
	/* 0x2761: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2764:
	/* 0x2764: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2767:
	/* 0x2767: jns    279f <trace_mmap_alert+0x279f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2767, 0x279f, x86_l_279f);
x86_l_2769:
	/* 0x2769: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_276c:
	/* 0x276c: jmp    27a1 <trace_mmap_alert+0x27a1> */
	X86_SIM_X86_JMP(0x276c, 0x27a1, x86_l_27a1);
x86_l_276e:
	/* 0x276e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2773:
	/* 0x2773: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2777:
	/* 0x2777: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2777, 0x36ba, x86_l_36ba);
x86_l_277d:
	/* 0x277d: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2781:
	/* 0x2781: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2785:
	/* 0x2785: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_278b:
	/* 0x278b: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2790:
	/* 0x2790: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2793:
	/* 0x2793: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2797:
	/* 0x2797: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_279a:
	/* 0x279a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_279d:
	/* 0x279d: js     2769 <trace_mmap_alert+0x2769> */
	X86_SIM_X86_JCC(X86_CC_S, 0x279d, 0x2769, x86_l_2769);
x86_l_279f:
	/* 0x279f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a1:
	/* 0x27a1: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27a5:
	/* 0x27a5: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_27a8:
	/* 0x27a8: jns    27af <trace_mmap_alert+0x27af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a8, 0x27af, x86_l_27af);
x86_l_27aa:
	/* 0x27aa: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ad:
	/* 0x27ad: jmp    27b1 <trace_mmap_alert+0x27b1> */
	X86_SIM_X86_JMP(0x27ad, 0x27b1, x86_l_27b1);
x86_l_27af:
	/* 0x27af: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b1:
	/* 0x27b1: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27b4:
	/* 0x27b4: je     2830 <trace_mmap_alert+0x2830> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b4, 0x2830, x86_l_2830);
x86_l_27b6:
	/* 0x27b6: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_27b9:
	/* 0x27b9: je     2830 <trace_mmap_alert+0x2830> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b9, 0x2830, x86_l_2830);
x86_l_27bb:
	/* 0x27bb: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27bf:
	/* 0x27bf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27c2:
	/* 0x27c2: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_27c8:
	/* 0x27c8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27cb:
	/* 0x27cb: jns    27d4 <trace_mmap_alert+0x27d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27cb, 0x27d4, x86_l_27d4);
x86_l_27cd:
	/* 0x27cd: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d0:
	/* 0x27d0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d4:
	/* 0x27d4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_27d8:
	/* 0x27d8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_27db:
	/* 0x27db: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_27e2:
	/* 0x27e2: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27e6:
	/* 0x27e6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27e9:
	/* 0x27e9: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27e9, 0x3780, x86_l_3780);
x86_l_27ef:
	/* 0x27ef: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_27f2:
	/* 0x27f2: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f2, 0x36bd, x86_l_36bd);
x86_l_27f8:
	/* 0x27f8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27fe:
	/* 0x27fe: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2801:
	/* 0x2801: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2804:
	/* 0x2804: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2804, 0x34f5, x86_l_34f5);
x86_l_280a:
	/* 0x280a: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_280e:
	/* 0x280e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2811:
	/* 0x2811: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2814:
	/* 0x2814: je     287e <trace_mmap_alert+0x287e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2814, 0x287e, x86_l_287e);
x86_l_2816:
	/* 0x2816: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_281a:
	/* 0x281a: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_281f:
	/* 0x281f: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2823:
	/* 0x2823: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2826:
	/* 0x2826: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2829:
	/* 0x2829: jne    2811 <trace_mmap_alert+0x2811> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2829, 0x2811, x86_l_2811);
x86_l_282b:
	/* 0x282b: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_282e:
	/* 0x282e: jmp    2883 <trace_mmap_alert+0x2883> */
	X86_SIM_X86_JMP(0x282e, 0x2883, x86_l_2883);
x86_l_2830:
	/* 0x2830: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2833:
	/* 0x2833: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2833, 0x36bd, x86_l_36bd);
x86_l_2839:
	/* 0x2839: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_283c:
	/* 0x283c: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283c, 0x36bd, x86_l_36bd);
x86_l_2842:
	/* 0x2842: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2846:
	/* 0x2846: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2849:
	/* 0x2849: jns    2850 <trace_mmap_alert+0x2850> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2849, 0x2850, x86_l_2850);
x86_l_284b:
	/* 0x284b: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284e:
	/* 0x284e: jmp    2852 <trace_mmap_alert+0x2852> */
	X86_SIM_X86_JMP(0x284e, 0x2852, x86_l_2852);
x86_l_2850:
	/* 0x2850: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2852:
	/* 0x2852: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2855:
	/* 0x2855: jns    285c <trace_mmap_alert+0x285c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2855, 0x285c, x86_l_285c);
x86_l_2857:
	/* 0x2857: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_285a:
	/* 0x285a: jmp    285e <trace_mmap_alert+0x285e> */
	X86_SIM_X86_JMP(0x285a, 0x285e, x86_l_285e);
x86_l_285c:
	/* 0x285c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_285e:
	/* 0x285e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2861:
	/* 0x2861: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2864:
	/* 0x2864: jns    286b <trace_mmap_alert+0x286b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2864, 0x286b, x86_l_286b);
x86_l_2866:
	/* 0x2866: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2869:
	/* 0x2869: jmp    286d <trace_mmap_alert+0x286d> */
	X86_SIM_X86_JMP(0x2869, 0x286d, x86_l_286d);
x86_l_286b:
	/* 0x286b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286d:
	/* 0x286d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2871:
	/* 0x2871: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2874:
	/* 0x2874: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2877:
	/* 0x2877: jns    28ae <trace_mmap_alert+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2877, 0x28ae, x86_l_28ae);
x86_l_2879:
	/* 0x2879: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_287c:
	/* 0x287c: jmp    28b0 <trace_mmap_alert+0x28b0> */
	X86_SIM_X86_JMP(0x287c, 0x28b0, x86_l_28b0);
x86_l_287e:
	/* 0x287e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2883:
	/* 0x2883: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2887:
	/* 0x2887: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2887, 0x36bd, x86_l_36bd);
x86_l_288d:
	/* 0x288d: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2891:
	/* 0x2891: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2894:
	/* 0x2894: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_289a:
	/* 0x289a: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_289f:
	/* 0x289f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28a2:
	/* 0x28a2: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a6:
	/* 0x28a6: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28a9:
	/* 0x28a9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28ac:
	/* 0x28ac: js     2879 <trace_mmap_alert+0x2879> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ac, 0x2879, x86_l_2879);
x86_l_28ae:
	/* 0x28ae: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b0:
	/* 0x28b0: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28b4:
	/* 0x28b4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28b7:
	/* 0x28b7: jns    28be <trace_mmap_alert+0x28be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b7, 0x28be, x86_l_28be);
x86_l_28b9:
	/* 0x28b9: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28bc:
	/* 0x28bc: jmp    28c0 <trace_mmap_alert+0x28c0> */
	X86_SIM_X86_JMP(0x28bc, 0x28c0, x86_l_28c0);
x86_l_28be:
	/* 0x28be: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c0:
	/* 0x28c0: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28c3:
	/* 0x28c3: je     293f <trace_mmap_alert+0x293f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c3, 0x293f, x86_l_293f);
x86_l_28c5:
	/* 0x28c5: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28c8:
	/* 0x28c8: je     293f <trace_mmap_alert+0x293f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c8, 0x293f, x86_l_293f);
x86_l_28ca:
	/* 0x28ca: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28ce:
	/* 0x28ce: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d1:
	/* 0x28d1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_28d7:
	/* 0x28d7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28da:
	/* 0x28da: jns    28e3 <trace_mmap_alert+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28da, 0x28e3, x86_l_28e3);
x86_l_28dc:
	/* 0x28dc: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28df:
	/* 0x28df: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28e3:
	/* 0x28e3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28e7:
	/* 0x28e7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28ea:
	/* 0x28ea: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28f1:
	/* 0x28f1: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28f5:
	/* 0x28f5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28f8:
	/* 0x28f8: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28f8, 0x3780, x86_l_3780);
x86_l_28fe:
	/* 0x28fe: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2901:
	/* 0x2901: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2901, 0x36ba, x86_l_36ba);
x86_l_2907:
	/* 0x2907: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_290d:
	/* 0x290d: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2910:
	/* 0x2910: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2913:
	/* 0x2913: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2913, 0x34f8, x86_l_34f8);
x86_l_2919:
	/* 0x2919: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_291d:
	/* 0x291d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2920:
	/* 0x2920: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2923:
	/* 0x2923: je     298d <trace_mmap_alert+0x298d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2923, 0x298d, x86_l_298d);
x86_l_2925:
	/* 0x2925: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2929:
	/* 0x2929: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_292e:
	/* 0x292e: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2932:
	/* 0x2932: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2935:
	/* 0x2935: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2938:
	/* 0x2938: jne    2920 <trace_mmap_alert+0x2920> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2938, 0x2920, x86_l_2920);
x86_l_293a:
	/* 0x293a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_293d:
	/* 0x293d: jmp    2992 <trace_mmap_alert+0x2992> */
	X86_SIM_X86_JMP(0x293d, 0x2992, x86_l_2992);
x86_l_293f:
	/* 0x293f: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2942:
	/* 0x2942: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2942, 0x36ba, x86_l_36ba);
x86_l_2948:
	/* 0x2948: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_294b:
	/* 0x294b: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x294b, 0x36ba, x86_l_36ba);
x86_l_2951:
	/* 0x2951: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2955:
	/* 0x2955: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2958:
	/* 0x2958: jns    295f <trace_mmap_alert+0x295f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2958, 0x295f, x86_l_295f);
x86_l_295a:
	/* 0x295a: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_295d:
	/* 0x295d: jmp    2961 <trace_mmap_alert+0x2961> */
	X86_SIM_X86_JMP(0x295d, 0x2961, x86_l_2961);
x86_l_295f:
	/* 0x295f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2961:
	/* 0x2961: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2964:
	/* 0x2964: jns    296b <trace_mmap_alert+0x296b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2964, 0x296b, x86_l_296b);
x86_l_2966:
	/* 0x2966: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2969:
	/* 0x2969: jmp    296d <trace_mmap_alert+0x296d> */
	X86_SIM_X86_JMP(0x2969, 0x296d, x86_l_296d);
x86_l_296b:
	/* 0x296b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_296d:
	/* 0x296d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2970:
	/* 0x2970: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2973:
	/* 0x2973: jns    297a <trace_mmap_alert+0x297a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2973, 0x297a, x86_l_297a);
x86_l_2975:
	/* 0x2975: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2978:
	/* 0x2978: jmp    297c <trace_mmap_alert+0x297c> */
	X86_SIM_X86_JMP(0x2978, 0x297c, x86_l_297c);
x86_l_297a:
	/* 0x297a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_297c:
	/* 0x297c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2980:
	/* 0x2980: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2983:
	/* 0x2983: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2986:
	/* 0x2986: jns    29be <trace_mmap_alert+0x29be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2986, 0x29be, x86_l_29be);
x86_l_2988:
	/* 0x2988: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_298b:
	/* 0x298b: jmp    29c0 <trace_mmap_alert+0x29c0> */
	X86_SIM_X86_JMP(0x298b, 0x29c0, x86_l_29c0);
x86_l_298d:
	/* 0x298d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2992:
	/* 0x2992: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2996:
	/* 0x2996: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2996, 0x36ba, x86_l_36ba);
x86_l_299c:
	/* 0x299c: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29a0:
	/* 0x29a0: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29a4:
	/* 0x29a4: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_29aa:
	/* 0x29aa: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_29af:
	/* 0x29af: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_29b2:
	/* 0x29b2: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b6:
	/* 0x29b6: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29b9:
	/* 0x29b9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29bc:
	/* 0x29bc: js     2988 <trace_mmap_alert+0x2988> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29bc, 0x2988, x86_l_2988);
x86_l_29be:
	/* 0x29be: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c0:
	/* 0x29c0: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29c4:
	/* 0x29c4: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_29c7:
	/* 0x29c7: jns    29ce <trace_mmap_alert+0x29ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29c7, 0x29ce, x86_l_29ce);
x86_l_29c9:
	/* 0x29c9: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29cc:
	/* 0x29cc: jmp    29d0 <trace_mmap_alert+0x29d0> */
	X86_SIM_X86_JMP(0x29cc, 0x29d0, x86_l_29d0);
x86_l_29ce:
	/* 0x29ce: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d0:
	/* 0x29d0: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29d3:
	/* 0x29d3: je     2a4f <trace_mmap_alert+0x2a4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29d3, 0x2a4f, x86_l_2a4f);
x86_l_29d5:
	/* 0x29d5: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_29d8:
	/* 0x29d8: je     2a4f <trace_mmap_alert+0x2a4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29d8, 0x2a4f, x86_l_2a4f);
x86_l_29da:
	/* 0x29da: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29de:
	/* 0x29de: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e1:
	/* 0x29e1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_29e7:
	/* 0x29e7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29ea:
	/* 0x29ea: jns    29f3 <trace_mmap_alert+0x29f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ea, 0x29f3, x86_l_29f3);
x86_l_29ec:
	/* 0x29ec: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ef:
	/* 0x29ef: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29f3:
	/* 0x29f3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_29f7:
	/* 0x29f7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_29fa:
	/* 0x29fa: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a01:
	/* 0x2a01: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a05:
	/* 0x2a05: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a08:
	/* 0x2a08: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a08, 0x3780, x86_l_3780);
x86_l_2a0e:
	/* 0x2a0e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2a11:
	/* 0x2a11: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a11, 0x36bd, x86_l_36bd);
x86_l_2a17:
	/* 0x2a17: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a1d:
	/* 0x2a1d: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a20:
	/* 0x2a20: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2a23:
	/* 0x2a23: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a23, 0x34f5, x86_l_34f5);
x86_l_2a29:
	/* 0x2a29: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a2d:
	/* 0x2a2d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a30:
	/* 0x2a30: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2a33:
	/* 0x2a33: je     2a9d <trace_mmap_alert+0x2a9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a33, 0x2a9d, x86_l_2a9d);
x86_l_2a35:
	/* 0x2a35: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a39:
	/* 0x2a39: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2a3e:
	/* 0x2a3e: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2a42:
	/* 0x2a42: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a45:
	/* 0x2a45: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2a48:
	/* 0x2a48: jne    2a30 <trace_mmap_alert+0x2a30> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a48, 0x2a30, x86_l_2a30);
x86_l_2a4a:
	/* 0x2a4a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2a4d:
	/* 0x2a4d: jmp    2aa2 <trace_mmap_alert+0x2aa2> */
	X86_SIM_X86_JMP(0x2a4d, 0x2aa2, x86_l_2aa2);
x86_l_2a4f:
	/* 0x2a4f: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a52:
	/* 0x2a52: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a52, 0x36bd, x86_l_36bd);
x86_l_2a58:
	/* 0x2a58: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a5b:
	/* 0x2a5b: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a5b, 0x36bd, x86_l_36bd);
x86_l_2a61:
	/* 0x2a61: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a65:
	/* 0x2a65: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a68:
	/* 0x2a68: jns    2a6f <trace_mmap_alert+0x2a6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a68, 0x2a6f, x86_l_2a6f);
x86_l_2a6a:
	/* 0x2a6a: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a6d:
	/* 0x2a6d: jmp    2a71 <trace_mmap_alert+0x2a71> */
	X86_SIM_X86_JMP(0x2a6d, 0x2a71, x86_l_2a71);
x86_l_2a6f:
	/* 0x2a6f: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a71:
	/* 0x2a71: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a74:
	/* 0x2a74: jns    2a7b <trace_mmap_alert+0x2a7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a74, 0x2a7b, x86_l_2a7b);
x86_l_2a76:
	/* 0x2a76: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a79:
	/* 0x2a79: jmp    2a7d <trace_mmap_alert+0x2a7d> */
	X86_SIM_X86_JMP(0x2a79, 0x2a7d, x86_l_2a7d);
x86_l_2a7b:
	/* 0x2a7b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a7d:
	/* 0x2a7d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a80:
	/* 0x2a80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a83:
	/* 0x2a83: jns    2a8a <trace_mmap_alert+0x2a8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a83, 0x2a8a, x86_l_2a8a);
x86_l_2a85:
	/* 0x2a85: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a88:
	/* 0x2a88: jmp    2a8c <trace_mmap_alert+0x2a8c> */
	X86_SIM_X86_JMP(0x2a88, 0x2a8c, x86_l_2a8c);
x86_l_2a8a:
	/* 0x2a8a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a8c:
	/* 0x2a8c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a90:
	/* 0x2a90: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a93:
	/* 0x2a93: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a96:
	/* 0x2a96: jns    2acd <trace_mmap_alert+0x2acd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a96, 0x2acd, x86_l_2acd);
x86_l_2a98:
	/* 0x2a98: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a9b:
	/* 0x2a9b: jmp    2acf <trace_mmap_alert+0x2acf> */
	X86_SIM_X86_JMP(0x2a9b, 0x2acf, x86_l_2acf);
x86_l_2a9d:
	/* 0x2a9d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2aa2:
	/* 0x2aa2: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2aa6:
	/* 0x2aa6: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2aa6, 0x36bd, x86_l_36bd);
x86_l_2aac:
	/* 0x2aac: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab0:
	/* 0x2ab0: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ab3:
	/* 0x2ab3: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ab9:
	/* 0x2ab9: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2abe:
	/* 0x2abe: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2ac1:
	/* 0x2ac1: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ac5:
	/* 0x2ac5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ac8:
	/* 0x2ac8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2acb:
	/* 0x2acb: js     2a98 <trace_mmap_alert+0x2a98> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2acb, 0x2a98, x86_l_2a98);
x86_l_2acd:
	/* 0x2acd: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2acf:
	/* 0x2acf: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ad3:
	/* 0x2ad3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ad6:
	/* 0x2ad6: jns    2add <trace_mmap_alert+0x2add> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad6, 0x2add, x86_l_2add);
x86_l_2ad8:
	/* 0x2ad8: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2adb:
	/* 0x2adb: jmp    2adf <trace_mmap_alert+0x2adf> */
	X86_SIM_X86_JMP(0x2adb, 0x2adf, x86_l_2adf);
x86_l_2add:
	/* 0x2add: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2adf:
	/* 0x2adf: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2ae2:
	/* 0x2ae2: je     2b5e <trace_mmap_alert+0x2b5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ae2, 0x2b5e, x86_l_2b5e);
x86_l_2ae4:
	/* 0x2ae4: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ae7:
	/* 0x2ae7: je     2b5e <trace_mmap_alert+0x2b5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ae7, 0x2b5e, x86_l_2b5e);
x86_l_2ae9:
	/* 0x2ae9: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2aed:
	/* 0x2aed: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2af0:
	/* 0x2af0: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2af6:
	/* 0x2af6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2af9:
	/* 0x2af9: jns    2b02 <trace_mmap_alert+0x2b02> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2af9, 0x2b02, x86_l_2b02);
x86_l_2afb:
	/* 0x2afb: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2afe:
	/* 0x2afe: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b02:
	/* 0x2b02: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b06:
	/* 0x2b06: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b09:
	/* 0x2b09: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2b10:
	/* 0x2b10: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b14:
	/* 0x2b14: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b17:
	/* 0x2b17: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b17, 0x3780, x86_l_3780);
x86_l_2b1d:
	/* 0x2b1d: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2b20:
	/* 0x2b20: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b20, 0x36ba, x86_l_36ba);
x86_l_2b26:
	/* 0x2b26: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b2c:
	/* 0x2b2c: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b2f:
	/* 0x2b2f: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2b32:
	/* 0x2b32: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b32, 0x34f8, x86_l_34f8);
x86_l_2b38:
	/* 0x2b38: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2b3c:
	/* 0x2b3c: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b3f:
	/* 0x2b3f: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2b42:
	/* 0x2b42: je     2bac <trace_mmap_alert+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b42, 0x2bac, x86_l_2bac);
x86_l_2b44:
	/* 0x2b44: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b48:
	/* 0x2b48: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2b4d:
	/* 0x2b4d: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2b51:
	/* 0x2b51: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2b54:
	/* 0x2b54: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2b57:
	/* 0x2b57: jne    2b3f <trace_mmap_alert+0x2b3f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b57, 0x2b3f, x86_l_2b3f);
x86_l_2b59:
	/* 0x2b59: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2b5c:
	/* 0x2b5c: jmp    2bb1 <trace_mmap_alert+0x2bb1> */
	X86_SIM_X86_JMP(0x2b5c, 0x2bb1, x86_l_2bb1);
x86_l_2b5e:
	/* 0x2b5e: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2b61:
	/* 0x2b61: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b61, 0x36ba, x86_l_36ba);
x86_l_2b67:
	/* 0x2b67: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b6a:
	/* 0x2b6a: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b6a, 0x36ba, x86_l_36ba);
x86_l_2b70:
	/* 0x2b70: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b74:
	/* 0x2b74: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b77:
	/* 0x2b77: jns    2b7e <trace_mmap_alert+0x2b7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b77, 0x2b7e, x86_l_2b7e);
x86_l_2b79:
	/* 0x2b79: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b7c:
	/* 0x2b7c: jmp    2b80 <trace_mmap_alert+0x2b80> */
	X86_SIM_X86_JMP(0x2b7c, 0x2b80, x86_l_2b80);
x86_l_2b7e:
	/* 0x2b7e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b80:
	/* 0x2b80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b83:
	/* 0x2b83: jns    2b8a <trace_mmap_alert+0x2b8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b83, 0x2b8a, x86_l_2b8a);
x86_l_2b85:
	/* 0x2b85: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b88:
	/* 0x2b88: jmp    2b8c <trace_mmap_alert+0x2b8c> */
	X86_SIM_X86_JMP(0x2b88, 0x2b8c, x86_l_2b8c);
x86_l_2b8a:
	/* 0x2b8a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b8c:
	/* 0x2b8c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b8f:
	/* 0x2b8f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b92:
	/* 0x2b92: jns    2b99 <trace_mmap_alert+0x2b99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b92, 0x2b99, x86_l_2b99);
x86_l_2b94:
	/* 0x2b94: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b97:
	/* 0x2b97: jmp    2b9b <trace_mmap_alert+0x2b9b> */
	X86_SIM_X86_JMP(0x2b97, 0x2b9b, x86_l_2b9b);
x86_l_2b99:
	/* 0x2b99: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b9b:
	/* 0x2b9b: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b9f:
	/* 0x2b9f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ba2:
	/* 0x2ba2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2ba5:
	/* 0x2ba5: jns    2bdd <trace_mmap_alert+0x2bdd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ba5, 0x2bdd, x86_l_2bdd);
x86_l_2ba7:
	/* 0x2ba7: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2baa:
	/* 0x2baa: jmp    2bdf <trace_mmap_alert+0x2bdf> */
	X86_SIM_X86_JMP(0x2baa, 0x2bdf, x86_l_2bdf);
x86_l_2bac:
	/* 0x2bac: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2bb1:
	/* 0x2bb1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2bb5:
	/* 0x2bb5: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2bb5, 0x36ba, x86_l_36ba);
x86_l_2bbb:
	/* 0x2bbb: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bbf:
	/* 0x2bbf: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2bc3:
	/* 0x2bc3: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2bc9:
	/* 0x2bc9: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2bce:
	/* 0x2bce: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2bd1:
	/* 0x2bd1: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bd5:
	/* 0x2bd5: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bd8:
	/* 0x2bd8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2bdb:
	/* 0x2bdb: js     2ba7 <trace_mmap_alert+0x2ba7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bdb, 0x2ba7, x86_l_2ba7);
x86_l_2bdd:
	/* 0x2bdd: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bdf:
	/* 0x2bdf: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2be3:
	/* 0x2be3: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2be6:
	/* 0x2be6: jns    2bed <trace_mmap_alert+0x2bed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2be6, 0x2bed, x86_l_2bed);
x86_l_2be8:
	/* 0x2be8: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2beb:
	/* 0x2beb: jmp    2bef <trace_mmap_alert+0x2bef> */
	X86_SIM_X86_JMP(0x2beb, 0x2bef, x86_l_2bef);
x86_l_2bed:
	/* 0x2bed: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bef:
	/* 0x2bef: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2bf2:
	/* 0x2bf2: je     2c6e <trace_mmap_alert+0x2c6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bf2, 0x2c6e, x86_l_2c6e);
x86_l_2bf4:
	/* 0x2bf4: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2bf7:
	/* 0x2bf7: je     2c6e <trace_mmap_alert+0x2c6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bf7, 0x2c6e, x86_l_2c6e);
x86_l_2bf9:
	/* 0x2bf9: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bfd:
	/* 0x2bfd: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c00:
	/* 0x2c00: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2c06:
	/* 0x2c06: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c09:
	/* 0x2c09: jns    2c12 <trace_mmap_alert+0x2c12> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c09, 0x2c12, x86_l_2c12);
x86_l_2c0b:
	/* 0x2c0b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c0e:
	/* 0x2c0e: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c12:
	/* 0x2c12: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2c16:
	/* 0x2c16: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2c19:
	/* 0x2c19: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2c20:
	/* 0x2c20: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c24:
	/* 0x2c24: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2c27:
	/* 0x2c27: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c27, 0x3780, x86_l_3780);
x86_l_2c2d:
	/* 0x2c2d: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2c30:
	/* 0x2c30: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c30, 0x36bd, x86_l_36bd);
x86_l_2c36:
	/* 0x2c36: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2c3c:
	/* 0x2c3c: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c3f:
	/* 0x2c3f: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2c42:
	/* 0x2c42: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c42, 0x34f5, x86_l_34f5);
x86_l_2c48:
	/* 0x2c48: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2c4c:
	/* 0x2c4c: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c4f:
	/* 0x2c4f: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2c52:
	/* 0x2c52: je     2cbc <trace_mmap_alert+0x2cbc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c52, 0x2cbc, x86_l_2cbc);
x86_l_2c54:
	/* 0x2c54: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2c58:
	/* 0x2c58: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2c5d:
	/* 0x2c5d: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2c61:
	/* 0x2c61: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2c64:
	/* 0x2c64: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2c67:
	/* 0x2c67: jne    2c4f <trace_mmap_alert+0x2c4f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c67, 0x2c4f, x86_l_2c4f);
x86_l_2c69:
	/* 0x2c69: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2c6c:
	/* 0x2c6c: jmp    2cc1 <trace_mmap_alert+0x2cc1> */
	X86_SIM_X86_JMP(0x2c6c, 0x2cc1, x86_l_2cc1);
x86_l_2c6e:
	/* 0x2c6e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c71:
	/* 0x2c71: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c71, 0x36bd, x86_l_36bd);
x86_l_2c77:
	/* 0x2c77: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c7a:
	/* 0x2c7a: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c7a, 0x36bd, x86_l_36bd);
x86_l_2c80:
	/* 0x2c80: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c84:
	/* 0x2c84: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c87:
	/* 0x2c87: jns    2c8e <trace_mmap_alert+0x2c8e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c87, 0x2c8e, x86_l_2c8e);
x86_l_2c89:
	/* 0x2c89: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8c:
	/* 0x2c8c: jmp    2c90 <trace_mmap_alert+0x2c90> */
	X86_SIM_X86_JMP(0x2c8c, 0x2c90, x86_l_2c90);
x86_l_2c8e:
	/* 0x2c8e: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c90:
	/* 0x2c90: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c93:
	/* 0x2c93: jns    2c9a <trace_mmap_alert+0x2c9a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c93, 0x2c9a, x86_l_2c9a);
x86_l_2c95:
	/* 0x2c95: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c98:
	/* 0x2c98: jmp    2c9c <trace_mmap_alert+0x2c9c> */
	X86_SIM_X86_JMP(0x2c98, 0x2c9c, x86_l_2c9c);
x86_l_2c9a:
	/* 0x2c9a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c9c:
	/* 0x2c9c: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c9f:
	/* 0x2c9f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ca2:
	/* 0x2ca2: jns    2ca9 <trace_mmap_alert+0x2ca9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ca2, 0x2ca9, x86_l_2ca9);
x86_l_2ca4:
	/* 0x2ca4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ca7:
	/* 0x2ca7: jmp    2cab <trace_mmap_alert+0x2cab> */
	X86_SIM_X86_JMP(0x2ca7, 0x2cab, x86_l_2cab);
x86_l_2ca9:
	/* 0x2ca9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cab:
	/* 0x2cab: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2caf:
	/* 0x2caf: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2cb2:
	/* 0x2cb2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2cb5:
	/* 0x2cb5: jns    2cec <trace_mmap_alert+0x2cec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cb5, 0x2cec, x86_l_2cec);
x86_l_2cb7:
	/* 0x2cb7: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cba:
	/* 0x2cba: jmp    2cee <trace_mmap_alert+0x2cee> */
	X86_SIM_X86_JMP(0x2cba, 0x2cee, x86_l_2cee);
x86_l_2cbc:
	/* 0x2cbc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2cc1:
	/* 0x2cc1: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2cc5:
	/* 0x2cc5: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2cc5, 0x36bd, x86_l_36bd);
x86_l_2ccb:
	/* 0x2ccb: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ccf:
	/* 0x2ccf: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2cd2:
	/* 0x2cd2: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2cd8:
	/* 0x2cd8: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2cdd:
	/* 0x2cdd: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2ce0:
	/* 0x2ce0: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ce4:
	/* 0x2ce4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ce7:
	/* 0x2ce7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2cea:
	/* 0x2cea: js     2cb7 <trace_mmap_alert+0x2cb7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2cea, 0x2cb7, x86_l_2cb7);
x86_l_2cec:
	/* 0x2cec: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cee:
	/* 0x2cee: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cf2:
	/* 0x2cf2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2cf5:
	/* 0x2cf5: jns    2cfc <trace_mmap_alert+0x2cfc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cf5, 0x2cfc, x86_l_2cfc);
x86_l_2cf7:
	/* 0x2cf7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cfa:
	/* 0x2cfa: jmp    2cfe <trace_mmap_alert+0x2cfe> */
	X86_SIM_X86_JMP(0x2cfa, 0x2cfe, x86_l_2cfe);
x86_l_2cfc:
	/* 0x2cfc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cfe:
	/* 0x2cfe: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2d01:
	/* 0x2d01: je     2d7d <trace_mmap_alert+0x2d7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d01, 0x2d7d, x86_l_2d7d);
x86_l_2d03:
	/* 0x2d03: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2d06:
	/* 0x2d06: je     2d7d <trace_mmap_alert+0x2d7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d06, 0x2d7d, x86_l_2d7d);
x86_l_2d08:
	/* 0x2d08: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d0c:
	/* 0x2d0c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d0f:
	/* 0x2d0f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2d15:
	/* 0x2d15: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2d18:
	/* 0x2d18: jns    2d21 <trace_mmap_alert+0x2d21> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d18, 0x2d21, x86_l_2d21);
x86_l_2d1a:
	/* 0x2d1a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d1d:
	/* 0x2d1d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d21:
	/* 0x2d21: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2d25:
	/* 0x2d25: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2d28:
	/* 0x2d28: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2d2f:
	/* 0x2d2f: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d33:
	/* 0x2d33: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2d36:
	/* 0x2d36: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d36, 0x3780, x86_l_3780);
x86_l_2d3c:
	/* 0x2d3c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2d3f:
	/* 0x2d3f: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d3f, 0x36ba, x86_l_36ba);
x86_l_2d45:
	/* 0x2d45: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2d4b:
	/* 0x2d4b: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2d4e:
	/* 0x2d4e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2d51:
	/* 0x2d51: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d51, 0x34f8, x86_l_34f8);
x86_l_2d57:
	/* 0x2d57: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2d5b:
	/* 0x2d5b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d5e:
	/* 0x2d5e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2d61:
	/* 0x2d61: je     2dcb <trace_mmap_alert+0x2dcb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d61, 0x2dcb, x86_l_2dcb);
x86_l_2d63:
	/* 0x2d63: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2d67:
	/* 0x2d67: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2d6c:
	/* 0x2d6c: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2d70:
	/* 0x2d70: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2d73:
	/* 0x2d73: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2d76:
	/* 0x2d76: jne    2d5e <trace_mmap_alert+0x2d5e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d76, 0x2d5e, x86_l_2d5e);
x86_l_2d78:
	/* 0x2d78: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2d7b:
	/* 0x2d7b: jmp    2dd0 <trace_mmap_alert+0x2dd0> */
	X86_SIM_X86_JMP(0x2d7b, 0x2dd0, x86_l_2dd0);
x86_l_2d7d:
	/* 0x2d7d: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2d80:
	/* 0x2d80: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d80, 0x36ba, x86_l_36ba);
x86_l_2d86:
	/* 0x2d86: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d89:
	/* 0x2d89: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d89, 0x36ba, x86_l_36ba);
x86_l_2d8f:
	/* 0x2d8f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d93:
	/* 0x2d93: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2d96:
	/* 0x2d96: jns    2d9d <trace_mmap_alert+0x2d9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d96, 0x2d9d, x86_l_2d9d);
x86_l_2d98:
	/* 0x2d98: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d9b:
	/* 0x2d9b: jmp    2d9f <trace_mmap_alert+0x2d9f> */
	X86_SIM_X86_JMP(0x2d9b, 0x2d9f, x86_l_2d9f);
x86_l_2d9d:
	/* 0x2d9d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d9f:
	/* 0x2d9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2da2:
	/* 0x2da2: jns    2da9 <trace_mmap_alert+0x2da9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2da2, 0x2da9, x86_l_2da9);
x86_l_2da4:
	/* 0x2da4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da7:
	/* 0x2da7: jmp    2dab <trace_mmap_alert+0x2dab> */
	X86_SIM_X86_JMP(0x2da7, 0x2dab, x86_l_2dab);
x86_l_2da9:
	/* 0x2da9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dab:
	/* 0x2dab: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dae:
	/* 0x2dae: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2db1:
	/* 0x2db1: jns    2db8 <trace_mmap_alert+0x2db8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2db1, 0x2db8, x86_l_2db8);
x86_l_2db3:
	/* 0x2db3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db6:
	/* 0x2db6: jmp    2dba <trace_mmap_alert+0x2dba> */
	X86_SIM_X86_JMP(0x2db6, 0x2dba, x86_l_2dba);
x86_l_2db8:
	/* 0x2db8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dba:
	/* 0x2dba: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2dbe:
	/* 0x2dbe: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2dc1:
	/* 0x2dc1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2dc4:
	/* 0x2dc4: jns    2dfc <trace_mmap_alert+0x2dfc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dc4, 0x2dfc, x86_l_2dfc);
x86_l_2dc6:
	/* 0x2dc6: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dc9:
	/* 0x2dc9: jmp    2dfe <trace_mmap_alert+0x2dfe> */
	X86_SIM_X86_JMP(0x2dc9, 0x2dfe, x86_l_2dfe);
x86_l_2dcb:
	/* 0x2dcb: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2dd0:
	/* 0x2dd0: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2dd4:
	/* 0x2dd4: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2dd4, 0x36ba, x86_l_36ba);
x86_l_2dda:
	/* 0x2dda: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dde:
	/* 0x2dde: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2de2:
	/* 0x2de2: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2de8:
	/* 0x2de8: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2ded:
	/* 0x2ded: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2df0:
	/* 0x2df0: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2df4:
	/* 0x2df4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2df7:
	/* 0x2df7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2dfa:
	/* 0x2dfa: js     2dc6 <trace_mmap_alert+0x2dc6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dfa, 0x2dc6, x86_l_2dc6);
x86_l_2dfc:
	/* 0x2dfc: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2dfe:
	/* 0x2dfe: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e02:
	/* 0x2e02: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2e05:
	/* 0x2e05: jns    2e0c <trace_mmap_alert+0x2e0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e05, 0x2e0c, x86_l_2e0c);
x86_l_2e07:
	/* 0x2e07: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e0a:
	/* 0x2e0a: jmp    2e0e <trace_mmap_alert+0x2e0e> */
	X86_SIM_X86_JMP(0x2e0a, 0x2e0e, x86_l_2e0e);
x86_l_2e0c:
	/* 0x2e0c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e0e:
	/* 0x2e0e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2e11:
	/* 0x2e11: je     2e8d <trace_mmap_alert+0x2e8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e11, 0x2e8d, x86_l_2e8d);
x86_l_2e13:
	/* 0x2e13: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e16:
	/* 0x2e16: je     2e8d <trace_mmap_alert+0x2e8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e16, 0x2e8d, x86_l_2e8d);
x86_l_2e18:
	/* 0x2e18: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e1c:
	/* 0x2e1c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e1f:
	/* 0x2e1f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2e25:
	/* 0x2e25: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2e28:
	/* 0x2e28: jns    2e31 <trace_mmap_alert+0x2e31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e28, 0x2e31, x86_l_2e31);
x86_l_2e2a:
	/* 0x2e2a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e2d:
	/* 0x2e2d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e31:
	/* 0x2e31: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2e35:
	/* 0x2e35: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2e38:
	/* 0x2e38: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2e3f:
	/* 0x2e3f: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e43:
	/* 0x2e43: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2e46:
	/* 0x2e46: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e46, 0x3780, x86_l_3780);
x86_l_2e4c:
	/* 0x2e4c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2e4f:
	/* 0x2e4f: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e4f, 0x36bd, x86_l_36bd);
x86_l_2e55:
	/* 0x2e55: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2e5b:
	/* 0x2e5b: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e5e:
	/* 0x2e5e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2e61:
	/* 0x2e61: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e61, 0x34f5, x86_l_34f5);
x86_l_2e67:
	/* 0x2e67: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2e6b:
	/* 0x2e6b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e6e:
	/* 0x2e6e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2e71:
	/* 0x2e71: je     2edb <trace_mmap_alert+0x2edb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e71, 0x2edb, x86_l_2edb);
x86_l_2e73:
	/* 0x2e73: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2e77:
	/* 0x2e77: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2e7c:
	/* 0x2e7c: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2e80:
	/* 0x2e80: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2e83:
	/* 0x2e83: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2e86:
	/* 0x2e86: jne    2e6e <trace_mmap_alert+0x2e6e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e86, 0x2e6e, x86_l_2e6e);
x86_l_2e88:
	/* 0x2e88: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2e8b:
	/* 0x2e8b: jmp    2ee0 <trace_mmap_alert+0x2ee0> */
	X86_SIM_X86_JMP(0x2e8b, 0x2ee0, x86_l_2ee0);
x86_l_2e8d:
	/* 0x2e8d: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2e90:
	/* 0x2e90: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e90, 0x36bd, x86_l_36bd);
x86_l_2e96:
	/* 0x2e96: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e99:
	/* 0x2e99: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e99, 0x36bd, x86_l_36bd);
x86_l_2e9f:
	/* 0x2e9f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ea3:
	/* 0x2ea3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ea6:
	/* 0x2ea6: jns    2ead <trace_mmap_alert+0x2ead> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ea6, 0x2ead, x86_l_2ead);
x86_l_2ea8:
	/* 0x2ea8: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eab:
	/* 0x2eab: jmp    2eaf <trace_mmap_alert+0x2eaf> */
	X86_SIM_X86_JMP(0x2eab, 0x2eaf, x86_l_2eaf);
x86_l_2ead:
	/* 0x2ead: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eaf:
	/* 0x2eaf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eb2:
	/* 0x2eb2: jns    2eb9 <trace_mmap_alert+0x2eb9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb2, 0x2eb9, x86_l_2eb9);
x86_l_2eb4:
	/* 0x2eb4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb7:
	/* 0x2eb7: jmp    2ebb <trace_mmap_alert+0x2ebb> */
	X86_SIM_X86_JMP(0x2eb7, 0x2ebb, x86_l_2ebb);
x86_l_2eb9:
	/* 0x2eb9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ebb:
	/* 0x2ebb: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ebe:
	/* 0x2ebe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ec1:
	/* 0x2ec1: jns    2ec8 <trace_mmap_alert+0x2ec8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ec1, 0x2ec8, x86_l_2ec8);
x86_l_2ec3:
	/* 0x2ec3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ec6:
	/* 0x2ec6: jmp    2eca <trace_mmap_alert+0x2eca> */
	X86_SIM_X86_JMP(0x2ec6, 0x2eca, x86_l_2eca);
x86_l_2ec8:
	/* 0x2ec8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eca:
	/* 0x2eca: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ece:
	/* 0x2ece: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ed1:
	/* 0x2ed1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ed4:
	/* 0x2ed4: jns    2f0b <trace_mmap_alert+0x2f0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ed4, 0x2f0b, x86_l_2f0b);
x86_l_2ed6:
	/* 0x2ed6: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ed9:
	/* 0x2ed9: jmp    2f0d <trace_mmap_alert+0x2f0d> */
	X86_SIM_X86_JMP(0x2ed9, 0x2f0d, x86_l_2f0d);
x86_l_2edb:
	/* 0x2edb: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2ee0:
	/* 0x2ee0: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2ee4:
	/* 0x2ee4: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ee4, 0x36bd, x86_l_36bd);
x86_l_2eea:
	/* 0x2eea: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eee:
	/* 0x2eee: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ef1:
	/* 0x2ef1: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ef7:
	/* 0x2ef7: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2efc:
	/* 0x2efc: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2eff:
	/* 0x2eff: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f03:
	/* 0x2f03: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f06:
	/* 0x2f06: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f09:
	/* 0x2f09: js     2ed6 <trace_mmap_alert+0x2ed6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f09, 0x2ed6, x86_l_2ed6);
x86_l_2f0b:
	/* 0x2f0b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f0d:
	/* 0x2f0d: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f11:
	/* 0x2f11: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f14:
	/* 0x2f14: jns    2f1b <trace_mmap_alert+0x2f1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f14, 0x2f1b, x86_l_2f1b);
x86_l_2f16:
	/* 0x2f16: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f19:
	/* 0x2f19: jmp    2f1d <trace_mmap_alert+0x2f1d> */
	X86_SIM_X86_JMP(0x2f19, 0x2f1d, x86_l_2f1d);
x86_l_2f1b:
	/* 0x2f1b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f1d:
	/* 0x2f1d: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f20:
	/* 0x2f20: je     2f9c <trace_mmap_alert+0x2f9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f20, 0x2f9c, x86_l_2f9c);
x86_l_2f22:
	/* 0x2f22: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f25:
	/* 0x2f25: je     2f9c <trace_mmap_alert+0x2f9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f25, 0x2f9c, x86_l_2f9c);
x86_l_2f27:
	/* 0x2f27: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f2b:
	/* 0x2f2b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f2e:
	/* 0x2f2e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2f34:
	/* 0x2f34: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f37:
	/* 0x2f37: jns    2f40 <trace_mmap_alert+0x2f40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f37, 0x2f40, x86_l_2f40);
x86_l_2f39:
	/* 0x2f39: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f3c:
	/* 0x2f3c: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f40:
	/* 0x2f40: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2f44:
	/* 0x2f44: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2f47:
	/* 0x2f47: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2f4e:
	/* 0x2f4e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f52:
	/* 0x2f52: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2f55:
	/* 0x2f55: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2f55, 0x3780, x86_l_3780);
x86_l_2f5b:
	/* 0x2f5b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2f5e:
	/* 0x2f5e: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f5e, 0x36ba, x86_l_36ba);
x86_l_2f64:
	/* 0x2f64: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2f6a:
	/* 0x2f6a: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f6d:
	/* 0x2f6d: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2f70:
	/* 0x2f70: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f70, 0x34f8, x86_l_34f8);
x86_l_2f76:
	/* 0x2f76: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2f7a:
	/* 0x2f7a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f7d:
	/* 0x2f7d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2f80:
	/* 0x2f80: je     2fea <trace_mmap_alert+0x2fea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f80, 0x2fea, x86_l_2fea);
x86_l_2f82:
	/* 0x2f82: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2f86:
	/* 0x2f86: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2f8b:
	/* 0x2f8b: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2f8f:
	/* 0x2f8f: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2f92:
	/* 0x2f92: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_2f95:
	/* 0x2f95: jne    2f7d <trace_mmap_alert+0x2f7d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f95, 0x2f7d, x86_l_2f7d);
x86_l_2f97:
	/* 0x2f97: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2f9a:
	/* 0x2f9a: jmp    2fef <trace_mmap_alert+0x2fef> */
	X86_SIM_X86_JMP(0x2f9a, 0x2fef, x86_l_2fef);
x86_l_2f9c:
	/* 0x2f9c: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f9f:
	/* 0x2f9f: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f9f, 0x36ba, x86_l_36ba);
x86_l_2fa5:
	/* 0x2fa5: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fa8:
	/* 0x2fa8: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fa8, 0x36ba, x86_l_36ba);
x86_l_2fae:
	/* 0x2fae: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fb2:
	/* 0x2fb2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fb5:
	/* 0x2fb5: jns    2fbc <trace_mmap_alert+0x2fbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fb5, 0x2fbc, x86_l_2fbc);
x86_l_2fb7:
	/* 0x2fb7: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fba:
	/* 0x2fba: jmp    2fbe <trace_mmap_alert+0x2fbe> */
	X86_SIM_X86_JMP(0x2fba, 0x2fbe, x86_l_2fbe);
x86_l_2fbc:
	/* 0x2fbc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fbe:
	/* 0x2fbe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fc1:
	/* 0x2fc1: jns    2fc8 <trace_mmap_alert+0x2fc8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fc1, 0x2fc8, x86_l_2fc8);
x86_l_2fc3:
	/* 0x2fc3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc6:
	/* 0x2fc6: jmp    2fca <trace_mmap_alert+0x2fca> */
	X86_SIM_X86_JMP(0x2fc6, 0x2fca, x86_l_2fca);
x86_l_2fc8:
	/* 0x2fc8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fca:
	/* 0x2fca: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fcd:
	/* 0x2fcd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fd0:
	/* 0x2fd0: jns    2fd7 <trace_mmap_alert+0x2fd7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd0, 0x2fd7, x86_l_2fd7);
x86_l_2fd2:
	/* 0x2fd2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd5:
	/* 0x2fd5: jmp    2fd9 <trace_mmap_alert+0x2fd9> */
	X86_SIM_X86_JMP(0x2fd5, 0x2fd9, x86_l_2fd9);
x86_l_2fd7:
	/* 0x2fd7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fd9:
	/* 0x2fd9: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fdd:
	/* 0x2fdd: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fe0:
	/* 0x2fe0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2fe3:
	/* 0x2fe3: jns    301b <trace_mmap_alert+0x301b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fe3, 0x301b, x86_l_301b);
x86_l_2fe5:
	/* 0x2fe5: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe8:
	/* 0x2fe8: jmp    301d <trace_mmap_alert+0x301d> */
	X86_SIM_X86_JMP(0x2fe8, 0x301d, x86_l_301d);
x86_l_2fea:
	/* 0x2fea: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2fef:
	/* 0x2fef: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2ff3:
	/* 0x2ff3: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ff3, 0x36ba, x86_l_36ba);
x86_l_2ff9:
	/* 0x2ff9: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ffd:
	/* 0x2ffd: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3001:
	/* 0x3001: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3007:
	/* 0x3007: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_300c:
	/* 0x300c: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_300f:
	/* 0x300f: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3013:
	/* 0x3013: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3016:
	/* 0x3016: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3019:
	/* 0x3019: js     2fe5 <trace_mmap_alert+0x2fe5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3019, 0x2fe5, x86_l_2fe5);
x86_l_301b:
	/* 0x301b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_301d:
	/* 0x301d: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3021:
	/* 0x3021: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3024:
	/* 0x3024: jns    302b <trace_mmap_alert+0x302b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3024, 0x302b, x86_l_302b);
x86_l_3026:
	/* 0x3026: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3029:
	/* 0x3029: jmp    302d <trace_mmap_alert+0x302d> */
	X86_SIM_X86_JMP(0x3029, 0x302d, x86_l_302d);
x86_l_302b:
	/* 0x302b: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_302d:
	/* 0x302d: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3030:
	/* 0x3030: je     30ac <trace_mmap_alert+0x30ac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3030, 0x30ac, x86_l_30ac);
x86_l_3032:
	/* 0x3032: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3035:
	/* 0x3035: je     30ac <trace_mmap_alert+0x30ac> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3035, 0x30ac, x86_l_30ac);
x86_l_3037:
	/* 0x3037: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_303b:
	/* 0x303b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_303e:
	/* 0x303e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3044:
	/* 0x3044: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3047:
	/* 0x3047: jns    3050 <trace_mmap_alert+0x3050> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3047, 0x3050, x86_l_3050);
x86_l_3049:
	/* 0x3049: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_304c:
	/* 0x304c: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3050:
	/* 0x3050: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3054:
	/* 0x3054: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3057:
	/* 0x3057: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_305e:
	/* 0x305e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3062:
	/* 0x3062: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3065:
	/* 0x3065: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3065, 0x3780, x86_l_3780);
x86_l_306b:
	/* 0x306b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_306e:
	/* 0x306e: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x306e, 0x36bd, x86_l_36bd);
x86_l_3074:
	/* 0x3074: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_307a:
	/* 0x307a: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_307d:
	/* 0x307d: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3080:
	/* 0x3080: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3080, 0x34f5, x86_l_34f5);
x86_l_3086:
	/* 0x3086: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_308a:
	/* 0x308a: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_308d:
	/* 0x308d: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_3090:
	/* 0x3090: je     30fa <trace_mmap_alert+0x30fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3090, 0x30fa, x86_l_30fa);
x86_l_3092:
	/* 0x3092: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3096:
	/* 0x3096: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_309b:
	/* 0x309b: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_309f:
	/* 0x309f: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_30a2:
	/* 0x30a2: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_30a5:
	/* 0x30a5: jne    308d <trace_mmap_alert+0x308d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30a5, 0x308d, x86_l_308d);
x86_l_30a7:
	/* 0x30a7: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_30aa:
	/* 0x30aa: jmp    30ff <trace_mmap_alert+0x30ff> */
	X86_SIM_X86_JMP(0x30aa, 0x30ff, x86_l_30ff);
x86_l_30ac:
	/* 0x30ac: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_30af:
	/* 0x30af: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30af, 0x36bd, x86_l_36bd);
x86_l_30b5:
	/* 0x30b5: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30b8:
	/* 0x30b8: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30b8, 0x36bd, x86_l_36bd);
x86_l_30be:
	/* 0x30be: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_30c2:
	/* 0x30c2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30c5:
	/* 0x30c5: jns    30cc <trace_mmap_alert+0x30cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30c5, 0x30cc, x86_l_30cc);
x86_l_30c7:
	/* 0x30c7: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30ca:
	/* 0x30ca: jmp    30ce <trace_mmap_alert+0x30ce> */
	X86_SIM_X86_JMP(0x30ca, 0x30ce, x86_l_30ce);
x86_l_30cc:
	/* 0x30cc: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30ce:
	/* 0x30ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30d1:
	/* 0x30d1: jns    30d8 <trace_mmap_alert+0x30d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30d1, 0x30d8, x86_l_30d8);
x86_l_30d3:
	/* 0x30d3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30d6:
	/* 0x30d6: jmp    30da <trace_mmap_alert+0x30da> */
	X86_SIM_X86_JMP(0x30d6, 0x30da, x86_l_30da);
x86_l_30d8:
	/* 0x30d8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30da:
	/* 0x30da: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30dd:
	/* 0x30dd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30e0:
	/* 0x30e0: jns    30e7 <trace_mmap_alert+0x30e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30e0, 0x30e7, x86_l_30e7);
x86_l_30e2:
	/* 0x30e2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30e5:
	/* 0x30e5: jmp    30e9 <trace_mmap_alert+0x30e9> */
	X86_SIM_X86_JMP(0x30e5, 0x30e9, x86_l_30e9);
x86_l_30e7:
	/* 0x30e7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30e9:
	/* 0x30e9: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30ed:
	/* 0x30ed: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_30f0:
	/* 0x30f0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_30f3:
	/* 0x30f3: jns    312a <trace_mmap_alert+0x312a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30f3, 0x312a, x86_l_312a);
x86_l_30f5:
	/* 0x30f5: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30f8:
	/* 0x30f8: jmp    312c <trace_mmap_alert+0x312c> */
	X86_SIM_X86_JMP(0x30f8, 0x312c, x86_l_312c);
x86_l_30fa:
	/* 0x30fa: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_30ff:
	/* 0x30ff: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3103:
	/* 0x3103: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3103, 0x36bd, x86_l_36bd);
x86_l_3109:
	/* 0x3109: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_310d:
	/* 0x310d: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3110:
	/* 0x3110: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3116:
	/* 0x3116: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_311b:
	/* 0x311b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_311e:
	/* 0x311e: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3122:
	/* 0x3122: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3125:
	/* 0x3125: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3128:
	/* 0x3128: js     30f5 <trace_mmap_alert+0x30f5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3128, 0x30f5, x86_l_30f5);
x86_l_312a:
	/* 0x312a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_312c:
	/* 0x312c: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3130:
	/* 0x3130: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3133:
	/* 0x3133: jns    313a <trace_mmap_alert+0x313a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3133, 0x313a, x86_l_313a);
x86_l_3135:
	/* 0x3135: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3138:
	/* 0x3138: jmp    313c <trace_mmap_alert+0x313c> */
	X86_SIM_X86_JMP(0x3138, 0x313c, x86_l_313c);
x86_l_313a:
	/* 0x313a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_313c:
	/* 0x313c: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_313f:
	/* 0x313f: je     31bb <trace_mmap_alert+0x31bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x313f, 0x31bb, x86_l_31bb);
x86_l_3141:
	/* 0x3141: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3144:
	/* 0x3144: je     31bb <trace_mmap_alert+0x31bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3144, 0x31bb, x86_l_31bb);
x86_l_3146:
	/* 0x3146: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_314a:
	/* 0x314a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_314d:
	/* 0x314d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3153:
	/* 0x3153: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3156:
	/* 0x3156: jns    315f <trace_mmap_alert+0x315f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3156, 0x315f, x86_l_315f);
x86_l_3158:
	/* 0x3158: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_315b:
	/* 0x315b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_315f:
	/* 0x315f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3163:
	/* 0x3163: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3166:
	/* 0x3166: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_316d:
	/* 0x316d: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3171:
	/* 0x3171: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3174:
	/* 0x3174: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3174, 0x3780, x86_l_3780);
x86_l_317a:
	/* 0x317a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_317d:
	/* 0x317d: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x317d, 0x36ba, x86_l_36ba);
x86_l_3183:
	/* 0x3183: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3189:
	/* 0x3189: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_318c:
	/* 0x318c: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_318f:
	/* 0x318f: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x318f, 0x34f8, x86_l_34f8);
x86_l_3195:
	/* 0x3195: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3199:
	/* 0x3199: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_319c:
	/* 0x319c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_319f:
	/* 0x319f: je     3209 <trace_mmap_alert+0x3209> */
	X86_SIM_X86_JCC(X86_CC_E, 0x319f, 0x3209, x86_l_3209);
x86_l_31a1:
	/* 0x31a1: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_31a5:
	/* 0x31a5: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_31aa:
	/* 0x31aa: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_31ae:
	/* 0x31ae: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_31b1:
	/* 0x31b1: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_31b4:
	/* 0x31b4: jne    319c <trace_mmap_alert+0x319c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31b4, 0x319c, x86_l_319c);
x86_l_31b6:
	/* 0x31b6: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_31b9:
	/* 0x31b9: jmp    320e <trace_mmap_alert+0x320e> */
	X86_SIM_X86_JMP(0x31b9, 0x320e, x86_l_320e);
x86_l_31bb:
	/* 0x31bb: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_31be:
	/* 0x31be: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31be, 0x36ba, x86_l_36ba);
x86_l_31c4:
	/* 0x31c4: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31c7:
	/* 0x31c7: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31c7, 0x36ba, x86_l_36ba);
x86_l_31cd:
	/* 0x31cd: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31d1:
	/* 0x31d1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31d4:
	/* 0x31d4: jns    31db <trace_mmap_alert+0x31db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31d4, 0x31db, x86_l_31db);
x86_l_31d6:
	/* 0x31d6: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d9:
	/* 0x31d9: jmp    31dd <trace_mmap_alert+0x31dd> */
	X86_SIM_X86_JMP(0x31d9, 0x31dd, x86_l_31dd);
x86_l_31db:
	/* 0x31db: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31dd:
	/* 0x31dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31e0:
	/* 0x31e0: jns    31e7 <trace_mmap_alert+0x31e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31e0, 0x31e7, x86_l_31e7);
x86_l_31e2:
	/* 0x31e2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31e5:
	/* 0x31e5: jmp    31e9 <trace_mmap_alert+0x31e9> */
	X86_SIM_X86_JMP(0x31e5, 0x31e9, x86_l_31e9);
x86_l_31e7:
	/* 0x31e7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31e9:
	/* 0x31e9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31ec:
	/* 0x31ec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31ef:
	/* 0x31ef: jns    31f6 <trace_mmap_alert+0x31f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31ef, 0x31f6, x86_l_31f6);
x86_l_31f1:
	/* 0x31f1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f4:
	/* 0x31f4: jmp    31f8 <trace_mmap_alert+0x31f8> */
	X86_SIM_X86_JMP(0x31f4, 0x31f8, x86_l_31f8);
x86_l_31f6:
	/* 0x31f6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31f8:
	/* 0x31f8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31fc:
	/* 0x31fc: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_31ff:
	/* 0x31ff: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3202:
	/* 0x3202: jns    323a <trace_mmap_alert+0x323a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3202, 0x323a, x86_l_323a);
x86_l_3204:
	/* 0x3204: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3207:
	/* 0x3207: jmp    323c <trace_mmap_alert+0x323c> */
	X86_SIM_X86_JMP(0x3207, 0x323c, x86_l_323c);
x86_l_3209:
	/* 0x3209: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_320e:
	/* 0x320e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3212:
	/* 0x3212: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3212, 0x36ba, x86_l_36ba);
x86_l_3218:
	/* 0x3218: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_321c:
	/* 0x321c: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3220:
	/* 0x3220: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3226:
	/* 0x3226: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_322b:
	/* 0x322b: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_322e:
	/* 0x322e: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3232:
	/* 0x3232: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3235:
	/* 0x3235: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3238:
	/* 0x3238: js     3204 <trace_mmap_alert+0x3204> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3238, 0x3204, x86_l_3204);
x86_l_323a:
	/* 0x323a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_323c:
	/* 0x323c: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3240:
	/* 0x3240: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3243:
	/* 0x3243: jns    324a <trace_mmap_alert+0x324a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3243, 0x324a, x86_l_324a);
x86_l_3245:
	/* 0x3245: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3248:
	/* 0x3248: jmp    324c <trace_mmap_alert+0x324c> */
	X86_SIM_X86_JMP(0x3248, 0x324c, x86_l_324c);
x86_l_324a:
	/* 0x324a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_324c:
	/* 0x324c: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_324f:
	/* 0x324f: je     32cb <trace_mmap_alert+0x32cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x324f, 0x32cb, x86_l_32cb);
x86_l_3251:
	/* 0x3251: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3254:
	/* 0x3254: je     32cb <trace_mmap_alert+0x32cb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3254, 0x32cb, x86_l_32cb);
x86_l_3256:
	/* 0x3256: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_325a:
	/* 0x325a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_325d:
	/* 0x325d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3263:
	/* 0x3263: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3266:
	/* 0x3266: jns    326f <trace_mmap_alert+0x326f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3266, 0x326f, x86_l_326f);
x86_l_3268:
	/* 0x3268: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_326b:
	/* 0x326b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_326f:
	/* 0x326f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3273:
	/* 0x3273: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3276:
	/* 0x3276: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_327d:
	/* 0x327d: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3281:
	/* 0x3281: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3284:
	/* 0x3284: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3284, 0x3780, x86_l_3780);
x86_l_328a:
	/* 0x328a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_328d:
	/* 0x328d: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x328d, 0x36bd, x86_l_36bd);
x86_l_3293:
	/* 0x3293: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3299:
	/* 0x3299: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_329c:
	/* 0x329c: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_329f:
	/* 0x329f: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x329f, 0x34f5, x86_l_34f5);
x86_l_32a5:
	/* 0x32a5: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_32a9:
	/* 0x32a9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32ac:
	/* 0x32ac: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_32af:
	/* 0x32af: je     3319 <trace_mmap_alert+0x3319> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32af, 0x3319, x86_l_3319);
x86_l_32b1:
	/* 0x32b1: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_32b5:
	/* 0x32b5: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_32ba:
	/* 0x32ba: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_32be:
	/* 0x32be: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_32c1:
	/* 0x32c1: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_32c4:
	/* 0x32c4: jne    32ac <trace_mmap_alert+0x32ac> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32c4, 0x32ac, x86_l_32ac);
x86_l_32c6:
	/* 0x32c6: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_32c9:
	/* 0x32c9: jmp    331e <trace_mmap_alert+0x331e> */
	X86_SIM_X86_JMP(0x32c9, 0x331e, x86_l_331e);
x86_l_32cb:
	/* 0x32cb: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_32ce:
	/* 0x32ce: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32ce, 0x36bd, x86_l_36bd);
x86_l_32d4:
	/* 0x32d4: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_32d7:
	/* 0x32d7: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32d7, 0x36bd, x86_l_36bd);
x86_l_32dd:
	/* 0x32dd: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32e1:
	/* 0x32e1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_32e4:
	/* 0x32e4: jns    32eb <trace_mmap_alert+0x32eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32e4, 0x32eb, x86_l_32eb);
x86_l_32e6:
	/* 0x32e6: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32e9:
	/* 0x32e9: jmp    32ed <trace_mmap_alert+0x32ed> */
	X86_SIM_X86_JMP(0x32e9, 0x32ed, x86_l_32ed);
x86_l_32eb:
	/* 0x32eb: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32ed:
	/* 0x32ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32f0:
	/* 0x32f0: jns    32f7 <trace_mmap_alert+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32f0, 0x32f7, x86_l_32f7);
x86_l_32f2:
	/* 0x32f2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32f5:
	/* 0x32f5: jmp    32f9 <trace_mmap_alert+0x32f9> */
	X86_SIM_X86_JMP(0x32f5, 0x32f9, x86_l_32f9);
x86_l_32f7:
	/* 0x32f7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32f9:
	/* 0x32f9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32fc:
	/* 0x32fc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_32ff:
	/* 0x32ff: jns    3306 <trace_mmap_alert+0x3306> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32ff, 0x3306, x86_l_3306);
x86_l_3301:
	/* 0x3301: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3304:
	/* 0x3304: jmp    3308 <trace_mmap_alert+0x3308> */
	X86_SIM_X86_JMP(0x3304, 0x3308, x86_l_3308);
x86_l_3306:
	/* 0x3306: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3308:
	/* 0x3308: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_330c:
	/* 0x330c: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_330f:
	/* 0x330f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3312:
	/* 0x3312: jns    3349 <trace_mmap_alert+0x3349> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3312, 0x3349, x86_l_3349);
x86_l_3314:
	/* 0x3314: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3317:
	/* 0x3317: jmp    334b <trace_mmap_alert+0x334b> */
	X86_SIM_X86_JMP(0x3317, 0x334b, x86_l_334b);
x86_l_3319:
	/* 0x3319: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_331e:
	/* 0x331e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3322:
	/* 0x3322: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3322, 0x36bd, x86_l_36bd);
x86_l_3328:
	/* 0x3328: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_332c:
	/* 0x332c: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_332f:
	/* 0x332f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3335:
	/* 0x3335: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_333a:
	/* 0x333a: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_333d:
	/* 0x333d: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3341:
	/* 0x3341: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3344:
	/* 0x3344: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3347:
	/* 0x3347: js     3314 <trace_mmap_alert+0x3314> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3347, 0x3314, x86_l_3314);
x86_l_3349:
	/* 0x3349: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_334b:
	/* 0x334b: lea    rdx,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_334f:
	/* 0x334f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3352:
	/* 0x3352: jns    3359 <trace_mmap_alert+0x3359> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3352, 0x3359, x86_l_3359);
x86_l_3354:
	/* 0x3354: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3357:
	/* 0x3357: jmp    335b <trace_mmap_alert+0x335b> */
	X86_SIM_X86_JMP(0x3357, 0x335b, x86_l_335b);
x86_l_3359:
	/* 0x3359: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_335b:
	/* 0x335b: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_335e:
	/* 0x335e: je     33da <trace_mmap_alert+0x33da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x335e, 0x33da, x86_l_33da);
x86_l_3360:
	/* 0x3360: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3363:
	/* 0x3363: je     33da <trace_mmap_alert+0x33da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3363, 0x33da, x86_l_33da);
x86_l_3365:
	/* 0x3365: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3369:
	/* 0x3369: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_336c:
	/* 0x336c: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3372:
	/* 0x3372: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3375:
	/* 0x3375: jns    337e <trace_mmap_alert+0x337e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3375, 0x337e, x86_l_337e);
x86_l_3377:
	/* 0x3377: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_337a:
	/* 0x337a: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_337e:
	/* 0x337e: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3382:
	/* 0x3382: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3385:
	/* 0x3385: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_338c:
	/* 0x338c: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3390:
	/* 0x3390: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3393:
	/* 0x3393: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3393, 0x3780, x86_l_3780);
x86_l_3399:
	/* 0x3399: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_339c:
	/* 0x339c: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x339c, 0x36ba, x86_l_36ba);
x86_l_33a2:
	/* 0x33a2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_33a8:
	/* 0x33a8: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_33ab:
	/* 0x33ab: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_33ae:
	/* 0x33ae: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33ae, 0x34f8, x86_l_34f8);
x86_l_33b4:
	/* 0x33b4: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_33b8:
	/* 0x33b8: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33bb:
	/* 0x33bb: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_33be:
	/* 0x33be: je     3428 <trace_mmap_alert+0x3428> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33be, 0x3428, x86_l_3428);
x86_l_33c0:
	/* 0x33c0: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_33c4:
	/* 0x33c4: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_33c9:
	/* 0x33c9: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_33cd:
	/* 0x33cd: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_33d0:
	/* 0x33d0: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_33d3:
	/* 0x33d3: jne    33bb <trace_mmap_alert+0x33bb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33d3, 0x33bb, x86_l_33bb);
x86_l_33d5:
	/* 0x33d5: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_33d8:
	/* 0x33d8: jmp    342d <trace_mmap_alert+0x342d> */
	X86_SIM_X86_JMP(0x33d8, 0x342d, x86_l_342d);
x86_l_33da:
	/* 0x33da: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_33dd:
	/* 0x33dd: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33dd, 0x36ba, x86_l_36ba);
x86_l_33e3:
	/* 0x33e3: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33e6:
	/* 0x33e6: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33e6, 0x36ba, x86_l_36ba);
x86_l_33ec:
	/* 0x33ec: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33f0:
	/* 0x33f0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_33f3:
	/* 0x33f3: jns    33fa <trace_mmap_alert+0x33fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33f3, 0x33fa, x86_l_33fa);
x86_l_33f5:
	/* 0x33f5: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33f8:
	/* 0x33f8: jmp    33fc <trace_mmap_alert+0x33fc> */
	X86_SIM_X86_JMP(0x33f8, 0x33fc, x86_l_33fc);
x86_l_33fa:
	/* 0x33fa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_33fc:
	/* 0x33fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33ff:
	/* 0x33ff: jns    3406 <trace_mmap_alert+0x3406> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33ff, 0x3406, x86_l_3406);
x86_l_3401:
	/* 0x3401: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3404:
	/* 0x3404: jmp    3408 <trace_mmap_alert+0x3408> */
	X86_SIM_X86_JMP(0x3404, 0x3408, x86_l_3408);
x86_l_3406:
	/* 0x3406: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3408:
	/* 0x3408: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_340b:
	/* 0x340b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_340e:
	/* 0x340e: jns    3415 <trace_mmap_alert+0x3415> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x340e, 0x3415, x86_l_3415);
x86_l_3410:
	/* 0x3410: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3413:
	/* 0x3413: jmp    3417 <trace_mmap_alert+0x3417> */
	X86_SIM_X86_JMP(0x3413, 0x3417, x86_l_3417);
x86_l_3415:
	/* 0x3415: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3417:
	/* 0x3417: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_341b:
	/* 0x341b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_341e:
	/* 0x341e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3421:
	/* 0x3421: jns    3459 <trace_mmap_alert+0x3459> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3421, 0x3459, x86_l_3459);
x86_l_3423:
	/* 0x3423: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3426:
	/* 0x3426: jmp    345b <trace_mmap_alert+0x345b> */
	X86_SIM_X86_JMP(0x3426, 0x345b, x86_l_345b);
x86_l_3428:
	/* 0x3428: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_342d:
	/* 0x342d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3431:
	/* 0x3431: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3431, 0x36ba, x86_l_36ba);
x86_l_3437:
	/* 0x3437: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_343b:
	/* 0x343b: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_343f:
	/* 0x343f: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3445:
	/* 0x3445: mov    BYTE PTR [r12+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_344a:
	/* 0x344a: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_344d:
	/* 0x344d: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3451:
	/* 0x3451: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3454:
	/* 0x3454: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3457:
	/* 0x3457: js     3423 <trace_mmap_alert+0x3423> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3457, 0x3423, x86_l_3423);
x86_l_3459:
	/* 0x3459: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_345b:
	/* 0x345b: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_345f:
	/* 0x345f: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3462:
	/* 0x3462: jns    3469 <trace_mmap_alert+0x3469> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3462, 0x3469, x86_l_3469);
x86_l_3464:
	/* 0x3464: mov    rbp,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3467:
	/* 0x3467: jmp    346b <trace_mmap_alert+0x346b> */
	X86_SIM_X86_JMP(0x3467, 0x346b, x86_l_346b);
x86_l_3469:
	/* 0x3469: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_346b:
	/* 0x346b: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_346e:
	/* 0x346e: je     3523 <trace_mmap_alert+0x3523> */
	X86_SIM_X86_JCC(X86_CC_E, 0x346e, 0x3523, x86_l_3523);
x86_l_3474:
	/* 0x3474: cmp    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_3477:
	/* 0x3477: je     3523 <trace_mmap_alert+0x3523> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3477, 0x3523, x86_l_3523);
x86_l_347d:
	/* 0x347d: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3481:
	/* 0x3481: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3484:
	/* 0x3484: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_348a:
	/* 0x348a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_348d:
	/* 0x348d: jns    3496 <trace_mmap_alert+0x3496> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x348d, 0x3496, x86_l_3496);
x86_l_348f:
	/* 0x348f: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3492:
	/* 0x3492: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3496:
	/* 0x3496: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_349a:
	/* 0x349a: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_349d:
	/* 0x349d: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_34a4:
	/* 0x34a4: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34a8:
	/* 0x34a8: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_34ab:
	/* 0x34ab: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x34ab, 0x3780, x86_l_3780);
x86_l_34b1:
	/* 0x34b1: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_34b4:
	/* 0x34b4: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34b4, 0x36bd, x86_l_36bd);
x86_l_34ba:
	/* 0x34ba: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_34c0:
	/* 0x34c0: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_34c3:
	/* 0x34c3: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_34c6:
	/* 0x34c6: jns    34f5 <trace_mmap_alert+0x34f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34c6, 0x34f5, x86_l_34f5);
x86_l_34c8:
	/* 0x34c8: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_34cc:
	/* 0x34cc: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_34cf:
	/* 0x34cf: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_34d2:
	/* 0x34d2: je     3571 <trace_mmap_alert+0x3571> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34d2, 0x3571, x86_l_3571);
x86_l_34d8:
	/* 0x34d8: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_34dc:
	/* 0x34dc: movzx  r15d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_34e1:
	/* 0x34e1: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_34e5:
	/* 0x34e5: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_34e8:
	/* 0x34e8: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_34eb:
	/* 0x34eb: jne    34cf <trace_mmap_alert+0x34cf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34eb, 0x34cf, x86_l_34cf);
x86_l_34ed:
	/* 0x34ed: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_34f0:
	/* 0x34f0: jmp    3576 <trace_mmap_alert+0x3576> */
	X86_SIM_X86_JMP(0x34f0, 0x3576, x86_l_3576);
x86_l_34f5:
	/* 0x34f5: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_34f8:
	/* 0x34f8: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_34fd:
	/* 0x34fd: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3501:
	/* 0x3501: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_3504:
	/* 0x3504: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3506:
	/* 0x3506: call   350b <trace_mmap_alert+0x350b> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_350b:
	/* 0x350b: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_350e:
	/* 0x350e: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3511:
	/* 0x3511: cmp    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_3518:
	/* 0x3518: je     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3518, 0x36d6, x86_l_36d6);
x86_l_351e:
	/* 0x351e: jmp    3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JMP(0x351e, 0x3789, x86_l_3789);
x86_l_3523:
	/* 0x3523: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3526:
	/* 0x3526: jne    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3526, 0x36bd, x86_l_36bd);
x86_l_352c:
	/* 0x352c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_352f:
	/* 0x352f: je     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x352f, 0x36bd, x86_l_36bd);
x86_l_3535:
	/* 0x3535: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3539:
	/* 0x3539: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_353c:
	/* 0x353c: jns    3543 <trace_mmap_alert+0x3543> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x353c, 0x3543, x86_l_3543);
x86_l_353e:
	/* 0x353e: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3541:
	/* 0x3541: jmp    3545 <trace_mmap_alert+0x3545> */
	X86_SIM_X86_JMP(0x3541, 0x3545, x86_l_3545);
x86_l_3543:
	/* 0x3543: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3545:
	/* 0x3545: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3548:
	/* 0x3548: jns    354f <trace_mmap_alert+0x354f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3548, 0x354f, x86_l_354f);
x86_l_354a:
	/* 0x354a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_354d:
	/* 0x354d: jmp    3551 <trace_mmap_alert+0x3551> */
	X86_SIM_X86_JMP(0x354d, 0x3551, x86_l_3551);
x86_l_354f:
	/* 0x354f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3551:
	/* 0x3551: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3554:
	/* 0x3554: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3557:
	/* 0x3557: jns    355e <trace_mmap_alert+0x355e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3557, 0x355e, x86_l_355e);
x86_l_3559:
	/* 0x3559: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_355c:
	/* 0x355c: jmp    3560 <trace_mmap_alert+0x3560> */
	X86_SIM_X86_JMP(0x355c, 0x3560, x86_l_3560);
x86_l_355e:
	/* 0x355e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3560:
	/* 0x3560: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3564:
	/* 0x3564: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3567:
	/* 0x3567: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_356a:
	/* 0x356a: jns    35a1 <trace_mmap_alert+0x35a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x356a, 0x35a1, x86_l_35a1);
x86_l_356c:
	/* 0x356c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_356f:
	/* 0x356f: jmp    35a3 <trace_mmap_alert+0x35a3> */
	X86_SIM_X86_JMP(0x356f, 0x35a3, x86_l_35a3);
x86_l_3571:
	/* 0x3571: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_3576:
	/* 0x3576: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_357a:
	/* 0x357a: jl     36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x357a, 0x36bd, x86_l_36bd);
x86_l_3580:
	/* 0x3580: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3584:
	/* 0x3584: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3587:
	/* 0x3587: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_358d:
	/* 0x358d: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_3592:
	/* 0x3592: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3595:
	/* 0x3595: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3599:
	/* 0x3599: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_359c:
	/* 0x359c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_359f:
	/* 0x359f: js     356c <trace_mmap_alert+0x356c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x359f, 0x356c, x86_l_356c);
x86_l_35a1:
	/* 0x35a1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35a3:
	/* 0x35a3: lea    rdi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35a7:
	/* 0x35a7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_35aa:
	/* 0x35aa: jns    35b1 <trace_mmap_alert+0x35b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35aa, 0x35b1, x86_l_35b1);
x86_l_35ac:
	/* 0x35ac: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35af:
	/* 0x35af: jmp    35b4 <trace_mmap_alert+0x35b4> */
	X86_SIM_X86_JMP(0x35af, 0x35b4, x86_l_35b4);
x86_l_35b1:
	/* 0x35b1: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35b4:
	/* 0x35b4: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_35b7:
	/* 0x35b7: je     3632 <trace_mmap_alert+0x3632> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35b7, 0x3632, x86_l_3632);
x86_l_35b9:
	/* 0x35b9: cmp    rbp,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_35bc:
	/* 0x35bc: je     3632 <trace_mmap_alert+0x3632> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35bc, 0x3632, x86_l_3632);
x86_l_35be:
	/* 0x35be: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35c2:
	/* 0x35c2: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35c5:
	/* 0x35c5: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_35ca:
	/* 0x35ca: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_35cd:
	/* 0x35cd: jns    35d6 <trace_mmap_alert+0x35d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35cd, 0x35d6, x86_l_35d6);
x86_l_35cf:
	/* 0x35cf: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35d2:
	/* 0x35d2: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_35d6:
	/* 0x35d6: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_35da:
	/* 0x35da: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_35dd:
	/* 0x35dd: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_35e4:
	/* 0x35e4: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_35e8:
	/* 0x35e8: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_35eb:
	/* 0x35eb: jb     3780 <trace_mmap_alert+0x3780> */
	X86_SIM_X86_JCC(X86_CC_B, 0x35eb, 0x3780, x86_l_3780);
x86_l_35f1:
	/* 0x35f1: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_35f4:
	/* 0x35f4: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35f4, 0x36ba, x86_l_36ba);
x86_l_35fa:
	/* 0x35fa: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3600:
	/* 0x3600: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3603:
	/* 0x3603: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3606:
	/* 0x3606: jns    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3606, 0x34f8, x86_l_34f8);
x86_l_360c:
	/* 0x360c: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3610:
	/* 0x3610: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3613:
	/* 0x3613: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_3616:
	/* 0x3616: je     367a <trace_mmap_alert+0x367a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3616, 0x367a, x86_l_367a);
x86_l_3618:
	/* 0x3618: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_361c:
	/* 0x361c: movzx  r15d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_3621:
	/* 0x3621: mov    BYTE PTR [rdi+r11*1],r15b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R15, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_3625:
	/* 0x3625: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3628:
	/* 0x3628: test   r15b,r15b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_8, 0, 0);
x86_l_362b:
	/* 0x362b: jne    3613 <trace_mmap_alert+0x3613> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x362b, 0x3613, x86_l_3613);
x86_l_362d:
	/* 0x362d: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_3630:
	/* 0x3630: jmp    367f <trace_mmap_alert+0x367f> */
	X86_SIM_X86_JMP(0x3630, 0x367f, x86_l_367f);
x86_l_3632:
	/* 0x3632: cmp    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3635:
	/* 0x3635: jne    36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3635, 0x36ba, x86_l_36ba);
x86_l_363b:
	/* 0x363b: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_363e:
	/* 0x363e: je     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x363e, 0x36ba, x86_l_36ba);
x86_l_3640:
	/* 0x3640: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3644:
	/* 0x3644: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3647:
	/* 0x3647: jns    364e <trace_mmap_alert+0x364e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3647, 0x364e, x86_l_364e);
x86_l_3649:
	/* 0x3649: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_364c:
	/* 0x364c: jmp    3651 <trace_mmap_alert+0x3651> */
	X86_SIM_X86_JMP(0x364c, 0x3651, x86_l_3651);
x86_l_364e:
	/* 0x364e: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3651:
	/* 0x3651: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3654:
	/* 0x3654: jns    365b <trace_mmap_alert+0x365b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3654, 0x365b, x86_l_365b);
x86_l_3656:
	/* 0x3656: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3659:
	/* 0x3659: jmp    365d <trace_mmap_alert+0x365d> */
	X86_SIM_X86_JMP(0x3659, 0x365d, x86_l_365d);
x86_l_365b:
	/* 0x365b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_365d:
	/* 0x365d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3660:
	/* 0x3660: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3663:
	/* 0x3663: jns    366a <trace_mmap_alert+0x366a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3663, 0x366a, x86_l_366a);
x86_l_3665:
	/* 0x3665: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3668:
	/* 0x3668: jmp    366c <trace_mmap_alert+0x366c> */
	X86_SIM_X86_JMP(0x3668, 0x366c, x86_l_366c);
x86_l_366a:
	/* 0x366a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_366c:
	/* 0x366c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3670:
	/* 0x3670: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3673:
	/* 0x3673: jns    36a3 <trace_mmap_alert+0x36a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3673, 0x36a3, x86_l_36a3);
x86_l_3675:
	/* 0x3675: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3678:
	/* 0x3678: jmp    36a5 <trace_mmap_alert+0x36a5> */
	X86_SIM_X86_JMP(0x3678, 0x36a5, x86_l_36a5);
x86_l_367a:
	/* 0x367a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_367f:
	/* 0x367f: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3683:
	/* 0x3683: jl     36ba <trace_mmap_alert+0x36ba> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3683, 0x36ba, x86_l_36ba);
x86_l_3685:
	/* 0x3685: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3689:
	/* 0x3689: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_368c:
	/* 0x368c: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3692:
	/* 0x3692: mov    BYTE PTR [r12+rdx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_3697:
	/* 0x3697: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_369a:
	/* 0x369a: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_369e:
	/* 0x369e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_36a1:
	/* 0x36a1: js     3675 <trace_mmap_alert+0x3675> */
	X86_SIM_X86_JCC(X86_CC_S, 0x36a1, 0x3675, x86_l_3675);
x86_l_36a3:
	/* 0x36a3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36a5:
	/* 0x36a5: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36a9:
	/* 0x36a9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_36ac:
	/* 0x36ac: jns    3739 <trace_mmap_alert+0x3739> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36ac, 0x3739, x86_l_3739);
x86_l_36b2:
	/* 0x36b2: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36b5:
	/* 0x36b5: jmp    373b <trace_mmap_alert+0x373b> */
	X86_SIM_X86_JMP(0x36b5, 0x373b, x86_l_373b);
x86_l_36ba:
	/* 0x36ba: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_36bd:
	/* 0x36bd: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36c2:
	/* 0x36c2: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36c6:
	/* 0x36c6: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_36c9:
	/* 0x36c9: cmp    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_36d0:
	/* 0x36d0: jne    3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x36d0, 0x3789, x86_l_3789);
x86_l_36d6:
	/* 0x36d6: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_36da:
	/* 0x36da: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_36dd:
	/* 0x36dd: jns    36e9 <trace_mmap_alert+0x36e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36dd, 0x36e9, x86_l_36e9);
x86_l_36df:
	/* 0x36df: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36e3:
	/* 0x36e3: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36e7:
	/* 0x36e7: jmp    36eb <trace_mmap_alert+0x36eb> */
	X86_SIM_X86_JMP(0x36e7, 0x36eb, x86_l_36eb);
x86_l_36e9:
	/* 0x36e9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36eb:
	/* 0x36eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36ee:
	/* 0x36ee: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_36f3:
	/* 0x36f3: jns    3717 <trace_mmap_alert+0x3717> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x36f3, 0x3717, x86_l_3717);
x86_l_36f5:
	/* 0x36f5: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36f8:
	/* 0x36f8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_36fa:
	/* 0x36fa: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_3701:
	/* 0x3701: je     372b <trace_mmap_alert+0x372b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3701, 0x372b, x86_l_372b);
x86_l_3703:
	/* 0x3703: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_3707:
	/* 0x3707: mov    BYTE PTR [r12+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_370b:
	/* 0x370b: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_370e:
	/* 0x370e: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_3710:
	/* 0x3710: jne    36fa <trace_mmap_alert+0x36fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3710, 0x36fa, x86_l_36fa);
x86_l_3712:
	/* 0x3712: jmp    37a7 <trace_mmap_alert+0x37a7> */
	X86_SIM_X86_JMP(0x3712, 0x37a7, x86_l_37a7);
x86_l_3717:
	/* 0x3717: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_371a:
	/* 0x371a: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_371f:
	/* 0x371f: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3722:
	/* 0x3722: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3724:
	/* 0x3724: call   3729 <trace_mmap_alert+0x3729> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_3729:
	/* 0x3729: jmp    37a7 <trace_mmap_alert+0x37a7> */
	X86_SIM_X86_JMP(0x3729, 0x37a7, x86_l_37a7);
x86_l_372b:
	/* 0x372b: mov    BYTE PTR [r12+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_3734:
	/* 0x3734: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3737:
	/* 0x3737: jmp    37a7 <trace_mmap_alert+0x37a7> */
	X86_SIM_X86_JMP(0x3737, 0x37a7, x86_l_37a7);
x86_l_3739:
	/* 0x3739: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_373b:
	/* 0x373b: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_373e:
	/* 0x373e: je     3890 <trace_mmap_alert+0x3890> */
	X86_SIM_X86_JCC(X86_CC_E, 0x373e, 0x3890, x86_l_3890);
x86_l_3744:
	/* 0x3744: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3747:
	/* 0x3747: je     3890 <trace_mmap_alert+0x3890> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3747, 0x3890, x86_l_3890);
x86_l_374d:
	/* 0x374d: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3751:
	/* 0x3751: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3754:
	/* 0x3754: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3759:
	/* 0x3759: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_375c:
	/* 0x375c: jns    3765 <trace_mmap_alert+0x3765> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x375c, 0x3765, x86_l_3765);
x86_l_375e:
	/* 0x375e: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3761:
	/* 0x3761: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3765:
	/* 0x3765: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_3769:
	/* 0x3769: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_376c:
	/* 0x376c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3773:
	/* 0x3773: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3777:
	/* 0x3777: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_377a:
	/* 0x377a: jae    38b0 <trace_mmap_alert+0x38b0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x377a, 0x38b0, x86_l_38b0);
x86_l_3780:
	/* 0x3780: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3785:
	/* 0x3785: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3789:
	/* 0x3789: dec    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_378c:
	/* 0x378c: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_378f:
	/* 0x378f: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3794:
	/* 0x3794: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_3799:
	/* 0x3799: mov    BYTE PTR [r12+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_37a2:
	/* 0x37a2: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_37a7:
	/* 0x37a7: and    r14d,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_37ae:
	/* 0x37ae: add    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_37b1:
	/* 0x37b1: add    rbx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_37b5:
	/* 0x37b5: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_37b8:
	/* 0x37b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37bb:
	/* 0x37bb: jns    37c2 <trace_mmap_alert+0x37c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37bb, 0x37c2, x86_l_37c2);
x86_l_37bd:
	/* 0x37bd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37c0:
	/* 0x37c0: jmp    37c4 <trace_mmap_alert+0x37c4> */
	X86_SIM_X86_JMP(0x37c0, 0x37c4, x86_l_37c4);
x86_l_37c2:
	/* 0x37c2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37c4:
	/* 0x37c4: mov    QWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_37d0:
	/* 0x37d0: mov    QWORD PTR [rsp+0xa8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 721554505728ULL);
x86_l_37dc:
	/* 0x37dc: lea    rdx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_37e0:
	/* 0x37e0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37e2:
	/* 0x37e2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_37e5:
	/* 0x37e5: jns    37ec <trace_mmap_alert+0x37ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37e5, 0x37ec, x86_l_37ec);
x86_l_37e7:
	/* 0x37e7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37ea:
	/* 0x37ea: jmp    37ee <trace_mmap_alert+0x37ee> */
	X86_SIM_X86_JMP(0x37ea, 0x37ee, x86_l_37ee);
x86_l_37ec:
	/* 0x37ec: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_37ee:
	/* 0x37ee: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_37f6:
	/* 0x37f6: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_37fa:
	/* 0x37fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37fd:
	/* 0x37fd: jns    3801 <trace_mmap_alert+0x3801> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37fd, 0x3801, x86_l_3801);
x86_l_37ff:
	/* 0x37ff: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3801:
	/* 0x3801: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3803:
	/* 0x3803: mov    QWORD PTR [rsp+0xb0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_380b:
	/* 0x380b: lea    rax,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_3813:
	/* 0x3813: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3816:
	/* 0x3816: jns    3824 <trace_mmap_alert+0x3824> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3816, 0x3824, x86_l_3824);
x86_l_3818:
	/* 0x3818: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_381b:
	/* 0x381b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_381e:
	/* 0x381e: jns    3826 <trace_mmap_alert+0x3826> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x381e, 0x3826, x86_l_3826);
x86_l_3820:
	/* 0x3820: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3822:
	/* 0x3822: jmp    3844 <trace_mmap_alert+0x3844> */
	X86_SIM_X86_JMP(0x3822, 0x3844, x86_l_3844);
x86_l_3824:
	/* 0x3824: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3826:
	/* 0x3826: lea    rcx,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_382e:
	/* 0x382e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3831:
	/* 0x3831: jns    3838 <trace_mmap_alert+0x3838> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3831, 0x3838, x86_l_3838);
x86_l_3833:
	/* 0x3833: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3836:
	/* 0x3836: jmp    383a <trace_mmap_alert+0x383a> */
	X86_SIM_X86_JMP(0x3836, 0x383a, x86_l_383a);
x86_l_3838:
	/* 0x3838: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_383a:
	/* 0x383a: imul   rax,rax,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_3841:
	/* 0x3841: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3844:
	/* 0x3844: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3847:
	/* 0x3847: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_384a:
	/* 0x384a: jns    3851 <trace_mmap_alert+0x3851> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x384a, 0x3851, x86_l_3851);
x86_l_384c:
	/* 0x384c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_384f:
	/* 0x384f: jmp    3853 <trace_mmap_alert+0x3853> */
	X86_SIM_X86_JMP(0x384f, 0x3853, x86_l_3853);
x86_l_3851:
	/* 0x3851: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3853:
	/* 0x3853: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3857:
	/* 0x3857: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3859:
	/* 0x3859: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_385c:
	/* 0x385c: jns    3863 <trace_mmap_alert+0x3863> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x385c, 0x3863, x86_l_3863);
x86_l_385e:
	/* 0x385e: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3861:
	/* 0x3861: jmp    3865 <trace_mmap_alert+0x3865> */
	X86_SIM_X86_JMP(0x3861, 0x3865, x86_l_3865);
x86_l_3863:
	/* 0x3863: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3865:
	/* 0x3865: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3868:
	/* 0x3868: jns    386c <trace_mmap_alert+0x386c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3868, 0x386c, x86_l_386c);
x86_l_386a:
	/* 0x386a: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_386c:
	/* 0x386c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_386f:
	/* 0x386f: jns    3876 <trace_mmap_alert+0x3876> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x386f, 0x3876, x86_l_3876);
x86_l_3871:
	/* 0x3871: mov    rdx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3874:
	/* 0x3874: jmp    3878 <trace_mmap_alert+0x3878> */
	X86_SIM_X86_JMP(0x3874, 0x3878, x86_l_3878);
x86_l_3876:
	/* 0x3876: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3878:
	/* 0x3878: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_387c:
	/* 0x387c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_387f:
	/* 0x387f: jns    3889 <trace_mmap_alert+0x3889> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x387f, 0x3889, x86_l_3889);
x86_l_3881:
	/* 0x3881: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3884:
	/* 0x3884: jmp    fba <trace_mmap_alert+0xfba> */
	X86_SIM_X86_JMP(0x3884, 0xfba, x86_l_fba);
x86_l_3889:
	/* 0x3889: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_388b:
	/* 0x388b: jmp    fba <trace_mmap_alert+0xfba> */
	X86_SIM_X86_JMP(0x388b, 0xfba, x86_l_fba);
x86_l_3890:
	/* 0x3890: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3893:
	/* 0x3893: jne    394c <trace_mmap_alert+0x394c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3893, 0x394c, x86_l_394c);
x86_l_3899:
	/* 0x3899: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_389c:
	/* 0x389c: je     394c <trace_mmap_alert+0x394c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x389c, 0x394c, x86_l_394c);
x86_l_38a2:
	/* 0x38a2: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38a6:
	/* 0x38a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_38a9:
	/* 0x38a9: jns    38ec <trace_mmap_alert+0x38ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38a9, 0x38ec, x86_l_38ec);
x86_l_38ab:
	/* 0x38ab: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38ae:
	/* 0x38ae: jmp    38ee <trace_mmap_alert+0x38ee> */
	X86_SIM_X86_JMP(0x38ae, 0x38ee, x86_l_38ee);
x86_l_38b0:
	/* 0x38b0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_38b3:
	/* 0x38b3: je     394c <trace_mmap_alert+0x394c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38b3, 0x394c, x86_l_394c);
x86_l_38b9:
	/* 0x38b9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_38bf:
	/* 0x38bf: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_38c2:
	/* 0x38c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38c5:
	/* 0x38c5: jns    390b <trace_mmap_alert+0x390b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38c5, 0x390b, x86_l_390b);
x86_l_38c7:
	/* 0x38c7: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_38cb:
	/* 0x38cb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38cd:
	/* 0x38cd: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_38d0:
	/* 0x38d0: je     3913 <trace_mmap_alert+0x3913> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38d0, 0x3913, x86_l_3913);
x86_l_38d2:
	/* 0x38d2: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_38d6:
	/* 0x38d6: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_38db:
	/* 0x38db: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_38df:
	/* 0x38df: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_38e2:
	/* 0x38e2: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_38e5:
	/* 0x38e5: jne    38cd <trace_mmap_alert+0x38cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x38e5, 0x38cd, x86_l_38cd);
x86_l_38e7:
	/* 0x38e7: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_38ea:
	/* 0x38ea: jmp    3917 <trace_mmap_alert+0x3917> */
	X86_SIM_X86_JMP(0x38ea, 0x3917, x86_l_3917);
x86_l_38ec:
	/* 0x38ec: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38ee:
	/* 0x38ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38f1:
	/* 0x38f1: jns    38f8 <trace_mmap_alert+0x38f8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38f1, 0x38f8, x86_l_38f8);
x86_l_38f3:
	/* 0x38f3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38f6:
	/* 0x38f6: jmp    38fa <trace_mmap_alert+0x38fa> */
	X86_SIM_X86_JMP(0x38f6, 0x38fa, x86_l_38fa);
x86_l_38f8:
	/* 0x38f8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38fa:
	/* 0x38fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38fd:
	/* 0x38fd: jns    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38fd, 0x36bd, x86_l_36bd);
x86_l_3903:
	/* 0x3903: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3906:
	/* 0x3906: jmp    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JMP(0x3906, 0x36bd, x86_l_36bd);
x86_l_390b:
	/* 0x390b: mov    rbp,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_390e:
	/* 0x390e: jmp    34f8 <trace_mmap_alert+0x34f8> */
	X86_SIM_X86_JMP(0x390e, 0x34f8, x86_l_34f8);
x86_l_3913:
	/* 0x3913: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_3917:
	/* 0x3917: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_391b:
	/* 0x391b: jl     394c <trace_mmap_alert+0x394c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x391b, 0x394c, x86_l_394c);
x86_l_391d:
	/* 0x391d: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3921:
	/* 0x3921: lea    eax,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3925:
	/* 0x3925: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_392a:
	/* 0x392a: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_392f:
	/* 0x392f: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3932:
	/* 0x3932: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3937:
	/* 0x3937: mov    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_393a:
	/* 0x393a: cmp    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_3941:
	/* 0x3941: je     36d6 <trace_mmap_alert+0x36d6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3941, 0x36d6, x86_l_36d6);
x86_l_3947:
	/* 0x3947: jmp    3789 <trace_mmap_alert+0x3789> */
	X86_SIM_X86_JMP(0x3947, 0x3789, x86_l_3789);
x86_l_394c:
	/* 0x394c: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_394f:
	/* 0x394f: jmp    36bd <trace_mmap_alert+0x36bd> */
	X86_SIM_X86_JMP(0x394f, 0x36bd, x86_l_36bd);
x86_l_3954:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
