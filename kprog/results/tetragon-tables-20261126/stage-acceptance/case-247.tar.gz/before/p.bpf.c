#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 216U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(14) M(15) M(18) M(19) M(20)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 file_modification_map[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/filp_close")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    QWORD PTR [rsp+0xa0],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_19:
	/* 0x19: mov    DWORD PTR [rsp+0x8c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 601295421440ULL);
x86_l_24:
	/* 0x24: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_2b:
	/* 0x2b: lea    rsi,[rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_33:
	/* 0x33: call   38 <trace_filp_close+0x38> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_38:
	/* 0x38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3b:
	/* 0x3b: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3b, 0x29a3, x86_l_29a3);
x86_l_41:
	/* 0x41: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_4b:
	/* 0x4b: lea    rsi,[rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_53:
	/* 0x53: call   58 <trace_filp_close+0x58> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_58:
	/* 0x58: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b:
	/* 0x5b: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b, 0x29a3, x86_l_29a3);
x86_l_61:
	/* 0x61: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64:
	/* 0x64: mov    WORD PTR [r15+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6e:
	/* 0x6e: mov    BYTE PTR [r15+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_76:
	/* 0x76: mov    QWORD PTR [r15+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_81:
	/* 0x81: mov    QWORD PTR [r15+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_8c:
	/* 0x8c: mov    QWORD PTR [r15+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_97:
	/* 0x97: mov    QWORD PTR [r15+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_a2:
	/* 0xa2: mov    QWORD PTR [r15+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_ad:
	/* 0xad: mov    QWORD PTR [r15+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b8:
	/* 0xb8: mov    QWORD PTR [r15+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_c3:
	/* 0xc3: mov    QWORD PTR [r15+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ce:
	/* 0xce: call   d3 <trace_filp_close+0xd3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_d3:
	/* 0xd3: mov    QWORD PTR [r15+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_da:
	/* 0xda: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e2:
	/* 0xe2: mov    QWORD PTR [r15+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_ea:
	/* 0xea: mov    QWORD PTR [r15+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_f2:
	/* 0xf2: mov    QWORD PTR [r15+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_fa:
	/* 0xfa: mov    QWORD PTR [r15+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_102:
	/* 0x102: mov    QWORD PTR [r15+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_10a:
	/* 0x10a: mov    QWORD PTR [r15+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_112:
	/* 0x112: mov    QWORD PTR [r15+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_11a:
	/* 0x11a: mov    QWORD PTR [r15+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_122:
	/* 0x122: mov    QWORD PTR [r15+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_12a:
	/* 0x12a: mov    QWORD PTR [r15+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_132:
	/* 0x132: mov    QWORD PTR [r15+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_13a:
	/* 0x13a: mov    QWORD PTR [r15+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_142:
	/* 0x142: call   147 <trace_filp_close+0x147> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_147:
	/* 0x147: mov    DWORD PTR [r15+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_14b:
	/* 0x14b: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14f:
	/* 0x14f: mov    DWORD PTR [r15+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_153:
	/* 0x153: mov    DWORD PTR [r15+0x70],0x308 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337928ULL);
x86_l_15b:
	/* 0x15b: call   160 <trace_filp_close+0x160> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_160:
	/* 0x160: mov    QWORD PTR [r15],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_163:
	/* 0x163: call   168 <trace_filp_close+0x168> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_168:
	/* 0x168: mov    WORD PTR [r15+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_16d:
	/* 0x16d: call   172 <trace_filp_close+0x172> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_172:
	/* 0x172: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_179:
	/* 0x179: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17c:
	/* 0x17c: jns    18d <trace_filp_close+0x18d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c, 0x18d, x86_l_18d);
x86_l_17e:
	/* 0x17e: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180:
	/* 0x180: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_185:
	/* 0x185: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_18b:
	/* 0x18b: jne    1ca <trace_filp_close+0x1ca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b, 0x1ca, x86_l_1ca);
x86_l_18d:
	/* 0x18d: call   192 <trace_filp_close+0x192> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_192:
	/* 0x192: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_195:
	/* 0x195: call   19a <trace_filp_close+0x19a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_19a:
	/* 0x19a: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_19e:
	/* 0x19e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a1:
	/* 0x1a1: jns    1b1 <trace_filp_close+0x1b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a1, 0x1b1, x86_l_1b1);
x86_l_1a3:
	/* 0x1a3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a6:
	/* 0x1a6: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1aa:
	/* 0x1aa: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ad:
	/* 0x1ad: js     1bc <trace_filp_close+0x1bc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ad, 0x1bc, x86_l_1bc);
x86_l_1af:
	/* 0x1af: jmp    1c6 <trace_filp_close+0x1c6> */
	X86_SIM_X86_JMP(0x1af, 0x1c6, x86_l_1c6);
x86_l_1b1:
	/* 0x1b1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b3:
	/* 0x1b3: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b7:
	/* 0x1b7: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ba:
	/* 0x1ba: jns    1c6 <trace_filp_close+0x1c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba, 0x1c6, x86_l_1c6);
x86_l_1bc:
	/* 0x1bc: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1be:
	/* 0x1be: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1c0:
	/* 0x1c0: jne    53b <trace_filp_close+0x53b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c0, 0x53b, x86_l_53b);
x86_l_1c6:
	/* 0x1c6: mov    eax,DWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ca:
	/* 0x1ca: mov    DWORD PTR [r15+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1ce:
	/* 0x1ce: mov    eax,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d2:
	/* 0x1d2: mov    DWORD PTR [rsp+0x88],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1d9:
	/* 0x1d9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1e0:
	/* 0x1e0: lea    rsi,[rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1e8:
	/* 0x1e8: call   1ed <trace_filp_close+0x1ed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ed:
	/* 0x1ed: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1f2:
	/* 0x1f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f5:
	/* 0x1f5: je     1173 <trace_filp_close+0x1173> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f5, 0x1173, x86_l_1173);
x86_l_1fb:
	/* 0x1fb: mov    eax,DWORD PTR [r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ff:
	/* 0x1ff: mov    DWORD PTR [rsp+0x84],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_206:
	/* 0x206: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_20d:
	/* 0x20d: lea    rsi,[rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_215:
	/* 0x215: call   21a <trace_filp_close+0x21a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_21a:
	/* 0x21a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21d:
	/* 0x21d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_220:
	/* 0x220: je     11f6 <trace_filp_close+0x11f6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x220, 0x11f6, x86_l_11f6);
x86_l_226:
	/* 0x226: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_22b:
	/* 0x22b: jne    234 <trace_filp_close+0x234> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22b, 0x234, x86_l_234);
x86_l_22d:
	/* 0x22d: call   232 <trace_filp_close+0x232> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_232:
	/* 0x232: jmp    28c <trace_filp_close+0x28c> */
	X86_SIM_X86_JMP(0x232, 0x28c, x86_l_28c);
x86_l_234:
	/* 0x234: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_239:
	/* 0x239: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_240:
	/* 0x240: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_243:
	/* 0x243: jns    25d <trace_filp_close+0x25d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x243, 0x25d, x86_l_25d);
x86_l_245:
	/* 0x245: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248:
	/* 0x248: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24b:
	/* 0x24b: js     264 <trace_filp_close+0x264> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24b, 0x264, x86_l_264);
x86_l_24d:
	/* 0x24d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f:
	/* 0x24f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_252:
	/* 0x252: js     26c <trace_filp_close+0x26c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x252, 0x26c, x86_l_26c);
x86_l_254:
	/* 0x254: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_256:
	/* 0x256: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_259:
	/* 0x259: js     274 <trace_filp_close+0x274> */
	X86_SIM_X86_JCC(X86_CC_S, 0x259, 0x274, x86_l_274);
x86_l_25b:
	/* 0x25b: jmp    28a <trace_filp_close+0x28a> */
	X86_SIM_X86_JMP(0x25b, 0x28a, x86_l_28a);
x86_l_25d:
	/* 0x25d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f:
	/* 0x25f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_262:
	/* 0x262: jns    24d <trace_filp_close+0x24d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x262, 0x24d, x86_l_24d);
x86_l_264:
	/* 0x264: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_267:
	/* 0x267: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a:
	/* 0x26a: jns    254 <trace_filp_close+0x254> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26a, 0x254, x86_l_254);
x86_l_26c:
	/* 0x26c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f:
	/* 0x26f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_272:
	/* 0x272: jns    28a <trace_filp_close+0x28a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x272, 0x28a, x86_l_28a);
x86_l_274:
	/* 0x274: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277:
	/* 0x277: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27a:
	/* 0x27a: je     28a <trace_filp_close+0x28a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a, 0x28a, x86_l_28a);
x86_l_27c:
	/* 0x27c: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_280:
	/* 0x280: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_283:
	/* 0x283: jns    28a <trace_filp_close+0x28a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x283, 0x28a, x86_l_28a);
x86_l_285:
	/* 0x285: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_288:
	/* 0x288: jmp    28c <trace_filp_close+0x28c> */
	X86_SIM_X86_JMP(0x288, 0x28c, x86_l_28c);
x86_l_28a:
	/* 0x28a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c:
	/* 0x28c: mov    QWORD PTR [r15+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_290:
	/* 0x290: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_294:
	/* 0x294: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_298:
	/* 0x298: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_29f:
	/* 0x29f: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2a4:
	/* 0x2a4: call   2a9 <trace_filp_close+0x2a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a9:
	/* 0x2a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ac:
	/* 0x2ac: je     2c4 <trace_filp_close+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ac, 0x2c4, x86_l_2c4);
x86_l_2ae:
	/* 0x2ae: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2b1:
	/* 0x2b1: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2b7:
	/* 0x2b7: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2ba:
	/* 0x2ba: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2bd:
	/* 0x2bd: jne    2c4 <trace_filp_close+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bd, 0x2c4, x86_l_2c4);
x86_l_2bf:
	/* 0x2bf: or     BYTE PTR [r15+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2c4:
	/* 0x2c4: movzx  eax,WORD PTR [r15+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2c9:
	/* 0x2c9: cmp    ax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R13, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2ce:
	/* 0x2ce: jne    1292 <trace_filp_close+0x1292> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ce, 0x1292, x86_l_1292);
x86_l_2d4:
	/* 0x2d4: mov    QWORD PTR [r15+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2df:
	/* 0x2df: mov    DWORD PTR [rsp+0x20],0x308 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438954248ULL);
x86_l_2e7:
	/* 0x2e7: mov    WORD PTR [rsp+0x1c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2ec:
	/* 0x2ec: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_2f3:
	/* 0x2f3: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2f8:
	/* 0x2f8: call   2fd <trace_filp_close+0x2fd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2fd:
	/* 0x2fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_300:
	/* 0x300: je     36b <trace_filp_close+0x36b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x300, 0x36b, x86_l_36b);
x86_l_302:
	/* 0x302: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_307:
	/* 0x307: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: call   30f <trace_filp_close+0x30f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_30f:
	/* 0x30f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_312:
	/* 0x312: je     36b <trace_filp_close+0x36b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x312, 0x36b, x86_l_36b);
x86_l_314:
	/* 0x314: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_318:
	/* 0x318: mov    QWORD PTR [r15+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_31f:
	/* 0x31f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_322:
	/* 0x322: mov    QWORD PTR [r15+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_329:
	/* 0x329: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32d:
	/* 0x32d: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_331:
	/* 0x331: mov    QWORD PTR [r15+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_338:
	/* 0x338: mov    QWORD PTR [r15+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_33f:
	/* 0x33f: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_343:
	/* 0x343: mov    QWORD PTR [r15+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_34a:
	/* 0x34a: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_34e:
	/* 0x34e: mov    QWORD PTR [r15+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_355:
	/* 0x355: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_359:
	/* 0x359: mov    QWORD PTR [r15+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_360:
	/* 0x360: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_364:
	/* 0x364: mov    QWORD PTR [r15+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_36b:
	/* 0x36b: mov    rax,QWORD PTR [r15+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_372:
	/* 0x372: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_379:
	/* 0x379: mov    ecx,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_37d:
	/* 0x37d: cmp    ecx,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_381:
	/* 0x381: jne    39b <trace_filp_close+0x39b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x381, 0x39b, x86_l_39b);
x86_l_383:
	/* 0x383: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_386:
	/* 0x386: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_389:
	/* 0x389: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_390:
	/* 0x390: jne    c14 <trace_filp_close+0xc14> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x390, 0xc14, x86_l_c14);
x86_l_396:
	/* 0x396: jmp    29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JMP(0x396, 0x29a3, x86_l_29a3);
x86_l_39b:
	/* 0x39b: mov    rax,QWORD PTR [r15+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_3a2:
	/* 0x3a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a5:
	/* 0x3a5: je     55c <trace_filp_close+0x55c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a5, 0x55c, x86_l_55c);
x86_l_3ab:
	/* 0x3ab: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_3b2:
	/* 0x3b2: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_3b5:
	/* 0x3b5: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3b8:
	/* 0x3b8: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3bb:
	/* 0x3bb: sete   r13b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3bf:
	/* 0x3bf: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3c2:
	/* 0x3c2: neg    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3c5:
	/* 0x3c5: xor    r13,QWORD PTR [r15+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_3cc:
	/* 0x3cc: or     r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3cf:
	/* 0x3cf: mov    rax,QWORD PTR [r15+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_3d6:
	/* 0x3d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d9:
	/* 0x3d9: je     3fa <trace_filp_close+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d9, 0x3fa, x86_l_3fa);
x86_l_3db:
	/* 0x3db: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3dd:
	/* 0x3dd: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_3e4:
	/* 0x3e4: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3e7:
	/* 0x3e7: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3ea:
	/* 0x3ea: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3ed:
	/* 0x3ed: xor    rcx,QWORD PTR [r15+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_3f4:
	/* 0x3f4: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3f7:
	/* 0x3f7: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3fa:
	/* 0x3fa: mov    rax,QWORD PTR [r15+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_401:
	/* 0x401: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_404:
	/* 0x404: je     420 <trace_filp_close+0x420> */
	X86_SIM_X86_JCC(X86_CC_E, 0x404, 0x420, x86_l_420);
x86_l_406:
	/* 0x406: mov    ecx,DWORD PTR [r15+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_40a:
	/* 0x40a: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_40d:
	/* 0x40d: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_410:
	/* 0x410: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_413:
	/* 0x413: xor    rcx,QWORD PTR [r15+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_41a:
	/* 0x41a: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_41d:
	/* 0x41d: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_420:
	/* 0x420: mov    rax,QWORD PTR [r15+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_427:
	/* 0x427: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42a:
	/* 0x42a: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42f:
	/* 0x42f: je     44d <trace_filp_close+0x44d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x42f, 0x44d, x86_l_44d);
x86_l_431:
	/* 0x431: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_434:
	/* 0x434: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_439:
	/* 0x439: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_43d:
	/* 0x43d: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_440:
	/* 0x440: xor    rcx,QWORD PTR [r15+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_447:
	/* 0x447: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_44a:
	/* 0x44a: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_44d:
	/* 0x44d: movzx  ebp,WORD PTR [r15+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_452:
	/* 0x452: mov    rbx,QWORD PTR [r15+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_459:
	/* 0x459: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_45c:
	/* 0x45c: mov    WORD PTR [rsp+0x10],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_461:
	/* 0x461: je     5d1 <trace_filp_close+0x5d1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x461, 0x5d1, x86_l_5d1);
x86_l_467:
	/* 0x467: mov    QWORD PTR [rsp+0x90],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_46f:
	/* 0x46f: mov    rax,QWORD PTR [r15+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_476:
	/* 0x476: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_47e:
	/* 0x47e: mov    r14,QWORD PTR [r15+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_485:
	/* 0x485: mov    rax,QWORD PTR [r15+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_48c:
	/* 0x48c: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_491:
	/* 0x491: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_496:
	/* 0x496: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_49d:
	/* 0x49d: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4a2:
	/* 0x4a2: call   4a7 <trace_filp_close+0x4a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4a7:
	/* 0x4a7: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4aa:
	/* 0x4aa: mov    eax,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4ae:
	/* 0x4ae: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b3:
	/* 0x4b3: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4ba:
	/* 0x4ba: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4bd:
	/* 0x4bd: je     4dd <trace_filp_close+0x4dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4bd, 0x4dd, x86_l_4dd);
x86_l_4bf:
	/* 0x4bf: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4c4:
	/* 0x4c4: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4c7:
	/* 0x4c7: call   4cc <trace_filp_close+0x4cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4cc:
	/* 0x4cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cf:
	/* 0x4cf: je     4dd <trace_filp_close+0x4dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cf, 0x4dd, x86_l_4dd);
x86_l_4d1:
	/* 0x4d1: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d4:
	/* 0x4d4: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4d8:
	/* 0x4d8: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4db:
	/* 0x4db: jmp    4e0 <trace_filp_close+0x4e0> */
	X86_SIM_X86_JMP(0x4db, 0x4e0, x86_l_4e0);
x86_l_4dd:
	/* 0x4dd: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e0:
	/* 0x4e0: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_4e5:
	/* 0x4e5: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4ea:
	/* 0x4ea: dec    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_4ed:
	/* 0x4ed: cmp    r14,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f0:
	/* 0x4f0: jb     508 <trace_filp_close+0x508> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4f0, 0x508, x86_l_508);
x86_l_4f2:
	/* 0x4f2: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4f6:
	/* 0x4f6: je     4fd <trace_filp_close+0x4fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4f6, 0x4fd, x86_l_4fd);
x86_l_4f8:
	/* 0x4f8: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4fb:
	/* 0x4fb: jbe    508 <trace_filp_close+0x508> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x4fb, 0x508, x86_l_508);
x86_l_4fd:
	/* 0x4fd: and    rbp,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 152ULL);
x86_l_505:
	/* 0x505: or     r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_508:
	/* 0x508: mov    eax,DWORD PTR [r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_50c:
	/* 0x50c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_511:
	/* 0x511: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_518:
	/* 0x518: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_51b:
	/* 0x51b: je     578 <trace_filp_close+0x578> */
	X86_SIM_X86_JCC(X86_CC_E, 0x51b, 0x578, x86_l_578);
x86_l_51d:
	/* 0x51d: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_522:
	/* 0x522: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_525:
	/* 0x525: call   52a <trace_filp_close+0x52a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_52a:
	/* 0x52a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52d:
	/* 0x52d: je     591 <trace_filp_close+0x591> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52d, 0x591, x86_l_591);
x86_l_52f:
	/* 0x52f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_532:
	/* 0x532: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_536:
	/* 0x536: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_539:
	/* 0x539: jmp    593 <trace_filp_close+0x593> */
	X86_SIM_X86_JMP(0x539, 0x593, x86_l_593);
x86_l_53b:
	/* 0x53b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_542:
	/* 0x542: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_547:
	/* 0x547: call   54c <trace_filp_close+0x54c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_54c:
	/* 0x54c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54f:
	/* 0x54f: je     d93 <trace_filp_close+0xd93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54f, 0xd93, x86_l_d93);
x86_l_555:
	/* 0x555: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_557:
	/* 0x557: jmp    1ca <trace_filp_close+0x1ca> */
	X86_SIM_X86_JMP(0x557, 0x1ca, x86_l_1ca);
x86_l_55c:
	/* 0x55c: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_563:
	/* 0x563: mov    rax,QWORD PTR [r15+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_56a:
	/* 0x56a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56d:
	/* 0x56d: jne    3db <trace_filp_close+0x3db> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x56d, 0x3db, x86_l_3db);
x86_l_573:
	/* 0x573: jmp    3fa <trace_filp_close+0x3fa> */
	X86_SIM_X86_JMP(0x573, 0x3fa, x86_l_3fa);
x86_l_578:
	/* 0x578: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57a:
	/* 0x57a: mov    r13,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_582:
	/* 0x582: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_585:
	/* 0x585: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_58a:
	/* 0x58a: cmp    r14,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58d:
	/* 0x58d: jae    5ad <trace_filp_close+0x5ad> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x58d, 0x5ad, x86_l_5ad);
x86_l_58f:
	/* 0x58f: jmp    5c3 <trace_filp_close+0x5c3> */
	X86_SIM_X86_JMP(0x58f, 0x5c3, x86_l_5c3);
x86_l_591:
	/* 0x591: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_593:
	/* 0x593: mov    r13,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_59b:
	/* 0x59b: mov    rdx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_5a0:
	/* 0x5a0: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5a3:
	/* 0x5a3: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5a8:
	/* 0x5a8: cmp    r14,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ab:
	/* 0x5ab: jb     5c3 <trace_filp_close+0x5c3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5ab, 0x5c3, x86_l_5c3);
x86_l_5ad:
	/* 0x5ad: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5b1:
	/* 0x5b1: je     5b8 <trace_filp_close+0x5b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b1, 0x5b8, x86_l_5b8);
x86_l_5b3:
	/* 0x5b3: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5b6:
	/* 0x5b6: jbe    5c3 <trace_filp_close+0x5c3> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5b6, 0x5c3, x86_l_5c3);
x86_l_5b8:
	/* 0x5b8: and    rbp,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 152ULL);
x86_l_5c0:
	/* 0x5c0: or     rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c3:
	/* 0x5c3: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c6:
	/* 0x5c6: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c9:
	/* 0x5c9: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_5cc:
	/* 0x5cc: movzx  ebp,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_5d1:
	/* 0x5d1: cmp    QWORD PTR [r15+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_5d9:
	/* 0x5d9: je     691 <trace_filp_close+0x691> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5d9, 0x691, x86_l_691);
x86_l_5df:
	/* 0x5df: mov    r14d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_5e2:
	/* 0x5e2: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_5e5:
	/* 0x5e5: call   5ea <trace_filp_close+0x5ea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_5ea:
	/* 0x5ea: mov    DWORD PTR [r15+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5ee:
	/* 0x5ee: mov    rbx,QWORD PTR [r15+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_5f5:
	/* 0x5f5: mov    rax,QWORD PTR [r15+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_5fc:
	/* 0x5fc: mov    QWORD PTR [rsp+0x70],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_601:
	/* 0x601: mov    r13,QWORD PTR [r15+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_608:
	/* 0x608: mov    r12,QWORD PTR [r15+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_60f:
	/* 0x60f: mov    WORD PTR [rsp+0x20],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_615:
	/* 0x615: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_61c:
	/* 0x61c: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_621:
	/* 0x621: call   626 <trace_filp_close+0x626> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_626:
	/* 0x626: mov    ecx,DWORD PTR [r15+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62a:
	/* 0x62a: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_62f:
	/* 0x62f: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_636:
	/* 0x636: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_639:
	/* 0x639: je     659 <trace_filp_close+0x659> */
	X86_SIM_X86_JCC(X86_CC_E, 0x639, 0x659, x86_l_659);
x86_l_63b:
	/* 0x63b: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_640:
	/* 0x640: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_643:
	/* 0x643: call   648 <trace_filp_close+0x648> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_648:
	/* 0x648: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64b:
	/* 0x64b: je     659 <trace_filp_close+0x659> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64b, 0x659, x86_l_659);
x86_l_64d:
	/* 0x64d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_650:
	/* 0x650: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_654:
	/* 0x654: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_657:
	/* 0x657: jmp    65b <trace_filp_close+0x65b> */
	X86_SIM_X86_JMP(0x657, 0x65b, x86_l_65b);
x86_l_659:
	/* 0x659: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_65b:
	/* 0x65b: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_65e:
	/* 0x65e: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_663:
	/* 0x663: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_666:
	/* 0x666: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_669:
	/* 0x669: jae    670 <trace_filp_close+0x670> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x669, 0x670, x86_l_670);
x86_l_66b:
	/* 0x66b: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_66e:
	/* 0x66e: jmp    686 <trace_filp_close+0x686> */
	X86_SIM_X86_JMP(0x66e, 0x686, x86_l_686);
x86_l_670:
	/* 0x670: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_674:
	/* 0x674: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_677:
	/* 0x677: je     67e <trace_filp_close+0x67e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x677, 0x67e, x86_l_67e);
x86_l_679:
	/* 0x679: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_67c:
	/* 0x67c: jbe    686 <trace_filp_close+0x686> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x67c, 0x686, x86_l_686);
x86_l_67e:
	/* 0x67e: and    r14,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 112ULL);
x86_l_683:
	/* 0x683: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_686:
	/* 0x686: movzx  ebp,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_68b:
	/* 0x68b: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_68e:
	/* 0x68e: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_691:
	/* 0x691: cmp    QWORD PTR [r15+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_699:
	/* 0x699: je     737 <trace_filp_close+0x737> */
	X86_SIM_X86_JCC(X86_CC_E, 0x699, 0x737, x86_l_737);
x86_l_69f:
	/* 0x69f: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6a4:
	/* 0x6a4: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6ab:
	/* 0x6ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6ae:
	/* 0x6ae: jns    6b5 <trace_filp_close+0x6b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6ae, 0x6b5, x86_l_6b5);
x86_l_6b0:
	/* 0x6b0: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6b3:
	/* 0x6b3: jmp    6b7 <trace_filp_close+0x6b7> */
	X86_SIM_X86_JMP(0x6b3, 0x6b7, x86_l_6b7);
x86_l_6b5:
	/* 0x6b5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b7:
	/* 0x6b7: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6bb:
	/* 0x6bb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6bd:
	/* 0x6bd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6c0:
	/* 0x6c0: jns    6cc <trace_filp_close+0x6cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6c0, 0x6cc, x86_l_6cc);
x86_l_6c2:
	/* 0x6c2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c5:
	/* 0x6c5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6c8:
	/* 0x6c8: js     6d3 <trace_filp_close+0x6d3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x6c8, 0x6d3, x86_l_6d3);
x86_l_6ca:
	/* 0x6ca: jmp    6d5 <trace_filp_close+0x6d5> */
	X86_SIM_X86_JMP(0x6ca, 0x6d5, x86_l_6d5);
x86_l_6cc:
	/* 0x6cc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6ce:
	/* 0x6ce: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6d1:
	/* 0x6d1: jns    6d5 <trace_filp_close+0x6d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6d1, 0x6d5, x86_l_6d5);
x86_l_6d3:
	/* 0x6d3: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d5:
	/* 0x6d5: mov    DWORD PTR [r15+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_6d9:
	/* 0x6d9: mov    rbx,QWORD PTR [r15+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_6e0:
	/* 0x6e0: mov    r14,QWORD PTR [r15+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_6e7:
	/* 0x6e7: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6ea:
	/* 0x6ea: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6ef:
	/* 0x6ef: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_6f6:
	/* 0x6f6: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6fb:
	/* 0x6fb: call   700 <trace_filp_close+0x700> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_700:
	/* 0x700: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_707:
	/* 0x707: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_70a:
	/* 0x70a: je     729 <trace_filp_close+0x729> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70a, 0x729, x86_l_729);
x86_l_70c:
	/* 0x70c: lea    rsi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_710:
	/* 0x710: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_713:
	/* 0x713: call   718 <trace_filp_close+0x718> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_718:
	/* 0x718: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_71b:
	/* 0x71b: je     729 <trace_filp_close+0x729> */
	X86_SIM_X86_JCC(X86_CC_E, 0x71b, 0x729, x86_l_729);
x86_l_71d:
	/* 0x71d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_720:
	/* 0x720: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_724:
	/* 0x724: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_727:
	/* 0x727: jmp    72b <trace_filp_close+0x72b> */
	X86_SIM_X86_JMP(0x727, 0x72b, x86_l_72b);
x86_l_729:
	/* 0x729: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_72b:
	/* 0x72b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_72e:
	/* 0x72e: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_731:
	/* 0x731: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_734:
	/* 0x734: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_737:
	/* 0x737: cmp    QWORD PTR [r15+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_73f:
	/* 0x73f: je     801 <trace_filp_close+0x801> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73f, 0x801, x86_l_801);
x86_l_745:
	/* 0x745: mov    rcx,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_74c:
	/* 0x74c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_750:
	/* 0x750: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_752:
	/* 0x752: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_755:
	/* 0x755: jns    764 <trace_filp_close+0x764> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x755, 0x764, x86_l_764);
x86_l_757:
	/* 0x757: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_75a:
	/* 0x75a: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_75d:
	/* 0x75d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_760:
	/* 0x760: js     76e <trace_filp_close+0x76e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x760, 0x76e, x86_l_76e);
x86_l_762:
	/* 0x762: jmp    770 <trace_filp_close+0x770> */
	X86_SIM_X86_JMP(0x762, 0x770, x86_l_770);
x86_l_764:
	/* 0x764: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_766:
	/* 0x766: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_769:
	/* 0x769: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_76c:
	/* 0x76c: jns    770 <trace_filp_close+0x770> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x76c, 0x770, x86_l_770);
x86_l_76e:
	/* 0x76e: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_770:
	/* 0x770: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_772:
	/* 0x772: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_776:
	/* 0x776: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_779:
	/* 0x779: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_77d:
	/* 0x77d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77f:
	/* 0x77f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_782:
	/* 0x782: jns    792 <trace_filp_close+0x792> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x782, 0x792, x86_l_792);
x86_l_784:
	/* 0x784: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_787:
	/* 0x787: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_78b:
	/* 0x78b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_78e:
	/* 0x78e: js     79d <trace_filp_close+0x79d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x78e, 0x79d, x86_l_79d);
x86_l_790:
	/* 0x790: jmp    79f <trace_filp_close+0x79f> */
	X86_SIM_X86_JMP(0x790, 0x79f, x86_l_79f);
x86_l_792:
	/* 0x792: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_794:
	/* 0x794: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_798:
	/* 0x798: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_79b:
	/* 0x79b: jns    79f <trace_filp_close+0x79f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x79b, 0x79f, x86_l_79f);
x86_l_79d:
	/* 0x79d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_79f:
	/* 0x79f: mov    DWORD PTR [r15+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7a3:
	/* 0x7a3: mov    rbx,QWORD PTR [r15+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_7aa:
	/* 0x7aa: mov    r14,QWORD PTR [r15+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_7b1:
	/* 0x7b1: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7b4:
	/* 0x7b4: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7b9:
	/* 0x7b9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_7c0:
	/* 0x7c0: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7c5:
	/* 0x7c5: call   7ca <trace_filp_close+0x7ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7ca:
	/* 0x7ca: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7d1:
	/* 0x7d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7d4:
	/* 0x7d4: je     7f3 <trace_filp_close+0x7f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d4, 0x7f3, x86_l_7f3);
x86_l_7d6:
	/* 0x7d6: lea    rsi,[r15+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7da:
	/* 0x7da: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7dd:
	/* 0x7dd: call   7e2 <trace_filp_close+0x7e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7e2:
	/* 0x7e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e5:
	/* 0x7e5: je     7f3 <trace_filp_close+0x7f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7e5, 0x7f3, x86_l_7f3);
x86_l_7e7:
	/* 0x7e7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ea:
	/* 0x7ea: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7ee:
	/* 0x7ee: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7f1:
	/* 0x7f1: jmp    7f5 <trace_filp_close+0x7f5> */
	X86_SIM_X86_JMP(0x7f1, 0x7f5, x86_l_7f5);
x86_l_7f3:
	/* 0x7f3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f5:
	/* 0x7f5: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7f8:
	/* 0x7f8: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7fb:
	/* 0x7fb: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7fe:
	/* 0x7fe: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_801:
	/* 0x801: cmp    QWORD PTR [r15+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_809:
	/* 0x809: je     9ef <trace_filp_close+0x9ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x809, 0x9ef, x86_l_9ef);
x86_l_80f:
	/* 0x80f: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_814:
	/* 0x814: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_81b:
	/* 0x81b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_81e:
	/* 0x81e: jns    834 <trace_filp_close+0x834> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x81e, 0x834, x86_l_834);
x86_l_820:
	/* 0x820: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_823:
	/* 0x823: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_826:
	/* 0x826: js     83b <trace_filp_close+0x83b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x826, 0x83b, x86_l_83b);
x86_l_828:
	/* 0x828: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82a:
	/* 0x82a: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_82d:
	/* 0x82d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_830:
	/* 0x830: js     846 <trace_filp_close+0x846> */
	X86_SIM_X86_JCC(X86_CC_S, 0x830, 0x846, x86_l_846);
x86_l_832:
	/* 0x832: jmp    891 <trace_filp_close+0x891> */
	X86_SIM_X86_JMP(0x832, 0x891, x86_l_891);
x86_l_834:
	/* 0x834: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_836:
	/* 0x836: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_839:
	/* 0x839: jns    828 <trace_filp_close+0x828> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x839, 0x828, x86_l_828);
x86_l_83b:
	/* 0x83b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_83e:
	/* 0x83e: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_841:
	/* 0x841: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_844:
	/* 0x844: jns    891 <trace_filp_close+0x891> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x844, 0x891, x86_l_891);
x86_l_846:
	/* 0x846: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_849:
	/* 0x849: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_84e:
	/* 0x84e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_852:
	/* 0x852: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_857:
	/* 0x857: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_85b:
	/* 0x85b: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_860:
	/* 0x860: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_864:
	/* 0x864: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_869:
	/* 0x869: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_86d:
	/* 0x86d: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_872:
	/* 0x872: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_876:
	/* 0x876: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_87b:
	/* 0x87b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_87f:
	/* 0x87f: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_884:
	/* 0x884: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_888:
	/* 0x888: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_88d:
	/* 0x88d: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_891:
	/* 0x891: lea    r13,[r15+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_895:
	/* 0x895: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_89a:
	/* 0x89a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89d:
	/* 0x89d: jns    975 <trace_filp_close+0x975> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x89d, 0x975, x86_l_975);
x86_l_8a3:
	/* 0x8a3: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8a6:
	/* 0x8a6: mov    BYTE PTR [r13+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8aa:
	/* 0x8aa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8ac:
	/* 0x8ac: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ac, 0x985, x86_l_985);
x86_l_8b2:
	/* 0x8b2: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_8b6:
	/* 0x8b6: mov    BYTE PTR [r15+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_8ba:
	/* 0x8ba: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8bc:
	/* 0x8bc: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8bc, 0x985, x86_l_985);
x86_l_8c2:
	/* 0x8c2: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_8c6:
	/* 0x8c6: mov    BYTE PTR [r15+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_8ca:
	/* 0x8ca: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8cc:
	/* 0x8cc: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8cc, 0x985, x86_l_985);
x86_l_8d2:
	/* 0x8d2: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_8d6:
	/* 0x8d6: mov    BYTE PTR [r15+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_8da:
	/* 0x8da: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8dc:
	/* 0x8dc: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8dc, 0x985, x86_l_985);
x86_l_8e2:
	/* 0x8e2: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_8e6:
	/* 0x8e6: mov    BYTE PTR [r15+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8ea:
	/* 0x8ea: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8ec:
	/* 0x8ec: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ec, 0x985, x86_l_985);
x86_l_8f2:
	/* 0x8f2: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_8f6:
	/* 0x8f6: mov    BYTE PTR [r15+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_8fa:
	/* 0x8fa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8fc:
	/* 0x8fc: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8fc, 0x985, x86_l_985);
x86_l_902:
	/* 0x902: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_906:
	/* 0x906: mov    BYTE PTR [r15+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_90a:
	/* 0x90a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_90c:
	/* 0x90c: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90c, 0x985, x86_l_985);
x86_l_90e:
	/* 0x90e: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_912:
	/* 0x912: mov    BYTE PTR [r15+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_916:
	/* 0x916: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_918:
	/* 0x918: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x918, 0x985, x86_l_985);
x86_l_91a:
	/* 0x91a: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_91e:
	/* 0x91e: mov    BYTE PTR [r15+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_922:
	/* 0x922: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_924:
	/* 0x924: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x924, 0x985, x86_l_985);
x86_l_926:
	/* 0x926: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_92a:
	/* 0x92a: mov    BYTE PTR [r15+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_92e:
	/* 0x92e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_930:
	/* 0x930: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x930, 0x985, x86_l_985);
x86_l_932:
	/* 0x932: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_936:
	/* 0x936: mov    BYTE PTR [r15+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_93a:
	/* 0x93a: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_93c:
	/* 0x93c: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93c, 0x985, x86_l_985);
x86_l_93e:
	/* 0x93e: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_942:
	/* 0x942: mov    BYTE PTR [r15+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_946:
	/* 0x946: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_948:
	/* 0x948: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x948, 0x985, x86_l_985);
x86_l_94a:
	/* 0x94a: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_94e:
	/* 0x94e: mov    BYTE PTR [r15+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_952:
	/* 0x952: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_954:
	/* 0x954: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x954, 0x985, x86_l_985);
x86_l_956:
	/* 0x956: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_95a:
	/* 0x95a: mov    BYTE PTR [r15+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_95e:
	/* 0x95e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_960:
	/* 0x960: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x960, 0x985, x86_l_985);
x86_l_962:
	/* 0x962: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_966:
	/* 0x966: mov    BYTE PTR [r15+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_96a:
	/* 0x96a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_96c:
	/* 0x96c: je     985 <trace_filp_close+0x985> */
	X86_SIM_X86_JCC(X86_CC_E, 0x96c, 0x985, x86_l_985);
x86_l_96e:
	/* 0x96e: mov    BYTE PTR [r15+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_973:
	/* 0x973: jmp    985 <trace_filp_close+0x985> */
	X86_SIM_X86_JMP(0x973, 0x985, x86_l_985);
x86_l_975:
	/* 0x975: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_97d:
	/* 0x97d: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_985:
	/* 0x985: mov    rbx,QWORD PTR [r15+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_98c:
	/* 0x98c: mov    r14,QWORD PTR [r15+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_993:
	/* 0x993: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_996:
	/* 0x996: movzx  eax,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_99b:
	/* 0x99b: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9a0:
	/* 0x9a0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_9a7:
	/* 0x9a7: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9ac:
	/* 0x9ac: call   9b1 <trace_filp_close+0x9b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9b1:
	/* 0x9b1: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9b8:
	/* 0x9b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9bb:
	/* 0x9bb: je     9d9 <trace_filp_close+0x9d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9bb, 0x9d9, x86_l_9d9);
x86_l_9bd:
	/* 0x9bd: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c0:
	/* 0x9c0: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_9c3:
	/* 0x9c3: call   9c8 <trace_filp_close+0x9c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9c8:
	/* 0x9c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9cb:
	/* 0x9cb: je     9d9 <trace_filp_close+0x9d9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9cb, 0x9d9, x86_l_9d9);
x86_l_9cd:
	/* 0x9cd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9d0:
	/* 0x9d0: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9d4:
	/* 0x9d4: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9d7:
	/* 0x9d7: jmp    9db <trace_filp_close+0x9db> */
	X86_SIM_X86_JMP(0x9d7, 0x9db, x86_l_9db);
x86_l_9d9:
	/* 0x9d9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9db:
	/* 0x9db: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_9de:
	/* 0x9de: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9e1:
	/* 0x9e1: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9e4:
	/* 0x9e4: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9e7:
	/* 0x9e7: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9ea:
	/* 0x9ea: movzx  ebp,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_9ef:
	/* 0x9ef: cmp    QWORD PTR [r15+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_9f7:
	/* 0x9f7: je     a7a <trace_filp_close+0xa7a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f7, 0xa7a, x86_l_a7a);
x86_l_9fd:
	/* 0x9fd: mov    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_a00:
	/* 0xa00: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a03:
	/* 0xa03: lea    r13,[r15+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a07:
	/* 0xa07: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a0a:
	/* 0xa0a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a0f:
	/* 0xa0f: call   a14 <trace_filp_close+0xa14> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_a14:
	/* 0xa14: mov    rbx,QWORD PTR [r15+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_a1b:
	/* 0xa1b: mov    r14,QWORD PTR [r15+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_a22:
	/* 0xa22: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a25:
	/* 0xa25: mov    WORD PTR [rsp+0x20],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a2b:
	/* 0xa2b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_a32:
	/* 0xa32: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a37:
	/* 0xa37: call   a3c <trace_filp_close+0xa3c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a3c:
	/* 0xa3c: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a43:
	/* 0xa43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a46:
	/* 0xa46: je     a64 <trace_filp_close+0xa64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa46, 0xa64, x86_l_a64);
x86_l_a48:
	/* 0xa48: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a4b:
	/* 0xa4b: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a4e:
	/* 0xa4e: call   a53 <trace_filp_close+0xa53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a53:
	/* 0xa53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a56:
	/* 0xa56: je     a64 <trace_filp_close+0xa64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa56, 0xa64, x86_l_a64);
x86_l_a58:
	/* 0xa58: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a5b:
	/* 0xa5b: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a5f:
	/* 0xa5f: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a62:
	/* 0xa62: jmp    a66 <trace_filp_close+0xa66> */
	X86_SIM_X86_JMP(0xa62, 0xa66, x86_l_a66);
x86_l_a64:
	/* 0xa64: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a66:
	/* 0xa66: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_a69:
	/* 0xa69: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a6c:
	/* 0xa6c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a6f:
	/* 0xa6f: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a72:
	/* 0xa72: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a75:
	/* 0xa75: movzx  ebp,WORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_a7a:
	/* 0xa7a: mov    rbx,QWORD PTR [r15+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_a81:
	/* 0xa81: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a84:
	/* 0xa84: je     ae6 <trace_filp_close+0xae6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa84, 0xae6, x86_l_ae6);
x86_l_a86:
	/* 0xa86: mov    eax,DWORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a8a:
	/* 0xa8a: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a8e:
	/* 0xa8e: mov    r14,QWORD PTR [r15+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_a95:
	/* 0xa95: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a98:
	/* 0xa98: mov    WORD PTR [rsp+0x18],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a9d:
	/* 0xa9d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_aa4:
	/* 0xaa4: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_aa9:
	/* 0xaa9: call   aae <trace_filp_close+0xaae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_aae:
	/* 0xaae: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ab5:
	/* 0xab5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ab8:
	/* 0xab8: je     ad8 <trace_filp_close+0xad8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xab8, 0xad8, x86_l_ad8);
x86_l_aba:
	/* 0xaba: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_abf:
	/* 0xabf: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ac2:
	/* 0xac2: call   ac7 <trace_filp_close+0xac7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ac7:
	/* 0xac7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aca:
	/* 0xaca: je     ad8 <trace_filp_close+0xad8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaca, 0xad8, x86_l_ad8);
x86_l_acc:
	/* 0xacc: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_acf:
	/* 0xacf: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ad3:
	/* 0xad3: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ad6:
	/* 0xad6: jmp    ada <trace_filp_close+0xada> */
	X86_SIM_X86_JMP(0xad6, 0xada, x86_l_ada);
x86_l_ad8:
	/* 0xad8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ada:
	/* 0xada: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_add:
	/* 0xadd: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ae0:
	/* 0xae0: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ae3:
	/* 0xae3: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ae6:
	/* 0xae6: mov    rbx,QWORD PTR [r15+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_aed:
	/* 0xaed: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_af0:
	/* 0xaf0: je     b4c <trace_filp_close+0xb4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaf0, 0xb4c, x86_l_b4c);
x86_l_af2:
	/* 0xaf2: mov    r14,QWORD PTR [r15+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_af9:
	/* 0xaf9: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_afc:
	/* 0xafc: mov    WORD PTR [rsp+0x20],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b01:
	/* 0xb01: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_b08:
	/* 0xb08: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b0d:
	/* 0xb0d: call   b12 <trace_filp_close+0xb12> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b12:
	/* 0xb12: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b19:
	/* 0xb19: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1c:
	/* 0xb1c: je     b3e <trace_filp_close+0xb3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb1c, 0xb3e, x86_l_b3e);
x86_l_b1e:
	/* 0xb1e: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b21:
	/* 0xb21: add    rsi,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_b25:
	/* 0xb25: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b28:
	/* 0xb28: call   b2d <trace_filp_close+0xb2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b2d:
	/* 0xb2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b30:
	/* 0xb30: je     b3e <trace_filp_close+0xb3e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb30, 0xb3e, x86_l_b3e);
x86_l_b32:
	/* 0xb32: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b35:
	/* 0xb35: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b39:
	/* 0xb39: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b3c:
	/* 0xb3c: jmp    b40 <trace_filp_close+0xb40> */
	X86_SIM_X86_JMP(0xb3c, 0xb40, x86_l_b40);
x86_l_b3e:
	/* 0xb3e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b40:
	/* 0xb40: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b43:
	/* 0xb43: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b46:
	/* 0xb46: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b49:
	/* 0xb49: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b4c:
	/* 0xb4c: mov    rbx,QWORD PTR [r15+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_b53:
	/* 0xb53: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b56:
	/* 0xb56: je     bd9 <trace_filp_close+0xbd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb56, 0xbd9, x86_l_bd9);
x86_l_b5c:
	/* 0xb5c: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_b5e:
	/* 0xb5e: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b61:
	/* 0xb61: mov    r14,QWORD PTR [r15+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_b68:
	/* 0xb68: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b6b:
	/* 0xb6b: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b70:
	/* 0xb70: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_b77:
	/* 0xb77: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b7c:
	/* 0xb7c: call   b81 <trace_filp_close+0xb81> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b81:
	/* 0xb81: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b88:
	/* 0xb88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8b:
	/* 0xb8b: je     bc8 <trace_filp_close+0xbc8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8b, 0xbc8, x86_l_bc8);
x86_l_b8d:
	/* 0xb8d: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b90:
	/* 0xb90: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_b95:
	/* 0xb95: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_b99:
	/* 0xb99: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b9c:
	/* 0xb9c: call   ba1 <trace_filp_close+0xba1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ba1:
	/* 0xba1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba4:
	/* 0xba4: jne    bbc <trace_filp_close+0xbbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xba4, 0xbbc, x86_l_bbc);
x86_l_ba6:
	/* 0xba6: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_bab:
	/* 0xbab: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_baf:
	/* 0xbaf: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bb2:
	/* 0xbb2: call   bb7 <trace_filp_close+0xbb7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bb7:
	/* 0xbb7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bba:
	/* 0xbba: je     bc8 <trace_filp_close+0xbc8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbba, 0xbc8, x86_l_bc8);
x86_l_bbc:
	/* 0xbbc: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bbf:
	/* 0xbbf: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bc3:
	/* 0xbc3: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bc6:
	/* 0xbc6: jmp    bca <trace_filp_close+0xbca> */
	X86_SIM_X86_JMP(0xbc6, 0xbca, x86_l_bca);
x86_l_bc8:
	/* 0xbc8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bca:
	/* 0xbca: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bcd:
	/* 0xbcd: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bd0:
	/* 0xbd0: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bd3:
	/* 0xbd3: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_bd6:
	/* 0xbd6: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bd9:
	/* 0xbd9: mov    rax,QWORD PTR [r15+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_be0:
	/* 0xbe0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be3:
	/* 0xbe3: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be8:
	/* 0xbe8: je     bf6 <trace_filp_close+0xbf6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe8, 0xbf6, x86_l_bf6);
x86_l_bea:
	/* 0xbea: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_bef:
	/* 0xbef: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_bf3:
	/* 0xbf3: or     r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bf6:
	/* 0xbf6: and    r13,QWORD PTR [r15+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_bfd:
	/* 0xbfd: mov    rax,QWORD PTR [r15+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c04:
	/* 0xc04: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c07:
	/* 0xc07: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c0e:
	/* 0xc0e: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc0e, 0x29a3, x86_l_29a3);
x86_l_c14:
	/* 0xc14: mov    rax,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_c1c:
	/* 0xc1c: mov    r14,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c20:
	/* 0xc20: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_c23:
	/* 0xc23: je     c5d <trace_filp_close+0xc5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc23, 0xc5d, x86_l_c5d);
x86_l_c25:
	/* 0xc25: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_c2d:
	/* 0xc2d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_c34:
	/* 0xc34: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c39:
	/* 0xc39: call   c3e <trace_filp_close+0xc3e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c3e:
	/* 0xc3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c41:
	/* 0xc41: je     28c3 <trace_filp_close+0x28c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc41, 0x28c3, x86_l_28c3);
x86_l_c47:
	/* 0xc47: lea    rcx,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c4b:
	/* 0xc4b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c4e:
	/* 0xc4e: jns    c66 <trace_filp_close+0xc66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc4e, 0xc66, x86_l_c66);
x86_l_c50:
	/* 0xc50: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c53:
	/* 0xc53: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c56:
	/* 0xc56: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c59:
	/* 0xc59: js     c71 <trace_filp_close+0xc71> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc59, 0xc71, x86_l_c71);
x86_l_c5b:
	/* 0xc5b: jmp    c7c <trace_filp_close+0xc7c> */
	X86_SIM_X86_JMP(0xc5b, 0xc7c, x86_l_c7c);
x86_l_c5d:
	/* 0xc5d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c5f:
	/* 0xc5f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c61:
	/* 0xc61: jmp    2982 <trace_filp_close+0x2982> */
	X86_SIM_X86_JMP(0xc61, 0x2982, x86_l_2982);
x86_l_c66:
	/* 0xc66: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c69:
	/* 0xc69: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c6c:
	/* 0xc6c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c6f:
	/* 0xc6f: jns    c7c <trace_filp_close+0xc7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc6f, 0xc7c, x86_l_c7c);
x86_l_c71:
	/* 0xc71: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c73:
	/* 0xc73: test   cl,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_c76:
	/* 0xc76: jne    d9d <trace_filp_close+0xd9d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc76, 0xd9d, x86_l_d9d);
x86_l_c7c:
	/* 0xc7c: lea    rcx,[r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c80:
	/* 0xc80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c83:
	/* 0xc83: jns    c8a <trace_filp_close+0xc8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc83, 0xc8a, x86_l_c8a);
x86_l_c85:
	/* 0xc85: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c88:
	/* 0xc88: jmp    c8d <trace_filp_close+0xc8d> */
	X86_SIM_X86_JMP(0xc88, 0xc8d, x86_l_c8d);
x86_l_c8a:
	/* 0xc8a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c8d:
	/* 0xc8d: lea    rcx,[r8-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_c91:
	/* 0xc91: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c94:
	/* 0xc94: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c97:
	/* 0xc97: jns    cbb <trace_filp_close+0xcbb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc97, 0xcbb, x86_l_cbb);
x86_l_c99:
	/* 0xc99: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9c:
	/* 0xc9c: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_c9f:
	/* 0xc9f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ca2:
	/* 0xca2: js     cc5 <trace_filp_close+0xcc5> */
	X86_SIM_X86_JCC(X86_CC_S, 0xca2, 0xcc5, x86_l_cc5);
x86_l_ca4:
	/* 0xca4: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ca6:
	/* 0xca6: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_caa:
	/* 0xcaa: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_cad:
	/* 0xcad: js     cd1 <trace_filp_close+0xcd1> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcad, 0xcd1, x86_l_cd1);
x86_l_caf:
	/* 0xcaf: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cb1:
	/* 0xcb1: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_cb4:
	/* 0xcb4: jne    cdd <trace_filp_close+0xcdd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcb4, 0xcdd, x86_l_cdd);
x86_l_cb6:
	/* 0xcb6: jmp    d62 <trace_filp_close+0xd62> */
	X86_SIM_X86_JMP(0xcb6, 0xd62, x86_l_d62);
x86_l_cbb:
	/* 0xcbb: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cbd:
	/* 0xcbd: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_cc0:
	/* 0xcc0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_cc3:
	/* 0xcc3: jns    ca4 <trace_filp_close+0xca4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcc3, 0xca4, x86_l_ca4);
x86_l_cc5:
	/* 0xcc5: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc8:
	/* 0xcc8: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ccc:
	/* 0xccc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ccf:
	/* 0xccf: jns    caf <trace_filp_close+0xcaf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xccf, 0xcaf, x86_l_caf);
x86_l_cd1:
	/* 0xcd1: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd4:
	/* 0xcd4: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_cd7:
	/* 0xcd7: je     d62 <trace_filp_close+0xd62> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcd7, 0xd62, x86_l_d62);
x86_l_cdd:
	/* 0xcdd: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ce0:
	/* 0xce0: je     d62 <trace_filp_close+0xd62> */
	X86_SIM_X86_JCC(X86_CC_E, 0xce0, 0xd62, x86_l_d62);
x86_l_ce6:
	/* 0xce6: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cea:
	/* 0xcea: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ced:
	/* 0xced: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_cf3:
	/* 0xcf3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_cf6:
	/* 0xcf6: jns    cff <trace_filp_close+0xcff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcf6, 0xcff, x86_l_cff);
x86_l_cf8:
	/* 0xcf8: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cfb:
	/* 0xcfb: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cff:
	/* 0xcff: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_d03:
	/* 0xd03: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d06:
	/* 0xd06: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_d0d:
	/* 0xd0d: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_d10:
	/* 0xd10: je     16a7 <trace_filp_close+0x16a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd10, 0x16a7, x86_l_16a7);
x86_l_d16:
	/* 0xd16: mov    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_d19:
	/* 0xd19: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_d1b:
	/* 0xd1b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_d21:
	/* 0xd21: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d24:
	/* 0xd24: mov    r15d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_d2a:
	/* 0xd2a: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_d2d:
	/* 0xd2d: jns    1684 <trace_filp_close+0x1684> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd2d, 0x1684, x86_l_1684);
x86_l_d33:
	/* 0xd33: mov    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d36:
	/* 0xd36: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_d3a:
	/* 0xd3a: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d3c:
	/* 0xd3c: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d3f:
	/* 0xd3f: je     e09 <trace_filp_close+0xe09> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd3f, 0xe09, x86_l_e09);
x86_l_d45:
	/* 0xd45: lea    r15,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_d49:
	/* 0xd49: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_d4e:
	/* 0xd4e: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_d52:
	/* 0xd52: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d55:
	/* 0xd55: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_d58:
	/* 0xd58: jne    d3c <trace_filp_close+0xd3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd58, 0xd3c, x86_l_d3c);
x86_l_d5a:
	/* 0xd5a: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_d5d:
	/* 0xd5d: jmp    e0e <trace_filp_close+0xe0e> */
	X86_SIM_X86_JMP(0xd5d, 0xe0e, x86_l_e0e);
x86_l_d62:
	/* 0xd62: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d65:
	/* 0xd65: jne    16a7 <trace_filp_close+0x16a7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd65, 0x16a7, x86_l_16a7);
x86_l_d6b:
	/* 0xd6b: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d6e:
	/* 0xd6e: je     16a7 <trace_filp_close+0x16a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd6e, 0x16a7, x86_l_16a7);
x86_l_d74:
	/* 0xd74: add    r8,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_d78:
	/* 0xd78: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_d7b:
	/* 0xd7b: jns    dd1 <trace_filp_close+0xdd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd7b, 0xdd1, x86_l_dd1);
x86_l_d7d:
	/* 0xd7d: mov    rsi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d80:
	/* 0xd80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d83:
	/* 0xd83: js     dd8 <trace_filp_close+0xdd8> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd83, 0xdd8, x86_l_dd8);
x86_l_d85:
	/* 0xd85: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d87:
	/* 0xd87: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d8a:
	/* 0xd8a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d8d:
	/* 0xd8d: js     de3 <trace_filp_close+0xde3> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd8d, 0xde3, x86_l_de3);
x86_l_d8f:
	/* 0xd8f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d91:
	/* 0xd91: jmp    de6 <trace_filp_close+0xde6> */
	X86_SIM_X86_JMP(0xd91, 0xde6, x86_l_de6);
x86_l_d93:
	/* 0xd93: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_d98:
	/* 0xd98: jmp    1ca <trace_filp_close+0x1ca> */
	X86_SIM_X86_JMP(0xd98, 0x1ca, x86_l_1ca);
x86_l_d9d:
	/* 0xd9d: lea    rcx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_da4:
	/* 0xda4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_da7:
	/* 0xda7: jns    16bd <trace_filp_close+0x16bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xda7, 0x16bd, x86_l_16bd);
x86_l_dad:
	/* 0xdad: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_daf:
	/* 0xdaf: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_db6:
	/* 0xdb6: je     16f8 <trace_filp_close+0x16f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb6, 0x16f8, x86_l_16f8);
x86_l_dbc:
	/* 0xdbc: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_dc0:
	/* 0xdc0: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_dc4:
	/* 0xdc4: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_dc7:
	/* 0xdc7: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_dca:
	/* 0xdca: jne    daf <trace_filp_close+0xdaf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdca, 0xdaf, x86_l_daf);
x86_l_dcc:
	/* 0xdcc: jmp    28c3 <trace_filp_close+0x28c3> */
	X86_SIM_X86_JMP(0xdcc, 0x28c3, x86_l_28c3);
x86_l_dd1:
	/* 0xdd1: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd3:
	/* 0xdd3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dd6:
	/* 0xdd6: jns    d85 <trace_filp_close+0xd85> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdd6, 0xd85, x86_l_d85);
x86_l_dd8:
	/* 0xdd8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ddb:
	/* 0xddb: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dde:
	/* 0xdde: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_de1:
	/* 0xde1: jns    d8f <trace_filp_close+0xd8f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde1, 0xd8f, x86_l_d8f);
x86_l_de3:
	/* 0xde3: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de6:
	/* 0xde6: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_dea:
	/* 0xdea: mov    r15d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_df0:
	/* 0xdf0: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_df3:
	/* 0xdf3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_df6:
	/* 0xdf6: jns    e33 <trace_filp_close+0xe33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdf6, 0xe33, x86_l_e33);
x86_l_df8:
	/* 0xdf8: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dfb:
	/* 0xdfb: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dff:
	/* 0xdff: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_e02:
	/* 0xe02: js     e3e <trace_filp_close+0xe3e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe02, 0xe3e, x86_l_e3e);
x86_l_e04:
	/* 0xe04: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e07:
	/* 0xe07: jmp    e41 <trace_filp_close+0xe41> */
	X86_SIM_X86_JMP(0xe07, 0xe41, x86_l_e41);
x86_l_e09:
	/* 0xe09: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_e0e:
	/* 0xe0e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e12:
	/* 0xe12: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e15:
	/* 0xe15: jl     16a7 <trace_filp_close+0x16a7> */
	X86_SIM_X86_JCC(X86_CC_L, 0xe15, 0x16a7, x86_l_16a7);
x86_l_e1b:
	/* 0xe1b: mov    BYTE PTR [rax+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_e22:
	/* 0xe22: mov    r15d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e28:
	/* 0xe28: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e2b:
	/* 0xe2b: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e2e:
	/* 0xe2e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e31:
	/* 0xe31: js     df8 <trace_filp_close+0xdf8> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe31, 0xdf8, x86_l_df8);
x86_l_e33:
	/* 0xe33: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e35:
	/* 0xe35: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e39:
	/* 0xe39: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_e3c:
	/* 0xe3c: jns    e04 <trace_filp_close+0xe04> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe3c, 0xe04, x86_l_e04);
x86_l_e3e:
	/* 0xe3e: mov    r13,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e41:
	/* 0xe41: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e44:
	/* 0xe44: je     eca <trace_filp_close+0xeca> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe44, 0xeca, x86_l_eca);
x86_l_e4a:
	/* 0xe4a: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_e4d:
	/* 0xe4d: je     eca <trace_filp_close+0xeca> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4d, 0xeca, x86_l_eca);
x86_l_e4f:
	/* 0xe4f: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e53:
	/* 0xe53: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e56:
	/* 0xe56: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e5c:
	/* 0xe5c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e5f:
	/* 0xe5f: jns    e68 <trace_filp_close+0xe68> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe5f, 0xe68, x86_l_e68);
x86_l_e61:
	/* 0xe61: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e64:
	/* 0xe64: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e68:
	/* 0xe68: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_e6c:
	/* 0xe6c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_e6f:
	/* 0xe6f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_e76:
	/* 0xe76: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_e79:
	/* 0xe79: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e7c:
	/* 0xe7c: jb     28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0xe7c, 0x28ad, x86_l_28ad);
x86_l_e82:
	/* 0xe82: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_e85:
	/* 0xe85: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe85, 0x1697, x86_l_1697);
x86_l_e8b:
	/* 0xe8b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_e91:
	/* 0xe91: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e94:
	/* 0xe94: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_e97:
	/* 0xe97: jns    1105 <trace_filp_close+0x1105> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe97, 0x1105, x86_l_1105);
x86_l_e9d:
	/* 0xe9d: mov    QWORD PTR [rsp+0x10],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ea2:
	/* 0xea2: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ea5:
	/* 0xea5: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ea9:
	/* 0xea9: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eab:
	/* 0xeab: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_eae:
	/* 0xeae: je     f19 <trace_filp_close+0xf19> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeae, 0xf19, x86_l_f19);
x86_l_eb0:
	/* 0xeb0: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_eb4:
	/* 0xeb4: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_eb9:
	/* 0xeb9: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_ebd:
	/* 0xebd: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_ec0:
	/* 0xec0: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_ec3:
	/* 0xec3: jne    eab <trace_filp_close+0xeab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xec3, 0xeab, x86_l_eab);
x86_l_ec5:
	/* 0xec5: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_ec8:
	/* 0xec8: jmp    f1e <trace_filp_close+0xf1e> */
	X86_SIM_X86_JMP(0xec8, 0xf1e, x86_l_f1e);
x86_l_eca:
	/* 0xeca: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ecd:
	/* 0xecd: jne    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xecd, 0x1697, x86_l_1697);
x86_l_ed3:
	/* 0xed3: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ed6:
	/* 0xed6: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed6, 0x1697, x86_l_1697);
x86_l_edc:
	/* 0xedc: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee0:
	/* 0xee0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ee3:
	/* 0xee3: jns    eea <trace_filp_close+0xeea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xee3, 0xeea, x86_l_eea);
x86_l_ee5:
	/* 0xee5: mov    r13,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee8:
	/* 0xee8: jmp    eed <trace_filp_close+0xeed> */
	X86_SIM_X86_JMP(0xee8, 0xeed, x86_l_eed);
x86_l_eea:
	/* 0xeea: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_eed:
	/* 0xeed: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ef0:
	/* 0xef0: jns    ef7 <trace_filp_close+0xef7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xef0, 0xef7, x86_l_ef7);
x86_l_ef2:
	/* 0xef2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef5:
	/* 0xef5: jmp    ef9 <trace_filp_close+0xef9> */
	X86_SIM_X86_JMP(0xef5, 0xef9, x86_l_ef9);
x86_l_ef7:
	/* 0xef7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef9:
	/* 0xef9: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_efc:
	/* 0xefc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_eff:
	/* 0xeff: jns    f06 <trace_filp_close+0xf06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeff, 0xf06, x86_l_f06);
x86_l_f01:
	/* 0xf01: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f04:
	/* 0xf04: jmp    f08 <trace_filp_close+0xf08> */
	X86_SIM_X86_JMP(0xf04, 0xf08, x86_l_f08);
x86_l_f06:
	/* 0xf06: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f08:
	/* 0xf08: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f0c:
	/* 0xf0c: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f0f:
	/* 0xf0f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f12:
	/* 0xf12: jns    f49 <trace_filp_close+0xf49> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf12, 0xf49, x86_l_f49);
x86_l_f14:
	/* 0xf14: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f17:
	/* 0xf17: jmp    f4b <trace_filp_close+0xf4b> */
	X86_SIM_X86_JMP(0xf17, 0xf4b, x86_l_f4b);
x86_l_f19:
	/* 0xf19: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_f1e:
	/* 0xf1e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f22:
	/* 0xf22: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f25:
	/* 0xf25: jl     15eb <trace_filp_close+0x15eb> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf25, 0x15eb, x86_l_15eb);
x86_l_f2b:
	/* 0xf2b: mov    r15,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f30:
	/* 0xf30: lea    esi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f34:
	/* 0xf34: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_f3a:
	/* 0xf3a: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_f3e:
	/* 0xf3e: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f41:
	/* 0xf41: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f44:
	/* 0xf44: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f47:
	/* 0xf47: js     f14 <trace_filp_close+0xf14> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf47, 0xf14, x86_l_f14);
x86_l_f49:
	/* 0xf49: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f4b:
	/* 0xf4b: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f4f:
	/* 0xf4f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f52:
	/* 0xf52: jns    f59 <trace_filp_close+0xf59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf52, 0xf59, x86_l_f59);
x86_l_f54:
	/* 0xf54: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f57:
	/* 0xf57: jmp    f5b <trace_filp_close+0xf5b> */
	X86_SIM_X86_JMP(0xf57, 0xf5b, x86_l_f5b);
x86_l_f59:
	/* 0xf59: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f5b:
	/* 0xf5b: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f5e:
	/* 0xf5e: je     fe4 <trace_filp_close+0xfe4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf5e, 0xfe4, x86_l_fe4);
x86_l_f64:
	/* 0xf64: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f67:
	/* 0xf67: je     fe4 <trace_filp_close+0xfe4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf67, 0xfe4, x86_l_fe4);
x86_l_f69:
	/* 0xf69: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f6d:
	/* 0xf6d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f70:
	/* 0xf70: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_f76:
	/* 0xf76: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f79:
	/* 0xf79: jns    f82 <trace_filp_close+0xf82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf79, 0xf82, x86_l_f82);
x86_l_f7b:
	/* 0xf7b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7e:
	/* 0xf7e: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f82:
	/* 0xf82: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_f86:
	/* 0xf86: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_f89:
	/* 0xf89: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_f90:
	/* 0xf90: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_f93:
	/* 0xf93: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f96:
	/* 0xf96: jb     28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0xf96, 0x28ad, x86_l_28ad);
x86_l_f9c:
	/* 0xf9c: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_f9f:
	/* 0xf9f: je     171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf9f, 0x171c, x86_l_171c);
x86_l_fa5:
	/* 0xfa5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_fab:
	/* 0xfab: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fae:
	/* 0xfae: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_fb1:
	/* 0xfb1: jns    1684 <trace_filp_close+0x1684> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfb1, 0x1684, x86_l_1684);
x86_l_fb7:
	/* 0xfb7: mov    QWORD PTR [rsp+0x10],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fbc:
	/* 0xfbc: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fbf:
	/* 0xfbf: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_fc3:
	/* 0xfc3: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fc5:
	/* 0xfc5: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fc8:
	/* 0xfc8: je     1032 <trace_filp_close+0x1032> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc8, 0x1032, x86_l_1032);
x86_l_fca:
	/* 0xfca: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_fce:
	/* 0xfce: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_fd3:
	/* 0xfd3: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_fd7:
	/* 0xfd7: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_fda:
	/* 0xfda: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_fdd:
	/* 0xfdd: jne    fc5 <trace_filp_close+0xfc5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfdd, 0xfc5, x86_l_fc5);
x86_l_fdf:
	/* 0xfdf: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_fe2:
	/* 0xfe2: jmp    1037 <trace_filp_close+0x1037> */
	X86_SIM_X86_JMP(0xfe2, 0x1037, x86_l_1037);
x86_l_fe4:
	/* 0xfe4: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fe7:
	/* 0xfe7: jne    171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xfe7, 0x171c, x86_l_171c);
x86_l_fed:
	/* 0xfed: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ff0:
	/* 0xff0: je     171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff0, 0x171c, x86_l_171c);
x86_l_ff6:
	/* 0xff6: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ffa:
	/* 0xffa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ffd:
	/* 0xffd: jns    1004 <trace_filp_close+0x1004> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xffd, 0x1004, x86_l_1004);
x86_l_fff:
	/* 0xfff: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1002:
	/* 0x1002: jmp    1006 <trace_filp_close+0x1006> */
	X86_SIM_X86_JMP(0x1002, 0x1006, x86_l_1006);
x86_l_1004:
	/* 0x1004: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1006:
	/* 0x1006: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1009:
	/* 0x1009: jns    1010 <trace_filp_close+0x1010> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1009, 0x1010, x86_l_1010);
x86_l_100b:
	/* 0x100b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_100e:
	/* 0x100e: jmp    1012 <trace_filp_close+0x1012> */
	X86_SIM_X86_JMP(0x100e, 0x1012, x86_l_1012);
x86_l_1010:
	/* 0x1010: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1012:
	/* 0x1012: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1015:
	/* 0x1015: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1018:
	/* 0x1018: jns    101f <trace_filp_close+0x101f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1018, 0x101f, x86_l_101f);
x86_l_101a:
	/* 0x101a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_101d:
	/* 0x101d: jmp    1021 <trace_filp_close+0x1021> */
	X86_SIM_X86_JMP(0x101d, 0x1021, x86_l_1021);
x86_l_101f:
	/* 0x101f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1021:
	/* 0x1021: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1025:
	/* 0x1025: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1028:
	/* 0x1028: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_102b:
	/* 0x102b: jns    1062 <trace_filp_close+0x1062> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x102b, 0x1062, x86_l_1062);
x86_l_102d:
	/* 0x102d: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1030:
	/* 0x1030: jmp    1064 <trace_filp_close+0x1064> */
	X86_SIM_X86_JMP(0x1030, 0x1064, x86_l_1064);
x86_l_1032:
	/* 0x1032: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1037:
	/* 0x1037: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_103b:
	/* 0x103b: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_103e:
	/* 0x103e: jl     1130 <trace_filp_close+0x1130> */
	X86_SIM_X86_JCC(X86_CC_L, 0x103e, 0x1130, x86_l_1130);
x86_l_1044:
	/* 0x1044: mov    r15,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1049:
	/* 0x1049: lea    edi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_104d:
	/* 0x104d: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1053:
	/* 0x1053: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1057:
	/* 0x1057: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_105a:
	/* 0x105a: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_105d:
	/* 0x105d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1060:
	/* 0x1060: js     102d <trace_filp_close+0x102d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1060, 0x102d, x86_l_102d);
x86_l_1062:
	/* 0x1062: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1064:
	/* 0x1064: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1068:
	/* 0x1068: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_106b:
	/* 0x106b: jns    1072 <trace_filp_close+0x1072> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x106b, 0x1072, x86_l_1072);
x86_l_106d:
	/* 0x106d: mov    r13,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1070:
	/* 0x1070: jmp    1075 <trace_filp_close+0x1075> */
	X86_SIM_X86_JMP(0x1070, 0x1075, x86_l_1075);
x86_l_1072:
	/* 0x1072: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1075:
	/* 0x1075: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1078:
	/* 0x1078: je     1110 <trace_filp_close+0x1110> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1078, 0x1110, x86_l_1110);
x86_l_107e:
	/* 0x107e: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1081:
	/* 0x1081: je     1110 <trace_filp_close+0x1110> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1081, 0x1110, x86_l_1110);
x86_l_1087:
	/* 0x1087: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_108b:
	/* 0x108b: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108e:
	/* 0x108e: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1094:
	/* 0x1094: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1097:
	/* 0x1097: jns    10a0 <trace_filp_close+0x10a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1097, 0x10a0, x86_l_10a0);
x86_l_1099:
	/* 0x1099: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_109c:
	/* 0x109c: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10a0:
	/* 0x10a0: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_10a4:
	/* 0x10a4: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_10a7:
	/* 0x10a7: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10ae:
	/* 0x10ae: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_10b1:
	/* 0x10b1: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10b4:
	/* 0x10b4: jb     28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10b4, 0x28ad, x86_l_28ad);
x86_l_10ba:
	/* 0x10ba: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_10bd:
	/* 0x10bd: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10bd, 0x1697, x86_l_1697);
x86_l_10c3:
	/* 0x10c3: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_10c9:
	/* 0x10c9: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_10cc:
	/* 0x10cc: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_10cf:
	/* 0x10cf: jns    1105 <trace_filp_close+0x1105> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10cf, 0x1105, x86_l_1105);
x86_l_10d1:
	/* 0x10d1: mov    QWORD PTR [rsp+0x10],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10d6:
	/* 0x10d6: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10d9:
	/* 0x10d9: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10dd:
	/* 0x10dd: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10df:
	/* 0x10df: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10e2:
	/* 0x10e2: je     15ab <trace_filp_close+0x15ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e2, 0x15ab, x86_l_15ab);
x86_l_10e8:
	/* 0x10e8: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_10ec:
	/* 0x10ec: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_10f1:
	/* 0x10f1: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_10f5:
	/* 0x10f5: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_10f8:
	/* 0x10f8: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_10fb:
	/* 0x10fb: jne    10df <trace_filp_close+0x10df> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10fb, 0x10df, x86_l_10df);
x86_l_10fd:
	/* 0x10fd: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1100:
	/* 0x1100: jmp    15b0 <trace_filp_close+0x15b0> */
	X86_SIM_X86_JMP(0x1100, 0x15b0, x86_l_15b0);
x86_l_1105:
	/* 0x1105: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1108:
	/* 0x1108: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_110b:
	/* 0x110b: jmp    1687 <trace_filp_close+0x1687> */
	X86_SIM_X86_JMP(0x110b, 0x1687, x86_l_1687);
x86_l_1110:
	/* 0x1110: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1113:
	/* 0x1113: jne    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1113, 0x1697, x86_l_1697);
x86_l_1119:
	/* 0x1119: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_111c:
	/* 0x111c: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0x111c, 0x1697, x86_l_1697);
x86_l_1122:
	/* 0x1122: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1126:
	/* 0x1126: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1129:
	/* 0x1129: jns    113d <trace_filp_close+0x113d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1129, 0x113d, x86_l_113d);
x86_l_112b:
	/* 0x112b: mov    r13,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_112e:
	/* 0x112e: jmp    1140 <trace_filp_close+0x1140> */
	X86_SIM_X86_JMP(0x112e, 0x1140, x86_l_1140);
x86_l_1130:
	/* 0x1130: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1133:
	/* 0x1133: mov    r15,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1138:
	/* 0x1138: jmp    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JMP(0x1138, 0x1697, x86_l_1697);
x86_l_113d:
	/* 0x113d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1140:
	/* 0x1140: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1143:
	/* 0x1143: jns    114a <trace_filp_close+0x114a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1143, 0x114a, x86_l_114a);
x86_l_1145:
	/* 0x1145: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1148:
	/* 0x1148: jmp    114c <trace_filp_close+0x114c> */
	X86_SIM_X86_JMP(0x1148, 0x114c, x86_l_114c);
x86_l_114a:
	/* 0x114a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_114c:
	/* 0x114c: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_114f:
	/* 0x114f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1152:
	/* 0x1152: jns    1159 <trace_filp_close+0x1159> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1152, 0x1159, x86_l_1159);
x86_l_1154:
	/* 0x1154: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1157:
	/* 0x1157: jmp    115b <trace_filp_close+0x115b> */
	X86_SIM_X86_JMP(0x1157, 0x115b, x86_l_115b);
x86_l_1159:
	/* 0x1159: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_115b:
	/* 0x115b: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_115f:
	/* 0x115f: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1162:
	/* 0x1162: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1165:
	/* 0x1165: jns    15db <trace_filp_close+0x15db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1165, 0x15db, x86_l_15db);
x86_l_116b:
	/* 0x116b: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_116e:
	/* 0x116e: jmp    15dd <trace_filp_close+0x15dd> */
	X86_SIM_X86_JMP(0x116e, 0x15dd, x86_l_15dd);
x86_l_1173:
	/* 0x1173: mov    eax,DWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_117a:
	/* 0x117a: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_117e:
	/* 0x117e: mov    DWORD PTR [rsp+0x1c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1186:
	/* 0x1186: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_118d:
	/* 0x118d: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1192:
	/* 0x1192: call   1197 <trace_filp_close+0x1197> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1197:
	/* 0x1197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_119a:
	/* 0x119a: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x119a, 0x29a3, x86_l_29a3);
x86_l_11a0:
	/* 0x11a0: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11a3:
	/* 0x11a3: mov    eax,DWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11a7:
	/* 0x11a7: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11ab:
	/* 0x11ab: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_11b0:
	/* 0x11b0: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11b3:
	/* 0x11b3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b5:
	/* 0x11b5: call   11ba <trace_filp_close+0x11ba> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_11ba:
	/* 0x11ba: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_11c1:
	/* 0x11c1: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11c6:
	/* 0x11c6: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_11cb:
	/* 0x11cb: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11ce:
	/* 0x11ce: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11d1:
	/* 0x11d1: call   11d6 <trace_filp_close+0x11d6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_11d6:
	/* 0x11d6: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_11db:
	/* 0x11db: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_11de:
	/* 0x11de: call   11e3 <trace_filp_close+0x11e3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11e3:
	/* 0x11e3: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_11e8:
	/* 0x11e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11eb:
	/* 0x11eb: jne    1fb <trace_filp_close+0x1fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11eb, 0x1fb, x86_l_1fb);
x86_l_11f1:
	/* 0x11f1: jmp    29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JMP(0x11f1, 0x29a3, x86_l_29a3);
x86_l_11f6:
	/* 0x11f6: mov    eax,DWORD PTR [rsp+0x84] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_11fd:
	/* 0x11fd: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1201:
	/* 0x1201: mov    DWORD PTR [rsp+0x1c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1209:
	/* 0x1209: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1210:
	/* 0x1210: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1215:
	/* 0x1215: call   121a <trace_filp_close+0x121a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_121a:
	/* 0x121a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_121d:
	/* 0x121d: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x121d, 0x29a3, x86_l_29a3);
x86_l_1223:
	/* 0x1223: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1226:
	/* 0x1226: mov    eax,DWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_122a:
	/* 0x122a: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_122e:
	/* 0x122e: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_1233:
	/* 0x1233: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1236:
	/* 0x1236: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1238:
	/* 0x1238: call   123d <trace_filp_close+0x123d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_123d:
	/* 0x123d: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_1244:
	/* 0x1244: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1249:
	/* 0x1249: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_124e:
	/* 0x124e: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1251:
	/* 0x1251: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1254:
	/* 0x1254: call   1259 <trace_filp_close+0x1259> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1259:
	/* 0x1259: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_125e:
	/* 0x125e: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1261:
	/* 0x1261: call   1266 <trace_filp_close+0x1266> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1266:
	/* 0x1266: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1269:
	/* 0x1269: je     29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1269, 0x29a3, x86_l_29a3);
x86_l_126f:
	/* 0x126f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1272:
	/* 0x1272: mov    r12,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_1279:
	/* 0x1279: lea    rax,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_127e:
	/* 0x127e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1281:
	/* 0x1281: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1284:
	/* 0x1284: jns    145b <trace_filp_close+0x145b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1284, 0x145b, x86_l_145b);
x86_l_128a:
	/* 0x128a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_128d:
	/* 0x128d: jmp    145d <trace_filp_close+0x145d> */
	X86_SIM_X86_JMP(0x128d, 0x145d, x86_l_145d);
x86_l_1292:
	/* 0x1292: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1295:
	/* 0x1295: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1299:
	/* 0x1299: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_129c:
	/* 0x129c: jns    1440 <trace_filp_close+0x1440> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x129c, 0x1440, x86_l_1440);
x86_l_12a2:
	/* 0x12a2: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12a5:
	/* 0x12a5: mov    QWORD PTR [r15+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_12ac:
	/* 0x12ac: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_12b0:
	/* 0x12b0: mov    QWORD PTR [r15+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_12b7:
	/* 0x12b7: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12bb:
	/* 0x12bb: mov    QWORD PTR [r15+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_12c2:
	/* 0x12c2: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12c6:
	/* 0x12c6: mov    QWORD PTR [r15+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_12cd:
	/* 0x12cd: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12d1:
	/* 0x12d1: mov    QWORD PTR [r15+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_12d8:
	/* 0x12d8: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12dc:
	/* 0x12dc: mov    QWORD PTR [r15+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_12e3:
	/* 0x12e3: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_12e7:
	/* 0x12e7: mov    QWORD PTR [r15+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_12ee:
	/* 0x12ee: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12f2:
	/* 0x12f2: mov    QWORD PTR [r15+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_12f9:
	/* 0x12f9: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_12fd:
	/* 0x12fd: mov    QWORD PTR [r15+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1304:
	/* 0x1304: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1308:
	/* 0x1308: mov    QWORD PTR [r15+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_130f:
	/* 0x130f: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1313:
	/* 0x1313: mov    QWORD PTR [r15+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_131a:
	/* 0x131a: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_131e:
	/* 0x131e: mov    QWORD PTR [r15+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1325:
	/* 0x1325: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1329:
	/* 0x1329: mov    QWORD PTR [r15+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_1330:
	/* 0x1330: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1334:
	/* 0x1334: mov    QWORD PTR [r15+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_133b:
	/* 0x133b: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_133f:
	/* 0x133f: mov    QWORD PTR [r15+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1346:
	/* 0x1346: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_134a:
	/* 0x134a: mov    QWORD PTR [r15+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_1351:
	/* 0x1351: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1358:
	/* 0x1358: mov    QWORD PTR [r15+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_135f:
	/* 0x135f: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1366:
	/* 0x1366: mov    QWORD PTR [r15+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_136d:
	/* 0x136d: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1374:
	/* 0x1374: mov    QWORD PTR [r15+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_137b:
	/* 0x137b: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1382:
	/* 0x1382: mov    QWORD PTR [r15+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1389:
	/* 0x1389: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1390:
	/* 0x1390: mov    QWORD PTR [r15+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1397:
	/* 0x1397: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_139e:
	/* 0x139e: mov    QWORD PTR [r15+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_13a5:
	/* 0x13a5: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_13ac:
	/* 0x13ac: mov    QWORD PTR [r15+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_13b3:
	/* 0x13b3: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_13ba:
	/* 0x13ba: mov    QWORD PTR [r15+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_13c1:
	/* 0x13c1: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_13c8:
	/* 0x13c8: mov    QWORD PTR [r15+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_13cf:
	/* 0x13cf: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_13d6:
	/* 0x13d6: mov    QWORD PTR [r15+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_13dd:
	/* 0x13dd: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_13e4:
	/* 0x13e4: mov    QWORD PTR [r15+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_13eb:
	/* 0x13eb: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_13f2:
	/* 0x13f2: mov    QWORD PTR [r15+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_13f9:
	/* 0x13f9: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1400:
	/* 0x1400: mov    QWORD PTR [r15+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1407:
	/* 0x1407: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_140e:
	/* 0x140e: mov    QWORD PTR [r15+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1415:
	/* 0x1415: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_141c:
	/* 0x141c: mov    QWORD PTR [r15+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1423:
	/* 0x1423: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_142a:
	/* 0x142a: mov    QWORD PTR [r15+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_1431:
	/* 0x1431: movzx  eax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1436:
	/* 0x1436: mov    WORD PTR [r15+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_143b:
	/* 0x143b: jmp    2d4 <trace_filp_close+0x2d4> */
	X86_SIM_X86_JMP(0x143b, 0x2d4, x86_l_2d4);
x86_l_1440:
	/* 0x1440: add    r15,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1447:
	/* 0x1447: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_144c:
	/* 0x144c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_144f:
	/* 0x144f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1451:
	/* 0x1451: call   1456 <trace_filp_close+0x1456> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1456:
	/* 0x1456: jmp    29a3 <trace_filp_close+0x29a3> */
	X86_SIM_X86_JMP(0x1456, 0x29a3, x86_l_29a3);
x86_l_145b:
	/* 0x145b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_145d:
	/* 0x145d: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1462:
	/* 0x1462: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1466:
	/* 0x1466: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1469:
	/* 0x1469: jns    1470 <trace_filp_close+0x1470> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1469, 0x1470, x86_l_1470);
x86_l_146b:
	/* 0x146b: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_146e:
	/* 0x146e: jmp    1472 <trace_filp_close+0x1472> */
	X86_SIM_X86_JMP(0x146e, 0x1472, x86_l_1472);
x86_l_1470:
	/* 0x1470: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1472:
	/* 0x1472: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1476:
	/* 0x1476: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1478:
	/* 0x1478: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_147b:
	/* 0x147b: jns    1482 <trace_filp_close+0x1482> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x147b, 0x1482, x86_l_1482);
x86_l_147d:
	/* 0x147d: mov    r14,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1480:
	/* 0x1480: jmp    1485 <trace_filp_close+0x1485> */
	X86_SIM_X86_JMP(0x1480, 0x1485, x86_l_1485);
x86_l_1482:
	/* 0x1482: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1485:
	/* 0x1485: lea    rdx,[r14+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1489:
	/* 0x1489: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_148c:
	/* 0x148c: jns    1490 <trace_filp_close+0x1490> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148c, 0x1490, x86_l_1490);
x86_l_148e:
	/* 0x148e: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1490:
	/* 0x1490: mov    DWORD PTR [rbx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1493:
	/* 0x1493: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1498:
	/* 0x1498: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_149b:
	/* 0x149b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_149d:
	/* 0x149d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14a0:
	/* 0x14a0: jns    14a7 <trace_filp_close+0x14a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14a0, 0x14a7, x86_l_14a7);
x86_l_14a2:
	/* 0x14a2: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14a5:
	/* 0x14a5: jmp    14a9 <trace_filp_close+0x14a9> */
	X86_SIM_X86_JMP(0x14a5, 0x14a9, x86_l_14a9);
x86_l_14a7:
	/* 0x14a7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14a9:
	/* 0x14a9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14ac:
	/* 0x14ac: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14af:
	/* 0x14af: jns    14b3 <trace_filp_close+0x14b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14af, 0x14b3, x86_l_14b3);
x86_l_14b1:
	/* 0x14b1: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14b3:
	/* 0x14b3: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_14b5:
	/* 0x14b5: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_14b9:
	/* 0x14b9: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_14bc:
	/* 0x14bc: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_14c0:
	/* 0x14c0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14c2:
	/* 0x14c2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14c5:
	/* 0x14c5: jns    14c9 <trace_filp_close+0x14c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14c5, 0x14c9, x86_l_14c9);
x86_l_14c7:
	/* 0x14c7: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c9:
	/* 0x14c9: mov    DWORD PTR [rbx+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_14cc:
	/* 0x14cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14cf:
	/* 0x14cf: jns    14d6 <trace_filp_close+0x14d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14cf, 0x14d6, x86_l_14d6);
x86_l_14d1:
	/* 0x14d1: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14d4:
	/* 0x14d4: jmp    14d8 <trace_filp_close+0x14d8> */
	X86_SIM_X86_JMP(0x14d4, 0x14d8, x86_l_14d8);
x86_l_14d6:
	/* 0x14d6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14d8:
	/* 0x14d8: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14dc:
	/* 0x14dc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14de:
	/* 0x14de: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14e1:
	/* 0x14e1: jns    14e8 <trace_filp_close+0x14e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14e1, 0x14e8, x86_l_14e8);
x86_l_14e3:
	/* 0x14e3: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14e6:
	/* 0x14e6: jmp    14ea <trace_filp_close+0x14ea> */
	X86_SIM_X86_JMP(0x14e6, 0x14ea, x86_l_14ea);
x86_l_14e8:
	/* 0x14e8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14ea:
	/* 0x14ea: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14ed:
	/* 0x14ed: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14f0:
	/* 0x14f0: jns    14f4 <trace_filp_close+0x14f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14f0, 0x14f4, x86_l_14f4);
x86_l_14f2:
	/* 0x14f2: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14f4:
	/* 0x14f4: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_14f6:
	/* 0x14f6: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_14fa:
	/* 0x14fa: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_14fd:
	/* 0x14fd: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1501:
	/* 0x1501: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1503:
	/* 0x1503: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1506:
	/* 0x1506: jns    150a <trace_filp_close+0x150a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1506, 0x150a, x86_l_150a);
x86_l_1508:
	/* 0x1508: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_150a:
	/* 0x150a: mov    DWORD PTR [rbx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_150d:
	/* 0x150d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_150f:
	/* 0x150f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1512:
	/* 0x1512: jns    1519 <trace_filp_close+0x1519> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1512, 0x1519, x86_l_1519);
x86_l_1514:
	/* 0x1514: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1517:
	/* 0x1517: jmp    151b <trace_filp_close+0x151b> */
	X86_SIM_X86_JMP(0x1517, 0x151b, x86_l_151b);
x86_l_1519:
	/* 0x1519: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_151b:
	/* 0x151b: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_151e:
	/* 0x151e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1521:
	/* 0x1521: jns    1525 <trace_filp_close+0x1525> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1521, 0x1525, x86_l_1525);
x86_l_1523:
	/* 0x1523: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1525:
	/* 0x1525: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1527:
	/* 0x1527: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_152b:
	/* 0x152b: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_152e:
	/* 0x152e: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1532:
	/* 0x1532: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1534:
	/* 0x1534: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1537:
	/* 0x1537: jns    153e <trace_filp_close+0x153e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1537, 0x153e, x86_l_153e);
x86_l_1539:
	/* 0x1539: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153c:
	/* 0x153c: jmp    1540 <trace_filp_close+0x1540> */
	X86_SIM_X86_JMP(0x153c, 0x1540, x86_l_1540);
x86_l_153e:
	/* 0x153e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1540:
	/* 0x1540: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1544:
	/* 0x1544: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1547:
	/* 0x1547: jns    154b <trace_filp_close+0x154b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1547, 0x154b, x86_l_154b);
x86_l_1549:
	/* 0x1549: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154b:
	/* 0x154b: lea    rcx,[r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_154f:
	/* 0x154f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1552:
	/* 0x1552: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1554:
	/* 0x1554: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1557:
	/* 0x1557: jns    155e <trace_filp_close+0x155e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1557, 0x155e, x86_l_155e);
x86_l_1559:
	/* 0x1559: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_155c:
	/* 0x155c: jmp    1560 <trace_filp_close+0x1560> */
	X86_SIM_X86_JMP(0x155c, 0x1560, x86_l_1560);
x86_l_155e:
	/* 0x155e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1560:
	/* 0x1560: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1563:
	/* 0x1563: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1566:
	/* 0x1566: jns    156a <trace_filp_close+0x156a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1566, 0x156a, x86_l_156a);
x86_l_1568:
	/* 0x1568: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_156a:
	/* 0x156a: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_156c:
	/* 0x156c: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1570:
	/* 0x1570: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1573:
	/* 0x1573: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1577:
	/* 0x1577: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1579:
	/* 0x1579: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_157c:
	/* 0x157c: jns    1583 <trace_filp_close+0x1583> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157c, 0x1583, x86_l_1583);
x86_l_157e:
	/* 0x157e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1581:
	/* 0x1581: jmp    1585 <trace_filp_close+0x1585> */
	X86_SIM_X86_JMP(0x1581, 0x1585, x86_l_1585);
x86_l_1583:
	/* 0x1583: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1585:
	/* 0x1585: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1589:
	/* 0x1589: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_158c:
	/* 0x158c: jns    1590 <trace_filp_close+0x1590> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x158c, 0x1590, x86_l_1590);
x86_l_158e:
	/* 0x158e: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1590:
	/* 0x1590: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1592:
	/* 0x1592: jne    177e <trace_filp_close+0x177e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1592, 0x177e, x86_l_177e);
x86_l_1598:
	/* 0x1598: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_159a:
	/* 0x159a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_159d:
	/* 0x159d: jns    1759 <trace_filp_close+0x1759> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x159d, 0x1759, x86_l_1759);
x86_l_15a3:
	/* 0x15a3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15a6:
	/* 0x15a6: jmp    175b <trace_filp_close+0x175b> */
	X86_SIM_X86_JMP(0x15a6, 0x175b, x86_l_175b);
x86_l_15ab:
	/* 0x15ab: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_15b0:
	/* 0x15b0: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_15b4:
	/* 0x15b4: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_15b7:
	/* 0x15b7: jl     15eb <trace_filp_close+0x15eb> */
	X86_SIM_X86_JCC(X86_CC_L, 0x15b7, 0x15eb, x86_l_15eb);
x86_l_15b9:
	/* 0x15b9: mov    r15,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15be:
	/* 0x15be: lea    esi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_15c2:
	/* 0x15c2: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_15c8:
	/* 0x15c8: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_15cc:
	/* 0x15cc: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_15cf:
	/* 0x15cf: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_15d2:
	/* 0x15d2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15d5:
	/* 0x15d5: js     116b <trace_filp_close+0x116b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x15d5, 0x116b, x86_l_116b);
x86_l_15db:
	/* 0x15db: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15dd:
	/* 0x15dd: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15e1:
	/* 0x15e1: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15e4:
	/* 0x15e4: jns    15f5 <trace_filp_close+0x15f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15e4, 0x15f5, x86_l_15f5);
x86_l_15e6:
	/* 0x15e6: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e9:
	/* 0x15e9: jmp    15f7 <trace_filp_close+0x15f7> */
	X86_SIM_X86_JMP(0x15e9, 0x15f7, x86_l_15f7);
x86_l_15eb:
	/* 0x15eb: mov    r15,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15f0:
	/* 0x15f0: jmp    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JMP(0x15f0, 0x1697, x86_l_1697);
x86_l_15f5:
	/* 0x15f5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15f7:
	/* 0x15f7: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: je     1704 <trace_filp_close+0x1704> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15fa, 0x1704, x86_l_1704);
x86_l_1600:
	/* 0x1600: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1603:
	/* 0x1603: je     1704 <trace_filp_close+0x1704> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1603, 0x1704, x86_l_1704);
x86_l_1609:
	/* 0x1609: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_160d:
	/* 0x160d: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1610:
	/* 0x1610: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1616:
	/* 0x1616: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1619:
	/* 0x1619: jns    1622 <trace_filp_close+0x1622> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1619, 0x1622, x86_l_1622);
x86_l_161b:
	/* 0x161b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_161e:
	/* 0x161e: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1622:
	/* 0x1622: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1626:
	/* 0x1626: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1629:
	/* 0x1629: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1630:
	/* 0x1630: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1633:
	/* 0x1633: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1636:
	/* 0x1636: jb     28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1636, 0x28ad, x86_l_28ad);
x86_l_163c:
	/* 0x163c: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_163f:
	/* 0x163f: je     171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x163f, 0x171c, x86_l_171c);
x86_l_1645:
	/* 0x1645: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_164b:
	/* 0x164b: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_164e:
	/* 0x164e: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1651:
	/* 0x1651: jns    1684 <trace_filp_close+0x1684> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1651, 0x1684, x86_l_1684);
x86_l_1653:
	/* 0x1653: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1658:
	/* 0x1658: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_165c:
	/* 0x165c: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_165e:
	/* 0x165e: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1661:
	/* 0x1661: je     1990 <trace_filp_close+0x1990> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1661, 0x1990, x86_l_1990);
x86_l_1667:
	/* 0x1667: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_166b:
	/* 0x166b: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_1670:
	/* 0x1670: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1674:
	/* 0x1674: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1677:
	/* 0x1677: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_167a:
	/* 0x167a: jne    165e <trace_filp_close+0x165e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x167a, 0x165e, x86_l_165e);
x86_l_167c:
	/* 0x167c: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_167f:
	/* 0x167f: jmp    1995 <trace_filp_close+0x1995> */
	X86_SIM_X86_JMP(0x167f, 0x1995, x86_l_1995);
x86_l_1684:
	/* 0x1684: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1687:
	/* 0x1687: mov    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_168a:
	/* 0x168a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_168c:
	/* 0x168c: call   1691 <trace_filp_close+0x1691> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1691:
	/* 0x1691: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1694:
	/* 0x1694: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1697:
	/* 0x1697: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_169a:
	/* 0x169a: cmp    r15d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_16a1:
	/* 0x16a1: jne    28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16a1, 0x28ad, x86_l_28ad);
x86_l_16a7:
	/* 0x16a7: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_16ab:
	/* 0x16ab: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_16ae:
	/* 0x16ae: jns    16d1 <trace_filp_close+0x16d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ae, 0x16d1, x86_l_16d1);
x86_l_16b0:
	/* 0x16b0: mov    rcx,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16b4:
	/* 0x16b4: mov    rcx,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16b8:
	/* 0x16b8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16bb:
	/* 0x16bb: js     16d8 <trace_filp_close+0x16d8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16bb, 0x16d8, x86_l_16d8);
x86_l_16bd:
	/* 0x16bd: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_16c2:
	/* 0x16c2: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16c5:
	/* 0x16c5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c7:
	/* 0x16c7: call   16cc <trace_filp_close+0x16cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_16cc:
	/* 0x16cc: jmp    28c3 <trace_filp_close+0x28c3> */
	X86_SIM_X86_JMP(0x16cc, 0x28c3, x86_l_28c3);
x86_l_16d1:
	/* 0x16d1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d3:
	/* 0x16d3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16d6:
	/* 0x16d6: jns    16bd <trace_filp_close+0x16bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16d6, 0x16bd, x86_l_16bd);
x86_l_16d8:
	/* 0x16d8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16da:
	/* 0x16da: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_16e1:
	/* 0x16e1: je     16f8 <trace_filp_close+0x16f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16e1, 0x16f8, x86_l_16f8);
x86_l_16e3:
	/* 0x16e3: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_16e7:
	/* 0x16e7: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_16eb:
	/* 0x16eb: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_16ee:
	/* 0x16ee: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_16f1:
	/* 0x16f1: jne    16da <trace_filp_close+0x16da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16f1, 0x16da, x86_l_16da);
x86_l_16f3:
	/* 0x16f3: jmp    28c3 <trace_filp_close+0x28c3> */
	X86_SIM_X86_JMP(0x16f3, 0x28c3, x86_l_28c3);
x86_l_16f8:
	/* 0x16f8: mov    BYTE PTR [rax+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_16ff:
	/* 0x16ff: jmp    28c3 <trace_filp_close+0x28c3> */
	X86_SIM_X86_JMP(0x16ff, 0x28c3, x86_l_28c3);
x86_l_1704:
	/* 0x1704: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1707:
	/* 0x1707: jne    171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1707, 0x171c, x86_l_171c);
x86_l_1709:
	/* 0x1709: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_170c:
	/* 0x170c: je     171c <trace_filp_close+0x171c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170c, 0x171c, x86_l_171c);
x86_l_170e:
	/* 0x170e: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1712:
	/* 0x1712: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1715:
	/* 0x1715: jns    1724 <trace_filp_close+0x1724> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1715, 0x1724, x86_l_1724);
x86_l_1717:
	/* 0x1717: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_171a:
	/* 0x171a: jmp    1726 <trace_filp_close+0x1726> */
	X86_SIM_X86_JMP(0x171a, 0x1726, x86_l_1726);
x86_l_171c:
	/* 0x171c: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_171f:
	/* 0x171f: jmp    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JMP(0x171f, 0x1697, x86_l_1697);
x86_l_1724:
	/* 0x1724: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1726:
	/* 0x1726: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1729:
	/* 0x1729: jns    1730 <trace_filp_close+0x1730> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1729, 0x1730, x86_l_1730);
x86_l_172b:
	/* 0x172b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_172e:
	/* 0x172e: jmp    1732 <trace_filp_close+0x1732> */
	X86_SIM_X86_JMP(0x172e, 0x1732, x86_l_1732);
x86_l_1730:
	/* 0x1730: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1732:
	/* 0x1732: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1735:
	/* 0x1735: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1738:
	/* 0x1738: jns    173f <trace_filp_close+0x173f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1738, 0x173f, x86_l_173f);
x86_l_173a:
	/* 0x173a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_173d:
	/* 0x173d: jmp    1741 <trace_filp_close+0x1741> */
	X86_SIM_X86_JMP(0x173d, 0x1741, x86_l_1741);
x86_l_173f:
	/* 0x173f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1741:
	/* 0x1741: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1745:
	/* 0x1745: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1748:
	/* 0x1748: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_174b:
	/* 0x174b: jns    19c1 <trace_filp_close+0x19c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x174b, 0x19c1, x86_l_19c1);
x86_l_1751:
	/* 0x1751: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1754:
	/* 0x1754: jmp    19c3 <trace_filp_close+0x19c3> */
	X86_SIM_X86_JMP(0x1754, 0x19c3, x86_l_19c3);
x86_l_1759:
	/* 0x1759: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_175b:
	/* 0x175b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_175e:
	/* 0x175e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1761:
	/* 0x1761: jns    1765 <trace_filp_close+0x1765> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1761, 0x1765, x86_l_1765);
x86_l_1763:
	/* 0x1763: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1765:
	/* 0x1765: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1767:
	/* 0x1767: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_176b:
	/* 0x176b: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_176e:
	/* 0x176e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1772:
	/* 0x1772: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1774:
	/* 0x1774: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1777:
	/* 0x1777: jns    177b <trace_filp_close+0x177b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1777, 0x177b, x86_l_177b);
x86_l_1779:
	/* 0x1779: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_177b:
	/* 0x177b: mov    DWORD PTR [rbx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_177e:
	/* 0x177e: mov    DWORD PTR [rbx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1781:
	/* 0x1781: lea    rbp,[r12+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1789:
	/* 0x1789: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_178c:
	/* 0x178c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_178f:
	/* 0x178f: jns    1796 <trace_filp_close+0x1796> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178f, 0x1796, x86_l_1796);
x86_l_1791:
	/* 0x1791: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1794:
	/* 0x1794: jmp    1798 <trace_filp_close+0x1798> */
	X86_SIM_X86_JMP(0x1794, 0x1798, x86_l_1798);
x86_l_1796:
	/* 0x1796: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1798:
	/* 0x1798: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_179c:
	/* 0x179c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_179e:
	/* 0x179e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17a1:
	/* 0x17a1: jns    17a8 <trace_filp_close+0x17a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17a1, 0x17a8, x86_l_17a8);
x86_l_17a3:
	/* 0x17a3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a6:
	/* 0x17a6: jmp    17aa <trace_filp_close+0x17aa> */
	X86_SIM_X86_JMP(0x17a6, 0x17aa, x86_l_17aa);
x86_l_17a8:
	/* 0x17a8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17aa:
	/* 0x17aa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17ad:
	/* 0x17ad: jns    17b1 <trace_filp_close+0x17b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ad, 0x17b1, x86_l_17b1);
x86_l_17af:
	/* 0x17af: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b1:
	/* 0x17b1: mov    DWORD PTR [rbx+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_17b4:
	/* 0x17b4: call   17b9 <trace_filp_close+0x17b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_17b9:
	/* 0x17b9: mov    DWORD PTR [rbx+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_17bc:
	/* 0x17bc: lea    rax,[r12+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_17c1:
	/* 0x17c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17c4:
	/* 0x17c4: jns    17cb <trace_filp_close+0x17cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c4, 0x17cb, x86_l_17cb);
x86_l_17c6:
	/* 0x17c6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c9:
	/* 0x17c9: jmp    17cd <trace_filp_close+0x17cd> */
	X86_SIM_X86_JMP(0x17c9, 0x17cd, x86_l_17cd);
x86_l_17cb:
	/* 0x17cb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17cd:
	/* 0x17cd: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d2:
	/* 0x17d2: mov    QWORD PTR [rbx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17d5:
	/* 0x17d5: add    rcx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_17d9:
	/* 0x17d9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17dc:
	/* 0x17dc: jns    17e3 <trace_filp_close+0x17e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17dc, 0x17e3, x86_l_17e3);
x86_l_17de:
	/* 0x17de: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17e1:
	/* 0x17e1: jmp    17e5 <trace_filp_close+0x17e5> */
	X86_SIM_X86_JMP(0x17e1, 0x17e5, x86_l_17e5);
x86_l_17e3:
	/* 0x17e3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17e5:
	/* 0x17e5: mov    QWORD PTR [rbx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_17e9:
	/* 0x17e9: add    r14,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_17ed:
	/* 0x17ed: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_17f0:
	/* 0x17f0: jns    17f7 <trace_filp_close+0x17f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17f0, 0x17f7, x86_l_17f7);
x86_l_17f2:
	/* 0x17f2: mov    rax,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17f5:
	/* 0x17f5: jmp    17f9 <trace_filp_close+0x17f9> */
	X86_SIM_X86_JMP(0x17f5, 0x17f9, x86_l_17f9);
x86_l_17f7:
	/* 0x17f7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f9:
	/* 0x17f9: mov    QWORD PTR [rbx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_17fd:
	/* 0x17fd: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1800:
	/* 0x1800: jns    180e <trace_filp_close+0x180e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1800, 0x180e, x86_l_180e);
x86_l_1802:
	/* 0x1802: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1806:
	/* 0x1806: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1808:
	/* 0x1808: je     180e <trace_filp_close+0x180e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1808, 0x180e, x86_l_180e);
x86_l_180a:
	/* 0x180a: or     BYTE PTR [rbx+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_180e:
	/* 0x180e: lea    rdi,[rbx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1812:
	/* 0x1812: mov    QWORD PTR [rbx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_181a:
	/* 0x181a: mov    QWORD PTR [rbx+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_1822:
	/* 0x1822: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1827:
	/* 0x1827: call   182c <trace_filp_close+0x182c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_182c:
	/* 0x182c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_182f:
	/* 0x182f: jns    1837 <trace_filp_close+0x1837> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x182f, 0x1837, x86_l_1837);
x86_l_1831:
	/* 0x1831: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1835:
	/* 0x1835: jmp    1839 <trace_filp_close+0x1839> */
	X86_SIM_X86_JMP(0x1835, 0x1839, x86_l_1839);
x86_l_1837:
	/* 0x1837: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1839:
	/* 0x1839: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_183c:
	/* 0x183c: jns    1843 <trace_filp_close+0x1843> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x183c, 0x1843, x86_l_1843);
x86_l_183e:
	/* 0x183e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1841:
	/* 0x1841: jmp    1845 <trace_filp_close+0x1845> */
	X86_SIM_X86_JMP(0x1841, 0x1845, x86_l_1845);
x86_l_1843:
	/* 0x1843: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1845:
	/* 0x1845: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1848:
	/* 0x1848: jns    1895 <trace_filp_close+0x1895> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1848, 0x1895, x86_l_1895);
x86_l_184a:
	/* 0x184a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_184d:
	/* 0x184d: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1852:
	/* 0x1852: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1856:
	/* 0x1856: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_185b:
	/* 0x185b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_185f:
	/* 0x185f: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1864:
	/* 0x1864: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1868:
	/* 0x1868: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_186d:
	/* 0x186d: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1871:
	/* 0x1871: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1876:
	/* 0x1876: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_187a:
	/* 0x187a: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_187f:
	/* 0x187f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1883:
	/* 0x1883: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1888:
	/* 0x1888: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_188c:
	/* 0x188c: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1891:
	/* 0x1891: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1895:
	/* 0x1895: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1898:
	/* 0x1898: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_189c:
	/* 0x189c: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18a1:
	/* 0x18a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18a4:
	/* 0x18a4: jns    1974 <trace_filp_close+0x1974> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18a4, 0x1974, x86_l_1974);
x86_l_18aa:
	/* 0x18aa: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_18ad:
	/* 0x18ad: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18af:
	/* 0x18af: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_18b1:
	/* 0x18b1: je     226 <trace_filp_close+0x226> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b1, 0x226, x86_l_226);
x86_l_18b7:
	/* 0x18b7: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_18bb:
	/* 0x18bb: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_18be:
	/* 0x18be: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18c0:
	/* 0x18c0: je     226 <trace_filp_close+0x226> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18c0, 0x226, x86_l_226);
x86_l_18c6:
	/* 0x18c6: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_18ca:
	/* 0x18ca: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_18cd:
	/* 0x18cd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18cf:
	/* 0x18cf: je     226 <trace_filp_close+0x226> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18cf, 0x226, x86_l_226);
x86_l_18d5:
	/* 0x18d5: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_18d9:
	/* 0x18d9: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18dc:
	/* 0x18dc: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_18df:
	/* 0x18df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18e1:
	/* 0x18e1: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e1, 0x1988, x86_l_1988);
x86_l_18e7:
	/* 0x18e7: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_18eb:
	/* 0x18eb: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_18ee:
	/* 0x18ee: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18f0:
	/* 0x18f0: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18f0, 0x1988, x86_l_1988);
x86_l_18f6:
	/* 0x18f6: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_18fa:
	/* 0x18fa: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_18fd:
	/* 0x18fd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18ff:
	/* 0x18ff: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18ff, 0x1988, x86_l_1988);
x86_l_1905:
	/* 0x1905: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1909:
	/* 0x1909: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_190c:
	/* 0x190c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_190e:
	/* 0x190e: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x190e, 0x1988, x86_l_1988);
x86_l_1910:
	/* 0x1910: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_1914:
	/* 0x1914: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_1917:
	/* 0x1917: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1919:
	/* 0x1919: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1919, 0x1988, x86_l_1988);
x86_l_191b:
	/* 0x191b: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_191f:
	/* 0x191f: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_1922:
	/* 0x1922: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1924:
	/* 0x1924: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1924, 0x1988, x86_l_1988);
x86_l_1926:
	/* 0x1926: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_192a:
	/* 0x192a: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_192d:
	/* 0x192d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_192f:
	/* 0x192f: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x192f, 0x1988, x86_l_1988);
x86_l_1931:
	/* 0x1931: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_1935:
	/* 0x1935: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1938:
	/* 0x1938: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_193a:
	/* 0x193a: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x193a, 0x1988, x86_l_1988);
x86_l_193c:
	/* 0x193c: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1940:
	/* 0x1940: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1943:
	/* 0x1943: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1945:
	/* 0x1945: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1945, 0x1988, x86_l_1988);
x86_l_1947:
	/* 0x1947: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_194b:
	/* 0x194b: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_194e:
	/* 0x194e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1950:
	/* 0x1950: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1950, 0x1988, x86_l_1988);
x86_l_1952:
	/* 0x1952: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1956:
	/* 0x1956: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1959:
	/* 0x1959: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_195b:
	/* 0x195b: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x195b, 0x1988, x86_l_1988);
x86_l_195d:
	/* 0x195d: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1961:
	/* 0x1961: mov    BYTE PTR [rdx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1964:
	/* 0x1964: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1966:
	/* 0x1966: je     1988 <trace_filp_close+0x1988> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1966, 0x1988, x86_l_1988);
x86_l_1968:
	/* 0x1968: mov    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_196b:
	/* 0x196b: mov    BYTE PTR [rdx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_196f:
	/* 0x196f: jmp    226 <trace_filp_close+0x226> */
	X86_SIM_X86_JMP(0x196f, 0x226, x86_l_226);
x86_l_1974:
	/* 0x1974: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_197c:
	/* 0x197c: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1983:
	/* 0x1983: jmp    226 <trace_filp_close+0x226> */
	X86_SIM_X86_JMP(0x1983, 0x226, x86_l_226);
x86_l_1988:
	/* 0x1988: mov    rbx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_198b:
	/* 0x198b: jmp    226 <trace_filp_close+0x226> */
	X86_SIM_X86_JMP(0x198b, 0x226, x86_l_226);
x86_l_1990:
	/* 0x1990: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1995:
	/* 0x1995: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1999:
	/* 0x1999: jl     1a8a <trace_filp_close+0x1a8a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1999, 0x1a8a, x86_l_1a8a);
x86_l_199f:
	/* 0x199f: lea    edi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_19a3:
	/* 0x19a3: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_19a9:
	/* 0x19a9: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_19ad:
	/* 0x19ad: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_19b0:
	/* 0x19b0: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b5:
	/* 0x19b5: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_19b8:
	/* 0x19b8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19bb:
	/* 0x19bb: js     1751 <trace_filp_close+0x1751> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19bb, 0x1751, x86_l_1751);
x86_l_19c1:
	/* 0x19c1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19c3:
	/* 0x19c3: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19c7:
	/* 0x19c7: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_19ca:
	/* 0x19ca: jns    19d1 <trace_filp_close+0x19d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19ca, 0x19d1, x86_l_19d1);
x86_l_19cc:
	/* 0x19cc: mov    r13,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19cf:
	/* 0x19cf: jmp    19d4 <trace_filp_close+0x19d4> */
	X86_SIM_X86_JMP(0x19cf, 0x19d4, x86_l_19d4);
x86_l_19d1:
	/* 0x19d1: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19d4:
	/* 0x19d4: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19d7:
	/* 0x19d7: je     1a62 <trace_filp_close+0x1a62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d7, 0x1a62, x86_l_1a62);
x86_l_19dd:
	/* 0x19dd: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_19e0:
	/* 0x19e0: je     1a62 <trace_filp_close+0x1a62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e0, 0x1a62, x86_l_1a62);
x86_l_19e6:
	/* 0x19e6: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19ea:
	/* 0x19ea: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19ed:
	/* 0x19ed: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_19f3:
	/* 0x19f3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19f6:
	/* 0x19f6: jns    19ff <trace_filp_close+0x19ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19f6, 0x19ff, x86_l_19ff);
x86_l_19f8:
	/* 0x19f8: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19fb:
	/* 0x19fb: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ff:
	/* 0x19ff: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a03:
	/* 0x1a03: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1a06:
	/* 0x1a06: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1a0d:
	/* 0x1a0d: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1a10:
	/* 0x1a10: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a13:
	/* 0x1a13: jb     28ad <trace_filp_close+0x28ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a13, 0x28ad, x86_l_28ad);
x86_l_1a19:
	/* 0x1a19: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1a1c:
	/* 0x1a1c: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1c, 0x1697, x86_l_1697);
x86_l_1a22:
	/* 0x1a22: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a27:
	/* 0x1a27: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1a2d:
	/* 0x1a2d: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a30:
	/* 0x1a30: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a33:
	/* 0x1a33: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1a36:
	/* 0x1a36: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a36, 0x26bd, x86_l_26bd);
x86_l_1a3c:
	/* 0x1a3c: lea    eax,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a40:
	/* 0x1a40: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a43:
	/* 0x1a43: cmp    rax,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1a46:
	/* 0x1a46: je     1ac1 <trace_filp_close+0x1ac1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a46, 0x1ac1, x86_l_1ac1);
x86_l_1a48:
	/* 0x1a48: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a4c:
	/* 0x1a4c: movzx  ebp,BYTE PTR [r10+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1a51:
	/* 0x1a51: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1a55:
	/* 0x1a55: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a58:
	/* 0x1a58: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1a5b:
	/* 0x1a5b: jne    1a43 <trace_filp_close+0x1a43> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a5b, 0x1a43, x86_l_1a43);
x86_l_1a5d:
	/* 0x1a5d: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1a60:
	/* 0x1a60: jmp    1ac5 <trace_filp_close+0x1ac5> */
	X86_SIM_X86_JMP(0x1a60, 0x1ac5, x86_l_1ac5);
x86_l_1a62:
	/* 0x1a62: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a65:
	/* 0x1a65: jne    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a65, 0x1697, x86_l_1697);
x86_l_1a6b:
	/* 0x1a6b: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a6e:
	/* 0x1a6e: je     1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a6e, 0x1697, x86_l_1697);
x86_l_1a74:
	/* 0x1a74: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a79:
	/* 0x1a79: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a7c:
	/* 0x1a7c: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a80:
	/* 0x1a80: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a83:
	/* 0x1a83: jns    1a92 <trace_filp_close+0x1a92> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a83, 0x1a92, x86_l_1a92);
x86_l_1a85:
	/* 0x1a85: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a88:
	/* 0x1a88: jmp    1a95 <trace_filp_close+0x1a95> */
	X86_SIM_X86_JMP(0x1a88, 0x1a95, x86_l_1a95);
x86_l_1a8a:
	/* 0x1a8a: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1a8d:
	/* 0x1a8d: jmp    2855 <trace_filp_close+0x2855> */
	X86_SIM_X86_JMP(0x1a8d, 0x2855, x86_l_2855);
x86_l_1a92:
	/* 0x1a92: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a95:
	/* 0x1a95: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a98:
	/* 0x1a98: jns    1a9f <trace_filp_close+0x1a9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a98, 0x1a9f, x86_l_1a9f);
x86_l_1a9a:
	/* 0x1a9a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a9d:
	/* 0x1a9d: jmp    1aa1 <trace_filp_close+0x1aa1> */
	X86_SIM_X86_JMP(0x1a9d, 0x1aa1, x86_l_1aa1);
x86_l_1a9f:
	/* 0x1a9f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aa1:
	/* 0x1aa1: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1aa4:
	/* 0x1aa4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1aa7:
	/* 0x1aa7: jns    1aae <trace_filp_close+0x1aae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aa7, 0x1aae, x86_l_1aae);
x86_l_1aa9:
	/* 0x1aa9: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1aac:
	/* 0x1aac: jmp    1ab0 <trace_filp_close+0x1ab0> */
	X86_SIM_X86_JMP(0x1aac, 0x1ab0, x86_l_1ab0);
x86_l_1aae:
	/* 0x1aae: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ab0:
	/* 0x1ab0: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ab4:
	/* 0x1ab4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ab7:
	/* 0x1ab7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1aba:
	/* 0x1aba: jns    1ae8 <trace_filp_close+0x1ae8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aba, 0x1ae8, x86_l_1ae8);
x86_l_1abc:
	/* 0x1abc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1abf:
	/* 0x1abf: jmp    1aea <trace_filp_close+0x1aea> */
	X86_SIM_X86_JMP(0x1abf, 0x1aea, x86_l_1aea);
x86_l_1ac1:
	/* 0x1ac1: mov    BYTE PTR [rdi+rax*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1ac5:
	/* 0x1ac5: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ac9:
	/* 0x1ac9: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ac9, 0x2852, x86_l_2852);
x86_l_1acf:
	/* 0x1acf: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ad3:
	/* 0x1ad3: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ad8:
	/* 0x1ad8: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1add:
	/* 0x1add: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ae0:
	/* 0x1ae0: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ae3:
	/* 0x1ae3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ae6:
	/* 0x1ae6: js     1abc <trace_filp_close+0x1abc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ae6, 0x1abc, x86_l_1abc);
x86_l_1ae8:
	/* 0x1ae8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aea:
	/* 0x1aea: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1aee:
	/* 0x1aee: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1af1:
	/* 0x1af1: jns    1af8 <trace_filp_close+0x1af8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af1, 0x1af8, x86_l_1af8);
x86_l_1af3:
	/* 0x1af3: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af6:
	/* 0x1af6: jmp    1afa <trace_filp_close+0x1afa> */
	X86_SIM_X86_JMP(0x1af6, 0x1afa, x86_l_1afa);
x86_l_1af8:
	/* 0x1af8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1afa:
	/* 0x1afa: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1afd:
	/* 0x1afd: je     1b77 <trace_filp_close+0x1b77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1afd, 0x1b77, x86_l_1b77);
x86_l_1aff:
	/* 0x1aff: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b02:
	/* 0x1b02: je     1b77 <trace_filp_close+0x1b77> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b02, 0x1b77, x86_l_1b77);
x86_l_1b04:
	/* 0x1b04: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b08:
	/* 0x1b08: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b0b:
	/* 0x1b0b: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1b10:
	/* 0x1b10: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b13:
	/* 0x1b13: jns    1b1c <trace_filp_close+0x1b1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b13, 0x1b1c, x86_l_1b1c);
x86_l_1b15:
	/* 0x1b15: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b18:
	/* 0x1b18: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b1c:
	/* 0x1b1c: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b20:
	/* 0x1b20: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1b23:
	/* 0x1b23: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b2a:
	/* 0x1b2a: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1b2d:
	/* 0x1b2d: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b30:
	/* 0x1b30: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b30, 0x28a5, x86_l_28a5);
x86_l_1b36:
	/* 0x1b36: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1b39:
	/* 0x1b39: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b39, 0x284f, x86_l_284f);
x86_l_1b3f:
	/* 0x1b3f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b45:
	/* 0x1b45: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b48:
	/* 0x1b48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b4b:
	/* 0x1b4b: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b4b, 0x27d0, x86_l_27d0);
x86_l_1b51:
	/* 0x1b51: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b55:
	/* 0x1b55: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b58:
	/* 0x1b58: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b5b:
	/* 0x1b5b: je     1bc5 <trace_filp_close+0x1bc5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5b, 0x1bc5, x86_l_1bc5);
x86_l_1b5d:
	/* 0x1b5d: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b61:
	/* 0x1b61: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b66:
	/* 0x1b66: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b6a:
	/* 0x1b6a: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b6d:
	/* 0x1b6d: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1b70:
	/* 0x1b70: jne    1b58 <trace_filp_close+0x1b58> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b70, 0x1b58, x86_l_1b58);
x86_l_1b72:
	/* 0x1b72: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1b75:
	/* 0x1b75: jmp    1bca <trace_filp_close+0x1bca> */
	X86_SIM_X86_JMP(0x1b75, 0x1bca, x86_l_1bca);
x86_l_1b77:
	/* 0x1b77: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b7a:
	/* 0x1b7a: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b7a, 0x284f, x86_l_284f);
x86_l_1b80:
	/* 0x1b80: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b83:
	/* 0x1b83: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b83, 0x284f, x86_l_284f);
x86_l_1b89:
	/* 0x1b89: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b8d:
	/* 0x1b8d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b90:
	/* 0x1b90: jns    1b97 <trace_filp_close+0x1b97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b90, 0x1b97, x86_l_1b97);
x86_l_1b92:
	/* 0x1b92: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b95:
	/* 0x1b95: jmp    1b99 <trace_filp_close+0x1b99> */
	X86_SIM_X86_JMP(0x1b95, 0x1b99, x86_l_1b99);
x86_l_1b97:
	/* 0x1b97: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b99:
	/* 0x1b99: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b9c:
	/* 0x1b9c: jns    1ba3 <trace_filp_close+0x1ba3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b9c, 0x1ba3, x86_l_1ba3);
x86_l_1b9e:
	/* 0x1b9e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ba1:
	/* 0x1ba1: jmp    1ba5 <trace_filp_close+0x1ba5> */
	X86_SIM_X86_JMP(0x1ba1, 0x1ba5, x86_l_1ba5);
x86_l_1ba3:
	/* 0x1ba3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ba5:
	/* 0x1ba5: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ba8:
	/* 0x1ba8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bab:
	/* 0x1bab: jns    1bb2 <trace_filp_close+0x1bb2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bab, 0x1bb2, x86_l_1bb2);
x86_l_1bad:
	/* 0x1bad: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bb0:
	/* 0x1bb0: jmp    1bb4 <trace_filp_close+0x1bb4> */
	X86_SIM_X86_JMP(0x1bb0, 0x1bb4, x86_l_1bb4);
x86_l_1bb2:
	/* 0x1bb2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bb4:
	/* 0x1bb4: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bb8:
	/* 0x1bb8: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1bbb:
	/* 0x1bbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bbe:
	/* 0x1bbe: jns    1bed <trace_filp_close+0x1bed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bbe, 0x1bed, x86_l_1bed);
x86_l_1bc0:
	/* 0x1bc0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bc3:
	/* 0x1bc3: jmp    1bef <trace_filp_close+0x1bef> */
	X86_SIM_X86_JMP(0x1bc3, 0x1bef, x86_l_1bef);
x86_l_1bc5:
	/* 0x1bc5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1bca:
	/* 0x1bca: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bce:
	/* 0x1bce: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1bce, 0x284f, x86_l_284f);
x86_l_1bd4:
	/* 0x1bd4: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bd8:
	/* 0x1bd8: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1bdd:
	/* 0x1bdd: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1be2:
	/* 0x1be2: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1be5:
	/* 0x1be5: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1be8:
	/* 0x1be8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1beb:
	/* 0x1beb: js     1bc0 <trace_filp_close+0x1bc0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1beb, 0x1bc0, x86_l_1bc0);
x86_l_1bed:
	/* 0x1bed: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bef:
	/* 0x1bef: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bf3:
	/* 0x1bf3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bf6:
	/* 0x1bf6: jns    1bfd <trace_filp_close+0x1bfd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bf6, 0x1bfd, x86_l_1bfd);
x86_l_1bf8:
	/* 0x1bf8: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bfb:
	/* 0x1bfb: jmp    1c00 <trace_filp_close+0x1c00> */
	X86_SIM_X86_JMP(0x1bfb, 0x1c00, x86_l_1c00);
x86_l_1bfd:
	/* 0x1bfd: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c00:
	/* 0x1c00: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c03:
	/* 0x1c03: je     1c7d <trace_filp_close+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c03, 0x1c7d, x86_l_1c7d);
x86_l_1c05:
	/* 0x1c05: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c08:
	/* 0x1c08: je     1c7d <trace_filp_close+0x1c7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c08, 0x1c7d, x86_l_1c7d);
x86_l_1c0a:
	/* 0x1c0a: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c0e:
	/* 0x1c0e: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c11:
	/* 0x1c11: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c16:
	/* 0x1c16: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c19:
	/* 0x1c19: jns    1c22 <trace_filp_close+0x1c22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c19, 0x1c22, x86_l_1c22);
x86_l_1c1b:
	/* 0x1c1b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c1e:
	/* 0x1c1e: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c22:
	/* 0x1c22: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c26:
	/* 0x1c26: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c29:
	/* 0x1c29: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c30:
	/* 0x1c30: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1c33:
	/* 0x1c33: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c36:
	/* 0x1c36: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c36, 0x28a5, x86_l_28a5);
x86_l_1c3c:
	/* 0x1c3c: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1c3f:
	/* 0x1c3f: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c3f, 0x2852, x86_l_2852);
x86_l_1c45:
	/* 0x1c45: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c4b:
	/* 0x1c4b: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c4e:
	/* 0x1c4e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c51:
	/* 0x1c51: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c51, 0x26bd, x86_l_26bd);
x86_l_1c57:
	/* 0x1c57: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c5b:
	/* 0x1c5b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c5e:
	/* 0x1c5e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c61:
	/* 0x1c61: je     1ccc <trace_filp_close+0x1ccc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c61, 0x1ccc, x86_l_1ccc);
x86_l_1c63:
	/* 0x1c63: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c67:
	/* 0x1c67: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c6c:
	/* 0x1c6c: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c70:
	/* 0x1c70: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c73:
	/* 0x1c73: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1c76:
	/* 0x1c76: jne    1c5e <trace_filp_close+0x1c5e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c76, 0x1c5e, x86_l_1c5e);
x86_l_1c78:
	/* 0x1c78: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1c7b:
	/* 0x1c7b: jmp    1cd1 <trace_filp_close+0x1cd1> */
	X86_SIM_X86_JMP(0x1c7b, 0x1cd1, x86_l_1cd1);
x86_l_1c7d:
	/* 0x1c7d: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c80:
	/* 0x1c80: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c80, 0x2852, x86_l_2852);
x86_l_1c86:
	/* 0x1c86: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c89:
	/* 0x1c89: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c89, 0x2852, x86_l_2852);
x86_l_1c8f:
	/* 0x1c8f: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c93:
	/* 0x1c93: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c96:
	/* 0x1c96: jns    1c9d <trace_filp_close+0x1c9d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c96, 0x1c9d, x86_l_1c9d);
x86_l_1c98:
	/* 0x1c98: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c9b:
	/* 0x1c9b: jmp    1ca0 <trace_filp_close+0x1ca0> */
	X86_SIM_X86_JMP(0x1c9b, 0x1ca0, x86_l_1ca0);
x86_l_1c9d:
	/* 0x1c9d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ca0:
	/* 0x1ca0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ca3:
	/* 0x1ca3: jns    1caa <trace_filp_close+0x1caa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca3, 0x1caa, x86_l_1caa);
x86_l_1ca5:
	/* 0x1ca5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca8:
	/* 0x1ca8: jmp    1cac <trace_filp_close+0x1cac> */
	X86_SIM_X86_JMP(0x1ca8, 0x1cac, x86_l_1cac);
x86_l_1caa:
	/* 0x1caa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cac:
	/* 0x1cac: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1caf:
	/* 0x1caf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb2:
	/* 0x1cb2: jns    1cb9 <trace_filp_close+0x1cb9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb2, 0x1cb9, x86_l_1cb9);
x86_l_1cb4:
	/* 0x1cb4: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cb7:
	/* 0x1cb7: jmp    1cbb <trace_filp_close+0x1cbb> */
	X86_SIM_X86_JMP(0x1cb7, 0x1cbb, x86_l_1cbb);
x86_l_1cb9:
	/* 0x1cb9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cbb:
	/* 0x1cbb: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cbf:
	/* 0x1cbf: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1cc2:
	/* 0x1cc2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc5:
	/* 0x1cc5: jns    1cf4 <trace_filp_close+0x1cf4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc5, 0x1cf4, x86_l_1cf4);
x86_l_1cc7:
	/* 0x1cc7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cca:
	/* 0x1cca: jmp    1cf6 <trace_filp_close+0x1cf6> */
	X86_SIM_X86_JMP(0x1cca, 0x1cf6, x86_l_1cf6);
x86_l_1ccc:
	/* 0x1ccc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1cd1:
	/* 0x1cd1: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1cd5:
	/* 0x1cd5: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1cd5, 0x2852, x86_l_2852);
x86_l_1cdb:
	/* 0x1cdb: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1cdf:
	/* 0x1cdf: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ce4:
	/* 0x1ce4: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1ce9:
	/* 0x1ce9: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cec:
	/* 0x1cec: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1cef:
	/* 0x1cef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cf2:
	/* 0x1cf2: js     1cc7 <trace_filp_close+0x1cc7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1cf2, 0x1cc7, x86_l_1cc7);
x86_l_1cf4:
	/* 0x1cf4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cf6:
	/* 0x1cf6: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cfa:
	/* 0x1cfa: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cfd:
	/* 0x1cfd: jns    1d04 <trace_filp_close+0x1d04> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cfd, 0x1d04, x86_l_1d04);
x86_l_1cff:
	/* 0x1cff: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d02:
	/* 0x1d02: jmp    1d06 <trace_filp_close+0x1d06> */
	X86_SIM_X86_JMP(0x1d02, 0x1d06, x86_l_1d06);
x86_l_1d04:
	/* 0x1d04: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d06:
	/* 0x1d06: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d09:
	/* 0x1d09: je     1d83 <trace_filp_close+0x1d83> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d09, 0x1d83, x86_l_1d83);
x86_l_1d0b:
	/* 0x1d0b: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d0e:
	/* 0x1d0e: je     1d83 <trace_filp_close+0x1d83> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d0e, 0x1d83, x86_l_1d83);
x86_l_1d10:
	/* 0x1d10: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d14:
	/* 0x1d14: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d17:
	/* 0x1d17: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d1c:
	/* 0x1d1c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d1f:
	/* 0x1d1f: jns    1d28 <trace_filp_close+0x1d28> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1f, 0x1d28, x86_l_1d28);
x86_l_1d21:
	/* 0x1d21: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d24:
	/* 0x1d24: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d28:
	/* 0x1d28: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1d2c:
	/* 0x1d2c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d2f:
	/* 0x1d2f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d36:
	/* 0x1d36: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1d39:
	/* 0x1d39: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d3c:
	/* 0x1d3c: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d3c, 0x28a5, x86_l_28a5);
x86_l_1d42:
	/* 0x1d42: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1d45:
	/* 0x1d45: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d45, 0x284f, x86_l_284f);
x86_l_1d4b:
	/* 0x1d4b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d51:
	/* 0x1d51: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d54:
	/* 0x1d54: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d57:
	/* 0x1d57: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d57, 0x27d0, x86_l_27d0);
x86_l_1d5d:
	/* 0x1d5d: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d61:
	/* 0x1d61: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d64:
	/* 0x1d64: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d67:
	/* 0x1d67: je     1dd1 <trace_filp_close+0x1dd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d67, 0x1dd1, x86_l_1dd1);
x86_l_1d69:
	/* 0x1d69: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d6d:
	/* 0x1d6d: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1d72:
	/* 0x1d72: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1d76:
	/* 0x1d76: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d79:
	/* 0x1d79: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1d7c:
	/* 0x1d7c: jne    1d64 <trace_filp_close+0x1d64> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d7c, 0x1d64, x86_l_1d64);
x86_l_1d7e:
	/* 0x1d7e: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d81:
	/* 0x1d81: jmp    1dd6 <trace_filp_close+0x1dd6> */
	X86_SIM_X86_JMP(0x1d81, 0x1dd6, x86_l_1dd6);
x86_l_1d83:
	/* 0x1d83: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d86:
	/* 0x1d86: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d86, 0x284f, x86_l_284f);
x86_l_1d8c:
	/* 0x1d8c: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d8f:
	/* 0x1d8f: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d8f, 0x284f, x86_l_284f);
x86_l_1d95:
	/* 0x1d95: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d99:
	/* 0x1d99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d9c:
	/* 0x1d9c: jns    1da3 <trace_filp_close+0x1da3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d9c, 0x1da3, x86_l_1da3);
x86_l_1d9e:
	/* 0x1d9e: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1da1:
	/* 0x1da1: jmp    1da5 <trace_filp_close+0x1da5> */
	X86_SIM_X86_JMP(0x1da1, 0x1da5, x86_l_1da5);
x86_l_1da3:
	/* 0x1da3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1da5:
	/* 0x1da5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1da8:
	/* 0x1da8: jns    1daf <trace_filp_close+0x1daf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1da8, 0x1daf, x86_l_1daf);
x86_l_1daa:
	/* 0x1daa: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dad:
	/* 0x1dad: jmp    1db1 <trace_filp_close+0x1db1> */
	X86_SIM_X86_JMP(0x1dad, 0x1db1, x86_l_1db1);
x86_l_1daf:
	/* 0x1daf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1db1:
	/* 0x1db1: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1db4:
	/* 0x1db4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1db7:
	/* 0x1db7: jns    1dbe <trace_filp_close+0x1dbe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1db7, 0x1dbe, x86_l_1dbe);
x86_l_1db9:
	/* 0x1db9: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dbc:
	/* 0x1dbc: jmp    1dc0 <trace_filp_close+0x1dc0> */
	X86_SIM_X86_JMP(0x1dbc, 0x1dc0, x86_l_1dc0);
x86_l_1dbe:
	/* 0x1dbe: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc0:
	/* 0x1dc0: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dc4:
	/* 0x1dc4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1dc7:
	/* 0x1dc7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dca:
	/* 0x1dca: jns    1df9 <trace_filp_close+0x1df9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dca, 0x1df9, x86_l_1df9);
x86_l_1dcc:
	/* 0x1dcc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dcf:
	/* 0x1dcf: jmp    1dfb <trace_filp_close+0x1dfb> */
	X86_SIM_X86_JMP(0x1dcf, 0x1dfb, x86_l_1dfb);
x86_l_1dd1:
	/* 0x1dd1: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1dd6:
	/* 0x1dd6: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1dda:
	/* 0x1dda: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1dda, 0x284f, x86_l_284f);
x86_l_1de0:
	/* 0x1de0: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1de4:
	/* 0x1de4: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1de9:
	/* 0x1de9: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1dee:
	/* 0x1dee: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1df1:
	/* 0x1df1: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1df4:
	/* 0x1df4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1df7:
	/* 0x1df7: js     1dcc <trace_filp_close+0x1dcc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1df7, 0x1dcc, x86_l_1dcc);
x86_l_1df9:
	/* 0x1df9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dfb:
	/* 0x1dfb: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dff:
	/* 0x1dff: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e02:
	/* 0x1e02: jns    1e09 <trace_filp_close+0x1e09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e02, 0x1e09, x86_l_1e09);
x86_l_1e04:
	/* 0x1e04: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e07:
	/* 0x1e07: jmp    1e0c <trace_filp_close+0x1e0c> */
	X86_SIM_X86_JMP(0x1e07, 0x1e0c, x86_l_1e0c);
x86_l_1e09:
	/* 0x1e09: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e0c:
	/* 0x1e0c: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e0f:
	/* 0x1e0f: je     1e89 <trace_filp_close+0x1e89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e0f, 0x1e89, x86_l_1e89);
x86_l_1e11:
	/* 0x1e11: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e14:
	/* 0x1e14: je     1e89 <trace_filp_close+0x1e89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e14, 0x1e89, x86_l_1e89);
x86_l_1e16:
	/* 0x1e16: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e1a:
	/* 0x1e1a: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e1d:
	/* 0x1e1d: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1e22:
	/* 0x1e22: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e25:
	/* 0x1e25: jns    1e2e <trace_filp_close+0x1e2e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e25, 0x1e2e, x86_l_1e2e);
x86_l_1e27:
	/* 0x1e27: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e2a:
	/* 0x1e2a: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e2e:
	/* 0x1e2e: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e32:
	/* 0x1e32: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e35:
	/* 0x1e35: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e3c:
	/* 0x1e3c: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e3f:
	/* 0x1e3f: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e42:
	/* 0x1e42: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e42, 0x28a5, x86_l_28a5);
x86_l_1e48:
	/* 0x1e48: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1e4b:
	/* 0x1e4b: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e4b, 0x2852, x86_l_2852);
x86_l_1e51:
	/* 0x1e51: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1e57:
	/* 0x1e57: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e5a:
	/* 0x1e5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e5d:
	/* 0x1e5d: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e5d, 0x26bd, x86_l_26bd);
x86_l_1e63:
	/* 0x1e63: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e67:
	/* 0x1e67: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e6a:
	/* 0x1e6a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1e6d:
	/* 0x1e6d: je     1ed8 <trace_filp_close+0x1ed8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e6d, 0x1ed8, x86_l_1ed8);
x86_l_1e6f:
	/* 0x1e6f: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e73:
	/* 0x1e73: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1e78:
	/* 0x1e78: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1e7c:
	/* 0x1e7c: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e7f:
	/* 0x1e7f: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1e82:
	/* 0x1e82: jne    1e6a <trace_filp_close+0x1e6a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e82, 0x1e6a, x86_l_1e6a);
x86_l_1e84:
	/* 0x1e84: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1e87:
	/* 0x1e87: jmp    1edd <trace_filp_close+0x1edd> */
	X86_SIM_X86_JMP(0x1e87, 0x1edd, x86_l_1edd);
x86_l_1e89:
	/* 0x1e89: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e8c:
	/* 0x1e8c: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e8c, 0x2852, x86_l_2852);
x86_l_1e92:
	/* 0x1e92: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e95:
	/* 0x1e95: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e95, 0x2852, x86_l_2852);
x86_l_1e9b:
	/* 0x1e9b: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e9f:
	/* 0x1e9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ea2:
	/* 0x1ea2: jns    1ea9 <trace_filp_close+0x1ea9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ea2, 0x1ea9, x86_l_1ea9);
x86_l_1ea4:
	/* 0x1ea4: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ea7:
	/* 0x1ea7: jmp    1eac <trace_filp_close+0x1eac> */
	X86_SIM_X86_JMP(0x1ea7, 0x1eac, x86_l_1eac);
x86_l_1ea9:
	/* 0x1ea9: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1eac:
	/* 0x1eac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1eaf:
	/* 0x1eaf: jns    1eb6 <trace_filp_close+0x1eb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eaf, 0x1eb6, x86_l_1eb6);
x86_l_1eb1:
	/* 0x1eb1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb4:
	/* 0x1eb4: jmp    1eb8 <trace_filp_close+0x1eb8> */
	X86_SIM_X86_JMP(0x1eb4, 0x1eb8, x86_l_1eb8);
x86_l_1eb6:
	/* 0x1eb6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1eb8:
	/* 0x1eb8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ebb:
	/* 0x1ebb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ebe:
	/* 0x1ebe: jns    1ec5 <trace_filp_close+0x1ec5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ebe, 0x1ec5, x86_l_1ec5);
x86_l_1ec0:
	/* 0x1ec0: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ec3:
	/* 0x1ec3: jmp    1ec7 <trace_filp_close+0x1ec7> */
	X86_SIM_X86_JMP(0x1ec3, 0x1ec7, x86_l_1ec7);
x86_l_1ec5:
	/* 0x1ec5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ec7:
	/* 0x1ec7: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ecb:
	/* 0x1ecb: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ece:
	/* 0x1ece: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ed1:
	/* 0x1ed1: jns    1f00 <trace_filp_close+0x1f00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ed1, 0x1f00, x86_l_1f00);
x86_l_1ed3:
	/* 0x1ed3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed6:
	/* 0x1ed6: jmp    1f02 <trace_filp_close+0x1f02> */
	X86_SIM_X86_JMP(0x1ed6, 0x1f02, x86_l_1f02);
x86_l_1ed8:
	/* 0x1ed8: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1edd:
	/* 0x1edd: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ee1:
	/* 0x1ee1: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ee1, 0x2852, x86_l_2852);
x86_l_1ee7:
	/* 0x1ee7: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eeb:
	/* 0x1eeb: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ef0:
	/* 0x1ef0: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1ef5:
	/* 0x1ef5: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ef8:
	/* 0x1ef8: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1efb:
	/* 0x1efb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1efe:
	/* 0x1efe: js     1ed3 <trace_filp_close+0x1ed3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1efe, 0x1ed3, x86_l_1ed3);
x86_l_1f00:
	/* 0x1f00: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f02:
	/* 0x1f02: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f06:
	/* 0x1f06: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f09:
	/* 0x1f09: jns    1f10 <trace_filp_close+0x1f10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f09, 0x1f10, x86_l_1f10);
x86_l_1f0b:
	/* 0x1f0b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f0e:
	/* 0x1f0e: jmp    1f12 <trace_filp_close+0x1f12> */
	X86_SIM_X86_JMP(0x1f0e, 0x1f12, x86_l_1f12);
x86_l_1f10:
	/* 0x1f10: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f12:
	/* 0x1f12: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f15:
	/* 0x1f15: je     1f8f <trace_filp_close+0x1f8f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f15, 0x1f8f, x86_l_1f8f);
x86_l_1f17:
	/* 0x1f17: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f1a:
	/* 0x1f1a: je     1f8f <trace_filp_close+0x1f8f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1a, 0x1f8f, x86_l_1f8f);
x86_l_1f1c:
	/* 0x1f1c: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f20:
	/* 0x1f20: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f23:
	/* 0x1f23: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f28:
	/* 0x1f28: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f2b:
	/* 0x1f2b: jns    1f34 <trace_filp_close+0x1f34> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f2b, 0x1f34, x86_l_1f34);
x86_l_1f2d:
	/* 0x1f2d: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f30:
	/* 0x1f30: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f34:
	/* 0x1f34: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f38:
	/* 0x1f38: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f3b:
	/* 0x1f3b: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f42:
	/* 0x1f42: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1f45:
	/* 0x1f45: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f48:
	/* 0x1f48: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f48, 0x28a5, x86_l_28a5);
x86_l_1f4e:
	/* 0x1f4e: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1f51:
	/* 0x1f51: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f51, 0x284f, x86_l_284f);
x86_l_1f57:
	/* 0x1f57: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f5d:
	/* 0x1f5d: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f60:
	/* 0x1f60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f63:
	/* 0x1f63: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f63, 0x27d0, x86_l_27d0);
x86_l_1f69:
	/* 0x1f69: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f6d:
	/* 0x1f6d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f70:
	/* 0x1f70: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1f73:
	/* 0x1f73: je     1fdd <trace_filp_close+0x1fdd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f73, 0x1fdd, x86_l_1fdd);
x86_l_1f75:
	/* 0x1f75: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f79:
	/* 0x1f79: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f7e:
	/* 0x1f7e: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f82:
	/* 0x1f82: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f85:
	/* 0x1f85: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1f88:
	/* 0x1f88: jne    1f70 <trace_filp_close+0x1f70> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f88, 0x1f70, x86_l_1f70);
x86_l_1f8a:
	/* 0x1f8a: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f8d:
	/* 0x1f8d: jmp    1fe2 <trace_filp_close+0x1fe2> */
	X86_SIM_X86_JMP(0x1f8d, 0x1fe2, x86_l_1fe2);
x86_l_1f8f:
	/* 0x1f8f: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f92:
	/* 0x1f92: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f92, 0x284f, x86_l_284f);
x86_l_1f98:
	/* 0x1f98: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f9b:
	/* 0x1f9b: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9b, 0x284f, x86_l_284f);
x86_l_1fa1:
	/* 0x1fa1: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fa5:
	/* 0x1fa5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fa8:
	/* 0x1fa8: jns    1faf <trace_filp_close+0x1faf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fa8, 0x1faf, x86_l_1faf);
x86_l_1faa:
	/* 0x1faa: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fad:
	/* 0x1fad: jmp    1fb1 <trace_filp_close+0x1fb1> */
	X86_SIM_X86_JMP(0x1fad, 0x1fb1, x86_l_1fb1);
x86_l_1faf:
	/* 0x1faf: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fb1:
	/* 0x1fb1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fb4:
	/* 0x1fb4: jns    1fbb <trace_filp_close+0x1fbb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb4, 0x1fbb, x86_l_1fbb);
x86_l_1fb6:
	/* 0x1fb6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb9:
	/* 0x1fb9: jmp    1fbd <trace_filp_close+0x1fbd> */
	X86_SIM_X86_JMP(0x1fb9, 0x1fbd, x86_l_1fbd);
x86_l_1fbb:
	/* 0x1fbb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fbd:
	/* 0x1fbd: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fc0:
	/* 0x1fc0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fc3:
	/* 0x1fc3: jns    1fca <trace_filp_close+0x1fca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc3, 0x1fca, x86_l_1fca);
x86_l_1fc5:
	/* 0x1fc5: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc8:
	/* 0x1fc8: jmp    1fcc <trace_filp_close+0x1fcc> */
	X86_SIM_X86_JMP(0x1fc8, 0x1fcc, x86_l_1fcc);
x86_l_1fca:
	/* 0x1fca: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fcc:
	/* 0x1fcc: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fd0:
	/* 0x1fd0: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1fd3:
	/* 0x1fd3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fd6:
	/* 0x1fd6: jns    2005 <trace_filp_close+0x2005> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd6, 0x2005, x86_l_2005);
x86_l_1fd8:
	/* 0x1fd8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fdb:
	/* 0x1fdb: jmp    2007 <trace_filp_close+0x2007> */
	X86_SIM_X86_JMP(0x1fdb, 0x2007, x86_l_2007);
x86_l_1fdd:
	/* 0x1fdd: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1fe2:
	/* 0x1fe2: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1fe6:
	/* 0x1fe6: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1fe6, 0x284f, x86_l_284f);
x86_l_1fec:
	/* 0x1fec: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ff0:
	/* 0x1ff0: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1ff5:
	/* 0x1ff5: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1ffa:
	/* 0x1ffa: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ffd:
	/* 0x1ffd: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2000:
	/* 0x2000: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2003:
	/* 0x2003: js     1fd8 <trace_filp_close+0x1fd8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2003, 0x1fd8, x86_l_1fd8);
x86_l_2005:
	/* 0x2005: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2007:
	/* 0x2007: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_200b:
	/* 0x200b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_200e:
	/* 0x200e: jns    2015 <trace_filp_close+0x2015> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x200e, 0x2015, x86_l_2015);
x86_l_2010:
	/* 0x2010: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2013:
	/* 0x2013: jmp    2018 <trace_filp_close+0x2018> */
	X86_SIM_X86_JMP(0x2013, 0x2018, x86_l_2018);
x86_l_2015:
	/* 0x2015: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2018:
	/* 0x2018: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201b:
	/* 0x201b: je     2095 <trace_filp_close+0x2095> */
	X86_SIM_X86_JCC(X86_CC_E, 0x201b, 0x2095, x86_l_2095);
x86_l_201d:
	/* 0x201d: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2020:
	/* 0x2020: je     2095 <trace_filp_close+0x2095> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2020, 0x2095, x86_l_2095);
x86_l_2022:
	/* 0x2022: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2026:
	/* 0x2026: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2029:
	/* 0x2029: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_202e:
	/* 0x202e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2031:
	/* 0x2031: jns    203a <trace_filp_close+0x203a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2031, 0x203a, x86_l_203a);
x86_l_2033:
	/* 0x2033: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2036:
	/* 0x2036: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_203a:
	/* 0x203a: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_203e:
	/* 0x203e: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2041:
	/* 0x2041: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2048:
	/* 0x2048: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_204b:
	/* 0x204b: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_204e:
	/* 0x204e: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x204e, 0x28a5, x86_l_28a5);
x86_l_2054:
	/* 0x2054: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2057:
	/* 0x2057: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2057, 0x2852, x86_l_2852);
x86_l_205d:
	/* 0x205d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2063:
	/* 0x2063: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2066:
	/* 0x2066: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2069:
	/* 0x2069: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2069, 0x26bd, x86_l_26bd);
x86_l_206f:
	/* 0x206f: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2073:
	/* 0x2073: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2076:
	/* 0x2076: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2079:
	/* 0x2079: je     20e4 <trace_filp_close+0x20e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2079, 0x20e4, x86_l_20e4);
x86_l_207b:
	/* 0x207b: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_207f:
	/* 0x207f: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2084:
	/* 0x2084: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2088:
	/* 0x2088: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_208b:
	/* 0x208b: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_208e:
	/* 0x208e: jne    2076 <trace_filp_close+0x2076> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x208e, 0x2076, x86_l_2076);
x86_l_2090:
	/* 0x2090: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2093:
	/* 0x2093: jmp    20e9 <trace_filp_close+0x20e9> */
	X86_SIM_X86_JMP(0x2093, 0x20e9, x86_l_20e9);
x86_l_2095:
	/* 0x2095: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2098:
	/* 0x2098: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2098, 0x2852, x86_l_2852);
x86_l_209e:
	/* 0x209e: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_20a1:
	/* 0x20a1: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a1, 0x2852, x86_l_2852);
x86_l_20a7:
	/* 0x20a7: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20ab:
	/* 0x20ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20ae:
	/* 0x20ae: jns    20b5 <trace_filp_close+0x20b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20ae, 0x20b5, x86_l_20b5);
x86_l_20b0:
	/* 0x20b0: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20b3:
	/* 0x20b3: jmp    20b8 <trace_filp_close+0x20b8> */
	X86_SIM_X86_JMP(0x20b3, 0x20b8, x86_l_20b8);
x86_l_20b5:
	/* 0x20b5: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20b8:
	/* 0x20b8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20bb:
	/* 0x20bb: jns    20c2 <trace_filp_close+0x20c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20bb, 0x20c2, x86_l_20c2);
x86_l_20bd:
	/* 0x20bd: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c0:
	/* 0x20c0: jmp    20c4 <trace_filp_close+0x20c4> */
	X86_SIM_X86_JMP(0x20c0, 0x20c4, x86_l_20c4);
x86_l_20c2:
	/* 0x20c2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20c4:
	/* 0x20c4: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20c7:
	/* 0x20c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20ca:
	/* 0x20ca: jns    20d1 <trace_filp_close+0x20d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20ca, 0x20d1, x86_l_20d1);
x86_l_20cc:
	/* 0x20cc: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20cf:
	/* 0x20cf: jmp    20d3 <trace_filp_close+0x20d3> */
	X86_SIM_X86_JMP(0x20cf, 0x20d3, x86_l_20d3);
x86_l_20d1:
	/* 0x20d1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20d3:
	/* 0x20d3: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20d7:
	/* 0x20d7: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_20da:
	/* 0x20da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20dd:
	/* 0x20dd: jns    210c <trace_filp_close+0x210c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20dd, 0x210c, x86_l_210c);
x86_l_20df:
	/* 0x20df: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e2:
	/* 0x20e2: jmp    210e <trace_filp_close+0x210e> */
	X86_SIM_X86_JMP(0x20e2, 0x210e, x86_l_210e);
x86_l_20e4:
	/* 0x20e4: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_20e9:
	/* 0x20e9: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20ed:
	/* 0x20ed: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x20ed, 0x2852, x86_l_2852);
x86_l_20f3:
	/* 0x20f3: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20f7:
	/* 0x20f7: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_20fc:
	/* 0x20fc: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2101:
	/* 0x2101: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2104:
	/* 0x2104: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2107:
	/* 0x2107: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_210a:
	/* 0x210a: js     20df <trace_filp_close+0x20df> */
	X86_SIM_X86_JCC(X86_CC_S, 0x210a, 0x20df, x86_l_20df);
x86_l_210c:
	/* 0x210c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210e:
	/* 0x210e: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2112:
	/* 0x2112: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2115:
	/* 0x2115: jns    211c <trace_filp_close+0x211c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2115, 0x211c, x86_l_211c);
x86_l_2117:
	/* 0x2117: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_211a:
	/* 0x211a: jmp    211e <trace_filp_close+0x211e> */
	X86_SIM_X86_JMP(0x211a, 0x211e, x86_l_211e);
x86_l_211c:
	/* 0x211c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_211e:
	/* 0x211e: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2121:
	/* 0x2121: je     219b <trace_filp_close+0x219b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2121, 0x219b, x86_l_219b);
x86_l_2123:
	/* 0x2123: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2126:
	/* 0x2126: je     219b <trace_filp_close+0x219b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2126, 0x219b, x86_l_219b);
x86_l_2128:
	/* 0x2128: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_212c:
	/* 0x212c: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_212f:
	/* 0x212f: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2134:
	/* 0x2134: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2137:
	/* 0x2137: jns    2140 <trace_filp_close+0x2140> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2137, 0x2140, x86_l_2140);
x86_l_2139:
	/* 0x2139: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213c:
	/* 0x213c: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2140:
	/* 0x2140: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2144:
	/* 0x2144: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2147:
	/* 0x2147: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_214e:
	/* 0x214e: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2151:
	/* 0x2151: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2154:
	/* 0x2154: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2154, 0x28a5, x86_l_28a5);
x86_l_215a:
	/* 0x215a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_215d:
	/* 0x215d: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x215d, 0x284f, x86_l_284f);
x86_l_2163:
	/* 0x2163: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2169:
	/* 0x2169: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_216c:
	/* 0x216c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_216f:
	/* 0x216f: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x216f, 0x27d0, x86_l_27d0);
x86_l_2175:
	/* 0x2175: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2179:
	/* 0x2179: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_217c:
	/* 0x217c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_217f:
	/* 0x217f: je     21e9 <trace_filp_close+0x21e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x217f, 0x21e9, x86_l_21e9);
x86_l_2181:
	/* 0x2181: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2185:
	/* 0x2185: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_218a:
	/* 0x218a: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_218e:
	/* 0x218e: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2191:
	/* 0x2191: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2194:
	/* 0x2194: jne    217c <trace_filp_close+0x217c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2194, 0x217c, x86_l_217c);
x86_l_2196:
	/* 0x2196: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2199:
	/* 0x2199: jmp    21ee <trace_filp_close+0x21ee> */
	X86_SIM_X86_JMP(0x2199, 0x21ee, x86_l_21ee);
x86_l_219b:
	/* 0x219b: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219e:
	/* 0x219e: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x219e, 0x284f, x86_l_284f);
x86_l_21a4:
	/* 0x21a4: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_21a7:
	/* 0x21a7: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a7, 0x284f, x86_l_284f);
x86_l_21ad:
	/* 0x21ad: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21b1:
	/* 0x21b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b4:
	/* 0x21b4: jns    21bb <trace_filp_close+0x21bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21b4, 0x21bb, x86_l_21bb);
x86_l_21b6:
	/* 0x21b6: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b9:
	/* 0x21b9: jmp    21bd <trace_filp_close+0x21bd> */
	X86_SIM_X86_JMP(0x21b9, 0x21bd, x86_l_21bd);
x86_l_21bb:
	/* 0x21bb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21bd:
	/* 0x21bd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21c0:
	/* 0x21c0: jns    21c7 <trace_filp_close+0x21c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21c0, 0x21c7, x86_l_21c7);
x86_l_21c2:
	/* 0x21c2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c5:
	/* 0x21c5: jmp    21c9 <trace_filp_close+0x21c9> */
	X86_SIM_X86_JMP(0x21c5, 0x21c9, x86_l_21c9);
x86_l_21c7:
	/* 0x21c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21c9:
	/* 0x21c9: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21cc:
	/* 0x21cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21cf:
	/* 0x21cf: jns    21d6 <trace_filp_close+0x21d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21cf, 0x21d6, x86_l_21d6);
x86_l_21d1:
	/* 0x21d1: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21d4:
	/* 0x21d4: jmp    21d8 <trace_filp_close+0x21d8> */
	X86_SIM_X86_JMP(0x21d4, 0x21d8, x86_l_21d8);
x86_l_21d6:
	/* 0x21d6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21d8:
	/* 0x21d8: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21dc:
	/* 0x21dc: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_21df:
	/* 0x21df: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21e2:
	/* 0x21e2: jns    2211 <trace_filp_close+0x2211> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21e2, 0x2211, x86_l_2211);
x86_l_21e4:
	/* 0x21e4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21e7:
	/* 0x21e7: jmp    2213 <trace_filp_close+0x2213> */
	X86_SIM_X86_JMP(0x21e7, 0x2213, x86_l_2213);
x86_l_21e9:
	/* 0x21e9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_21ee:
	/* 0x21ee: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_21f2:
	/* 0x21f2: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x21f2, 0x284f, x86_l_284f);
x86_l_21f8:
	/* 0x21f8: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21fc:
	/* 0x21fc: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2201:
	/* 0x2201: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2206:
	/* 0x2206: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2209:
	/* 0x2209: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_220c:
	/* 0x220c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_220f:
	/* 0x220f: js     21e4 <trace_filp_close+0x21e4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x220f, 0x21e4, x86_l_21e4);
x86_l_2211:
	/* 0x2211: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2213:
	/* 0x2213: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2217:
	/* 0x2217: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_221a:
	/* 0x221a: jns    2221 <trace_filp_close+0x2221> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x221a, 0x2221, x86_l_2221);
x86_l_221c:
	/* 0x221c: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_221f:
	/* 0x221f: jmp    2224 <trace_filp_close+0x2224> */
	X86_SIM_X86_JMP(0x221f, 0x2224, x86_l_2224);
x86_l_2221:
	/* 0x2221: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2224:
	/* 0x2224: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2227:
	/* 0x2227: je     22a1 <trace_filp_close+0x22a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2227, 0x22a1, x86_l_22a1);
x86_l_2229:
	/* 0x2229: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_222c:
	/* 0x222c: je     22a1 <trace_filp_close+0x22a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222c, 0x22a1, x86_l_22a1);
x86_l_222e:
	/* 0x222e: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2232:
	/* 0x2232: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2235:
	/* 0x2235: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_223a:
	/* 0x223a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_223d:
	/* 0x223d: jns    2246 <trace_filp_close+0x2246> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x223d, 0x2246, x86_l_2246);
x86_l_223f:
	/* 0x223f: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2242:
	/* 0x2242: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2246:
	/* 0x2246: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_224a:
	/* 0x224a: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_224d:
	/* 0x224d: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2254:
	/* 0x2254: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2257:
	/* 0x2257: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_225a:
	/* 0x225a: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x225a, 0x28a5, x86_l_28a5);
x86_l_2260:
	/* 0x2260: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2263:
	/* 0x2263: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2263, 0x2852, x86_l_2852);
x86_l_2269:
	/* 0x2269: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_226f:
	/* 0x226f: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2272:
	/* 0x2272: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2275:
	/* 0x2275: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2275, 0x26bd, x86_l_26bd);
x86_l_227b:
	/* 0x227b: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_227f:
	/* 0x227f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2282:
	/* 0x2282: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2285:
	/* 0x2285: je     22f0 <trace_filp_close+0x22f0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2285, 0x22f0, x86_l_22f0);
x86_l_2287:
	/* 0x2287: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_228b:
	/* 0x228b: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2290:
	/* 0x2290: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2294:
	/* 0x2294: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2297:
	/* 0x2297: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_229a:
	/* 0x229a: jne    2282 <trace_filp_close+0x2282> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x229a, 0x2282, x86_l_2282);
x86_l_229c:
	/* 0x229c: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_229f:
	/* 0x229f: jmp    22f5 <trace_filp_close+0x22f5> */
	X86_SIM_X86_JMP(0x229f, 0x22f5, x86_l_22f5);
x86_l_22a1:
	/* 0x22a1: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22a4:
	/* 0x22a4: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22a4, 0x2852, x86_l_2852);
x86_l_22aa:
	/* 0x22aa: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22ad:
	/* 0x22ad: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22ad, 0x2852, x86_l_2852);
x86_l_22b3:
	/* 0x22b3: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22b7:
	/* 0x22b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22ba:
	/* 0x22ba: jns    22c1 <trace_filp_close+0x22c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22ba, 0x22c1, x86_l_22c1);
x86_l_22bc:
	/* 0x22bc: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22bf:
	/* 0x22bf: jmp    22c4 <trace_filp_close+0x22c4> */
	X86_SIM_X86_JMP(0x22bf, 0x22c4, x86_l_22c4);
x86_l_22c1:
	/* 0x22c1: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22c4:
	/* 0x22c4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22c7:
	/* 0x22c7: jns    22ce <trace_filp_close+0x22ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22c7, 0x22ce, x86_l_22ce);
x86_l_22c9:
	/* 0x22c9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22cc:
	/* 0x22cc: jmp    22d0 <trace_filp_close+0x22d0> */
	X86_SIM_X86_JMP(0x22cc, 0x22d0, x86_l_22d0);
x86_l_22ce:
	/* 0x22ce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22d0:
	/* 0x22d0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_22d3:
	/* 0x22d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22d6:
	/* 0x22d6: jns    22dd <trace_filp_close+0x22dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22d6, 0x22dd, x86_l_22dd);
x86_l_22d8:
	/* 0x22d8: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22db:
	/* 0x22db: jmp    22df <trace_filp_close+0x22df> */
	X86_SIM_X86_JMP(0x22db, 0x22df, x86_l_22df);
x86_l_22dd:
	/* 0x22dd: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22df:
	/* 0x22df: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22e3:
	/* 0x22e3: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_22e6:
	/* 0x22e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22e9:
	/* 0x22e9: jns    2318 <trace_filp_close+0x2318> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e9, 0x2318, x86_l_2318);
x86_l_22eb:
	/* 0x22eb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ee:
	/* 0x22ee: jmp    231a <trace_filp_close+0x231a> */
	X86_SIM_X86_JMP(0x22ee, 0x231a, x86_l_231a);
x86_l_22f0:
	/* 0x22f0: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_22f5:
	/* 0x22f5: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_22f9:
	/* 0x22f9: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x22f9, 0x2852, x86_l_2852);
x86_l_22ff:
	/* 0x22ff: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2303:
	/* 0x2303: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2308:
	/* 0x2308: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_230d:
	/* 0x230d: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2310:
	/* 0x2310: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2313:
	/* 0x2313: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2316:
	/* 0x2316: js     22eb <trace_filp_close+0x22eb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2316, 0x22eb, x86_l_22eb);
x86_l_2318:
	/* 0x2318: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_231a:
	/* 0x231a: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_231e:
	/* 0x231e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2321:
	/* 0x2321: jns    2328 <trace_filp_close+0x2328> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2321, 0x2328, x86_l_2328);
x86_l_2323:
	/* 0x2323: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2326:
	/* 0x2326: jmp    232a <trace_filp_close+0x232a> */
	X86_SIM_X86_JMP(0x2326, 0x232a, x86_l_232a);
x86_l_2328:
	/* 0x2328: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_232a:
	/* 0x232a: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_232d:
	/* 0x232d: je     23a7 <trace_filp_close+0x23a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x232d, 0x23a7, x86_l_23a7);
x86_l_232f:
	/* 0x232f: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2332:
	/* 0x2332: je     23a7 <trace_filp_close+0x23a7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2332, 0x23a7, x86_l_23a7);
x86_l_2334:
	/* 0x2334: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2338:
	/* 0x2338: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_233b:
	/* 0x233b: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2340:
	/* 0x2340: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2343:
	/* 0x2343: jns    234c <trace_filp_close+0x234c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2343, 0x234c, x86_l_234c);
x86_l_2345:
	/* 0x2345: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2348:
	/* 0x2348: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_234c:
	/* 0x234c: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2350:
	/* 0x2350: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2353:
	/* 0x2353: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_235a:
	/* 0x235a: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_235d:
	/* 0x235d: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2360:
	/* 0x2360: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2360, 0x28a5, x86_l_28a5);
x86_l_2366:
	/* 0x2366: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2369:
	/* 0x2369: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2369, 0x284f, x86_l_284f);
x86_l_236f:
	/* 0x236f: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2375:
	/* 0x2375: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2378:
	/* 0x2378: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_237b:
	/* 0x237b: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x237b, 0x27d0, x86_l_27d0);
x86_l_2381:
	/* 0x2381: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2385:
	/* 0x2385: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2388:
	/* 0x2388: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_238b:
	/* 0x238b: je     23f5 <trace_filp_close+0x23f5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x238b, 0x23f5, x86_l_23f5);
x86_l_238d:
	/* 0x238d: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2391:
	/* 0x2391: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2396:
	/* 0x2396: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_239a:
	/* 0x239a: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_239d:
	/* 0x239d: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_23a0:
	/* 0x23a0: jne    2388 <trace_filp_close+0x2388> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23a0, 0x2388, x86_l_2388);
x86_l_23a2:
	/* 0x23a2: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_23a5:
	/* 0x23a5: jmp    23fa <trace_filp_close+0x23fa> */
	X86_SIM_X86_JMP(0x23a5, 0x23fa, x86_l_23fa);
x86_l_23a7:
	/* 0x23a7: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23aa:
	/* 0x23aa: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23aa, 0x284f, x86_l_284f);
x86_l_23b0:
	/* 0x23b0: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_23b3:
	/* 0x23b3: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23b3, 0x284f, x86_l_284f);
x86_l_23b9:
	/* 0x23b9: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23bd:
	/* 0x23bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23c0:
	/* 0x23c0: jns    23c7 <trace_filp_close+0x23c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c0, 0x23c7, x86_l_23c7);
x86_l_23c2:
	/* 0x23c2: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23c5:
	/* 0x23c5: jmp    23c9 <trace_filp_close+0x23c9> */
	X86_SIM_X86_JMP(0x23c5, 0x23c9, x86_l_23c9);
x86_l_23c7:
	/* 0x23c7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c9:
	/* 0x23c9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23cc:
	/* 0x23cc: jns    23d3 <trace_filp_close+0x23d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23cc, 0x23d3, x86_l_23d3);
x86_l_23ce:
	/* 0x23ce: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d1:
	/* 0x23d1: jmp    23d5 <trace_filp_close+0x23d5> */
	X86_SIM_X86_JMP(0x23d1, 0x23d5, x86_l_23d5);
x86_l_23d3:
	/* 0x23d3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d5:
	/* 0x23d5: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23d8:
	/* 0x23d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23db:
	/* 0x23db: jns    23e2 <trace_filp_close+0x23e2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23db, 0x23e2, x86_l_23e2);
x86_l_23dd:
	/* 0x23dd: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e0:
	/* 0x23e0: jmp    23e4 <trace_filp_close+0x23e4> */
	X86_SIM_X86_JMP(0x23e0, 0x23e4, x86_l_23e4);
x86_l_23e2:
	/* 0x23e2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e4:
	/* 0x23e4: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23e8:
	/* 0x23e8: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_23eb:
	/* 0x23eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23ee:
	/* 0x23ee: jns    241d <trace_filp_close+0x241d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23ee, 0x241d, x86_l_241d);
x86_l_23f0:
	/* 0x23f0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f3:
	/* 0x23f3: jmp    241f <trace_filp_close+0x241f> */
	X86_SIM_X86_JMP(0x23f3, 0x241f, x86_l_241f);
x86_l_23f5:
	/* 0x23f5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_23fa:
	/* 0x23fa: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_23fe:
	/* 0x23fe: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x23fe, 0x284f, x86_l_284f);
x86_l_2404:
	/* 0x2404: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2408:
	/* 0x2408: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_240d:
	/* 0x240d: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2412:
	/* 0x2412: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2415:
	/* 0x2415: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2418:
	/* 0x2418: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_241b:
	/* 0x241b: js     23f0 <trace_filp_close+0x23f0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x241b, 0x23f0, x86_l_23f0);
x86_l_241d:
	/* 0x241d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_241f:
	/* 0x241f: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2423:
	/* 0x2423: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2426:
	/* 0x2426: jns    242d <trace_filp_close+0x242d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2426, 0x242d, x86_l_242d);
x86_l_2428:
	/* 0x2428: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_242b:
	/* 0x242b: jmp    2430 <trace_filp_close+0x2430> */
	X86_SIM_X86_JMP(0x242b, 0x2430, x86_l_2430);
x86_l_242d:
	/* 0x242d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2430:
	/* 0x2430: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2433:
	/* 0x2433: je     24ad <trace_filp_close+0x24ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2433, 0x24ad, x86_l_24ad);
x86_l_2435:
	/* 0x2435: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2438:
	/* 0x2438: je     24ad <trace_filp_close+0x24ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2438, 0x24ad, x86_l_24ad);
x86_l_243a:
	/* 0x243a: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_243e:
	/* 0x243e: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2441:
	/* 0x2441: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2446:
	/* 0x2446: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2449:
	/* 0x2449: jns    2452 <trace_filp_close+0x2452> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2449, 0x2452, x86_l_2452);
x86_l_244b:
	/* 0x244b: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244e:
	/* 0x244e: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2452:
	/* 0x2452: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2456:
	/* 0x2456: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2459:
	/* 0x2459: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2460:
	/* 0x2460: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2463:
	/* 0x2463: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2466:
	/* 0x2466: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2466, 0x28a5, x86_l_28a5);
x86_l_246c:
	/* 0x246c: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_246f:
	/* 0x246f: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x246f, 0x2852, x86_l_2852);
x86_l_2475:
	/* 0x2475: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_247b:
	/* 0x247b: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_247e:
	/* 0x247e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2481:
	/* 0x2481: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2481, 0x26bd, x86_l_26bd);
x86_l_2487:
	/* 0x2487: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_248b:
	/* 0x248b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_248e:
	/* 0x248e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2491:
	/* 0x2491: je     24fc <trace_filp_close+0x24fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2491, 0x24fc, x86_l_24fc);
x86_l_2493:
	/* 0x2493: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2497:
	/* 0x2497: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_249c:
	/* 0x249c: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_24a0:
	/* 0x24a0: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24a3:
	/* 0x24a3: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_24a6:
	/* 0x24a6: jne    248e <trace_filp_close+0x248e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24a6, 0x248e, x86_l_248e);
x86_l_24a8:
	/* 0x24a8: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_24ab:
	/* 0x24ab: jmp    2501 <trace_filp_close+0x2501> */
	X86_SIM_X86_JMP(0x24ab, 0x2501, x86_l_2501);
x86_l_24ad:
	/* 0x24ad: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24b0:
	/* 0x24b0: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24b0, 0x2852, x86_l_2852);
x86_l_24b6:
	/* 0x24b6: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_24b9:
	/* 0x24b9: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24b9, 0x2852, x86_l_2852);
x86_l_24bf:
	/* 0x24bf: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24c3:
	/* 0x24c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24c6:
	/* 0x24c6: jns    24cd <trace_filp_close+0x24cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24c6, 0x24cd, x86_l_24cd);
x86_l_24c8:
	/* 0x24c8: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24cb:
	/* 0x24cb: jmp    24d0 <trace_filp_close+0x24d0> */
	X86_SIM_X86_JMP(0x24cb, 0x24d0, x86_l_24d0);
x86_l_24cd:
	/* 0x24cd: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24d0:
	/* 0x24d0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24d3:
	/* 0x24d3: jns    24da <trace_filp_close+0x24da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24d3, 0x24da, x86_l_24da);
x86_l_24d5:
	/* 0x24d5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d8:
	/* 0x24d8: jmp    24dc <trace_filp_close+0x24dc> */
	X86_SIM_X86_JMP(0x24d8, 0x24dc, x86_l_24dc);
x86_l_24da:
	/* 0x24da: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24dc:
	/* 0x24dc: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24df:
	/* 0x24df: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24e2:
	/* 0x24e2: jns    24e9 <trace_filp_close+0x24e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24e2, 0x24e9, x86_l_24e9);
x86_l_24e4:
	/* 0x24e4: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e7:
	/* 0x24e7: jmp    24eb <trace_filp_close+0x24eb> */
	X86_SIM_X86_JMP(0x24e7, 0x24eb, x86_l_24eb);
x86_l_24e9:
	/* 0x24e9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24eb:
	/* 0x24eb: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ef:
	/* 0x24ef: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24f2:
	/* 0x24f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24f5:
	/* 0x24f5: jns    2524 <trace_filp_close+0x2524> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f5, 0x2524, x86_l_2524);
x86_l_24f7:
	/* 0x24f7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fa:
	/* 0x24fa: jmp    2526 <trace_filp_close+0x2526> */
	X86_SIM_X86_JMP(0x24fa, 0x2526, x86_l_2526);
x86_l_24fc:
	/* 0x24fc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2501:
	/* 0x2501: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2505:
	/* 0x2505: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2505, 0x2852, x86_l_2852);
x86_l_250b:
	/* 0x250b: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_250f:
	/* 0x250f: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2514:
	/* 0x2514: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2519:
	/* 0x2519: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_251c:
	/* 0x251c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_251f:
	/* 0x251f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2522:
	/* 0x2522: js     24f7 <trace_filp_close+0x24f7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2522, 0x24f7, x86_l_24f7);
x86_l_2524:
	/* 0x2524: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2526:
	/* 0x2526: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_252a:
	/* 0x252a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_252d:
	/* 0x252d: jns    2534 <trace_filp_close+0x2534> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x252d, 0x2534, x86_l_2534);
x86_l_252f:
	/* 0x252f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2532:
	/* 0x2532: jmp    2536 <trace_filp_close+0x2536> */
	X86_SIM_X86_JMP(0x2532, 0x2536, x86_l_2536);
x86_l_2534:
	/* 0x2534: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2536:
	/* 0x2536: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2539:
	/* 0x2539: je     25b3 <trace_filp_close+0x25b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2539, 0x25b3, x86_l_25b3);
x86_l_253b:
	/* 0x253b: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_253e:
	/* 0x253e: je     25b3 <trace_filp_close+0x25b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x253e, 0x25b3, x86_l_25b3);
x86_l_2540:
	/* 0x2540: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2544:
	/* 0x2544: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2547:
	/* 0x2547: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_254c:
	/* 0x254c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_254f:
	/* 0x254f: jns    2558 <trace_filp_close+0x2558> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x254f, 0x2558, x86_l_2558);
x86_l_2551:
	/* 0x2551: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2554:
	/* 0x2554: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2558:
	/* 0x2558: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_255c:
	/* 0x255c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_255f:
	/* 0x255f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2566:
	/* 0x2566: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2569:
	/* 0x2569: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_256c:
	/* 0x256c: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x256c, 0x28a5, x86_l_28a5);
x86_l_2572:
	/* 0x2572: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2575:
	/* 0x2575: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2575, 0x284f, x86_l_284f);
x86_l_257b:
	/* 0x257b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2581:
	/* 0x2581: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2584:
	/* 0x2584: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2587:
	/* 0x2587: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2587, 0x27d0, x86_l_27d0);
x86_l_258d:
	/* 0x258d: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2591:
	/* 0x2591: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2594:
	/* 0x2594: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2597:
	/* 0x2597: je     2601 <trace_filp_close+0x2601> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2597, 0x2601, x86_l_2601);
x86_l_2599:
	/* 0x2599: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_259d:
	/* 0x259d: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_25a2:
	/* 0x25a2: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_25a6:
	/* 0x25a6: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25a9:
	/* 0x25a9: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_25ac:
	/* 0x25ac: jne    2594 <trace_filp_close+0x2594> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25ac, 0x2594, x86_l_2594);
x86_l_25ae:
	/* 0x25ae: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_25b1:
	/* 0x25b1: jmp    2606 <trace_filp_close+0x2606> */
	X86_SIM_X86_JMP(0x25b1, 0x2606, x86_l_2606);
x86_l_25b3:
	/* 0x25b3: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b6:
	/* 0x25b6: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25b6, 0x284f, x86_l_284f);
x86_l_25bc:
	/* 0x25bc: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25bf:
	/* 0x25bf: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25bf, 0x284f, x86_l_284f);
x86_l_25c5:
	/* 0x25c5: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25c9:
	/* 0x25c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25cc:
	/* 0x25cc: jns    25d3 <trace_filp_close+0x25d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25cc, 0x25d3, x86_l_25d3);
x86_l_25ce:
	/* 0x25ce: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25d1:
	/* 0x25d1: jmp    25d5 <trace_filp_close+0x25d5> */
	X86_SIM_X86_JMP(0x25d1, 0x25d5, x86_l_25d5);
x86_l_25d3:
	/* 0x25d3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25d5:
	/* 0x25d5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25d8:
	/* 0x25d8: jns    25df <trace_filp_close+0x25df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25d8, 0x25df, x86_l_25df);
x86_l_25da:
	/* 0x25da: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25dd:
	/* 0x25dd: jmp    25e1 <trace_filp_close+0x25e1> */
	X86_SIM_X86_JMP(0x25dd, 0x25e1, x86_l_25e1);
x86_l_25df:
	/* 0x25df: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25e1:
	/* 0x25e1: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25e4:
	/* 0x25e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e7:
	/* 0x25e7: jns    25ee <trace_filp_close+0x25ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e7, 0x25ee, x86_l_25ee);
x86_l_25e9:
	/* 0x25e9: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ec:
	/* 0x25ec: jmp    25f0 <trace_filp_close+0x25f0> */
	X86_SIM_X86_JMP(0x25ec, 0x25f0, x86_l_25f0);
x86_l_25ee:
	/* 0x25ee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f0:
	/* 0x25f0: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25f4:
	/* 0x25f4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_25f7:
	/* 0x25f7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25fa:
	/* 0x25fa: jns    2629 <trace_filp_close+0x2629> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25fa, 0x2629, x86_l_2629);
x86_l_25fc:
	/* 0x25fc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ff:
	/* 0x25ff: jmp    262b <trace_filp_close+0x262b> */
	X86_SIM_X86_JMP(0x25ff, 0x262b, x86_l_262b);
x86_l_2601:
	/* 0x2601: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2606:
	/* 0x2606: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_260a:
	/* 0x260a: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x260a, 0x284f, x86_l_284f);
x86_l_2610:
	/* 0x2610: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2614:
	/* 0x2614: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2619:
	/* 0x2619: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_261e:
	/* 0x261e: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2621:
	/* 0x2621: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2624:
	/* 0x2624: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2627:
	/* 0x2627: js     25fc <trace_filp_close+0x25fc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2627, 0x25fc, x86_l_25fc);
x86_l_2629:
	/* 0x2629: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_262b:
	/* 0x262b: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_262f:
	/* 0x262f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2632:
	/* 0x2632: jns    2639 <trace_filp_close+0x2639> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2632, 0x2639, x86_l_2639);
x86_l_2634:
	/* 0x2634: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2637:
	/* 0x2637: jmp    263c <trace_filp_close+0x263c> */
	X86_SIM_X86_JMP(0x2637, 0x263c, x86_l_263c);
x86_l_2639:
	/* 0x2639: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_263c:
	/* 0x263c: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263f:
	/* 0x263f: je     26ca <trace_filp_close+0x26ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x263f, 0x26ca, x86_l_26ca);
x86_l_2645:
	/* 0x2645: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2648:
	/* 0x2648: je     26ca <trace_filp_close+0x26ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2648, 0x26ca, x86_l_26ca);
x86_l_264e:
	/* 0x264e: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2652:
	/* 0x2652: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2655:
	/* 0x2655: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_265a:
	/* 0x265a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_265d:
	/* 0x265d: jns    2666 <trace_filp_close+0x2666> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x265d, 0x2666, x86_l_2666);
x86_l_265f:
	/* 0x265f: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2662:
	/* 0x2662: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2666:
	/* 0x2666: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_266a:
	/* 0x266a: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_266d:
	/* 0x266d: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2674:
	/* 0x2674: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2677:
	/* 0x2677: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_267a:
	/* 0x267a: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x267a, 0x28a5, x86_l_28a5);
x86_l_2680:
	/* 0x2680: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2683:
	/* 0x2683: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2683, 0x2852, x86_l_2852);
x86_l_2689:
	/* 0x2689: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_268f:
	/* 0x268f: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2692:
	/* 0x2692: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2695:
	/* 0x2695: jns    26bd <trace_filp_close+0x26bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2695, 0x26bd, x86_l_26bd);
x86_l_2697:
	/* 0x2697: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_269b:
	/* 0x269b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269e:
	/* 0x269e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_26a1:
	/* 0x26a1: je     2719 <trace_filp_close+0x2719> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a1, 0x2719, x86_l_2719);
x86_l_26a3:
	/* 0x26a3: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26a7:
	/* 0x26a7: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_26ac:
	/* 0x26ac: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_26b0:
	/* 0x26b0: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26b3:
	/* 0x26b3: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_26b6:
	/* 0x26b6: jne    269e <trace_filp_close+0x269e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26b6, 0x269e, x86_l_269e);
x86_l_26b8:
	/* 0x26b8: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_26bb:
	/* 0x26bb: jmp    271e <trace_filp_close+0x271e> */
	X86_SIM_X86_JMP(0x26bb, 0x271e, x86_l_271e);
x86_l_26bd:
	/* 0x26bd: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26c0:
	/* 0x26c0: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26c5:
	/* 0x26c5: jmp    1687 <trace_filp_close+0x1687> */
	X86_SIM_X86_JMP(0x26c5, 0x1687, x86_l_1687);
x86_l_26ca:
	/* 0x26ca: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26cd:
	/* 0x26cd: jne    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26cd, 0x2852, x86_l_2852);
x86_l_26d3:
	/* 0x26d3: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26d6:
	/* 0x26d6: je     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d6, 0x2852, x86_l_2852);
x86_l_26dc:
	/* 0x26dc: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26e0:
	/* 0x26e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26e3:
	/* 0x26e3: jns    26ea <trace_filp_close+0x26ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26e3, 0x26ea, x86_l_26ea);
x86_l_26e5:
	/* 0x26e5: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26e8:
	/* 0x26e8: jmp    26ed <trace_filp_close+0x26ed> */
	X86_SIM_X86_JMP(0x26e8, 0x26ed, x86_l_26ed);
x86_l_26ea:
	/* 0x26ea: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26ed:
	/* 0x26ed: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26f0:
	/* 0x26f0: jns    26f7 <trace_filp_close+0x26f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f0, 0x26f7, x86_l_26f7);
x86_l_26f2:
	/* 0x26f2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f5:
	/* 0x26f5: jmp    26f9 <trace_filp_close+0x26f9> */
	X86_SIM_X86_JMP(0x26f5, 0x26f9, x86_l_26f9);
x86_l_26f7:
	/* 0x26f7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26f9:
	/* 0x26f9: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26fc:
	/* 0x26fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26ff:
	/* 0x26ff: jns    2706 <trace_filp_close+0x2706> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26ff, 0x2706, x86_l_2706);
x86_l_2701:
	/* 0x2701: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2704:
	/* 0x2704: jmp    2708 <trace_filp_close+0x2708> */
	X86_SIM_X86_JMP(0x2704, 0x2708, x86_l_2708);
x86_l_2706:
	/* 0x2706: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2708:
	/* 0x2708: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_270c:
	/* 0x270c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_270f:
	/* 0x270f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2712:
	/* 0x2712: jns    2741 <trace_filp_close+0x2741> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2712, 0x2741, x86_l_2741);
x86_l_2714:
	/* 0x2714: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2717:
	/* 0x2717: jmp    2743 <trace_filp_close+0x2743> */
	X86_SIM_X86_JMP(0x2717, 0x2743, x86_l_2743);
x86_l_2719:
	/* 0x2719: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_271e:
	/* 0x271e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2722:
	/* 0x2722: jl     2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2722, 0x2852, x86_l_2852);
x86_l_2728:
	/* 0x2728: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_272c:
	/* 0x272c: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2731:
	/* 0x2731: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2736:
	/* 0x2736: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2739:
	/* 0x2739: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_273c:
	/* 0x273c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_273f:
	/* 0x273f: js     2714 <trace_filp_close+0x2714> */
	X86_SIM_X86_JCC(X86_CC_S, 0x273f, 0x2714, x86_l_2714);
x86_l_2741:
	/* 0x2741: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2743:
	/* 0x2743: lea    rax,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2747:
	/* 0x2747: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_274a:
	/* 0x274a: jns    2751 <trace_filp_close+0x2751> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x274a, 0x2751, x86_l_2751);
x86_l_274c:
	/* 0x274c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274f:
	/* 0x274f: jmp    2753 <trace_filp_close+0x2753> */
	X86_SIM_X86_JMP(0x274f, 0x2753, x86_l_2753);
x86_l_2751:
	/* 0x2751: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2753:
	/* 0x2753: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2756:
	/* 0x2756: je     27da <trace_filp_close+0x27da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2756, 0x27da, x86_l_27da);
x86_l_275c:
	/* 0x275c: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_275f:
	/* 0x275f: je     27da <trace_filp_close+0x27da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275f, 0x27da, x86_l_27da);
x86_l_2761:
	/* 0x2761: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2765:
	/* 0x2765: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2768:
	/* 0x2768: mov    esi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_276d:
	/* 0x276d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2770:
	/* 0x2770: jns    2779 <trace_filp_close+0x2779> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2770, 0x2779, x86_l_2779);
x86_l_2772:
	/* 0x2772: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2775:
	/* 0x2775: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2779:
	/* 0x2779: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_277d:
	/* 0x277d: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2780:
	/* 0x2780: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2787:
	/* 0x2787: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_278a:
	/* 0x278a: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_278d:
	/* 0x278d: jb     28a5 <trace_filp_close+0x28a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x278d, 0x28a5, x86_l_28a5);
x86_l_2793:
	/* 0x2793: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2796:
	/* 0x2796: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2796, 0x284f, x86_l_284f);
x86_l_279c:
	/* 0x279c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27a2:
	/* 0x27a2: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27a5:
	/* 0x27a5: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27a8:
	/* 0x27a8: jns    27d0 <trace_filp_close+0x27d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a8, 0x27d0, x86_l_27d0);
x86_l_27aa:
	/* 0x27aa: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27ae:
	/* 0x27ae: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b1:
	/* 0x27b1: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_27b4:
	/* 0x27b4: je     281d <trace_filp_close+0x281d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b4, 0x281d, x86_l_281d);
x86_l_27b6:
	/* 0x27b6: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_27ba:
	/* 0x27ba: movzx  ebp,BYTE PTR [rsi+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_27bf:
	/* 0x27bf: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_27c3:
	/* 0x27c3: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_27c6:
	/* 0x27c6: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_27c9:
	/* 0x27c9: jne    27b1 <trace_filp_close+0x27b1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27c9, 0x27b1, x86_l_27b1);
x86_l_27cb:
	/* 0x27cb: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_27ce:
	/* 0x27ce: jmp    2822 <trace_filp_close+0x2822> */
	X86_SIM_X86_JMP(0x27ce, 0x2822, x86_l_2822);
x86_l_27d0:
	/* 0x27d0: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d5:
	/* 0x27d5: jmp    1687 <trace_filp_close+0x1687> */
	X86_SIM_X86_JMP(0x27d5, 0x1687, x86_l_1687);
x86_l_27da:
	/* 0x27da: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27dd:
	/* 0x27dd: jne    284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27dd, 0x284f, x86_l_284f);
x86_l_27df:
	/* 0x27df: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27e2:
	/* 0x27e2: je     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e2, 0x284f, x86_l_284f);
x86_l_27e4:
	/* 0x27e4: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27e8:
	/* 0x27e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27eb:
	/* 0x27eb: jns    27f2 <trace_filp_close+0x27f2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27eb, 0x27f2, x86_l_27f2);
x86_l_27ed:
	/* 0x27ed: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27f0:
	/* 0x27f0: jmp    27f4 <trace_filp_close+0x27f4> */
	X86_SIM_X86_JMP(0x27f0, 0x27f4, x86_l_27f4);
x86_l_27f2:
	/* 0x27f2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27f4:
	/* 0x27f4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27f7:
	/* 0x27f7: jns    27fe <trace_filp_close+0x27fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27f7, 0x27fe, x86_l_27fe);
x86_l_27f9:
	/* 0x27f9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27fc:
	/* 0x27fc: jmp    2800 <trace_filp_close+0x2800> */
	X86_SIM_X86_JMP(0x27fc, 0x2800, x86_l_2800);
x86_l_27fe:
	/* 0x27fe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2800:
	/* 0x2800: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2803:
	/* 0x2803: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2806:
	/* 0x2806: jns    280d <trace_filp_close+0x280d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2806, 0x280d, x86_l_280d);
x86_l_2808:
	/* 0x2808: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_280b:
	/* 0x280b: jmp    280f <trace_filp_close+0x280f> */
	X86_SIM_X86_JMP(0x280b, 0x280f, x86_l_280f);
x86_l_280d:
	/* 0x280d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_280f:
	/* 0x280f: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2813:
	/* 0x2813: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2816:
	/* 0x2816: jns    283f <trace_filp_close+0x283f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2816, 0x283f, x86_l_283f);
x86_l_2818:
	/* 0x2818: mov    rdi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_281b:
	/* 0x281b: jmp    2841 <trace_filp_close+0x2841> */
	X86_SIM_X86_JMP(0x281b, 0x2841, x86_l_2841);
x86_l_281d:
	/* 0x281d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2822:
	/* 0x2822: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2826:
	/* 0x2826: jl     284f <trace_filp_close+0x284f> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2826, 0x284f, x86_l_284f);
x86_l_2828:
	/* 0x2828: lea    esi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_282c:
	/* 0x282c: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2832:
	/* 0x2832: mov    BYTE PTR [r12+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_2837:
	/* 0x2837: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_283a:
	/* 0x283a: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_283d:
	/* 0x283d: js     2818 <trace_filp_close+0x2818> */
	X86_SIM_X86_JCC(X86_CC_S, 0x283d, 0x2818, x86_l_2818);
x86_l_283f:
	/* 0x283f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2841:
	/* 0x2841: lea    rsi,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2845:
	/* 0x2845: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2848:
	/* 0x2848: jns    285f <trace_filp_close+0x285f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2848, 0x285f, x86_l_285f);
x86_l_284a:
	/* 0x284a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284d:
	/* 0x284d: jmp    2861 <trace_filp_close+0x2861> */
	X86_SIM_X86_JMP(0x284d, 0x2861, x86_l_2861);
x86_l_284f:
	/* 0x284f: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2852:
	/* 0x2852: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2855:
	/* 0x2855: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_285a:
	/* 0x285a: jmp    1697 <trace_filp_close+0x1697> */
	X86_SIM_X86_JMP(0x285a, 0x1697, x86_l_1697);
x86_l_285f:
	/* 0x285f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2861:
	/* 0x2861: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2864:
	/* 0x2864: je     29bb <trace_filp_close+0x29bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2864, 0x29bb, x86_l_29bb);
x86_l_286a:
	/* 0x286a: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_286d:
	/* 0x286d: je     29bb <trace_filp_close+0x29bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x286d, 0x29bb, x86_l_29bb);
x86_l_2873:
	/* 0x2873: lea    rdx,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2877:
	/* 0x2877: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_287a:
	/* 0x287a: mov    ecx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_287f:
	/* 0x287f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2882:
	/* 0x2882: jns    288b <trace_filp_close+0x288b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2882, 0x288b, x86_l_288b);
x86_l_2884:
	/* 0x2884: mov    r9,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2887:
	/* 0x2887: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_288b:
	/* 0x288b: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_288f:
	/* 0x288f: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2892:
	/* 0x2892: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2899:
	/* 0x2899: mov    edx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_289c:
	/* 0x289c: sub    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_289f:
	/* 0x289f: jae    29db <trace_filp_close+0x29db> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x289f, 0x29db, x86_l_29db);
x86_l_28a5:
	/* 0x28a5: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_28a8:
	/* 0x28a8: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28ad:
	/* 0x28ad: dec    r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_28b0:
	/* 0x28b0: and    r15d,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_28b7:
	/* 0x28b7: mov    BYTE PTR [rax+r15*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 47ULL);
x86_l_28bc:
	/* 0x28bc: mov    BYTE PTR [rax+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_28c3:
	/* 0x28c3: add    r14,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_28c7:
	/* 0x28c7: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_28ca:
	/* 0x28ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28cd:
	/* 0x28cd: jns    28d4 <trace_filp_close+0x28d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28cd, 0x28d4, x86_l_28d4);
x86_l_28cf:
	/* 0x28cf: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d2:
	/* 0x28d2: jmp    28d6 <trace_filp_close+0x28d6> */
	X86_SIM_X86_JMP(0x28d2, 0x28d6, x86_l_28d6);
x86_l_28d4:
	/* 0x28d4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d6:
	/* 0x28d6: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_28df:
	/* 0x28df: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_28e8:
	/* 0x28e8: lea    rcx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28ec:
	/* 0x28ec: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28ef:
	/* 0x28ef: jns    28f6 <trace_filp_close+0x28f6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ef, 0x28f6, x86_l_28f6);
x86_l_28f1:
	/* 0x28f1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28f4:
	/* 0x28f4: jmp    28f8 <trace_filp_close+0x28f8> */
	X86_SIM_X86_JMP(0x28f4, 0x28f8, x86_l_28f8);
x86_l_28f6:
	/* 0x28f6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28f8:
	/* 0x28f8: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28fd:
	/* 0x28fd: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2901:
	/* 0x2901: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2904:
	/* 0x2904: jns    290c <trace_filp_close+0x290c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2904, 0x290c, x86_l_290c);
x86_l_2906:
	/* 0x2906: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2908:
	/* 0x2908: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_290a:
	/* 0x290a: jmp    290e <trace_filp_close+0x290e> */
	X86_SIM_X86_JMP(0x290a, 0x290e, x86_l_290e);
x86_l_290c:
	/* 0x290c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_290e:
	/* 0x290e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2913:
	/* 0x2913: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2918:
	/* 0x2918: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_291b:
	/* 0x291b: jns    2925 <trace_filp_close+0x2925> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x291b, 0x2925, x86_l_2925);
x86_l_291d:
	/* 0x291d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2920:
	/* 0x2920: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2923:
	/* 0x2923: js     2932 <trace_filp_close+0x2932> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2923, 0x2932, x86_l_2932);
x86_l_2925:
	/* 0x2925: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_292a:
	/* 0x292a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_292d:
	/* 0x292d: jns    2932 <trace_filp_close+0x2932> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x292d, 0x2932, x86_l_2932);
x86_l_292f:
	/* 0x292f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2932:
	/* 0x2932: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2935:
	/* 0x2935: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2938:
	/* 0x2938: jns    293f <trace_filp_close+0x293f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2938, 0x293f, x86_l_293f);
x86_l_293a:
	/* 0x293a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_293d:
	/* 0x293d: jmp    2941 <trace_filp_close+0x2941> */
	X86_SIM_X86_JMP(0x293d, 0x2941, x86_l_2941);
x86_l_293f:
	/* 0x293f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2941:
	/* 0x2941: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2945:
	/* 0x2945: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2947:
	/* 0x2947: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_294a:
	/* 0x294a: jns    2956 <trace_filp_close+0x2956> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x294a, 0x2956, x86_l_2956);
x86_l_294c:
	/* 0x294c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_294f:
	/* 0x294f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2952:
	/* 0x2952: js     295d <trace_filp_close+0x295d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2952, 0x295d, x86_l_295d);
x86_l_2954:
	/* 0x2954: jmp    295f <trace_filp_close+0x295f> */
	X86_SIM_X86_JMP(0x2954, 0x295f, x86_l_295f);
x86_l_2956:
	/* 0x2956: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2958:
	/* 0x2958: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_295b:
	/* 0x295b: jns    295f <trace_filp_close+0x295f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x295b, 0x295f, x86_l_295f);
x86_l_295d:
	/* 0x295d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_295f:
	/* 0x295f: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2962:
	/* 0x2962: jns    2974 <trace_filp_close+0x2974> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2962, 0x2974, x86_l_2974);
x86_l_2964:
	/* 0x2964: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2967:
	/* 0x2967: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_296b:
	/* 0x296b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_296e:
	/* 0x296e: js     297f <trace_filp_close+0x297f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x296e, 0x297f, x86_l_297f);
x86_l_2970:
	/* 0x2970: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2972:
	/* 0x2972: jmp    2982 <trace_filp_close+0x2982> */
	X86_SIM_X86_JMP(0x2972, 0x2982, x86_l_2982);
x86_l_2974:
	/* 0x2974: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2976:
	/* 0x2976: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_297a:
	/* 0x297a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_297d:
	/* 0x297d: jns    2970 <trace_filp_close+0x2970> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x297d, 0x2970, x86_l_2970);
x86_l_297f:
	/* 0x297f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2982:
	/* 0x2982: mov    edx,DWORD PTR [rbx+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2985:
	/* 0x2985: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2989:
	/* 0x2989: mov    DWORD PTR [rsp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_298d:
	/* 0x298d: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2992:
	/* 0x2992: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)file_modification_map));
x86_l_2999:
	/* 0x2999: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_299e:
	/* 0x299e: call   29a3 <trace_filp_close+0x29a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_29a3:
	/* 0x29a3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29a5:
	/* 0x29a5: add    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_29ac:
	/* 0x29ac: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29ad:
	/* 0x29ad: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29af:
	/* 0x29af: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29b1:
	/* 0x29b1: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29b3:
	/* 0x29b3: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29b5:
	/* 0x29b5: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29b6:
	/* 0x29b6: jmp    2a73 <trace_filp_close+0x2a73> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_29bb:
	/* 0x29bb: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29be:
	/* 0x29be: jne    2a6b <trace_filp_close+0x2a6b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29be, 0x2a6b, x86_l_2a6b);
x86_l_29c4:
	/* 0x29c4: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29c7:
	/* 0x29c7: je     2a6b <trace_filp_close+0x2a6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29c7, 0x2a6b, x86_l_2a6b);
x86_l_29cd:
	/* 0x29cd: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29d1:
	/* 0x29d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29d4:
	/* 0x29d4: jns    2a1b <trace_filp_close+0x2a1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d4, 0x2a1b, x86_l_2a1b);
x86_l_29d6:
	/* 0x29d6: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29d9:
	/* 0x29d9: jmp    2a1d <trace_filp_close+0x2a1d> */
	X86_SIM_X86_JMP(0x29d9, 0x2a1d, x86_l_2a1d);
x86_l_29db:
	/* 0x29db: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_29de:
	/* 0x29de: je     2a6b <trace_filp_close+0x2a6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29de, 0x2a6b, x86_l_2a6b);
x86_l_29e4:
	/* 0x29e4: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_29ea:
	/* 0x29ea: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_29ed:
	/* 0x29ed: add    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_29f0:
	/* 0x29f0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29f3:
	/* 0x29f3: jns    2a3a <trace_filp_close+0x2a3a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f3, 0x2a3a, x86_l_2a3a);
x86_l_29f5:
	/* 0x29f5: lea    edx,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29f9:
	/* 0x29f9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29fc:
	/* 0x29fc: cmp    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_29ff:
	/* 0x29ff: je     2a47 <trace_filp_close+0x2a47> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29ff, 0x2a47, x86_l_2a47);
x86_l_2a01:
	/* 0x2a01: lea    r10,[r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a05:
	/* 0x2a05: movzx  r11d,BYTE PTR [rcx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_2a0a:
	/* 0x2a0a: mov    BYTE PTR [rdi+r8*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_2a0e:
	/* 0x2a0e: mov    r8,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_2a11:
	/* 0x2a11: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_2a14:
	/* 0x2a14: jne    29fc <trace_filp_close+0x29fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a14, 0x29fc, x86_l_29fc);
x86_l_2a16:
	/* 0x2a16: mov    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_2a19:
	/* 0x2a19: jmp    2a4b <trace_filp_close+0x2a4b> */
	X86_SIM_X86_JMP(0x2a19, 0x2a4b, x86_l_2a4b);
x86_l_2a1b:
	/* 0x2a1b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a1d:
	/* 0x2a1d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a20:
	/* 0x2a20: jns    2a27 <trace_filp_close+0x2a27> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a20, 0x2a27, x86_l_2a27);
x86_l_2a22:
	/* 0x2a22: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a25:
	/* 0x2a25: jmp    2a29 <trace_filp_close+0x2a29> */
	X86_SIM_X86_JMP(0x2a25, 0x2a29, x86_l_2a29);
x86_l_2a27:
	/* 0x2a27: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a29:
	/* 0x2a29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a2c:
	/* 0x2a2c: jns    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a2c, 0x2852, x86_l_2852);
x86_l_2a32:
	/* 0x2a32: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a35:
	/* 0x2a35: jmp    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JMP(0x2a35, 0x2852, x86_l_2852);
x86_l_2a3a:
	/* 0x2a3a: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a3d:
	/* 0x2a3d: mov    rbx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a42:
	/* 0x2a42: jmp    1687 <trace_filp_close+0x1687> */
	X86_SIM_X86_JMP(0x2a42, 0x1687, x86_l_1687);
x86_l_2a47:
	/* 0x2a47: mov    BYTE PTR [rdi+rdx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_2a4b:
	/* 0x2a4b: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2a4f:
	/* 0x2a4f: jl     2a6b <trace_filp_close+0x2a6b> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2a4f, 0x2a6b, x86_l_2a6b);
x86_l_2a51:
	/* 0x2a51: lea    ecx,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a55:
	/* 0x2a55: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2a5b:
	/* 0x2a5b: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a5e:
	/* 0x2a5e: mov    BYTE PTR [r12+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2a63:
	/* 0x2a63: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a66:
	/* 0x2a66: jmp    2855 <trace_filp_close+0x2855> */
	X86_SIM_X86_JMP(0x2a66, 0x2855, x86_l_2855);
x86_l_2a6b:
	/* 0x2a6b: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a6e:
	/* 0x2a6e: jmp    2852 <trace_filp_close+0x2852> */
	X86_SIM_X86_JMP(0x2a6e, 0x2852, x86_l_2852);
x86_l_2a73:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
