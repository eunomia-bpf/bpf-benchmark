#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 168U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20)
#include "../x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 data_heap[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC_MEM, X86_OP_SETCC_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC(".text")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_d:
	/* 0xd: mov    r14,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_13:
	/* 0x13: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16:
	/* 0x16: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_1e:
	/* 0x1e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)data_heap));
x86_l_25:
	/* 0x25: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2a:
	/* 0x2a: call   2f <data_event_str+0x2f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f:
	/* 0x2f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32:
	/* 0x32: je     a5 <data_event_str+0xa5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32, 0xa5, x86_l_a5);
x86_l_34:
	/* 0x34: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37:
	/* 0x37: mov    DWORD PTR [rax],0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d:
	/* 0x3d: call   42 <data_event_str+0x42> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_42:
	/* 0x42: mov    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_45:
	/* 0x45: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_49:
	/* 0x49: mov    QWORD PTR [r12+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4e:
	/* 0x4e: cmp    rax,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_52:
	/* 0x52: jne    5c <data_event_str+0x5c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x52, 0x5c, x86_l_5c);
x86_l_54:
	/* 0x54: mov    rax,QWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_58:
	/* 0x58: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c:
	/* 0x5c: call   61 <data_event_str+0x61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_61:
	/* 0x61: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_66:
	/* 0x66: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6a:
	/* 0x6a: mov    rcx,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e:
	/* 0x6e: mov    QWORD PTR [rbx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_76:
	/* 0x76: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_79:
	/* 0x79: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_7c:
	/* 0x7c: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_7f:
	/* 0x7f: call   b9 <do_str> */
	X86_SIM_X86_CALL(x86_l_b9, 0x84ULL);
x86_l_84:
	/* 0x84: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_86:
	/* 0x86: sar    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 31ULL);
x86_l_89:
	/* 0x89: and    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_AND, 0);
x86_l_8b:
	/* 0x8b: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_8d:
	/* 0x8d: jg     91 <data_event_str+0x91> */
	X86_SIM_X86_JCC(X86_CC_G, 0x8d, 0x91, x86_l_91);
x86_l_8f:
	/* 0x8f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_91:
	/* 0x91: mov    DWORD PTR [rbx],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbx+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_9b:
	/* 0x9b: mov    DWORD PTR [rbx+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9e:
	/* 0x9e: mov    eax,0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_a3:
	/* 0xa3: jmp    a7 <data_event_str+0xa7> */
	X86_SIM_X86_JMP(0xa3, 0xa7, x86_l_a7);
x86_l_a5:
	/* 0xa5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a7:
	/* 0xa7: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_ab:
	/* 0xab: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ac:
	/* 0xac: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ae:
	/* 0xae: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b0:
	/* 0xb0: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b2:
	/* 0xb2: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b4:
	/* 0xb4: jmp    311 <__do_str+0x1f5> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_311:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_b9 */
x86_l_b9:
	/* 0xb9: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bb:
	/* 0xbb: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_bd:
	/* 0xbd: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_bf:
	/* 0xbf: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c0:
	/* 0xc0: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c1:
	/* 0xc1: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c4:
	/* 0xc4: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c7:
	/* 0xc7: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ca:
	/* 0xca: mov    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_cf:
	/* 0xcf: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_d4:
	/* 0xd4: call   11c <__do_str> */
	X86_SIM_X86_CALL(x86_l_11c, 0xd9ULL);
x86_l_d9:
	/* 0xd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dc:
	/* 0xdc: js     110 <do_str+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0xdc, 0x110, x86_l_110);
x86_l_de:
	/* 0xde: cmp    BYTE PTR [rsp+0x7],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 30064771072ULL);
x86_l_e3:
	/* 0xe3: jne    110 <do_str+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xe3, 0x110, x86_l_110);
x86_l_e5:
	/* 0xe5: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_eb:
	/* 0xeb: add    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_ee:
	/* 0xee: lea    rcx,[rsp+0x7] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_f3:
	/* 0xf3: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f6:
	/* 0xf6: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f9:
	/* 0xf9: call   11c <__do_str> */
	X86_SIM_X86_CALL(x86_l_11c, 0xfeULL);
x86_l_fe:
	/* 0xfe: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_101:
	/* 0x101: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_104:
	/* 0x104: js     10b <do_str+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x104, 0x10b, x86_l_10b);
x86_l_106:
	/* 0x106: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_109:
	/* 0x109: jmp    10d <do_str+0x54> */
	X86_SIM_X86_SUB_JMP(0x109, 0x10d, x86_l_10d);
x86_l_10b:
	/* 0x10b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10d:
	/* 0x10d: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_110:
	/* 0x110: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_114:
	/* 0x114: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_115:
	/* 0x115: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_117:
	/* 0x117: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_119:
	/* 0x119: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_11b:
	/* 0x11b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_11b);

	/* native subroutine native_link_sub_11c */
x86_l_11c:
	/* 0x11c: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11e:
	/* 0x11e: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_120:
	/* 0x120: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_122:
	/* 0x122: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_123:
	/* 0x123: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_127:
	/* 0x127: mov    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_12d:
	/* 0x12d: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_130:
	/* 0x130: lea    rdi,[rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_134:
	/* 0x134: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_137:
	/* 0x137: js     162 <__do_str+0x46> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x137, 0x162, x86_l_162);
x86_l_139:
	/* 0x139: mov    esi,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_13e:
	/* 0x13e: call   270 <__do_str+0x154> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_143:
	/* 0x143: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_146:
	/* 0x146: js     305 <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JCC(X86_CC_S, 0x146, 0x305, x86_l_305);
x86_l_14c:
	/* 0x14c: cmp    rax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_152:
	/* 0x152: setne  BYTE PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_SETCC_MEM, X86_R15, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 0ULL);
x86_l_156:
	/* 0x156: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_159:
	/* 0x159: jne    1b0 <__do_str+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x159, 0x1b0, x86_l_1b0);
x86_l_15b:
	/* 0x15b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15d:
	/* 0x15d: jmp    305 <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JMP(0x15d, 0x305, x86_l_305);
x86_l_162:
	/* 0x162: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_165:
	/* 0x165: jns    188 <__do_str+0x6c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x165, 0x188, x86_l_188);
x86_l_167:
	/* 0x167: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_169:
	/* 0x169: cmp    rcx,0x7fde */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32734ULL);
x86_l_170:
	/* 0x170: je     1a0 <__do_str+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x170, 0x1a0, x86_l_1a0);
x86_l_172:
	/* 0x172: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_176:
	/* 0x176: movzx  esi,BYTE PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_17a:
	/* 0x17a: mov    BYTE PTR [rdi+rcx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_17e:
	/* 0x17e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_181:
	/* 0x181: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_184:
	/* 0x184: jne    169 <__do_str+0x4d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x184, 0x169, x86_l_169);
x86_l_186:
	/* 0x186: jmp    14c <__do_str+0x30> */
	X86_SIM_X86_SUB_JMP(0x186, 0x14c, x86_l_14c);
x86_l_188:
	/* 0x188: mov    edx,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_18d:
	/* 0x18d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18f:
	/* 0x18f: call   2c7 <__do_str+0x1ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 32735ULL);
x86_l_194:
	/* 0x194: mov    rax,0xffffffffffffffde */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551582ULL);
x86_l_19b:
	/* 0x19b: jmp    305 <__do_str+0x1e9> */
	X86_SIM_X86_SUB_JMP(0x19b, 0x305, x86_l_305);
x86_l_1a0:
	/* 0x1a0: mov    BYTE PTR [rbx+0x7ffe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 140728898420736ULL);
x86_l_1a7:
	/* 0x1a7: mov    BYTE PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ab:
	/* 0x1ab: mov    eax,0x7fdf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32735ULL);
x86_l_1b0:
	/* 0x1b0: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: lea    r15d,[rax+0x1f] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
x86_l_1b7:
	/* 0x1b7: and    r15d,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1be:
	/* 0x1be: mov    DWORD PTR [rbx+0x4],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c2:
	/* 0x1c2: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_1ca:
	/* 0x1ca: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_1d1:
	/* 0x1d1: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d6:
	/* 0x1d6: call   30e <__do_str+0x1f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1db:
	/* 0x1db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1de:
	/* 0x1de: je     253 <__do_str+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1de, 0x253, x86_l_253);
x86_l_1e0:
	/* 0x1e0: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1e4:
	/* 0x1e4: je     253 <__do_str+0x137> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e4, 0x253, x86_l_253);
x86_l_1e6:
	/* 0x1e6: mov    rsi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_1ed:
	/* 0x1ed: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1f2:
	/* 0x1f2: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f5:
	/* 0x1f5: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f8:
	/* 0x1f8: mov    r8,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1fb:
	/* 0x1fb: call   333 <__do_str+0x217> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_200:
	/* 0x200: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_203:
	/* 0x203: jns    2ff <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x203, 0x2ff, x86_l_2ff);
x86_l_209:
	/* 0x209: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20c:
	/* 0x20c: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_214:
	/* 0x214: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_21b:
	/* 0x21b: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_220:
	/* 0x220: call   358 <__do_str+0x23c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_225:
	/* 0x225: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: je     2ff <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x228, 0x2ff, x86_l_2ff);
x86_l_22e:
	/* 0x22e: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_232:
	/* 0x232: jg     2cb <__do_str+0x1af> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x232, 0x2cb, x86_l_2cb);
x86_l_238:
	/* 0x238: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_23c:
	/* 0x23c: je     2e5 <__do_str+0x1c9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23c, 0x2e5, x86_l_2e5);
x86_l_242:
	/* 0x242: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_246:
	/* 0x246: jne    2a3 <__do_str+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x246, 0x2a3, x86_l_2a3);
x86_l_248:
	/* 0x248: add    rax,0x560 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1376ULL);
x86_l_24e:
	/* 0x24e: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x24e, 0x2fb, x86_l_2fb);
x86_l_253:
	/* 0x253: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_25a:
	/* 0x25a: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_25d:
	/* 0x25d: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_260:
	/* 0x260: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_262:
	/* 0x262: call   39a <__do_str+0x27e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_267:
	/* 0x267: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a:
	/* 0x26a: jns    2ff <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x26a, 0x2ff, x86_l_2ff);
x86_l_270:
	/* 0x270: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_27b:
	/* 0x27b: mov    rdi,QWORD PTR [rip+0x133] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_282:
	/* 0x282: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_287:
	/* 0x287: call   3bf <__do_str+0x2a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_28c:
	/* 0x28c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28f:
	/* 0x28f: je     2ff <__do_str+0x1e3> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x28f, 0x2ff, x86_l_2ff);
x86_l_291:
	/* 0x291: cmp    rbx,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_295:
	/* 0x295: jg     2b1 <__do_str+0x195> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x295, 0x2b1, x86_l_2b1);
x86_l_297:
	/* 0x297: cmp    rbx,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_29b:
	/* 0x29b: je     2e5 <__do_str+0x1c9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x29b, 0x2e5, x86_l_2e5);
x86_l_29d:
	/* 0x29d: cmp    rbx,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2a1:
	/* 0x2a1: je     248 <__do_str+0x12c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2a1, 0x248, x86_l_248);
x86_l_2a3:
	/* 0x2a3: cmp    rbx,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2a7:
	/* 0x2a7: jne    2dd <__do_str+0x1c1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2a7, 0x2dd, x86_l_2dd);
x86_l_2a9:
	/* 0x2a9: add    rax,0x558 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1368ULL);
x86_l_2af:
	/* 0x2af: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2af, 0x2fb, x86_l_2fb);
x86_l_2b1:
	/* 0x2b1: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2b5:
	/* 0x2b5: je     2ed <__do_str+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2b5, 0x2ed, x86_l_2ed);
x86_l_2b7:
	/* 0x2b7: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2bb:
	/* 0x2bb: je     2f5 <__do_str+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2bb, 0x2f5, x86_l_2f5);
x86_l_2bd:
	/* 0x2bd: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2c1:
	/* 0x2c1: jne    2dd <__do_str+0x1c1> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2c1, 0x2dd, x86_l_2dd);
x86_l_2c3:
	/* 0x2c3: add    rax,0x548 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1352ULL);
x86_l_2c9:
	/* 0x2c9: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2c9, 0x2fb, x86_l_2fb);
x86_l_2cb:
	/* 0x2cb: cmp    rbx,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2cf:
	/* 0x2cf: je     2ed <__do_str+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2cf, 0x2ed, x86_l_2ed);
x86_l_2d1:
	/* 0x2d1: cmp    rbx,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2d5:
	/* 0x2d5: je     2f5 <__do_str+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2d5, 0x2f5, x86_l_2f5);
x86_l_2d7:
	/* 0x2d7: cmp    rbx,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_2db:
	/* 0x2db: je     2c3 <__do_str+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2db, 0x2c3, x86_l_2c3);
x86_l_2dd:
	/* 0x2dd: add    rax,0x540 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1344ULL);
x86_l_2e3:
	/* 0x2e3: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2e3, 0x2fb, x86_l_2fb);
x86_l_2e5:
	/* 0x2e5: add    rax,0x568 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1384ULL);
x86_l_2eb:
	/* 0x2eb: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2eb, 0x2fb, x86_l_2fb);
x86_l_2ed:
	/* 0x2ed: add    rax,0x570 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1392ULL);
x86_l_2f3:
	/* 0x2f3: jmp    2fb <__do_str+0x1df> */
	X86_SIM_X86_SUB_JMP(0x2f3, 0x2fb, x86_l_2fb);
x86_l_2f5:
	/* 0x2f5: add    rax,0x550 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1360ULL);
x86_l_2fb:
	/* 0x2fb: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2ff:
	/* 0x2ff: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_302:
	/* 0x302: dec    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_305:
	/* 0x305: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_309:
	/* 0x309: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30c:
	/* 0x30c: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_30e:
	/* 0x30e: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_310:
	/* 0x310: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_310);

x86_sim_ret_dispatch_11b:
	switch (__x86_sim_ret_addr) {
	case 0x84ULL: goto x86_l_84;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_310:
	switch (__x86_sim_ret_addr) {
	case 0xd9ULL: goto x86_l_d9;
	case 0xfeULL: goto x86_l_fe;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
