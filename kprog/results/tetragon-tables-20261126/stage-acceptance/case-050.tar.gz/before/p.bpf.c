#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 40U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 cilium_cidr_v4_dyn[] __ksym;
extern __u8 cilium_cidr_v4_fix[] __ksym;
extern __u8 cilium_percpu_trace_id[] __ksym;
extern __u8 cilium_xdp_scratch[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_LOAD, X86_OP_MOVBE_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("xdp/entry")
int p_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_8:
	/* 0x8: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_b:
	/* 0xb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_tracing_ip_option_type));
x86_l_12:
	/* 0x12: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15:
	/* 0x15: je     53 <cil_xdp_entry+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15, 0x53, x86_l_53);
x86_l_17:
	/* 0x17: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1a:
	/* 0x1a: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d:
	/* 0x1d: mov    rcx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21:
	/* 0x21: lea    rdi,[rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_25:
	/* 0x25: cmp    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28:
	/* 0x28: jbe    12d <cil_xdp_entry+0x12d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x28, 0x12d, x86_l_12d);
x86_l_2e:
	/* 0x2e: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_36:
	/* 0x36: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_3d:
	/* 0x3d: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_42:
	/* 0x42: call   47 <cil_xdp_entry+0x47> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_47:
	/* 0x47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a:
	/* 0x4a: je     53 <cil_xdp_entry+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a, 0x53, x86_l_53);
x86_l_4c:
	/* 0x4c: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53:
	/* 0x53: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_56:
	/* 0x56: lea    rdx,[rcx+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_5a:
	/* 0x5a: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_5f:
	/* 0x5f: cmp    rdx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_63:
	/* 0x63: ja     1bd <cil_xdp_entry+0x1bd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x63, 0x1bd, x86_l_1bd);
x86_l_69:
	/* 0x69: movzx  ebp,WORD PTR [rcx+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 12ULL);
x86_l_6d:
	/* 0x6d: cmp    bp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, 0, 6ULL);
x86_l_71:
	/* 0x71: jb     1bd <cil_xdp_entry+0x1bd> */
	X86_SIM_X86_JCC(X86_CC_B, 0x71, 0x1bd, x86_l_1bd);
x86_l_77:
	/* 0x77: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_7f:
	/* 0x7f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_86:
	/* 0x86: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8b:
	/* 0x8b: call   90 <cil_xdp_entry+0x90> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_90:
	/* 0x90: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_93:
	/* 0x93: je     9c <cil_xdp_entry+0x9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93, 0x9c, x86_l_9c);
x86_l_95:
	/* 0x95: mov    DWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_9c:
	/* 0x9c: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a4:
	/* 0xa4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_ab:
	/* 0xab: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b0:
	/* 0xb0: call   b5 <cil_xdp_entry+0xb5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b5:
	/* 0xb5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8:
	/* 0xb8: je     c1 <cil_xdp_entry+0xc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8, 0xc1, x86_l_c1);
x86_l_ba:
	/* 0xba: mov    DWORD PTR [rax+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_c1:
	/* 0xc1: cmp    bp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, 0, 8ULL);
x86_l_c5:
	/* 0xc5: jne    17e <cil_xdp_entry+0x17e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc5, 0x17e, x86_l_17e);
x86_l_cb:
	/* 0xcb: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&__config_enable_xdp_prefilter));
x86_l_d2:
	/* 0xd2: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d5:
	/* 0xd5: je     17e <cil_xdp_entry+0x17e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd5, 0x17e, x86_l_17e);
x86_l_db:
	/* 0xdb: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de:
	/* 0xde: lea    rcx,[rax+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_e2:
	/* 0xe2: cmp    rcx,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_e6:
	/* 0xe6: ja     123 <cil_xdp_entry+0x123> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe6, 0x123, x86_l_123);
x86_l_e8:
	/* 0xe8: mov    eax,DWORD PTR [rax+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_eb:
	/* 0xeb: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_ef:
	/* 0xef: mov    DWORD PTR [rsp+0x8],0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738400ULL);
x86_l_f7:
	/* 0xf7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_cidr_v4_dyn));
x86_l_fe:
	/* 0xfe: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_103:
	/* 0x103: call   108 <cil_xdp_entry+0x108> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_108:
	/* 0x108: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10b:
	/* 0x10b: jne    123 <cil_xdp_entry+0x123> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10b, 0x123, x86_l_123);
x86_l_10d:
	/* 0x10d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_cidr_v4_fix));
x86_l_114:
	/* 0x114: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_119:
	/* 0x119: call   11e <cil_xdp_entry+0x11e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11e:
	/* 0x11e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_121:
	/* 0x121: je     17e <cil_xdp_entry+0x17e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x121, 0x17e, x86_l_17e);
x86_l_123:
	/* 0x123: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_128:
	/* 0x128: jmp    1bd <cil_xdp_entry+0x1bd> */
	X86_SIM_X86_JMP(0x128, 0x1bd, x86_l_1bd);
x86_l_12d:
	/* 0x12d: cmp    WORD PTR [rax+0xc],0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 51539607560ULL);
x86_l_132:
	/* 0x132: jne    2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x132, 0x2e, x86_l_2e);
x86_l_138:
	/* 0x138: lea    rsi,[rax+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34ULL);
x86_l_13c:
	/* 0x13c: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13f:
	/* 0x13f: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x13f, 0x2e, x86_l_2e);
x86_l_145:
	/* 0x145: movzx  edi,BYTE PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_148:
	/* 0x148: and    edi,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_14b:
	/* 0x14b: cmp    dil,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, 0, 6ULL);
x86_l_14f:
	/* 0x14f: jae    1ca <cil_xdp_entry+0x1ca> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x14f, 0x1ca, x86_l_1ca);
x86_l_151:
	/* 0x151: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_154:
	/* 0x154: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_15c:
	/* 0x15c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_percpu_trace_id));
x86_l_163:
	/* 0x163: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_168:
	/* 0x168: call   16d <cil_xdp_entry+0x16d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16d:
	/* 0x16d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_170:
	/* 0x170: je     53 <cil_xdp_entry+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x170, 0x53, x86_l_53);
x86_l_176:
	/* 0x176: mov    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: jmp    53 <cil_xdp_entry+0x53> */
	X86_SIM_X86_JMP(0x179, 0x53, x86_l_53);
x86_l_17e:
	/* 0x17e: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_186:
	/* 0x186: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cilium_xdp_scratch));
x86_l_18d:
	/* 0x18d: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_192:
	/* 0x192: call   197 <cil_xdp_entry+0x197> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: je     1b8 <cil_xdp_entry+0x1b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a, 0x1b8, x86_l_1b8);
x86_l_19c:
	/* 0x19c: mov    ebp,DWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19f:
	/* 0x19f: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1a1:
	/* 0x1a1: je     1b8 <cil_xdp_entry+0x1b8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1, 0x1b8, x86_l_1b8);
x86_l_1a3:
	/* 0x1a3: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: mov    esi,0xfffffffc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4294967292ULL);
x86_l_1ab:
	/* 0x1ab: call   1b0 <cil_xdp_entry+0x1b0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_xdp_adjust_meta);
x86_l_1b0:
	/* 0x1b0: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b2:
	/* 0x1b2: je     283 <cil_xdp_entry+0x283> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2, 0x283, x86_l_283);
x86_l_1b8:
	/* 0x1b8: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bd:
	/* 0x1bd: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1c1:
	/* 0x1c1: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1c2:
	/* 0x1c2: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1c4:
	/* 0x1c4: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1c5:
	/* 0x1c5: jmp    38c <cil_xdp_entry+0x38c> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1ca:
	/* 0x1ca: lea    r8,[rax+0x23] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 35ULL);
x86_l_1ce:
	/* 0x1ce: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d1:
	/* 0x1d1: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d1, 0x2e, x86_l_2e);
x86_l_1d7:
	/* 0x1d7: movzx  r14d,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1db:
	/* 0x1db: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1de:
	/* 0x1de: je     154 <cil_xdp_entry+0x154> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de, 0x154, x86_l_154);
x86_l_1e4:
	/* 0x1e4: mov    esi,0x23 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_1e9:
	/* 0x1e9: cmp    r14d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ed:
	/* 0x1ed: jne    2a0 <cil_xdp_entry+0x2a0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ed, 0x2a0, x86_l_2a0);
x86_l_1f3:
	/* 0x1f3: lea    edi,[rdi*4+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 2), 34ULL);
x86_l_1fa:
	/* 0x1fa: cmp    esi,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1fc:
	/* 0x1fc: jae    151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1fc, 0x151, x86_l_151);
x86_l_202:
	/* 0x202: mov    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_205:
	/* 0x205: lea    r9,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_209:
	/* 0x209: inc    r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_20c:
	/* 0x20c: cmp    r9,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20f:
	/* 0x20f: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x20f, 0x2e, x86_l_2e);
x86_l_215:
	/* 0x215: lea    r9,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_219:
	/* 0x219: movzx  r14d,BYTE PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21d:
	/* 0x21d: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_220:
	/* 0x220: je     154 <cil_xdp_entry+0x154> */
	X86_SIM_X86_JCC(X86_CC_E, 0x220, 0x154, x86_l_154);
x86_l_226:
	/* 0x226: cmp    r14d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_22a:
	/* 0x22a: jne    318 <cil_xdp_entry+0x318> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22a, 0x318, x86_l_318);
x86_l_230:
	/* 0x230: add    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R14, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_233:
	/* 0x233: cmp    esi,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_235:
	/* 0x235: jae    151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x235, 0x151, x86_l_151);
x86_l_23b:
	/* 0x23b: mov    edi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_23d:
	/* 0x23d: lea    r8,[rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_241:
	/* 0x241: inc    r8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_244:
	/* 0x244: cmp    r8,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_247:
	/* 0x247: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x247, 0x2e, x86_l_2e);
x86_l_24d:
	/* 0x24d: lea    r8,[rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_251:
	/* 0x251: movzx  r8d,BYTE PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_255:
	/* 0x255: cmp    r8b,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_259:
	/* 0x259: jb     151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_B, 0x259, 0x151, x86_l_151);
x86_l_25f:
	/* 0x25f: lea    r9,[rax+rdi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 0), 0ULL);
x86_l_263:
	/* 0x263: add    r9,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_267:
	/* 0x267: cmp    r9,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26a:
	/* 0x26a: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x26a, 0x2e, x86_l_2e);
x86_l_270:
	/* 0x270: cmp    r8b,dl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_273:
	/* 0x273: jne    151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x273, 0x151, x86_l_151);
x86_l_279:
	/* 0x279: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27c:
	/* 0x27c: movzx  r8d,BYTE PTR [rdi+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_281:
	/* 0x281: jmp    2bc <cil_xdp_entry+0x2bc> */
	X86_SIM_X86_JMP(0x281, 0x2bc, x86_l_2bc);
x86_l_283:
	/* 0x283: mov    rcx,QWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_287:
	/* 0x287: lea    rax,[rcx+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_28b:
	/* 0x28b: cmp    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_28e:
	/* 0x28e: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_293:
	/* 0x293: ja     1bd <cil_xdp_entry+0x1bd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x293, 0x1bd, x86_l_1bd);
x86_l_299:
	/* 0x299: mov    DWORD PTR [rcx],ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b:
	/* 0x29b: jmp    1bd <cil_xdp_entry+0x1bd> */
	X86_SIM_X86_JMP(0x29b, 0x1bd, x86_l_1bd);
x86_l_2a0:
	/* 0x2a0: lea    rsi,[rax+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2a4:
	/* 0x2a4: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a7:
	/* 0x2a7: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a7, 0x2e, x86_l_2e);
x86_l_2ad:
	/* 0x2ad: movzx  r8d,BYTE PTR [rax+0x23] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 35ULL);
x86_l_2b2:
	/* 0x2b2: mov    esi,0x22 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_2b7:
	/* 0x2b7: cmp    r14b,dl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2ba:
	/* 0x2ba: jne    2fd <cil_xdp_entry+0x2fd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ba, 0x2fd, x86_l_2fd);
x86_l_2bc:
	/* 0x2bc: cmp    r8b,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 10ULL);
x86_l_2c0:
	/* 0x2c0: je     36b <cil_xdp_entry+0x36b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c0, 0x36b, x86_l_36b);
x86_l_2c6:
	/* 0x2c6: movzx  edx,r8b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RDX, X86_R8, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2ca:
	/* 0x2ca: cmp    edx,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_2cd:
	/* 0x2cd: je     34a <cil_xdp_entry+0x34a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cd, 0x34a, x86_l_34a);
x86_l_2cf:
	/* 0x2cf: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d2:
	/* 0x2d2: jne    2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d2, 0x2e, x86_l_2e);
x86_l_2d8:
	/* 0x2d8: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2da:
	/* 0x2da: lea    rsi,[rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_2de:
	/* 0x2de: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_2e2:
	/* 0x2e2: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e5:
	/* 0x2e5: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e5, 0x2e, x86_l_2e);
x86_l_2eb:
	/* 0x2eb: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2ee:
	/* 0x2ee: movbe  ax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RAX, X86_RAX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_2f4:
	/* 0x2f4: movzx  r14d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2f8:
	/* 0x2f8: jmp    154 <cil_xdp_entry+0x154> */
	X86_SIM_X86_JMP(0x2f8, 0x154, x86_l_154);
x86_l_2fd:
	/* 0x2fd: movzx  esi,r8b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RSI, X86_R8, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_301:
	/* 0x301: add    esi,0x22 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 34ULL);
x86_l_304:
	/* 0x304: lea    edi,[rdi*4+0x22] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 2), 34ULL);
x86_l_30b:
	/* 0x30b: cmp    esi,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_30d:
	/* 0x30d: jae    151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x30d, 0x151, x86_l_151);
x86_l_313:
	/* 0x313: jmp    202 <cil_xdp_entry+0x202> */
	X86_SIM_X86_JMP(0x313, 0x202, x86_l_202);
x86_l_318:
	/* 0x318: lea    r9,[rax+r8*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_31c:
	/* 0x31c: add    r9,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_320:
	/* 0x320: cmp    r9,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_323:
	/* 0x323: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x323, 0x2e, x86_l_2e);
x86_l_329:
	/* 0x329: add    r8,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_32c:
	/* 0x32c: movzx  r8d,BYTE PTR [r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_331:
	/* 0x331: cmp    r14b,dl */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_334:
	/* 0x334: je     2bc <cil_xdp_entry+0x2bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x334, 0x2bc, x86_l_2bc);
x86_l_336:
	/* 0x336: movzx  r14d,r8b */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_33a:
	/* 0x33a: add    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R14, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_33d:
	/* 0x33d: cmp    esi,edi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_33f:
	/* 0x33f: jae    151 <cil_xdp_entry+0x151> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x33f, 0x151, x86_l_151);
x86_l_345:
	/* 0x345: jmp    23b <cil_xdp_entry+0x23b> */
	X86_SIM_X86_JMP(0x345, 0x23b, x86_l_23b);
x86_l_34a:
	/* 0x34a: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_34c:
	/* 0x34c: lea    rsi,[rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_350:
	/* 0x350: add    rsi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_354:
	/* 0x354: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_357:
	/* 0x357: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x357, 0x2e, x86_l_2e);
x86_l_35d:
	/* 0x35d: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_360:
	/* 0x360: movbe  r14d,DWORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 2ULL);
x86_l_366:
	/* 0x366: jmp    154 <cil_xdp_entry+0x154> */
	X86_SIM_X86_JMP(0x366, 0x154, x86_l_154);
x86_l_36b:
	/* 0x36b: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_36d:
	/* 0x36d: lea    rsi,[rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_371:
	/* 0x371: add    rsi,0xa */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 10ULL);
x86_l_375:
	/* 0x375: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_378:
	/* 0x378: ja     2e <cil_xdp_entry+0x2e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x378, 0x2e, x86_l_2e);
x86_l_37e:
	/* 0x37e: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_381:
	/* 0x381: movbe  r14,QWORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 2ULL);
x86_l_387:
	/* 0x387: jmp    154 <cil_xdp_entry+0x154> */
	X86_SIM_X86_JMP(0x387, 0x154, x86_l_154);
x86_l_38c:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
