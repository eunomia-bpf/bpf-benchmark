#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 execve_map[] __ksym;
extern __u8 execve_map_stats[] __ksym;
extern __u8 exit_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_parents_bin[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/acct_process")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6:
	/* 0x6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_d:
	/* 0xd: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: call   15 <event_exit_acct_process+0x15> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_15:
	/* 0x15: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18:
	/* 0x18: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c:
	/* 0x1c: mov    DWORD PTR [rsp+0x4],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_21:
	/* 0x21: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_28:
	/* 0x28: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2d:
	/* 0x2d: call   32 <event_exit_acct_process+0x32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_32:
	/* 0x32: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_35:
	/* 0x35: je     28b <event_exit_acct_process+0x28b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x35, 0x28b, x86_l_28b);
x86_l_3b:
	/* 0x3b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e:
	/* 0x3e: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_43:
	/* 0x43: je     21e <event_exit_acct_process+0x21e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x43, 0x21e, x86_l_21e);
x86_l_49:
	/* 0x49: call   4e <event_exit_acct_process+0x4e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_4e:
	/* 0x4e: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_51:
	/* 0x51: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_59:
	/* 0x59: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exit_heap_map));
x86_l_60:
	/* 0x60: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_65:
	/* 0x65: call   6a <event_exit_acct_process+0x6a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6a:
	/* 0x6a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d:
	/* 0x6d: je     28b <event_exit_acct_process+0x28b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d, 0x28b, x86_l_28b);
x86_l_73:
	/* 0x73: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_76:
	/* 0x76: movabs rax,0x2800000007 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 171798691847ULL);
x86_l_80:
	/* 0x80: mov    QWORD PTR [r12],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84:
	/* 0x84: call   89 <event_exit_acct_process+0x89> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_89:
	/* 0x89: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8e:
	/* 0x8e: mov    DWORD PTR [r12+0x10],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_93:
	/* 0x93: mov    DWORD PTR [r12+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_9c:
	/* 0x9c: mov    rax,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a0:
	/* 0xa0: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a5:
	/* 0xa5: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_a8:
	/* 0xa8: add    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_ac:
	/* 0xac: mov    DWORD PTR [r12+0x24],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_b1:
	/* 0xb1: add    r13,0xa8c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2700ULL);
x86_l_b8:
	/* 0xb8: jns    c7 <event_exit_acct_process+0xc7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb8, 0xc7, x86_l_c7);
x86_l_ba:
	/* 0xba: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bd:
	/* 0xbd: jns    d6 <event_exit_acct_process+0xd6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbd, 0xd6, x86_l_d6);
x86_l_bf:
	/* 0xbf: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c3:
	/* 0xc3: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5:
	/* 0xc5: jmp    dc <event_exit_acct_process+0xdc> */
	X86_SIM_X86_JMP(0xc5, 0xdc, x86_l_dc);
x86_l_c7:
	/* 0xc7: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_cc:
	/* 0xcc: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_cf:
	/* 0xcf: call   d4 <event_exit_acct_process+0xd4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d4:
	/* 0xd4: jmp    dc <event_exit_acct_process+0xdc> */
	X86_SIM_X86_JMP(0xd4, 0xdc, x86_l_dc);
x86_l_d6:
	/* 0xd6: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dc:
	/* 0xdc: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e4:
	/* 0xe4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_eb:
	/* 0xeb: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f0:
	/* 0xf0: call   f5 <event_exit_acct_process+0xf5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f5:
	/* 0xf5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f8:
	/* 0xf8: je     170 <event_exit_acct_process+0x170> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf8, 0x170, x86_l_170);
x86_l_fa:
	/* 0xfa: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: je     170 <event_exit_acct_process+0x170> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe, 0x170, x86_l_170);
x86_l_100:
	/* 0x100: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_107:
	/* 0x107: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_10c:
	/* 0x10c: mov    r8d,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_112:
	/* 0x112: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_115:
	/* 0x115: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_118:
	/* 0x118: call   11d <event_exit_acct_process+0x11d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_11d:
	/* 0x11d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_120:
	/* 0x120: jns    21e <event_exit_acct_process+0x21e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x120, 0x21e, x86_l_21e);
x86_l_126:
	/* 0x126: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_129:
	/* 0x129: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_131:
	/* 0x131: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_138:
	/* 0x138: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_13d:
	/* 0x13d: call   142 <event_exit_acct_process+0x142> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_142:
	/* 0x142: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_145:
	/* 0x145: je     21e <event_exit_acct_process+0x21e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x145, 0x21e, x86_l_21e);
x86_l_14b:
	/* 0x14b: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_14f:
	/* 0x14f: jg     1ea <event_exit_acct_process+0x1ea> */
	X86_SIM_X86_JCC(X86_CC_G, 0x14f, 0x1ea, x86_l_1ea);
x86_l_155:
	/* 0x155: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_159:
	/* 0x159: je     204 <event_exit_acct_process+0x204> */
	X86_SIM_X86_JCC(X86_CC_E, 0x159, 0x204, x86_l_204);
x86_l_15f:
	/* 0x15f: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_163:
	/* 0x163: jne    1c2 <event_exit_acct_process+0x1c2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x163, 0x1c2, x86_l_1c2);
x86_l_165:
	/* 0x165: add    rax,0x1a8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 424ULL);
x86_l_16b:
	/* 0x16b: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x16b, 0x21a, x86_l_21a);
x86_l_170:
	/* 0x170: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_177:
	/* 0x177: mov    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_17c:
	/* 0x17c: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_181:
	/* 0x181: call   186 <event_exit_acct_process+0x186> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_186:
	/* 0x186: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_189:
	/* 0x189: jns    21e <event_exit_acct_process+0x21e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x189, 0x21e, x86_l_21e);
x86_l_18f:
	/* 0x18f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_192:
	/* 0x192: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_19a:
	/* 0x19a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_1a1:
	/* 0x1a1: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a6:
	/* 0x1a6: call   1ab <event_exit_acct_process+0x1ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ab:
	/* 0x1ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ae:
	/* 0x1ae: je     21e <event_exit_acct_process+0x21e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ae, 0x21e, x86_l_21e);
x86_l_1b0:
	/* 0x1b0: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_1b4:
	/* 0x1b4: jg     1d0 <event_exit_acct_process+0x1d0> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1b4, 0x1d0, x86_l_1d0);
x86_l_1b6:
	/* 0x1b6: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_1ba:
	/* 0x1ba: je     204 <event_exit_acct_process+0x204> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ba, 0x204, x86_l_204);
x86_l_1bc:
	/* 0x1bc: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_1c0:
	/* 0x1c0: je     165 <event_exit_acct_process+0x165> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c0, 0x165, x86_l_165);
x86_l_1c2:
	/* 0x1c2: cmp    r15,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_1c6:
	/* 0x1c6: jne    1fc <event_exit_acct_process+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c6, 0x1fc, x86_l_1fc);
x86_l_1c8:
	/* 0x1c8: add    rax,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_l_1ce:
	/* 0x1ce: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x1ce, 0x21a, x86_l_21a);
x86_l_1d0:
	/* 0x1d0: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_1d4:
	/* 0x1d4: je     20c <event_exit_acct_process+0x20c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d4, 0x20c, x86_l_20c);
x86_l_1d6:
	/* 0x1d6: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_1da:
	/* 0x1da: je     214 <event_exit_acct_process+0x214> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da, 0x214, x86_l_214);
x86_l_1dc:
	/* 0x1dc: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_1e0:
	/* 0x1e0: jne    1fc <event_exit_acct_process+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e0, 0x1fc, x86_l_1fc);
x86_l_1e2:
	/* 0x1e2: add    rax,0x190 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 400ULL);
x86_l_1e8:
	/* 0x1e8: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x1e8, 0x21a, x86_l_21a);
x86_l_1ea:
	/* 0x1ea: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_1ee:
	/* 0x1ee: je     20c <event_exit_acct_process+0x20c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee, 0x20c, x86_l_20c);
x86_l_1f0:
	/* 0x1f0: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_1f4:
	/* 0x1f4: je     214 <event_exit_acct_process+0x214> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f4, 0x214, x86_l_214);
x86_l_1f6:
	/* 0x1f6: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_1fa:
	/* 0x1fa: je     1e2 <event_exit_acct_process+0x1e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa, 0x1e2, x86_l_1e2);
x86_l_1fc:
	/* 0x1fc: add    rax,0x188 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 392ULL);
x86_l_202:
	/* 0x202: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x202, 0x21a, x86_l_21a);
x86_l_204:
	/* 0x204: add    rax,0x1b0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 432ULL);
x86_l_20a:
	/* 0x20a: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x20a, 0x21a, x86_l_21a);
x86_l_20c:
	/* 0x20c: add    rax,0x1b8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 440ULL);
x86_l_212:
	/* 0x212: jmp    21a <event_exit_acct_process+0x21a> */
	X86_SIM_X86_JMP(0x212, 0x21a, x86_l_21a);
x86_l_214:
	/* 0x214: add    rax,0x198 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 408ULL);
x86_l_21a:
	/* 0x21a: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_21e:
	/* 0x21e: mov    DWORD PTR [rsp+0x8],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_223:
	/* 0x223: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_22a:
	/* 0x22a: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22f:
	/* 0x22f: call   234 <event_exit_acct_process+0x234> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_234:
	/* 0x234: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_236:
	/* 0x236: je     25b <event_exit_acct_process+0x25b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x236, 0x25b, x86_l_25b);
x86_l_238:
	/* 0x238: mov    DWORD PTR [rsp+0x4],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869186ULL);
x86_l_240:
	/* 0x240: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map_stats));
x86_l_247:
	/* 0x247: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24c:
	/* 0x24c: call   251 <event_exit_acct_process+0x251> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_251:
	/* 0x251: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_254:
	/* 0x254: je     27c <event_exit_acct_process+0x27c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x254, 0x27c, x86_l_27c);
x86_l_256:
	/* 0x256: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_259:
	/* 0x259: jmp    27c <event_exit_acct_process+0x27c> */
	X86_SIM_X86_JMP(0x259, 0x27c, x86_l_27c);
x86_l_25b:
	/* 0x25b: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_263:
	/* 0x263: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map_stats));
x86_l_26a:
	/* 0x26a: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26f:
	/* 0x26f: call   274 <event_exit_acct_process+0x274> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_274:
	/* 0x274: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_277:
	/* 0x277: je     27c <event_exit_acct_process+0x27c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x277, 0x27c, x86_l_27c);
x86_l_279:
	/* 0x279: dec    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_DEC)), 0ULL);
x86_l_27c:
	/* 0x27c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_parents_bin));
x86_l_283:
	/* 0x283: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_286:
	/* 0x286: call   28b <event_exit_acct_process+0x28b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_28b:
	/* 0x28b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d:
	/* 0x28d: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_291:
	/* 0x291: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_292:
	/* 0x292: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_294:
	/* 0x294: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_296:
	/* 0x296: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_298:
	/* 0x298: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: jmp    29f <event_exit_acct_process+0x29f> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_29f:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
