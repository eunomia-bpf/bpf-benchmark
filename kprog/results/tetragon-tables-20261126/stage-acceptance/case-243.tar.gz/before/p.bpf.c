#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 216U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(3) M(4) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(15) M(16) M(19) M(20)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 file_modification_map[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/fd_install")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x94],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 635655159808ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x94] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_fd_install+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x2a32, x86_l_2a32);
x86_l_3c:
	/* 0x3c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0x94] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 148ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_fd_install+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x2a32, x86_l_2a32);
x86_l_5c:
	/* 0x5c: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    WORD PTR [r15+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_69:
	/* 0x69: mov    BYTE PTR [r15+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_71:
	/* 0x71: mov    QWORD PTR [r15+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7c:
	/* 0x7c: mov    QWORD PTR [r15+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_87:
	/* 0x87: mov    QWORD PTR [r15+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_92:
	/* 0x92: mov    QWORD PTR [r15+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9d:
	/* 0x9d: mov    QWORD PTR [r15+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a8:
	/* 0xa8: mov    QWORD PTR [r15+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b3:
	/* 0xb3: mov    QWORD PTR [r15+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_be:
	/* 0xbe: mov    QWORD PTR [r15+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_c9:
	/* 0xc9: call   ce <trace_fd_install+0xce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_ce:
	/* 0xce: mov    QWORD PTR [r15+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d5:
	/* 0xd5: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_dd:
	/* 0xdd: mov    QWORD PTR [r15+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e5:
	/* 0xe5: mov    QWORD PTR [r15+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ed:
	/* 0xed: mov    QWORD PTR [r15+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f5:
	/* 0xf5: mov    QWORD PTR [r15+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fd:
	/* 0xfd: mov    QWORD PTR [r15+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_105:
	/* 0x105: mov    QWORD PTR [r15+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10d:
	/* 0x10d: mov    QWORD PTR [r15+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_115:
	/* 0x115: mov    QWORD PTR [r15+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11d:
	/* 0x11d: mov    QWORD PTR [r15+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_125:
	/* 0x125: mov    QWORD PTR [r15+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12d:
	/* 0x12d: mov    QWORD PTR [r15+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_135:
	/* 0x135: mov    QWORD PTR [r15+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13d:
	/* 0x13d: call   142 <trace_fd_install+0x142> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_142:
	/* 0x142: mov    DWORD PTR [r15+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [r15+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14e:
	/* 0x14e: mov    DWORD PTR [r15+0x70],0x308 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337928ULL);
x86_l_156:
	/* 0x156: call   15b <trace_fd_install+0x15b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_15b:
	/* 0x15b: mov    QWORD PTR [r15],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e:
	/* 0x15e: call   163 <trace_fd_install+0x163> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_163:
	/* 0x163: mov    WORD PTR [r15+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_168:
	/* 0x168: call   16d <trace_fd_install+0x16d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16d:
	/* 0x16d: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_170:
	/* 0x170: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_174:
	/* 0x174: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177:
	/* 0x177: jns    188 <trace_fd_install+0x188> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x177, 0x188, x86_l_188);
x86_l_179:
	/* 0x179: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b:
	/* 0x17b: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_180:
	/* 0x180: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_186:
	/* 0x186: jne    1c1 <trace_fd_install+0x1c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x186, 0x1c1, x86_l_1c1);
x86_l_188:
	/* 0x188: call   18d <trace_fd_install+0x18d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18d:
	/* 0x18d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_190:
	/* 0x190: call   195 <trace_fd_install+0x195> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_195:
	/* 0x195: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_199:
	/* 0x199: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19c:
	/* 0x19c: jns    1ac <trace_fd_install+0x1ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19c, 0x1ac, x86_l_1ac);
x86_l_19e:
	/* 0x19e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a1:
	/* 0x1a1: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a5:
	/* 0x1a5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a8:
	/* 0x1a8: js     1b7 <trace_fd_install+0x1b7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a8, 0x1b7, x86_l_1b7);
x86_l_1aa:
	/* 0x1aa: jmp    1bd <trace_fd_install+0x1bd> */
	X86_SIM_X86_JMP(0x1aa, 0x1bd, x86_l_1bd);
x86_l_1ac:
	/* 0x1ac: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ae:
	/* 0x1ae: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b2:
	/* 0x1b2: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b5:
	/* 0x1b5: jns    1bd <trace_fd_install+0x1bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b5, 0x1bd, x86_l_1bd);
x86_l_1b7:
	/* 0x1b7: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b9:
	/* 0x1b9: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1bb:
	/* 0x1bb: jne    231 <trace_fd_install+0x231> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bb, 0x231, x86_l_231);
x86_l_1bd:
	/* 0x1bd: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c1:
	/* 0x1c1: mov    DWORD PTR [r15+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c5:
	/* 0x1c5: mov    eax,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c9:
	/* 0x1c9: mov    DWORD PTR [rsp+0x90],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1d0:
	/* 0x1d0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d7:
	/* 0x1d7: lea    rsi,[rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1df:
	/* 0x1df: call   1e4 <trace_fd_install+0x1e4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e4:
	/* 0x1e4: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1ec:
	/* 0x1ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ef:
	/* 0x1ef: je     258 <trace_fd_install+0x258> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef, 0x258, x86_l_258);
x86_l_1f1:
	/* 0x1f1: mov    eax,DWORD PTR [r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f5:
	/* 0x1f5: mov    DWORD PTR [rsp+0x8c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_1fc:
	/* 0x1fc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_203:
	/* 0x203: lea    rsi,[rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_20b:
	/* 0x20b: call   210 <trace_fd_install+0x210> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_210:
	/* 0x210: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_213:
	/* 0x213: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_216:
	/* 0x216: je     2de <trace_fd_install+0x2de> */
	X86_SIM_X86_JCC(X86_CC_E, 0x216, 0x2de, x86_l_2de);
x86_l_21c:
	/* 0x21c: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_221:
	/* 0x221: jne    77e <trace_fd_install+0x77e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x221, 0x77e, x86_l_77e);
x86_l_227:
	/* 0x227: call   22c <trace_fd_install+0x22c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_22c:
	/* 0x22c: jmp    7d6 <trace_fd_install+0x7d6> */
	X86_SIM_X86_JMP(0x22c, 0x7d6, x86_l_7d6);
x86_l_231:
	/* 0x231: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_238:
	/* 0x238: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_23d:
	/* 0x23d: call   242 <trace_fd_install+0x242> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_242:
	/* 0x242: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_245:
	/* 0x245: je     24e <trace_fd_install+0x24e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x245, 0x24e, x86_l_24e);
x86_l_247:
	/* 0x247: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_249:
	/* 0x249: jmp    1c1 <trace_fd_install+0x1c1> */
	X86_SIM_X86_JMP(0x249, 0x1c1, x86_l_1c1);
x86_l_24e:
	/* 0x24e: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_253:
	/* 0x253: jmp    1c1 <trace_fd_install+0x1c1> */
	X86_SIM_X86_JMP(0x253, 0x1c1, x86_l_1c1);
x86_l_258:
	/* 0x258: mov    eax,DWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_25f:
	/* 0x25f: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_263:
	/* 0x263: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_26b:
	/* 0x26b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_272:
	/* 0x272: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_277:
	/* 0x277: call   27c <trace_fd_install+0x27c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27c:
	/* 0x27c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27f:
	/* 0x27f: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f, 0x2a32, x86_l_2a32);
x86_l_285:
	/* 0x285: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_288:
	/* 0x288: mov    eax,DWORD PTR [rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_28c:
	/* 0x28c: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_290:
	/* 0x290: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_295:
	/* 0x295: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_298:
	/* 0x298: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29a:
	/* 0x29a: call   29f <trace_fd_install+0x29f> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_29f:
	/* 0x29f: mov    r12,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_2a6:
	/* 0x2a6: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ab:
	/* 0x2ab: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2b0:
	/* 0x2b0: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2b3:
	/* 0x2b3: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2b6:
	/* 0x2b6: call   2bb <trace_fd_install+0x2bb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2bb:
	/* 0x2bb: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2c0:
	/* 0x2c0: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2c3:
	/* 0x2c3: call   2c8 <trace_fd_install+0x2c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c8:
	/* 0x2c8: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2d0:
	/* 0x2d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d3:
	/* 0x2d3: jne    1f1 <trace_fd_install+0x1f1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d3, 0x1f1, x86_l_1f1);
x86_l_2d9:
	/* 0x2d9: jmp    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JMP(0x2d9, 0x2a32, x86_l_2a32);
x86_l_2de:
	/* 0x2de: mov    eax,DWORD PTR [rsp+0x8c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 140ULL);
x86_l_2e5:
	/* 0x2e5: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2e9:
	/* 0x2e9: mov    DWORD PTR [rsp+0x2c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 188978561024ULL);
x86_l_2f1:
	/* 0x2f1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_2f8:
	/* 0x2f8: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2fd:
	/* 0x2fd: call   302 <trace_fd_install+0x302> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_302:
	/* 0x302: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_305:
	/* 0x305: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x305, 0x2a32, x86_l_2a32);
x86_l_30b:
	/* 0x30b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30e:
	/* 0x30e: mov    eax,DWORD PTR [rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_312:
	/* 0x312: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_316:
	/* 0x316: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_31b:
	/* 0x31b: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_31e:
	/* 0x31e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_320:
	/* 0x320: call   325 <trace_fd_install+0x325> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_325:
	/* 0x325: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_32c:
	/* 0x32c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_331:
	/* 0x331: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_336:
	/* 0x336: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_339:
	/* 0x339: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33c:
	/* 0x33c: call   341 <trace_fd_install+0x341> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_341:
	/* 0x341: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_346:
	/* 0x346: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_349:
	/* 0x349: call   34e <trace_fd_install+0x34e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_34e:
	/* 0x34e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_351:
	/* 0x351: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x351, 0x2a32, x86_l_2a32);
x86_l_357:
	/* 0x357: mov    r9,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_35e:
	/* 0x35e: lea    r8,[r9+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_362:
	/* 0x362: mov    rcx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_365:
	/* 0x365: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_368:
	/* 0x368: jns    36f <trace_fd_install+0x36f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x368, 0x36f, x86_l_36f);
x86_l_36a:
	/* 0x36a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36d:
	/* 0x36d: jmp    371 <trace_fd_install+0x371> */
	X86_SIM_X86_JMP(0x36d, 0x371, x86_l_371);
x86_l_36f:
	/* 0x36f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_371:
	/* 0x371: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_376:
	/* 0x376: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_37a:
	/* 0x37a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_37d:
	/* 0x37d: jns    384 <trace_fd_install+0x384> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x37d, 0x384, x86_l_384);
x86_l_37f:
	/* 0x37f: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_382:
	/* 0x382: jmp    386 <trace_fd_install+0x386> */
	X86_SIM_X86_JMP(0x382, 0x386, x86_l_386);
x86_l_384:
	/* 0x384: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_386:
	/* 0x386: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_38a:
	/* 0x38a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_38c:
	/* 0x38c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_38f:
	/* 0x38f: jns    396 <trace_fd_install+0x396> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x38f, 0x396, x86_l_396);
x86_l_391:
	/* 0x391: mov    rbx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_394:
	/* 0x394: jmp    398 <trace_fd_install+0x398> */
	X86_SIM_X86_JMP(0x394, 0x398, x86_l_398);
x86_l_396:
	/* 0x396: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_398:
	/* 0x398: lea    rdx,[rbx+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_39c:
	/* 0x39c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_39f:
	/* 0x39f: jns    3a3 <trace_fd_install+0x3a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x39f, 0x3a3, x86_l_3a3);
x86_l_3a1:
	/* 0x3a1: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a3:
	/* 0x3a3: mov    DWORD PTR [rax+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_3a6:
	/* 0x3a6: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3aa:
	/* 0x3aa: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3ad:
	/* 0x3ad: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3af:
	/* 0x3af: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3b2:
	/* 0x3b2: jns    3b9 <trace_fd_install+0x3b9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3b2, 0x3b9, x86_l_3b9);
x86_l_3b4:
	/* 0x3b4: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b7:
	/* 0x3b7: jmp    3bb <trace_fd_install+0x3bb> */
	X86_SIM_X86_JMP(0x3b7, 0x3bb, x86_l_3bb);
x86_l_3b9:
	/* 0x3b9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3bb:
	/* 0x3bb: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3be:
	/* 0x3be: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3c1:
	/* 0x3c1: jns    3c5 <trace_fd_install+0x3c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c1, 0x3c5, x86_l_3c5);
x86_l_3c3:
	/* 0x3c3: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c5:
	/* 0x3c5: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3c7:
	/* 0x3c7: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3cb:
	/* 0x3cb: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3ce:
	/* 0x3ce: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3d2:
	/* 0x3d2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d4:
	/* 0x3d4: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3d7:
	/* 0x3d7: jns    3db <trace_fd_install+0x3db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d7, 0x3db, x86_l_3db);
x86_l_3d9:
	/* 0x3d9: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3db:
	/* 0x3db: mov    DWORD PTR [rax+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_3de:
	/* 0x3de: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3e1:
	/* 0x3e1: jns    3e8 <trace_fd_install+0x3e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e1, 0x3e8, x86_l_3e8);
x86_l_3e3:
	/* 0x3e3: mov    rdx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e6:
	/* 0x3e6: jmp    3ea <trace_fd_install+0x3ea> */
	X86_SIM_X86_JMP(0x3e6, 0x3ea, x86_l_3ea);
x86_l_3e8:
	/* 0x3e8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ea:
	/* 0x3ea: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3ee:
	/* 0x3ee: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f0:
	/* 0x3f0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3f3:
	/* 0x3f3: jns    3fa <trace_fd_install+0x3fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f3, 0x3fa, x86_l_3fa);
x86_l_3f5:
	/* 0x3f5: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f8:
	/* 0x3f8: jmp    3fc <trace_fd_install+0x3fc> */
	X86_SIM_X86_JMP(0x3f8, 0x3fc, x86_l_3fc);
x86_l_3fa:
	/* 0x3fa: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fc:
	/* 0x3fc: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ff:
	/* 0x3ff: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_402:
	/* 0x402: jns    406 <trace_fd_install+0x406> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x402, 0x406, x86_l_406);
x86_l_404:
	/* 0x404: mov    edi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_406:
	/* 0x406: mov    esi,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_408:
	/* 0x408: shl    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_40c:
	/* 0x40c: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_40f:
	/* 0x40f: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_413:
	/* 0x413: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_415:
	/* 0x415: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_418:
	/* 0x418: jns    41c <trace_fd_install+0x41c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x418, 0x41c, x86_l_41c);
x86_l_41a:
	/* 0x41a: mov    esi,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41c:
	/* 0x41c: mov    DWORD PTR [rax+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_41f:
	/* 0x41f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_421:
	/* 0x421: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_424:
	/* 0x424: jns    42b <trace_fd_install+0x42b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x424, 0x42b, x86_l_42b);
x86_l_426:
	/* 0x426: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_429:
	/* 0x429: jmp    42d <trace_fd_install+0x42d> */
	X86_SIM_X86_JMP(0x429, 0x42d, x86_l_42d);
x86_l_42b:
	/* 0x42b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42d:
	/* 0x42d: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_430:
	/* 0x430: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_433:
	/* 0x433: jns    437 <trace_fd_install+0x437> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x433, 0x437, x86_l_437);
x86_l_435:
	/* 0x435: mov    esi,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_437:
	/* 0x437: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_439:
	/* 0x439: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_43d:
	/* 0x43d: add    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_440:
	/* 0x440: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_444:
	/* 0x444: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_447:
	/* 0x447: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_44a:
	/* 0x44a: jns    451 <trace_fd_install+0x451> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x44a, 0x451, x86_l_451);
x86_l_44c:
	/* 0x44c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44f:
	/* 0x44f: jmp    453 <trace_fd_install+0x453> */
	X86_SIM_X86_JMP(0x44f, 0x453, x86_l_453);
x86_l_451:
	/* 0x451: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_453:
	/* 0x453: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_457:
	/* 0x457: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_45a:
	/* 0x45a: jns    45f <trace_fd_install+0x45f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45a, 0x45f, x86_l_45f);
x86_l_45c:
	/* 0x45c: mov    r8d,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45f:
	/* 0x45f: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_463:
	/* 0x463: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_466:
	/* 0x466: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_468:
	/* 0x468: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_46b:
	/* 0x46b: jns    472 <trace_fd_install+0x472> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x46b, 0x472, x86_l_472);
x86_l_46d:
	/* 0x46d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_470:
	/* 0x470: jmp    474 <trace_fd_install+0x474> */
	X86_SIM_X86_JMP(0x470, 0x474, x86_l_474);
x86_l_472:
	/* 0x472: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_474:
	/* 0x474: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_477:
	/* 0x477: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_47a:
	/* 0x47a: jns    47e <trace_fd_install+0x47e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x47a, 0x47e, x86_l_47e);
x86_l_47c:
	/* 0x47c: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_47e:
	/* 0x47e: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_480:
	/* 0x480: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_484:
	/* 0x484: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_487:
	/* 0x487: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_48b:
	/* 0x48b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_48d:
	/* 0x48d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_490:
	/* 0x490: jns    497 <trace_fd_install+0x497> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x490, 0x497, x86_l_497);
x86_l_492:
	/* 0x492: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_495:
	/* 0x495: jmp    499 <trace_fd_install+0x499> */
	X86_SIM_X86_JMP(0x495, 0x499, x86_l_499);
x86_l_497:
	/* 0x497: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_499:
	/* 0x499: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_49d:
	/* 0x49d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4a0:
	/* 0x4a0: jns    4a4 <trace_fd_install+0x4a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4a0, 0x4a4, x86_l_4a4);
x86_l_4a2:
	/* 0x4a2: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a4:
	/* 0x4a4: cmp    r8d,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4a7:
	/* 0x4a7: jne    4da <trace_fd_install+0x4da> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a7, 0x4da, x86_l_4da);
x86_l_4a9:
	/* 0x4a9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ab:
	/* 0x4ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: jns    4b5 <trace_fd_install+0x4b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ae, 0x4b5, x86_l_4b5);
x86_l_4b0:
	/* 0x4b0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b3:
	/* 0x4b3: jmp    4b7 <trace_fd_install+0x4b7> */
	X86_SIM_X86_JMP(0x4b3, 0x4b7, x86_l_4b7);
x86_l_4b5:
	/* 0x4b5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4b7:
	/* 0x4b7: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4ba:
	/* 0x4ba: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4bd:
	/* 0x4bd: jns    4c1 <trace_fd_install+0x4c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4bd, 0x4c1, x86_l_4c1);
x86_l_4bf:
	/* 0x4bf: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c1:
	/* 0x4c1: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4c3:
	/* 0x4c3: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_4c7:
	/* 0x4c7: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4ca:
	/* 0x4ca: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_4ce:
	/* 0x4ce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d0:
	/* 0x4d0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4d3:
	/* 0x4d3: jns    4d7 <trace_fd_install+0x4d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4d3, 0x4d7, x86_l_4d7);
x86_l_4d5:
	/* 0x4d5: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4d7:
	/* 0x4d7: mov    DWORD PTR [rax+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4da:
	/* 0x4da: mov    QWORD PTR [rsp+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4df:
	/* 0x4df: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4e4:
	/* 0x4e4: mov    DWORD PTR [rax+0x30],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4e8:
	/* 0x4e8: lea    rbp,[r9+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4ef:
	/* 0x4ef: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_4f2:
	/* 0x4f2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f5:
	/* 0x4f5: jns    4fc <trace_fd_install+0x4fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4f5, 0x4fc, x86_l_4fc);
x86_l_4f7:
	/* 0x4f7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fa:
	/* 0x4fa: jmp    4fe <trace_fd_install+0x4fe> */
	X86_SIM_X86_JMP(0x4fa, 0x4fe, x86_l_4fe);
x86_l_4fc:
	/* 0x4fc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4fe:
	/* 0x4fe: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_502:
	/* 0x502: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_504:
	/* 0x504: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_507:
	/* 0x507: jns    50e <trace_fd_install+0x50e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x507, 0x50e, x86_l_50e);
x86_l_509:
	/* 0x509: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50c:
	/* 0x50c: jmp    510 <trace_fd_install+0x510> */
	X86_SIM_X86_JMP(0x50c, 0x510, x86_l_510);
x86_l_50e:
	/* 0x50e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_510:
	/* 0x510: mov    r14,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_513:
	/* 0x513: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_516:
	/* 0x516: jns    51a <trace_fd_install+0x51a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x516, 0x51a, x86_l_51a);
x86_l_518:
	/* 0x518: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51a:
	/* 0x51a: mov    r12,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_51f:
	/* 0x51f: mov    DWORD PTR [r12+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_524:
	/* 0x524: call   529 <trace_fd_install+0x529> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_529:
	/* 0x529: mov    DWORD PTR [r12+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_52e:
	/* 0x52e: lea    rax,[r14+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_532:
	/* 0x532: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_535:
	/* 0x535: jns    53c <trace_fd_install+0x53c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x535, 0x53c, x86_l_53c);
x86_l_537:
	/* 0x537: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53a:
	/* 0x53a: jmp    53e <trace_fd_install+0x53e> */
	X86_SIM_X86_JMP(0x53a, 0x53e, x86_l_53e);
x86_l_53c:
	/* 0x53c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_53e:
	/* 0x53e: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_543:
	/* 0x543: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_546:
	/* 0x546: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_54b:
	/* 0x54b: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_54f:
	/* 0x54f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_552:
	/* 0x552: jns    559 <trace_fd_install+0x559> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x552, 0x559, x86_l_559);
x86_l_554:
	/* 0x554: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_557:
	/* 0x557: jmp    55b <trace_fd_install+0x55b> */
	X86_SIM_X86_JMP(0x557, 0x55b, x86_l_55b);
x86_l_559:
	/* 0x559: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_55b:
	/* 0x55b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_560:
	/* 0x560: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_564:
	/* 0x564: add    rbx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_568:
	/* 0x568: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_56b:
	/* 0x56b: jns    572 <trace_fd_install+0x572> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x56b, 0x572, x86_l_572);
x86_l_56d:
	/* 0x56d: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_570:
	/* 0x570: jmp    574 <trace_fd_install+0x574> */
	X86_SIM_X86_JMP(0x570, 0x574, x86_l_574);
x86_l_572:
	/* 0x572: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_574:
	/* 0x574: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_579:
	/* 0x579: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_57d:
	/* 0x57d: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_580:
	/* 0x580: jns    58d <trace_fd_install+0x58d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x580, 0x58d, x86_l_58d);
x86_l_582:
	/* 0x582: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_585:
	/* 0x585: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_587:
	/* 0x587: je     58d <trace_fd_install+0x58d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x587, 0x58d, x86_l_58d);
x86_l_589:
	/* 0x589: or     BYTE PTR [rcx+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_58d:
	/* 0x58d: lea    rdi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_591:
	/* 0x591: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_599:
	/* 0x599: mov    QWORD PTR [rcx+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_5a1:
	/* 0x5a1: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_5a6:
	/* 0x5a6: call   5ab <trace_fd_install+0x5ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_5ab:
	/* 0x5ab: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5ae:
	/* 0x5ae: jns    5b6 <trace_fd_install+0x5b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5ae, 0x5b6, x86_l_5b6);
x86_l_5b0:
	/* 0x5b0: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b4:
	/* 0x5b4: jmp    5b8 <trace_fd_install+0x5b8> */
	X86_SIM_X86_JMP(0x5b4, 0x5b8, x86_l_5b8);
x86_l_5b6:
	/* 0x5b6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5b8:
	/* 0x5b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5bb:
	/* 0x5bb: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5c0:
	/* 0x5c0: jns    5c7 <trace_fd_install+0x5c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5c0, 0x5c7, x86_l_5c7);
x86_l_5c2:
	/* 0x5c2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c5:
	/* 0x5c5: jmp    5c9 <trace_fd_install+0x5c9> */
	X86_SIM_X86_JMP(0x5c5, 0x5c9, x86_l_5c9);
x86_l_5c7:
	/* 0x5c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5c9:
	/* 0x5c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5cc:
	/* 0x5cc: jns    619 <trace_fd_install+0x619> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5cc, 0x619, x86_l_619);
x86_l_5ce:
	/* 0x5ce: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5d1:
	/* 0x5d1: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5d6:
	/* 0x5d6: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5da:
	/* 0x5da: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5df:
	/* 0x5df: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e3:
	/* 0x5e3: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5e8:
	/* 0x5e8: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5ec:
	/* 0x5ec: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_5f1:
	/* 0x5f1: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5f5:
	/* 0x5f5: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5fa:
	/* 0x5fa: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5fe:
	/* 0x5fe: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_603:
	/* 0x603: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_607:
	/* 0x607: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_60c:
	/* 0x60c: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_610:
	/* 0x610: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_615:
	/* 0x615: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_619:
	/* 0x619: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_61c:
	/* 0x61c: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_620:
	/* 0x620: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_625:
	/* 0x625: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_628:
	/* 0x628: jns    75f <trace_fd_install+0x75f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x628, 0x75f, x86_l_75f);
x86_l_62e:
	/* 0x62e: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_631:
	/* 0x631: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_633:
	/* 0x633: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_635:
	/* 0x635: je     76e <trace_fd_install+0x76e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x635, 0x76e, x86_l_76e);
x86_l_63b:
	/* 0x63b: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_63f:
	/* 0x63f: mov    BYTE PTR [rbp+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_642:
	/* 0x642: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_644:
	/* 0x644: je     76e <trace_fd_install+0x76e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x644, 0x76e, x86_l_76e);
x86_l_64a:
	/* 0x64a: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_64e:
	/* 0x64e: mov    BYTE PTR [rbp+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_651:
	/* 0x651: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_653:
	/* 0x653: je     76e <trace_fd_install+0x76e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x653, 0x76e, x86_l_76e);
x86_l_659:
	/* 0x659: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_65d:
	/* 0x65d: mov    BYTE PTR [rbp+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_660:
	/* 0x660: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_662:
	/* 0x662: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x662, 0x1905, x86_l_1905);
x86_l_668:
	/* 0x668: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_66c:
	/* 0x66c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_671:
	/* 0x671: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_674:
	/* 0x674: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_676:
	/* 0x676: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x676, 0x1905, x86_l_1905);
x86_l_67c:
	/* 0x67c: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_680:
	/* 0x680: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_685:
	/* 0x685: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_688:
	/* 0x688: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_68a:
	/* 0x68a: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x68a, 0x1905, x86_l_1905);
x86_l_690:
	/* 0x690: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_694:
	/* 0x694: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_699:
	/* 0x699: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_69c:
	/* 0x69c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_69e:
	/* 0x69e: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69e, 0x1905, x86_l_1905);
x86_l_6a4:
	/* 0x6a4: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_6a8:
	/* 0x6a8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6ad:
	/* 0x6ad: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_6b0:
	/* 0x6b0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6b2:
	/* 0x6b2: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b2, 0x1905, x86_l_1905);
x86_l_6b8:
	/* 0x6b8: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_6bc:
	/* 0x6bc: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6c1:
	/* 0x6c1: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_6c4:
	/* 0x6c4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6c6:
	/* 0x6c6: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c6, 0x1905, x86_l_1905);
x86_l_6cc:
	/* 0x6cc: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_6d0:
	/* 0x6d0: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6d5:
	/* 0x6d5: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_6d8:
	/* 0x6d8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6da:
	/* 0x6da: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6da, 0x1905, x86_l_1905);
x86_l_6e0:
	/* 0x6e0: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_6e4:
	/* 0x6e4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e9:
	/* 0x6e9: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_6ec:
	/* 0x6ec: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6ee:
	/* 0x6ee: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6ee, 0x1905, x86_l_1905);
x86_l_6f4:
	/* 0x6f4: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_6f8:
	/* 0x6f8: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6fd:
	/* 0x6fd: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_700:
	/* 0x700: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_702:
	/* 0x702: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x702, 0x1905, x86_l_1905);
x86_l_708:
	/* 0x708: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_70c:
	/* 0x70c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_711:
	/* 0x711: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_714:
	/* 0x714: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_716:
	/* 0x716: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x716, 0x1905, x86_l_1905);
x86_l_71c:
	/* 0x71c: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_720:
	/* 0x720: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_725:
	/* 0x725: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_728:
	/* 0x728: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_72a:
	/* 0x72a: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x72a, 0x1905, x86_l_1905);
x86_l_730:
	/* 0x730: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_734:
	/* 0x734: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_739:
	/* 0x739: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_73c:
	/* 0x73c: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_73e:
	/* 0x73e: je     1905 <trace_fd_install+0x1905> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73e, 0x1905, x86_l_1905);
x86_l_744:
	/* 0x744: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_749:
	/* 0x749: mov    BYTE PTR [rbp+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_74d:
	/* 0x74d: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_752:
	/* 0x752: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_757:
	/* 0x757: je     227 <trace_fd_install+0x227> */
	X86_SIM_X86_JCC(X86_CC_E, 0x757, 0x227, x86_l_227);
x86_l_75d:
	/* 0x75d: jmp    77e <trace_fd_install+0x77e> */
	X86_SIM_X86_JMP(0x75d, 0x77e, x86_l_77e);
x86_l_75f:
	/* 0x75f: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_767:
	/* 0x767: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_76e:
	/* 0x76e: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_773:
	/* 0x773: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_778:
	/* 0x778: je     227 <trace_fd_install+0x227> */
	X86_SIM_X86_JCC(X86_CC_E, 0x778, 0x227, x86_l_227);
x86_l_77e:
	/* 0x77e: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_783:
	/* 0x783: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_78a:
	/* 0x78a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_78d:
	/* 0x78d: jns    7a7 <trace_fd_install+0x7a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x78d, 0x7a7, x86_l_7a7);
x86_l_78f:
	/* 0x78f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_792:
	/* 0x792: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_795:
	/* 0x795: js     7ae <trace_fd_install+0x7ae> */
	X86_SIM_X86_JCC(X86_CC_S, 0x795, 0x7ae, x86_l_7ae);
x86_l_797:
	/* 0x797: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_799:
	/* 0x799: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_79c:
	/* 0x79c: js     7b6 <trace_fd_install+0x7b6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x79c, 0x7b6, x86_l_7b6);
x86_l_79e:
	/* 0x79e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7a0:
	/* 0x7a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a3:
	/* 0x7a3: js     7be <trace_fd_install+0x7be> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7a3, 0x7be, x86_l_7be);
x86_l_7a5:
	/* 0x7a5: jmp    7d4 <trace_fd_install+0x7d4> */
	X86_SIM_X86_JMP(0x7a5, 0x7d4, x86_l_7d4);
x86_l_7a7:
	/* 0x7a7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7a9:
	/* 0x7a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ac:
	/* 0x7ac: jns    797 <trace_fd_install+0x797> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ac, 0x797, x86_l_797);
x86_l_7ae:
	/* 0x7ae: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b1:
	/* 0x7b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b4:
	/* 0x7b4: jns    79e <trace_fd_install+0x79e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7b4, 0x79e, x86_l_79e);
x86_l_7b6:
	/* 0x7b6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b9:
	/* 0x7b9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7bc:
	/* 0x7bc: jns    7d4 <trace_fd_install+0x7d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7bc, 0x7d4, x86_l_7d4);
x86_l_7be:
	/* 0x7be: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c1:
	/* 0x7c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c4:
	/* 0x7c4: je     7d4 <trace_fd_install+0x7d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7c4, 0x7d4, x86_l_7d4);
x86_l_7c6:
	/* 0x7c6: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_7ca:
	/* 0x7ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7cd:
	/* 0x7cd: jns    7d4 <trace_fd_install+0x7d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7cd, 0x7d4, x86_l_7d4);
x86_l_7cf:
	/* 0x7cf: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7d2:
	/* 0x7d2: jmp    7d6 <trace_fd_install+0x7d6> */
	X86_SIM_X86_JMP(0x7d2, 0x7d6, x86_l_7d6);
x86_l_7d4:
	/* 0x7d4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d6:
	/* 0x7d6: mov    QWORD PTR [r15+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7da:
	/* 0x7da: mov    QWORD PTR [rbp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7de:
	/* 0x7de: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7e2:
	/* 0x7e2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_7e9:
	/* 0x7e9: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_7ee:
	/* 0x7ee: call   7f3 <trace_fd_install+0x7f3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f3:
	/* 0x7f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f6:
	/* 0x7f6: je     80e <trace_fd_install+0x80e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f6, 0x80e, x86_l_80e);
x86_l_7f8:
	/* 0x7f8: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_7fb:
	/* 0x7fb: mov    BYTE PTR [rbp+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_801:
	/* 0x801: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_804:
	/* 0x804: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_807:
	/* 0x807: jne    80e <trace_fd_install+0x80e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x807, 0x80e, x86_l_80e);
x86_l_809:
	/* 0x809: or     BYTE PTR [r15+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_80e:
	/* 0x80e: movzx  eax,WORD PTR [r15+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_813:
	/* 0x813: cmp    ax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R13, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_818:
	/* 0x818: jne    1613 <trace_fd_install+0x1613> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x818, 0x1613, x86_l_1613);
x86_l_81e:
	/* 0x81e: mov    QWORD PTR [r15+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_829:
	/* 0x829: mov    DWORD PTR [rsp+0x30],0x308 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430984ULL);
x86_l_831:
	/* 0x831: mov    WORD PTR [rsp+0x2c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_836:
	/* 0x836: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_83d:
	/* 0x83d: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_842:
	/* 0x842: call   847 <trace_fd_install+0x847> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_847:
	/* 0x847: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_84a:
	/* 0x84a: je     8b5 <trace_fd_install+0x8b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x84a, 0x8b5, x86_l_8b5);
x86_l_84c:
	/* 0x84c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_851:
	/* 0x851: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_854:
	/* 0x854: call   859 <trace_fd_install+0x859> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_859:
	/* 0x859: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85c:
	/* 0x85c: je     8b5 <trace_fd_install+0x8b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85c, 0x8b5, x86_l_8b5);
x86_l_85e:
	/* 0x85e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_862:
	/* 0x862: mov    QWORD PTR [r15+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_869:
	/* 0x869: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86c:
	/* 0x86c: mov    QWORD PTR [r15+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_873:
	/* 0x873: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_877:
	/* 0x877: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_87b:
	/* 0x87b: mov    QWORD PTR [r15+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_882:
	/* 0x882: mov    QWORD PTR [r15+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_889:
	/* 0x889: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_88d:
	/* 0x88d: mov    QWORD PTR [r15+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_894:
	/* 0x894: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_898:
	/* 0x898: mov    QWORD PTR [r15+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_89f:
	/* 0x89f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8a3:
	/* 0x8a3: mov    QWORD PTR [r15+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_8aa:
	/* 0x8aa: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8ae:
	/* 0x8ae: mov    QWORD PTR [r15+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_8b5:
	/* 0x8b5: mov    rax,QWORD PTR [r15+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_8bc:
	/* 0x8bc: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8c3:
	/* 0x8c3: mov    ecx,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8c7:
	/* 0x8c7: cmp    ecx,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_8cb:
	/* 0x8cb: jne    8e5 <trace_fd_install+0x8e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8cb, 0x8e5, x86_l_8e5);
x86_l_8cd:
	/* 0x8cd: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8d0:
	/* 0x8d0: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8d3:
	/* 0x8d3: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8da:
	/* 0x8da: jne    1163 <trace_fd_install+0x1163> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8da, 0x1163, x86_l_1163);
x86_l_8e0:
	/* 0x8e0: jmp    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JMP(0x8e0, 0x2a32, x86_l_2a32);
x86_l_8e5:
	/* 0x8e5: mov    rax,QWORD PTR [r15+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_8ec:
	/* 0x8ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ef:
	/* 0x8ef: je     a8d <trace_fd_install+0xa8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ef, 0xa8d, x86_l_a8d);
x86_l_8f5:
	/* 0x8f5: movzx  ecx,BYTE PTR [rbp+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_8fc:
	/* 0x8fc: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_8ff:
	/* 0x8ff: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_902:
	/* 0x902: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_905:
	/* 0x905: sete   r13b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_909:
	/* 0x909: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_90c:
	/* 0x90c: neg    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_90f:
	/* 0x90f: xor    r13,QWORD PTR [r15+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_916:
	/* 0x916: or     r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_919:
	/* 0x919: mov    rax,QWORD PTR [r15+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_920:
	/* 0x920: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_923:
	/* 0x923: je     944 <trace_fd_install+0x944> */
	X86_SIM_X86_JCC(X86_CC_E, 0x923, 0x944, x86_l_944);
x86_l_925:
	/* 0x925: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_927:
	/* 0x927: cmp    BYTE PTR [rbp+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_92e:
	/* 0x92e: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_931:
	/* 0x931: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_934:
	/* 0x934: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_937:
	/* 0x937: xor    rcx,QWORD PTR [r15+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_93e:
	/* 0x93e: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_941:
	/* 0x941: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_944:
	/* 0x944: mov    rax,QWORD PTR [r15+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_94b:
	/* 0x94b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_94e:
	/* 0x94e: je     96a <trace_fd_install+0x96a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94e, 0x96a, x86_l_96a);
x86_l_950:
	/* 0x950: mov    ecx,DWORD PTR [r15+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_954:
	/* 0x954: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_957:
	/* 0x957: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_95a:
	/* 0x95a: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_95d:
	/* 0x95d: xor    rcx,QWORD PTR [r15+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_964:
	/* 0x964: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_967:
	/* 0x967: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_96a:
	/* 0x96a: mov    rax,QWORD PTR [r15+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_971:
	/* 0x971: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_974:
	/* 0x974: mov    QWORD PTR [rsp+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_979:
	/* 0x979: je     99a <trace_fd_install+0x99a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x979, 0x99a, x86_l_99a);
x86_l_97b:
	/* 0x97b: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_97e:
	/* 0x97e: mov    rcx,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_986:
	/* 0x986: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_98a:
	/* 0x98a: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_98d:
	/* 0x98d: xor    rcx,QWORD PTR [r15+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_994:
	/* 0x994: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_997:
	/* 0x997: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_99a:
	/* 0x99a: movzx  eax,WORD PTR [r15+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_99f:
	/* 0x99f: mov    r14,QWORD PTR [r15+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_9a6:
	/* 0x9a6: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_9a9:
	/* 0x9a9: mov    WORD PTR [rsp+0x20],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9ae:
	/* 0x9ae: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9b3:
	/* 0x9b3: je     afd <trace_fd_install+0xafd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b3, 0xafd, x86_l_afd);
x86_l_9b9:
	/* 0x9b9: mov    QWORD PTR [rsp+0x98],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_9c1:
	/* 0x9c1: mov    rcx,QWORD PTR [r15+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_9c8:
	/* 0x9c8: mov    QWORD PTR [rsp+0xa0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_9d0:
	/* 0x9d0: mov    rbx,QWORD PTR [r15+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_9d7:
	/* 0x9d7: mov    rcx,QWORD PTR [r15+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_9de:
	/* 0x9de: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_9e3:
	/* 0x9e3: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_9e8:
	/* 0x9e8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_9ef:
	/* 0x9ef: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_9f4:
	/* 0x9f4: call   9f9 <trace_fd_install+0x9f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9f9:
	/* 0x9f9: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9fc:
	/* 0x9fc: mov    eax,DWORD PTR [r15+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_a00:
	/* 0xa00: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a05:
	/* 0xa05: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a0c:
	/* 0xa0c: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a0f:
	/* 0xa0f: je     a2f <trace_fd_install+0xa2f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa0f, 0xa2f, x86_l_a2f);
x86_l_a11:
	/* 0xa11: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a16:
	/* 0xa16: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a19:
	/* 0xa19: call   a1e <trace_fd_install+0xa1e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a1e:
	/* 0xa1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a21:
	/* 0xa21: je     a2f <trace_fd_install+0xa2f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa21, 0xa2f, x86_l_a2f);
x86_l_a23:
	/* 0xa23: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a26:
	/* 0xa26: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a2a:
	/* 0xa2a: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a2d:
	/* 0xa2d: jmp    a32 <trace_fd_install+0xa32> */
	X86_SIM_X86_JMP(0xa2d, 0xa32, x86_l_a32);
x86_l_a2f:
	/* 0xa2f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a32:
	/* 0xa32: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_a37:
	/* 0xa37: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a3c:
	/* 0xa3c: dec    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_a3f:
	/* 0xa3f: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a42:
	/* 0xa42: jb     a5a <trace_fd_install+0xa5a> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa42, 0xa5a, x86_l_a5a);
x86_l_a44:
	/* 0xa44: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a48:
	/* 0xa48: je     a4f <trace_fd_install+0xa4f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa48, 0xa4f, x86_l_a4f);
x86_l_a4a:
	/* 0xa4a: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_a4d:
	/* 0xa4d: jbe    a5a <trace_fd_install+0xa5a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa4d, 0xa5a, x86_l_a5a);
x86_l_a4f:
	/* 0xa4f: and    rbp,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 160ULL);
x86_l_a57:
	/* 0xa57: or     r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a5a:
	/* 0xa5a: mov    eax,DWORD PTR [r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_a5e:
	/* 0xa5e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a63:
	/* 0xa63: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a6a:
	/* 0xa6a: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a6d:
	/* 0xa6d: je     aa9 <trace_fd_install+0xaa9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa6d, 0xaa9, x86_l_aa9);
x86_l_a6f:
	/* 0xa6f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a74:
	/* 0xa74: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a77:
	/* 0xa77: call   a7c <trace_fd_install+0xa7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a7c:
	/* 0xa7c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a7f:
	/* 0xa7f: je     ac2 <trace_fd_install+0xac2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7f, 0xac2, x86_l_ac2);
x86_l_a81:
	/* 0xa81: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a84:
	/* 0xa84: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a88:
	/* 0xa88: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a8b:
	/* 0xa8b: jmp    ac4 <trace_fd_install+0xac4> */
	X86_SIM_X86_JMP(0xa8b, 0xac4, x86_l_ac4);
x86_l_a8d:
	/* 0xa8d: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a94:
	/* 0xa94: mov    rax,QWORD PTR [r15+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_a9b:
	/* 0xa9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a9e:
	/* 0xa9e: jne    925 <trace_fd_install+0x925> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa9e, 0x925, x86_l_925);
x86_l_aa4:
	/* 0xaa4: jmp    944 <trace_fd_install+0x944> */
	X86_SIM_X86_JMP(0xaa4, 0x944, x86_l_944);
x86_l_aa9:
	/* 0xaa9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aab:
	/* 0xaab: mov    r13,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_ab3:
	/* 0xab3: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ab6:
	/* 0xab6: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_abb:
	/* 0xabb: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_abe:
	/* 0xabe: jae    ade <trace_fd_install+0xade> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xabe, 0xade, x86_l_ade);
x86_l_ac0:
	/* 0xac0: jmp    af4 <trace_fd_install+0xaf4> */
	X86_SIM_X86_JMP(0xac0, 0xaf4, x86_l_af4);
x86_l_ac2:
	/* 0xac2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ac4:
	/* 0xac4: mov    r13,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_acc:
	/* 0xacc: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_ad1:
	/* 0xad1: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ad4:
	/* 0xad4: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ad9:
	/* 0xad9: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adc:
	/* 0xadc: jb     af4 <trace_fd_install+0xaf4> */
	X86_SIM_X86_JCC(X86_CC_B, 0xadc, 0xaf4, x86_l_af4);
x86_l_ade:
	/* 0xade: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ae2:
	/* 0xae2: je     ae9 <trace_fd_install+0xae9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae2, 0xae9, x86_l_ae9);
x86_l_ae4:
	/* 0xae4: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ae7:
	/* 0xae7: jbe    af4 <trace_fd_install+0xaf4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xae7, 0xaf4, x86_l_af4);
x86_l_ae9:
	/* 0xae9: and    rbp,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 160ULL);
x86_l_af1:
	/* 0xaf1: or     rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_af4:
	/* 0xaf4: or     r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_af7:
	/* 0xaf7: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_afa:
	/* 0xafa: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_afd:
	/* 0xafd: cmp    QWORD PTR [r15+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_b05:
	/* 0xb05: je     b9d <trace_fd_install+0xb9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb05, 0xb9d, x86_l_b9d);
x86_l_b0b:
	/* 0xb0b: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b0e:
	/* 0xb0e: call   b13 <trace_fd_install+0xb13> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_b13:
	/* 0xb13: mov    DWORD PTR [r15+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b17:
	/* 0xb17: mov    rbx,QWORD PTR [r15+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_b1e:
	/* 0xb1e: mov    rax,QWORD PTR [r15+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_b25:
	/* 0xb25: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_b2a:
	/* 0xb2a: mov    r13,QWORD PTR [r15+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_b31:
	/* 0xb31: mov    r12,QWORD PTR [r15+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_b38:
	/* 0xb38: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_b3d:
	/* 0xb3d: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b42:
	/* 0xb42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_b49:
	/* 0xb49: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b4e:
	/* 0xb4e: call   b53 <trace_fd_install+0xb53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b53:
	/* 0xb53: mov    ecx,DWORD PTR [r15+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b57:
	/* 0xb57: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b5c:
	/* 0xb5c: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b63:
	/* 0xb63: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b66:
	/* 0xb66: je     b86 <trace_fd_install+0xb86> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb66, 0xb86, x86_l_b86);
x86_l_b68:
	/* 0xb68: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b6d:
	/* 0xb6d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b70:
	/* 0xb70: call   b75 <trace_fd_install+0xb75> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b75:
	/* 0xb75: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b78:
	/* 0xb78: je     b86 <trace_fd_install+0xb86> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb78, 0xb86, x86_l_b86);
x86_l_b7a:
	/* 0xb7a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b7d:
	/* 0xb7d: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b81:
	/* 0xb81: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b84:
	/* 0xb84: jmp    b88 <trace_fd_install+0xb88> */
	X86_SIM_X86_JMP(0xb84, 0xb88, x86_l_b88);
x86_l_b86:
	/* 0xb86: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b88:
	/* 0xb88: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b8b:
	/* 0xb8b: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b90:
	/* 0xb90: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_b93:
	/* 0xb93: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b96:
	/* 0xb96: jae    bb1 <trace_fd_install+0xbb1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb96, 0xbb1, x86_l_bb1);
x86_l_b98:
	/* 0xb98: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b9b:
	/* 0xb9b: jmp    bc7 <trace_fd_install+0xbc7> */
	X86_SIM_X86_JMP(0xb9b, 0xbc7, x86_l_bc7);
x86_l_b9d:
	/* 0xb9d: movzx  ebp,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_ba2:
	/* 0xba2: cmp    QWORD PTR [r15+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_baa:
	/* 0xbaa: jne    be0 <trace_fd_install+0xbe0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbaa, 0xbe0, x86_l_be0);
x86_l_bac:
	/* 0xbac: jmp    c78 <trace_fd_install+0xc78> */
	X86_SIM_X86_JMP(0xbac, 0xc78, x86_l_c78);
x86_l_bb1:
	/* 0xbb1: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bb5:
	/* 0xbb5: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_bb8:
	/* 0xbb8: je     bbf <trace_fd_install+0xbbf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb8, 0xbbf, x86_l_bbf);
x86_l_bba:
	/* 0xbba: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_bbd:
	/* 0xbbd: jbe    bc7 <trace_fd_install+0xbc7> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xbbd, 0xbc7, x86_l_bc7);
x86_l_bbf:
	/* 0xbbf: and    r14,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 120ULL);
x86_l_bc4:
	/* 0xbc4: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bc7:
	/* 0xbc7: movzx  ebp,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_bcc:
	/* 0xbcc: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bcf:
	/* 0xbcf: and    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bd2:
	/* 0xbd2: cmp    QWORD PTR [r15+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_bda:
	/* 0xbda: je     c78 <trace_fd_install+0xc78> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbda, 0xc78, x86_l_c78);
x86_l_be0:
	/* 0xbe0: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_be5:
	/* 0xbe5: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_bec:
	/* 0xbec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bef:
	/* 0xbef: jns    bf6 <trace_fd_install+0xbf6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbef, 0xbf6, x86_l_bf6);
x86_l_bf1:
	/* 0xbf1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf4:
	/* 0xbf4: jmp    bf8 <trace_fd_install+0xbf8> */
	X86_SIM_X86_JMP(0xbf4, 0xbf8, x86_l_bf8);
x86_l_bf6:
	/* 0xbf6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bf8:
	/* 0xbf8: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_bfc:
	/* 0xbfc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bfe:
	/* 0xbfe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c01:
	/* 0xc01: jns    c0d <trace_fd_install+0xc0d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc01, 0xc0d, x86_l_c0d);
x86_l_c03:
	/* 0xc03: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c06:
	/* 0xc06: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c09:
	/* 0xc09: js     c14 <trace_fd_install+0xc14> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc09, 0xc14, x86_l_c14);
x86_l_c0b:
	/* 0xc0b: jmp    c16 <trace_fd_install+0xc16> */
	X86_SIM_X86_JMP(0xc0b, 0xc16, x86_l_c16);
x86_l_c0d:
	/* 0xc0d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c0f:
	/* 0xc0f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c12:
	/* 0xc12: jns    c16 <trace_fd_install+0xc16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc12, 0xc16, x86_l_c16);
x86_l_c14:
	/* 0xc14: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c16:
	/* 0xc16: mov    DWORD PTR [r15+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_c1a:
	/* 0xc1a: mov    rbx,QWORD PTR [r15+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_c21:
	/* 0xc21: mov    r14,QWORD PTR [r15+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_c28:
	/* 0xc28: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c2b:
	/* 0xc2b: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c30:
	/* 0xc30: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_c37:
	/* 0xc37: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c3c:
	/* 0xc3c: call   c41 <trace_fd_install+0xc41> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c41:
	/* 0xc41: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c48:
	/* 0xc48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c4b:
	/* 0xc4b: je     c6a <trace_fd_install+0xc6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc4b, 0xc6a, x86_l_c6a);
x86_l_c4d:
	/* 0xc4d: lea    rsi,[r15+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_c51:
	/* 0xc51: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c54:
	/* 0xc54: call   c59 <trace_fd_install+0xc59> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c59:
	/* 0xc59: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c5c:
	/* 0xc5c: je     c6a <trace_fd_install+0xc6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc5c, 0xc6a, x86_l_c6a);
x86_l_c5e:
	/* 0xc5e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c61:
	/* 0xc61: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c65:
	/* 0xc65: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c68:
	/* 0xc68: jmp    c6c <trace_fd_install+0xc6c> */
	X86_SIM_X86_JMP(0xc68, 0xc6c, x86_l_c6c);
x86_l_c6a:
	/* 0xc6a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c6c:
	/* 0xc6c: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c6f:
	/* 0xc6f: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c72:
	/* 0xc72: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c75:
	/* 0xc75: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c78:
	/* 0xc78: cmp    QWORD PTR [r15+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_c80:
	/* 0xc80: je     d42 <trace_fd_install+0xd42> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc80, 0xd42, x86_l_d42);
x86_l_c86:
	/* 0xc86: mov    rcx,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_c8d:
	/* 0xc8d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c91:
	/* 0xc91: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c93:
	/* 0xc93: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c96:
	/* 0xc96: jns    ca5 <trace_fd_install+0xca5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc96, 0xca5, x86_l_ca5);
x86_l_c98:
	/* 0xc98: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9b:
	/* 0xc9b: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c9e:
	/* 0xc9e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ca1:
	/* 0xca1: js     caf <trace_fd_install+0xcaf> */
	X86_SIM_X86_JCC(X86_CC_S, 0xca1, 0xcaf, x86_l_caf);
x86_l_ca3:
	/* 0xca3: jmp    cb1 <trace_fd_install+0xcb1> */
	X86_SIM_X86_JMP(0xca3, 0xcb1, x86_l_cb1);
x86_l_ca5:
	/* 0xca5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ca7:
	/* 0xca7: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_caa:
	/* 0xcaa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cad:
	/* 0xcad: jns    cb1 <trace_fd_install+0xcb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcad, 0xcb1, x86_l_cb1);
x86_l_caf:
	/* 0xcaf: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cb1:
	/* 0xcb1: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_cb3:
	/* 0xcb3: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_cb7:
	/* 0xcb7: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_cba:
	/* 0xcba: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_cbe:
	/* 0xcbe: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cc0:
	/* 0xcc0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cc3:
	/* 0xcc3: jns    cd3 <trace_fd_install+0xcd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcc3, 0xcd3, x86_l_cd3);
x86_l_cc5:
	/* 0xcc5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc8:
	/* 0xcc8: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_ccc:
	/* 0xccc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ccf:
	/* 0xccf: js     cde <trace_fd_install+0xcde> */
	X86_SIM_X86_JCC(X86_CC_S, 0xccf, 0xcde, x86_l_cde);
x86_l_cd1:
	/* 0xcd1: jmp    ce0 <trace_fd_install+0xce0> */
	X86_SIM_X86_JMP(0xcd1, 0xce0, x86_l_ce0);
x86_l_cd3:
	/* 0xcd3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cd5:
	/* 0xcd5: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_cd9:
	/* 0xcd9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cdc:
	/* 0xcdc: jns    ce0 <trace_fd_install+0xce0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcdc, 0xce0, x86_l_ce0);
x86_l_cde:
	/* 0xcde: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce0:
	/* 0xce0: mov    DWORD PTR [r15+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ce4:
	/* 0xce4: mov    rbx,QWORD PTR [r15+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_ceb:
	/* 0xceb: mov    r14,QWORD PTR [r15+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_cf2:
	/* 0xcf2: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_cf5:
	/* 0xcf5: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cfa:
	/* 0xcfa: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_d01:
	/* 0xd01: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d06:
	/* 0xd06: call   d0b <trace_fd_install+0xd0b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d0b:
	/* 0xd0b: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_d12:
	/* 0xd12: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d15:
	/* 0xd15: je     d34 <trace_fd_install+0xd34> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd15, 0xd34, x86_l_d34);
x86_l_d17:
	/* 0xd17: lea    rsi,[r15+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d1b:
	/* 0xd1b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d1e:
	/* 0xd1e: call   d23 <trace_fd_install+0xd23> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d23:
	/* 0xd23: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d26:
	/* 0xd26: je     d34 <trace_fd_install+0xd34> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd26, 0xd34, x86_l_d34);
x86_l_d28:
	/* 0xd28: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d2b:
	/* 0xd2b: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d2f:
	/* 0xd2f: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_d32:
	/* 0xd32: jmp    d36 <trace_fd_install+0xd36> */
	X86_SIM_X86_JMP(0xd32, 0xd36, x86_l_d36);
x86_l_d34:
	/* 0xd34: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d36:
	/* 0xd36: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_d39:
	/* 0xd39: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d3c:
	/* 0xd3c: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_d3f:
	/* 0xd3f: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d42:
	/* 0xd42: cmp    QWORD PTR [r15+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_d4a:
	/* 0xd4a: je     f30 <trace_fd_install+0xf30> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd4a, 0xf30, x86_l_f30);
x86_l_d50:
	/* 0xd50: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_d55:
	/* 0xd55: add    rax,QWORD PTR [r15+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_d5c:
	/* 0xd5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d5f:
	/* 0xd5f: jns    d75 <trace_fd_install+0xd75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd5f, 0xd75, x86_l_d75);
x86_l_d61:
	/* 0xd61: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d64:
	/* 0xd64: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d67:
	/* 0xd67: js     d7c <trace_fd_install+0xd7c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd67, 0xd7c, x86_l_d7c);
x86_l_d69:
	/* 0xd69: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d6b:
	/* 0xd6b: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d6e:
	/* 0xd6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d71:
	/* 0xd71: js     d87 <trace_fd_install+0xd87> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd71, 0xd87, x86_l_d87);
x86_l_d73:
	/* 0xd73: jmp    dd2 <trace_fd_install+0xdd2> */
	X86_SIM_X86_JMP(0xd73, 0xdd2, x86_l_dd2);
x86_l_d75:
	/* 0xd75: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d77:
	/* 0xd77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d7a:
	/* 0xd7a: jns    d69 <trace_fd_install+0xd69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd7a, 0xd69, x86_l_d69);
x86_l_d7c:
	/* 0xd7c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d7f:
	/* 0xd7f: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d82:
	/* 0xd82: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d85:
	/* 0xd85: jns    dd2 <trace_fd_install+0xdd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd85, 0xdd2, x86_l_dd2);
x86_l_d87:
	/* 0xd87: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d8a:
	/* 0xd8a: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d8f:
	/* 0xd8f: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d93:
	/* 0xd93: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d98:
	/* 0xd98: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d9c:
	/* 0xd9c: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_da1:
	/* 0xda1: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_da5:
	/* 0xda5: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_daa:
	/* 0xdaa: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_dae:
	/* 0xdae: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_db3:
	/* 0xdb3: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_db7:
	/* 0xdb7: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_dbc:
	/* 0xdbc: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_dc0:
	/* 0xdc0: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_dc5:
	/* 0xdc5: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_dc9:
	/* 0xdc9: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_dce:
	/* 0xdce: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_dd2:
	/* 0xdd2: lea    r13,[r15+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_dd6:
	/* 0xdd6: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ddb:
	/* 0xddb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dde:
	/* 0xdde: jns    eb6 <trace_fd_install+0xeb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdde, 0xeb6, x86_l_eb6);
x86_l_de4:
	/* 0xde4: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_de7:
	/* 0xde7: mov    BYTE PTR [r13+0x0],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_deb:
	/* 0xdeb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ded:
	/* 0xded: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xded, 0xec6, x86_l_ec6);
x86_l_df3:
	/* 0xdf3: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_df7:
	/* 0xdf7: mov    BYTE PTR [r15+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_dfb:
	/* 0xdfb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_dfd:
	/* 0xdfd: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdfd, 0xec6, x86_l_ec6);
x86_l_e03:
	/* 0xe03: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_e07:
	/* 0xe07: mov    BYTE PTR [r15+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_e0b:
	/* 0xe0b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e0d:
	/* 0xe0d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe0d, 0xec6, x86_l_ec6);
x86_l_e13:
	/* 0xe13: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_e17:
	/* 0xe17: mov    BYTE PTR [r15+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_e1b:
	/* 0xe1b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e1d:
	/* 0xe1d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe1d, 0xec6, x86_l_ec6);
x86_l_e23:
	/* 0xe23: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_e27:
	/* 0xe27: mov    BYTE PTR [r15+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_e2b:
	/* 0xe2b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e2d:
	/* 0xe2d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe2d, 0xec6, x86_l_ec6);
x86_l_e33:
	/* 0xe33: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_e37:
	/* 0xe37: mov    BYTE PTR [r15+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_e3b:
	/* 0xe3b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e3d:
	/* 0xe3d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe3d, 0xec6, x86_l_ec6);
x86_l_e43:
	/* 0xe43: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_e47:
	/* 0xe47: mov    BYTE PTR [r15+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_e4b:
	/* 0xe4b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e4d:
	/* 0xe4d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4d, 0xec6, x86_l_ec6);
x86_l_e4f:
	/* 0xe4f: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_e53:
	/* 0xe53: mov    BYTE PTR [r15+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_e57:
	/* 0xe57: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e59:
	/* 0xe59: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe59, 0xec6, x86_l_ec6);
x86_l_e5b:
	/* 0xe5b: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_e5f:
	/* 0xe5f: mov    BYTE PTR [r15+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_e63:
	/* 0xe63: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e65:
	/* 0xe65: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe65, 0xec6, x86_l_ec6);
x86_l_e67:
	/* 0xe67: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_e6b:
	/* 0xe6b: mov    BYTE PTR [r15+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_e6f:
	/* 0xe6f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e71:
	/* 0xe71: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe71, 0xec6, x86_l_ec6);
x86_l_e73:
	/* 0xe73: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_e77:
	/* 0xe77: mov    BYTE PTR [r15+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_e7b:
	/* 0xe7b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e7d:
	/* 0xe7d: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe7d, 0xec6, x86_l_ec6);
x86_l_e7f:
	/* 0xe7f: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_e83:
	/* 0xe83: mov    BYTE PTR [r15+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_e87:
	/* 0xe87: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e89:
	/* 0xe89: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe89, 0xec6, x86_l_ec6);
x86_l_e8b:
	/* 0xe8b: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_e8f:
	/* 0xe8f: mov    BYTE PTR [r15+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_e93:
	/* 0xe93: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e95:
	/* 0xe95: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe95, 0xec6, x86_l_ec6);
x86_l_e97:
	/* 0xe97: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_e9b:
	/* 0xe9b: mov    BYTE PTR [r15+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_e9f:
	/* 0xe9f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ea1:
	/* 0xea1: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xea1, 0xec6, x86_l_ec6);
x86_l_ea3:
	/* 0xea3: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_ea7:
	/* 0xea7: mov    BYTE PTR [r15+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_eab:
	/* 0xeab: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_ead:
	/* 0xead: je     ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xead, 0xec6, x86_l_ec6);
x86_l_eaf:
	/* 0xeaf: mov    BYTE PTR [r15+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_eb4:
	/* 0xeb4: jmp    ec6 <trace_fd_install+0xec6> */
	X86_SIM_X86_JMP(0xeb4, 0xec6, x86_l_ec6);
x86_l_eb6:
	/* 0xeb6: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_ebe:
	/* 0xebe: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ec6:
	/* 0xec6: mov    rbx,QWORD PTR [r15+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_ecd:
	/* 0xecd: mov    r14,QWORD PTR [r15+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_ed4:
	/* 0xed4: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ed7:
	/* 0xed7: movzx  eax,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_edc:
	/* 0xedc: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ee1:
	/* 0xee1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_ee8:
	/* 0xee8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_eed:
	/* 0xeed: call   ef2 <trace_fd_install+0xef2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ef2:
	/* 0xef2: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ef9:
	/* 0xef9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_efc:
	/* 0xefc: je     f1a <trace_fd_install+0xf1a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xefc, 0xf1a, x86_l_f1a);
x86_l_efe:
	/* 0xefe: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f01:
	/* 0xf01: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f04:
	/* 0xf04: call   f09 <trace_fd_install+0xf09> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f09:
	/* 0xf09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f0c:
	/* 0xf0c: je     f1a <trace_fd_install+0xf1a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf0c, 0xf1a, x86_l_f1a);
x86_l_f0e:
	/* 0xf0e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f11:
	/* 0xf11: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f15:
	/* 0xf15: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f18:
	/* 0xf18: jmp    f1c <trace_fd_install+0xf1c> */
	X86_SIM_X86_JMP(0xf18, 0xf1c, x86_l_f1c);
x86_l_f1a:
	/* 0xf1a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f1c:
	/* 0xf1c: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f1f:
	/* 0xf1f: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f22:
	/* 0xf22: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f25:
	/* 0xf25: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f28:
	/* 0xf28: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f2b:
	/* 0xf2b: movzx  ebp,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_f30:
	/* 0xf30: cmp    QWORD PTR [r15+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_f38:
	/* 0xf38: je     fbb <trace_fd_install+0xfbb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf38, 0xfbb, x86_l_fbb);
x86_l_f3e:
	/* 0xf3e: mov    r12d,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_f41:
	/* 0xf41: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f44:
	/* 0xf44: lea    r13,[r15+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_f48:
	/* 0xf48: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f4b:
	/* 0xf4b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_f50:
	/* 0xf50: call   f55 <trace_fd_install+0xf55> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_f55:
	/* 0xf55: mov    rbx,QWORD PTR [r15+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_f5c:
	/* 0xf5c: mov    r14,QWORD PTR [r15+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_f63:
	/* 0xf63: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f66:
	/* 0xf66: mov    WORD PTR [rsp+0x30],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f6c:
	/* 0xf6c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_f73:
	/* 0xf73: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f78:
	/* 0xf78: call   f7d <trace_fd_install+0xf7d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f7d:
	/* 0xf7d: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_f84:
	/* 0xf84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f87:
	/* 0xf87: je     fa5 <trace_fd_install+0xfa5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf87, 0xfa5, x86_l_fa5);
x86_l_f89:
	/* 0xf89: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f8c:
	/* 0xf8c: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_f8f:
	/* 0xf8f: call   f94 <trace_fd_install+0xf94> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f94:
	/* 0xf94: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f97:
	/* 0xf97: je     fa5 <trace_fd_install+0xfa5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf97, 0xfa5, x86_l_fa5);
x86_l_f99:
	/* 0xf99: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f9c:
	/* 0xf9c: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa0:
	/* 0xfa0: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fa3:
	/* 0xfa3: jmp    fa7 <trace_fd_install+0xfa7> */
	X86_SIM_X86_JMP(0xfa3, 0xfa7, x86_l_fa7);
x86_l_fa5:
	/* 0xfa5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa7:
	/* 0xfa7: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_faa:
	/* 0xfaa: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fad:
	/* 0xfad: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fb0:
	/* 0xfb0: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_fb3:
	/* 0xfb3: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_fb6:
	/* 0xfb6: movzx  ebp,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_fbb:
	/* 0xfbb: mov    rbx,QWORD PTR [r15+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_fc2:
	/* 0xfc2: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fc5:
	/* 0xfc5: je     1027 <trace_fd_install+0x1027> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc5, 0x1027, x86_l_1027);
x86_l_fc7:
	/* 0xfc7: mov    eax,DWORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fcb:
	/* 0xfcb: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fcf:
	/* 0xfcf: mov    r14,QWORD PTR [r15+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_fd6:
	/* 0xfd6: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fd9:
	/* 0xfd9: mov    WORD PTR [rsp+0x14],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_fde:
	/* 0xfde: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_fe5:
	/* 0xfe5: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_fea:
	/* 0xfea: call   fef <trace_fd_install+0xfef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fef:
	/* 0xfef: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ff6:
	/* 0xff6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ff9:
	/* 0xff9: je     1019 <trace_fd_install+0x1019> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff9, 0x1019, x86_l_1019);
x86_l_ffb:
	/* 0xffb: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1000:
	/* 0x1000: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1003:
	/* 0x1003: call   1008 <trace_fd_install+0x1008> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1008:
	/* 0x1008: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_100b:
	/* 0x100b: je     1019 <trace_fd_install+0x1019> */
	X86_SIM_X86_JCC(X86_CC_E, 0x100b, 0x1019, x86_l_1019);
x86_l_100d:
	/* 0x100d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1010:
	/* 0x1010: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1014:
	/* 0x1014: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1017:
	/* 0x1017: jmp    101b <trace_fd_install+0x101b> */
	X86_SIM_X86_JMP(0x1017, 0x101b, x86_l_101b);
x86_l_1019:
	/* 0x1019: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_101b:
	/* 0x101b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_101e:
	/* 0x101e: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1021:
	/* 0x1021: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1024:
	/* 0x1024: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1027:
	/* 0x1027: mov    rbx,QWORD PTR [r15+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_102e:
	/* 0x102e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1031:
	/* 0x1031: je     108d <trace_fd_install+0x108d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1031, 0x108d, x86_l_108d);
x86_l_1033:
	/* 0x1033: mov    r14,QWORD PTR [r15+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_103a:
	/* 0x103a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_103d:
	/* 0x103d: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1042:
	/* 0x1042: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_1049:
	/* 0x1049: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_104e:
	/* 0x104e: call   1053 <trace_fd_install+0x1053> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1053:
	/* 0x1053: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_105a:
	/* 0x105a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_105d:
	/* 0x105d: je     107f <trace_fd_install+0x107f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x105d, 0x107f, x86_l_107f);
x86_l_105f:
	/* 0x105f: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1062:
	/* 0x1062: add    rsi,0x24 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 36ULL);
x86_l_1066:
	/* 0x1066: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1069:
	/* 0x1069: call   106e <trace_fd_install+0x106e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_106e:
	/* 0x106e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1071:
	/* 0x1071: je     107f <trace_fd_install+0x107f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1071, 0x107f, x86_l_107f);
x86_l_1073:
	/* 0x1073: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1076:
	/* 0x1076: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_107a:
	/* 0x107a: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_107d:
	/* 0x107d: jmp    1081 <trace_fd_install+0x1081> */
	X86_SIM_X86_JMP(0x107d, 0x1081, x86_l_1081);
x86_l_107f:
	/* 0x107f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1081:
	/* 0x1081: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1084:
	/* 0x1084: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1087:
	/* 0x1087: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_108a:
	/* 0x108a: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_108d:
	/* 0x108d: mov    rbx,QWORD PTR [r15+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_1094:
	/* 0x1094: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1097:
	/* 0x1097: je     1120 <trace_fd_install+0x1120> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1097, 0x1120, x86_l_1120);
x86_l_109d:
	/* 0x109d: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_109f:
	/* 0x109f: mov    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10a2:
	/* 0x10a2: mov    r14,QWORD PTR [r15+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_10a9:
	/* 0x10a9: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_10ac:
	/* 0x10ac: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10b1:
	/* 0x10b1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_10b8:
	/* 0x10b8: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10bd:
	/* 0x10bd: call   10c2 <trace_fd_install+0x10c2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10c2:
	/* 0x10c2: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_10c9:
	/* 0x10c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10cc:
	/* 0x10cc: je     110f <trace_fd_install+0x110f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10cc, 0x110f, x86_l_110f);
x86_l_10ce:
	/* 0x10ce: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10d1:
	/* 0x10d1: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_10d9:
	/* 0x10d9: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_10dd:
	/* 0x10dd: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10e0:
	/* 0x10e0: call   10e5 <trace_fd_install+0x10e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10e5:
	/* 0x10e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e8:
	/* 0x10e8: jne    1103 <trace_fd_install+0x1103> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10e8, 0x1103, x86_l_1103);
x86_l_10ea:
	/* 0x10ea: mov    rax,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_10f2:
	/* 0x10f2: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10f6:
	/* 0x10f6: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10f9:
	/* 0x10f9: call   10fe <trace_fd_install+0x10fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10fe:
	/* 0x10fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1101:
	/* 0x1101: je     110f <trace_fd_install+0x110f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1101, 0x110f, x86_l_110f);
x86_l_1103:
	/* 0x1103: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1106:
	/* 0x1106: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_110a:
	/* 0x110a: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_110d:
	/* 0x110d: jmp    1111 <trace_fd_install+0x1111> */
	X86_SIM_X86_JMP(0x110d, 0x1111, x86_l_1111);
x86_l_110f:
	/* 0x110f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1111:
	/* 0x1111: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1114:
	/* 0x1114: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1117:
	/* 0x1117: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_111a:
	/* 0x111a: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_111d:
	/* 0x111d: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1120:
	/* 0x1120: mov    rax,QWORD PTR [r15+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1127:
	/* 0x1127: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_112a:
	/* 0x112a: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_112f:
	/* 0x112f: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1134:
	/* 0x1134: je     1145 <trace_fd_install+0x1145> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1134, 0x1145, x86_l_1145);
x86_l_1136:
	/* 0x1136: mov    rcx,QWORD PTR [rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_113e:
	/* 0x113e: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_1142:
	/* 0x1142: or     r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1145:
	/* 0x1145: and    r13,QWORD PTR [r15+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_R15, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_114c:
	/* 0x114c: mov    rax,QWORD PTR [r15+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1153:
	/* 0x1153: and    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1156:
	/* 0x1156: mov    QWORD PTR [r15+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_115d:
	/* 0x115d: je     2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_E, 0x115d, 0x2a32, x86_l_2a32);
x86_l_1163:
	/* 0x1163: mov    rbx,QWORD PTR [r14+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1167:
	/* 0x1167: lea    r14,[rbx+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_116b:
	/* 0x116b: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_116e:
	/* 0x116e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1171:
	/* 0x1171: jns    1180 <trace_fd_install+0x1180> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1171, 0x1180, x86_l_1180);
x86_l_1173:
	/* 0x1173: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1176:
	/* 0x1176: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1179:
	/* 0x1179: js     118b <trace_fd_install+0x118b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1179, 0x118b, x86_l_118b);
x86_l_117b:
	/* 0x117b: jmp    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JMP(0x117b, 0x2a32, x86_l_2a32);
x86_l_1180:
	/* 0x1180: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1182:
	/* 0x1182: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1185:
	/* 0x1185: jns    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1185, 0x2a32, x86_l_2a32);
x86_l_118b:
	/* 0x118b: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_118e:
	/* 0x118e: and    eax,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_1193:
	/* 0x1193: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_1198:
	/* 0x1198: jne    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1198, 0x2a32, x86_l_2a32);
x86_l_119e:
	/* 0x119e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11a1:
	/* 0x11a1: je     11db <trace_fd_install+0x11db> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11a1, 0x11db, x86_l_11db);
x86_l_11a3:
	/* 0x11a3: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_11ab:
	/* 0x11ab: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_11b2:
	/* 0x11b2: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_11b7:
	/* 0x11b7: call   11bc <trace_fd_install+0x11bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11bc:
	/* 0x11bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11bf:
	/* 0x11bf: je     2947 <trace_fd_install+0x2947> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11bf, 0x2947, x86_l_2947);
x86_l_11c5:
	/* 0x11c5: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11c9:
	/* 0x11c9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11cc:
	/* 0x11cc: jns    11e4 <trace_fd_install+0x11e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11cc, 0x11e4, x86_l_11e4);
x86_l_11ce:
	/* 0x11ce: mov    r13,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11d1:
	/* 0x11d1: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_11d4:
	/* 0x11d4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11d7:
	/* 0x11d7: js     11ef <trace_fd_install+0x11ef> */
	X86_SIM_X86_JCC(X86_CC_S, 0x11d7, 0x11ef, x86_l_11ef);
x86_l_11d9:
	/* 0x11d9: jmp    11fa <trace_fd_install+0x11fa> */
	X86_SIM_X86_JMP(0x11d9, 0x11fa, x86_l_11fa);
x86_l_11db:
	/* 0x11db: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11dd:
	/* 0x11dd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11df:
	/* 0x11df: jmp    2a02 <trace_fd_install+0x2a02> */
	X86_SIM_X86_JMP(0x11df, 0x2a02, x86_l_2a02);
x86_l_11e4:
	/* 0x11e4: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11e7:
	/* 0x11e7: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_11ea:
	/* 0x11ea: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11ed:
	/* 0x11ed: jns    11fa <trace_fd_install+0x11fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11ed, 0x11fa, x86_l_11fa);
x86_l_11ef:
	/* 0x11ef: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11f1:
	/* 0x11f1: test   cl,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_11f4:
	/* 0x11f4: jne    12fa <trace_fd_install+0x12fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11f4, 0x12fa, x86_l_12fa);
x86_l_11fa:
	/* 0x11fa: add    rbx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_11fe:
	/* 0x11fe: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1201:
	/* 0x1201: jns    1208 <trace_fd_install+0x1208> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1201, 0x1208, x86_l_1208);
x86_l_1203:
	/* 0x1203: mov    r8,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1206:
	/* 0x1206: jmp    120b <trace_fd_install+0x120b> */
	X86_SIM_X86_JMP(0x1206, 0x120b, x86_l_120b);
x86_l_1208:
	/* 0x1208: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_120b:
	/* 0x120b: lea    rcx,[r8-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_120f:
	/* 0x120f: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1212:
	/* 0x1212: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1215:
	/* 0x1215: jns    1231 <trace_fd_install+0x1231> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1215, 0x1231, x86_l_1231);
x86_l_1217:
	/* 0x1217: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_121a:
	/* 0x121a: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_121d:
	/* 0x121d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1220:
	/* 0x1220: js     123b <trace_fd_install+0x123b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1220, 0x123b, x86_l_123b);
x86_l_1222:
	/* 0x1222: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1224:
	/* 0x1224: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1228:
	/* 0x1228: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_122b:
	/* 0x122b: js     1247 <trace_fd_install+0x1247> */
	X86_SIM_X86_JCC(X86_CC_S, 0x122b, 0x1247, x86_l_1247);
x86_l_122d:
	/* 0x122d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_122f:
	/* 0x122f: jmp    124a <trace_fd_install+0x124a> */
	X86_SIM_X86_JMP(0x122f, 0x124a, x86_l_124a);
x86_l_1231:
	/* 0x1231: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1233:
	/* 0x1233: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1236:
	/* 0x1236: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1239:
	/* 0x1239: jns    1222 <trace_fd_install+0x1222> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1239, 0x1222, x86_l_1222);
x86_l_123b:
	/* 0x123b: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_123e:
	/* 0x123e: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1242:
	/* 0x1242: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1245:
	/* 0x1245: jns    122d <trace_fd_install+0x122d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1245, 0x122d, x86_l_122d);
x86_l_1247:
	/* 0x1247: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_124a:
	/* 0x124a: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_124d:
	/* 0x124d: je     12da <trace_fd_install+0x12da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x124d, 0x12da, x86_l_12da);
x86_l_1253:
	/* 0x1253: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1256:
	/* 0x1256: je     12da <trace_fd_install+0x12da> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1256, 0x12da, x86_l_12da);
x86_l_125c:
	/* 0x125c: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1260:
	/* 0x1260: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1263:
	/* 0x1263: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1269:
	/* 0x1269: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_126c:
	/* 0x126c: jns    1275 <trace_fd_install+0x1275> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x126c, 0x1275, x86_l_1275);
x86_l_126e:
	/* 0x126e: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1271:
	/* 0x1271: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1275:
	/* 0x1275: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1279:
	/* 0x1279: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_127c:
	/* 0x127c: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1283:
	/* 0x1283: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1286:
	/* 0x1286: je     1564 <trace_fd_install+0x1564> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1286, 0x1564, x86_l_1564);
x86_l_128c:
	/* 0x128c: mov    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_128f:
	/* 0x128f: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_1291:
	/* 0x1291: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1297:
	/* 0x1297: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_129a:
	/* 0x129a: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_129f:
	/* 0x129f: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_12a2:
	/* 0x12a2: jns    1542 <trace_fd_install+0x1542> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12a2, 0x1542, x86_l_1542);
x86_l_12a8:
	/* 0x12a8: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_12ac:
	/* 0x12ac: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ae:
	/* 0x12ae: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12b1:
	/* 0x12b1: je     1356 <trace_fd_install+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12b1, 0x1356, x86_l_1356);
x86_l_12b7:
	/* 0x12b7: lea    r15,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12bb:
	/* 0x12bb: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_12be:
	/* 0x12be: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_12c3:
	/* 0x12c3: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_12c7:
	/* 0x12c7: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12ca:
	/* 0x12ca: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_12cd:
	/* 0x12cd: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_12d0:
	/* 0x12d0: jne    12ae <trace_fd_install+0x12ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12d0, 0x12ae, x86_l_12ae);
x86_l_12d2:
	/* 0x12d2: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_12d5:
	/* 0x12d5: jmp    135b <trace_fd_install+0x135b> */
	X86_SIM_X86_JMP(0x12d5, 0x135b, x86_l_135b);
x86_l_12da:
	/* 0x12da: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_12dd:
	/* 0x12dd: jne    1564 <trace_fd_install+0x1564> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12dd, 0x1564, x86_l_1564);
x86_l_12e3:
	/* 0x12e3: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_12e6:
	/* 0x12e6: je     1564 <trace_fd_install+0x1564> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12e6, 0x1564, x86_l_1564);
x86_l_12ec:
	/* 0x12ec: add    r8,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_12f0:
	/* 0x12f0: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_12f3:
	/* 0x12f3: jns    132e <trace_fd_install+0x132e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f3, 0x132e, x86_l_132e);
x86_l_12f5:
	/* 0x12f5: mov    rsi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12f8:
	/* 0x12f8: jmp    1330 <trace_fd_install+0x1330> */
	X86_SIM_X86_JMP(0x12f8, 0x1330, x86_l_1330);
x86_l_12fa:
	/* 0x12fa: lea    rcx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1301:
	/* 0x1301: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1304:
	/* 0x1304: jns    159e <trace_fd_install+0x159e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1304, 0x159e, x86_l_159e);
x86_l_130a:
	/* 0x130a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_130c:
	/* 0x130c: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1313:
	/* 0x1313: je     15b2 <trace_fd_install+0x15b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1313, 0x15b2, x86_l_15b2);
x86_l_1319:
	/* 0x1319: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_131d:
	/* 0x131d: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1321:
	/* 0x1321: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1324:
	/* 0x1324: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_1327:
	/* 0x1327: jne    130c <trace_fd_install+0x130c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1327, 0x130c, x86_l_130c);
x86_l_1329:
	/* 0x1329: jmp    2947 <trace_fd_install+0x2947> */
	X86_SIM_X86_JMP(0x1329, 0x2947, x86_l_2947);
x86_l_132e:
	/* 0x132e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1330:
	/* 0x1330: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1333:
	/* 0x1333: jns    133a <trace_fd_install+0x133a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1333, 0x133a, x86_l_133a);
x86_l_1335:
	/* 0x1335: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1338:
	/* 0x1338: jmp    133c <trace_fd_install+0x133c> */
	X86_SIM_X86_JMP(0x1338, 0x133c, x86_l_133c);
x86_l_133a:
	/* 0x133a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_133c:
	/* 0x133c: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_133f:
	/* 0x133f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1342:
	/* 0x1342: jns    1349 <trace_fd_install+0x1349> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1342, 0x1349, x86_l_1349);
x86_l_1344:
	/* 0x1344: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1347:
	/* 0x1347: jmp    134b <trace_fd_install+0x134b> */
	X86_SIM_X86_JMP(0x1347, 0x134b, x86_l_134b);
x86_l_1349:
	/* 0x1349: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_134b:
	/* 0x134b: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_134f:
	/* 0x134f: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1354:
	/* 0x1354: jmp    1374 <trace_fd_install+0x1374> */
	X86_SIM_X86_JMP(0x1354, 0x1374, x86_l_1374);
x86_l_1356:
	/* 0x1356: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_135b:
	/* 0x135b: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_135f:
	/* 0x135f: jl     1564 <trace_fd_install+0x1564> */
	X86_SIM_X86_JCC(X86_CC_L, 0x135f, 0x1564, x86_l_1564);
x86_l_1365:
	/* 0x1365: mov    BYTE PTR [rax+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_136c:
	/* 0x136c: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1371:
	/* 0x1371: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1374:
	/* 0x1374: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1377:
	/* 0x1377: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_137a:
	/* 0x137a: jns    1381 <trace_fd_install+0x1381> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x137a, 0x1381, x86_l_1381);
x86_l_137c:
	/* 0x137c: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137f:
	/* 0x137f: jmp    1383 <trace_fd_install+0x1383> */
	X86_SIM_X86_JMP(0x137f, 0x1383, x86_l_1383);
x86_l_1381:
	/* 0x1381: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1383:
	/* 0x1383: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1387:
	/* 0x1387: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_138a:
	/* 0x138a: jns    1391 <trace_fd_install+0x1391> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138a, 0x1391, x86_l_1391);
x86_l_138c:
	/* 0x138c: mov    r13,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_138f:
	/* 0x138f: jmp    1394 <trace_fd_install+0x1394> */
	X86_SIM_X86_JMP(0x138f, 0x1394, x86_l_1394);
x86_l_1391:
	/* 0x1391: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1394:
	/* 0x1394: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1397:
	/* 0x1397: je     1423 <trace_fd_install+0x1423> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1397, 0x1423, x86_l_1423);
x86_l_139d:
	/* 0x139d: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_13a0:
	/* 0x13a0: je     1423 <trace_fd_install+0x1423> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13a0, 0x1423, x86_l_1423);
x86_l_13a6:
	/* 0x13a6: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13aa:
	/* 0x13aa: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13ad:
	/* 0x13ad: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_13b3:
	/* 0x13b3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_13b6:
	/* 0x13b6: jns    13bf <trace_fd_install+0x13bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13b6, 0x13bf, x86_l_13bf);
x86_l_13b8:
	/* 0x13b8: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13bb:
	/* 0x13bb: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13bf:
	/* 0x13bf: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_13c3:
	/* 0x13c3: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_13c6:
	/* 0x13c6: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_13cd:
	/* 0x13cd: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_13cf:
	/* 0x13cf: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_13d2:
	/* 0x13d2: jb     2934 <trace_fd_install+0x2934> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13d2, 0x2934, x86_l_2934);
x86_l_13d8:
	/* 0x13d8: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_13db:
	/* 0x13db: je     1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13db, 0x1555, x86_l_1555);
x86_l_13e1:
	/* 0x13e1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_13e7:
	/* 0x13e7: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_13ea:
	/* 0x13ea: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_13ed:
	/* 0x13ed: jns    18ab <trace_fd_install+0x18ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13ed, 0x18ab, x86_l_18ab);
x86_l_13f3:
	/* 0x13f3: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_13f8:
	/* 0x13f8: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_13fc:
	/* 0x13fc: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13fe:
	/* 0x13fe: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1401:
	/* 0x1401: je     1472 <trace_fd_install+0x1472> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1401, 0x1472, x86_l_1472);
x86_l_1403:
	/* 0x1403: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1407:
	/* 0x1407: mov    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_140a:
	/* 0x140a: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_140f:
	/* 0x140f: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1413:
	/* 0x1413: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1416:
	/* 0x1416: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1419:
	/* 0x1419: mov    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_141c:
	/* 0x141c: jne    13fe <trace_fd_install+0x13fe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x141c, 0x13fe, x86_l_13fe);
x86_l_141e:
	/* 0x141e: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1421:
	/* 0x1421: jmp    1477 <trace_fd_install+0x1477> */
	X86_SIM_X86_JMP(0x1421, 0x1477, x86_l_1477);
x86_l_1423:
	/* 0x1423: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1426:
	/* 0x1426: jne    1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1426, 0x1555, x86_l_1555);
x86_l_142c:
	/* 0x142c: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_142f:
	/* 0x142f: je     1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_E, 0x142f, 0x1555, x86_l_1555);
x86_l_1435:
	/* 0x1435: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1439:
	/* 0x1439: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_143c:
	/* 0x143c: jns    1443 <trace_fd_install+0x1443> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x143c, 0x1443, x86_l_1443);
x86_l_143e:
	/* 0x143e: mov    r13,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1441:
	/* 0x1441: jmp    1446 <trace_fd_install+0x1446> */
	X86_SIM_X86_JMP(0x1441, 0x1446, x86_l_1446);
x86_l_1443:
	/* 0x1443: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1446:
	/* 0x1446: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1449:
	/* 0x1449: jns    1450 <trace_fd_install+0x1450> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1449, 0x1450, x86_l_1450);
x86_l_144b:
	/* 0x144b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_144e:
	/* 0x144e: jmp    1452 <trace_fd_install+0x1452> */
	X86_SIM_X86_JMP(0x144e, 0x1452, x86_l_1452);
x86_l_1450:
	/* 0x1450: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1452:
	/* 0x1452: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1455:
	/* 0x1455: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1458:
	/* 0x1458: jns    145f <trace_fd_install+0x145f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1458, 0x145f, x86_l_145f);
x86_l_145a:
	/* 0x145a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_145d:
	/* 0x145d: jmp    1461 <trace_fd_install+0x1461> */
	X86_SIM_X86_JMP(0x145d, 0x1461, x86_l_1461);
x86_l_145f:
	/* 0x145f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1461:
	/* 0x1461: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1465:
	/* 0x1465: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1468:
	/* 0x1468: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_146b:
	/* 0x146b: jns    149e <trace_fd_install+0x149e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x146b, 0x149e, x86_l_149e);
x86_l_146d:
	/* 0x146d: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1470:
	/* 0x1470: jmp    14a0 <trace_fd_install+0x14a0> */
	X86_SIM_X86_JMP(0x1470, 0x14a0, x86_l_14a0);
x86_l_1472:
	/* 0x1472: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1477:
	/* 0x1477: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_147b:
	/* 0x147b: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1480:
	/* 0x1480: jl     1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1480, 0x1555, x86_l_1555);
x86_l_1486:
	/* 0x1486: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1489:
	/* 0x1489: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_148f:
	/* 0x148f: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_1493:
	/* 0x1493: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1496:
	/* 0x1496: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1499:
	/* 0x1499: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_149c:
	/* 0x149c: js     146d <trace_fd_install+0x146d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x149c, 0x146d, x86_l_146d);
x86_l_149e:
	/* 0x149e: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14a0:
	/* 0x14a0: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14a4:
	/* 0x14a4: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14a7:
	/* 0x14a7: jns    14ae <trace_fd_install+0x14ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14a7, 0x14ae, x86_l_14ae);
x86_l_14a9:
	/* 0x14a9: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ac:
	/* 0x14ac: jmp    14b0 <trace_fd_install+0x14b0> */
	X86_SIM_X86_JMP(0x14ac, 0x14b0, x86_l_14b0);
x86_l_14ae:
	/* 0x14ae: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14b0:
	/* 0x14b0: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14b3:
	/* 0x14b3: je     15be <trace_fd_install+0x15be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14b3, 0x15be, x86_l_15be);
x86_l_14b9:
	/* 0x14b9: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_14bc:
	/* 0x14bc: je     15be <trace_fd_install+0x15be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14bc, 0x15be, x86_l_15be);
x86_l_14c2:
	/* 0x14c2: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14c6:
	/* 0x14c6: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14c9:
	/* 0x14c9: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_14cf:
	/* 0x14cf: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14d2:
	/* 0x14d2: jns    14db <trace_fd_install+0x14db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14d2, 0x14db, x86_l_14db);
x86_l_14d4:
	/* 0x14d4: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14d7:
	/* 0x14d7: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14db:
	/* 0x14db: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14df:
	/* 0x14df: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_14e2:
	/* 0x14e2: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_14e9:
	/* 0x14e9: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_14eb:
	/* 0x14eb: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_14ee:
	/* 0x14ee: jb     2934 <trace_fd_install+0x2934> */
	X86_SIM_X86_JCC(X86_CC_B, 0x14ee, 0x2934, x86_l_2934);
x86_l_14f4:
	/* 0x14f4: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_14f7:
	/* 0x14f7: je     1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f7, 0x1a0c, x86_l_1a0c);
x86_l_14fd:
	/* 0x14fd: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1503:
	/* 0x1503: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1506:
	/* 0x1506: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1509:
	/* 0x1509: jns    1542 <trace_fd_install+0x1542> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1509, 0x1542, x86_l_1542);
x86_l_150b:
	/* 0x150b: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1510:
	/* 0x1510: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1514:
	/* 0x1514: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1516:
	/* 0x1516: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1519:
	/* 0x1519: je     17dc <trace_fd_install+0x17dc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1519, 0x17dc, x86_l_17dc);
x86_l_151f:
	/* 0x151f: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1523:
	/* 0x1523: mov    r15,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1526:
	/* 0x1526: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_152b:
	/* 0x152b: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_152f:
	/* 0x152f: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1532:
	/* 0x1532: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1535:
	/* 0x1535: mov    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1538:
	/* 0x1538: jne    1516 <trace_fd_install+0x1516> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1538, 0x1516, x86_l_1516);
x86_l_153a:
	/* 0x153a: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_153d:
	/* 0x153d: jmp    17e1 <trace_fd_install+0x17e1> */
	X86_SIM_X86_JMP(0x153d, 0x17e1, x86_l_17e1);
x86_l_1542:
	/* 0x1542: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1545:
	/* 0x1545: mov    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1548:
	/* 0x1548: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_154a:
	/* 0x154a: call   154f <trace_fd_install+0x154f> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_154f:
	/* 0x154f: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1552:
	/* 0x1552: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1555:
	/* 0x1555: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1558:
	/* 0x1558: cmp    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_155e:
	/* 0x155e: jne    2934 <trace_fd_install+0x2934> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x155e, 0x2934, x86_l_2934);
x86_l_1564:
	/* 0x1564: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1568:
	/* 0x1568: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_156b:
	/* 0x156b: jns    1577 <trace_fd_install+0x1577> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156b, 0x1577, x86_l_1577);
x86_l_156d:
	/* 0x156d: mov    rcx,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1571:
	/* 0x1571: mov    rcx,QWORD PTR [r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1575:
	/* 0x1575: jmp    1579 <trace_fd_install+0x1579> */
	X86_SIM_X86_JMP(0x1575, 0x1579, x86_l_1579);
x86_l_1577:
	/* 0x1577: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1579:
	/* 0x1579: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_157c:
	/* 0x157c: jns    159e <trace_fd_install+0x159e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157c, 0x159e, x86_l_159e);
x86_l_157e:
	/* 0x157e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1580:
	/* 0x1580: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1587:
	/* 0x1587: je     15b2 <trace_fd_install+0x15b2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1587, 0x15b2, x86_l_15b2);
x86_l_1589:
	/* 0x1589: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_158d:
	/* 0x158d: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1591:
	/* 0x1591: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1594:
	/* 0x1594: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_1597:
	/* 0x1597: jne    1580 <trace_fd_install+0x1580> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1597, 0x1580, x86_l_1580);
x86_l_1599:
	/* 0x1599: jmp    2947 <trace_fd_install+0x2947> */
	X86_SIM_X86_JMP(0x1599, 0x2947, x86_l_2947);
x86_l_159e:
	/* 0x159e: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_15a3:
	/* 0x15a3: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15a6:
	/* 0x15a6: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a8:
	/* 0x15a8: call   15ad <trace_fd_install+0x15ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_15ad:
	/* 0x15ad: jmp    2947 <trace_fd_install+0x2947> */
	X86_SIM_X86_JMP(0x15ad, 0x2947, x86_l_2947);
x86_l_15b2:
	/* 0x15b2: mov    BYTE PTR [rax+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_15b9:
	/* 0x15b9: jmp    2947 <trace_fd_install+0x2947> */
	X86_SIM_X86_JMP(0x15b9, 0x2947, x86_l_2947);
x86_l_15be:
	/* 0x15be: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15c1:
	/* 0x15c1: jne    1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15c1, 0x1a0c, x86_l_1a0c);
x86_l_15c7:
	/* 0x15c7: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15ca:
	/* 0x15ca: je     1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15ca, 0x1a0c, x86_l_1a0c);
x86_l_15d0:
	/* 0x15d0: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15d4:
	/* 0x15d4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15d7:
	/* 0x15d7: jns    15de <trace_fd_install+0x15de> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15d7, 0x15de, x86_l_15de);
x86_l_15d9:
	/* 0x15d9: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15dc:
	/* 0x15dc: jmp    15e0 <trace_fd_install+0x15e0> */
	X86_SIM_X86_JMP(0x15dc, 0x15e0, x86_l_15e0);
x86_l_15de:
	/* 0x15de: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15e0:
	/* 0x15e0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15e3:
	/* 0x15e3: jns    15ea <trace_fd_install+0x15ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15e3, 0x15ea, x86_l_15ea);
x86_l_15e5:
	/* 0x15e5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e8:
	/* 0x15e8: jmp    15ec <trace_fd_install+0x15ec> */
	X86_SIM_X86_JMP(0x15e8, 0x15ec, x86_l_15ec);
x86_l_15ea:
	/* 0x15ea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15ec:
	/* 0x15ec: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15ef:
	/* 0x15ef: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15f2:
	/* 0x15f2: jns    15f9 <trace_fd_install+0x15f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15f2, 0x15f9, x86_l_15f9);
x86_l_15f4:
	/* 0x15f4: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15f7:
	/* 0x15f7: jmp    15fb <trace_fd_install+0x15fb> */
	X86_SIM_X86_JMP(0x15f7, 0x15fb, x86_l_15fb);
x86_l_15f9:
	/* 0x15f9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15fb:
	/* 0x15fb: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15ff:
	/* 0x15ff: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1602:
	/* 0x1602: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1605:
	/* 0x1605: jns    180c <trace_fd_install+0x180c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1605, 0x180c, x86_l_180c);
x86_l_160b:
	/* 0x160b: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160e:
	/* 0x160e: jmp    180e <trace_fd_install+0x180e> */
	X86_SIM_X86_JMP(0x160e, 0x180e, x86_l_180e);
x86_l_1613:
	/* 0x1613: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1616:
	/* 0x1616: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_161a:
	/* 0x161a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_161d:
	/* 0x161d: jns    17c1 <trace_fd_install+0x17c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x161d, 0x17c1, x86_l_17c1);
x86_l_1623:
	/* 0x1623: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1626:
	/* 0x1626: mov    QWORD PTR [r15+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_162d:
	/* 0x162d: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1631:
	/* 0x1631: mov    QWORD PTR [r15+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1638:
	/* 0x1638: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_163c:
	/* 0x163c: mov    QWORD PTR [r15+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1643:
	/* 0x1643: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1647:
	/* 0x1647: mov    QWORD PTR [r15+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_164e:
	/* 0x164e: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1652:
	/* 0x1652: mov    QWORD PTR [r15+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_1659:
	/* 0x1659: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_165d:
	/* 0x165d: mov    QWORD PTR [r15+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1664:
	/* 0x1664: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1668:
	/* 0x1668: mov    QWORD PTR [r15+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_166f:
	/* 0x166f: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1673:
	/* 0x1673: mov    QWORD PTR [r15+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_167a:
	/* 0x167a: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_167e:
	/* 0x167e: mov    QWORD PTR [r15+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1685:
	/* 0x1685: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1689:
	/* 0x1689: mov    QWORD PTR [r15+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1690:
	/* 0x1690: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1694:
	/* 0x1694: mov    QWORD PTR [r15+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_169b:
	/* 0x169b: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_169f:
	/* 0x169f: mov    QWORD PTR [r15+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_16a6:
	/* 0x16a6: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_16aa:
	/* 0x16aa: mov    QWORD PTR [r15+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_16b1:
	/* 0x16b1: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_16b5:
	/* 0x16b5: mov    QWORD PTR [r15+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_16bc:
	/* 0x16bc: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_16c0:
	/* 0x16c0: mov    QWORD PTR [r15+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_16c7:
	/* 0x16c7: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_16cb:
	/* 0x16cb: mov    QWORD PTR [r15+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_16d2:
	/* 0x16d2: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_16d9:
	/* 0x16d9: mov    QWORD PTR [r15+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_16e0:
	/* 0x16e0: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_16e7:
	/* 0x16e7: mov    QWORD PTR [r15+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_16ee:
	/* 0x16ee: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_16f5:
	/* 0x16f5: mov    QWORD PTR [r15+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_16fc:
	/* 0x16fc: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1703:
	/* 0x1703: mov    QWORD PTR [r15+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_170a:
	/* 0x170a: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1711:
	/* 0x1711: mov    QWORD PTR [r15+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1718:
	/* 0x1718: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_171f:
	/* 0x171f: mov    QWORD PTR [r15+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1726:
	/* 0x1726: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_172d:
	/* 0x172d: mov    QWORD PTR [r15+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1734:
	/* 0x1734: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_173b:
	/* 0x173b: mov    QWORD PTR [r15+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1742:
	/* 0x1742: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1749:
	/* 0x1749: mov    QWORD PTR [r15+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1750:
	/* 0x1750: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1757:
	/* 0x1757: mov    QWORD PTR [r15+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_175e:
	/* 0x175e: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1765:
	/* 0x1765: mov    QWORD PTR [r15+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_176c:
	/* 0x176c: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1773:
	/* 0x1773: mov    QWORD PTR [r15+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_177a:
	/* 0x177a: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1781:
	/* 0x1781: mov    QWORD PTR [r15+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1788:
	/* 0x1788: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_178f:
	/* 0x178f: mov    QWORD PTR [r15+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1796:
	/* 0x1796: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_179d:
	/* 0x179d: mov    QWORD PTR [r15+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_17a4:
	/* 0x17a4: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_17ab:
	/* 0x17ab: mov    QWORD PTR [r15+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_17b2:
	/* 0x17b2: movzx  eax,WORD PTR [r13+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_17b7:
	/* 0x17b7: mov    WORD PTR [r15+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_17bc:
	/* 0x17bc: jmp    81e <trace_fd_install+0x81e> */
	X86_SIM_X86_JMP(0x17bc, 0x81e, x86_l_81e);
x86_l_17c1:
	/* 0x17c1: add    r15,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_17c8:
	/* 0x17c8: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_17cd:
	/* 0x17cd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_17d0:
	/* 0x17d0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17d2:
	/* 0x17d2: call   17d7 <trace_fd_install+0x17d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_17d7:
	/* 0x17d7: jmp    2a32 <trace_fd_install+0x2a32> */
	X86_SIM_X86_JMP(0x17d7, 0x2a32, x86_l_2a32);
x86_l_17dc:
	/* 0x17dc: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_17e1:
	/* 0x17e1: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_17e5:
	/* 0x17e5: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17ea:
	/* 0x17ea: jl     1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x17ea, 0x1a0c, x86_l_1a0c);
x86_l_17f0:
	/* 0x17f0: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_17f3:
	/* 0x17f3: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_17f9:
	/* 0x17f9: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_17fd:
	/* 0x17fd: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1800:
	/* 0x1800: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1803:
	/* 0x1803: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1806:
	/* 0x1806: js     160b <trace_fd_install+0x160b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1806, 0x160b, x86_l_160b);
x86_l_180c:
	/* 0x180c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_180e:
	/* 0x180e: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1812:
	/* 0x1812: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1815:
	/* 0x1815: jns    181c <trace_fd_install+0x181c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1815, 0x181c, x86_l_181c);
x86_l_1817:
	/* 0x1817: mov    r13,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_181a:
	/* 0x181a: jmp    181f <trace_fd_install+0x181f> */
	X86_SIM_X86_JMP(0x181a, 0x181f, x86_l_181f);
x86_l_181c:
	/* 0x181c: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_181f:
	/* 0x181f: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1822:
	/* 0x1822: je     18b6 <trace_fd_install+0x18b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1822, 0x18b6, x86_l_18b6);
x86_l_1828:
	/* 0x1828: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_182b:
	/* 0x182b: je     18b6 <trace_fd_install+0x18b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x182b, 0x18b6, x86_l_18b6);
x86_l_1831:
	/* 0x1831: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1835:
	/* 0x1835: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1838:
	/* 0x1838: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_183e:
	/* 0x183e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1841:
	/* 0x1841: jns    184a <trace_fd_install+0x184a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1841, 0x184a, x86_l_184a);
x86_l_1843:
	/* 0x1843: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1846:
	/* 0x1846: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_184a:
	/* 0x184a: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_184e:
	/* 0x184e: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1851:
	/* 0x1851: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1858:
	/* 0x1858: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_185a:
	/* 0x185a: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_185d:
	/* 0x185d: jb     2934 <trace_fd_install+0x2934> */
	X86_SIM_X86_JCC(X86_CC_B, 0x185d, 0x2934, x86_l_2934);
x86_l_1863:
	/* 0x1863: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1866:
	/* 0x1866: je     1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1866, 0x1555, x86_l_1555);
x86_l_186c:
	/* 0x186c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1872:
	/* 0x1872: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1875:
	/* 0x1875: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1878:
	/* 0x1878: jns    18ab <trace_fd_install+0x18ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1878, 0x18ab, x86_l_18ab);
x86_l_187a:
	/* 0x187a: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_187d:
	/* 0x187d: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1882:
	/* 0x1882: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1886:
	/* 0x1886: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1888:
	/* 0x1888: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_188b:
	/* 0x188b: je     191f <trace_fd_install+0x191f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x188b, 0x191f, x86_l_191f);
x86_l_1891:
	/* 0x1891: lea    r12,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1895:
	/* 0x1895: movzx  ebp,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_189a:
	/* 0x189a: mov    BYTE PTR [rdi+rbx*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_189e:
	/* 0x189e: mov    rbx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_18a1:
	/* 0x18a1: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_18a4:
	/* 0x18a4: jne    1888 <trace_fd_install+0x1888> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18a4, 0x1888, x86_l_1888);
x86_l_18a6:
	/* 0x18a6: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_18a9:
	/* 0x18a9: jmp    1924 <trace_fd_install+0x1924> */
	X86_SIM_X86_JMP(0x18a9, 0x1924, x86_l_1924);
x86_l_18ab:
	/* 0x18ab: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18ae:
	/* 0x18ae: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_18b1:
	/* 0x18b1: jmp    1545 <trace_fd_install+0x1545> */
	X86_SIM_X86_JMP(0x18b1, 0x1545, x86_l_1545);
x86_l_18b6:
	/* 0x18b6: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_18b9:
	/* 0x18b9: jne    1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18b9, 0x1555, x86_l_1555);
x86_l_18bf:
	/* 0x18bf: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18c2:
	/* 0x18c2: je     1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18c2, 0x1555, x86_l_1555);
x86_l_18c8:
	/* 0x18c8: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18cc:
	/* 0x18cc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18cf:
	/* 0x18cf: jns    18d6 <trace_fd_install+0x18d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18cf, 0x18d6, x86_l_18d6);
x86_l_18d1:
	/* 0x18d1: mov    r13,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d4:
	/* 0x18d4: jmp    18d9 <trace_fd_install+0x18d9> */
	X86_SIM_X86_JMP(0x18d4, 0x18d9, x86_l_18d9);
x86_l_18d6:
	/* 0x18d6: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18d9:
	/* 0x18d9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18dc:
	/* 0x18dc: jns    18e3 <trace_fd_install+0x18e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18dc, 0x18e3, x86_l_18e3);
x86_l_18de:
	/* 0x18de: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18e1:
	/* 0x18e1: jmp    18e5 <trace_fd_install+0x18e5> */
	X86_SIM_X86_JMP(0x18e1, 0x18e5, x86_l_18e5);
x86_l_18e3:
	/* 0x18e3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18e5:
	/* 0x18e5: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_18e8:
	/* 0x18e8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_18eb:
	/* 0x18eb: jns    18f2 <trace_fd_install+0x18f2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18eb, 0x18f2, x86_l_18f2);
x86_l_18ed:
	/* 0x18ed: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18f0:
	/* 0x18f0: jmp    18f4 <trace_fd_install+0x18f4> */
	X86_SIM_X86_JMP(0x18f0, 0x18f4, x86_l_18f4);
x86_l_18f2:
	/* 0x18f2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18f4:
	/* 0x18f4: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18f8:
	/* 0x18f8: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_18fb:
	/* 0x18fb: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_18fe:
	/* 0x18fe: jns    194f <trace_fd_install+0x194f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18fe, 0x194f, x86_l_194f);
x86_l_1900:
	/* 0x1900: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1903:
	/* 0x1903: jmp    1951 <trace_fd_install+0x1951> */
	X86_SIM_X86_JMP(0x1903, 0x1951, x86_l_1951);
x86_l_1905:
	/* 0x1905: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_190a:
	/* 0x190a: mov    r14,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_190f:
	/* 0x190f: test   BYTE PTR [r13+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_1914:
	/* 0x1914: je     227 <trace_fd_install+0x227> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1914, 0x227, x86_l_227);
x86_l_191a:
	/* 0x191a: jmp    77e <trace_fd_install+0x77e> */
	X86_SIM_X86_JMP(0x191a, 0x77e, x86_l_77e);
x86_l_191f:
	/* 0x191f: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1924:
	/* 0x1924: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1928:
	/* 0x1928: jl     28d6 <trace_fd_install+0x28d6> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1928, 0x28d6, x86_l_28d6);
x86_l_192e:
	/* 0x192e: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1931:
	/* 0x1931: lea    esi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1935:
	/* 0x1935: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_193b:
	/* 0x193b: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_193f:
	/* 0x193f: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1942:
	/* 0x1942: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1947:
	/* 0x1947: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_194a:
	/* 0x194a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_194d:
	/* 0x194d: js     1900 <trace_fd_install+0x1900> */
	X86_SIM_X86_JCC(X86_CC_S, 0x194d, 0x1900, x86_l_1900);
x86_l_194f:
	/* 0x194f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1951:
	/* 0x1951: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1955:
	/* 0x1955: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1958:
	/* 0x1958: jns    195f <trace_fd_install+0x195f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1958, 0x195f, x86_l_195f);
x86_l_195a:
	/* 0x195a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_195d:
	/* 0x195d: jmp    1961 <trace_fd_install+0x1961> */
	X86_SIM_X86_JMP(0x195d, 0x1961, x86_l_1961);
x86_l_195f:
	/* 0x195f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1961:
	/* 0x1961: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1964:
	/* 0x1964: je     19e9 <trace_fd_install+0x19e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1964, 0x19e9, x86_l_19e9);
x86_l_196a:
	/* 0x196a: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_196d:
	/* 0x196d: je     19e9 <trace_fd_install+0x19e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x196d, 0x19e9, x86_l_19e9);
x86_l_196f:
	/* 0x196f: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1973:
	/* 0x1973: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1976:
	/* 0x1976: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_197c:
	/* 0x197c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_197f:
	/* 0x197f: jns    1988 <trace_fd_install+0x1988> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x197f, 0x1988, x86_l_1988);
x86_l_1981:
	/* 0x1981: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1984:
	/* 0x1984: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1988:
	/* 0x1988: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_198c:
	/* 0x198c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_198f:
	/* 0x198f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1996:
	/* 0x1996: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1998:
	/* 0x1998: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_199b:
	/* 0x199b: jb     2934 <trace_fd_install+0x2934> */
	X86_SIM_X86_JCC(X86_CC_B, 0x199b, 0x2934, x86_l_2934);
x86_l_19a1:
	/* 0x19a1: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_19a4:
	/* 0x19a4: je     1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a4, 0x1a0c, x86_l_1a0c);
x86_l_19a6:
	/* 0x19a6: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19a9:
	/* 0x19a9: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ae:
	/* 0x19ae: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_19b4:
	/* 0x19b4: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19b7:
	/* 0x19b7: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_19ba:
	/* 0x19ba: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_19bd:
	/* 0x19bd: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19bd, 0x2748, x86_l_2748);
x86_l_19c3:
	/* 0x19c3: lea    eax,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_19c7:
	/* 0x19c7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19ca:
	/* 0x19ca: cmp    rax,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_19cd:
	/* 0x19cd: je     1a42 <trace_fd_install+0x1a42> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19cd, 0x1a42, x86_l_1a42);
x86_l_19cf:
	/* 0x19cf: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_19d3:
	/* 0x19d3: movzx  ebp,BYTE PTR [r10+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_19d8:
	/* 0x19d8: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_19dc:
	/* 0x19dc: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19df:
	/* 0x19df: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_19e2:
	/* 0x19e2: jne    19ca <trace_fd_install+0x19ca> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19e2, 0x19ca, x86_l_19ca);
x86_l_19e4:
	/* 0x19e4: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_19e7:
	/* 0x19e7: jmp    1a46 <trace_fd_install+0x1a46> */
	X86_SIM_X86_JMP(0x19e7, 0x1a46, x86_l_1a46);
x86_l_19e9:
	/* 0x19e9: cmp    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19ec:
	/* 0x19ec: jne    1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19ec, 0x1a0c, x86_l_1a0c);
x86_l_19ee:
	/* 0x19ee: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_19f1:
	/* 0x19f1: je     1a0c <trace_fd_install+0x1a0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19f1, 0x1a0c, x86_l_1a0c);
x86_l_19f3:
	/* 0x19f3: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_19f6:
	/* 0x19f6: mov    QWORD PTR [rsp+0x8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19fb:
	/* 0x19fb: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19fe:
	/* 0x19fe: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a02:
	/* 0x1a02: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a05:
	/* 0x1a05: jns    1a14 <trace_fd_install+0x1a14> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a05, 0x1a14, x86_l_1a14);
x86_l_1a07:
	/* 0x1a07: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a0a:
	/* 0x1a0a: jmp    1a16 <trace_fd_install+0x1a16> */
	X86_SIM_X86_JMP(0x1a0a, 0x1a16, x86_l_1a16);
x86_l_1a0c:
	/* 0x1a0c: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1a0f:
	/* 0x1a0f: jmp    1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JMP(0x1a0f, 0x1555, x86_l_1555);
x86_l_1a14:
	/* 0x1a14: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a16:
	/* 0x1a16: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a19:
	/* 0x1a19: jns    1a20 <trace_fd_install+0x1a20> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a19, 0x1a20, x86_l_1a20);
x86_l_1a1b:
	/* 0x1a1b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a1e:
	/* 0x1a1e: jmp    1a22 <trace_fd_install+0x1a22> */
	X86_SIM_X86_JMP(0x1a1e, 0x1a22, x86_l_1a22);
x86_l_1a20:
	/* 0x1a20: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a22:
	/* 0x1a22: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a25:
	/* 0x1a25: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a28:
	/* 0x1a28: jns    1a2f <trace_fd_install+0x1a2f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a28, 0x1a2f, x86_l_1a2f);
x86_l_1a2a:
	/* 0x1a2a: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a2d:
	/* 0x1a2d: jmp    1a31 <trace_fd_install+0x1a31> */
	X86_SIM_X86_JMP(0x1a2d, 0x1a31, x86_l_1a31);
x86_l_1a2f:
	/* 0x1a2f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a31:
	/* 0x1a31: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a35:
	/* 0x1a35: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1a38:
	/* 0x1a38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a3b:
	/* 0x1a3b: jns    1a69 <trace_fd_install+0x1a69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a3b, 0x1a69, x86_l_1a69);
x86_l_1a3d:
	/* 0x1a3d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a40:
	/* 0x1a40: jmp    1a6b <trace_fd_install+0x1a6b> */
	X86_SIM_X86_JMP(0x1a40, 0x1a6b, x86_l_1a6b);
x86_l_1a42:
	/* 0x1a42: mov    BYTE PTR [rdi+rax*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1a46:
	/* 0x1a46: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a4a:
	/* 0x1a4a: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a4a, 0x28d0, x86_l_28d0);
x86_l_1a50:
	/* 0x1a50: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a54:
	/* 0x1a54: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1a59:
	/* 0x1a59: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1a5e:
	/* 0x1a5e: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a61:
	/* 0x1a61: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1a64:
	/* 0x1a64: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a67:
	/* 0x1a67: js     1a3d <trace_fd_install+0x1a3d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a67, 0x1a3d, x86_l_1a3d);
x86_l_1a69:
	/* 0x1a69: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a6b:
	/* 0x1a6b: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a6f:
	/* 0x1a6f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a72:
	/* 0x1a72: jns    1a79 <trace_fd_install+0x1a79> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a72, 0x1a79, x86_l_1a79);
x86_l_1a74:
	/* 0x1a74: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a77:
	/* 0x1a77: jmp    1a7c <trace_fd_install+0x1a7c> */
	X86_SIM_X86_JMP(0x1a77, 0x1a7c, x86_l_1a7c);
x86_l_1a79:
	/* 0x1a79: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a7c:
	/* 0x1a7c: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a7f:
	/* 0x1a7f: je     1af9 <trace_fd_install+0x1af9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a7f, 0x1af9, x86_l_1af9);
x86_l_1a81:
	/* 0x1a81: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1a84:
	/* 0x1a84: je     1af9 <trace_fd_install+0x1af9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a84, 0x1af9, x86_l_1af9);
x86_l_1a86:
	/* 0x1a86: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a8a:
	/* 0x1a8a: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a8d:
	/* 0x1a8d: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1a92:
	/* 0x1a92: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a95:
	/* 0x1a95: jns    1a9e <trace_fd_install+0x1a9e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a95, 0x1a9e, x86_l_1a9e);
x86_l_1a97:
	/* 0x1a97: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a9a:
	/* 0x1a9a: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a9e:
	/* 0x1a9e: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1aa2:
	/* 0x1aa2: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1aa5:
	/* 0x1aa5: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1aac:
	/* 0x1aac: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1aaf:
	/* 0x1aaf: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ab2:
	/* 0x1ab2: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ab2, 0x2929, x86_l_2929);
x86_l_1ab8:
	/* 0x1ab8: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1abb:
	/* 0x1abb: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1abb, 0x28d3, x86_l_28d3);
x86_l_1ac1:
	/* 0x1ac1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1ac7:
	/* 0x1ac7: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1aca:
	/* 0x1aca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1acd:
	/* 0x1acd: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1acd, 0x2745, x86_l_2745);
x86_l_1ad3:
	/* 0x1ad3: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ad7:
	/* 0x1ad7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ada:
	/* 0x1ada: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1add:
	/* 0x1add: je     1b48 <trace_fd_install+0x1b48> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1add, 0x1b48, x86_l_1b48);
x86_l_1adf:
	/* 0x1adf: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ae3:
	/* 0x1ae3: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1ae8:
	/* 0x1ae8: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1aec:
	/* 0x1aec: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1aef:
	/* 0x1aef: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1af2:
	/* 0x1af2: jne    1ada <trace_fd_install+0x1ada> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1af2, 0x1ada, x86_l_1ada);
x86_l_1af4:
	/* 0x1af4: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1af7:
	/* 0x1af7: jmp    1b4d <trace_fd_install+0x1b4d> */
	X86_SIM_X86_JMP(0x1af7, 0x1b4d, x86_l_1b4d);
x86_l_1af9:
	/* 0x1af9: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1afc:
	/* 0x1afc: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1afc, 0x28d3, x86_l_28d3);
x86_l_1b02:
	/* 0x1b02: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b05:
	/* 0x1b05: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b05, 0x28d3, x86_l_28d3);
x86_l_1b0b:
	/* 0x1b0b: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b0f:
	/* 0x1b0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b12:
	/* 0x1b12: jns    1b19 <trace_fd_install+0x1b19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b12, 0x1b19, x86_l_1b19);
x86_l_1b14:
	/* 0x1b14: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b17:
	/* 0x1b17: jmp    1b1c <trace_fd_install+0x1b1c> */
	X86_SIM_X86_JMP(0x1b17, 0x1b1c, x86_l_1b1c);
x86_l_1b19:
	/* 0x1b19: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b1c:
	/* 0x1b1c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b1f:
	/* 0x1b1f: jns    1b26 <trace_fd_install+0x1b26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1f, 0x1b26, x86_l_1b26);
x86_l_1b21:
	/* 0x1b21: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b24:
	/* 0x1b24: jmp    1b28 <trace_fd_install+0x1b28> */
	X86_SIM_X86_JMP(0x1b24, 0x1b28, x86_l_1b28);
x86_l_1b26:
	/* 0x1b26: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b28:
	/* 0x1b28: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b2b:
	/* 0x1b2b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b2e:
	/* 0x1b2e: jns    1b35 <trace_fd_install+0x1b35> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b2e, 0x1b35, x86_l_1b35);
x86_l_1b30:
	/* 0x1b30: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b33:
	/* 0x1b33: jmp    1b37 <trace_fd_install+0x1b37> */
	X86_SIM_X86_JMP(0x1b33, 0x1b37, x86_l_1b37);
x86_l_1b35:
	/* 0x1b35: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b37:
	/* 0x1b37: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b3b:
	/* 0x1b3b: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1b3e:
	/* 0x1b3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b41:
	/* 0x1b41: jns    1b70 <trace_fd_install+0x1b70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b41, 0x1b70, x86_l_1b70);
x86_l_1b43:
	/* 0x1b43: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b46:
	/* 0x1b46: jmp    1b72 <trace_fd_install+0x1b72> */
	X86_SIM_X86_JMP(0x1b46, 0x1b72, x86_l_1b72);
x86_l_1b48:
	/* 0x1b48: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1b4d:
	/* 0x1b4d: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b51:
	/* 0x1b51: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1b51, 0x28d3, x86_l_28d3);
x86_l_1b57:
	/* 0x1b57: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b5b:
	/* 0x1b5b: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1b60:
	/* 0x1b60: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1b65:
	/* 0x1b65: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b68:
	/* 0x1b68: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1b6b:
	/* 0x1b6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b6e:
	/* 0x1b6e: js     1b43 <trace_fd_install+0x1b43> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b6e, 0x1b43, x86_l_1b43);
x86_l_1b70:
	/* 0x1b70: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b72:
	/* 0x1b72: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b76:
	/* 0x1b76: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b79:
	/* 0x1b79: jns    1b80 <trace_fd_install+0x1b80> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b79, 0x1b80, x86_l_1b80);
x86_l_1b7b:
	/* 0x1b7b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7e:
	/* 0x1b7e: jmp    1b82 <trace_fd_install+0x1b82> */
	X86_SIM_X86_JMP(0x1b7e, 0x1b82, x86_l_1b82);
x86_l_1b80:
	/* 0x1b80: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b82:
	/* 0x1b82: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b85:
	/* 0x1b85: je     1bff <trace_fd_install+0x1bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b85, 0x1bff, x86_l_1bff);
x86_l_1b87:
	/* 0x1b87: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b8a:
	/* 0x1b8a: je     1bff <trace_fd_install+0x1bff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b8a, 0x1bff, x86_l_1bff);
x86_l_1b8c:
	/* 0x1b8c: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b90:
	/* 0x1b90: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b93:
	/* 0x1b93: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1b98:
	/* 0x1b98: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b9b:
	/* 0x1b9b: jns    1ba4 <trace_fd_install+0x1ba4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b9b, 0x1ba4, x86_l_1ba4);
x86_l_1b9d:
	/* 0x1b9d: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ba0:
	/* 0x1ba0: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ba4:
	/* 0x1ba4: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1ba8:
	/* 0x1ba8: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1bab:
	/* 0x1bab: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1bb2:
	/* 0x1bb2: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1bb5:
	/* 0x1bb5: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1bb8:
	/* 0x1bb8: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1bb8, 0x2929, x86_l_2929);
x86_l_1bbe:
	/* 0x1bbe: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1bc1:
	/* 0x1bc1: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bc1, 0x28d0, x86_l_28d0);
x86_l_1bc7:
	/* 0x1bc7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1bcd:
	/* 0x1bcd: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1bd0:
	/* 0x1bd0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bd3:
	/* 0x1bd3: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bd3, 0x2748, x86_l_2748);
x86_l_1bd9:
	/* 0x1bd9: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bdd:
	/* 0x1bdd: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1be0:
	/* 0x1be0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1be3:
	/* 0x1be3: je     1c4d <trace_fd_install+0x1c4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1be3, 0x1c4d, x86_l_1c4d);
x86_l_1be5:
	/* 0x1be5: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1be9:
	/* 0x1be9: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1bee:
	/* 0x1bee: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1bf2:
	/* 0x1bf2: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1bf5:
	/* 0x1bf5: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1bf8:
	/* 0x1bf8: jne    1be0 <trace_fd_install+0x1be0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bf8, 0x1be0, x86_l_1be0);
x86_l_1bfa:
	/* 0x1bfa: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1bfd:
	/* 0x1bfd: jmp    1c52 <trace_fd_install+0x1c52> */
	X86_SIM_X86_JMP(0x1bfd, 0x1c52, x86_l_1c52);
x86_l_1bff:
	/* 0x1bff: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c02:
	/* 0x1c02: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c02, 0x28d0, x86_l_28d0);
x86_l_1c08:
	/* 0x1c08: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c0b:
	/* 0x1c0b: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c0b, 0x28d0, x86_l_28d0);
x86_l_1c11:
	/* 0x1c11: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c15:
	/* 0x1c15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c18:
	/* 0x1c18: jns    1c1f <trace_fd_install+0x1c1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c18, 0x1c1f, x86_l_1c1f);
x86_l_1c1a:
	/* 0x1c1a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c1d:
	/* 0x1c1d: jmp    1c21 <trace_fd_install+0x1c21> */
	X86_SIM_X86_JMP(0x1c1d, 0x1c21, x86_l_1c21);
x86_l_1c1f:
	/* 0x1c1f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c21:
	/* 0x1c21: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c24:
	/* 0x1c24: jns    1c2b <trace_fd_install+0x1c2b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c24, 0x1c2b, x86_l_1c2b);
x86_l_1c26:
	/* 0x1c26: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c29:
	/* 0x1c29: jmp    1c2d <trace_fd_install+0x1c2d> */
	X86_SIM_X86_JMP(0x1c29, 0x1c2d, x86_l_1c2d);
x86_l_1c2b:
	/* 0x1c2b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c2d:
	/* 0x1c2d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c30:
	/* 0x1c30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c33:
	/* 0x1c33: jns    1c3a <trace_fd_install+0x1c3a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c33, 0x1c3a, x86_l_1c3a);
x86_l_1c35:
	/* 0x1c35: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c38:
	/* 0x1c38: jmp    1c3c <trace_fd_install+0x1c3c> */
	X86_SIM_X86_JMP(0x1c38, 0x1c3c, x86_l_1c3c);
x86_l_1c3a:
	/* 0x1c3a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c3c:
	/* 0x1c3c: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c40:
	/* 0x1c40: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1c43:
	/* 0x1c43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c46:
	/* 0x1c46: jns    1c75 <trace_fd_install+0x1c75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c46, 0x1c75, x86_l_1c75);
x86_l_1c48:
	/* 0x1c48: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c4b:
	/* 0x1c4b: jmp    1c77 <trace_fd_install+0x1c77> */
	X86_SIM_X86_JMP(0x1c4b, 0x1c77, x86_l_1c77);
x86_l_1c4d:
	/* 0x1c4d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c52:
	/* 0x1c52: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c56:
	/* 0x1c56: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c56, 0x28d0, x86_l_28d0);
x86_l_1c5c:
	/* 0x1c5c: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c60:
	/* 0x1c60: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1c65:
	/* 0x1c65: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1c6a:
	/* 0x1c6a: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c6d:
	/* 0x1c6d: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1c70:
	/* 0x1c70: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c73:
	/* 0x1c73: js     1c48 <trace_fd_install+0x1c48> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c73, 0x1c48, x86_l_1c48);
x86_l_1c75:
	/* 0x1c75: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c77:
	/* 0x1c77: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c7b:
	/* 0x1c7b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c7e:
	/* 0x1c7e: jns    1c85 <trace_fd_install+0x1c85> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c7e, 0x1c85, x86_l_1c85);
x86_l_1c80:
	/* 0x1c80: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c83:
	/* 0x1c83: jmp    1c88 <trace_fd_install+0x1c88> */
	X86_SIM_X86_JMP(0x1c83, 0x1c88, x86_l_1c88);
x86_l_1c85:
	/* 0x1c85: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c88:
	/* 0x1c88: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c8b:
	/* 0x1c8b: je     1d05 <trace_fd_install+0x1d05> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c8b, 0x1d05, x86_l_1d05);
x86_l_1c8d:
	/* 0x1c8d: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c90:
	/* 0x1c90: je     1d05 <trace_fd_install+0x1d05> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c90, 0x1d05, x86_l_1d05);
x86_l_1c92:
	/* 0x1c92: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c96:
	/* 0x1c96: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c99:
	/* 0x1c99: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c9e:
	/* 0x1c9e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ca1:
	/* 0x1ca1: jns    1caa <trace_fd_install+0x1caa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca1, 0x1caa, x86_l_1caa);
x86_l_1ca3:
	/* 0x1ca3: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca6:
	/* 0x1ca6: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1caa:
	/* 0x1caa: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1cae:
	/* 0x1cae: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1cb1:
	/* 0x1cb1: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1cb8:
	/* 0x1cb8: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1cbb:
	/* 0x1cbb: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cbe:
	/* 0x1cbe: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cbe, 0x2929, x86_l_2929);
x86_l_1cc4:
	/* 0x1cc4: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1cc7:
	/* 0x1cc7: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc7, 0x28d3, x86_l_28d3);
x86_l_1ccd:
	/* 0x1ccd: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1cd3:
	/* 0x1cd3: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1cd6:
	/* 0x1cd6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cd9:
	/* 0x1cd9: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cd9, 0x2745, x86_l_2745);
x86_l_1cdf:
	/* 0x1cdf: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ce3:
	/* 0x1ce3: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ce6:
	/* 0x1ce6: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ce9:
	/* 0x1ce9: je     1d54 <trace_fd_install+0x1d54> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce9, 0x1d54, x86_l_1d54);
x86_l_1ceb:
	/* 0x1ceb: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1cef:
	/* 0x1cef: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1cf4:
	/* 0x1cf4: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1cf8:
	/* 0x1cf8: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1cfb:
	/* 0x1cfb: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1cfe:
	/* 0x1cfe: jne    1ce6 <trace_fd_install+0x1ce6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cfe, 0x1ce6, x86_l_1ce6);
x86_l_1d00:
	/* 0x1d00: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d03:
	/* 0x1d03: jmp    1d59 <trace_fd_install+0x1d59> */
	X86_SIM_X86_JMP(0x1d03, 0x1d59, x86_l_1d59);
x86_l_1d05:
	/* 0x1d05: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d08:
	/* 0x1d08: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d08, 0x28d3, x86_l_28d3);
x86_l_1d0e:
	/* 0x1d0e: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d11:
	/* 0x1d11: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d11, 0x28d3, x86_l_28d3);
x86_l_1d17:
	/* 0x1d17: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d1b:
	/* 0x1d1b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d1e:
	/* 0x1d1e: jns    1d25 <trace_fd_install+0x1d25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1e, 0x1d25, x86_l_1d25);
x86_l_1d20:
	/* 0x1d20: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d23:
	/* 0x1d23: jmp    1d28 <trace_fd_install+0x1d28> */
	X86_SIM_X86_JMP(0x1d23, 0x1d28, x86_l_1d28);
x86_l_1d25:
	/* 0x1d25: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d28:
	/* 0x1d28: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d2b:
	/* 0x1d2b: jns    1d32 <trace_fd_install+0x1d32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d2b, 0x1d32, x86_l_1d32);
x86_l_1d2d:
	/* 0x1d2d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d30:
	/* 0x1d30: jmp    1d34 <trace_fd_install+0x1d34> */
	X86_SIM_X86_JMP(0x1d30, 0x1d34, x86_l_1d34);
x86_l_1d32:
	/* 0x1d32: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d34:
	/* 0x1d34: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d37:
	/* 0x1d37: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d3a:
	/* 0x1d3a: jns    1d41 <trace_fd_install+0x1d41> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d3a, 0x1d41, x86_l_1d41);
x86_l_1d3c:
	/* 0x1d3c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d3f:
	/* 0x1d3f: jmp    1d43 <trace_fd_install+0x1d43> */
	X86_SIM_X86_JMP(0x1d3f, 0x1d43, x86_l_1d43);
x86_l_1d41:
	/* 0x1d41: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d43:
	/* 0x1d43: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d47:
	/* 0x1d47: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d4a:
	/* 0x1d4a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d4d:
	/* 0x1d4d: jns    1d7c <trace_fd_install+0x1d7c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d4d, 0x1d7c, x86_l_1d7c);
x86_l_1d4f:
	/* 0x1d4f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d52:
	/* 0x1d52: jmp    1d7e <trace_fd_install+0x1d7e> */
	X86_SIM_X86_JMP(0x1d52, 0x1d7e, x86_l_1d7e);
x86_l_1d54:
	/* 0x1d54: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d59:
	/* 0x1d59: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d5d:
	/* 0x1d5d: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d5d, 0x28d3, x86_l_28d3);
x86_l_1d63:
	/* 0x1d63: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d67:
	/* 0x1d67: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d6c:
	/* 0x1d6c: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1d71:
	/* 0x1d71: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d74:
	/* 0x1d74: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d77:
	/* 0x1d77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d7a:
	/* 0x1d7a: js     1d4f <trace_fd_install+0x1d4f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d7a, 0x1d4f, x86_l_1d4f);
x86_l_1d7c:
	/* 0x1d7c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d7e:
	/* 0x1d7e: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d82:
	/* 0x1d82: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d85:
	/* 0x1d85: jns    1d8c <trace_fd_install+0x1d8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d85, 0x1d8c, x86_l_1d8c);
x86_l_1d87:
	/* 0x1d87: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d8a:
	/* 0x1d8a: jmp    1d8e <trace_fd_install+0x1d8e> */
	X86_SIM_X86_JMP(0x1d8a, 0x1d8e, x86_l_1d8e);
x86_l_1d8c:
	/* 0x1d8c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d8e:
	/* 0x1d8e: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d91:
	/* 0x1d91: je     1e0b <trace_fd_install+0x1e0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d91, 0x1e0b, x86_l_1e0b);
x86_l_1d93:
	/* 0x1d93: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d96:
	/* 0x1d96: je     1e0b <trace_fd_install+0x1e0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d96, 0x1e0b, x86_l_1e0b);
x86_l_1d98:
	/* 0x1d98: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d9c:
	/* 0x1d9c: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d9f:
	/* 0x1d9f: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1da4:
	/* 0x1da4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1da7:
	/* 0x1da7: jns    1db0 <trace_fd_install+0x1db0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1da7, 0x1db0, x86_l_1db0);
x86_l_1da9:
	/* 0x1da9: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dac:
	/* 0x1dac: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1db0:
	/* 0x1db0: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1db4:
	/* 0x1db4: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1db7:
	/* 0x1db7: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1dbe:
	/* 0x1dbe: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1dc1:
	/* 0x1dc1: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1dc4:
	/* 0x1dc4: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dc4, 0x2929, x86_l_2929);
x86_l_1dca:
	/* 0x1dca: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1dcd:
	/* 0x1dcd: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dcd, 0x28d0, x86_l_28d0);
x86_l_1dd3:
	/* 0x1dd3: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1dd9:
	/* 0x1dd9: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1ddc:
	/* 0x1ddc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ddf:
	/* 0x1ddf: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ddf, 0x2748, x86_l_2748);
x86_l_1de5:
	/* 0x1de5: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1de9:
	/* 0x1de9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dec:
	/* 0x1dec: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1def:
	/* 0x1def: je     1e59 <trace_fd_install+0x1e59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1def, 0x1e59, x86_l_1e59);
x86_l_1df1:
	/* 0x1df1: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1df5:
	/* 0x1df5: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1dfa:
	/* 0x1dfa: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1dfe:
	/* 0x1dfe: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e01:
	/* 0x1e01: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1e04:
	/* 0x1e04: jne    1dec <trace_fd_install+0x1dec> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e04, 0x1dec, x86_l_1dec);
x86_l_1e06:
	/* 0x1e06: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1e09:
	/* 0x1e09: jmp    1e5e <trace_fd_install+0x1e5e> */
	X86_SIM_X86_JMP(0x1e09, 0x1e5e, x86_l_1e5e);
x86_l_1e0b:
	/* 0x1e0b: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e0e:
	/* 0x1e0e: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e0e, 0x28d0, x86_l_28d0);
x86_l_1e14:
	/* 0x1e14: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e17:
	/* 0x1e17: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e17, 0x28d0, x86_l_28d0);
x86_l_1e1d:
	/* 0x1e1d: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e21:
	/* 0x1e21: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e24:
	/* 0x1e24: jns    1e2b <trace_fd_install+0x1e2b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e24, 0x1e2b, x86_l_1e2b);
x86_l_1e26:
	/* 0x1e26: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e29:
	/* 0x1e29: jmp    1e2d <trace_fd_install+0x1e2d> */
	X86_SIM_X86_JMP(0x1e29, 0x1e2d, x86_l_1e2d);
x86_l_1e2b:
	/* 0x1e2b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e2d:
	/* 0x1e2d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e30:
	/* 0x1e30: jns    1e37 <trace_fd_install+0x1e37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e30, 0x1e37, x86_l_1e37);
x86_l_1e32:
	/* 0x1e32: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e35:
	/* 0x1e35: jmp    1e39 <trace_fd_install+0x1e39> */
	X86_SIM_X86_JMP(0x1e35, 0x1e39, x86_l_1e39);
x86_l_1e37:
	/* 0x1e37: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e39:
	/* 0x1e39: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e3c:
	/* 0x1e3c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e3f:
	/* 0x1e3f: jns    1e46 <trace_fd_install+0x1e46> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e3f, 0x1e46, x86_l_1e46);
x86_l_1e41:
	/* 0x1e41: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e44:
	/* 0x1e44: jmp    1e48 <trace_fd_install+0x1e48> */
	X86_SIM_X86_JMP(0x1e44, 0x1e48, x86_l_1e48);
x86_l_1e46:
	/* 0x1e46: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e48:
	/* 0x1e48: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e4c:
	/* 0x1e4c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e4f:
	/* 0x1e4f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e52:
	/* 0x1e52: jns    1e81 <trace_fd_install+0x1e81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e52, 0x1e81, x86_l_1e81);
x86_l_1e54:
	/* 0x1e54: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e57:
	/* 0x1e57: jmp    1e83 <trace_fd_install+0x1e83> */
	X86_SIM_X86_JMP(0x1e57, 0x1e83, x86_l_1e83);
x86_l_1e59:
	/* 0x1e59: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e5e:
	/* 0x1e5e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e62:
	/* 0x1e62: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e62, 0x28d0, x86_l_28d0);
x86_l_1e68:
	/* 0x1e68: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e6c:
	/* 0x1e6c: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1e71:
	/* 0x1e71: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1e76:
	/* 0x1e76: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e79:
	/* 0x1e79: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e7c:
	/* 0x1e7c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e7f:
	/* 0x1e7f: js     1e54 <trace_fd_install+0x1e54> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e7f, 0x1e54, x86_l_1e54);
x86_l_1e81:
	/* 0x1e81: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e83:
	/* 0x1e83: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e87:
	/* 0x1e87: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e8a:
	/* 0x1e8a: jns    1e91 <trace_fd_install+0x1e91> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e8a, 0x1e91, x86_l_1e91);
x86_l_1e8c:
	/* 0x1e8c: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8f:
	/* 0x1e8f: jmp    1e94 <trace_fd_install+0x1e94> */
	X86_SIM_X86_JMP(0x1e8f, 0x1e94, x86_l_1e94);
x86_l_1e91:
	/* 0x1e91: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e94:
	/* 0x1e94: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e97:
	/* 0x1e97: je     1f11 <trace_fd_install+0x1f11> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e97, 0x1f11, x86_l_1f11);
x86_l_1e99:
	/* 0x1e99: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e9c:
	/* 0x1e9c: je     1f11 <trace_fd_install+0x1f11> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e9c, 0x1f11, x86_l_1f11);
x86_l_1e9e:
	/* 0x1e9e: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ea2:
	/* 0x1ea2: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ea5:
	/* 0x1ea5: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1eaa:
	/* 0x1eaa: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ead:
	/* 0x1ead: jns    1eb6 <trace_fd_install+0x1eb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ead, 0x1eb6, x86_l_1eb6);
x86_l_1eaf:
	/* 0x1eaf: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb2:
	/* 0x1eb2: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eb6:
	/* 0x1eb6: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1eba:
	/* 0x1eba: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1ebd:
	/* 0x1ebd: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1ec4:
	/* 0x1ec4: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1ec7:
	/* 0x1ec7: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1eca:
	/* 0x1eca: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1eca, 0x2929, x86_l_2929);
x86_l_1ed0:
	/* 0x1ed0: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1ed3:
	/* 0x1ed3: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ed3, 0x28d3, x86_l_28d3);
x86_l_1ed9:
	/* 0x1ed9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1edf:
	/* 0x1edf: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1ee2:
	/* 0x1ee2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ee5:
	/* 0x1ee5: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ee5, 0x2745, x86_l_2745);
x86_l_1eeb:
	/* 0x1eeb: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eef:
	/* 0x1eef: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ef2:
	/* 0x1ef2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ef5:
	/* 0x1ef5: je     1f60 <trace_fd_install+0x1f60> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef5, 0x1f60, x86_l_1f60);
x86_l_1ef7:
	/* 0x1ef7: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1efb:
	/* 0x1efb: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1f00:
	/* 0x1f00: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f04:
	/* 0x1f04: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f07:
	/* 0x1f07: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_1f0a:
	/* 0x1f0a: jne    1ef2 <trace_fd_install+0x1ef2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f0a, 0x1ef2, x86_l_1ef2);
x86_l_1f0c:
	/* 0x1f0c: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1f0f:
	/* 0x1f0f: jmp    1f65 <trace_fd_install+0x1f65> */
	X86_SIM_X86_JMP(0x1f0f, 0x1f65, x86_l_1f65);
x86_l_1f11:
	/* 0x1f11: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f14:
	/* 0x1f14: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f14, 0x28d3, x86_l_28d3);
x86_l_1f1a:
	/* 0x1f1a: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f1d:
	/* 0x1f1d: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1d, 0x28d3, x86_l_28d3);
x86_l_1f23:
	/* 0x1f23: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f27:
	/* 0x1f27: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f2a:
	/* 0x1f2a: jns    1f31 <trace_fd_install+0x1f31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f2a, 0x1f31, x86_l_1f31);
x86_l_1f2c:
	/* 0x1f2c: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f2f:
	/* 0x1f2f: jmp    1f34 <trace_fd_install+0x1f34> */
	X86_SIM_X86_JMP(0x1f2f, 0x1f34, x86_l_1f34);
x86_l_1f31:
	/* 0x1f31: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f34:
	/* 0x1f34: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f37:
	/* 0x1f37: jns    1f3e <trace_fd_install+0x1f3e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f37, 0x1f3e, x86_l_1f3e);
x86_l_1f39:
	/* 0x1f39: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f3c:
	/* 0x1f3c: jmp    1f40 <trace_fd_install+0x1f40> */
	X86_SIM_X86_JMP(0x1f3c, 0x1f40, x86_l_1f40);
x86_l_1f3e:
	/* 0x1f3e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f40:
	/* 0x1f40: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f43:
	/* 0x1f43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f46:
	/* 0x1f46: jns    1f4d <trace_fd_install+0x1f4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f46, 0x1f4d, x86_l_1f4d);
x86_l_1f48:
	/* 0x1f48: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f4b:
	/* 0x1f4b: jmp    1f4f <trace_fd_install+0x1f4f> */
	X86_SIM_X86_JMP(0x1f4b, 0x1f4f, x86_l_1f4f);
x86_l_1f4d:
	/* 0x1f4d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4f:
	/* 0x1f4f: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f53:
	/* 0x1f53: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f56:
	/* 0x1f56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f59:
	/* 0x1f59: jns    1f88 <trace_fd_install+0x1f88> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f59, 0x1f88, x86_l_1f88);
x86_l_1f5b:
	/* 0x1f5b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5e:
	/* 0x1f5e: jmp    1f8a <trace_fd_install+0x1f8a> */
	X86_SIM_X86_JMP(0x1f5e, 0x1f8a, x86_l_1f8a);
x86_l_1f60:
	/* 0x1f60: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1f65:
	/* 0x1f65: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f69:
	/* 0x1f69: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f69, 0x28d3, x86_l_28d3);
x86_l_1f6f:
	/* 0x1f6f: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f73:
	/* 0x1f73: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f78:
	/* 0x1f78: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_1f7d:
	/* 0x1f7d: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f80:
	/* 0x1f80: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f83:
	/* 0x1f83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f86:
	/* 0x1f86: js     1f5b <trace_fd_install+0x1f5b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f86, 0x1f5b, x86_l_1f5b);
x86_l_1f88:
	/* 0x1f88: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8a:
	/* 0x1f8a: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f8e:
	/* 0x1f8e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f91:
	/* 0x1f91: jns    1f98 <trace_fd_install+0x1f98> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f91, 0x1f98, x86_l_1f98);
x86_l_1f93:
	/* 0x1f93: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f96:
	/* 0x1f96: jmp    1f9a <trace_fd_install+0x1f9a> */
	X86_SIM_X86_JMP(0x1f96, 0x1f9a, x86_l_1f9a);
x86_l_1f98:
	/* 0x1f98: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f9a:
	/* 0x1f9a: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f9d:
	/* 0x1f9d: je     2017 <trace_fd_install+0x2017> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f9d, 0x2017, x86_l_2017);
x86_l_1f9f:
	/* 0x1f9f: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fa2:
	/* 0x1fa2: je     2017 <trace_fd_install+0x2017> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa2, 0x2017, x86_l_2017);
x86_l_1fa4:
	/* 0x1fa4: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fa8:
	/* 0x1fa8: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fab:
	/* 0x1fab: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1fb0:
	/* 0x1fb0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fb3:
	/* 0x1fb3: jns    1fbc <trace_fd_install+0x1fbc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb3, 0x1fbc, x86_l_1fbc);
x86_l_1fb5:
	/* 0x1fb5: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb8:
	/* 0x1fb8: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fbc:
	/* 0x1fbc: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1fc0:
	/* 0x1fc0: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1fc3:
	/* 0x1fc3: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1fca:
	/* 0x1fca: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1fcd:
	/* 0x1fcd: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fd0:
	/* 0x1fd0: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1fd0, 0x2929, x86_l_2929);
x86_l_1fd6:
	/* 0x1fd6: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1fd9:
	/* 0x1fd9: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd9, 0x28d0, x86_l_28d0);
x86_l_1fdf:
	/* 0x1fdf: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1fe5:
	/* 0x1fe5: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fe8:
	/* 0x1fe8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1feb:
	/* 0x1feb: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1feb, 0x2748, x86_l_2748);
x86_l_1ff1:
	/* 0x1ff1: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ff5:
	/* 0x1ff5: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ff8:
	/* 0x1ff8: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ffb:
	/* 0x1ffb: je     2065 <trace_fd_install+0x2065> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ffb, 0x2065, x86_l_2065);
x86_l_1ffd:
	/* 0x1ffd: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2001:
	/* 0x2001: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2006:
	/* 0x2006: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_200a:
	/* 0x200a: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_200d:
	/* 0x200d: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2010:
	/* 0x2010: jne    1ff8 <trace_fd_install+0x1ff8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2010, 0x1ff8, x86_l_1ff8);
x86_l_2012:
	/* 0x2012: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2015:
	/* 0x2015: jmp    206a <trace_fd_install+0x206a> */
	X86_SIM_X86_JMP(0x2015, 0x206a, x86_l_206a);
x86_l_2017:
	/* 0x2017: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201a:
	/* 0x201a: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x201a, 0x28d0, x86_l_28d0);
x86_l_2020:
	/* 0x2020: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2023:
	/* 0x2023: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2023, 0x28d0, x86_l_28d0);
x86_l_2029:
	/* 0x2029: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_202d:
	/* 0x202d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2030:
	/* 0x2030: jns    2037 <trace_fd_install+0x2037> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2030, 0x2037, x86_l_2037);
x86_l_2032:
	/* 0x2032: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2035:
	/* 0x2035: jmp    2039 <trace_fd_install+0x2039> */
	X86_SIM_X86_JMP(0x2035, 0x2039, x86_l_2039);
x86_l_2037:
	/* 0x2037: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2039:
	/* 0x2039: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_203c:
	/* 0x203c: jns    2043 <trace_fd_install+0x2043> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x203c, 0x2043, x86_l_2043);
x86_l_203e:
	/* 0x203e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2041:
	/* 0x2041: jmp    2045 <trace_fd_install+0x2045> */
	X86_SIM_X86_JMP(0x2041, 0x2045, x86_l_2045);
x86_l_2043:
	/* 0x2043: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2045:
	/* 0x2045: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2048:
	/* 0x2048: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_204b:
	/* 0x204b: jns    2052 <trace_fd_install+0x2052> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x204b, 0x2052, x86_l_2052);
x86_l_204d:
	/* 0x204d: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2050:
	/* 0x2050: jmp    2054 <trace_fd_install+0x2054> */
	X86_SIM_X86_JMP(0x2050, 0x2054, x86_l_2054);
x86_l_2052:
	/* 0x2052: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2054:
	/* 0x2054: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2058:
	/* 0x2058: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_205b:
	/* 0x205b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_205e:
	/* 0x205e: jns    208d <trace_fd_install+0x208d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x205e, 0x208d, x86_l_208d);
x86_l_2060:
	/* 0x2060: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2063:
	/* 0x2063: jmp    208f <trace_fd_install+0x208f> */
	X86_SIM_X86_JMP(0x2063, 0x208f, x86_l_208f);
x86_l_2065:
	/* 0x2065: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_206a:
	/* 0x206a: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_206e:
	/* 0x206e: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x206e, 0x28d0, x86_l_28d0);
x86_l_2074:
	/* 0x2074: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2078:
	/* 0x2078: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_207d:
	/* 0x207d: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2082:
	/* 0x2082: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2085:
	/* 0x2085: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2088:
	/* 0x2088: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_208b:
	/* 0x208b: js     2060 <trace_fd_install+0x2060> */
	X86_SIM_X86_JCC(X86_CC_S, 0x208b, 0x2060, x86_l_2060);
x86_l_208d:
	/* 0x208d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208f:
	/* 0x208f: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2093:
	/* 0x2093: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2096:
	/* 0x2096: jns    209d <trace_fd_install+0x209d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2096, 0x209d, x86_l_209d);
x86_l_2098:
	/* 0x2098: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_209b:
	/* 0x209b: jmp    20a0 <trace_fd_install+0x20a0> */
	X86_SIM_X86_JMP(0x209b, 0x20a0, x86_l_20a0);
x86_l_209d:
	/* 0x209d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20a0:
	/* 0x20a0: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20a3:
	/* 0x20a3: je     211d <trace_fd_install+0x211d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a3, 0x211d, x86_l_211d);
x86_l_20a5:
	/* 0x20a5: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_20a8:
	/* 0x20a8: je     211d <trace_fd_install+0x211d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a8, 0x211d, x86_l_211d);
x86_l_20aa:
	/* 0x20aa: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20ae:
	/* 0x20ae: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20b1:
	/* 0x20b1: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_20b6:
	/* 0x20b6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20b9:
	/* 0x20b9: jns    20c2 <trace_fd_install+0x20c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20b9, 0x20c2, x86_l_20c2);
x86_l_20bb:
	/* 0x20bb: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20be:
	/* 0x20be: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20c2:
	/* 0x20c2: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_20c6:
	/* 0x20c6: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20c9:
	/* 0x20c9: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20d0:
	/* 0x20d0: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_20d3:
	/* 0x20d3: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20d6:
	/* 0x20d6: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20d6, 0x2929, x86_l_2929);
x86_l_20dc:
	/* 0x20dc: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_20df:
	/* 0x20df: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20df, 0x28d3, x86_l_28d3);
x86_l_20e5:
	/* 0x20e5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20eb:
	/* 0x20eb: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20ee:
	/* 0x20ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20f1:
	/* 0x20f1: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20f1, 0x2745, x86_l_2745);
x86_l_20f7:
	/* 0x20f7: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20fb:
	/* 0x20fb: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20fe:
	/* 0x20fe: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2101:
	/* 0x2101: je     216c <trace_fd_install+0x216c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2101, 0x216c, x86_l_216c);
x86_l_2103:
	/* 0x2103: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2107:
	/* 0x2107: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_210c:
	/* 0x210c: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2110:
	/* 0x2110: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2113:
	/* 0x2113: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2116:
	/* 0x2116: jne    20fe <trace_fd_install+0x20fe> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2116, 0x20fe, x86_l_20fe);
x86_l_2118:
	/* 0x2118: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_211b:
	/* 0x211b: jmp    2171 <trace_fd_install+0x2171> */
	X86_SIM_X86_JMP(0x211b, 0x2171, x86_l_2171);
x86_l_211d:
	/* 0x211d: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2120:
	/* 0x2120: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2120, 0x28d3, x86_l_28d3);
x86_l_2126:
	/* 0x2126: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2129:
	/* 0x2129: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2129, 0x28d3, x86_l_28d3);
x86_l_212f:
	/* 0x212f: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2133:
	/* 0x2133: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2136:
	/* 0x2136: jns    213d <trace_fd_install+0x213d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2136, 0x213d, x86_l_213d);
x86_l_2138:
	/* 0x2138: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213b:
	/* 0x213b: jmp    2140 <trace_fd_install+0x2140> */
	X86_SIM_X86_JMP(0x213b, 0x2140, x86_l_2140);
x86_l_213d:
	/* 0x213d: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2140:
	/* 0x2140: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2143:
	/* 0x2143: jns    214a <trace_fd_install+0x214a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2143, 0x214a, x86_l_214a);
x86_l_2145:
	/* 0x2145: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2148:
	/* 0x2148: jmp    214c <trace_fd_install+0x214c> */
	X86_SIM_X86_JMP(0x2148, 0x214c, x86_l_214c);
x86_l_214a:
	/* 0x214a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214c:
	/* 0x214c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_214f:
	/* 0x214f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2152:
	/* 0x2152: jns    2159 <trace_fd_install+0x2159> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2152, 0x2159, x86_l_2159);
x86_l_2154:
	/* 0x2154: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2157:
	/* 0x2157: jmp    215b <trace_fd_install+0x215b> */
	X86_SIM_X86_JMP(0x2157, 0x215b, x86_l_215b);
x86_l_2159:
	/* 0x2159: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215b:
	/* 0x215b: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_215f:
	/* 0x215f: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2162:
	/* 0x2162: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2165:
	/* 0x2165: jns    2194 <trace_fd_install+0x2194> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2165, 0x2194, x86_l_2194);
x86_l_2167:
	/* 0x2167: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216a:
	/* 0x216a: jmp    2196 <trace_fd_install+0x2196> */
	X86_SIM_X86_JMP(0x216a, 0x2196, x86_l_2196);
x86_l_216c:
	/* 0x216c: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2171:
	/* 0x2171: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2175:
	/* 0x2175: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2175, 0x28d3, x86_l_28d3);
x86_l_217b:
	/* 0x217b: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_217f:
	/* 0x217f: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2184:
	/* 0x2184: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2189:
	/* 0x2189: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_218c:
	/* 0x218c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_218f:
	/* 0x218f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2192:
	/* 0x2192: js     2167 <trace_fd_install+0x2167> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2192, 0x2167, x86_l_2167);
x86_l_2194:
	/* 0x2194: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2196:
	/* 0x2196: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_219a:
	/* 0x219a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_219d:
	/* 0x219d: jns    21a4 <trace_fd_install+0x21a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x219d, 0x21a4, x86_l_21a4);
x86_l_219f:
	/* 0x219f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21a2:
	/* 0x21a2: jmp    21a6 <trace_fd_install+0x21a6> */
	X86_SIM_X86_JMP(0x21a2, 0x21a6, x86_l_21a6);
x86_l_21a4:
	/* 0x21a4: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21a6:
	/* 0x21a6: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21a9:
	/* 0x21a9: je     2223 <trace_fd_install+0x2223> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21a9, 0x2223, x86_l_2223);
x86_l_21ab:
	/* 0x21ab: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21ae:
	/* 0x21ae: je     2223 <trace_fd_install+0x2223> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21ae, 0x2223, x86_l_2223);
x86_l_21b0:
	/* 0x21b0: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21b4:
	/* 0x21b4: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b7:
	/* 0x21b7: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_21bc:
	/* 0x21bc: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21bf:
	/* 0x21bf: jns    21c8 <trace_fd_install+0x21c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21bf, 0x21c8, x86_l_21c8);
x86_l_21c1:
	/* 0x21c1: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c4:
	/* 0x21c4: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21c8:
	/* 0x21c8: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_21cc:
	/* 0x21cc: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21cf:
	/* 0x21cf: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_21d6:
	/* 0x21d6: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_21d9:
	/* 0x21d9: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21dc:
	/* 0x21dc: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21dc, 0x2929, x86_l_2929);
x86_l_21e2:
	/* 0x21e2: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_21e5:
	/* 0x21e5: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e5, 0x28d0, x86_l_28d0);
x86_l_21eb:
	/* 0x21eb: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_21f1:
	/* 0x21f1: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_21f4:
	/* 0x21f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21f7:
	/* 0x21f7: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21f7, 0x2748, x86_l_2748);
x86_l_21fd:
	/* 0x21fd: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2201:
	/* 0x2201: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2204:
	/* 0x2204: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2207:
	/* 0x2207: je     2271 <trace_fd_install+0x2271> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2207, 0x2271, x86_l_2271);
x86_l_2209:
	/* 0x2209: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_220d:
	/* 0x220d: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2212:
	/* 0x2212: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2216:
	/* 0x2216: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2219:
	/* 0x2219: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_221c:
	/* 0x221c: jne    2204 <trace_fd_install+0x2204> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x221c, 0x2204, x86_l_2204);
x86_l_221e:
	/* 0x221e: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2221:
	/* 0x2221: jmp    2276 <trace_fd_install+0x2276> */
	X86_SIM_X86_JMP(0x2221, 0x2276, x86_l_2276);
x86_l_2223:
	/* 0x2223: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2226:
	/* 0x2226: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2226, 0x28d0, x86_l_28d0);
x86_l_222c:
	/* 0x222c: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_222f:
	/* 0x222f: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222f, 0x28d0, x86_l_28d0);
x86_l_2235:
	/* 0x2235: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2239:
	/* 0x2239: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_223c:
	/* 0x223c: jns    2243 <trace_fd_install+0x2243> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x223c, 0x2243, x86_l_2243);
x86_l_223e:
	/* 0x223e: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2241:
	/* 0x2241: jmp    2245 <trace_fd_install+0x2245> */
	X86_SIM_X86_JMP(0x2241, 0x2245, x86_l_2245);
x86_l_2243:
	/* 0x2243: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2245:
	/* 0x2245: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2248:
	/* 0x2248: jns    224f <trace_fd_install+0x224f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2248, 0x224f, x86_l_224f);
x86_l_224a:
	/* 0x224a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_224d:
	/* 0x224d: jmp    2251 <trace_fd_install+0x2251> */
	X86_SIM_X86_JMP(0x224d, 0x2251, x86_l_2251);
x86_l_224f:
	/* 0x224f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2251:
	/* 0x2251: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2254:
	/* 0x2254: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2257:
	/* 0x2257: jns    225e <trace_fd_install+0x225e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2257, 0x225e, x86_l_225e);
x86_l_2259:
	/* 0x2259: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225c:
	/* 0x225c: jmp    2260 <trace_fd_install+0x2260> */
	X86_SIM_X86_JMP(0x225c, 0x2260, x86_l_2260);
x86_l_225e:
	/* 0x225e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2260:
	/* 0x2260: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2264:
	/* 0x2264: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2267:
	/* 0x2267: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_226a:
	/* 0x226a: jns    2299 <trace_fd_install+0x2299> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x226a, 0x2299, x86_l_2299);
x86_l_226c:
	/* 0x226c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_226f:
	/* 0x226f: jmp    229b <trace_fd_install+0x229b> */
	X86_SIM_X86_JMP(0x226f, 0x229b, x86_l_229b);
x86_l_2271:
	/* 0x2271: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2276:
	/* 0x2276: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_227a:
	/* 0x227a: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x227a, 0x28d0, x86_l_28d0);
x86_l_2280:
	/* 0x2280: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2284:
	/* 0x2284: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2289:
	/* 0x2289: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_228e:
	/* 0x228e: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2291:
	/* 0x2291: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2294:
	/* 0x2294: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2297:
	/* 0x2297: js     226c <trace_fd_install+0x226c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2297, 0x226c, x86_l_226c);
x86_l_2299:
	/* 0x2299: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_229b:
	/* 0x229b: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_229f:
	/* 0x229f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22a2:
	/* 0x22a2: jns    22a9 <trace_fd_install+0x22a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a2, 0x22a9, x86_l_22a9);
x86_l_22a4:
	/* 0x22a4: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22a7:
	/* 0x22a7: jmp    22ac <trace_fd_install+0x22ac> */
	X86_SIM_X86_JMP(0x22a7, 0x22ac, x86_l_22ac);
x86_l_22a9:
	/* 0x22a9: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ac:
	/* 0x22ac: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22af:
	/* 0x22af: je     2329 <trace_fd_install+0x2329> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22af, 0x2329, x86_l_2329);
x86_l_22b1:
	/* 0x22b1: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_22b4:
	/* 0x22b4: je     2329 <trace_fd_install+0x2329> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22b4, 0x2329, x86_l_2329);
x86_l_22b6:
	/* 0x22b6: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22ba:
	/* 0x22ba: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22bd:
	/* 0x22bd: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_22c2:
	/* 0x22c2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22c5:
	/* 0x22c5: jns    22ce <trace_fd_install+0x22ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22c5, 0x22ce, x86_l_22ce);
x86_l_22c7:
	/* 0x22c7: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ca:
	/* 0x22ca: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22ce:
	/* 0x22ce: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22d2:
	/* 0x22d2: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22d5:
	/* 0x22d5: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22dc:
	/* 0x22dc: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_22df:
	/* 0x22df: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22e2:
	/* 0x22e2: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22e2, 0x2929, x86_l_2929);
x86_l_22e8:
	/* 0x22e8: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_22eb:
	/* 0x22eb: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22eb, 0x28d3, x86_l_28d3);
x86_l_22f1:
	/* 0x22f1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_22f7:
	/* 0x22f7: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_22fa:
	/* 0x22fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22fd:
	/* 0x22fd: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22fd, 0x2745, x86_l_2745);
x86_l_2303:
	/* 0x2303: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2307:
	/* 0x2307: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_230a:
	/* 0x230a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_230d:
	/* 0x230d: je     2378 <trace_fd_install+0x2378> */
	X86_SIM_X86_JCC(X86_CC_E, 0x230d, 0x2378, x86_l_2378);
x86_l_230f:
	/* 0x230f: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2313:
	/* 0x2313: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2318:
	/* 0x2318: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_231c:
	/* 0x231c: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_231f:
	/* 0x231f: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2322:
	/* 0x2322: jne    230a <trace_fd_install+0x230a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2322, 0x230a, x86_l_230a);
x86_l_2324:
	/* 0x2324: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2327:
	/* 0x2327: jmp    237d <trace_fd_install+0x237d> */
	X86_SIM_X86_JMP(0x2327, 0x237d, x86_l_237d);
x86_l_2329:
	/* 0x2329: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_232c:
	/* 0x232c: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x232c, 0x28d3, x86_l_28d3);
x86_l_2332:
	/* 0x2332: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2335:
	/* 0x2335: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2335, 0x28d3, x86_l_28d3);
x86_l_233b:
	/* 0x233b: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_233f:
	/* 0x233f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2342:
	/* 0x2342: jns    2349 <trace_fd_install+0x2349> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2342, 0x2349, x86_l_2349);
x86_l_2344:
	/* 0x2344: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2347:
	/* 0x2347: jmp    234c <trace_fd_install+0x234c> */
	X86_SIM_X86_JMP(0x2347, 0x234c, x86_l_234c);
x86_l_2349:
	/* 0x2349: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_234c:
	/* 0x234c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_234f:
	/* 0x234f: jns    2356 <trace_fd_install+0x2356> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x234f, 0x2356, x86_l_2356);
x86_l_2351:
	/* 0x2351: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2354:
	/* 0x2354: jmp    2358 <trace_fd_install+0x2358> */
	X86_SIM_X86_JMP(0x2354, 0x2358, x86_l_2358);
x86_l_2356:
	/* 0x2356: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2358:
	/* 0x2358: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_235b:
	/* 0x235b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_235e:
	/* 0x235e: jns    2365 <trace_fd_install+0x2365> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x235e, 0x2365, x86_l_2365);
x86_l_2360:
	/* 0x2360: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2363:
	/* 0x2363: jmp    2367 <trace_fd_install+0x2367> */
	X86_SIM_X86_JMP(0x2363, 0x2367, x86_l_2367);
x86_l_2365:
	/* 0x2365: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2367:
	/* 0x2367: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_236b:
	/* 0x236b: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_236e:
	/* 0x236e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2371:
	/* 0x2371: jns    23a0 <trace_fd_install+0x23a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2371, 0x23a0, x86_l_23a0);
x86_l_2373:
	/* 0x2373: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2376:
	/* 0x2376: jmp    23a2 <trace_fd_install+0x23a2> */
	X86_SIM_X86_JMP(0x2376, 0x23a2, x86_l_23a2);
x86_l_2378:
	/* 0x2378: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_237d:
	/* 0x237d: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2381:
	/* 0x2381: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2381, 0x28d3, x86_l_28d3);
x86_l_2387:
	/* 0x2387: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_238b:
	/* 0x238b: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2390:
	/* 0x2390: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2395:
	/* 0x2395: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2398:
	/* 0x2398: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_239b:
	/* 0x239b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_239e:
	/* 0x239e: js     2373 <trace_fd_install+0x2373> */
	X86_SIM_X86_JCC(X86_CC_S, 0x239e, 0x2373, x86_l_2373);
x86_l_23a0:
	/* 0x23a0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23a2:
	/* 0x23a2: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23a6:
	/* 0x23a6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23a9:
	/* 0x23a9: jns    23b0 <trace_fd_install+0x23b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23a9, 0x23b0, x86_l_23b0);
x86_l_23ab:
	/* 0x23ab: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ae:
	/* 0x23ae: jmp    23b2 <trace_fd_install+0x23b2> */
	X86_SIM_X86_JMP(0x23ae, 0x23b2, x86_l_23b2);
x86_l_23b0:
	/* 0x23b0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b2:
	/* 0x23b2: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23b5:
	/* 0x23b5: je     242f <trace_fd_install+0x242f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23b5, 0x242f, x86_l_242f);
x86_l_23b7:
	/* 0x23b7: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23ba:
	/* 0x23ba: je     242f <trace_fd_install+0x242f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ba, 0x242f, x86_l_242f);
x86_l_23bc:
	/* 0x23bc: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23c0:
	/* 0x23c0: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c3:
	/* 0x23c3: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_23c8:
	/* 0x23c8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23cb:
	/* 0x23cb: jns    23d4 <trace_fd_install+0x23d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23cb, 0x23d4, x86_l_23d4);
x86_l_23cd:
	/* 0x23cd: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d0:
	/* 0x23d0: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23d4:
	/* 0x23d4: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_23d8:
	/* 0x23d8: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23db:
	/* 0x23db: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_23e2:
	/* 0x23e2: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_23e5:
	/* 0x23e5: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23e8:
	/* 0x23e8: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x23e8, 0x2929, x86_l_2929);
x86_l_23ee:
	/* 0x23ee: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_23f1:
	/* 0x23f1: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f1, 0x28d0, x86_l_28d0);
x86_l_23f7:
	/* 0x23f7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_23fd:
	/* 0x23fd: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2400:
	/* 0x2400: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2403:
	/* 0x2403: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2403, 0x2748, x86_l_2748);
x86_l_2409:
	/* 0x2409: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_240d:
	/* 0x240d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2410:
	/* 0x2410: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2413:
	/* 0x2413: je     247d <trace_fd_install+0x247d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2413, 0x247d, x86_l_247d);
x86_l_2415:
	/* 0x2415: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2419:
	/* 0x2419: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_241e:
	/* 0x241e: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2422:
	/* 0x2422: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2425:
	/* 0x2425: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2428:
	/* 0x2428: jne    2410 <trace_fd_install+0x2410> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2428, 0x2410, x86_l_2410);
x86_l_242a:
	/* 0x242a: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_242d:
	/* 0x242d: jmp    2482 <trace_fd_install+0x2482> */
	X86_SIM_X86_JMP(0x242d, 0x2482, x86_l_2482);
x86_l_242f:
	/* 0x242f: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2432:
	/* 0x2432: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2432, 0x28d0, x86_l_28d0);
x86_l_2438:
	/* 0x2438: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_243b:
	/* 0x243b: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x243b, 0x28d0, x86_l_28d0);
x86_l_2441:
	/* 0x2441: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2445:
	/* 0x2445: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2448:
	/* 0x2448: jns    244f <trace_fd_install+0x244f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2448, 0x244f, x86_l_244f);
x86_l_244a:
	/* 0x244a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244d:
	/* 0x244d: jmp    2451 <trace_fd_install+0x2451> */
	X86_SIM_X86_JMP(0x244d, 0x2451, x86_l_2451);
x86_l_244f:
	/* 0x244f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2451:
	/* 0x2451: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2454:
	/* 0x2454: jns    245b <trace_fd_install+0x245b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2454, 0x245b, x86_l_245b);
x86_l_2456:
	/* 0x2456: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2459:
	/* 0x2459: jmp    245d <trace_fd_install+0x245d> */
	X86_SIM_X86_JMP(0x2459, 0x245d, x86_l_245d);
x86_l_245b:
	/* 0x245b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_245d:
	/* 0x245d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2460:
	/* 0x2460: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2463:
	/* 0x2463: jns    246a <trace_fd_install+0x246a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2463, 0x246a, x86_l_246a);
x86_l_2465:
	/* 0x2465: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2468:
	/* 0x2468: jmp    246c <trace_fd_install+0x246c> */
	X86_SIM_X86_JMP(0x2468, 0x246c, x86_l_246c);
x86_l_246a:
	/* 0x246a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_246c:
	/* 0x246c: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2470:
	/* 0x2470: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2473:
	/* 0x2473: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2476:
	/* 0x2476: jns    24a5 <trace_fd_install+0x24a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2476, 0x24a5, x86_l_24a5);
x86_l_2478:
	/* 0x2478: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_247b:
	/* 0x247b: jmp    24a7 <trace_fd_install+0x24a7> */
	X86_SIM_X86_JMP(0x247b, 0x24a7, x86_l_24a7);
x86_l_247d:
	/* 0x247d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2482:
	/* 0x2482: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2486:
	/* 0x2486: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2486, 0x28d0, x86_l_28d0);
x86_l_248c:
	/* 0x248c: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2490:
	/* 0x2490: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2495:
	/* 0x2495: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_249a:
	/* 0x249a: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_249d:
	/* 0x249d: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24a0:
	/* 0x24a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24a3:
	/* 0x24a3: js     2478 <trace_fd_install+0x2478> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24a3, 0x2478, x86_l_2478);
x86_l_24a5:
	/* 0x24a5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24a7:
	/* 0x24a7: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ab:
	/* 0x24ab: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24ae:
	/* 0x24ae: jns    24b5 <trace_fd_install+0x24b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ae, 0x24b5, x86_l_24b5);
x86_l_24b0:
	/* 0x24b0: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24b3:
	/* 0x24b3: jmp    24b8 <trace_fd_install+0x24b8> */
	X86_SIM_X86_JMP(0x24b3, 0x24b8, x86_l_24b8);
x86_l_24b5:
	/* 0x24b5: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24b8:
	/* 0x24b8: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24bb:
	/* 0x24bb: je     2535 <trace_fd_install+0x2535> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24bb, 0x2535, x86_l_2535);
x86_l_24bd:
	/* 0x24bd: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_24c0:
	/* 0x24c0: je     2535 <trace_fd_install+0x2535> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c0, 0x2535, x86_l_2535);
x86_l_24c2:
	/* 0x24c2: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24c6:
	/* 0x24c6: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24c9:
	/* 0x24c9: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_24ce:
	/* 0x24ce: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24d1:
	/* 0x24d1: jns    24da <trace_fd_install+0x24da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24d1, 0x24da, x86_l_24da);
x86_l_24d3:
	/* 0x24d3: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d6:
	/* 0x24d6: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24da:
	/* 0x24da: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_24de:
	/* 0x24de: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_24e1:
	/* 0x24e1: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_24e8:
	/* 0x24e8: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_24eb:
	/* 0x24eb: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24ee:
	/* 0x24ee: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x24ee, 0x2929, x86_l_2929);
x86_l_24f4:
	/* 0x24f4: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_24f7:
	/* 0x24f7: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24f7, 0x28d3, x86_l_28d3);
x86_l_24fd:
	/* 0x24fd: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2503:
	/* 0x2503: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2506:
	/* 0x2506: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2509:
	/* 0x2509: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2509, 0x2745, x86_l_2745);
x86_l_250f:
	/* 0x250f: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2513:
	/* 0x2513: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2516:
	/* 0x2516: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2519:
	/* 0x2519: je     2584 <trace_fd_install+0x2584> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2519, 0x2584, x86_l_2584);
x86_l_251b:
	/* 0x251b: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_251f:
	/* 0x251f: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2524:
	/* 0x2524: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2528:
	/* 0x2528: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_252b:
	/* 0x252b: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_252e:
	/* 0x252e: jne    2516 <trace_fd_install+0x2516> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x252e, 0x2516, x86_l_2516);
x86_l_2530:
	/* 0x2530: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2533:
	/* 0x2533: jmp    2589 <trace_fd_install+0x2589> */
	X86_SIM_X86_JMP(0x2533, 0x2589, x86_l_2589);
x86_l_2535:
	/* 0x2535: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2538:
	/* 0x2538: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2538, 0x28d3, x86_l_28d3);
x86_l_253e:
	/* 0x253e: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2541:
	/* 0x2541: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2541, 0x28d3, x86_l_28d3);
x86_l_2547:
	/* 0x2547: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_254b:
	/* 0x254b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_254e:
	/* 0x254e: jns    2555 <trace_fd_install+0x2555> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x254e, 0x2555, x86_l_2555);
x86_l_2550:
	/* 0x2550: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2553:
	/* 0x2553: jmp    2558 <trace_fd_install+0x2558> */
	X86_SIM_X86_JMP(0x2553, 0x2558, x86_l_2558);
x86_l_2555:
	/* 0x2555: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2558:
	/* 0x2558: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_255b:
	/* 0x255b: jns    2562 <trace_fd_install+0x2562> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x255b, 0x2562, x86_l_2562);
x86_l_255d:
	/* 0x255d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2560:
	/* 0x2560: jmp    2564 <trace_fd_install+0x2564> */
	X86_SIM_X86_JMP(0x2560, 0x2564, x86_l_2564);
x86_l_2562:
	/* 0x2562: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2564:
	/* 0x2564: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2567:
	/* 0x2567: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_256a:
	/* 0x256a: jns    2571 <trace_fd_install+0x2571> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x256a, 0x2571, x86_l_2571);
x86_l_256c:
	/* 0x256c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_256f:
	/* 0x256f: jmp    2573 <trace_fd_install+0x2573> */
	X86_SIM_X86_JMP(0x256f, 0x2573, x86_l_2573);
x86_l_2571:
	/* 0x2571: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2573:
	/* 0x2573: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2577:
	/* 0x2577: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_257a:
	/* 0x257a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_257d:
	/* 0x257d: jns    25ac <trace_fd_install+0x25ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x257d, 0x25ac, x86_l_25ac);
x86_l_257f:
	/* 0x257f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2582:
	/* 0x2582: jmp    25ae <trace_fd_install+0x25ae> */
	X86_SIM_X86_JMP(0x2582, 0x25ae, x86_l_25ae);
x86_l_2584:
	/* 0x2584: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2589:
	/* 0x2589: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_258d:
	/* 0x258d: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x258d, 0x28d3, x86_l_28d3);
x86_l_2593:
	/* 0x2593: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2597:
	/* 0x2597: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_259c:
	/* 0x259c: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_25a1:
	/* 0x25a1: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25a4:
	/* 0x25a4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_25a7:
	/* 0x25a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25aa:
	/* 0x25aa: js     257f <trace_fd_install+0x257f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25aa, 0x257f, x86_l_257f);
x86_l_25ac:
	/* 0x25ac: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25ae:
	/* 0x25ae: lea    rsi,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25b2:
	/* 0x25b2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25b5:
	/* 0x25b5: jns    25bc <trace_fd_install+0x25bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25b5, 0x25bc, x86_l_25bc);
x86_l_25b7:
	/* 0x25b7: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ba:
	/* 0x25ba: jmp    25be <trace_fd_install+0x25be> */
	X86_SIM_X86_JMP(0x25ba, 0x25be, x86_l_25be);
x86_l_25bc:
	/* 0x25bc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25be:
	/* 0x25be: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25c1:
	/* 0x25c1: je     263b <trace_fd_install+0x263b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c1, 0x263b, x86_l_263b);
x86_l_25c3:
	/* 0x25c3: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_25c6:
	/* 0x25c6: je     263b <trace_fd_install+0x263b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25c6, 0x263b, x86_l_263b);
x86_l_25c8:
	/* 0x25c8: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25cc:
	/* 0x25cc: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25cf:
	/* 0x25cf: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_25d4:
	/* 0x25d4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25d7:
	/* 0x25d7: jns    25e0 <trace_fd_install+0x25e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25d7, 0x25e0, x86_l_25e0);
x86_l_25d9:
	/* 0x25d9: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25dc:
	/* 0x25dc: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25e0:
	/* 0x25e0: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_25e4:
	/* 0x25e4: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_25e7:
	/* 0x25e7: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_25ee:
	/* 0x25ee: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_25f1:
	/* 0x25f1: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25f4:
	/* 0x25f4: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x25f4, 0x2929, x86_l_2929);
x86_l_25fa:
	/* 0x25fa: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_25fd:
	/* 0x25fd: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25fd, 0x28d0, x86_l_28d0);
x86_l_2603:
	/* 0x2603: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2609:
	/* 0x2609: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_260c:
	/* 0x260c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_260f:
	/* 0x260f: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x260f, 0x2748, x86_l_2748);
x86_l_2615:
	/* 0x2615: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2619:
	/* 0x2619: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_261c:
	/* 0x261c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_261f:
	/* 0x261f: je     2689 <trace_fd_install+0x2689> */
	X86_SIM_X86_JCC(X86_CC_E, 0x261f, 0x2689, x86_l_2689);
x86_l_2621:
	/* 0x2621: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2625:
	/* 0x2625: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_262a:
	/* 0x262a: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_262e:
	/* 0x262e: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2631:
	/* 0x2631: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2634:
	/* 0x2634: jne    261c <trace_fd_install+0x261c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2634, 0x261c, x86_l_261c);
x86_l_2636:
	/* 0x2636: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2639:
	/* 0x2639: jmp    268e <trace_fd_install+0x268e> */
	X86_SIM_X86_JMP(0x2639, 0x268e, x86_l_268e);
x86_l_263b:
	/* 0x263b: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263e:
	/* 0x263e: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x263e, 0x28d0, x86_l_28d0);
x86_l_2644:
	/* 0x2644: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2647:
	/* 0x2647: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2647, 0x28d0, x86_l_28d0);
x86_l_264d:
	/* 0x264d: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2651:
	/* 0x2651: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2654:
	/* 0x2654: jns    265b <trace_fd_install+0x265b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2654, 0x265b, x86_l_265b);
x86_l_2656:
	/* 0x2656: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2659:
	/* 0x2659: jmp    265d <trace_fd_install+0x265d> */
	X86_SIM_X86_JMP(0x2659, 0x265d, x86_l_265d);
x86_l_265b:
	/* 0x265b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_265d:
	/* 0x265d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2660:
	/* 0x2660: jns    2667 <trace_fd_install+0x2667> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2660, 0x2667, x86_l_2667);
x86_l_2662:
	/* 0x2662: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2665:
	/* 0x2665: jmp    2669 <trace_fd_install+0x2669> */
	X86_SIM_X86_JMP(0x2665, 0x2669, x86_l_2669);
x86_l_2667:
	/* 0x2667: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2669:
	/* 0x2669: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_266c:
	/* 0x266c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_266f:
	/* 0x266f: jns    2676 <trace_fd_install+0x2676> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x266f, 0x2676, x86_l_2676);
x86_l_2671:
	/* 0x2671: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2674:
	/* 0x2674: jmp    2678 <trace_fd_install+0x2678> */
	X86_SIM_X86_JMP(0x2674, 0x2678, x86_l_2678);
x86_l_2676:
	/* 0x2676: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2678:
	/* 0x2678: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_267c:
	/* 0x267c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_267f:
	/* 0x267f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2682:
	/* 0x2682: jns    26b1 <trace_fd_install+0x26b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2682, 0x26b1, x86_l_26b1);
x86_l_2684:
	/* 0x2684: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2687:
	/* 0x2687: jmp    26b3 <trace_fd_install+0x26b3> */
	X86_SIM_X86_JMP(0x2687, 0x26b3, x86_l_26b3);
x86_l_2689:
	/* 0x2689: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_268e:
	/* 0x268e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2692:
	/* 0x2692: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2692, 0x28d0, x86_l_28d0);
x86_l_2698:
	/* 0x2698: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_269c:
	/* 0x269c: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_26a1:
	/* 0x26a1: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_26a6:
	/* 0x26a6: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26a9:
	/* 0x26a9: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26ac:
	/* 0x26ac: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26af:
	/* 0x26af: js     2684 <trace_fd_install+0x2684> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26af, 0x2684, x86_l_2684);
x86_l_26b1:
	/* 0x26b1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b3:
	/* 0x26b3: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26b7:
	/* 0x26b7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26ba:
	/* 0x26ba: jns    26c1 <trace_fd_install+0x26c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26ba, 0x26c1, x86_l_26c1);
x86_l_26bc:
	/* 0x26bc: mov    r13,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26bf:
	/* 0x26bf: jmp    26c4 <trace_fd_install+0x26c4> */
	X86_SIM_X86_JMP(0x26bf, 0x26c4, x86_l_26c4);
x86_l_26c1:
	/* 0x26c1: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26c4:
	/* 0x26c4: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26c7:
	/* 0x26c7: je     2755 <trace_fd_install+0x2755> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26c7, 0x2755, x86_l_2755);
x86_l_26cd:
	/* 0x26cd: cmp    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_26d0:
	/* 0x26d0: je     2755 <trace_fd_install+0x2755> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d0, 0x2755, x86_l_2755);
x86_l_26d6:
	/* 0x26d6: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26da:
	/* 0x26da: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26dd:
	/* 0x26dd: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_26e2:
	/* 0x26e2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26e5:
	/* 0x26e5: jns    26ee <trace_fd_install+0x26ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26e5, 0x26ee, x86_l_26ee);
x86_l_26e7:
	/* 0x26e7: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26ea:
	/* 0x26ea: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26ee:
	/* 0x26ee: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26f2:
	/* 0x26f2: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_26f5:
	/* 0x26f5: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_26fc:
	/* 0x26fc: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_26ff:
	/* 0x26ff: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2702:
	/* 0x2702: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2702, 0x2929, x86_l_2929);
x86_l_2708:
	/* 0x2708: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_270b:
	/* 0x270b: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x270b, 0x28d3, x86_l_28d3);
x86_l_2711:
	/* 0x2711: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2717:
	/* 0x2717: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_271a:
	/* 0x271a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271d:
	/* 0x271d: jns    2745 <trace_fd_install+0x2745> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x271d, 0x2745, x86_l_2745);
x86_l_271f:
	/* 0x271f: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2723:
	/* 0x2723: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2726:
	/* 0x2726: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2729:
	/* 0x2729: je     27a4 <trace_fd_install+0x27a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2729, 0x27a4, x86_l_27a4);
x86_l_272b:
	/* 0x272b: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_272f:
	/* 0x272f: movzx  ebp,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2734:
	/* 0x2734: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2738:
	/* 0x2738: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_273b:
	/* 0x273b: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_273e:
	/* 0x273e: jne    2726 <trace_fd_install+0x2726> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x273e, 0x2726, x86_l_2726);
x86_l_2740:
	/* 0x2740: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2743:
	/* 0x2743: jmp    27a9 <trace_fd_install+0x27a9> */
	X86_SIM_X86_JMP(0x2743, 0x27a9, x86_l_27a9);
x86_l_2745:
	/* 0x2745: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2748:
	/* 0x2748: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_274d:
	/* 0x274d: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2750:
	/* 0x2750: jmp    1545 <trace_fd_install+0x1545> */
	X86_SIM_X86_JMP(0x2750, 0x1545, x86_l_1545);
x86_l_2755:
	/* 0x2755: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2758:
	/* 0x2758: jne    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2758, 0x28d3, x86_l_28d3);
x86_l_275e:
	/* 0x275e: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2761:
	/* 0x2761: je     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2761, 0x28d3, x86_l_28d3);
x86_l_2767:
	/* 0x2767: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_276b:
	/* 0x276b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_276e:
	/* 0x276e: jns    2775 <trace_fd_install+0x2775> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x276e, 0x2775, x86_l_2775);
x86_l_2770:
	/* 0x2770: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2773:
	/* 0x2773: jmp    2778 <trace_fd_install+0x2778> */
	X86_SIM_X86_JMP(0x2773, 0x2778, x86_l_2778);
x86_l_2775:
	/* 0x2775: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2778:
	/* 0x2778: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_277b:
	/* 0x277b: jns    2782 <trace_fd_install+0x2782> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x277b, 0x2782, x86_l_2782);
x86_l_277d:
	/* 0x277d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2780:
	/* 0x2780: jmp    2784 <trace_fd_install+0x2784> */
	X86_SIM_X86_JMP(0x2780, 0x2784, x86_l_2784);
x86_l_2782:
	/* 0x2782: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2784:
	/* 0x2784: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2787:
	/* 0x2787: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_278a:
	/* 0x278a: jns    2791 <trace_fd_install+0x2791> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x278a, 0x2791, x86_l_2791);
x86_l_278c:
	/* 0x278c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_278f:
	/* 0x278f: jmp    2793 <trace_fd_install+0x2793> */
	X86_SIM_X86_JMP(0x278f, 0x2793, x86_l_2793);
x86_l_2791:
	/* 0x2791: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2793:
	/* 0x2793: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2797:
	/* 0x2797: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_279a:
	/* 0x279a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_279d:
	/* 0x279d: jns    27cc <trace_fd_install+0x27cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x279d, 0x27cc, x86_l_27cc);
x86_l_279f:
	/* 0x279f: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27a2:
	/* 0x27a2: jmp    27ce <trace_fd_install+0x27ce> */
	X86_SIM_X86_JMP(0x27a2, 0x27ce, x86_l_27ce);
x86_l_27a4:
	/* 0x27a4: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_27a9:
	/* 0x27a9: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27ad:
	/* 0x27ad: jl     28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_L, 0x27ad, 0x28d3, x86_l_28d3);
x86_l_27b3:
	/* 0x27b3: lea    eax,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27b7:
	/* 0x27b7: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_27bc:
	/* 0x27bc: mov    BYTE PTR [r12+rax*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_27c1:
	/* 0x27c1: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27c4:
	/* 0x27c4: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_27c7:
	/* 0x27c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27ca:
	/* 0x27ca: js     279f <trace_fd_install+0x279f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27ca, 0x279f, x86_l_279f);
x86_l_27cc:
	/* 0x27cc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27ce:
	/* 0x27ce: lea    rax,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d2:
	/* 0x27d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27d5:
	/* 0x27d5: jns    27dc <trace_fd_install+0x27dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27d5, 0x27dc, x86_l_27dc);
x86_l_27d7:
	/* 0x27d7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27da:
	/* 0x27da: jmp    27de <trace_fd_install+0x27de> */
	X86_SIM_X86_JMP(0x27da, 0x27de, x86_l_27de);
x86_l_27dc:
	/* 0x27dc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27de:
	/* 0x27de: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_27e1:
	/* 0x27e1: je     285b <trace_fd_install+0x285b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e1, 0x285b, x86_l_285b);
x86_l_27e3:
	/* 0x27e3: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27e6:
	/* 0x27e6: je     285b <trace_fd_install+0x285b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e6, 0x285b, x86_l_285b);
x86_l_27e8:
	/* 0x27e8: lea    rdi,[r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27ec:
	/* 0x27ec: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27ef:
	/* 0x27ef: mov    esi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_27f4:
	/* 0x27f4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27f7:
	/* 0x27f7: jns    2800 <trace_fd_install+0x2800> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27f7, 0x2800, x86_l_2800);
x86_l_27f9:
	/* 0x27f9: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27fc:
	/* 0x27fc: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2800:
	/* 0x2800: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2804:
	/* 0x2804: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2807:
	/* 0x2807: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_280e:
	/* 0x280e: mov    edi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2811:
	/* 0x2811: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2814:
	/* 0x2814: jb     2929 <trace_fd_install+0x2929> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2814, 0x2929, x86_l_2929);
x86_l_281a:
	/* 0x281a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_281d:
	/* 0x281d: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281d, 0x28d0, x86_l_28d0);
x86_l_2823:
	/* 0x2823: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2829:
	/* 0x2829: add    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_282c:
	/* 0x282c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_282f:
	/* 0x282f: jns    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x282f, 0x2748, x86_l_2748);
x86_l_2835:
	/* 0x2835: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2839:
	/* 0x2839: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_283c:
	/* 0x283c: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_283f:
	/* 0x283f: je     289e <trace_fd_install+0x289e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283f, 0x289e, x86_l_289e);
x86_l_2841:
	/* 0x2841: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2845:
	/* 0x2845: movzx  ebp,BYTE PTR [rsi+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_284a:
	/* 0x284a: mov    BYTE PTR [rdi+r11*1],bpl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RBP, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_284e:
	/* 0x284e: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2851:
	/* 0x2851: test   bpl,bpl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_8, 0, 0);
x86_l_2854:
	/* 0x2854: jne    283c <trace_fd_install+0x283c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2854, 0x283c, x86_l_283c);
x86_l_2856:
	/* 0x2856: mov    r9d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2859:
	/* 0x2859: jmp    28a3 <trace_fd_install+0x28a3> */
	X86_SIM_X86_JMP(0x2859, 0x28a3, x86_l_28a3);
x86_l_285b:
	/* 0x285b: cmp    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_285e:
	/* 0x285e: jne    28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x285e, 0x28d0, x86_l_28d0);
x86_l_2860:
	/* 0x2860: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2863:
	/* 0x2863: je     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2863, 0x28d0, x86_l_28d0);
x86_l_2865:
	/* 0x2865: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2869:
	/* 0x2869: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_286c:
	/* 0x286c: jns    2873 <trace_fd_install+0x2873> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x286c, 0x2873, x86_l_2873);
x86_l_286e:
	/* 0x286e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2871:
	/* 0x2871: jmp    2875 <trace_fd_install+0x2875> */
	X86_SIM_X86_JMP(0x2871, 0x2875, x86_l_2875);
x86_l_2873:
	/* 0x2873: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2875:
	/* 0x2875: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2878:
	/* 0x2878: jns    287f <trace_fd_install+0x287f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2878, 0x287f, x86_l_287f);
x86_l_287a:
	/* 0x287a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_287d:
	/* 0x287d: jmp    2881 <trace_fd_install+0x2881> */
	X86_SIM_X86_JMP(0x287d, 0x2881, x86_l_2881);
x86_l_287f:
	/* 0x287f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2881:
	/* 0x2881: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2884:
	/* 0x2884: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2887:
	/* 0x2887: jns    288e <trace_fd_install+0x288e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2887, 0x288e, x86_l_288e);
x86_l_2889:
	/* 0x2889: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_288c:
	/* 0x288c: jmp    2890 <trace_fd_install+0x2890> */
	X86_SIM_X86_JMP(0x288c, 0x2890, x86_l_2890);
x86_l_288e:
	/* 0x288e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2890:
	/* 0x2890: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2894:
	/* 0x2894: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2897:
	/* 0x2897: jns    28c0 <trace_fd_install+0x28c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2897, 0x28c0, x86_l_28c0);
x86_l_2899:
	/* 0x2899: mov    rdi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_289c:
	/* 0x289c: jmp    28c2 <trace_fd_install+0x28c2> */
	X86_SIM_X86_JMP(0x289c, 0x28c2, x86_l_28c2);
x86_l_289e:
	/* 0x289e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_28a3:
	/* 0x28a3: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_28a7:
	/* 0x28a7: jl     28d0 <trace_fd_install+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_L, 0x28a7, 0x28d0, x86_l_28d0);
x86_l_28a9:
	/* 0x28a9: lea    esi,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_28ad:
	/* 0x28ad: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_28b3:
	/* 0x28b3: mov    BYTE PTR [r12+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_28b8:
	/* 0x28b8: sub    r15d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28bb:
	/* 0x28bb: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_28be:
	/* 0x28be: js     2899 <trace_fd_install+0x2899> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28be, 0x2899, x86_l_2899);
x86_l_28c0:
	/* 0x28c0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c2:
	/* 0x28c2: lea    rsi,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28c6:
	/* 0x28c6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28c9:
	/* 0x28c9: jns    28e3 <trace_fd_install+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28c9, 0x28e3, x86_l_28e3);
x86_l_28cb:
	/* 0x28cb: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ce:
	/* 0x28ce: jmp    28e5 <trace_fd_install+0x28e5> */
	X86_SIM_X86_JMP(0x28ce, 0x28e5, x86_l_28e5);
x86_l_28d0:
	/* 0x28d0: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_28d3:
	/* 0x28d3: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_28d6:
	/* 0x28d6: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28db:
	/* 0x28db: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_28de:
	/* 0x28de: jmp    1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JMP(0x28de, 0x1555, x86_l_1555);
x86_l_28e3:
	/* 0x28e3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28e5:
	/* 0x28e5: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28e8:
	/* 0x28e8: je     2a4a <trace_fd_install+0x2a4a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28e8, 0x2a4a, x86_l_2a4a);
x86_l_28ee:
	/* 0x28ee: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28f1:
	/* 0x28f1: je     2a4a <trace_fd_install+0x2a4a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28f1, 0x2a4a, x86_l_2a4a);
x86_l_28f7:
	/* 0x28f7: lea    rdx,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28fb:
	/* 0x28fb: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28fe:
	/* 0x28fe: mov    ecx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2903:
	/* 0x2903: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2906:
	/* 0x2906: jns    290f <trace_fd_install+0x290f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2906, 0x290f, x86_l_290f);
x86_l_2908:
	/* 0x2908: mov    r9,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_290b:
	/* 0x290b: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_290f:
	/* 0x290f: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2913:
	/* 0x2913: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2916:
	/* 0x2916: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_291d:
	/* 0x291d: mov    edx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2920:
	/* 0x2920: sub    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2923:
	/* 0x2923: jae    2a6a <trace_fd_install+0x2a6a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2923, 0x2a6a, x86_l_2a6a);
x86_l_2929:
	/* 0x2929: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_292c:
	/* 0x292c: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2931:
	/* 0x2931: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2934:
	/* 0x2934: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2936:
	/* 0x2936: and    ebx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_293c:
	/* 0x293c: mov    BYTE PTR [rax+rbx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 47ULL);
x86_l_2940:
	/* 0x2940: mov    BYTE PTR [rax+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2947:
	/* 0x2947: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_294a:
	/* 0x294a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_294d:
	/* 0x294d: jns    2954 <trace_fd_install+0x2954> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x294d, 0x2954, x86_l_2954);
x86_l_294f:
	/* 0x294f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2952:
	/* 0x2952: jmp    2956 <trace_fd_install+0x2956> */
	X86_SIM_X86_JMP(0x2952, 0x2956, x86_l_2956);
x86_l_2954:
	/* 0x2954: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2956:
	/* 0x2956: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_295f:
	/* 0x295f: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2968:
	/* 0x2968: lea    rcx,[rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_296c:
	/* 0x296c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_296f:
	/* 0x296f: jns    2976 <trace_fd_install+0x2976> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296f, 0x2976, x86_l_2976);
x86_l_2971:
	/* 0x2971: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2974:
	/* 0x2974: jmp    2978 <trace_fd_install+0x2978> */
	X86_SIM_X86_JMP(0x2974, 0x2978, x86_l_2978);
x86_l_2976:
	/* 0x2976: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2978:
	/* 0x2978: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_297d:
	/* 0x297d: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2981:
	/* 0x2981: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2984:
	/* 0x2984: jns    298c <trace_fd_install+0x298c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2984, 0x298c, x86_l_298c);
x86_l_2986:
	/* 0x2986: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2988:
	/* 0x2988: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_298a:
	/* 0x298a: jmp    298e <trace_fd_install+0x298e> */
	X86_SIM_X86_JMP(0x298a, 0x298e, x86_l_298e);
x86_l_298c:
	/* 0x298c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_298e:
	/* 0x298e: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2993:
	/* 0x2993: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2998:
	/* 0x2998: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_299b:
	/* 0x299b: jns    29a5 <trace_fd_install+0x29a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x299b, 0x29a5, x86_l_29a5);
x86_l_299d:
	/* 0x299d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29a0:
	/* 0x29a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29a3:
	/* 0x29a3: js     29b2 <trace_fd_install+0x29b2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29a3, 0x29b2, x86_l_29b2);
x86_l_29a5:
	/* 0x29a5: lea    rax,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29aa:
	/* 0x29aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29ad:
	/* 0x29ad: jns    29b2 <trace_fd_install+0x29b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ad, 0x29b2, x86_l_29b2);
x86_l_29af:
	/* 0x29af: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b2:
	/* 0x29b2: mov    rax,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_29b5:
	/* 0x29b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29b8:
	/* 0x29b8: jns    29bf <trace_fd_install+0x29bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29b8, 0x29bf, x86_l_29bf);
x86_l_29ba:
	/* 0x29ba: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29bd:
	/* 0x29bd: jmp    29c1 <trace_fd_install+0x29c1> */
	X86_SIM_X86_JMP(0x29bd, 0x29c1, x86_l_29c1);
x86_l_29bf:
	/* 0x29bf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c1:
	/* 0x29c1: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29c5:
	/* 0x29c5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c7:
	/* 0x29c7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29ca:
	/* 0x29ca: jns    29d6 <trace_fd_install+0x29d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ca, 0x29d6, x86_l_29d6);
x86_l_29cc:
	/* 0x29cc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29cf:
	/* 0x29cf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29d2:
	/* 0x29d2: js     29dd <trace_fd_install+0x29dd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29d2, 0x29dd, x86_l_29dd);
x86_l_29d4:
	/* 0x29d4: jmp    29df <trace_fd_install+0x29df> */
	X86_SIM_X86_JMP(0x29d4, 0x29df, x86_l_29df);
x86_l_29d6:
	/* 0x29d6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d8:
	/* 0x29d8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29db:
	/* 0x29db: jns    29df <trace_fd_install+0x29df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29db, 0x29df, x86_l_29df);
x86_l_29dd:
	/* 0x29dd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29df:
	/* 0x29df: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_29e2:
	/* 0x29e2: jns    29f4 <trace_fd_install+0x29f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29e2, 0x29f4, x86_l_29f4);
x86_l_29e4:
	/* 0x29e4: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29e7:
	/* 0x29e7: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29eb:
	/* 0x29eb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29ee:
	/* 0x29ee: js     29ff <trace_fd_install+0x29ff> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29ee, 0x29ff, x86_l_29ff);
x86_l_29f0:
	/* 0x29f0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f2:
	/* 0x29f2: jmp    2a02 <trace_fd_install+0x2a02> */
	X86_SIM_X86_JMP(0x29f2, 0x2a02, x86_l_2a02);
x86_l_29f4:
	/* 0x29f4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29f6:
	/* 0x29f6: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29fa:
	/* 0x29fa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29fd:
	/* 0x29fd: jns    29f0 <trace_fd_install+0x29f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29fd, 0x29f0, x86_l_29f0);
x86_l_29ff:
	/* 0x29ff: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a02:
	/* 0x2a02: mov    edx,DWORD PTR [rbp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2a05:
	/* 0x2a05: mov    DWORD PTR [rsp+0x30],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a09:
	/* 0x2a09: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2a0d:
	/* 0x2a0d: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a12:
	/* 0x2a12: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2a1a:
	/* 0x2a1a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)file_modification_map));
x86_l_2a21:
	/* 0x2a21: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a26:
	/* 0x2a26: lea    rdx,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2a2b:
	/* 0x2a2b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a2d:
	/* 0x2a2d: call   2a32 <trace_fd_install+0x2a32> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2a32:
	/* 0x2a32: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a34:
	/* 0x2a34: add    rsp,0xa8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_2a3b:
	/* 0x2a3b: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a3c:
	/* 0x2a3c: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a3e:
	/* 0x2a3e: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a40:
	/* 0x2a40: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a42:
	/* 0x2a42: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a44:
	/* 0x2a44: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a45:
	/* 0x2a45: jmp    2b05 <trace_fd_install+0x2b05> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2a4a:
	/* 0x2a4a: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a4d:
	/* 0x2a4d: jne    2afd <trace_fd_install+0x2afd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a4d, 0x2afd, x86_l_2afd);
x86_l_2a53:
	/* 0x2a53: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a56:
	/* 0x2a56: je     2afd <trace_fd_install+0x2afd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a56, 0x2afd, x86_l_2afd);
x86_l_2a5c:
	/* 0x2a5c: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a60:
	/* 0x2a60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a63:
	/* 0x2a63: jns    2aaa <trace_fd_install+0x2aaa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a63, 0x2aaa, x86_l_2aaa);
x86_l_2a65:
	/* 0x2a65: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a68:
	/* 0x2a68: jmp    2aac <trace_fd_install+0x2aac> */
	X86_SIM_X86_JMP(0x2a68, 0x2aac, x86_l_2aac);
x86_l_2a6a:
	/* 0x2a6a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2a6d:
	/* 0x2a6d: je     2afd <trace_fd_install+0x2afd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6d, 0x2afd, x86_l_2afd);
x86_l_2a73:
	/* 0x2a73: and    edx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a79:
	/* 0x2a79: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a7c:
	/* 0x2a7c: add    rdi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a7f:
	/* 0x2a7f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a82:
	/* 0x2a82: jns    2ac9 <trace_fd_install+0x2ac9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a82, 0x2ac9, x86_l_2ac9);
x86_l_2a84:
	/* 0x2a84: lea    edx,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a88:
	/* 0x2a88: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a8b:
	/* 0x2a8b: cmp    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2a8e:
	/* 0x2a8e: je     2ad1 <trace_fd_install+0x2ad1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a8e, 0x2ad1, x86_l_2ad1);
x86_l_2a90:
	/* 0x2a90: lea    r10,[r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a94:
	/* 0x2a94: movzx  r11d,BYTE PTR [rcx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_2a99:
	/* 0x2a99: mov    BYTE PTR [rdi+r8*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_2a9d:
	/* 0x2a9d: mov    r8,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_2aa0:
	/* 0x2aa0: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_2aa3:
	/* 0x2aa3: jne    2a8b <trace_fd_install+0x2a8b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aa3, 0x2a8b, x86_l_2a8b);
x86_l_2aa5:
	/* 0x2aa5: mov    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_2aa8:
	/* 0x2aa8: jmp    2ad5 <trace_fd_install+0x2ad5> */
	X86_SIM_X86_JMP(0x2aa8, 0x2ad5, x86_l_2ad5);
x86_l_2aaa:
	/* 0x2aaa: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aac:
	/* 0x2aac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2aaf:
	/* 0x2aaf: jns    2ab6 <trace_fd_install+0x2ab6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aaf, 0x2ab6, x86_l_2ab6);
x86_l_2ab1:
	/* 0x2ab1: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab4:
	/* 0x2ab4: jmp    2ab8 <trace_fd_install+0x2ab8> */
	X86_SIM_X86_JMP(0x2ab4, 0x2ab8, x86_l_2ab8);
x86_l_2ab6:
	/* 0x2ab6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ab8:
	/* 0x2ab8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2abb:
	/* 0x2abb: jns    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2abb, 0x28d3, x86_l_28d3);
x86_l_2ac1:
	/* 0x2ac1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ac4:
	/* 0x2ac4: jmp    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JMP(0x2ac4, 0x28d3, x86_l_28d3);
x86_l_2ac9:
	/* 0x2ac9: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2acc:
	/* 0x2acc: jmp    2748 <trace_fd_install+0x2748> */
	X86_SIM_X86_JMP(0x2acc, 0x2748, x86_l_2748);
x86_l_2ad1:
	/* 0x2ad1: mov    BYTE PTR [rdi+rdx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_2ad5:
	/* 0x2ad5: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2ad9:
	/* 0x2ad9: jl     2afd <trace_fd_install+0x2afd> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ad9, 0x2afd, x86_l_2afd);
x86_l_2adb:
	/* 0x2adb: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2ade:
	/* 0x2ade: lea    ecx,[r15-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ae2:
	/* 0x2ae2: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ae8:
	/* 0x2ae8: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2aeb:
	/* 0x2aeb: mov    BYTE PTR [r12+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2af0:
	/* 0x2af0: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2af3:
	/* 0x2af3: mov    rbp,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2af8:
	/* 0x2af8: jmp    1555 <trace_fd_install+0x1555> */
	X86_SIM_X86_JMP(0x2af8, 0x1555, x86_l_1555);
x86_l_2afd:
	/* 0x2afd: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b00:
	/* 0x2b00: jmp    28d3 <trace_fd_install+0x28d3> */
	X86_SIM_X86_JMP(0x2b00, 0x28d3, x86_l_28d3);
x86_l_2b05:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
