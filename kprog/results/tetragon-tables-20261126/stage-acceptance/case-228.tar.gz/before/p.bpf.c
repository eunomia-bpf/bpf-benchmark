#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 232U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(2) M(4) M(5) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(18) M(21) M(22)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/chmod_common")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xa4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704374636544ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_chmod_common+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x1300, x86_l_1300);
x86_l_3c:
	/* 0x3c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_chmod_common+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x1300, x86_l_1300);
x86_l_5c:
	/* 0x5c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9e:
	/* 0x9e: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a9:
	/* 0xa9: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b4:
	/* 0xb4: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bf:
	/* 0xbf: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ca:
	/* 0xca: call   cf <trace_chmod_common+0xcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f6:
	/* 0xf6: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_116:
	/* 0x116: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11e:
	/* 0x11e: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12e:
	/* 0x12e: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13e:
	/* 0x13e: call   143 <trace_chmod_common+0x143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_143:
	/* 0x143: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [rbp+0x70],0x317 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337943ULL);
x86_l_154:
	/* 0x154: call   159 <trace_chmod_common+0x159> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d:
	/* 0x15d: call   162 <trace_chmod_common+0x162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_162:
	/* 0x162: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_166:
	/* 0x166: call   16b <trace_chmod_common+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16b:
	/* 0x16b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: jns    186 <trace_chmod_common+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175, 0x186, x86_l_186);
x86_l_177:
	/* 0x177: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17e:
	/* 0x17e: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_184:
	/* 0x184: jne    1c3 <trace_chmod_common+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184, 0x1c3, x86_l_1c3);
x86_l_186:
	/* 0x186: call   18b <trace_chmod_common+0x18b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18b:
	/* 0x18b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: call   193 <trace_chmod_common+0x193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_193:
	/* 0x193: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: jns    1aa <trace_chmod_common+0x1aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19a, 0x1aa, x86_l_1aa);
x86_l_19c:
	/* 0x19c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1a3:
	/* 0x1a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     1b5 <trace_chmod_common+0x1b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a6, 0x1b5, x86_l_1b5);
x86_l_1a8:
	/* 0x1a8: jmp    1bf <trace_chmod_common+0x1bf> */
	X86_SIM_X86_JMP(0x1a8, 0x1bf, x86_l_1bf);
x86_l_1aa:
	/* 0x1aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac:
	/* 0x1ac: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1b0:
	/* 0x1b0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: jns    1bf <trace_chmod_common+0x1bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3, 0x1bf, x86_l_1bf);
x86_l_1b5:
	/* 0x1b5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7:
	/* 0x1b7: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b9:
	/* 0x1b9: jne    558 <trace_chmod_common+0x558> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b9, 0x558, x86_l_558);
x86_l_1bf:
	/* 0x1bf: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [r13+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1cb:
	/* 0x1cb: mov    DWORD PTR [rsp+0xa0],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1d2:
	/* 0x1d2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d9:
	/* 0x1d9: lea    rsi,[rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1e1:
	/* 0x1e1: call   1e6 <trace_chmod_common+0x1e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e6:
	/* 0x1e6: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1ee:
	/* 0x1ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f1:
	/* 0x1f1: je     11e5 <trace_chmod_common+0x11e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1, 0x11e5, x86_l_11e5);
x86_l_1f7:
	/* 0x1f7: mov    eax,DWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fb:
	/* 0x1fb: mov    DWORD PTR [rsp+0x9c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_202:
	/* 0x202: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_209:
	/* 0x209: lea    rsi,[rsp+0x9c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_211:
	/* 0x211: call   216 <trace_chmod_common+0x216> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_216:
	/* 0x216: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_219:
	/* 0x219: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21c:
	/* 0x21c: mov    QWORD PTR [rsp+0x28],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_221:
	/* 0x221: mov    QWORD PTR [rsp],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225:
	/* 0x225: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: mov    QWORD PTR [rsp+0x20],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22d:
	/* 0x22d: je     126b <trace_chmod_common+0x126b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22d, 0x126b, x86_l_126b);
x86_l_233:
	/* 0x233: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_239:
	/* 0x239: jne    242 <trace_chmod_common+0x242> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x239, 0x242, x86_l_242);
x86_l_23b:
	/* 0x23b: call   240 <trace_chmod_common+0x240> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_240:
	/* 0x240: jmp    29a <trace_chmod_common+0x29a> */
	X86_SIM_X86_JMP(0x240, 0x29a, x86_l_29a);
x86_l_242:
	/* 0x242: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_247:
	/* 0x247: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_24e:
	/* 0x24e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_251:
	/* 0x251: jns    26b <trace_chmod_common+0x26b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x251, 0x26b, x86_l_26b);
x86_l_253:
	/* 0x253: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_256:
	/* 0x256: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_259:
	/* 0x259: js     272 <trace_chmod_common+0x272> */
	X86_SIM_X86_JCC(X86_CC_S, 0x259, 0x272, x86_l_272);
x86_l_25b:
	/* 0x25b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25d:
	/* 0x25d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_260:
	/* 0x260: js     27a <trace_chmod_common+0x27a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x260, 0x27a, x86_l_27a);
x86_l_262:
	/* 0x262: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_264:
	/* 0x264: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_267:
	/* 0x267: js     282 <trace_chmod_common+0x282> */
	X86_SIM_X86_JCC(X86_CC_S, 0x267, 0x282, x86_l_282);
x86_l_269:
	/* 0x269: jmp    298 <trace_chmod_common+0x298> */
	X86_SIM_X86_JMP(0x269, 0x298, x86_l_298);
x86_l_26b:
	/* 0x26b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26d:
	/* 0x26d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_270:
	/* 0x270: jns    25b <trace_chmod_common+0x25b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x270, 0x25b, x86_l_25b);
x86_l_272:
	/* 0x272: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_275:
	/* 0x275: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_278:
	/* 0x278: jns    262 <trace_chmod_common+0x262> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x278, 0x262, x86_l_262);
x86_l_27a:
	/* 0x27a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d:
	/* 0x27d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_280:
	/* 0x280: jns    298 <trace_chmod_common+0x298> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x280, 0x298, x86_l_298);
x86_l_282:
	/* 0x282: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_285:
	/* 0x285: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_288:
	/* 0x288: je     298 <trace_chmod_common+0x298> */
	X86_SIM_X86_JCC(X86_CC_E, 0x288, 0x298, x86_l_298);
x86_l_28a:
	/* 0x28a: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_28e:
	/* 0x28e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_291:
	/* 0x291: jns    298 <trace_chmod_common+0x298> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x291, 0x298, x86_l_298);
x86_l_293:
	/* 0x293: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_296:
	/* 0x296: jmp    29a <trace_chmod_common+0x29a> */
	X86_SIM_X86_JMP(0x296, 0x29a, x86_l_29a);
x86_l_298:
	/* 0x298: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29a:
	/* 0x29a: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29e:
	/* 0x29e: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a2:
	/* 0x2a2: mov    DWORD PTR [rsp+0x1c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2a6:
	/* 0x2a6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_2ad:
	/* 0x2ad: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2b2:
	/* 0x2b2: call   2b7 <trace_chmod_common+0x2b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2b7:
	/* 0x2b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ba:
	/* 0x2ba: je     2d2 <trace_chmod_common+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ba, 0x2d2, x86_l_2d2);
x86_l_2bc:
	/* 0x2bc: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2bf:
	/* 0x2bf: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2c5:
	/* 0x2c5: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2c8:
	/* 0x2c8: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2cb:
	/* 0x2cb: jne    2d2 <trace_chmod_common+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cb, 0x2d2, x86_l_2d2);
x86_l_2cd:
	/* 0x2cd: or     BYTE PTR [r13+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2d2:
	/* 0x2d2: movzx  eax,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2d7:
	/* 0x2d7: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2dd:
	/* 0x2dd: jne    1307 <trace_chmod_common+0x1307> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2dd, 0x1307, x86_l_1307);
x86_l_2e3:
	/* 0x2e3: mov    QWORD PTR [r13+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2ee:
	/* 0x2ee: mov    DWORD PTR [rsp+0x40],0x317 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907735ULL);
x86_l_2f6:
	/* 0x2f6: mov    WORD PTR [rsp+0x34],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2fb:
	/* 0x2fb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_302:
	/* 0x302: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_307:
	/* 0x307: call   30c <trace_chmod_common+0x30c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_30c:
	/* 0x30c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30f:
	/* 0x30f: je     37a <trace_chmod_common+0x37a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30f, 0x37a, x86_l_37a);
x86_l_311:
	/* 0x311: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_316:
	/* 0x316: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_319:
	/* 0x319: call   31e <trace_chmod_common+0x31e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_31e:
	/* 0x31e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_321:
	/* 0x321: je     37a <trace_chmod_common+0x37a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x321, 0x37a, x86_l_37a);
x86_l_323:
	/* 0x323: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_327:
	/* 0x327: mov    QWORD PTR [r13+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_32e:
	/* 0x32e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_331:
	/* 0x331: mov    QWORD PTR [r13+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_338:
	/* 0x338: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33c:
	/* 0x33c: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_340:
	/* 0x340: mov    QWORD PTR [r13+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_347:
	/* 0x347: mov    QWORD PTR [r13+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_34e:
	/* 0x34e: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_352:
	/* 0x352: mov    QWORD PTR [r13+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_359:
	/* 0x359: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_35d:
	/* 0x35d: mov    QWORD PTR [r13+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_364:
	/* 0x364: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_368:
	/* 0x368: mov    QWORD PTR [r13+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_36f:
	/* 0x36f: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_373:
	/* 0x373: mov    QWORD PTR [r13+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_37a:
	/* 0x37a: mov    rax,QWORD PTR [r13+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_381:
	/* 0x381: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_388:
	/* 0x388: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38c:
	/* 0x38c: cmp    ecx,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_390:
	/* 0x390: mov    QWORD PTR [rsp+0xb0],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_398:
	/* 0x398: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39d:
	/* 0x39d: jne    3bc <trace_chmod_common+0x3bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x39d, 0x3bc, x86_l_3bc);
x86_l_39f:
	/* 0x39f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a2:
	/* 0x3a2: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3a5:
	/* 0x3a5: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3ac:
	/* 0x3ac: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3b1:
	/* 0x3b1: jne    c54 <trace_chmod_common+0xc54> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b1, 0xc54, x86_l_c54);
x86_l_3b7:
	/* 0x3b7: jmp    2fbd <trace_chmod_common+0x2fbd> */
	X86_SIM_X86_JMP(0x3b7, 0x2fbd, x86_l_2fbd);
x86_l_3bc:
	/* 0x3bc: mov    rax,QWORD PTR [r13+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_3c3:
	/* 0x3c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3c6:
	/* 0x3c6: je     579 <trace_chmod_common+0x579> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3c6, 0x579, x86_l_579);
x86_l_3cc:
	/* 0x3cc: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_3d3:
	/* 0x3d3: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_3d6:
	/* 0x3d6: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d9:
	/* 0x3d9: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3dc:
	/* 0x3dc: sete   r12b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3e0:
	/* 0x3e0: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3e3:
	/* 0x3e3: neg    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3e6:
	/* 0x3e6: xor    r12,QWORD PTR [r13+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_3ed:
	/* 0x3ed: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3f0:
	/* 0x3f0: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_3f7:
	/* 0x3f7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3fa:
	/* 0x3fa: je     41b <trace_chmod_common+0x41b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3fa, 0x41b, x86_l_41b);
x86_l_3fc:
	/* 0x3fc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fe:
	/* 0x3fe: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_405:
	/* 0x405: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_408:
	/* 0x408: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_40b:
	/* 0x40b: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_40e:
	/* 0x40e: xor    rcx,QWORD PTR [r13+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_415:
	/* 0x415: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_418:
	/* 0x418: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_41b:
	/* 0x41b: mov    rax,QWORD PTR [r13+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_422:
	/* 0x422: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_425:
	/* 0x425: je     441 <trace_chmod_common+0x441> */
	X86_SIM_X86_JCC(X86_CC_E, 0x425, 0x441, x86_l_441);
x86_l_427:
	/* 0x427: mov    ecx,DWORD PTR [r13+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_42b:
	/* 0x42b: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_42e:
	/* 0x42e: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_431:
	/* 0x431: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_434:
	/* 0x434: xor    rcx,QWORD PTR [r13+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_43b:
	/* 0x43b: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_43e:
	/* 0x43e: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_441:
	/* 0x441: mov    rax,QWORD PTR [r13+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_448:
	/* 0x448: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44b:
	/* 0x44b: je     46c <trace_chmod_common+0x46c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x44b, 0x46c, x86_l_46c);
x86_l_44d:
	/* 0x44d: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_450:
	/* 0x450: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_458:
	/* 0x458: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_45c:
	/* 0x45c: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_45f:
	/* 0x45f: xor    rcx,QWORD PTR [r13+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_466:
	/* 0x466: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_469:
	/* 0x469: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_46c:
	/* 0x46c: movzx  r14d,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_471:
	/* 0x471: mov    rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_474:
	/* 0x474: mov    r13,QWORD PTR [r13+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_47b:
	/* 0x47b: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_47e:
	/* 0x47e: mov    WORD PTR [rsp+0xe],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_484:
	/* 0x484: je     5df <trace_chmod_common+0x5df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x484, 0x5df, x86_l_5df);
x86_l_48a:
	/* 0x48a: mov    rax,QWORD PTR [rbx+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_491:
	/* 0x491: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_499:
	/* 0x499: mov    rbp,QWORD PTR [rbx+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_4a0:
	/* 0x4a0: mov    rax,QWORD PTR [rbx+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_4a7:
	/* 0x4a7: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4ac:
	/* 0x4ac: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4b2:
	/* 0x4b2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_4b9:
	/* 0x4b9: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4be:
	/* 0x4be: call   4c3 <trace_chmod_common+0x4c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4c3:
	/* 0x4c3: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4c6:
	/* 0x4c6: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4c9:
	/* 0x4c9: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4ce:
	/* 0x4ce: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4d5:
	/* 0x4d5: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4d8:
	/* 0x4d8: je     4f8 <trace_chmod_common+0x4f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d8, 0x4f8, x86_l_4f8);
x86_l_4da:
	/* 0x4da: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_4df:
	/* 0x4df: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4e2:
	/* 0x4e2: call   4e7 <trace_chmod_common+0x4e7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4e7:
	/* 0x4e7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ea:
	/* 0x4ea: je     4f8 <trace_chmod_common+0x4f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4ea, 0x4f8, x86_l_4f8);
x86_l_4ec:
	/* 0x4ec: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ef:
	/* 0x4ef: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4f3:
	/* 0x4f3: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4f6:
	/* 0x4f6: jmp    4fa <trace_chmod_common+0x4fa> */
	X86_SIM_X86_JMP(0x4f6, 0x4fa, x86_l_4fa);
x86_l_4f8:
	/* 0x4f8: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4fa:
	/* 0x4fa: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_4ff:
	/* 0x4ff: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_504:
	/* 0x504: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_507:
	/* 0x507: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_50a:
	/* 0x50a: jb     522 <trace_chmod_common+0x522> */
	X86_SIM_X86_JCC(X86_CC_B, 0x50a, 0x522, x86_l_522);
x86_l_50c:
	/* 0x50c: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_510:
	/* 0x510: je     517 <trace_chmod_common+0x517> */
	X86_SIM_X86_JCC(X86_CC_E, 0x510, 0x517, x86_l_517);
x86_l_512:
	/* 0x512: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_515:
	/* 0x515: jbe    522 <trace_chmod_common+0x522> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x515, 0x522, x86_l_522);
x86_l_517:
	/* 0x517: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_51f:
	/* 0x51f: or     rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_522:
	/* 0x522: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_526:
	/* 0x526: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_529:
	/* 0x529: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_52e:
	/* 0x52e: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_535:
	/* 0x535: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_538:
	/* 0x538: je     595 <trace_chmod_common+0x595> */
	X86_SIM_X86_JCC(X86_CC_E, 0x538, 0x595, x86_l_595);
x86_l_53a:
	/* 0x53a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_53f:
	/* 0x53f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_542:
	/* 0x542: call   547 <trace_chmod_common+0x547> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_547:
	/* 0x547: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54a:
	/* 0x54a: je     5a6 <trace_chmod_common+0x5a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54a, 0x5a6, x86_l_5a6);
x86_l_54c:
	/* 0x54c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54f:
	/* 0x54f: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_553:
	/* 0x553: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_556:
	/* 0x556: jmp    5a8 <trace_chmod_common+0x5a8> */
	X86_SIM_X86_JMP(0x556, 0x5a8, x86_l_5a8);
x86_l_558:
	/* 0x558: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_55f:
	/* 0x55f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_564:
	/* 0x564: call   569 <trace_chmod_common+0x569> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_569:
	/* 0x569: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56c:
	/* 0x56c: je     ddd <trace_chmod_common+0xddd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56c, 0xddd, x86_l_ddd);
x86_l_572:
	/* 0x572: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_574:
	/* 0x574: jmp    1c3 <trace_chmod_common+0x1c3> */
	X86_SIM_X86_JMP(0x574, 0x1c3, x86_l_1c3);
x86_l_579:
	/* 0x579: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_580:
	/* 0x580: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_587:
	/* 0x587: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58a:
	/* 0x58a: jne    3fc <trace_chmod_common+0x3fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x58a, 0x3fc, x86_l_3fc);
x86_l_590:
	/* 0x590: jmp    41b <trace_chmod_common+0x41b> */
	X86_SIM_X86_JMP(0x590, 0x41b, x86_l_41b);
x86_l_595:
	/* 0x595: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_597:
	/* 0x597: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_59a:
	/* 0x59a: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_59f:
	/* 0x59f: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a2:
	/* 0x5a2: jae    5ba <trace_chmod_common+0x5ba> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5a2, 0x5ba, x86_l_5ba);
x86_l_5a4:
	/* 0x5a4: jmp    5d0 <trace_chmod_common+0x5d0> */
	X86_SIM_X86_JMP(0x5a4, 0x5d0, x86_l_5d0);
x86_l_5a6:
	/* 0x5a6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5a8:
	/* 0x5a8: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_5ad:
	/* 0x5ad: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5b0:
	/* 0x5b0: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5b5:
	/* 0x5b5: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b8:
	/* 0x5b8: jb     5d0 <trace_chmod_common+0x5d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5b8, 0x5d0, x86_l_5d0);
x86_l_5ba:
	/* 0x5ba: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5be:
	/* 0x5be: je     5c5 <trace_chmod_common+0x5c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5be, 0x5c5, x86_l_5c5);
x86_l_5c0:
	/* 0x5c0: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5c3:
	/* 0x5c3: jbe    5d0 <trace_chmod_common+0x5d0> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5c3, 0x5d0, x86_l_5d0);
x86_l_5c5:
	/* 0x5c5: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_5cd:
	/* 0x5cd: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5d0:
	/* 0x5d0: or     rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5d3:
	/* 0x5d3: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5d6:
	/* 0x5d6: and    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_5d9:
	/* 0x5d9: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_5df:
	/* 0x5df: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e3:
	/* 0x5e3: cmp    QWORD PTR [r13+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_5eb:
	/* 0x5eb: je     689 <trace_chmod_common+0x689> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5eb, 0x689, x86_l_689);
x86_l_5f1:
	/* 0x5f1: call   5f6 <trace_chmod_common+0x5f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_5f6:
	/* 0x5f6: mov    DWORD PTR [r13+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5fa:
	/* 0x5fa: mov    rbx,QWORD PTR [r13+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_601:
	/* 0x601: mov    rax,QWORD PTR [r13+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_608:
	/* 0x608: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_60d:
	/* 0x60d: mov    rbp,QWORD PTR [r13+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_614:
	/* 0x614: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_617:
	/* 0x617: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_61a:
	/* 0x61a: mov    r13,QWORD PTR [r13+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_621:
	/* 0x621: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_626:
	/* 0x626: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_62d:
	/* 0x62d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_632:
	/* 0x632: call   637 <trace_chmod_common+0x637> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_637:
	/* 0x637: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_63b:
	/* 0x63b: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_640:
	/* 0x640: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_647:
	/* 0x647: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64a:
	/* 0x64a: je     66a <trace_chmod_common+0x66a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64a, 0x66a, x86_l_66a);
x86_l_64c:
	/* 0x64c: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_651:
	/* 0x651: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_654:
	/* 0x654: call   659 <trace_chmod_common+0x659> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_659:
	/* 0x659: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_65c:
	/* 0x65c: je     66a <trace_chmod_common+0x66a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65c, 0x66a, x86_l_66a);
x86_l_65e:
	/* 0x65e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_661:
	/* 0x661: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_665:
	/* 0x665: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_668:
	/* 0x668: jmp    66c <trace_chmod_common+0x66c> */
	X86_SIM_X86_JMP(0x668, 0x66c, x86_l_66c);
x86_l_66a:
	/* 0x66a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_66c:
	/* 0x66c: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_672:
	/* 0x672: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_675:
	/* 0x675: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_67a:
	/* 0x67a: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_67d:
	/* 0x67d: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_680:
	/* 0x680: jae    69d <trace_chmod_common+0x69d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x680, 0x69d, x86_l_69d);
x86_l_682:
	/* 0x682: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_687:
	/* 0x687: jmp    6b5 <trace_chmod_common+0x6b5> */
	X86_SIM_X86_JMP(0x687, 0x6b5, x86_l_6b5);
x86_l_689:
	/* 0x689: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_68e:
	/* 0x68e: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_696:
	/* 0x696: jne    6cd <trace_chmod_common+0x6cd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x696, 0x6cd, x86_l_6cd);
x86_l_698:
	/* 0x698: jmp    76c <trace_chmod_common+0x76c> */
	X86_SIM_X86_JMP(0x698, 0x76c, x86_l_76c);
x86_l_69d:
	/* 0x69d: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6a1:
	/* 0x6a1: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6a6:
	/* 0x6a6: je     6ad <trace_chmod_common+0x6ad> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a6, 0x6ad, x86_l_6ad);
x86_l_6a8:
	/* 0x6a8: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6ab:
	/* 0x6ab: jbe    6b5 <trace_chmod_common+0x6b5> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x6ab, 0x6b5, x86_l_6b5);
x86_l_6ad:
	/* 0x6ad: and    r15,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 56ULL);
x86_l_6b2:
	/* 0x6b2: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6b5:
	/* 0x6b5: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6b8:
	/* 0x6b8: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_6bb:
	/* 0x6bb: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6bf:
	/* 0x6bf: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6c7:
	/* 0x6c7: je     76c <trace_chmod_common+0x76c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c7, 0x76c, x86_l_76c);
x86_l_6cd:
	/* 0x6cd: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6d2:
	/* 0x6d2: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6d9:
	/* 0x6d9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6dc:
	/* 0x6dc: jns    6e3 <trace_chmod_common+0x6e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6dc, 0x6e3, x86_l_6e3);
x86_l_6de:
	/* 0x6de: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e1:
	/* 0x6e1: jmp    6e5 <trace_chmod_common+0x6e5> */
	X86_SIM_X86_JMP(0x6e1, 0x6e5, x86_l_6e5);
x86_l_6e3:
	/* 0x6e3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e5:
	/* 0x6e5: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6e9:
	/* 0x6e9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6eb:
	/* 0x6eb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ee:
	/* 0x6ee: jns    6fa <trace_chmod_common+0x6fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6ee, 0x6fa, x86_l_6fa);
x86_l_6f0:
	/* 0x6f0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f3:
	/* 0x6f3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6f6:
	/* 0x6f6: js     701 <trace_chmod_common+0x701> */
	X86_SIM_X86_JCC(X86_CC_S, 0x6f6, 0x701, x86_l_701);
x86_l_6f8:
	/* 0x6f8: jmp    703 <trace_chmod_common+0x703> */
	X86_SIM_X86_JMP(0x6f8, 0x703, x86_l_703);
x86_l_6fa:
	/* 0x6fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6fc:
	/* 0x6fc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ff:
	/* 0x6ff: jns    703 <trace_chmod_common+0x703> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6ff, 0x703, x86_l_703);
x86_l_701:
	/* 0x701: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_703:
	/* 0x703: mov    DWORD PTR [r13+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_707:
	/* 0x707: mov    rbx,QWORD PTR [r13+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_70e:
	/* 0x70e: mov    r15,QWORD PTR [r13+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_715:
	/* 0x715: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_718:
	/* 0x718: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_71e:
	/* 0x71e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_725:
	/* 0x725: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_72a:
	/* 0x72a: call   72f <trace_chmod_common+0x72f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_72f:
	/* 0x72f: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_736:
	/* 0x736: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_739:
	/* 0x739: je     758 <trace_chmod_common+0x758> */
	X86_SIM_X86_JCC(X86_CC_E, 0x739, 0x758, x86_l_758);
x86_l_73b:
	/* 0x73b: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_73f:
	/* 0x73f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_742:
	/* 0x742: call   747 <trace_chmod_common+0x747> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_747:
	/* 0x747: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_74a:
	/* 0x74a: je     758 <trace_chmod_common+0x758> */
	X86_SIM_X86_JCC(X86_CC_E, 0x74a, 0x758, x86_l_758);
x86_l_74c:
	/* 0x74c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_74f:
	/* 0x74f: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_753:
	/* 0x753: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_756:
	/* 0x756: jmp    75a <trace_chmod_common+0x75a> */
	X86_SIM_X86_JMP(0x756, 0x75a, x86_l_75a);
x86_l_758:
	/* 0x758: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_75a:
	/* 0x75a: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_75d:
	/* 0x75d: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_760:
	/* 0x760: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_763:
	/* 0x763: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_766:
	/* 0x766: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_76c:
	/* 0x76c: cmp    QWORD PTR [r13+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_774:
	/* 0x774: je     83d <trace_chmod_common+0x83d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x774, 0x83d, x86_l_83d);
x86_l_77a:
	/* 0x77a: mov    rcx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_781:
	/* 0x781: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_785:
	/* 0x785: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_787:
	/* 0x787: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_78a:
	/* 0x78a: jns    799 <trace_chmod_common+0x799> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x78a, 0x799, x86_l_799);
x86_l_78c:
	/* 0x78c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_78f:
	/* 0x78f: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_792:
	/* 0x792: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_795:
	/* 0x795: js     7a3 <trace_chmod_common+0x7a3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x795, 0x7a3, x86_l_7a3);
x86_l_797:
	/* 0x797: jmp    7a5 <trace_chmod_common+0x7a5> */
	X86_SIM_X86_JMP(0x797, 0x7a5, x86_l_7a5);
x86_l_799:
	/* 0x799: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_79b:
	/* 0x79b: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_79e:
	/* 0x79e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_7a1:
	/* 0x7a1: jns    7a5 <trace_chmod_common+0x7a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7a1, 0x7a5, x86_l_7a5);
x86_l_7a3:
	/* 0x7a3: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7a5:
	/* 0x7a5: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_7a7:
	/* 0x7a7: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_7ab:
	/* 0x7ab: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7ae:
	/* 0x7ae: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7b2:
	/* 0x7b2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7b4:
	/* 0x7b4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7b7:
	/* 0x7b7: jns    7c7 <trace_chmod_common+0x7c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7b7, 0x7c7, x86_l_7c7);
x86_l_7b9:
	/* 0x7b9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7bc:
	/* 0x7bc: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7c0:
	/* 0x7c0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7c3:
	/* 0x7c3: js     7d2 <trace_chmod_common+0x7d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7c3, 0x7d2, x86_l_7d2);
x86_l_7c5:
	/* 0x7c5: jmp    7d4 <trace_chmod_common+0x7d4> */
	X86_SIM_X86_JMP(0x7c5, 0x7d4, x86_l_7d4);
x86_l_7c7:
	/* 0x7c7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7c9:
	/* 0x7c9: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7cd:
	/* 0x7cd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7d0:
	/* 0x7d0: jns    7d4 <trace_chmod_common+0x7d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7d0, 0x7d4, x86_l_7d4);
x86_l_7d2:
	/* 0x7d2: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7d4:
	/* 0x7d4: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7d8:
	/* 0x7d8: mov    rbx,QWORD PTR [r13+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_7df:
	/* 0x7df: mov    r15,QWORD PTR [r13+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_7e6:
	/* 0x7e6: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7e9:
	/* 0x7e9: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7ef:
	/* 0x7ef: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_7f6:
	/* 0x7f6: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7fb:
	/* 0x7fb: call   800 <trace_chmod_common+0x800> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_800:
	/* 0x800: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_807:
	/* 0x807: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_80a:
	/* 0x80a: je     829 <trace_chmod_common+0x829> */
	X86_SIM_X86_JCC(X86_CC_E, 0x80a, 0x829, x86_l_829);
x86_l_80c:
	/* 0x80c: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_810:
	/* 0x810: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_813:
	/* 0x813: call   818 <trace_chmod_common+0x818> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_818:
	/* 0x818: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_81b:
	/* 0x81b: je     829 <trace_chmod_common+0x829> */
	X86_SIM_X86_JCC(X86_CC_E, 0x81b, 0x829, x86_l_829);
x86_l_81d:
	/* 0x81d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_820:
	/* 0x820: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_824:
	/* 0x824: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_827:
	/* 0x827: jmp    82b <trace_chmod_common+0x82b> */
	X86_SIM_X86_JMP(0x827, 0x82b, x86_l_82b);
x86_l_829:
	/* 0x829: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82b:
	/* 0x82b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_82e:
	/* 0x82e: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_831:
	/* 0x831: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_834:
	/* 0x834: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_837:
	/* 0x837: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_83d:
	/* 0x83d: cmp    QWORD PTR [r13+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_845:
	/* 0x845: je     a21 <trace_chmod_common+0xa21> */
	X86_SIM_X86_JCC(X86_CC_E, 0x845, 0xa21, x86_l_a21);
x86_l_84b:
	/* 0x84b: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_850:
	/* 0x850: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_857:
	/* 0x857: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85a:
	/* 0x85a: jns    86d <trace_chmod_common+0x86d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x85a, 0x86d, x86_l_86d);
x86_l_85c:
	/* 0x85c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_85f:
	/* 0x85f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_862:
	/* 0x862: js     874 <trace_chmod_common+0x874> */
	X86_SIM_X86_JCC(X86_CC_S, 0x862, 0x874, x86_l_874);
x86_l_864:
	/* 0x864: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_866:
	/* 0x866: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_869:
	/* 0x869: js     87c <trace_chmod_common+0x87c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x869, 0x87c, x86_l_87c);
x86_l_86b:
	/* 0x86b: jmp    8c7 <trace_chmod_common+0x8c7> */
	X86_SIM_X86_JMP(0x86b, 0x8c7, x86_l_8c7);
x86_l_86d:
	/* 0x86d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_86f:
	/* 0x86f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_872:
	/* 0x872: jns    864 <trace_chmod_common+0x864> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x872, 0x864, x86_l_864);
x86_l_874:
	/* 0x874: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_877:
	/* 0x877: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_87a:
	/* 0x87a: jns    8c7 <trace_chmod_common+0x8c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x87a, 0x8c7, x86_l_8c7);
x86_l_87c:
	/* 0x87c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_87f:
	/* 0x87f: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_884:
	/* 0x884: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_888:
	/* 0x888: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_88d:
	/* 0x88d: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_891:
	/* 0x891: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_896:
	/* 0x896: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_89a:
	/* 0x89a: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_89f:
	/* 0x89f: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8a3:
	/* 0x8a3: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_8a8:
	/* 0x8a8: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8ac:
	/* 0x8ac: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_8b1:
	/* 0x8b1: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8b5:
	/* 0x8b5: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8ba:
	/* 0x8ba: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8be:
	/* 0x8be: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_8c3:
	/* 0x8c3: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_8c7:
	/* 0x8c7: lea    r15,[rbp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_8cb:
	/* 0x8cb: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_8d0:
	/* 0x8d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8d3:
	/* 0x8d3: jns    9aa <trace_chmod_common+0x9aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8d3, 0x9aa, x86_l_9aa);
x86_l_8d9:
	/* 0x8d9: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8dc:
	/* 0x8dc: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8df:
	/* 0x8df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8e1:
	/* 0x8e1: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e1, 0x9b9, x86_l_9b9);
x86_l_8e7:
	/* 0x8e7: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_8eb:
	/* 0x8eb: mov    BYTE PTR [r13+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_8ef:
	/* 0x8ef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8f1:
	/* 0x8f1: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8f1, 0x9b9, x86_l_9b9);
x86_l_8f7:
	/* 0x8f7: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_8fb:
	/* 0x8fb: mov    BYTE PTR [r13+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_8ff:
	/* 0x8ff: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_901:
	/* 0x901: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x901, 0x9b9, x86_l_9b9);
x86_l_907:
	/* 0x907: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_90b:
	/* 0x90b: mov    BYTE PTR [r13+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_90f:
	/* 0x90f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_911:
	/* 0x911: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x911, 0x9b9, x86_l_9b9);
x86_l_917:
	/* 0x917: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_91b:
	/* 0x91b: mov    BYTE PTR [r13+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_91f:
	/* 0x91f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_921:
	/* 0x921: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x921, 0x9b9, x86_l_9b9);
x86_l_927:
	/* 0x927: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_92b:
	/* 0x92b: mov    BYTE PTR [r13+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_92f:
	/* 0x92f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_931:
	/* 0x931: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x931, 0x9b9, x86_l_9b9);
x86_l_937:
	/* 0x937: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_93b:
	/* 0x93b: mov    BYTE PTR [r13+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_93f:
	/* 0x93f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_941:
	/* 0x941: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x941, 0x9b9, x86_l_9b9);
x86_l_943:
	/* 0x943: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_947:
	/* 0x947: mov    BYTE PTR [r13+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_94b:
	/* 0x94b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_94d:
	/* 0x94d: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94d, 0x9b9, x86_l_9b9);
x86_l_94f:
	/* 0x94f: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_953:
	/* 0x953: mov    BYTE PTR [r13+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_957:
	/* 0x957: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_959:
	/* 0x959: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x959, 0x9b9, x86_l_9b9);
x86_l_95b:
	/* 0x95b: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_95f:
	/* 0x95f: mov    BYTE PTR [r13+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_963:
	/* 0x963: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_965:
	/* 0x965: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x965, 0x9b9, x86_l_9b9);
x86_l_967:
	/* 0x967: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_96b:
	/* 0x96b: mov    BYTE PTR [r13+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_96f:
	/* 0x96f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_971:
	/* 0x971: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x971, 0x9b9, x86_l_9b9);
x86_l_973:
	/* 0x973: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_977:
	/* 0x977: mov    BYTE PTR [r13+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_97b:
	/* 0x97b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_97d:
	/* 0x97d: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x97d, 0x9b9, x86_l_9b9);
x86_l_97f:
	/* 0x97f: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_983:
	/* 0x983: mov    BYTE PTR [r13+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_987:
	/* 0x987: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_989:
	/* 0x989: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x989, 0x9b9, x86_l_9b9);
x86_l_98b:
	/* 0x98b: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_98f:
	/* 0x98f: mov    BYTE PTR [r13+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_993:
	/* 0x993: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_995:
	/* 0x995: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x995, 0x9b9, x86_l_9b9);
x86_l_997:
	/* 0x997: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_99b:
	/* 0x99b: mov    BYTE PTR [r13+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_99f:
	/* 0x99f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_9a1:
	/* 0x9a1: je     9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a1, 0x9b9, x86_l_9b9);
x86_l_9a3:
	/* 0x9a3: mov    BYTE PTR [r13+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_9a8:
	/* 0x9a8: jmp    9b9 <trace_chmod_common+0x9b9> */
	X86_SIM_X86_JMP(0x9a8, 0x9b9, x86_l_9b9);
x86_l_9aa:
	/* 0x9aa: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_9b2:
	/* 0x9b2: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9b9:
	/* 0x9b9: mov    rbx,QWORD PTR [r13+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_9c0:
	/* 0x9c0: mov    r13,QWORD PTR [r13+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_9c7:
	/* 0x9c7: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9ca:
	/* 0x9ca: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9d0:
	/* 0x9d0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_9d7:
	/* 0x9d7: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9dc:
	/* 0x9dc: call   9e1 <trace_chmod_common+0x9e1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9e1:
	/* 0x9e1: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9e8:
	/* 0x9e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9eb:
	/* 0x9eb: je     a09 <trace_chmod_common+0xa09> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9eb, 0xa09, x86_l_a09);
x86_l_9ed:
	/* 0x9ed: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9f0:
	/* 0x9f0: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_9f3:
	/* 0x9f3: call   9f8 <trace_chmod_common+0x9f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9f8:
	/* 0x9f8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9fb:
	/* 0x9fb: je     a09 <trace_chmod_common+0xa09> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9fb, 0xa09, x86_l_a09);
x86_l_9fd:
	/* 0x9fd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a00:
	/* 0xa00: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a04:
	/* 0xa04: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a07:
	/* 0xa07: jmp    a0b <trace_chmod_common+0xa0b> */
	X86_SIM_X86_JMP(0xa07, 0xa0b, x86_l_a0b);
x86_l_a09:
	/* 0xa09: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a0b:
	/* 0xa0b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a0e:
	/* 0xa0e: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a11:
	/* 0xa11: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a14:
	/* 0xa14: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a17:
	/* 0xa17: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a1b:
	/* 0xa1b: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_a21:
	/* 0xa21: cmp    QWORD PTR [r13+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a29:
	/* 0xa29: je     aa4 <trace_chmod_common+0xaa4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa29, 0xaa4, x86_l_aa4);
x86_l_a2b:
	/* 0xa2b: lea    r15,[rbp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a2f:
	/* 0xa2f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a32:
	/* 0xa32: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a37:
	/* 0xa37: call   a3c <trace_chmod_common+0xa3c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_a3c:
	/* 0xa3c: mov    rbx,QWORD PTR [r13+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_a43:
	/* 0xa43: mov    r13,QWORD PTR [r13+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_a4a:
	/* 0xa4a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a4d:
	/* 0xa4d: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a53:
	/* 0xa53: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_a5a:
	/* 0xa5a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a5f:
	/* 0xa5f: call   a64 <trace_chmod_common+0xa64> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a64:
	/* 0xa64: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a6b:
	/* 0xa6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a6e:
	/* 0xa6e: je     a8c <trace_chmod_common+0xa8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa6e, 0xa8c, x86_l_a8c);
x86_l_a70:
	/* 0xa70: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a73:
	/* 0xa73: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a76:
	/* 0xa76: call   a7b <trace_chmod_common+0xa7b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a7b:
	/* 0xa7b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a7e:
	/* 0xa7e: je     a8c <trace_chmod_common+0xa8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7e, 0xa8c, x86_l_a8c);
x86_l_a80:
	/* 0xa80: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a83:
	/* 0xa83: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a87:
	/* 0xa87: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a8a:
	/* 0xa8a: jmp    a8e <trace_chmod_common+0xa8e> */
	X86_SIM_X86_JMP(0xa8a, 0xa8e, x86_l_a8e);
x86_l_a8c:
	/* 0xa8c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a8e:
	/* 0xa8e: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a91:
	/* 0xa91: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a94:
	/* 0xa94: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a97:
	/* 0xa97: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a9a:
	/* 0xa9a: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a9e:
	/* 0xa9e: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_aa4:
	/* 0xaa4: mov    rbx,QWORD PTR [r13+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_aab:
	/* 0xaab: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_aae:
	/* 0xaae: je     b17 <trace_chmod_common+0xb17> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaae, 0xb17, x86_l_b17);
x86_l_ab0:
	/* 0xab0: mov    eax,DWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ab4:
	/* 0xab4: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ab8:
	/* 0xab8: mov    r15,QWORD PTR [r13+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_abf:
	/* 0xabf: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ac2:
	/* 0xac2: mov    WORD PTR [rsp+0x1c],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_ac8:
	/* 0xac8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_acf:
	/* 0xacf: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_ad4:
	/* 0xad4: call   ad9 <trace_chmod_common+0xad9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad9:
	/* 0xad9: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ae0:
	/* 0xae0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae3:
	/* 0xae3: je     b03 <trace_chmod_common+0xb03> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae3, 0xb03, x86_l_b03);
x86_l_ae5:
	/* 0xae5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_aea:
	/* 0xaea: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aed:
	/* 0xaed: call   af2 <trace_chmod_common+0xaf2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_af2:
	/* 0xaf2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af5:
	/* 0xaf5: je     b03 <trace_chmod_common+0xb03> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaf5, 0xb03, x86_l_b03);
x86_l_af7:
	/* 0xaf7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_afa:
	/* 0xafa: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_afe:
	/* 0xafe: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b01:
	/* 0xb01: jmp    b05 <trace_chmod_common+0xb05> */
	X86_SIM_X86_JMP(0xb01, 0xb05, x86_l_b05);
x86_l_b03:
	/* 0xb03: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b05:
	/* 0xb05: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b08:
	/* 0xb08: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b0b:
	/* 0xb0b: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b0e:
	/* 0xb0e: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b11:
	/* 0xb11: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_b17:
	/* 0xb17: mov    rbx,QWORD PTR [r13+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b1e:
	/* 0xb1e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b21:
	/* 0xb21: je     b81 <trace_chmod_common+0xb81> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb21, 0xb81, x86_l_b81);
x86_l_b23:
	/* 0xb23: mov    r15,QWORD PTR [r13+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_b2a:
	/* 0xb2a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b2d:
	/* 0xb2d: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b33:
	/* 0xb33: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_b3a:
	/* 0xb3a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b3f:
	/* 0xb3f: call   b44 <trace_chmod_common+0xb44> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b44:
	/* 0xb44: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b4b:
	/* 0xb4b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4e:
	/* 0xb4e: je     b6d <trace_chmod_common+0xb6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4e, 0xb6d, x86_l_b6d);
x86_l_b50:
	/* 0xb50: lea    rsi,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_b54:
	/* 0xb54: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b57:
	/* 0xb57: call   b5c <trace_chmod_common+0xb5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b5c:
	/* 0xb5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5f:
	/* 0xb5f: je     b6d <trace_chmod_common+0xb6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5f, 0xb6d, x86_l_b6d);
x86_l_b61:
	/* 0xb61: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b64:
	/* 0xb64: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b68:
	/* 0xb68: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b6b:
	/* 0xb6b: jmp    b6f <trace_chmod_common+0xb6f> */
	X86_SIM_X86_JMP(0xb6b, 0xb6f, x86_l_b6f);
x86_l_b6d:
	/* 0xb6d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b6f:
	/* 0xb6f: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b72:
	/* 0xb72: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b75:
	/* 0xb75: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b78:
	/* 0xb78: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b7b:
	/* 0xb7b: movzx  r14d,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_b81:
	/* 0xb81: mov    rbx,QWORD PTR [r13+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_b88:
	/* 0xb88: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b8b:
	/* 0xb8b: je     c11 <trace_chmod_common+0xc11> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8b, 0xc11, x86_l_c11);
x86_l_b91:
	/* 0xb91: mov    r13,QWORD PTR [r13+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_b98:
	/* 0xb98: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b9b:
	/* 0xb9b: mov    WORD PTR [rsp+0x40],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ba1:
	/* 0xba1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_ba8:
	/* 0xba8: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bad:
	/* 0xbad: call   bb2 <trace_chmod_common+0xbb2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bb2:
	/* 0xbb2: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bb9:
	/* 0xbb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbc:
	/* 0xbbc: je     bff <trace_chmod_common+0xbff> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbbc, 0xbff, x86_l_bff);
x86_l_bbe:
	/* 0xbbe: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc1:
	/* 0xbc1: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_bc9:
	/* 0xbc9: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_bcd:
	/* 0xbcd: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bd0:
	/* 0xbd0: call   bd5 <trace_chmod_common+0xbd5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bd5:
	/* 0xbd5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd8:
	/* 0xbd8: jne    bf3 <trace_chmod_common+0xbf3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbd8, 0xbf3, x86_l_bf3);
x86_l_bda:
	/* 0xbda: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_be2:
	/* 0xbe2: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_be6:
	/* 0xbe6: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_be9:
	/* 0xbe9: call   bee <trace_chmod_common+0xbee> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bee:
	/* 0xbee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bf1:
	/* 0xbf1: je     bff <trace_chmod_common+0xbff> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbf1, 0xbff, x86_l_bff);
x86_l_bf3:
	/* 0xbf3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf6:
	/* 0xbf6: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfa:
	/* 0xbfa: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bfd:
	/* 0xbfd: jmp    c01 <trace_chmod_common+0xc01> */
	X86_SIM_X86_JMP(0xbfd, 0xc01, x86_l_c01);
x86_l_bff:
	/* 0xbff: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c01:
	/* 0xc01: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c04:
	/* 0xc04: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c07:
	/* 0xc07: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c0a:
	/* 0xc0a: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c0d:
	/* 0xc0d: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c11:
	/* 0xc11: mov    rax,QWORD PTR [r13+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c18:
	/* 0xc18: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c1b:
	/* 0xc1b: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c20:
	/* 0xc20: je     c31 <trace_chmod_common+0xc31> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc20, 0xc31, x86_l_c31);
x86_l_c22:
	/* 0xc22: mov    rcx,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c2a:
	/* 0xc2a: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_c2e:
	/* 0xc2e: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c31:
	/* 0xc31: and    r12,QWORD PTR [r13+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_c38:
	/* 0xc38: mov    rax,QWORD PTR [r13+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c3f:
	/* 0xc3f: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c42:
	/* 0xc42: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c49:
	/* 0xc49: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_c4e:
	/* 0xc4e: je     2fbd <trace_chmod_common+0x2fbd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc4e, 0x2fbd, x86_l_2fbd);
x86_l_c54:
	/* 0xc54: mov    rbx,QWORD PTR [r14+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c58:
	/* 0xc58: movzx  eax,WORD PTR [r14+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 104ULL);
x86_l_c5d:
	/* 0xc5d: mov    WORD PTR [rsp+0x1c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_c62:
	/* 0xc62: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_c6a:
	/* 0xc6a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_c71:
	/* 0xc71: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c76:
	/* 0xc76: call   c7b <trace_chmod_common+0xc7b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c7b:
	/* 0xc7b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7e:
	/* 0xc7e: je     ca2 <trace_chmod_common+0xca2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc7e, 0xca2, x86_l_ca2);
x86_l_c80:
	/* 0xc80: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c83:
	/* 0xc83: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c86:
	/* 0xc86: je     1190 <trace_chmod_common+0x1190> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc86, 0x1190, x86_l_1190);
x86_l_c8c:
	/* 0xc8c: lea    rax,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c90:
	/* 0xc90: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c93:
	/* 0xc93: jns    cbd <trace_chmod_common+0xcbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc93, 0xcbd, x86_l_cbd);
x86_l_c95:
	/* 0xc95: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c98:
	/* 0xc98: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c9b:
	/* 0xc9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c9e:
	/* 0xc9e: js     cc8 <trace_chmod_common+0xcc8> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc9e, 0xcc8, x86_l_cc8);
x86_l_ca0:
	/* 0xca0: jmp    cd2 <trace_chmod_common+0xcd2> */
	X86_SIM_X86_JMP(0xca0, 0xcd2, x86_l_cd2);
x86_l_ca2:
	/* 0xca2: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ca4:
	/* 0xca4: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_cac:
	/* 0xcac: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_cb2:
	/* 0xcb2: jbe    2932 <trace_chmod_common+0x2932> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xcb2, 0x2932, x86_l_2932);
x86_l_cb8:
	/* 0xcb8: jmp    2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JMP(0xcb8, 0x2a0a, x86_l_2a0a);
x86_l_cbd:
	/* 0xcbd: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cc0:
	/* 0xcc0: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_cc3:
	/* 0xcc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc6:
	/* 0xcc6: jns    cd2 <trace_chmod_common+0xcd2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcc6, 0xcd2, x86_l_cd2);
x86_l_cc8:
	/* 0xcc8: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cca:
	/* 0xcca: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_ccc:
	/* 0xccc: jne    de7 <trace_chmod_common+0xde7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xccc, 0xde7, x86_l_de7);
x86_l_cd2:
	/* 0xcd2: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_cd5:
	/* 0xcd5: jns    cdc <trace_chmod_common+0xcdc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcd5, 0xcdc, x86_l_cdc);
x86_l_cd7:
	/* 0xcd7: mov    rsi,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cda:
	/* 0xcda: jmp    cde <trace_chmod_common+0xcde> */
	X86_SIM_X86_JMP(0xcda, 0xcde, x86_l_cde);
x86_l_cdc:
	/* 0xcdc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cde:
	/* 0xcde: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_ce2:
	/* 0xce2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce5:
	/* 0xce5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ce8:
	/* 0xce8: jns    d0c <trace_chmod_common+0xd0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xce8, 0xd0c, x86_l_d0c);
x86_l_cea:
	/* 0xcea: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ced:
	/* 0xced: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_cf0:
	/* 0xcf0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cf3:
	/* 0xcf3: js     d16 <trace_chmod_common+0xd16> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcf3, 0xd16, x86_l_d16);
x86_l_cf5:
	/* 0xcf5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf7:
	/* 0xcf7: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cfb:
	/* 0xcfb: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cfe:
	/* 0xcfe: js     d22 <trace_chmod_common+0xd22> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcfe, 0xd22, x86_l_d22);
x86_l_d00:
	/* 0xd00: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d02:
	/* 0xd02: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d05:
	/* 0xd05: jne    d2e <trace_chmod_common+0xd2e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd05, 0xd2e, x86_l_d2e);
x86_l_d07:
	/* 0xd07: jmp    dac <trace_chmod_common+0xdac> */
	X86_SIM_X86_JMP(0xd07, 0xdac, x86_l_dac);
x86_l_d0c:
	/* 0xd0c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d0e:
	/* 0xd0e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_d11:
	/* 0xd11: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d14:
	/* 0xd14: jns    cf5 <trace_chmod_common+0xcf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd14, 0xcf5, x86_l_cf5);
x86_l_d16:
	/* 0xd16: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d19:
	/* 0xd19: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d1d:
	/* 0xd1d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d20:
	/* 0xd20: jns    d00 <trace_chmod_common+0xd00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd20, 0xd00, x86_l_d00);
x86_l_d22:
	/* 0xd22: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d25:
	/* 0xd25: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d28:
	/* 0xd28: je     dac <trace_chmod_common+0xdac> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd28, 0xdac, x86_l_dac);
x86_l_d2e:
	/* 0xd2e: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d31:
	/* 0xd31: je     dac <trace_chmod_common+0xdac> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd31, 0xdac, x86_l_dac);
x86_l_d33:
	/* 0xd33: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d37:
	/* 0xd37: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d3a:
	/* 0xd3a: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_d40:
	/* 0xd40: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d43:
	/* 0xd43: jns    d4c <trace_chmod_common+0xd4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd43, 0xd4c, x86_l_d4c);
x86_l_d45:
	/* 0xd45: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d48:
	/* 0xd48: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d4c:
	/* 0xd4c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_d50:
	/* 0xd50: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d53:
	/* 0xd53: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_d5a:
	/* 0xd5a: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_d5d:
	/* 0xd5d: je     1136 <trace_chmod_common+0x1136> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd5d, 0x1136, x86_l_1136);
x86_l_d63:
	/* 0xd63: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_d66:
	/* 0xd66: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_d68:
	/* 0xd68: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_d6e:
	/* 0xd6e: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d71:
	/* 0xd71: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_d76:
	/* 0xd76: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_d79:
	/* 0xd79: jns    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd79, 0x111a, x86_l_111a);
x86_l_d7f:
	/* 0xd7f: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_d83:
	/* 0xd83: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d86:
	/* 0xd86: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_d89:
	/* 0xd89: je     e53 <trace_chmod_common+0xe53> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd89, 0xe53, x86_l_e53);
x86_l_d8f:
	/* 0xd8f: lea    rbx,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_d93:
	/* 0xd93: movzx  r14d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_d98:
	/* 0xd98: mov    BYTE PTR [rdi+r11*1],r14b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R14, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_d9c:
	/* 0xd9c: mov    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d9f:
	/* 0xd9f: test   r14b,r14b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_8, 0, 0);
x86_l_da2:
	/* 0xda2: jne    d86 <trace_chmod_common+0xd86> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xda2, 0xd86, x86_l_d86);
x86_l_da4:
	/* 0xda4: mov    r8d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_da7:
	/* 0xda7: jmp    e58 <trace_chmod_common+0xe58> */
	X86_SIM_X86_JMP(0xda7, 0xe58, x86_l_e58);
x86_l_dac:
	/* 0xdac: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_daf:
	/* 0xdaf: jne    1136 <trace_chmod_common+0x1136> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xdaf, 0x1136, x86_l_1136);
x86_l_db5:
	/* 0xdb5: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_db8:
	/* 0xdb8: je     1136 <trace_chmod_common+0x1136> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb8, 0x1136, x86_l_1136);
x86_l_dbe:
	/* 0xdbe: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_dc2:
	/* 0xdc2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_dc5:
	/* 0xdc5: jns    e1c <trace_chmod_common+0xe1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdc5, 0xe1c, x86_l_e1c);
x86_l_dc7:
	/* 0xdc7: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dca:
	/* 0xdca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dcd:
	/* 0xdcd: js     e23 <trace_chmod_common+0xe23> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdcd, 0xe23, x86_l_e23);
x86_l_dcf:
	/* 0xdcf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd1:
	/* 0xdd1: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd4:
	/* 0xdd4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dd7:
	/* 0xdd7: js     e2e <trace_chmod_common+0xe2e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdd7, 0xe2e, x86_l_e2e);
x86_l_dd9:
	/* 0xdd9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ddb:
	/* 0xddb: jmp    e31 <trace_chmod_common+0xe31> */
	X86_SIM_X86_JMP(0xddb, 0xe31, x86_l_e31);
x86_l_ddd:
	/* 0xddd: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_de2:
	/* 0xde2: jmp    1c3 <trace_chmod_common+0x1c3> */
	X86_SIM_X86_JMP(0xde2, 0x1c3, x86_l_1c3);
x86_l_de7:
	/* 0xde7: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_dee:
	/* 0xdee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_df1:
	/* 0xdf1: jns    114b <trace_chmod_common+0x114b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdf1, 0x114b, x86_l_114b);
x86_l_df7:
	/* 0xdf7: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_df9:
	/* 0xdf9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dfb:
	/* 0xdfb: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_e02:
	/* 0xe02: je     1189 <trace_chmod_common+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe02, 0x1189, x86_l_1189);
x86_l_e08:
	/* 0xe08: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_e0c:
	/* 0xe0c: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_e10:
	/* 0xe10: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e13:
	/* 0xe13: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_e15:
	/* 0xe15: jne    dfb <trace_chmod_common+0xdfb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe15, 0xdfb, x86_l_dfb);
x86_l_e17:
	/* 0xe17: jmp    2915 <trace_chmod_common+0x2915> */
	X86_SIM_X86_JMP(0xe17, 0x2915, x86_l_2915);
x86_l_e1c:
	/* 0xe1c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e1e:
	/* 0xe1e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e21:
	/* 0xe21: jns    dcf <trace_chmod_common+0xdcf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe21, 0xdcf, x86_l_dcf);
x86_l_e23:
	/* 0xe23: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e26:
	/* 0xe26: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e29:
	/* 0xe29: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e2c:
	/* 0xe2c: jns    dd9 <trace_chmod_common+0xdd9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe2c, 0xdd9, x86_l_dd9);
x86_l_e2e:
	/* 0xe2e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e31:
	/* 0xe31: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e35:
	/* 0xe35: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e3a:
	/* 0xe3a: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e3d:
	/* 0xe3d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e40:
	/* 0xe40: jns    e79 <trace_chmod_common+0xe79> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe40, 0xe79, x86_l_e79);
x86_l_e42:
	/* 0xe42: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e45:
	/* 0xe45: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e49:
	/* 0xe49: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e4c:
	/* 0xe4c: js     e84 <trace_chmod_common+0xe84> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe4c, 0xe84, x86_l_e84);
x86_l_e4e:
	/* 0xe4e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e51:
	/* 0xe51: jmp    e87 <trace_chmod_common+0xe87> */
	X86_SIM_X86_JMP(0xe51, 0xe87, x86_l_e87);
x86_l_e53:
	/* 0xe53: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_e58:
	/* 0xe58: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e5c:
	/* 0xe5c: jl     1136 <trace_chmod_common+0x1136> */
	X86_SIM_X86_JCC(X86_CC_L, 0xe5c, 0x1136, x86_l_1136);
x86_l_e62:
	/* 0xe62: mov    BYTE PTR [rbp+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_e69:
	/* 0xe69: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e6e:
	/* 0xe6e: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e71:
	/* 0xe71: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e74:
	/* 0xe74: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e77:
	/* 0xe77: js     e42 <trace_chmod_common+0xe42> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe77, 0xe42, x86_l_e42);
x86_l_e79:
	/* 0xe79: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e7b:
	/* 0xe7b: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e7f:
	/* 0xe7f: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e82:
	/* 0xe82: jns    e4e <trace_chmod_common+0xe4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe82, 0xe4e, x86_l_e4e);
x86_l_e84:
	/* 0xe84: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e87:
	/* 0xe87: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e8a:
	/* 0xe8a: je     f04 <trace_chmod_common+0xf04> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8a, 0xf04, x86_l_f04);
x86_l_e8c:
	/* 0xe8c: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_e8f:
	/* 0xe8f: je     f04 <trace_chmod_common+0xf04> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8f, 0xf04, x86_l_f04);
x86_l_e91:
	/* 0xe91: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e95:
	/* 0xe95: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e98:
	/* 0xe98: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e9e:
	/* 0xe9e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ea1:
	/* 0xea1: jns    eaa <trace_chmod_common+0xeaa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xea1, 0xeaa, x86_l_eaa);
x86_l_ea3:
	/* 0xea3: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ea6:
	/* 0xea6: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_eaa:
	/* 0xeaa: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_eae:
	/* 0xeae: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_eb1:
	/* 0xeb1: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_eb8:
	/* 0xeb8: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_eba:
	/* 0xeba: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_ebd:
	/* 0xebd: jb     2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_B, 0xebd, 0x2900, x86_l_2900);
x86_l_ec3:
	/* 0xec3: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_ec6:
	/* 0xec6: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec6, 0x1127, x86_l_1127);
x86_l_ecc:
	/* 0xecc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_ed2:
	/* 0xed2: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_ed5:
	/* 0xed5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_ed8:
	/* 0xed8: jns    1117 <trace_chmod_common+0x1117> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xed8, 0x1117, x86_l_1117);
x86_l_ede:
	/* 0xede: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ee2:
	/* 0xee2: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ee5:
	/* 0xee5: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_ee8:
	/* 0xee8: je     f53 <trace_chmod_common+0xf53> */
	X86_SIM_X86_JCC(X86_CC_E, 0xee8, 0xf53, x86_l_f53);
x86_l_eea:
	/* 0xeea: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_eee:
	/* 0xeee: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_ef3:
	/* 0xef3: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_ef7:
	/* 0xef7: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_efa:
	/* 0xefa: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_efd:
	/* 0xefd: jne    ee5 <trace_chmod_common+0xee5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xefd, 0xee5, x86_l_ee5);
x86_l_eff:
	/* 0xeff: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_f02:
	/* 0xf02: jmp    f58 <trace_chmod_common+0xf58> */
	X86_SIM_X86_JMP(0xf02, 0xf58, x86_l_f58);
x86_l_f04:
	/* 0xf04: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f07:
	/* 0xf07: jne    1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf07, 0x1127, x86_l_1127);
x86_l_f0d:
	/* 0xf0d: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f10:
	/* 0xf10: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf10, 0x1127, x86_l_1127);
x86_l_f16:
	/* 0xf16: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f1a:
	/* 0xf1a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f1d:
	/* 0xf1d: jns    f24 <trace_chmod_common+0xf24> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf1d, 0xf24, x86_l_f24);
x86_l_f1f:
	/* 0xf1f: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f22:
	/* 0xf22: jmp    f27 <trace_chmod_common+0xf27> */
	X86_SIM_X86_JMP(0xf22, 0xf27, x86_l_f27);
x86_l_f24:
	/* 0xf24: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f27:
	/* 0xf27: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f2a:
	/* 0xf2a: jns    f31 <trace_chmod_common+0xf31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf2a, 0xf31, x86_l_f31);
x86_l_f2c:
	/* 0xf2c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f2f:
	/* 0xf2f: jmp    f33 <trace_chmod_common+0xf33> */
	X86_SIM_X86_JMP(0xf2f, 0xf33, x86_l_f33);
x86_l_f31:
	/* 0xf31: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f33:
	/* 0xf33: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f36:
	/* 0xf36: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f39:
	/* 0xf39: jns    f40 <trace_chmod_common+0xf40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf39, 0xf40, x86_l_f40);
x86_l_f3b:
	/* 0xf3b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3e:
	/* 0xf3e: jmp    f42 <trace_chmod_common+0xf42> */
	X86_SIM_X86_JMP(0xf3e, 0xf42, x86_l_f42);
x86_l_f40:
	/* 0xf40: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f42:
	/* 0xf42: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f46:
	/* 0xf46: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f49:
	/* 0xf49: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f4c:
	/* 0xf4c: jns    f7b <trace_chmod_common+0xf7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf4c, 0xf7b, x86_l_f7b);
x86_l_f4e:
	/* 0xf4e: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f51:
	/* 0xf51: jmp    f7d <trace_chmod_common+0xf7d> */
	X86_SIM_X86_JMP(0xf51, 0xf7d, x86_l_f7d);
x86_l_f53:
	/* 0xf53: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f58:
	/* 0xf58: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f5c:
	/* 0xf5c: jl     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf5c, 0x1127, x86_l_1127);
x86_l_f62:
	/* 0xf62: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f65:
	/* 0xf65: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_f6b:
	/* 0xf6b: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_f70:
	/* 0xf70: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f73:
	/* 0xf73: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f76:
	/* 0xf76: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f79:
	/* 0xf79: js     f4e <trace_chmod_common+0xf4e> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf79, 0xf4e, x86_l_f4e);
x86_l_f7b:
	/* 0xf7b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f7d:
	/* 0xf7d: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f81:
	/* 0xf81: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f84:
	/* 0xf84: jns    f8b <trace_chmod_common+0xf8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf84, 0xf8b, x86_l_f8b);
x86_l_f86:
	/* 0xf86: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f89:
	/* 0xf89: jmp    f8d <trace_chmod_common+0xf8d> */
	X86_SIM_X86_JMP(0xf89, 0xf8d, x86_l_f8d);
x86_l_f8b:
	/* 0xf8b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8d:
	/* 0xf8d: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f90:
	/* 0xf90: je     100a <trace_chmod_common+0x100a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf90, 0x100a, x86_l_100a);
x86_l_f92:
	/* 0xf92: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f95:
	/* 0xf95: je     100a <trace_chmod_common+0x100a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf95, 0x100a, x86_l_100a);
x86_l_f97:
	/* 0xf97: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f9b:
	/* 0xf9b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f9e:
	/* 0xf9e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_fa4:
	/* 0xfa4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fa7:
	/* 0xfa7: jns    fb0 <trace_chmod_common+0xfb0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfa7, 0xfb0, x86_l_fb0);
x86_l_fa9:
	/* 0xfa9: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fac:
	/* 0xfac: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fb0:
	/* 0xfb0: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fb4:
	/* 0xfb4: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_fb7:
	/* 0xfb7: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fbe:
	/* 0xfbe: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_fc0:
	/* 0xfc0: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_fc3:
	/* 0xfc3: jb     2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_B, 0xfc3, 0x2900, x86_l_2900);
x86_l_fc9:
	/* 0xfc9: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_fcc:
	/* 0xfcc: je     1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfcc, 0x1124, x86_l_1124);
x86_l_fd2:
	/* 0xfd2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_fd8:
	/* 0xfd8: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fdb:
	/* 0xfdb: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_fde:
	/* 0xfde: jns    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfde, 0x111a, x86_l_111a);
x86_l_fe4:
	/* 0xfe4: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_fe8:
	/* 0xfe8: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_feb:
	/* 0xfeb: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_fee:
	/* 0xfee: je     1058 <trace_chmod_common+0x1058> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfee, 0x1058, x86_l_1058);
x86_l_ff0:
	/* 0xff0: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_ff4:
	/* 0xff4: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_ff9:
	/* 0xff9: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_ffd:
	/* 0xffd: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1000:
	/* 0x1000: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1003:
	/* 0x1003: jne    feb <trace_chmod_common+0xfeb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1003, 0xfeb, x86_l_feb);
x86_l_1005:
	/* 0x1005: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1008:
	/* 0x1008: jmp    105d <trace_chmod_common+0x105d> */
	X86_SIM_X86_JMP(0x1008, 0x105d, x86_l_105d);
x86_l_100a:
	/* 0x100a: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_100d:
	/* 0x100d: jne    1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x100d, 0x1124, x86_l_1124);
x86_l_1013:
	/* 0x1013: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1016:
	/* 0x1016: je     1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1016, 0x1124, x86_l_1124);
x86_l_101c:
	/* 0x101c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1020:
	/* 0x1020: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1023:
	/* 0x1023: jns    102a <trace_chmod_common+0x102a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1023, 0x102a, x86_l_102a);
x86_l_1025:
	/* 0x1025: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1028:
	/* 0x1028: jmp    102c <trace_chmod_common+0x102c> */
	X86_SIM_X86_JMP(0x1028, 0x102c, x86_l_102c);
x86_l_102a:
	/* 0x102a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_102c:
	/* 0x102c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_102f:
	/* 0x102f: jns    1036 <trace_chmod_common+0x1036> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x102f, 0x1036, x86_l_1036);
x86_l_1031:
	/* 0x1031: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1034:
	/* 0x1034: jmp    1038 <trace_chmod_common+0x1038> */
	X86_SIM_X86_JMP(0x1034, 0x1038, x86_l_1038);
x86_l_1036:
	/* 0x1036: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1038:
	/* 0x1038: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_103b:
	/* 0x103b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_103e:
	/* 0x103e: jns    1045 <trace_chmod_common+0x1045> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x103e, 0x1045, x86_l_1045);
x86_l_1040:
	/* 0x1040: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1043:
	/* 0x1043: jmp    1047 <trace_chmod_common+0x1047> */
	X86_SIM_X86_JMP(0x1043, 0x1047, x86_l_1047);
x86_l_1045:
	/* 0x1045: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1047:
	/* 0x1047: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_104b:
	/* 0x104b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_104e:
	/* 0x104e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1051:
	/* 0x1051: jns    1080 <trace_chmod_common+0x1080> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1051, 0x1080, x86_l_1080);
x86_l_1053:
	/* 0x1053: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1056:
	/* 0x1056: jmp    1082 <trace_chmod_common+0x1082> */
	X86_SIM_X86_JMP(0x1056, 0x1082, x86_l_1082);
x86_l_1058:
	/* 0x1058: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_105d:
	/* 0x105d: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1061:
	/* 0x1061: jl     1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1061, 0x1124, x86_l_1124);
x86_l_1067:
	/* 0x1067: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_106a:
	/* 0x106a: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1070:
	/* 0x1070: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1075:
	/* 0x1075: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1078:
	/* 0x1078: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_107b:
	/* 0x107b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_107e:
	/* 0x107e: js     1053 <trace_chmod_common+0x1053> */
	X86_SIM_X86_JCC(X86_CC_S, 0x107e, 0x1053, x86_l_1053);
x86_l_1080:
	/* 0x1080: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1082:
	/* 0x1082: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1086:
	/* 0x1086: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1089:
	/* 0x1089: jns    1090 <trace_chmod_common+0x1090> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1089, 0x1090, x86_l_1090);
x86_l_108b:
	/* 0x108b: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_108e:
	/* 0x108e: jmp    1093 <trace_chmod_common+0x1093> */
	X86_SIM_X86_JMP(0x108e, 0x1093, x86_l_1093);
x86_l_1090:
	/* 0x1090: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1093:
	/* 0x1093: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1096:
	/* 0x1096: je     1197 <trace_chmod_common+0x1197> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1096, 0x1197, x86_l_1197);
x86_l_109c:
	/* 0x109c: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_109f:
	/* 0x109f: je     1197 <trace_chmod_common+0x1197> */
	X86_SIM_X86_JCC(X86_CC_E, 0x109f, 0x1197, x86_l_1197);
x86_l_10a5:
	/* 0x10a5: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10a9:
	/* 0x10a9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ac:
	/* 0x10ac: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_10b2:
	/* 0x10b2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10b5:
	/* 0x10b5: jns    10be <trace_chmod_common+0x10be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10b5, 0x10be, x86_l_10be);
x86_l_10b7:
	/* 0x10b7: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10ba:
	/* 0x10ba: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10be:
	/* 0x10be: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_10c2:
	/* 0x10c2: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_10c5:
	/* 0x10c5: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10cc:
	/* 0x10cc: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_10ce:
	/* 0x10ce: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10d1:
	/* 0x10d1: jb     2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10d1, 0x2900, x86_l_2900);
x86_l_10d7:
	/* 0x10d7: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_10da:
	/* 0x10da: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10da, 0x1127, x86_l_1127);
x86_l_10dc:
	/* 0x10dc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_10e2:
	/* 0x10e2: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_10e5:
	/* 0x10e5: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_10e8:
	/* 0x10e8: jns    1117 <trace_chmod_common+0x1117> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10e8, 0x1117, x86_l_1117);
x86_l_10ea:
	/* 0x10ea: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10ee:
	/* 0x10ee: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10f1:
	/* 0x10f1: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_10f4:
	/* 0x10f4: je     1632 <trace_chmod_common+0x1632> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10f4, 0x1632, x86_l_1632);
x86_l_10fa:
	/* 0x10fa: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_10fe:
	/* 0x10fe: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1103:
	/* 0x1103: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1107:
	/* 0x1107: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_110a:
	/* 0x110a: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_110d:
	/* 0x110d: jne    10f1 <trace_chmod_common+0x10f1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x110d, 0x10f1, x86_l_10f1);
x86_l_110f:
	/* 0x110f: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1112:
	/* 0x1112: jmp    1637 <trace_chmod_common+0x1637> */
	X86_SIM_X86_JMP(0x1112, 0x1637, x86_l_1637);
x86_l_1117:
	/* 0x1117: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_111a:
	/* 0x111a: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_111d:
	/* 0x111d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_111f:
	/* 0x111f: call   1124 <trace_chmod_common+0x1124> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1124:
	/* 0x1124: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1127:
	/* 0x1127: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_112a:
	/* 0x112a: cmp    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1130:
	/* 0x1130: jne    2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1130, 0x2900, x86_l_2900);
x86_l_1136:
	/* 0x1136: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_113a:
	/* 0x113a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_113d:
	/* 0x113d: jns    1161 <trace_chmod_common+0x1161> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x113d, 0x1161, x86_l_1161);
x86_l_113f:
	/* 0x113f: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1142:
	/* 0x1142: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1146:
	/* 0x1146: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1149:
	/* 0x1149: js     1168 <trace_chmod_common+0x1168> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1149, 0x1168, x86_l_1168);
x86_l_114b:
	/* 0x114b: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_114d:
	/* 0x114d: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1152:
	/* 0x1152: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1155:
	/* 0x1155: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1157:
	/* 0x1157: call   115c <trace_chmod_common+0x115c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_115c:
	/* 0x115c: jmp    2915 <trace_chmod_common+0x2915> */
	X86_SIM_X86_JMP(0x115c, 0x2915, x86_l_2915);
x86_l_1161:
	/* 0x1161: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1163:
	/* 0x1163: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1166:
	/* 0x1166: jns    114b <trace_chmod_common+0x114b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1166, 0x114b, x86_l_114b);
x86_l_1168:
	/* 0x1168: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116a:
	/* 0x116a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116c:
	/* 0x116c: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1173:
	/* 0x1173: je     1189 <trace_chmod_common+0x1189> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1173, 0x1189, x86_l_1189);
x86_l_1175:
	/* 0x1175: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1179:
	/* 0x1179: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_117d:
	/* 0x117d: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1180:
	/* 0x1180: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1182:
	/* 0x1182: jne    116c <trace_chmod_common+0x116c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1182, 0x116c, x86_l_116c);
x86_l_1184:
	/* 0x1184: jmp    2915 <trace_chmod_common+0x2915> */
	X86_SIM_X86_JMP(0x1184, 0x2915, x86_l_2915);
x86_l_1189:
	/* 0x1189: mov    BYTE PTR [rbp+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_1190:
	/* 0x1190: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1192:
	/* 0x1192: jmp    2915 <trace_chmod_common+0x2915> */
	X86_SIM_X86_JMP(0x1192, 0x2915, x86_l_2915);
x86_l_1197:
	/* 0x1197: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_119a:
	/* 0x119a: jne    1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x119a, 0x1127, x86_l_1127);
x86_l_119c:
	/* 0x119c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_119f:
	/* 0x119f: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0x119f, 0x1127, x86_l_1127);
x86_l_11a1:
	/* 0x11a1: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11a5:
	/* 0x11a5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11a8:
	/* 0x11a8: jns    11af <trace_chmod_common+0x11af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11a8, 0x11af, x86_l_11af);
x86_l_11aa:
	/* 0x11aa: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ad:
	/* 0x11ad: jmp    11b2 <trace_chmod_common+0x11b2> */
	X86_SIM_X86_JMP(0x11ad, 0x11b2, x86_l_11b2);
x86_l_11af:
	/* 0x11af: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b2:
	/* 0x11b2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11b5:
	/* 0x11b5: jns    11bc <trace_chmod_common+0x11bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11b5, 0x11bc, x86_l_11bc);
x86_l_11b7:
	/* 0x11b7: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11ba:
	/* 0x11ba: jmp    11be <trace_chmod_common+0x11be> */
	X86_SIM_X86_JMP(0x11ba, 0x11be, x86_l_11be);
x86_l_11bc:
	/* 0x11bc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11be:
	/* 0x11be: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11c1:
	/* 0x11c1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11c4:
	/* 0x11c4: jns    11cb <trace_chmod_common+0x11cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11c4, 0x11cb, x86_l_11cb);
x86_l_11c6:
	/* 0x11c6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11c9:
	/* 0x11c9: jmp    11cd <trace_chmod_common+0x11cd> */
	X86_SIM_X86_JMP(0x11c9, 0x11cd, x86_l_11cd);
x86_l_11cb:
	/* 0x11cb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11cd:
	/* 0x11cd: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11d1:
	/* 0x11d1: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_11d4:
	/* 0x11d4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_11d7:
	/* 0x11d7: jns    165e <trace_chmod_common+0x165e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11d7, 0x165e, x86_l_165e);
x86_l_11dd:
	/* 0x11dd: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11e0:
	/* 0x11e0: jmp    1660 <trace_chmod_common+0x1660> */
	X86_SIM_X86_JMP(0x11e0, 0x1660, x86_l_1660);
x86_l_11e5:
	/* 0x11e5: mov    eax,DWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_11ec:
	/* 0x11ec: mov    DWORD PTR [rsp+0x1c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_11f0:
	/* 0x11f0: mov    DWORD PTR [rsp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_11f8:
	/* 0x11f8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_11ff:
	/* 0x11ff: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1204:
	/* 0x1204: call   1209 <trace_chmod_common+0x1209> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1209:
	/* 0x1209: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_120c:
	/* 0x120c: je     1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x120c, 0x1300, x86_l_1300);
x86_l_1212:
	/* 0x1212: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1215:
	/* 0x1215: mov    eax,DWORD PTR [rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1219:
	/* 0x1219: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_121d:
	/* 0x121d: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1222:
	/* 0x1222: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1225:
	/* 0x1225: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1227:
	/* 0x1227: call   122c <trace_chmod_common+0x122c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_122c:
	/* 0x122c: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1233:
	/* 0x1233: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1238:
	/* 0x1238: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_123d:
	/* 0x123d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1240:
	/* 0x1240: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1243:
	/* 0x1243: call   1248 <trace_chmod_common+0x1248> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1248:
	/* 0x1248: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_124d:
	/* 0x124d: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1250:
	/* 0x1250: call   1255 <trace_chmod_common+0x1255> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1255:
	/* 0x1255: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_125d:
	/* 0x125d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1260:
	/* 0x1260: jne    1f7 <trace_chmod_common+0x1f7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1260, 0x1f7, x86_l_1f7);
x86_l_1266:
	/* 0x1266: jmp    1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JMP(0x1266, 0x1300, x86_l_1300);
x86_l_126b:
	/* 0x126b: mov    eax,DWORD PTR [rsp+0x9c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_1272:
	/* 0x1272: mov    DWORD PTR [rsp+0x1c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1276:
	/* 0x1276: mov    DWORD PTR [rsp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_127e:
	/* 0x127e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1285:
	/* 0x1285: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_128a:
	/* 0x128a: call   128f <trace_chmod_common+0x128f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_128f:
	/* 0x128f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1292:
	/* 0x1292: je     1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1292, 0x1300, x86_l_1300);
x86_l_1294:
	/* 0x1294: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1297:
	/* 0x1297: mov    eax,DWORD PTR [rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_129b:
	/* 0x129b: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_129f:
	/* 0x129f: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_12a4:
	/* 0x12a4: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12a7:
	/* 0x12a7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12a9:
	/* 0x12a9: call   12ae <trace_chmod_common+0x12ae> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_12ae:
	/* 0x12ae: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_12b5:
	/* 0x12b5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_12ba:
	/* 0x12ba: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12bf:
	/* 0x12bf: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12c2:
	/* 0x12c2: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12c5:
	/* 0x12c5: call   12ca <trace_chmod_common+0x12ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_12ca:
	/* 0x12ca: lea    rsi,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_12cf:
	/* 0x12cf: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12d2:
	/* 0x12d2: call   12d7 <trace_chmod_common+0x12d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12d7:
	/* 0x12d7: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_12dc:
	/* 0x12dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12df:
	/* 0x12df: je     1300 <trace_chmod_common+0x1300> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12df, 0x1300, x86_l_1300);
x86_l_12e1:
	/* 0x12e1: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_12e8:
	/* 0x12e8: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12ec:
	/* 0x12ec: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ef:
	/* 0x12ef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12f2:
	/* 0x12f2: jns    14d3 <trace_chmod_common+0x14d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12f2, 0x14d3, x86_l_14d3);
x86_l_12f8:
	/* 0x12f8: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12fb:
	/* 0x12fb: jmp    14d6 <trace_chmod_common+0x14d6> */
	X86_SIM_X86_JMP(0x12fb, 0x14d6, x86_l_14d6);
x86_l_1300:
	/* 0x1300: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1302:
	/* 0x1302: jmp    2fbd <trace_chmod_common+0x2fbd> */
	X86_SIM_X86_JMP(0x1302, 0x2fbd, x86_l_2fbd);
x86_l_1307:
	/* 0x1307: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_130a:
	/* 0x130a: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_130e:
	/* 0x130e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1311:
	/* 0x1311: jns    14b6 <trace_chmod_common+0x14b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1311, 0x14b6, x86_l_14b6);
x86_l_1317:
	/* 0x1317: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_131a:
	/* 0x131a: mov    QWORD PTR [r13+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1321:
	/* 0x1321: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1325:
	/* 0x1325: mov    QWORD PTR [r13+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_132c:
	/* 0x132c: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1330:
	/* 0x1330: mov    QWORD PTR [r13+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1337:
	/* 0x1337: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_133b:
	/* 0x133b: mov    QWORD PTR [r13+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1342:
	/* 0x1342: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1346:
	/* 0x1346: mov    QWORD PTR [r13+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_134d:
	/* 0x134d: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1351:
	/* 0x1351: mov    QWORD PTR [r13+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1358:
	/* 0x1358: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_135c:
	/* 0x135c: mov    QWORD PTR [r13+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1363:
	/* 0x1363: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1367:
	/* 0x1367: mov    QWORD PTR [r13+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_136e:
	/* 0x136e: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1372:
	/* 0x1372: mov    QWORD PTR [r13+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1379:
	/* 0x1379: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_137d:
	/* 0x137d: mov    QWORD PTR [r13+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1384:
	/* 0x1384: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1388:
	/* 0x1388: mov    QWORD PTR [r13+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_138f:
	/* 0x138f: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1393:
	/* 0x1393: mov    QWORD PTR [r13+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_139a:
	/* 0x139a: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_139e:
	/* 0x139e: mov    QWORD PTR [r13+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_13a5:
	/* 0x13a5: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_13a9:
	/* 0x13a9: mov    QWORD PTR [r13+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_13b0:
	/* 0x13b0: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_13b4:
	/* 0x13b4: mov    QWORD PTR [r13+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_13bb:
	/* 0x13bb: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_13bf:
	/* 0x13bf: mov    QWORD PTR [r13+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_13c6:
	/* 0x13c6: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_13cd:
	/* 0x13cd: mov    QWORD PTR [r13+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_13d4:
	/* 0x13d4: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_13db:
	/* 0x13db: mov    QWORD PTR [r13+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_13e2:
	/* 0x13e2: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_13e9:
	/* 0x13e9: mov    QWORD PTR [r13+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_13f0:
	/* 0x13f0: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_13f7:
	/* 0x13f7: mov    QWORD PTR [r13+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_13fe:
	/* 0x13fe: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1405:
	/* 0x1405: mov    QWORD PTR [r13+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_140c:
	/* 0x140c: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1413:
	/* 0x1413: mov    QWORD PTR [r13+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_141a:
	/* 0x141a: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1421:
	/* 0x1421: mov    QWORD PTR [r13+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1428:
	/* 0x1428: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_142f:
	/* 0x142f: mov    QWORD PTR [r13+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1436:
	/* 0x1436: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_143d:
	/* 0x143d: mov    QWORD PTR [r13+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1444:
	/* 0x1444: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_144b:
	/* 0x144b: mov    QWORD PTR [r13+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1452:
	/* 0x1452: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1459:
	/* 0x1459: mov    QWORD PTR [r13+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_1460:
	/* 0x1460: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1467:
	/* 0x1467: mov    QWORD PTR [r13+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_146e:
	/* 0x146e: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1475:
	/* 0x1475: mov    QWORD PTR [r13+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_147c:
	/* 0x147c: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1483:
	/* 0x1483: mov    QWORD PTR [r13+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_148a:
	/* 0x148a: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_1491:
	/* 0x1491: mov    QWORD PTR [r13+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1498:
	/* 0x1498: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_149f:
	/* 0x149f: mov    QWORD PTR [r13+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_14a6:
	/* 0x14a6: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_14ac:
	/* 0x14ac: mov    WORD PTR [r13+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_14b1:
	/* 0x14b1: jmp    2e3 <trace_chmod_common+0x2e3> */
	X86_SIM_X86_JMP(0x14b1, 0x2e3, x86_l_2e3);
x86_l_14b6:
	/* 0x14b6: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_14bd:
	/* 0x14bd: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_14c2:
	/* 0x14c2: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_14c5:
	/* 0x14c5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14c7:
	/* 0x14c7: call   14cc <trace_chmod_common+0x14cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_14cc:
	/* 0x14cc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14ce:
	/* 0x14ce: jmp    2fbd <trace_chmod_common+0x2fbd> */
	X86_SIM_X86_JMP(0x14ce, 0x2fbd, x86_l_2fbd);
x86_l_14d3:
	/* 0x14d3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14d6:
	/* 0x14d6: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14da:
	/* 0x14da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14dd:
	/* 0x14dd: jns    14e4 <trace_chmod_common+0x14e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14dd, 0x14e4, x86_l_14e4);
x86_l_14df:
	/* 0x14df: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14e2:
	/* 0x14e2: jmp    14e6 <trace_chmod_common+0x14e6> */
	X86_SIM_X86_JMP(0x14e2, 0x14e6, x86_l_14e6);
x86_l_14e4:
	/* 0x14e4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e6:
	/* 0x14e6: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_14e9:
	/* 0x14e9: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_14ed:
	/* 0x14ed: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14ef:
	/* 0x14ef: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14f2:
	/* 0x14f2: jns    14f9 <trace_chmod_common+0x14f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14f2, 0x14f9, x86_l_14f9);
x86_l_14f4:
	/* 0x14f4: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14f7:
	/* 0x14f7: jmp    14fc <trace_chmod_common+0x14fc> */
	X86_SIM_X86_JMP(0x14f7, 0x14fc, x86_l_14fc);
x86_l_14f9:
	/* 0x14f9: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14fc:
	/* 0x14fc: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1501:
	/* 0x1501: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1504:
	/* 0x1504: jns    1508 <trace_chmod_common+0x1508> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1504, 0x1508, x86_l_1508);
x86_l_1506:
	/* 0x1506: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1508:
	/* 0x1508: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_150d:
	/* 0x150d: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1510:
	/* 0x1510: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1514:
	/* 0x1514: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1517:
	/* 0x1517: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1519:
	/* 0x1519: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_151c:
	/* 0x151c: jns    1523 <trace_chmod_common+0x1523> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x151c, 0x1523, x86_l_1523);
x86_l_151e:
	/* 0x151e: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1521:
	/* 0x1521: jmp    1525 <trace_chmod_common+0x1525> */
	X86_SIM_X86_JMP(0x1521, 0x1525, x86_l_1525);
x86_l_1523:
	/* 0x1523: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1525:
	/* 0x1525: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1528:
	/* 0x1528: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_152b:
	/* 0x152b: jns    152f <trace_chmod_common+0x152f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x152b, 0x152f, x86_l_152f);
x86_l_152d:
	/* 0x152d: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_152f:
	/* 0x152f: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1531:
	/* 0x1531: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1535:
	/* 0x1535: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1538:
	/* 0x1538: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_153c:
	/* 0x153c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_153e:
	/* 0x153e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1541:
	/* 0x1541: jns    1545 <trace_chmod_common+0x1545> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1541, 0x1545, x86_l_1545);
x86_l_1543:
	/* 0x1543: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1545:
	/* 0x1545: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_154a:
	/* 0x154a: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_154d:
	/* 0x154d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1550:
	/* 0x1550: jns    1557 <trace_chmod_common+0x1557> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1550, 0x1557, x86_l_1557);
x86_l_1552:
	/* 0x1552: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1555:
	/* 0x1555: jmp    1559 <trace_chmod_common+0x1559> */
	X86_SIM_X86_JMP(0x1555, 0x1559, x86_l_1559);
x86_l_1557:
	/* 0x1557: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1559:
	/* 0x1559: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_155d:
	/* 0x155d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_155f:
	/* 0x155f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1562:
	/* 0x1562: jns    1569 <trace_chmod_common+0x1569> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1562, 0x1569, x86_l_1569);
x86_l_1564:
	/* 0x1564: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1567:
	/* 0x1567: jmp    156b <trace_chmod_common+0x156b> */
	X86_SIM_X86_JMP(0x1567, 0x156b, x86_l_156b);
x86_l_1569:
	/* 0x1569: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156b:
	/* 0x156b: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_156e:
	/* 0x156e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1571:
	/* 0x1571: jns    1575 <trace_chmod_common+0x1575> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1571, 0x1575, x86_l_1575);
x86_l_1573:
	/* 0x1573: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1575:
	/* 0x1575: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1577:
	/* 0x1577: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_157b:
	/* 0x157b: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_157e:
	/* 0x157e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1582:
	/* 0x1582: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1584:
	/* 0x1584: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1587:
	/* 0x1587: jns    158b <trace_chmod_common+0x158b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1587, 0x158b, x86_l_158b);
x86_l_1589:
	/* 0x1589: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158b:
	/* 0x158b: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1590:
	/* 0x1590: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1593:
	/* 0x1593: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1595:
	/* 0x1595: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1598:
	/* 0x1598: jns    159f <trace_chmod_common+0x159f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1598, 0x159f, x86_l_159f);
x86_l_159a:
	/* 0x159a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_159d:
	/* 0x159d: jmp    15a1 <trace_chmod_common+0x15a1> */
	X86_SIM_X86_JMP(0x159d, 0x15a1, x86_l_15a1);
x86_l_159f:
	/* 0x159f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a1:
	/* 0x15a1: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15a4:
	/* 0x15a4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15a7:
	/* 0x15a7: jns    15ab <trace_chmod_common+0x15ab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15a7, 0x15ab, x86_l_15ab);
x86_l_15a9:
	/* 0x15a9: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ab:
	/* 0x15ab: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15ad:
	/* 0x15ad: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15b1:
	/* 0x15b1: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15b4:
	/* 0x15b4: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15b8:
	/* 0x15b8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15ba:
	/* 0x15ba: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15bd:
	/* 0x15bd: jns    15c4 <trace_chmod_common+0x15c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15bd, 0x15c4, x86_l_15c4);
x86_l_15bf:
	/* 0x15bf: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15c2:
	/* 0x15c2: jmp    15c6 <trace_chmod_common+0x15c6> */
	X86_SIM_X86_JMP(0x15c2, 0x15c6, x86_l_15c6);
x86_l_15c4:
	/* 0x15c4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c6:
	/* 0x15c6: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_15ca:
	/* 0x15ca: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15cd:
	/* 0x15cd: jns    15d1 <trace_chmod_common+0x15d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15cd, 0x15d1, x86_l_15d1);
x86_l_15cf:
	/* 0x15cf: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d1:
	/* 0x15d1: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15d6:
	/* 0x15d6: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15d9:
	/* 0x15d9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15db:
	/* 0x15db: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15de:
	/* 0x15de: jns    15e5 <trace_chmod_common+0x15e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15de, 0x15e5, x86_l_15e5);
x86_l_15e0:
	/* 0x15e0: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e3:
	/* 0x15e3: jmp    15e7 <trace_chmod_common+0x15e7> */
	X86_SIM_X86_JMP(0x15e3, 0x15e7, x86_l_15e7);
x86_l_15e5:
	/* 0x15e5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15e7:
	/* 0x15e7: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15ea:
	/* 0x15ea: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15ed:
	/* 0x15ed: jns    15f1 <trace_chmod_common+0x15f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ed, 0x15f1, x86_l_15f1);
x86_l_15ef:
	/* 0x15ef: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15f1:
	/* 0x15f1: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_15f3:
	/* 0x15f3: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15f7:
	/* 0x15f7: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15fa:
	/* 0x15fa: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15fe:
	/* 0x15fe: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1600:
	/* 0x1600: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1603:
	/* 0x1603: jns    160a <trace_chmod_common+0x160a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1603, 0x160a, x86_l_160a);
x86_l_1605:
	/* 0x1605: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1608:
	/* 0x1608: jmp    160c <trace_chmod_common+0x160c> */
	X86_SIM_X86_JMP(0x1608, 0x160c, x86_l_160c);
x86_l_160a:
	/* 0x160a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_160c:
	/* 0x160c: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1610:
	/* 0x1610: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1613:
	/* 0x1613: jns    1617 <trace_chmod_common+0x1617> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1613, 0x1617, x86_l_1617);
x86_l_1615:
	/* 0x1615: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1617:
	/* 0x1617: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1619:
	/* 0x1619: jne    1777 <trace_chmod_common+0x1777> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1619, 0x1777, x86_l_1777);
x86_l_161f:
	/* 0x161f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1621:
	/* 0x1621: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1624:
	/* 0x1624: jns    174d <trace_chmod_common+0x174d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1624, 0x174d, x86_l_174d);
x86_l_162a:
	/* 0x162a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162d:
	/* 0x162d: jmp    174f <trace_chmod_common+0x174f> */
	X86_SIM_X86_JMP(0x162d, 0x174f, x86_l_174f);
x86_l_1632:
	/* 0x1632: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1637:
	/* 0x1637: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_163b:
	/* 0x163b: jl     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_L, 0x163b, 0x1127, x86_l_1127);
x86_l_1641:
	/* 0x1641: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1644:
	/* 0x1644: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_164a:
	/* 0x164a: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_164f:
	/* 0x164f: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1652:
	/* 0x1652: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1655:
	/* 0x1655: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1658:
	/* 0x1658: js     11dd <trace_chmod_common+0x11dd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1658, 0x11dd, x86_l_11dd);
x86_l_165e:
	/* 0x165e: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1660:
	/* 0x1660: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1664:
	/* 0x1664: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1667:
	/* 0x1667: jns    166e <trace_chmod_common+0x166e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1667, 0x166e, x86_l_166e);
x86_l_1669:
	/* 0x1669: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_166c:
	/* 0x166c: jmp    1670 <trace_chmod_common+0x1670> */
	X86_SIM_X86_JMP(0x166c, 0x1670, x86_l_1670);
x86_l_166e:
	/* 0x166e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1670:
	/* 0x1670: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1673:
	/* 0x1673: je     16f8 <trace_chmod_common+0x16f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1673, 0x16f8, x86_l_16f8);
x86_l_1679:
	/* 0x1679: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_167c:
	/* 0x167c: je     16f8 <trace_chmod_common+0x16f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x167c, 0x16f8, x86_l_16f8);
x86_l_167e:
	/* 0x167e: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1682:
	/* 0x1682: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1685:
	/* 0x1685: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_168b:
	/* 0x168b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_168e:
	/* 0x168e: jns    1697 <trace_chmod_common+0x1697> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x168e, 0x1697, x86_l_1697);
x86_l_1690:
	/* 0x1690: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1693:
	/* 0x1693: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1697:
	/* 0x1697: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_169b:
	/* 0x169b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_169e:
	/* 0x169e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_16a5:
	/* 0x16a5: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_16a7:
	/* 0x16a7: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16aa:
	/* 0x16aa: jb     2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16aa, 0x2900, x86_l_2900);
x86_l_16b0:
	/* 0x16b0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_16b3:
	/* 0x16b3: je     1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16b3, 0x1124, x86_l_1124);
x86_l_16b9:
	/* 0x16b9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_16bf:
	/* 0x16bf: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16c2:
	/* 0x16c2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_16c5:
	/* 0x16c5: jns    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16c5, 0x111a, x86_l_111a);
x86_l_16cb:
	/* 0x16cb: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_16cf:
	/* 0x16cf: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d2:
	/* 0x16d2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_16d5:
	/* 0x16d5: je     1a13 <trace_chmod_common+0x1a13> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d5, 0x1a13, x86_l_1a13);
x86_l_16db:
	/* 0x16db: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_16df:
	/* 0x16df: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_16e4:
	/* 0x16e4: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_16e8:
	/* 0x16e8: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_16eb:
	/* 0x16eb: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_16ee:
	/* 0x16ee: jne    16d2 <trace_chmod_common+0x16d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16ee, 0x16d2, x86_l_16d2);
x86_l_16f0:
	/* 0x16f0: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_16f3:
	/* 0x16f3: jmp    1a18 <trace_chmod_common+0x1a18> */
	X86_SIM_X86_JMP(0x16f3, 0x1a18, x86_l_1a18);
x86_l_16f8:
	/* 0x16f8: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16fb:
	/* 0x16fb: jne    1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16fb, 0x1124, x86_l_1124);
x86_l_1701:
	/* 0x1701: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1704:
	/* 0x1704: je     1124 <trace_chmod_common+0x1124> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1704, 0x1124, x86_l_1124);
x86_l_170a:
	/* 0x170a: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_170e:
	/* 0x170e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1711:
	/* 0x1711: jns    1718 <trace_chmod_common+0x1718> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1711, 0x1718, x86_l_1718);
x86_l_1713:
	/* 0x1713: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1716:
	/* 0x1716: jmp    171a <trace_chmod_common+0x171a> */
	X86_SIM_X86_JMP(0x1716, 0x171a, x86_l_171a);
x86_l_1718:
	/* 0x1718: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_171a:
	/* 0x171a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_171d:
	/* 0x171d: jns    1724 <trace_chmod_common+0x1724> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x171d, 0x1724, x86_l_1724);
x86_l_171f:
	/* 0x171f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1722:
	/* 0x1722: jmp    1726 <trace_chmod_common+0x1726> */
	X86_SIM_X86_JMP(0x1722, 0x1726, x86_l_1726);
x86_l_1724:
	/* 0x1724: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1726:
	/* 0x1726: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1729:
	/* 0x1729: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_172c:
	/* 0x172c: jns    1733 <trace_chmod_common+0x1733> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x172c, 0x1733, x86_l_1733);
x86_l_172e:
	/* 0x172e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1731:
	/* 0x1731: jmp    1735 <trace_chmod_common+0x1735> */
	X86_SIM_X86_JMP(0x1731, 0x1735, x86_l_1735);
x86_l_1733:
	/* 0x1733: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1735:
	/* 0x1735: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1739:
	/* 0x1739: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_173c:
	/* 0x173c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_173f:
	/* 0x173f: jns    1a43 <trace_chmod_common+0x1a43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x173f, 0x1a43, x86_l_1a43);
x86_l_1745:
	/* 0x1745: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1748:
	/* 0x1748: jmp    1a45 <trace_chmod_common+0x1a45> */
	X86_SIM_X86_JMP(0x1748, 0x1a45, x86_l_1a45);
x86_l_174d:
	/* 0x174d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174f:
	/* 0x174f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1752:
	/* 0x1752: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1755:
	/* 0x1755: jns    1759 <trace_chmod_common+0x1759> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1755, 0x1759, x86_l_1759);
x86_l_1757:
	/* 0x1757: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1759:
	/* 0x1759: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_175b:
	/* 0x175b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_175f:
	/* 0x175f: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1762:
	/* 0x1762: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1766:
	/* 0x1766: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1768:
	/* 0x1768: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_176b:
	/* 0x176b: jns    176f <trace_chmod_common+0x176f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x176b, 0x176f, x86_l_176f);
x86_l_176d:
	/* 0x176d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_176f:
	/* 0x176f: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1774:
	/* 0x1774: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1777:
	/* 0x1777: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_177c:
	/* 0x177c: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_177f:
	/* 0x177f: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1786:
	/* 0x1786: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1789:
	/* 0x1789: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_178c:
	/* 0x178c: jns    1793 <trace_chmod_common+0x1793> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178c, 0x1793, x86_l_1793);
x86_l_178e:
	/* 0x178e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1791:
	/* 0x1791: jmp    1795 <trace_chmod_common+0x1795> */
	X86_SIM_X86_JMP(0x1791, 0x1795, x86_l_1795);
x86_l_1793:
	/* 0x1793: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1795:
	/* 0x1795: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1799:
	/* 0x1799: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_179b:
	/* 0x179b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_179e:
	/* 0x179e: jns    17a5 <trace_chmod_common+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x179e, 0x17a5, x86_l_17a5);
x86_l_17a0:
	/* 0x17a0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a3:
	/* 0x17a3: jmp    17a7 <trace_chmod_common+0x17a7> */
	X86_SIM_X86_JMP(0x17a3, 0x17a7, x86_l_17a7);
x86_l_17a5:
	/* 0x17a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a7:
	/* 0x17a7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17aa:
	/* 0x17aa: jns    17ae <trace_chmod_common+0x17ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17aa, 0x17ae, x86_l_17ae);
x86_l_17ac:
	/* 0x17ac: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ae:
	/* 0x17ae: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17b3:
	/* 0x17b3: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_17b7:
	/* 0x17b7: call   17bc <trace_chmod_common+0x17bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_17bc:
	/* 0x17bc: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_17c0:
	/* 0x17c0: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_17c4:
	/* 0x17c4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17c7:
	/* 0x17c7: jns    17ce <trace_chmod_common+0x17ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c7, 0x17ce, x86_l_17ce);
x86_l_17c9:
	/* 0x17c9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17cc:
	/* 0x17cc: jmp    17d0 <trace_chmod_common+0x17d0> */
	X86_SIM_X86_JMP(0x17cc, 0x17d0, x86_l_17d0);
x86_l_17ce:
	/* 0x17ce: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17d0:
	/* 0x17d0: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17d5:
	/* 0x17d5: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17d8:
	/* 0x17d8: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_17dc:
	/* 0x17dc: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_17df:
	/* 0x17df: jns    17e6 <trace_chmod_common+0x17e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17df, 0x17e6, x86_l_17e6);
x86_l_17e1:
	/* 0x17e1: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17e4:
	/* 0x17e4: jmp    17e8 <trace_chmod_common+0x17e8> */
	X86_SIM_X86_JMP(0x17e4, 0x17e8, x86_l_17e8);
x86_l_17e6:
	/* 0x17e6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17e8:
	/* 0x17e8: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17ed:
	/* 0x17ed: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_17f1:
	/* 0x17f1: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_17f5:
	/* 0x17f5: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17f8:
	/* 0x17f8: jns    1800 <trace_chmod_common+0x1800> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17f8, 0x1800, x86_l_1800);
x86_l_17fa:
	/* 0x17fa: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17fe:
	/* 0x17fe: jmp    1802 <trace_chmod_common+0x1802> */
	X86_SIM_X86_JMP(0x17fe, 0x1802, x86_l_1802);
x86_l_1800:
	/* 0x1800: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1802:
	/* 0x1802: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1805:
	/* 0x1805: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_180a:
	/* 0x180a: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_180e:
	/* 0x180e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1811:
	/* 0x1811: jns    181e <trace_chmod_common+0x181e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1811, 0x181e, x86_l_181e);
x86_l_1813:
	/* 0x1813: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1815:
	/* 0x1815: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1817:
	/* 0x1817: je     181e <trace_chmod_common+0x181e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1817, 0x181e, x86_l_181e);
x86_l_1819:
	/* 0x1819: or     BYTE PTR [r14+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_181e:
	/* 0x181e: lea    rdi,[r14+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1822:
	/* 0x1822: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_182a:
	/* 0x182a: mov    QWORD PTR [r14+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_1832:
	/* 0x1832: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1837:
	/* 0x1837: call   183c <trace_chmod_common+0x183c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_183c:
	/* 0x183c: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_183f:
	/* 0x183f: mov    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1842:
	/* 0x1842: jns    184a <trace_chmod_common+0x184a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1842, 0x184a, x86_l_184a);
x86_l_1844:
	/* 0x1844: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1848:
	/* 0x1848: jmp    184c <trace_chmod_common+0x184c> */
	X86_SIM_X86_JMP(0x1848, 0x184c, x86_l_184c);
x86_l_184a:
	/* 0x184a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_184c:
	/* 0x184c: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1851:
	/* 0x1851: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1855:
	/* 0x1855: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1858:
	/* 0x1858: jns    185f <trace_chmod_common+0x185f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1858, 0x185f, x86_l_185f);
x86_l_185a:
	/* 0x185a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_185d:
	/* 0x185d: jmp    1861 <trace_chmod_common+0x1861> */
	X86_SIM_X86_JMP(0x185d, 0x1861, x86_l_1861);
x86_l_185f:
	/* 0x185f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1861:
	/* 0x1861: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1864:
	/* 0x1864: jns    18b1 <trace_chmod_common+0x18b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1864, 0x18b1, x86_l_18b1);
x86_l_1866:
	/* 0x1866: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1869:
	/* 0x1869: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_186e:
	/* 0x186e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1872:
	/* 0x1872: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1877:
	/* 0x1877: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_187b:
	/* 0x187b: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1880:
	/* 0x1880: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1884:
	/* 0x1884: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1889:
	/* 0x1889: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_188d:
	/* 0x188d: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1892:
	/* 0x1892: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1896:
	/* 0x1896: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_189b:
	/* 0x189b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_189f:
	/* 0x189f: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_18a4:
	/* 0x18a4: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_18a8:
	/* 0x18a8: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_18ad:
	/* 0x18ad: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_18b1:
	/* 0x18b1: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18b4:
	/* 0x18b4: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_18b8:
	/* 0x18b8: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_18bd:
	/* 0x18bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c0:
	/* 0x18c0: jns    19df <trace_chmod_common+0x19df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c0, 0x19df, x86_l_19df);
x86_l_18c6:
	/* 0x18c6: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_18c9:
	/* 0x18c9: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18cb:
	/* 0x18cb: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_18cd:
	/* 0x18cd: je     19ee <trace_chmod_common+0x19ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18cd, 0x19ee, x86_l_19ee);
x86_l_18d3:
	/* 0x18d3: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_18d7:
	/* 0x18d7: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_18da:
	/* 0x18da: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18dc:
	/* 0x18dc: je     19ee <trace_chmod_common+0x19ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18dc, 0x19ee, x86_l_19ee);
x86_l_18e2:
	/* 0x18e2: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_18e6:
	/* 0x18e6: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_18e9:
	/* 0x18e9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18eb:
	/* 0x18eb: je     19ee <trace_chmod_common+0x19ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18eb, 0x19ee, x86_l_19ee);
x86_l_18f1:
	/* 0x18f1: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_18f5:
	/* 0x18f5: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_18f8:
	/* 0x18f8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18fa:
	/* 0x18fa: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18fa, 0x19f8, x86_l_19f8);
x86_l_1900:
	/* 0x1900: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1904:
	/* 0x1904: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1909:
	/* 0x1909: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_190c:
	/* 0x190c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_190e:
	/* 0x190e: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x190e, 0x19f8, x86_l_19f8);
x86_l_1914:
	/* 0x1914: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1918:
	/* 0x1918: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_191d:
	/* 0x191d: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_1920:
	/* 0x1920: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1922:
	/* 0x1922: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1922, 0x19f8, x86_l_19f8);
x86_l_1928:
	/* 0x1928: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_192c:
	/* 0x192c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1931:
	/* 0x1931: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_1934:
	/* 0x1934: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1936:
	/* 0x1936: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1936, 0x19f8, x86_l_19f8);
x86_l_193c:
	/* 0x193c: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_1940:
	/* 0x1940: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1945:
	/* 0x1945: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_1948:
	/* 0x1948: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_194a:
	/* 0x194a: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194a, 0x19f8, x86_l_19f8);
x86_l_1950:
	/* 0x1950: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1954:
	/* 0x1954: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1959:
	/* 0x1959: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_195c:
	/* 0x195c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_195e:
	/* 0x195e: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x195e, 0x19f8, x86_l_19f8);
x86_l_1964:
	/* 0x1964: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1968:
	/* 0x1968: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_196d:
	/* 0x196d: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_1970:
	/* 0x1970: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1972:
	/* 0x1972: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1972, 0x19f8, x86_l_19f8);
x86_l_1978:
	/* 0x1978: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_197c:
	/* 0x197c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1981:
	/* 0x1981: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1984:
	/* 0x1984: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1986:
	/* 0x1986: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1986, 0x19f8, x86_l_19f8);
x86_l_1988:
	/* 0x1988: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_198c:
	/* 0x198c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1991:
	/* 0x1991: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1994:
	/* 0x1994: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1996:
	/* 0x1996: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1996, 0x19f8, x86_l_19f8);
x86_l_1998:
	/* 0x1998: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_199c:
	/* 0x199c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19a1:
	/* 0x19a1: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_19a4:
	/* 0x19a4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19a6:
	/* 0x19a6: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a6, 0x19f8, x86_l_19f8);
x86_l_19a8:
	/* 0x19a8: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_19ac:
	/* 0x19ac: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19b1:
	/* 0x19b1: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_19b4:
	/* 0x19b4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19b6:
	/* 0x19b6: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b6, 0x19f8, x86_l_19f8);
x86_l_19b8:
	/* 0x19b8: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_19bc:
	/* 0x19bc: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19c1:
	/* 0x19c1: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_19c4:
	/* 0x19c4: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19c6:
	/* 0x19c6: je     19f8 <trace_chmod_common+0x19f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c6, 0x19f8, x86_l_19f8);
x86_l_19c8:
	/* 0x19c8: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19cd:
	/* 0x19cd: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_19d1:
	/* 0x19d1: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19d6:
	/* 0x19d6: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19da:
	/* 0x19da: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_19dd:
	/* 0x19dd: jmp    19ee <trace_chmod_common+0x19ee> */
	X86_SIM_X86_JMP(0x19dd, 0x19ee, x86_l_19ee);
x86_l_19df:
	/* 0x19df: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_19e7:
	/* 0x19e7: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19ee:
	/* 0x19ee: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19f3:
	/* 0x19f3: jmp    233 <trace_chmod_common+0x233> */
	X86_SIM_X86_JMP(0x19f3, 0x233, x86_l_233);
x86_l_19f8:
	/* 0x19f8: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_19fd:
	/* 0x19fd: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a01:
	/* 0x1a01: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a04:
	/* 0x1a04: mov    rbp,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a09:
	/* 0x1a09: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a0e:
	/* 0x1a0e: jmp    233 <trace_chmod_common+0x233> */
	X86_SIM_X86_JMP(0x1a0e, 0x233, x86_l_233);
x86_l_1a13:
	/* 0x1a13: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a18:
	/* 0x1a18: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a1c:
	/* 0x1a1c: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a1c, 0x28ab, x86_l_28ab);
x86_l_1a22:
	/* 0x1a22: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a25:
	/* 0x1a25: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1a2b:
	/* 0x1a2b: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1a30:
	/* 0x1a30: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a33:
	/* 0x1a33: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a37:
	/* 0x1a37: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a3a:
	/* 0x1a3a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a3d:
	/* 0x1a3d: js     1745 <trace_chmod_common+0x1745> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a3d, 0x1745, x86_l_1745);
x86_l_1a43:
	/* 0x1a43: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a45:
	/* 0x1a45: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a49:
	/* 0x1a49: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1a4c:
	/* 0x1a4c: jns    1a53 <trace_chmod_common+0x1a53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a4c, 0x1a53, x86_l_1a53);
x86_l_1a4e:
	/* 0x1a4e: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a51:
	/* 0x1a51: jmp    1a56 <trace_chmod_common+0x1a56> */
	X86_SIM_X86_JMP(0x1a51, 0x1a56, x86_l_1a56);
x86_l_1a53:
	/* 0x1a53: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a56:
	/* 0x1a56: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a59:
	/* 0x1a59: je     1ad3 <trace_chmod_common+0x1ad3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a59, 0x1ad3, x86_l_1ad3);
x86_l_1a5b:
	/* 0x1a5b: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1a5e:
	/* 0x1a5e: je     1ad3 <trace_chmod_common+0x1ad3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5e, 0x1ad3, x86_l_1ad3);
x86_l_1a60:
	/* 0x1a60: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a64:
	/* 0x1a64: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a67:
	/* 0x1a67: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1a6d:
	/* 0x1a6d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a70:
	/* 0x1a70: jns    1a79 <trace_chmod_common+0x1a79> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a70, 0x1a79, x86_l_1a79);
x86_l_1a72:
	/* 0x1a72: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a75:
	/* 0x1a75: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a79:
	/* 0x1a79: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a7d:
	/* 0x1a7d: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1a80:
	/* 0x1a80: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1a87:
	/* 0x1a87: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1a89:
	/* 0x1a89: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a8c:
	/* 0x1a8c: jb     2900 <trace_chmod_common+0x2900> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a8c, 0x2900, x86_l_2900);
x86_l_1a92:
	/* 0x1a92: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1a95:
	/* 0x1a95: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a95, 0x1127, x86_l_1127);
x86_l_1a9b:
	/* 0x1a9b: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1aa1:
	/* 0x1aa1: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1aa4:
	/* 0x1aa4: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1aa7:
	/* 0x1aa7: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aa7, 0x271b, x86_l_271b);
x86_l_1aad:
	/* 0x1aad: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ab1:
	/* 0x1ab1: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ab4:
	/* 0x1ab4: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ab7:
	/* 0x1ab7: je     1b22 <trace_chmod_common+0x1b22> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ab7, 0x1b22, x86_l_1b22);
x86_l_1ab9:
	/* 0x1ab9: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1abd:
	/* 0x1abd: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1ac2:
	/* 0x1ac2: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ac6:
	/* 0x1ac6: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ac9:
	/* 0x1ac9: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1acc:
	/* 0x1acc: jne    1ab4 <trace_chmod_common+0x1ab4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1acc, 0x1ab4, x86_l_1ab4);
x86_l_1ace:
	/* 0x1ace: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ad1:
	/* 0x1ad1: jmp    1b27 <trace_chmod_common+0x1b27> */
	X86_SIM_X86_JMP(0x1ad1, 0x1b27, x86_l_1b27);
x86_l_1ad3:
	/* 0x1ad3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ad6:
	/* 0x1ad6: jne    1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ad6, 0x1127, x86_l_1127);
x86_l_1adc:
	/* 0x1adc: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1adf:
	/* 0x1adf: je     1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1adf, 0x1127, x86_l_1127);
x86_l_1ae5:
	/* 0x1ae5: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ae9:
	/* 0x1ae9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1aec:
	/* 0x1aec: jns    1af3 <trace_chmod_common+0x1af3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1aec, 0x1af3, x86_l_1af3);
x86_l_1aee:
	/* 0x1aee: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af1:
	/* 0x1af1: jmp    1af6 <trace_chmod_common+0x1af6> */
	X86_SIM_X86_JMP(0x1af1, 0x1af6, x86_l_1af6);
x86_l_1af3:
	/* 0x1af3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1af6:
	/* 0x1af6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1af9:
	/* 0x1af9: jns    1b00 <trace_chmod_common+0x1b00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af9, 0x1b00, x86_l_1b00);
x86_l_1afb:
	/* 0x1afb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1afe:
	/* 0x1afe: jmp    1b02 <trace_chmod_common+0x1b02> */
	X86_SIM_X86_JMP(0x1afe, 0x1b02, x86_l_1b02);
x86_l_1b00:
	/* 0x1b00: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b02:
	/* 0x1b02: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b05:
	/* 0x1b05: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b08:
	/* 0x1b08: jns    1b0f <trace_chmod_common+0x1b0f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b08, 0x1b0f, x86_l_1b0f);
x86_l_1b0a:
	/* 0x1b0a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b0d:
	/* 0x1b0d: jmp    1b11 <trace_chmod_common+0x1b11> */
	X86_SIM_X86_JMP(0x1b0d, 0x1b11, x86_l_1b11);
x86_l_1b0f:
	/* 0x1b0f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b11:
	/* 0x1b11: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b15:
	/* 0x1b15: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b18:
	/* 0x1b18: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b1b:
	/* 0x1b1b: jns    1b4a <trace_chmod_common+0x1b4a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1b, 0x1b4a, x86_l_1b4a);
x86_l_1b1d:
	/* 0x1b1d: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b20:
	/* 0x1b20: jmp    1b4c <trace_chmod_common+0x1b4c> */
	X86_SIM_X86_JMP(0x1b20, 0x1b4c, x86_l_1b4c);
x86_l_1b22:
	/* 0x1b22: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1b27:
	/* 0x1b27: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b2b:
	/* 0x1b2b: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1b2b, 0x28ae, x86_l_28ae);
x86_l_1b31:
	/* 0x1b31: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b34:
	/* 0x1b34: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1b3a:
	/* 0x1b3a: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1b3f:
	/* 0x1b3f: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b42:
	/* 0x1b42: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b45:
	/* 0x1b45: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b48:
	/* 0x1b48: js     1b1d <trace_chmod_common+0x1b1d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b48, 0x1b1d, x86_l_1b1d);
x86_l_1b4a:
	/* 0x1b4a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b4c:
	/* 0x1b4c: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b50:
	/* 0x1b50: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b53:
	/* 0x1b53: jns    1b5a <trace_chmod_common+0x1b5a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b53, 0x1b5a, x86_l_1b5a);
x86_l_1b55:
	/* 0x1b55: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b58:
	/* 0x1b58: jmp    1b5c <trace_chmod_common+0x1b5c> */
	X86_SIM_X86_JMP(0x1b58, 0x1b5c, x86_l_1b5c);
x86_l_1b5a:
	/* 0x1b5a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b5c:
	/* 0x1b5c: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b5f:
	/* 0x1b5f: je     1bd9 <trace_chmod_common+0x1bd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b5f, 0x1bd9, x86_l_1bd9);
x86_l_1b61:
	/* 0x1b61: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1b64:
	/* 0x1b64: je     1bd9 <trace_chmod_common+0x1bd9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b64, 0x1bd9, x86_l_1bd9);
x86_l_1b66:
	/* 0x1b66: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b6a:
	/* 0x1b6a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b6d:
	/* 0x1b6d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1b73:
	/* 0x1b73: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b76:
	/* 0x1b76: jns    1b7f <trace_chmod_common+0x1b7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b76, 0x1b7f, x86_l_1b7f);
x86_l_1b78:
	/* 0x1b78: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7b:
	/* 0x1b7b: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b7f:
	/* 0x1b7f: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b83:
	/* 0x1b83: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1b86:
	/* 0x1b86: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b8d:
	/* 0x1b8d: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1b8f:
	/* 0x1b8f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b92:
	/* 0x1b92: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b92, 0x28fc, x86_l_28fc);
x86_l_1b98:
	/* 0x1b98: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1b9b:
	/* 0x1b9b: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b9b, 0x28ab, x86_l_28ab);
x86_l_1ba1:
	/* 0x1ba1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1ba7:
	/* 0x1ba7: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1baa:
	/* 0x1baa: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1bad:
	/* 0x1bad: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bad, 0x282d, x86_l_282d);
x86_l_1bb3:
	/* 0x1bb3: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bb7:
	/* 0x1bb7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bba:
	/* 0x1bba: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1bbd:
	/* 0x1bbd: je     1c27 <trace_chmod_common+0x1c27> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bbd, 0x1c27, x86_l_1c27);
x86_l_1bbf:
	/* 0x1bbf: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1bc3:
	/* 0x1bc3: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1bc8:
	/* 0x1bc8: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1bcc:
	/* 0x1bcc: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1bcf:
	/* 0x1bcf: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1bd2:
	/* 0x1bd2: jne    1bba <trace_chmod_common+0x1bba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bd2, 0x1bba, x86_l_1bba);
x86_l_1bd4:
	/* 0x1bd4: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1bd7:
	/* 0x1bd7: jmp    1c2c <trace_chmod_common+0x1c2c> */
	X86_SIM_X86_JMP(0x1bd7, 0x1c2c, x86_l_1c2c);
x86_l_1bd9:
	/* 0x1bd9: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1bdc:
	/* 0x1bdc: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bdc, 0x28ab, x86_l_28ab);
x86_l_1be2:
	/* 0x1be2: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1be5:
	/* 0x1be5: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1be5, 0x28ab, x86_l_28ab);
x86_l_1beb:
	/* 0x1beb: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bef:
	/* 0x1bef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bf2:
	/* 0x1bf2: jns    1bf9 <trace_chmod_common+0x1bf9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bf2, 0x1bf9, x86_l_1bf9);
x86_l_1bf4:
	/* 0x1bf4: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bf7:
	/* 0x1bf7: jmp    1bfb <trace_chmod_common+0x1bfb> */
	X86_SIM_X86_JMP(0x1bf7, 0x1bfb, x86_l_1bfb);
x86_l_1bf9:
	/* 0x1bf9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bfb:
	/* 0x1bfb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bfe:
	/* 0x1bfe: jns    1c05 <trace_chmod_common+0x1c05> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bfe, 0x1c05, x86_l_1c05);
x86_l_1c00:
	/* 0x1c00: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c03:
	/* 0x1c03: jmp    1c07 <trace_chmod_common+0x1c07> */
	X86_SIM_X86_JMP(0x1c03, 0x1c07, x86_l_1c07);
x86_l_1c05:
	/* 0x1c05: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c07:
	/* 0x1c07: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c0a:
	/* 0x1c0a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c0d:
	/* 0x1c0d: jns    1c14 <trace_chmod_common+0x1c14> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c0d, 0x1c14, x86_l_1c14);
x86_l_1c0f:
	/* 0x1c0f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c12:
	/* 0x1c12: jmp    1c16 <trace_chmod_common+0x1c16> */
	X86_SIM_X86_JMP(0x1c12, 0x1c16, x86_l_1c16);
x86_l_1c14:
	/* 0x1c14: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c16:
	/* 0x1c16: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c1a:
	/* 0x1c1a: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c1d:
	/* 0x1c1d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c20:
	/* 0x1c20: jns    1c4f <trace_chmod_common+0x1c4f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c20, 0x1c4f, x86_l_1c4f);
x86_l_1c22:
	/* 0x1c22: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c25:
	/* 0x1c25: jmp    1c51 <trace_chmod_common+0x1c51> */
	X86_SIM_X86_JMP(0x1c25, 0x1c51, x86_l_1c51);
x86_l_1c27:
	/* 0x1c27: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c2c:
	/* 0x1c2c: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c30:
	/* 0x1c30: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c30, 0x28ab, x86_l_28ab);
x86_l_1c36:
	/* 0x1c36: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c39:
	/* 0x1c39: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1c3f:
	/* 0x1c3f: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1c44:
	/* 0x1c44: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c47:
	/* 0x1c47: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c4a:
	/* 0x1c4a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c4d:
	/* 0x1c4d: js     1c22 <trace_chmod_common+0x1c22> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c4d, 0x1c22, x86_l_1c22);
x86_l_1c4f:
	/* 0x1c4f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c51:
	/* 0x1c51: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c55:
	/* 0x1c55: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1c58:
	/* 0x1c58: jns    1c5f <trace_chmod_common+0x1c5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c58, 0x1c5f, x86_l_1c5f);
x86_l_1c5a:
	/* 0x1c5a: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c5d:
	/* 0x1c5d: jmp    1c62 <trace_chmod_common+0x1c62> */
	X86_SIM_X86_JMP(0x1c5d, 0x1c62, x86_l_1c62);
x86_l_1c5f:
	/* 0x1c5f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c62:
	/* 0x1c62: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c65:
	/* 0x1c65: je     1cdf <trace_chmod_common+0x1cdf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c65, 0x1cdf, x86_l_1cdf);
x86_l_1c67:
	/* 0x1c67: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c6a:
	/* 0x1c6a: je     1cdf <trace_chmod_common+0x1cdf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c6a, 0x1cdf, x86_l_1cdf);
x86_l_1c6c:
	/* 0x1c6c: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c70:
	/* 0x1c70: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c73:
	/* 0x1c73: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c79:
	/* 0x1c79: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c7c:
	/* 0x1c7c: jns    1c85 <trace_chmod_common+0x1c85> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c7c, 0x1c85, x86_l_1c85);
x86_l_1c7e:
	/* 0x1c7e: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c81:
	/* 0x1c81: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c85:
	/* 0x1c85: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c89:
	/* 0x1c89: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c8c:
	/* 0x1c8c: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c93:
	/* 0x1c93: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1c95:
	/* 0x1c95: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c98:
	/* 0x1c98: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c98, 0x28fc, x86_l_28fc);
x86_l_1c9e:
	/* 0x1c9e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1ca1:
	/* 0x1ca1: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ca1, 0x28ae, x86_l_28ae);
x86_l_1ca7:
	/* 0x1ca7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1cad:
	/* 0x1cad: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1cb0:
	/* 0x1cb0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1cb3:
	/* 0x1cb3: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb3, 0x271b, x86_l_271b);
x86_l_1cb9:
	/* 0x1cb9: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1cbd:
	/* 0x1cbd: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cc0:
	/* 0x1cc0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1cc3:
	/* 0x1cc3: je     1d2e <trace_chmod_common+0x1d2e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc3, 0x1d2e, x86_l_1d2e);
x86_l_1cc5:
	/* 0x1cc5: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1cc9:
	/* 0x1cc9: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1cce:
	/* 0x1cce: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1cd2:
	/* 0x1cd2: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1cd5:
	/* 0x1cd5: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1cd8:
	/* 0x1cd8: jne    1cc0 <trace_chmod_common+0x1cc0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cd8, 0x1cc0, x86_l_1cc0);
x86_l_1cda:
	/* 0x1cda: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1cdd:
	/* 0x1cdd: jmp    1d33 <trace_chmod_common+0x1d33> */
	X86_SIM_X86_JMP(0x1cdd, 0x1d33, x86_l_1d33);
x86_l_1cdf:
	/* 0x1cdf: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ce2:
	/* 0x1ce2: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ce2, 0x28ae, x86_l_28ae);
x86_l_1ce8:
	/* 0x1ce8: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ceb:
	/* 0x1ceb: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ceb, 0x28ae, x86_l_28ae);
x86_l_1cf1:
	/* 0x1cf1: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cf5:
	/* 0x1cf5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cf8:
	/* 0x1cf8: jns    1cff <trace_chmod_common+0x1cff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cf8, 0x1cff, x86_l_1cff);
x86_l_1cfa:
	/* 0x1cfa: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cfd:
	/* 0x1cfd: jmp    1d02 <trace_chmod_common+0x1d02> */
	X86_SIM_X86_JMP(0x1cfd, 0x1d02, x86_l_1d02);
x86_l_1cff:
	/* 0x1cff: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d02:
	/* 0x1d02: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d05:
	/* 0x1d05: jns    1d0c <trace_chmod_common+0x1d0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d05, 0x1d0c, x86_l_1d0c);
x86_l_1d07:
	/* 0x1d07: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d0a:
	/* 0x1d0a: jmp    1d0e <trace_chmod_common+0x1d0e> */
	X86_SIM_X86_JMP(0x1d0a, 0x1d0e, x86_l_1d0e);
x86_l_1d0c:
	/* 0x1d0c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d0e:
	/* 0x1d0e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d11:
	/* 0x1d11: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d14:
	/* 0x1d14: jns    1d1b <trace_chmod_common+0x1d1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d14, 0x1d1b, x86_l_1d1b);
x86_l_1d16:
	/* 0x1d16: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d19:
	/* 0x1d19: jmp    1d1d <trace_chmod_common+0x1d1d> */
	X86_SIM_X86_JMP(0x1d19, 0x1d1d, x86_l_1d1d);
x86_l_1d1b:
	/* 0x1d1b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d1d:
	/* 0x1d1d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d21:
	/* 0x1d21: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d24:
	/* 0x1d24: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d27:
	/* 0x1d27: jns    1d56 <trace_chmod_common+0x1d56> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d27, 0x1d56, x86_l_1d56);
x86_l_1d29:
	/* 0x1d29: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d2c:
	/* 0x1d2c: jmp    1d58 <trace_chmod_common+0x1d58> */
	X86_SIM_X86_JMP(0x1d2c, 0x1d58, x86_l_1d58);
x86_l_1d2e:
	/* 0x1d2e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d33:
	/* 0x1d33: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d37:
	/* 0x1d37: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d37, 0x28ae, x86_l_28ae);
x86_l_1d3d:
	/* 0x1d3d: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d40:
	/* 0x1d40: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d46:
	/* 0x1d46: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1d4b:
	/* 0x1d4b: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d4e:
	/* 0x1d4e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d51:
	/* 0x1d51: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d54:
	/* 0x1d54: js     1d29 <trace_chmod_common+0x1d29> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d54, 0x1d29, x86_l_1d29);
x86_l_1d56:
	/* 0x1d56: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d58:
	/* 0x1d58: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d5c:
	/* 0x1d5c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d5f:
	/* 0x1d5f: jns    1d66 <trace_chmod_common+0x1d66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d5f, 0x1d66, x86_l_1d66);
x86_l_1d61:
	/* 0x1d61: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d64:
	/* 0x1d64: jmp    1d68 <trace_chmod_common+0x1d68> */
	X86_SIM_X86_JMP(0x1d64, 0x1d68, x86_l_1d68);
x86_l_1d66:
	/* 0x1d66: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d68:
	/* 0x1d68: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d6b:
	/* 0x1d6b: je     1de5 <trace_chmod_common+0x1de5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d6b, 0x1de5, x86_l_1de5);
x86_l_1d6d:
	/* 0x1d6d: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d70:
	/* 0x1d70: je     1de5 <trace_chmod_common+0x1de5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d70, 0x1de5, x86_l_1de5);
x86_l_1d72:
	/* 0x1d72: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d76:
	/* 0x1d76: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d79:
	/* 0x1d79: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d7f:
	/* 0x1d7f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d82:
	/* 0x1d82: jns    1d8b <trace_chmod_common+0x1d8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d82, 0x1d8b, x86_l_1d8b);
x86_l_1d84:
	/* 0x1d84: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d87:
	/* 0x1d87: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d8b:
	/* 0x1d8b: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1d8f:
	/* 0x1d8f: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d92:
	/* 0x1d92: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d99:
	/* 0x1d99: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1d9b:
	/* 0x1d9b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d9e:
	/* 0x1d9e: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d9e, 0x28fc, x86_l_28fc);
x86_l_1da4:
	/* 0x1da4: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1da7:
	/* 0x1da7: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da7, 0x28ab, x86_l_28ab);
x86_l_1dad:
	/* 0x1dad: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1db3:
	/* 0x1db3: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1db6:
	/* 0x1db6: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1db9:
	/* 0x1db9: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1db9, 0x282d, x86_l_282d);
x86_l_1dbf:
	/* 0x1dbf: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1dc3:
	/* 0x1dc3: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dc6:
	/* 0x1dc6: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1dc9:
	/* 0x1dc9: je     1e33 <trace_chmod_common+0x1e33> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dc9, 0x1e33, x86_l_1e33);
x86_l_1dcb:
	/* 0x1dcb: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1dcf:
	/* 0x1dcf: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1dd4:
	/* 0x1dd4: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1dd8:
	/* 0x1dd8: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ddb:
	/* 0x1ddb: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1dde:
	/* 0x1dde: jne    1dc6 <trace_chmod_common+0x1dc6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dde, 0x1dc6, x86_l_1dc6);
x86_l_1de0:
	/* 0x1de0: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1de3:
	/* 0x1de3: jmp    1e38 <trace_chmod_common+0x1e38> */
	X86_SIM_X86_JMP(0x1de3, 0x1e38, x86_l_1e38);
x86_l_1de5:
	/* 0x1de5: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1de8:
	/* 0x1de8: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1de8, 0x28ab, x86_l_28ab);
x86_l_1dee:
	/* 0x1dee: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1df1:
	/* 0x1df1: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1df1, 0x28ab, x86_l_28ab);
x86_l_1df7:
	/* 0x1df7: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dfb:
	/* 0x1dfb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dfe:
	/* 0x1dfe: jns    1e05 <trace_chmod_common+0x1e05> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dfe, 0x1e05, x86_l_1e05);
x86_l_1e00:
	/* 0x1e00: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e03:
	/* 0x1e03: jmp    1e07 <trace_chmod_common+0x1e07> */
	X86_SIM_X86_JMP(0x1e03, 0x1e07, x86_l_1e07);
x86_l_1e05:
	/* 0x1e05: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e07:
	/* 0x1e07: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e0a:
	/* 0x1e0a: jns    1e11 <trace_chmod_common+0x1e11> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e0a, 0x1e11, x86_l_1e11);
x86_l_1e0c:
	/* 0x1e0c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e0f:
	/* 0x1e0f: jmp    1e13 <trace_chmod_common+0x1e13> */
	X86_SIM_X86_JMP(0x1e0f, 0x1e13, x86_l_1e13);
x86_l_1e11:
	/* 0x1e11: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e13:
	/* 0x1e13: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e16:
	/* 0x1e16: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e19:
	/* 0x1e19: jns    1e20 <trace_chmod_common+0x1e20> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e19, 0x1e20, x86_l_1e20);
x86_l_1e1b:
	/* 0x1e1b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e1e:
	/* 0x1e1e: jmp    1e22 <trace_chmod_common+0x1e22> */
	X86_SIM_X86_JMP(0x1e1e, 0x1e22, x86_l_1e22);
x86_l_1e20:
	/* 0x1e20: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e22:
	/* 0x1e22: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e26:
	/* 0x1e26: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e29:
	/* 0x1e29: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e2c:
	/* 0x1e2c: jns    1e5b <trace_chmod_common+0x1e5b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e2c, 0x1e5b, x86_l_1e5b);
x86_l_1e2e:
	/* 0x1e2e: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e31:
	/* 0x1e31: jmp    1e5d <trace_chmod_common+0x1e5d> */
	X86_SIM_X86_JMP(0x1e31, 0x1e5d, x86_l_1e5d);
x86_l_1e33:
	/* 0x1e33: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e38:
	/* 0x1e38: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e3c:
	/* 0x1e3c: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e3c, 0x28ab, x86_l_28ab);
x86_l_1e42:
	/* 0x1e42: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e45:
	/* 0x1e45: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1e4b:
	/* 0x1e4b: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1e50:
	/* 0x1e50: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e53:
	/* 0x1e53: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e56:
	/* 0x1e56: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e59:
	/* 0x1e59: js     1e2e <trace_chmod_common+0x1e2e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e59, 0x1e2e, x86_l_1e2e);
x86_l_1e5b:
	/* 0x1e5b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e5d:
	/* 0x1e5d: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e61:
	/* 0x1e61: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e64:
	/* 0x1e64: jns    1e6b <trace_chmod_common+0x1e6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e64, 0x1e6b, x86_l_1e6b);
x86_l_1e66:
	/* 0x1e66: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e69:
	/* 0x1e69: jmp    1e6e <trace_chmod_common+0x1e6e> */
	X86_SIM_X86_JMP(0x1e69, 0x1e6e, x86_l_1e6e);
x86_l_1e6b:
	/* 0x1e6b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e6e:
	/* 0x1e6e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e71:
	/* 0x1e71: je     1eeb <trace_chmod_common+0x1eeb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e71, 0x1eeb, x86_l_1eeb);
x86_l_1e73:
	/* 0x1e73: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1e76:
	/* 0x1e76: je     1eeb <trace_chmod_common+0x1eeb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e76, 0x1eeb, x86_l_1eeb);
x86_l_1e78:
	/* 0x1e78: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e7c:
	/* 0x1e7c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e7f:
	/* 0x1e7f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1e85:
	/* 0x1e85: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e88:
	/* 0x1e88: jns    1e91 <trace_chmod_common+0x1e91> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e88, 0x1e91, x86_l_1e91);
x86_l_1e8a:
	/* 0x1e8a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8d:
	/* 0x1e8d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e91:
	/* 0x1e91: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e95:
	/* 0x1e95: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e98:
	/* 0x1e98: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e9f:
	/* 0x1e9f: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1ea1:
	/* 0x1ea1: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ea4:
	/* 0x1ea4: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ea4, 0x28fc, x86_l_28fc);
x86_l_1eaa:
	/* 0x1eaa: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1ead:
	/* 0x1ead: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ead, 0x28ae, x86_l_28ae);
x86_l_1eb3:
	/* 0x1eb3: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1eb9:
	/* 0x1eb9: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1ebc:
	/* 0x1ebc: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1ebf:
	/* 0x1ebf: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ebf, 0x271b, x86_l_271b);
x86_l_1ec5:
	/* 0x1ec5: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ec9:
	/* 0x1ec9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ecc:
	/* 0x1ecc: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ecf:
	/* 0x1ecf: je     1f3a <trace_chmod_common+0x1f3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ecf, 0x1f3a, x86_l_1f3a);
x86_l_1ed1:
	/* 0x1ed1: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ed5:
	/* 0x1ed5: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1eda:
	/* 0x1eda: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ede:
	/* 0x1ede: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ee1:
	/* 0x1ee1: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1ee4:
	/* 0x1ee4: jne    1ecc <trace_chmod_common+0x1ecc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee4, 0x1ecc, x86_l_1ecc);
x86_l_1ee6:
	/* 0x1ee6: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ee9:
	/* 0x1ee9: jmp    1f3f <trace_chmod_common+0x1f3f> */
	X86_SIM_X86_JMP(0x1ee9, 0x1f3f, x86_l_1f3f);
x86_l_1eeb:
	/* 0x1eeb: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1eee:
	/* 0x1eee: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eee, 0x28ae, x86_l_28ae);
x86_l_1ef4:
	/* 0x1ef4: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ef7:
	/* 0x1ef7: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef7, 0x28ae, x86_l_28ae);
x86_l_1efd:
	/* 0x1efd: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f01:
	/* 0x1f01: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f04:
	/* 0x1f04: jns    1f0b <trace_chmod_common+0x1f0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f04, 0x1f0b, x86_l_1f0b);
x86_l_1f06:
	/* 0x1f06: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f09:
	/* 0x1f09: jmp    1f0e <trace_chmod_common+0x1f0e> */
	X86_SIM_X86_JMP(0x1f09, 0x1f0e, x86_l_1f0e);
x86_l_1f0b:
	/* 0x1f0b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f0e:
	/* 0x1f0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f11:
	/* 0x1f11: jns    1f18 <trace_chmod_common+0x1f18> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f11, 0x1f18, x86_l_1f18);
x86_l_1f13:
	/* 0x1f13: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f16:
	/* 0x1f16: jmp    1f1a <trace_chmod_common+0x1f1a> */
	X86_SIM_X86_JMP(0x1f16, 0x1f1a, x86_l_1f1a);
x86_l_1f18:
	/* 0x1f18: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f1a:
	/* 0x1f1a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f1d:
	/* 0x1f1d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f20:
	/* 0x1f20: jns    1f27 <trace_chmod_common+0x1f27> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f20, 0x1f27, x86_l_1f27);
x86_l_1f22:
	/* 0x1f22: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f25:
	/* 0x1f25: jmp    1f29 <trace_chmod_common+0x1f29> */
	X86_SIM_X86_JMP(0x1f25, 0x1f29, x86_l_1f29);
x86_l_1f27:
	/* 0x1f27: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f29:
	/* 0x1f29: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f2d:
	/* 0x1f2d: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f30:
	/* 0x1f30: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f33:
	/* 0x1f33: jns    1f62 <trace_chmod_common+0x1f62> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f33, 0x1f62, x86_l_1f62);
x86_l_1f35:
	/* 0x1f35: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f38:
	/* 0x1f38: jmp    1f64 <trace_chmod_common+0x1f64> */
	X86_SIM_X86_JMP(0x1f38, 0x1f64, x86_l_1f64);
x86_l_1f3a:
	/* 0x1f3a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1f3f:
	/* 0x1f3f: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f43:
	/* 0x1f43: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f43, 0x28ae, x86_l_28ae);
x86_l_1f49:
	/* 0x1f49: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f4c:
	/* 0x1f4c: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f52:
	/* 0x1f52: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1f57:
	/* 0x1f57: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f5a:
	/* 0x1f5a: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f5d:
	/* 0x1f5d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f60:
	/* 0x1f60: js     1f35 <trace_chmod_common+0x1f35> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f60, 0x1f35, x86_l_1f35);
x86_l_1f62:
	/* 0x1f62: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f64:
	/* 0x1f64: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f68:
	/* 0x1f68: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f6b:
	/* 0x1f6b: jns    1f72 <trace_chmod_common+0x1f72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6b, 0x1f72, x86_l_1f72);
x86_l_1f6d:
	/* 0x1f6d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f70:
	/* 0x1f70: jmp    1f74 <trace_chmod_common+0x1f74> */
	X86_SIM_X86_JMP(0x1f70, 0x1f74, x86_l_1f74);
x86_l_1f72:
	/* 0x1f72: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f74:
	/* 0x1f74: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f77:
	/* 0x1f77: je     1ff1 <trace_chmod_common+0x1ff1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f77, 0x1ff1, x86_l_1ff1);
x86_l_1f79:
	/* 0x1f79: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f7c:
	/* 0x1f7c: je     1ff1 <trace_chmod_common+0x1ff1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7c, 0x1ff1, x86_l_1ff1);
x86_l_1f7e:
	/* 0x1f7e: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f82:
	/* 0x1f82: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f85:
	/* 0x1f85: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f8b:
	/* 0x1f8b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f8e:
	/* 0x1f8e: jns    1f97 <trace_chmod_common+0x1f97> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f8e, 0x1f97, x86_l_1f97);
x86_l_1f90:
	/* 0x1f90: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f93:
	/* 0x1f93: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f97:
	/* 0x1f97: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1f9b:
	/* 0x1f9b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f9e:
	/* 0x1f9e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1fa5:
	/* 0x1fa5: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1fa7:
	/* 0x1fa7: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1faa:
	/* 0x1faa: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1faa, 0x28fc, x86_l_28fc);
x86_l_1fb0:
	/* 0x1fb0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1fb3:
	/* 0x1fb3: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb3, 0x28ab, x86_l_28ab);
x86_l_1fb9:
	/* 0x1fb9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1fbf:
	/* 0x1fbf: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fc2:
	/* 0x1fc2: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1fc5:
	/* 0x1fc5: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc5, 0x282d, x86_l_282d);
x86_l_1fcb:
	/* 0x1fcb: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fcf:
	/* 0x1fcf: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fd2:
	/* 0x1fd2: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1fd5:
	/* 0x1fd5: je     203f <trace_chmod_common+0x203f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fd5, 0x203f, x86_l_203f);
x86_l_1fd7:
	/* 0x1fd7: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1fdb:
	/* 0x1fdb: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1fe0:
	/* 0x1fe0: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1fe4:
	/* 0x1fe4: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1fe7:
	/* 0x1fe7: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1fea:
	/* 0x1fea: jne    1fd2 <trace_chmod_common+0x1fd2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fea, 0x1fd2, x86_l_1fd2);
x86_l_1fec:
	/* 0x1fec: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1fef:
	/* 0x1fef: jmp    2044 <trace_chmod_common+0x2044> */
	X86_SIM_X86_JMP(0x1fef, 0x2044, x86_l_2044);
x86_l_1ff1:
	/* 0x1ff1: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ff4:
	/* 0x1ff4: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ff4, 0x28ab, x86_l_28ab);
x86_l_1ffa:
	/* 0x1ffa: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ffd:
	/* 0x1ffd: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ffd, 0x28ab, x86_l_28ab);
x86_l_2003:
	/* 0x2003: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2007:
	/* 0x2007: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_200a:
	/* 0x200a: jns    2011 <trace_chmod_common+0x2011> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x200a, 0x2011, x86_l_2011);
x86_l_200c:
	/* 0x200c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_200f:
	/* 0x200f: jmp    2013 <trace_chmod_common+0x2013> */
	X86_SIM_X86_JMP(0x200f, 0x2013, x86_l_2013);
x86_l_2011:
	/* 0x2011: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2013:
	/* 0x2013: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2016:
	/* 0x2016: jns    201d <trace_chmod_common+0x201d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2016, 0x201d, x86_l_201d);
x86_l_2018:
	/* 0x2018: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_201b:
	/* 0x201b: jmp    201f <trace_chmod_common+0x201f> */
	X86_SIM_X86_JMP(0x201b, 0x201f, x86_l_201f);
x86_l_201d:
	/* 0x201d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_201f:
	/* 0x201f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2022:
	/* 0x2022: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2025:
	/* 0x2025: jns    202c <trace_chmod_common+0x202c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2025, 0x202c, x86_l_202c);
x86_l_2027:
	/* 0x2027: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_202a:
	/* 0x202a: jmp    202e <trace_chmod_common+0x202e> */
	X86_SIM_X86_JMP(0x202a, 0x202e, x86_l_202e);
x86_l_202c:
	/* 0x202c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_202e:
	/* 0x202e: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2032:
	/* 0x2032: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2035:
	/* 0x2035: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2038:
	/* 0x2038: jns    2067 <trace_chmod_common+0x2067> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2038, 0x2067, x86_l_2067);
x86_l_203a:
	/* 0x203a: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203d:
	/* 0x203d: jmp    2069 <trace_chmod_common+0x2069> */
	X86_SIM_X86_JMP(0x203d, 0x2069, x86_l_2069);
x86_l_203f:
	/* 0x203f: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2044:
	/* 0x2044: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2048:
	/* 0x2048: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2048, 0x28ab, x86_l_28ab);
x86_l_204e:
	/* 0x204e: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2051:
	/* 0x2051: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2057:
	/* 0x2057: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_205c:
	/* 0x205c: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_205f:
	/* 0x205f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2062:
	/* 0x2062: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2065:
	/* 0x2065: js     203a <trace_chmod_common+0x203a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2065, 0x203a, x86_l_203a);
x86_l_2067:
	/* 0x2067: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2069:
	/* 0x2069: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_206d:
	/* 0x206d: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2070:
	/* 0x2070: jns    2077 <trace_chmod_common+0x2077> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2070, 0x2077, x86_l_2077);
x86_l_2072:
	/* 0x2072: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2075:
	/* 0x2075: jmp    207a <trace_chmod_common+0x207a> */
	X86_SIM_X86_JMP(0x2075, 0x207a, x86_l_207a);
x86_l_2077:
	/* 0x2077: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_207a:
	/* 0x207a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_207d:
	/* 0x207d: je     20f7 <trace_chmod_common+0x20f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207d, 0x20f7, x86_l_20f7);
x86_l_207f:
	/* 0x207f: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2082:
	/* 0x2082: je     20f7 <trace_chmod_common+0x20f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2082, 0x20f7, x86_l_20f7);
x86_l_2084:
	/* 0x2084: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2088:
	/* 0x2088: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208b:
	/* 0x208b: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2091:
	/* 0x2091: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2094:
	/* 0x2094: jns    209d <trace_chmod_common+0x209d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2094, 0x209d, x86_l_209d);
x86_l_2096:
	/* 0x2096: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2099:
	/* 0x2099: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_209d:
	/* 0x209d: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_20a1:
	/* 0x20a1: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20a4:
	/* 0x20a4: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20ab:
	/* 0x20ab: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20ad:
	/* 0x20ad: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20b0:
	/* 0x20b0: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20b0, 0x28fc, x86_l_28fc);
x86_l_20b6:
	/* 0x20b6: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_20b9:
	/* 0x20b9: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b9, 0x28ae, x86_l_28ae);
x86_l_20bf:
	/* 0x20bf: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20c5:
	/* 0x20c5: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20c8:
	/* 0x20c8: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_20cb:
	/* 0x20cb: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20cb, 0x271b, x86_l_271b);
x86_l_20d1:
	/* 0x20d1: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_20d5:
	/* 0x20d5: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20d8:
	/* 0x20d8: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_20db:
	/* 0x20db: je     2146 <trace_chmod_common+0x2146> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20db, 0x2146, x86_l_2146);
x86_l_20dd:
	/* 0x20dd: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_20e1:
	/* 0x20e1: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_20e6:
	/* 0x20e6: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_20ea:
	/* 0x20ea: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_20ed:
	/* 0x20ed: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_20f0:
	/* 0x20f0: jne    20d8 <trace_chmod_common+0x20d8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20f0, 0x20d8, x86_l_20d8);
x86_l_20f2:
	/* 0x20f2: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_20f5:
	/* 0x20f5: jmp    214b <trace_chmod_common+0x214b> */
	X86_SIM_X86_JMP(0x20f5, 0x214b, x86_l_214b);
x86_l_20f7:
	/* 0x20f7: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20fa:
	/* 0x20fa: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20fa, 0x28ae, x86_l_28ae);
x86_l_2100:
	/* 0x2100: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2103:
	/* 0x2103: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2103, 0x28ae, x86_l_28ae);
x86_l_2109:
	/* 0x2109: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_210d:
	/* 0x210d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2110:
	/* 0x2110: jns    2117 <trace_chmod_common+0x2117> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2110, 0x2117, x86_l_2117);
x86_l_2112:
	/* 0x2112: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2115:
	/* 0x2115: jmp    211a <trace_chmod_common+0x211a> */
	X86_SIM_X86_JMP(0x2115, 0x211a, x86_l_211a);
x86_l_2117:
	/* 0x2117: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_211a:
	/* 0x211a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_211d:
	/* 0x211d: jns    2124 <trace_chmod_common+0x2124> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x211d, 0x2124, x86_l_2124);
x86_l_211f:
	/* 0x211f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2122:
	/* 0x2122: jmp    2126 <trace_chmod_common+0x2126> */
	X86_SIM_X86_JMP(0x2122, 0x2126, x86_l_2126);
x86_l_2124:
	/* 0x2124: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2126:
	/* 0x2126: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2129:
	/* 0x2129: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_212c:
	/* 0x212c: jns    2133 <trace_chmod_common+0x2133> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x212c, 0x2133, x86_l_2133);
x86_l_212e:
	/* 0x212e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2131:
	/* 0x2131: jmp    2135 <trace_chmod_common+0x2135> */
	X86_SIM_X86_JMP(0x2131, 0x2135, x86_l_2135);
x86_l_2133:
	/* 0x2133: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2135:
	/* 0x2135: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2139:
	/* 0x2139: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_213c:
	/* 0x213c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_213f:
	/* 0x213f: jns    216e <trace_chmod_common+0x216e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x213f, 0x216e, x86_l_216e);
x86_l_2141:
	/* 0x2141: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2144:
	/* 0x2144: jmp    2170 <trace_chmod_common+0x2170> */
	X86_SIM_X86_JMP(0x2144, 0x2170, x86_l_2170);
x86_l_2146:
	/* 0x2146: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_214b:
	/* 0x214b: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_214f:
	/* 0x214f: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x214f, 0x28ae, x86_l_28ae);
x86_l_2155:
	/* 0x2155: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2158:
	/* 0x2158: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_215e:
	/* 0x215e: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2163:
	/* 0x2163: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2166:
	/* 0x2166: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2169:
	/* 0x2169: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_216c:
	/* 0x216c: js     2141 <trace_chmod_common+0x2141> */
	X86_SIM_X86_JCC(X86_CC_S, 0x216c, 0x2141, x86_l_2141);
x86_l_216e:
	/* 0x216e: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2170:
	/* 0x2170: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2174:
	/* 0x2174: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2177:
	/* 0x2177: jns    217e <trace_chmod_common+0x217e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2177, 0x217e, x86_l_217e);
x86_l_2179:
	/* 0x2179: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217c:
	/* 0x217c: jmp    2180 <trace_chmod_common+0x2180> */
	X86_SIM_X86_JMP(0x217c, 0x2180, x86_l_2180);
x86_l_217e:
	/* 0x217e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2180:
	/* 0x2180: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2183:
	/* 0x2183: je     21fd <trace_chmod_common+0x21fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2183, 0x21fd, x86_l_21fd);
x86_l_2185:
	/* 0x2185: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2188:
	/* 0x2188: je     21fd <trace_chmod_common+0x21fd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2188, 0x21fd, x86_l_21fd);
x86_l_218a:
	/* 0x218a: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_218e:
	/* 0x218e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2191:
	/* 0x2191: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2197:
	/* 0x2197: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_219a:
	/* 0x219a: jns    21a3 <trace_chmod_common+0x21a3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x219a, 0x21a3, x86_l_21a3);
x86_l_219c:
	/* 0x219c: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_219f:
	/* 0x219f: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21a3:
	/* 0x21a3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_21a7:
	/* 0x21a7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21aa:
	/* 0x21aa: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_21b1:
	/* 0x21b1: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21b3:
	/* 0x21b3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21b6:
	/* 0x21b6: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21b6, 0x28fc, x86_l_28fc);
x86_l_21bc:
	/* 0x21bc: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_21bf:
	/* 0x21bf: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21bf, 0x28ab, x86_l_28ab);
x86_l_21c5:
	/* 0x21c5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_21cb:
	/* 0x21cb: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_21ce:
	/* 0x21ce: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_21d1:
	/* 0x21d1: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21d1, 0x282d, x86_l_282d);
x86_l_21d7:
	/* 0x21d7: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_21db:
	/* 0x21db: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21de:
	/* 0x21de: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_21e1:
	/* 0x21e1: je     224b <trace_chmod_common+0x224b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e1, 0x224b, x86_l_224b);
x86_l_21e3:
	/* 0x21e3: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_21e7:
	/* 0x21e7: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_21ec:
	/* 0x21ec: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_21f0:
	/* 0x21f0: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_21f3:
	/* 0x21f3: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_21f6:
	/* 0x21f6: jne    21de <trace_chmod_common+0x21de> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21f6, 0x21de, x86_l_21de);
x86_l_21f8:
	/* 0x21f8: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_21fb:
	/* 0x21fb: jmp    2250 <trace_chmod_common+0x2250> */
	X86_SIM_X86_JMP(0x21fb, 0x2250, x86_l_2250);
x86_l_21fd:
	/* 0x21fd: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2200:
	/* 0x2200: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2200, 0x28ab, x86_l_28ab);
x86_l_2206:
	/* 0x2206: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2209:
	/* 0x2209: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2209, 0x28ab, x86_l_28ab);
x86_l_220f:
	/* 0x220f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2213:
	/* 0x2213: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2216:
	/* 0x2216: jns    221d <trace_chmod_common+0x221d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2216, 0x221d, x86_l_221d);
x86_l_2218:
	/* 0x2218: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_221b:
	/* 0x221b: jmp    221f <trace_chmod_common+0x221f> */
	X86_SIM_X86_JMP(0x221b, 0x221f, x86_l_221f);
x86_l_221d:
	/* 0x221d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_221f:
	/* 0x221f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2222:
	/* 0x2222: jns    2229 <trace_chmod_common+0x2229> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2222, 0x2229, x86_l_2229);
x86_l_2224:
	/* 0x2224: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2227:
	/* 0x2227: jmp    222b <trace_chmod_common+0x222b> */
	X86_SIM_X86_JMP(0x2227, 0x222b, x86_l_222b);
x86_l_2229:
	/* 0x2229: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_222b:
	/* 0x222b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_222e:
	/* 0x222e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2231:
	/* 0x2231: jns    2238 <trace_chmod_common+0x2238> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2231, 0x2238, x86_l_2238);
x86_l_2233:
	/* 0x2233: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2236:
	/* 0x2236: jmp    223a <trace_chmod_common+0x223a> */
	X86_SIM_X86_JMP(0x2236, 0x223a, x86_l_223a);
x86_l_2238:
	/* 0x2238: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_223a:
	/* 0x223a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_223e:
	/* 0x223e: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2241:
	/* 0x2241: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2244:
	/* 0x2244: jns    2273 <trace_chmod_common+0x2273> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2244, 0x2273, x86_l_2273);
x86_l_2246:
	/* 0x2246: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2249:
	/* 0x2249: jmp    2275 <trace_chmod_common+0x2275> */
	X86_SIM_X86_JMP(0x2249, 0x2275, x86_l_2275);
x86_l_224b:
	/* 0x224b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2250:
	/* 0x2250: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2254:
	/* 0x2254: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2254, 0x28ab, x86_l_28ab);
x86_l_225a:
	/* 0x225a: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_225d:
	/* 0x225d: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2263:
	/* 0x2263: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2268:
	/* 0x2268: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_226b:
	/* 0x226b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_226e:
	/* 0x226e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2271:
	/* 0x2271: js     2246 <trace_chmod_common+0x2246> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2271, 0x2246, x86_l_2246);
x86_l_2273:
	/* 0x2273: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2275:
	/* 0x2275: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2279:
	/* 0x2279: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_227c:
	/* 0x227c: jns    2283 <trace_chmod_common+0x2283> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x227c, 0x2283, x86_l_2283);
x86_l_227e:
	/* 0x227e: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2281:
	/* 0x2281: jmp    2286 <trace_chmod_common+0x2286> */
	X86_SIM_X86_JMP(0x2281, 0x2286, x86_l_2286);
x86_l_2283:
	/* 0x2283: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2286:
	/* 0x2286: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2289:
	/* 0x2289: je     2303 <trace_chmod_common+0x2303> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2289, 0x2303, x86_l_2303);
x86_l_228b:
	/* 0x228b: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_228e:
	/* 0x228e: je     2303 <trace_chmod_common+0x2303> */
	X86_SIM_X86_JCC(X86_CC_E, 0x228e, 0x2303, x86_l_2303);
x86_l_2290:
	/* 0x2290: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2294:
	/* 0x2294: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2297:
	/* 0x2297: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_229d:
	/* 0x229d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22a0:
	/* 0x22a0: jns    22a9 <trace_chmod_common+0x22a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a0, 0x22a9, x86_l_22a9);
x86_l_22a2:
	/* 0x22a2: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22a5:
	/* 0x22a5: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22a9:
	/* 0x22a9: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22ad:
	/* 0x22ad: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22b0:
	/* 0x22b0: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22b7:
	/* 0x22b7: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_22b9:
	/* 0x22b9: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22bc:
	/* 0x22bc: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22bc, 0x28fc, x86_l_28fc);
x86_l_22c2:
	/* 0x22c2: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_22c5:
	/* 0x22c5: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c5, 0x28ae, x86_l_28ae);
x86_l_22cb:
	/* 0x22cb: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_22d1:
	/* 0x22d1: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_22d4:
	/* 0x22d4: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_22d7:
	/* 0x22d7: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22d7, 0x271b, x86_l_271b);
x86_l_22dd:
	/* 0x22dd: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_22e1:
	/* 0x22e1: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22e4:
	/* 0x22e4: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_22e7:
	/* 0x22e7: je     2352 <trace_chmod_common+0x2352> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22e7, 0x2352, x86_l_2352);
x86_l_22e9:
	/* 0x22e9: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_22ed:
	/* 0x22ed: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_22f2:
	/* 0x22f2: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_22f6:
	/* 0x22f6: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_22f9:
	/* 0x22f9: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_22fc:
	/* 0x22fc: jne    22e4 <trace_chmod_common+0x22e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22fc, 0x22e4, x86_l_22e4);
x86_l_22fe:
	/* 0x22fe: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2301:
	/* 0x2301: jmp    2357 <trace_chmod_common+0x2357> */
	X86_SIM_X86_JMP(0x2301, 0x2357, x86_l_2357);
x86_l_2303:
	/* 0x2303: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2306:
	/* 0x2306: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2306, 0x28ae, x86_l_28ae);
x86_l_230c:
	/* 0x230c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_230f:
	/* 0x230f: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x230f, 0x28ae, x86_l_28ae);
x86_l_2315:
	/* 0x2315: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2319:
	/* 0x2319: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_231c:
	/* 0x231c: jns    2323 <trace_chmod_common+0x2323> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x231c, 0x2323, x86_l_2323);
x86_l_231e:
	/* 0x231e: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2321:
	/* 0x2321: jmp    2326 <trace_chmod_common+0x2326> */
	X86_SIM_X86_JMP(0x2321, 0x2326, x86_l_2326);
x86_l_2323:
	/* 0x2323: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2326:
	/* 0x2326: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2329:
	/* 0x2329: jns    2330 <trace_chmod_common+0x2330> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2329, 0x2330, x86_l_2330);
x86_l_232b:
	/* 0x232b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_232e:
	/* 0x232e: jmp    2332 <trace_chmod_common+0x2332> */
	X86_SIM_X86_JMP(0x232e, 0x2332, x86_l_2332);
x86_l_2330:
	/* 0x2330: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2332:
	/* 0x2332: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2335:
	/* 0x2335: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2338:
	/* 0x2338: jns    233f <trace_chmod_common+0x233f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2338, 0x233f, x86_l_233f);
x86_l_233a:
	/* 0x233a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_233d:
	/* 0x233d: jmp    2341 <trace_chmod_common+0x2341> */
	X86_SIM_X86_JMP(0x233d, 0x2341, x86_l_2341);
x86_l_233f:
	/* 0x233f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2341:
	/* 0x2341: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2345:
	/* 0x2345: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2348:
	/* 0x2348: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_234b:
	/* 0x234b: jns    237a <trace_chmod_common+0x237a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x234b, 0x237a, x86_l_237a);
x86_l_234d:
	/* 0x234d: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2350:
	/* 0x2350: jmp    237c <trace_chmod_common+0x237c> */
	X86_SIM_X86_JMP(0x2350, 0x237c, x86_l_237c);
x86_l_2352:
	/* 0x2352: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2357:
	/* 0x2357: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_235b:
	/* 0x235b: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x235b, 0x28ae, x86_l_28ae);
x86_l_2361:
	/* 0x2361: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2364:
	/* 0x2364: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_236a:
	/* 0x236a: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_236f:
	/* 0x236f: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2372:
	/* 0x2372: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2375:
	/* 0x2375: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2378:
	/* 0x2378: js     234d <trace_chmod_common+0x234d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2378, 0x234d, x86_l_234d);
x86_l_237a:
	/* 0x237a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_237c:
	/* 0x237c: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2380:
	/* 0x2380: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2383:
	/* 0x2383: jns    238a <trace_chmod_common+0x238a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2383, 0x238a, x86_l_238a);
x86_l_2385:
	/* 0x2385: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2388:
	/* 0x2388: jmp    238c <trace_chmod_common+0x238c> */
	X86_SIM_X86_JMP(0x2388, 0x238c, x86_l_238c);
x86_l_238a:
	/* 0x238a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_238c:
	/* 0x238c: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_238f:
	/* 0x238f: je     2409 <trace_chmod_common+0x2409> */
	X86_SIM_X86_JCC(X86_CC_E, 0x238f, 0x2409, x86_l_2409);
x86_l_2391:
	/* 0x2391: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2394:
	/* 0x2394: je     2409 <trace_chmod_common+0x2409> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2394, 0x2409, x86_l_2409);
x86_l_2396:
	/* 0x2396: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_239a:
	/* 0x239a: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_239d:
	/* 0x239d: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_23a3:
	/* 0x23a3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23a6:
	/* 0x23a6: jns    23af <trace_chmod_common+0x23af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23a6, 0x23af, x86_l_23af);
x86_l_23a8:
	/* 0x23a8: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ab:
	/* 0x23ab: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23af:
	/* 0x23af: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_23b3:
	/* 0x23b3: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23b6:
	/* 0x23b6: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_23bd:
	/* 0x23bd: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_23bf:
	/* 0x23bf: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23c2:
	/* 0x23c2: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x23c2, 0x28fc, x86_l_28fc);
x86_l_23c8:
	/* 0x23c8: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_23cb:
	/* 0x23cb: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23cb, 0x28ab, x86_l_28ab);
x86_l_23d1:
	/* 0x23d1: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_23d7:
	/* 0x23d7: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_23da:
	/* 0x23da: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_23dd:
	/* 0x23dd: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23dd, 0x282d, x86_l_282d);
x86_l_23e3:
	/* 0x23e3: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23e7:
	/* 0x23e7: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23ea:
	/* 0x23ea: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_23ed:
	/* 0x23ed: je     2457 <trace_chmod_common+0x2457> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ed, 0x2457, x86_l_2457);
x86_l_23ef:
	/* 0x23ef: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_23f3:
	/* 0x23f3: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_23f8:
	/* 0x23f8: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_23fc:
	/* 0x23fc: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_23ff:
	/* 0x23ff: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2402:
	/* 0x2402: jne    23ea <trace_chmod_common+0x23ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2402, 0x23ea, x86_l_23ea);
x86_l_2404:
	/* 0x2404: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2407:
	/* 0x2407: jmp    245c <trace_chmod_common+0x245c> */
	X86_SIM_X86_JMP(0x2407, 0x245c, x86_l_245c);
x86_l_2409:
	/* 0x2409: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_240c:
	/* 0x240c: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x240c, 0x28ab, x86_l_28ab);
x86_l_2412:
	/* 0x2412: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2415:
	/* 0x2415: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2415, 0x28ab, x86_l_28ab);
x86_l_241b:
	/* 0x241b: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_241f:
	/* 0x241f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2422:
	/* 0x2422: jns    2429 <trace_chmod_common+0x2429> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2422, 0x2429, x86_l_2429);
x86_l_2424:
	/* 0x2424: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2427:
	/* 0x2427: jmp    242b <trace_chmod_common+0x242b> */
	X86_SIM_X86_JMP(0x2427, 0x242b, x86_l_242b);
x86_l_2429:
	/* 0x2429: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_242b:
	/* 0x242b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_242e:
	/* 0x242e: jns    2435 <trace_chmod_common+0x2435> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x242e, 0x2435, x86_l_2435);
x86_l_2430:
	/* 0x2430: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2433:
	/* 0x2433: jmp    2437 <trace_chmod_common+0x2437> */
	X86_SIM_X86_JMP(0x2433, 0x2437, x86_l_2437);
x86_l_2435:
	/* 0x2435: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2437:
	/* 0x2437: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_243a:
	/* 0x243a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_243d:
	/* 0x243d: jns    2444 <trace_chmod_common+0x2444> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x243d, 0x2444, x86_l_2444);
x86_l_243f:
	/* 0x243f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2442:
	/* 0x2442: jmp    2446 <trace_chmod_common+0x2446> */
	X86_SIM_X86_JMP(0x2442, 0x2446, x86_l_2446);
x86_l_2444:
	/* 0x2444: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2446:
	/* 0x2446: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_244a:
	/* 0x244a: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_244d:
	/* 0x244d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2450:
	/* 0x2450: jns    247f <trace_chmod_common+0x247f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2450, 0x247f, x86_l_247f);
x86_l_2452:
	/* 0x2452: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2455:
	/* 0x2455: jmp    2481 <trace_chmod_common+0x2481> */
	X86_SIM_X86_JMP(0x2455, 0x2481, x86_l_2481);
x86_l_2457:
	/* 0x2457: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_245c:
	/* 0x245c: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2460:
	/* 0x2460: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2460, 0x28ab, x86_l_28ab);
x86_l_2466:
	/* 0x2466: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2469:
	/* 0x2469: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_246f:
	/* 0x246f: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2474:
	/* 0x2474: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2477:
	/* 0x2477: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_247a:
	/* 0x247a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_247d:
	/* 0x247d: js     2452 <trace_chmod_common+0x2452> */
	X86_SIM_X86_JCC(X86_CC_S, 0x247d, 0x2452, x86_l_2452);
x86_l_247f:
	/* 0x247f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2481:
	/* 0x2481: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2485:
	/* 0x2485: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2488:
	/* 0x2488: jns    248f <trace_chmod_common+0x248f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2488, 0x248f, x86_l_248f);
x86_l_248a:
	/* 0x248a: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248d:
	/* 0x248d: jmp    2492 <trace_chmod_common+0x2492> */
	X86_SIM_X86_JMP(0x248d, 0x2492, x86_l_2492);
x86_l_248f:
	/* 0x248f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2492:
	/* 0x2492: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2495:
	/* 0x2495: je     250f <trace_chmod_common+0x250f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2495, 0x250f, x86_l_250f);
x86_l_2497:
	/* 0x2497: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_249a:
	/* 0x249a: je     250f <trace_chmod_common+0x250f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x249a, 0x250f, x86_l_250f);
x86_l_249c:
	/* 0x249c: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a0:
	/* 0x24a0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24a3:
	/* 0x24a3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_24a9:
	/* 0x24a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24ac:
	/* 0x24ac: jns    24b5 <trace_chmod_common+0x24b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ac, 0x24b5, x86_l_24b5);
x86_l_24ae:
	/* 0x24ae: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24b1:
	/* 0x24b1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b5:
	/* 0x24b5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_24b9:
	/* 0x24b9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_24bc:
	/* 0x24bc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_24c3:
	/* 0x24c3: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_24c5:
	/* 0x24c5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24c8:
	/* 0x24c8: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x24c8, 0x28fc, x86_l_28fc);
x86_l_24ce:
	/* 0x24ce: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_24d1:
	/* 0x24d1: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24d1, 0x28ae, x86_l_28ae);
x86_l_24d7:
	/* 0x24d7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_24dd:
	/* 0x24dd: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_24e0:
	/* 0x24e0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_24e3:
	/* 0x24e3: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24e3, 0x271b, x86_l_271b);
x86_l_24e9:
	/* 0x24e9: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24ed:
	/* 0x24ed: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f0:
	/* 0x24f0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_24f3:
	/* 0x24f3: je     255e <trace_chmod_common+0x255e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24f3, 0x255e, x86_l_255e);
x86_l_24f5:
	/* 0x24f5: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_24f9:
	/* 0x24f9: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_24fe:
	/* 0x24fe: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2502:
	/* 0x2502: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2505:
	/* 0x2505: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2508:
	/* 0x2508: jne    24f0 <trace_chmod_common+0x24f0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2508, 0x24f0, x86_l_24f0);
x86_l_250a:
	/* 0x250a: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_250d:
	/* 0x250d: jmp    2563 <trace_chmod_common+0x2563> */
	X86_SIM_X86_JMP(0x250d, 0x2563, x86_l_2563);
x86_l_250f:
	/* 0x250f: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2512:
	/* 0x2512: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2512, 0x28ae, x86_l_28ae);
x86_l_2518:
	/* 0x2518: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_251b:
	/* 0x251b: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x251b, 0x28ae, x86_l_28ae);
x86_l_2521:
	/* 0x2521: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2525:
	/* 0x2525: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2528:
	/* 0x2528: jns    252f <trace_chmod_common+0x252f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2528, 0x252f, x86_l_252f);
x86_l_252a:
	/* 0x252a: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_252d:
	/* 0x252d: jmp    2532 <trace_chmod_common+0x2532> */
	X86_SIM_X86_JMP(0x252d, 0x2532, x86_l_2532);
x86_l_252f:
	/* 0x252f: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2532:
	/* 0x2532: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2535:
	/* 0x2535: jns    253c <trace_chmod_common+0x253c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2535, 0x253c, x86_l_253c);
x86_l_2537:
	/* 0x2537: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_253a:
	/* 0x253a: jmp    253e <trace_chmod_common+0x253e> */
	X86_SIM_X86_JMP(0x253a, 0x253e, x86_l_253e);
x86_l_253c:
	/* 0x253c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_253e:
	/* 0x253e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2541:
	/* 0x2541: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2544:
	/* 0x2544: jns    254b <trace_chmod_common+0x254b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2544, 0x254b, x86_l_254b);
x86_l_2546:
	/* 0x2546: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2549:
	/* 0x2549: jmp    254d <trace_chmod_common+0x254d> */
	X86_SIM_X86_JMP(0x2549, 0x254d, x86_l_254d);
x86_l_254b:
	/* 0x254b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_254d:
	/* 0x254d: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2551:
	/* 0x2551: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2554:
	/* 0x2554: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2557:
	/* 0x2557: jns    2586 <trace_chmod_common+0x2586> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2557, 0x2586, x86_l_2586);
x86_l_2559:
	/* 0x2559: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_255c:
	/* 0x255c: jmp    2588 <trace_chmod_common+0x2588> */
	X86_SIM_X86_JMP(0x255c, 0x2588, x86_l_2588);
x86_l_255e:
	/* 0x255e: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2563:
	/* 0x2563: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2567:
	/* 0x2567: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2567, 0x28ae, x86_l_28ae);
x86_l_256d:
	/* 0x256d: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2570:
	/* 0x2570: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2576:
	/* 0x2576: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_257b:
	/* 0x257b: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_257e:
	/* 0x257e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2581:
	/* 0x2581: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2584:
	/* 0x2584: js     2559 <trace_chmod_common+0x2559> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2584, 0x2559, x86_l_2559);
x86_l_2586:
	/* 0x2586: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2588:
	/* 0x2588: lea    rdx,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_258c:
	/* 0x258c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_258f:
	/* 0x258f: jns    2596 <trace_chmod_common+0x2596> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x258f, 0x2596, x86_l_2596);
x86_l_2591:
	/* 0x2591: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2594:
	/* 0x2594: jmp    2598 <trace_chmod_common+0x2598> */
	X86_SIM_X86_JMP(0x2594, 0x2598, x86_l_2598);
x86_l_2596:
	/* 0x2596: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2598:
	/* 0x2598: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_259b:
	/* 0x259b: je     2615 <trace_chmod_common+0x2615> */
	X86_SIM_X86_JCC(X86_CC_E, 0x259b, 0x2615, x86_l_2615);
x86_l_259d:
	/* 0x259d: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25a0:
	/* 0x25a0: je     2615 <trace_chmod_common+0x2615> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25a0, 0x2615, x86_l_2615);
x86_l_25a2:
	/* 0x25a2: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a6:
	/* 0x25a6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25a9:
	/* 0x25a9: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_25af:
	/* 0x25af: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25b2:
	/* 0x25b2: jns    25bb <trace_chmod_common+0x25bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25b2, 0x25bb, x86_l_25bb);
x86_l_25b4:
	/* 0x25b4: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25b7:
	/* 0x25b7: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25bb:
	/* 0x25bb: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_25bf:
	/* 0x25bf: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_25c2:
	/* 0x25c2: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_25c9:
	/* 0x25c9: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_25cb:
	/* 0x25cb: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25ce:
	/* 0x25ce: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x25ce, 0x28fc, x86_l_28fc);
x86_l_25d4:
	/* 0x25d4: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_25d7:
	/* 0x25d7: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25d7, 0x28ab, x86_l_28ab);
x86_l_25dd:
	/* 0x25dd: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_25e3:
	/* 0x25e3: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25e6:
	/* 0x25e6: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_25e9:
	/* 0x25e9: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e9, 0x282d, x86_l_282d);
x86_l_25ef:
	/* 0x25ef: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25f3:
	/* 0x25f3: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f6:
	/* 0x25f6: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_25f9:
	/* 0x25f9: je     2663 <trace_chmod_common+0x2663> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f9, 0x2663, x86_l_2663);
x86_l_25fb:
	/* 0x25fb: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25ff:
	/* 0x25ff: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2604:
	/* 0x2604: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2608:
	/* 0x2608: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_260b:
	/* 0x260b: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_260e:
	/* 0x260e: jne    25f6 <trace_chmod_common+0x25f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x260e, 0x25f6, x86_l_25f6);
x86_l_2610:
	/* 0x2610: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2613:
	/* 0x2613: jmp    2668 <trace_chmod_common+0x2668> */
	X86_SIM_X86_JMP(0x2613, 0x2668, x86_l_2668);
x86_l_2615:
	/* 0x2615: cmp    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2618:
	/* 0x2618: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2618, 0x28ab, x86_l_28ab);
x86_l_261e:
	/* 0x261e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2621:
	/* 0x2621: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2621, 0x28ab, x86_l_28ab);
x86_l_2627:
	/* 0x2627: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_262b:
	/* 0x262b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_262e:
	/* 0x262e: jns    2635 <trace_chmod_common+0x2635> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x262e, 0x2635, x86_l_2635);
x86_l_2630:
	/* 0x2630: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2633:
	/* 0x2633: jmp    2637 <trace_chmod_common+0x2637> */
	X86_SIM_X86_JMP(0x2633, 0x2637, x86_l_2637);
x86_l_2635:
	/* 0x2635: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2637:
	/* 0x2637: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263a:
	/* 0x263a: jns    2641 <trace_chmod_common+0x2641> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x263a, 0x2641, x86_l_2641);
x86_l_263c:
	/* 0x263c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_263f:
	/* 0x263f: jmp    2643 <trace_chmod_common+0x2643> */
	X86_SIM_X86_JMP(0x263f, 0x2643, x86_l_2643);
x86_l_2641:
	/* 0x2641: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2643:
	/* 0x2643: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2646:
	/* 0x2646: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2649:
	/* 0x2649: jns    2650 <trace_chmod_common+0x2650> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2649, 0x2650, x86_l_2650);
x86_l_264b:
	/* 0x264b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264e:
	/* 0x264e: jmp    2652 <trace_chmod_common+0x2652> */
	X86_SIM_X86_JMP(0x264e, 0x2652, x86_l_2652);
x86_l_2650:
	/* 0x2650: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2652:
	/* 0x2652: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2656:
	/* 0x2656: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2659:
	/* 0x2659: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_265c:
	/* 0x265c: jns    268b <trace_chmod_common+0x268b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x265c, 0x268b, x86_l_268b);
x86_l_265e:
	/* 0x265e: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2661:
	/* 0x2661: jmp    268d <trace_chmod_common+0x268d> */
	X86_SIM_X86_JMP(0x2661, 0x268d, x86_l_268d);
x86_l_2663:
	/* 0x2663: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2668:
	/* 0x2668: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_266c:
	/* 0x266c: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x266c, 0x28ab, x86_l_28ab);
x86_l_2672:
	/* 0x2672: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2675:
	/* 0x2675: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_267b:
	/* 0x267b: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2680:
	/* 0x2680: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2683:
	/* 0x2683: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2686:
	/* 0x2686: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2689:
	/* 0x2689: js     265e <trace_chmod_common+0x265e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2689, 0x265e, x86_l_265e);
x86_l_268b:
	/* 0x268b: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268d:
	/* 0x268d: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2691:
	/* 0x2691: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2694:
	/* 0x2694: jns    269b <trace_chmod_common+0x269b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2694, 0x269b, x86_l_269b);
x86_l_2696:
	/* 0x2696: mov    r15,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2699:
	/* 0x2699: jmp    269e <trace_chmod_common+0x269e> */
	X86_SIM_X86_JMP(0x2699, 0x269e, x86_l_269e);
x86_l_269b:
	/* 0x269b: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269e:
	/* 0x269e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26a1:
	/* 0x26a1: je     2727 <trace_chmod_common+0x2727> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a1, 0x2727, x86_l_2727);
x86_l_26a7:
	/* 0x26a7: cmp    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_26aa:
	/* 0x26aa: je     2727 <trace_chmod_common+0x2727> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26aa, 0x2727, x86_l_2727);
x86_l_26ac:
	/* 0x26ac: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26b0:
	/* 0x26b0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26b3:
	/* 0x26b3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_26b9:
	/* 0x26b9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26bc:
	/* 0x26bc: jns    26c5 <trace_chmod_common+0x26c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26bc, 0x26c5, x86_l_26c5);
x86_l_26be:
	/* 0x26be: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c1:
	/* 0x26c1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26c5:
	/* 0x26c5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26c9:
	/* 0x26c9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_26cc:
	/* 0x26cc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_26d3:
	/* 0x26d3: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_26d5:
	/* 0x26d5: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26d8:
	/* 0x26d8: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26d8, 0x28fc, x86_l_28fc);
x86_l_26de:
	/* 0x26de: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_26e1:
	/* 0x26e1: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e1, 0x28ae, x86_l_28ae);
x86_l_26e7:
	/* 0x26e7: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_26ed:
	/* 0x26ed: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26f0:
	/* 0x26f0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_26f3:
	/* 0x26f3: jns    271b <trace_chmod_common+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f3, 0x271b, x86_l_271b);
x86_l_26f5:
	/* 0x26f5: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26f9:
	/* 0x26f9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26fc:
	/* 0x26fc: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_26ff:
	/* 0x26ff: je     2776 <trace_chmod_common+0x2776> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26ff, 0x2776, x86_l_2776);
x86_l_2701:
	/* 0x2701: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2705:
	/* 0x2705: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_270a:
	/* 0x270a: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_270e:
	/* 0x270e: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2711:
	/* 0x2711: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2714:
	/* 0x2714: jne    26fc <trace_chmod_common+0x26fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2714, 0x26fc, x86_l_26fc);
x86_l_2716:
	/* 0x2716: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2719:
	/* 0x2719: jmp    277b <trace_chmod_common+0x277b> */
	X86_SIM_X86_JMP(0x2719, 0x277b, x86_l_277b);
x86_l_271b:
	/* 0x271b: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_271e:
	/* 0x271e: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2722:
	/* 0x2722: jmp    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JMP(0x2722, 0x111a, x86_l_111a);
x86_l_2727:
	/* 0x2727: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_272a:
	/* 0x272a: jne    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x272a, 0x28ae, x86_l_28ae);
x86_l_2730:
	/* 0x2730: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2733:
	/* 0x2733: je     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2733, 0x28ae, x86_l_28ae);
x86_l_2739:
	/* 0x2739: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_273d:
	/* 0x273d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2740:
	/* 0x2740: jns    2747 <trace_chmod_common+0x2747> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2740, 0x2747, x86_l_2747);
x86_l_2742:
	/* 0x2742: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2745:
	/* 0x2745: jmp    274a <trace_chmod_common+0x274a> */
	X86_SIM_X86_JMP(0x2745, 0x274a, x86_l_274a);
x86_l_2747:
	/* 0x2747: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_274a:
	/* 0x274a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_274d:
	/* 0x274d: jns    2754 <trace_chmod_common+0x2754> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x274d, 0x2754, x86_l_2754);
x86_l_274f:
	/* 0x274f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2752:
	/* 0x2752: jmp    2756 <trace_chmod_common+0x2756> */
	X86_SIM_X86_JMP(0x2752, 0x2756, x86_l_2756);
x86_l_2754:
	/* 0x2754: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2756:
	/* 0x2756: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2759:
	/* 0x2759: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_275c:
	/* 0x275c: jns    2763 <trace_chmod_common+0x2763> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x275c, 0x2763, x86_l_2763);
x86_l_275e:
	/* 0x275e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2761:
	/* 0x2761: jmp    2765 <trace_chmod_common+0x2765> */
	X86_SIM_X86_JMP(0x2761, 0x2765, x86_l_2765);
x86_l_2763:
	/* 0x2763: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2765:
	/* 0x2765: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2769:
	/* 0x2769: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_276c:
	/* 0x276c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_276f:
	/* 0x276f: jns    279e <trace_chmod_common+0x279e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x276f, 0x279e, x86_l_279e);
x86_l_2771:
	/* 0x2771: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2774:
	/* 0x2774: jmp    27a0 <trace_chmod_common+0x27a0> */
	X86_SIM_X86_JMP(0x2774, 0x27a0, x86_l_27a0);
x86_l_2776:
	/* 0x2776: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_277b:
	/* 0x277b: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_277f:
	/* 0x277f: jl     28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_L, 0x277f, 0x28ae, x86_l_28ae);
x86_l_2785:
	/* 0x2785: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2788:
	/* 0x2788: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_278e:
	/* 0x278e: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2793:
	/* 0x2793: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2796:
	/* 0x2796: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2799:
	/* 0x2799: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_279c:
	/* 0x279c: js     2771 <trace_chmod_common+0x2771> */
	X86_SIM_X86_JCC(X86_CC_S, 0x279c, 0x2771, x86_l_2771);
x86_l_279e:
	/* 0x279e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a0:
	/* 0x27a0: lea    rdi,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27a4:
	/* 0x27a4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27a7:
	/* 0x27a7: jns    27ae <trace_chmod_common+0x27ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27a7, 0x27ae, x86_l_27ae);
x86_l_27a9:
	/* 0x27a9: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27ac:
	/* 0x27ac: jmp    27b1 <trace_chmod_common+0x27b1> */
	X86_SIM_X86_JMP(0x27ac, 0x27b1, x86_l_27b1);
x86_l_27ae:
	/* 0x27ae: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b1:
	/* 0x27b1: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_27b4:
	/* 0x27b4: je     2836 <trace_chmod_common+0x2836> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27b4, 0x2836, x86_l_2836);
x86_l_27ba:
	/* 0x27ba: cmp    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_27bd:
	/* 0x27bd: je     2836 <trace_chmod_common+0x2836> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27bd, 0x2836, x86_l_2836);
x86_l_27bf:
	/* 0x27bf: lea    rdi,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27c3:
	/* 0x27c3: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27c6:
	/* 0x27c6: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_27cb:
	/* 0x27cb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27ce:
	/* 0x27ce: jns    27d7 <trace_chmod_common+0x27d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ce, 0x27d7, x86_l_27d7);
x86_l_27d0:
	/* 0x27d0: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d3:
	/* 0x27d3: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d7:
	/* 0x27d7: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_27db:
	/* 0x27db: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_27de:
	/* 0x27de: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_27e5:
	/* 0x27e5: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_27e7:
	/* 0x27e7: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27ea:
	/* 0x27ea: jb     28fc <trace_chmod_common+0x28fc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27ea, 0x28fc, x86_l_28fc);
x86_l_27f0:
	/* 0x27f0: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_27f3:
	/* 0x27f3: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f3, 0x28ab, x86_l_28ab);
x86_l_27f9:
	/* 0x27f9: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27ff:
	/* 0x27ff: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2802:
	/* 0x2802: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2805:
	/* 0x2805: jns    282d <trace_chmod_common+0x282d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2805, 0x282d, x86_l_282d);
x86_l_2807:
	/* 0x2807: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_280b:
	/* 0x280b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_280e:
	/* 0x280e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2811:
	/* 0x2811: je     287a <trace_chmod_common+0x287a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2811, 0x287a, x86_l_287a);
x86_l_2813:
	/* 0x2813: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2817:
	/* 0x2817: movzx  r12d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_281c:
	/* 0x281c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2820:
	/* 0x2820: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2823:
	/* 0x2823: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2826:
	/* 0x2826: jne    280e <trace_chmod_common+0x280e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2826, 0x280e, x86_l_280e);
x86_l_2828:
	/* 0x2828: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_282b:
	/* 0x282b: jmp    287f <trace_chmod_common+0x287f> */
	X86_SIM_X86_JMP(0x282b, 0x287f, x86_l_287f);
x86_l_282d:
	/* 0x282d: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2831:
	/* 0x2831: jmp    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JMP(0x2831, 0x111a, x86_l_111a);
x86_l_2836:
	/* 0x2836: cmp    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2839:
	/* 0x2839: jne    28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2839, 0x28ab, x86_l_28ab);
x86_l_283b:
	/* 0x283b: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_283e:
	/* 0x283e: je     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x283e, 0x28ab, x86_l_28ab);
x86_l_2840:
	/* 0x2840: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2844:
	/* 0x2844: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2847:
	/* 0x2847: jns    284e <trace_chmod_common+0x284e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2847, 0x284e, x86_l_284e);
x86_l_2849:
	/* 0x2849: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284c:
	/* 0x284c: jmp    2851 <trace_chmod_common+0x2851> */
	X86_SIM_X86_JMP(0x284c, 0x2851, x86_l_2851);
x86_l_284e:
	/* 0x284e: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2851:
	/* 0x2851: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2854:
	/* 0x2854: jns    285b <trace_chmod_common+0x285b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2854, 0x285b, x86_l_285b);
x86_l_2856:
	/* 0x2856: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2859:
	/* 0x2859: jmp    285d <trace_chmod_common+0x285d> */
	X86_SIM_X86_JMP(0x2859, 0x285d, x86_l_285d);
x86_l_285b:
	/* 0x285b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_285d:
	/* 0x285d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2860:
	/* 0x2860: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2863:
	/* 0x2863: jns    286a <trace_chmod_common+0x286a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2863, 0x286a, x86_l_286a);
x86_l_2865:
	/* 0x2865: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2868:
	/* 0x2868: jmp    286c <trace_chmod_common+0x286c> */
	X86_SIM_X86_JMP(0x2868, 0x286c, x86_l_286c);
x86_l_286a:
	/* 0x286a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286c:
	/* 0x286c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2870:
	/* 0x2870: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2873:
	/* 0x2873: jns    289b <trace_chmod_common+0x289b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2873, 0x289b, x86_l_289b);
x86_l_2875:
	/* 0x2875: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2878:
	/* 0x2878: jmp    289d <trace_chmod_common+0x289d> */
	X86_SIM_X86_JMP(0x2878, 0x289d, x86_l_289d);
x86_l_287a:
	/* 0x287a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_287f:
	/* 0x287f: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2883:
	/* 0x2883: jl     28ab <trace_chmod_common+0x28ab> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2883, 0x28ab, x86_l_28ab);
x86_l_2885:
	/* 0x2885: lea    edx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2888:
	/* 0x2888: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_288e:
	/* 0x288e: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2893:
	/* 0x2893: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2896:
	/* 0x2896: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2899:
	/* 0x2899: js     2875 <trace_chmod_common+0x2875> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2899, 0x2875, x86_l_2875);
x86_l_289b:
	/* 0x289b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_289d:
	/* 0x289d: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28a1:
	/* 0x28a1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: jns    28b7 <trace_chmod_common+0x28b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28a4, 0x28b7, x86_l_28b7);
x86_l_28a6:
	/* 0x28a6: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a9:
	/* 0x28a9: jmp    28b9 <trace_chmod_common+0x28b9> */
	X86_SIM_X86_JMP(0x28a9, 0x28b9, x86_l_28b9);
x86_l_28ab:
	/* 0x28ab: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_28ae:
	/* 0x28ae: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b2:
	/* 0x28b2: jmp    1127 <trace_chmod_common+0x1127> */
	X86_SIM_X86_JMP(0x28b2, 0x1127, x86_l_1127);
x86_l_28b7:
	/* 0x28b7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b9:
	/* 0x28b9: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28bc:
	/* 0x28bc: je     2fd3 <trace_chmod_common+0x2fd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28bc, 0x2fd3, x86_l_2fd3);
x86_l_28c2:
	/* 0x28c2: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28c5:
	/* 0x28c5: je     2fd3 <trace_chmod_common+0x2fd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c5, 0x2fd3, x86_l_2fd3);
x86_l_28cb:
	/* 0x28cb: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28cf:
	/* 0x28cf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28d2:
	/* 0x28d2: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_28d7:
	/* 0x28d7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28da:
	/* 0x28da: jns    28e3 <trace_chmod_common+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28da, 0x28e3, x86_l_28e3);
x86_l_28dc:
	/* 0x28dc: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28df:
	/* 0x28df: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28e3:
	/* 0x28e3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28e7:
	/* 0x28e7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28ea:
	/* 0x28ea: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28f1:
	/* 0x28f1: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_28f3:
	/* 0x28f3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28f6:
	/* 0x28f6: jae    2ff3 <trace_chmod_common+0x2ff3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x28f6, 0x2ff3, x86_l_2ff3);
x86_l_28fc:
	/* 0x28fc: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2900:
	/* 0x2900: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2902:
	/* 0x2902: mov    eax,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2904:
	/* 0x2904: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2909:
	/* 0x2909: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_290e:
	/* 0x290e: mov    BYTE PTR [rbp+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2915:
	/* 0x2915: and    ebx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_291b:
	/* 0x291b: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_291e:
	/* 0x291e: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2926:
	/* 0x2926: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_292c:
	/* 0x292c: ja     2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x292c, 0x2a0a, x86_l_2a0a);
x86_l_2932:
	/* 0x2932: mov    BYTE PTR [r13+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_293b:
	/* 0x293b: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2943:
	/* 0x2943: mov    WORD PTR [r13+0x7d8c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_294b:
	/* 0x294b: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2951:
	/* 0x2951: ja     2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2951, 0x2a0a, x86_l_2a0a);
x86_l_2957:
	/* 0x2957: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_295c:
	/* 0x295c: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2960:
	/* 0x2960: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2967:
	/* 0x2967: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_296a:
	/* 0x296a: jns    2991 <trace_chmod_common+0x2991> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296a, 0x2991, x86_l_2991);
x86_l_296c:
	/* 0x296c: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_296f:
	/* 0x296f: jns    29da <trace_chmod_common+0x29da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x296f, 0x29da, x86_l_29da);
x86_l_2971:
	/* 0x2971: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2973:
	/* 0x2973: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_297a:
	/* 0x297a: je     29e8 <trace_chmod_common+0x29e8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x297a, 0x29e8, x86_l_29e8);
x86_l_297c:
	/* 0x297c: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2980:
	/* 0x2980: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2985:
	/* 0x2985: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2988:
	/* 0x2988: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_298b:
	/* 0x298b: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_298d:
	/* 0x298d: jne    2973 <trace_chmod_common+0x2973> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x298d, 0x2973, x86_l_2973);
x86_l_298f:
	/* 0x298f: jmp    299e <trace_chmod_common+0x299e> */
	X86_SIM_X86_JMP(0x298f, 0x299e, x86_l_299e);
x86_l_2991:
	/* 0x2991: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2996:
	/* 0x2996: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2999:
	/* 0x2999: call   299e <trace_chmod_common+0x299e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_299e:
	/* 0x299e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29a1:
	/* 0x29a1: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_29a3:
	/* 0x29a3: jle    2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x29a3, 0x2a0a, x86_l_2a0a);
x86_l_29a5:
	/* 0x29a5: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_29ad:
	/* 0x29ad: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_29b4:
	/* 0x29b4: ja     2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JCC(X86_CC_A, 0x29b4, 0x2a0a, x86_l_2a0a);
x86_l_29b6:
	/* 0x29b6: mov    DWORD PTR [rdx+r13*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 138ULL);
x86_l_29be:
	/* 0x29be: add    cx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_29c6:
	/* 0x29c6: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_29c9:
	/* 0x29c9: mov    WORD PTR [r13+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_29d1:
	/* 0x29d1: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_29d8:
	/* 0x29d8: jmp    2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JMP(0x29d8, 0x2a0a, x86_l_2a0a);
x86_l_29da:
	/* 0x29da: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_29df:
	/* 0x29df: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e1:
	/* 0x29e1: call   29e6 <trace_chmod_common+0x29e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_29e6:
	/* 0x29e6: jmp    2a0a <trace_chmod_common+0x2a0a> */
	X86_SIM_X86_JMP(0x29e6, 0x2a0a, x86_l_2a0a);
x86_l_29e8:
	/* 0x29e8: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_29ef:
	/* 0x29ef: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_29f4:
	/* 0x29f4: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_29f9:
	/* 0x29f9: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a01:
	/* 0x2a01: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2a08:
	/* 0x2a08: jbe    29b6 <trace_chmod_common+0x29b6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2a08, 0x29b6, x86_l_29b6);
x86_l_2a0a:
	/* 0x2a0a: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2a12:
	/* 0x2a12: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2a19:
	/* 0x2a19: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a1e:
	/* 0x2a1e: ja     2a80 <trace_chmod_common+0x2a80> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a1e, 0x2a80, x86_l_2a80);
x86_l_2a20:
	/* 0x2a20: mov    BYTE PTR [r13+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_2a29:
	/* 0x2a29: cmp    ebx,0x7cfd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31997ULL);
x86_l_2a2f:
	/* 0x2a2f: ja     2a80 <trace_chmod_common+0x2a80> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a2f, 0x2a80, x86_l_2a80);
x86_l_2a31:
	/* 0x2a31: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2a35:
	/* 0x2a35: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2a3c:
	/* 0x2a3c: lea    rax,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2a41:
	/* 0x2a41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a44:
	/* 0x2a44: jns    2a53 <trace_chmod_common+0x2a53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a44, 0x2a53, x86_l_2a53);
x86_l_2a46:
	/* 0x2a46: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a49:
	/* 0x2a49: jns    2a7b <trace_chmod_common+0x2a7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a49, 0x2a7b, x86_l_2a7b);
x86_l_2a4b:
	/* 0x2a4b: movzx  eax,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2a4e:
	/* 0x2a4e: mov    WORD PTR [rdi],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a51:
	/* 0x2a51: jmp    2a67 <trace_chmod_common+0x2a67> */
	X86_SIM_X86_JMP(0x2a51, 0x2a67, x86_l_2a67);
x86_l_2a53:
	/* 0x2a53: lea    rdx,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2a58:
	/* 0x2a58: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2a5d:
	/* 0x2a5d: call   2a62 <trace_chmod_common+0x2a62> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a62:
	/* 0x2a62: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a65:
	/* 0x2a65: js     2a80 <trace_chmod_common+0x2a80> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a65, 0x2a80, x86_l_2a80);
x86_l_2a67:
	/* 0x2a67: add    ebx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_2a6a:
	/* 0x2a6a: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2a72:
	/* 0x2a72: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2a79:
	/* 0x2a79: jmp    2a80 <trace_chmod_common+0x2a80> */
	X86_SIM_X86_JMP(0x2a79, 0x2a80, x86_l_2a80);
x86_l_2a7b:
	/* 0x2a7b: mov    WORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a80:
	/* 0x2a80: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2a87:
	/* 0x2a87: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2a8b:
	/* 0x2a8b: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a8e:
	/* 0x2a8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a91:
	/* 0x2a91: jns    2aa3 <trace_chmod_common+0x2aa3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a91, 0x2aa3, x86_l_2aa3);
x86_l_2a93:
	/* 0x2a93: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a96:
	/* 0x2a96: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a9a:
	/* 0x2a9a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a9d:
	/* 0x2a9d: js     2aaf <trace_chmod_common+0x2aaf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a9d, 0x2aaf, x86_l_2aaf);
x86_l_2a9f:
	/* 0x2a9f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aa1:
	/* 0x2aa1: jmp    2ab2 <trace_chmod_common+0x2ab2> */
	X86_SIM_X86_JMP(0x2aa1, 0x2ab2, x86_l_2ab2);
x86_l_2aa3:
	/* 0x2aa3: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aa6:
	/* 0x2aa6: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2aaa:
	/* 0x2aaa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aad:
	/* 0x2aad: jns    2a9f <trace_chmod_common+0x2a9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aad, 0x2a9f, x86_l_2a9f);
x86_l_2aaf:
	/* 0x2aaf: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab2:
	/* 0x2ab2: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2ab6:
	/* 0x2ab6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ab8:
	/* 0x2ab8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2abb:
	/* 0x2abb: jns    2acc <trace_chmod_common+0x2acc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2abb, 0x2acc, x86_l_2acc);
x86_l_2abd:
	/* 0x2abd: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ac0:
	/* 0x2ac0: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2ac5:
	/* 0x2ac5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ac8:
	/* 0x2ac8: js     2ad9 <trace_chmod_common+0x2ad9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ac8, 0x2ad9, x86_l_2ad9);
x86_l_2aca:
	/* 0x2aca: jmp    2adb <trace_chmod_common+0x2adb> */
	X86_SIM_X86_JMP(0x2aca, 0x2adb, x86_l_2adb);
x86_l_2acc:
	/* 0x2acc: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2acf:
	/* 0x2acf: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2ad4:
	/* 0x2ad4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ad7:
	/* 0x2ad7: jns    2adb <trace_chmod_common+0x2adb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad7, 0x2adb, x86_l_2adb);
x86_l_2ad9:
	/* 0x2ad9: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2adb:
	/* 0x2adb: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2adf:
	/* 0x2adf: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ae3:
	/* 0x2ae3: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ae6:
	/* 0x2ae6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ae8:
	/* 0x2ae8: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2aeb:
	/* 0x2aeb: jns    2afa <trace_chmod_common+0x2afa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aeb, 0x2afa, x86_l_2afa);
x86_l_2aed:
	/* 0x2aed: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2af0:
	/* 0x2af0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2af3:
	/* 0x2af3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2af6:
	/* 0x2af6: js     2b04 <trace_chmod_common+0x2b04> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2af6, 0x2b04, x86_l_2b04);
x86_l_2af8:
	/* 0x2af8: jmp    2b06 <trace_chmod_common+0x2b06> */
	X86_SIM_X86_JMP(0x2af8, 0x2b06, x86_l_2b06);
x86_l_2afa:
	/* 0x2afa: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2afc:
	/* 0x2afc: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2aff:
	/* 0x2aff: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2b02:
	/* 0x2b02: jns    2b06 <trace_chmod_common+0x2b06> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b02, 0x2b06, x86_l_2b06);
x86_l_2b04:
	/* 0x2b04: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b06:
	/* 0x2b06: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2b08:
	/* 0x2b08: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2b0c:
	/* 0x2b0c: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b0f:
	/* 0x2b0f: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2b13:
	/* 0x2b13: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b15:
	/* 0x2b15: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b18:
	/* 0x2b18: jns    2b1c <trace_chmod_common+0x2b1c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b18, 0x2b1c, x86_l_2b1c);
x86_l_2b1a:
	/* 0x2b1a: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b1c:
	/* 0x2b1c: mov    DWORD PTR [r13+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2b20:
	/* 0x2b20: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b23:
	/* 0x2b23: jns    2b2a <trace_chmod_common+0x2b2a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b23, 0x2b2a, x86_l_2b2a);
x86_l_2b25:
	/* 0x2b25: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b28:
	/* 0x2b28: jmp    2b2c <trace_chmod_common+0x2b2c> */
	X86_SIM_X86_JMP(0x2b28, 0x2b2c, x86_l_2b2c);
x86_l_2b2a:
	/* 0x2b2a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b2c:
	/* 0x2b2c: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2b30:
	/* 0x2b30: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b32:
	/* 0x2b32: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b35:
	/* 0x2b35: jns    2b44 <trace_chmod_common+0x2b44> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b35, 0x2b44, x86_l_2b44);
x86_l_2b37:
	/* 0x2b37: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3a:
	/* 0x2b3a: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b3d:
	/* 0x2b3d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b40:
	/* 0x2b40: js     2b4e <trace_chmod_common+0x2b4e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b40, 0x2b4e, x86_l_2b4e);
x86_l_2b42:
	/* 0x2b42: jmp    2b50 <trace_chmod_common+0x2b50> */
	X86_SIM_X86_JMP(0x2b42, 0x2b50, x86_l_2b50);
x86_l_2b44:
	/* 0x2b44: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b46:
	/* 0x2b46: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b49:
	/* 0x2b49: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b4c:
	/* 0x2b4c: jns    2b50 <trace_chmod_common+0x2b50> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b4c, 0x2b50, x86_l_2b50);
x86_l_2b4e:
	/* 0x2b4e: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b50:
	/* 0x2b50: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2b52:
	/* 0x2b52: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2b56:
	/* 0x2b56: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b59:
	/* 0x2b59: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2b5d:
	/* 0x2b5d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b5f:
	/* 0x2b5f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b62:
	/* 0x2b62: jns    2b66 <trace_chmod_common+0x2b66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b62, 0x2b66, x86_l_2b66);
x86_l_2b64:
	/* 0x2b64: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b66:
	/* 0x2b66: mov    DWORD PTR [r13+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b6a:
	/* 0x2b6a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b6c:
	/* 0x2b6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b6f:
	/* 0x2b6f: jns    2b7e <trace_chmod_common+0x2b7e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b6f, 0x2b7e, x86_l_2b7e);
x86_l_2b71:
	/* 0x2b71: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b74:
	/* 0x2b74: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b77:
	/* 0x2b77: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b7a:
	/* 0x2b7a: js     2b88 <trace_chmod_common+0x2b88> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b7a, 0x2b88, x86_l_2b88);
x86_l_2b7c:
	/* 0x2b7c: jmp    2b8a <trace_chmod_common+0x2b8a> */
	X86_SIM_X86_JMP(0x2b7c, 0x2b8a, x86_l_2b8a);
x86_l_2b7e:
	/* 0x2b7e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b80:
	/* 0x2b80: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b83:
	/* 0x2b83: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b86:
	/* 0x2b86: jns    2b8a <trace_chmod_common+0x2b8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b86, 0x2b8a, x86_l_2b8a);
x86_l_2b88:
	/* 0x2b88: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b8a:
	/* 0x2b8a: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2b8c:
	/* 0x2b8c: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2b90:
	/* 0x2b90: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b93:
	/* 0x2b93: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2b97:
	/* 0x2b97: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b99:
	/* 0x2b99: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b9c:
	/* 0x2b9c: jns    2bac <trace_chmod_common+0x2bac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b9c, 0x2bac, x86_l_2bac);
x86_l_2b9e:
	/* 0x2b9e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ba1:
	/* 0x2ba1: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2ba5:
	/* 0x2ba5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ba8:
	/* 0x2ba8: js     2bb7 <trace_chmod_common+0x2bb7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ba8, 0x2bb7, x86_l_2bb7);
x86_l_2baa:
	/* 0x2baa: jmp    2bb9 <trace_chmod_common+0x2bb9> */
	X86_SIM_X86_JMP(0x2baa, 0x2bb9, x86_l_2bb9);
x86_l_2bac:
	/* 0x2bac: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bae:
	/* 0x2bae: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2bb2:
	/* 0x2bb2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bb5:
	/* 0x2bb5: jns    2bb9 <trace_chmod_common+0x2bb9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bb5, 0x2bb9, x86_l_2bb9);
x86_l_2bb7:
	/* 0x2bb7: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bb9:
	/* 0x2bb9: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bbe:
	/* 0x2bbe: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bc1:
	/* 0x2bc1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bc3:
	/* 0x2bc3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bc6:
	/* 0x2bc6: jns    2bd5 <trace_chmod_common+0x2bd5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bc6, 0x2bd5, x86_l_2bd5);
x86_l_2bc8:
	/* 0x2bc8: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bcb:
	/* 0x2bcb: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bce:
	/* 0x2bce: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2bd1:
	/* 0x2bd1: js     2bdf <trace_chmod_common+0x2bdf> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bd1, 0x2bdf, x86_l_2bdf);
x86_l_2bd3:
	/* 0x2bd3: jmp    2be1 <trace_chmod_common+0x2be1> */
	X86_SIM_X86_JMP(0x2bd3, 0x2be1, x86_l_2be1);
x86_l_2bd5:
	/* 0x2bd5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bd7:
	/* 0x2bd7: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bda:
	/* 0x2bda: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2bdd:
	/* 0x2bdd: jns    2be1 <trace_chmod_common+0x2be1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bdd, 0x2be1, x86_l_2be1);
x86_l_2bdf:
	/* 0x2bdf: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2be1:
	/* 0x2be1: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2be3:
	/* 0x2be3: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2be7:
	/* 0x2be7: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2bea:
	/* 0x2bea: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2bee:
	/* 0x2bee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bf0:
	/* 0x2bf0: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bf3:
	/* 0x2bf3: jns    2c03 <trace_chmod_common+0x2c03> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bf3, 0x2c03, x86_l_2c03);
x86_l_2bf5:
	/* 0x2bf5: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bf8:
	/* 0x2bf8: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2bfc:
	/* 0x2bfc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bff:
	/* 0x2bff: js     2c0e <trace_chmod_common+0x2c0e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bff, 0x2c0e, x86_l_2c0e);
x86_l_2c01:
	/* 0x2c01: jmp    2c10 <trace_chmod_common+0x2c10> */
	X86_SIM_X86_JMP(0x2c01, 0x2c10, x86_l_2c10);
x86_l_2c03:
	/* 0x2c03: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c05:
	/* 0x2c05: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2c09:
	/* 0x2c09: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c0c:
	/* 0x2c0c: jns    2c10 <trace_chmod_common+0x2c10> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c0c, 0x2c10, x86_l_2c10);
x86_l_2c0e:
	/* 0x2c0e: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c10:
	/* 0x2c10: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2c12:
	/* 0x2c12: jne    2c4e <trace_chmod_common+0x2c4e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c12, 0x2c4e, x86_l_2c4e);
x86_l_2c14:
	/* 0x2c14: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c16:
	/* 0x2c16: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c19:
	/* 0x2c19: jns    2c28 <trace_chmod_common+0x2c28> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c19, 0x2c28, x86_l_2c28);
x86_l_2c1b:
	/* 0x2c1b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c1e:
	/* 0x2c1e: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c21:
	/* 0x2c21: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c24:
	/* 0x2c24: js     2c32 <trace_chmod_common+0x2c32> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c24, 0x2c32, x86_l_2c32);
x86_l_2c26:
	/* 0x2c26: jmp    2c34 <trace_chmod_common+0x2c34> */
	X86_SIM_X86_JMP(0x2c26, 0x2c34, x86_l_2c34);
x86_l_2c28:
	/* 0x2c28: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c2a:
	/* 0x2c2a: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c2d:
	/* 0x2c2d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c30:
	/* 0x2c30: jns    2c34 <trace_chmod_common+0x2c34> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c30, 0x2c34, x86_l_2c34);
x86_l_2c32:
	/* 0x2c32: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c34:
	/* 0x2c34: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2c36:
	/* 0x2c36: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2c3a:
	/* 0x2c3a: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c3d:
	/* 0x2c3d: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2c41:
	/* 0x2c41: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c43:
	/* 0x2c43: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c46:
	/* 0x2c46: jns    2c4a <trace_chmod_common+0x2c4a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c46, 0x2c4a, x86_l_2c4a);
x86_l_2c48:
	/* 0x2c48: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c4a:
	/* 0x2c4a: mov    DWORD PTR [r13+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c4e:
	/* 0x2c4e: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2c52:
	/* 0x2c52: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2c59:
	/* 0x2c59: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2c5c:
	/* 0x2c5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c5f:
	/* 0x2c5f: jns    2c66 <trace_chmod_common+0x2c66> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c5f, 0x2c66, x86_l_2c66);
x86_l_2c61:
	/* 0x2c61: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c64:
	/* 0x2c64: jmp    2c68 <trace_chmod_common+0x2c68> */
	X86_SIM_X86_JMP(0x2c64, 0x2c68, x86_l_2c68);
x86_l_2c66:
	/* 0x2c66: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c68:
	/* 0x2c68: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2c6c:
	/* 0x2c6c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c6e:
	/* 0x2c6e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c71:
	/* 0x2c71: jns    2c7d <trace_chmod_common+0x2c7d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c71, 0x2c7d, x86_l_2c7d);
x86_l_2c73:
	/* 0x2c73: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c76:
	/* 0x2c76: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c79:
	/* 0x2c79: js     2c84 <trace_chmod_common+0x2c84> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c79, 0x2c84, x86_l_2c84);
x86_l_2c7b:
	/* 0x2c7b: jmp    2c86 <trace_chmod_common+0x2c86> */
	X86_SIM_X86_JMP(0x2c7b, 0x2c86, x86_l_2c86);
x86_l_2c7d:
	/* 0x2c7d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c7f:
	/* 0x2c7f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c82:
	/* 0x2c82: jns    2c86 <trace_chmod_common+0x2c86> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c82, 0x2c86, x86_l_2c86);
x86_l_2c84:
	/* 0x2c84: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c86:
	/* 0x2c86: lea    rbp,[r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c8a:
	/* 0x2c8a: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8e:
	/* 0x2c8e: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2c92:
	/* 0x2c92: call   2c97 <trace_chmod_common+0x2c97> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2c97:
	/* 0x2c97: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c9b:
	/* 0x2c9b: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2c9f:
	/* 0x2c9f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ca2:
	/* 0x2ca2: jns    2ca9 <trace_chmod_common+0x2ca9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ca2, 0x2ca9, x86_l_2ca9);
x86_l_2ca4:
	/* 0x2ca4: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ca7:
	/* 0x2ca7: jmp    2cab <trace_chmod_common+0x2cab> */
	X86_SIM_X86_JMP(0x2ca7, 0x2cab, x86_l_2cab);
x86_l_2ca9:
	/* 0x2ca9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cab:
	/* 0x2cab: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2caf:
	/* 0x2caf: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2cb3:
	/* 0x2cb3: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2cb6:
	/* 0x2cb6: jns    2cbd <trace_chmod_common+0x2cbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cb6, 0x2cbd, x86_l_2cbd);
x86_l_2cb8:
	/* 0x2cb8: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cbb:
	/* 0x2cbb: jmp    2cbf <trace_chmod_common+0x2cbf> */
	X86_SIM_X86_JMP(0x2cbb, 0x2cbf, x86_l_2cbf);
x86_l_2cbd:
	/* 0x2cbd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cbf:
	/* 0x2cbf: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cc3:
	/* 0x2cc3: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2cc7:
	/* 0x2cc7: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2ccb:
	/* 0x2ccb: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2cce:
	/* 0x2cce: jns    2cd6 <trace_chmod_common+0x2cd6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cce, 0x2cd6, x86_l_2cd6);
x86_l_2cd0:
	/* 0x2cd0: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cd4:
	/* 0x2cd4: jmp    2cd8 <trace_chmod_common+0x2cd8> */
	X86_SIM_X86_JMP(0x2cd4, 0x2cd8, x86_l_2cd8);
x86_l_2cd6:
	/* 0x2cd6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cd8:
	/* 0x2cd8: mov    r15,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2ce0:
	/* 0x2ce0: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ce4:
	/* 0x2ce4: mov    QWORD PTR [rcx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2ce8:
	/* 0x2ce8: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2ceb:
	/* 0x2ceb: jns    2cf7 <trace_chmod_common+0x2cf7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ceb, 0x2cf7, x86_l_2cf7);
x86_l_2ced:
	/* 0x2ced: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cef:
	/* 0x2cef: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2cf1:
	/* 0x2cf1: je     2cf7 <trace_chmod_common+0x2cf7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cf1, 0x2cf7, x86_l_2cf7);
x86_l_2cf3:
	/* 0x2cf3: or     BYTE PTR [rcx+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_2cf7:
	/* 0x2cf7: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2cfc:
	/* 0x2cfc: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_2d00:
	/* 0x2d00: mov    QWORD PTR [rcx+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_2d08:
	/* 0x2d08: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_2d10:
	/* 0x2d10: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2d15:
	/* 0x2d15: call   2d1a <trace_chmod_common+0x2d1a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_2d1a:
	/* 0x2d1a: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2d1d:
	/* 0x2d1d: jns    2d25 <trace_chmod_common+0x2d25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d1d, 0x2d25, x86_l_2d25);
x86_l_2d1f:
	/* 0x2d1f: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d23:
	/* 0x2d23: jmp    2d27 <trace_chmod_common+0x2d27> */
	X86_SIM_X86_JMP(0x2d23, 0x2d27, x86_l_2d27);
x86_l_2d25:
	/* 0x2d25: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d27:
	/* 0x2d27: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d2c:
	/* 0x2d2c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d2f:
	/* 0x2d2f: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d33:
	/* 0x2d33: jns    2d3f <trace_chmod_common+0x2d3f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d33, 0x2d3f, x86_l_2d3f);
x86_l_2d35:
	/* 0x2d35: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d38:
	/* 0x2d38: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d3b:
	/* 0x2d3b: js     2d46 <trace_chmod_common+0x2d46> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d3b, 0x2d46, x86_l_2d46);
x86_l_2d3d:
	/* 0x2d3d: jmp    2d87 <trace_chmod_common+0x2d87> */
	X86_SIM_X86_JMP(0x2d3d, 0x2d87, x86_l_2d87);
x86_l_2d3f:
	/* 0x2d3f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d41:
	/* 0x2d41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d44:
	/* 0x2d44: jns    2d87 <trace_chmod_common+0x2d87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d44, 0x2d87, x86_l_2d87);
x86_l_2d46:
	/* 0x2d46: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d49:
	/* 0x2d49: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2d4e:
	/* 0x2d4e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d52:
	/* 0x2d52: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2d57:
	/* 0x2d57: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d5b:
	/* 0x2d5b: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2d60:
	/* 0x2d60: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2d64:
	/* 0x2d64: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2d69:
	/* 0x2d69: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d6d:
	/* 0x2d6d: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2d72:
	/* 0x2d72: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d76:
	/* 0x2d76: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2d7b:
	/* 0x2d7b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2d7f:
	/* 0x2d7f: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2d83:
	/* 0x2d83: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2d87:
	/* 0x2d87: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d8c:
	/* 0x2d8c: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_2d90:
	/* 0x2d90: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2d95:
	/* 0x2d95: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d98:
	/* 0x2d98: jns    2e6e <trace_chmod_common+0x2e6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2d98, 0x2e6e, x86_l_2e6e);
x86_l_2d9e:
	/* 0x2d9e: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2da1:
	/* 0x2da1: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da3:
	/* 0x2da3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2da5:
	/* 0x2da5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2da5, 0x2e7d, x86_l_2e7d);
x86_l_2dab:
	/* 0x2dab: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2daf:
	/* 0x2daf: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_2db3:
	/* 0x2db3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2db5:
	/* 0x2db5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2db5, 0x2e7d, x86_l_2e7d);
x86_l_2dbb:
	/* 0x2dbb: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2dbf:
	/* 0x2dbf: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_2dc3:
	/* 0x2dc3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2dc5:
	/* 0x2dc5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dc5, 0x2e7d, x86_l_2e7d);
x86_l_2dcb:
	/* 0x2dcb: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2dcf:
	/* 0x2dcf: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2dd3:
	/* 0x2dd3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2dd5:
	/* 0x2dd5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dd5, 0x2e7d, x86_l_2e7d);
x86_l_2ddb:
	/* 0x2ddb: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2ddf:
	/* 0x2ddf: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2de3:
	/* 0x2de3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2de5:
	/* 0x2de5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2de5, 0x2e7d, x86_l_2e7d);
x86_l_2deb:
	/* 0x2deb: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2def:
	/* 0x2def: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2df3:
	/* 0x2df3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2df5:
	/* 0x2df5: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2df5, 0x2e7d, x86_l_2e7d);
x86_l_2dfb:
	/* 0x2dfb: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2dff:
	/* 0x2dff: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2e03:
	/* 0x2e03: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e05:
	/* 0x2e05: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e05, 0x2e7d, x86_l_2e7d);
x86_l_2e07:
	/* 0x2e07: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2e0b:
	/* 0x2e0b: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_2e0f:
	/* 0x2e0f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e11:
	/* 0x2e11: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e11, 0x2e7d, x86_l_2e7d);
x86_l_2e13:
	/* 0x2e13: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2e17:
	/* 0x2e17: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_2e1b:
	/* 0x2e1b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e1d:
	/* 0x2e1d: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e1d, 0x2e7d, x86_l_2e7d);
x86_l_2e1f:
	/* 0x2e1f: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2e23:
	/* 0x2e23: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_2e27:
	/* 0x2e27: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e29:
	/* 0x2e29: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e29, 0x2e7d, x86_l_2e7d);
x86_l_2e2b:
	/* 0x2e2b: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2e2f:
	/* 0x2e2f: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_2e33:
	/* 0x2e33: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e35:
	/* 0x2e35: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e35, 0x2e7d, x86_l_2e7d);
x86_l_2e37:
	/* 0x2e37: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2e3b:
	/* 0x2e3b: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_2e3f:
	/* 0x2e3f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e41:
	/* 0x2e41: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e41, 0x2e7d, x86_l_2e7d);
x86_l_2e43:
	/* 0x2e43: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2e47:
	/* 0x2e47: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2e4b:
	/* 0x2e4b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e4d:
	/* 0x2e4d: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e4d, 0x2e7d, x86_l_2e7d);
x86_l_2e4f:
	/* 0x2e4f: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2e53:
	/* 0x2e53: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_2e57:
	/* 0x2e57: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2e59:
	/* 0x2e59: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e59, 0x2e7d, x86_l_2e7d);
x86_l_2e5b:
	/* 0x2e5b: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2e5f:
	/* 0x2e5f: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_2e63:
	/* 0x2e63: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2e65:
	/* 0x2e65: je     2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e65, 0x2e7d, x86_l_2e7d);
x86_l_2e67:
	/* 0x2e67: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_2e6c:
	/* 0x2e6c: jmp    2e7d <trace_chmod_common+0x2e7d> */
	X86_SIM_X86_JMP(0x2e6c, 0x2e7d, x86_l_2e7d);
x86_l_2e6e:
	/* 0x2e6e: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2e76:
	/* 0x2e76: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e7d:
	/* 0x2e7d: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2e80:
	/* 0x2e80: jns    2efa <trace_chmod_common+0x2efa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e80, 0x2efa, x86_l_2efa);
x86_l_2e82:
	/* 0x2e82: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e86:
	/* 0x2e86: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e8b:
	/* 0x2e8b: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e8e:
	/* 0x2e8e: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e92:
	/* 0x2e92: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e96:
	/* 0x2e96: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e9a:
	/* 0x2e9a: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e9e:
	/* 0x2e9e: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ea2:
	/* 0x2ea2: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ea6:
	/* 0x2ea6: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2eaa:
	/* 0x2eaa: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2eae:
	/* 0x2eae: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2eb2:
	/* 0x2eb2: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2eb6:
	/* 0x2eb6: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2eba:
	/* 0x2eba: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ebe:
	/* 0x2ebe: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ec2:
	/* 0x2ec2: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ec6:
	/* 0x2ec6: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2eca:
	/* 0x2eca: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ece:
	/* 0x2ece: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2ed2:
	/* 0x2ed2: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2ed6:
	/* 0x2ed6: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2eda:
	/* 0x2eda: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ede:
	/* 0x2ede: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2ee2:
	/* 0x2ee2: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2ee6:
	/* 0x2ee6: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2eea:
	/* 0x2eea: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2eee:
	/* 0x2eee: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_2ef3:
	/* 0x2ef3: jne    2f6d <trace_chmod_common+0x2f6d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ef3, 0x2f6d, x86_l_2f6d);
x86_l_2ef5:
	/* 0x2ef5: jmp    2f89 <trace_chmod_common+0x2f89> */
	X86_SIM_X86_JMP(0x2ef5, 0x2f89, x86_l_2f89);
x86_l_2efa:
	/* 0x2efa: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2eff:
	/* 0x2eff: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_2f07:
	/* 0x2f07: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_2f0f:
	/* 0x2f0f: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_2f17:
	/* 0x2f17: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_2f1f:
	/* 0x2f1f: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2f27:
	/* 0x2f27: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_2f2f:
	/* 0x2f2f: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2f37:
	/* 0x2f37: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2f3f:
	/* 0x2f3f: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2f47:
	/* 0x2f47: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2f4f:
	/* 0x2f4f: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2f57:
	/* 0x2f57: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2f5f:
	/* 0x2f5f: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f66:
	/* 0x2f66: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_2f6b:
	/* 0x2f6b: je     2f89 <trace_chmod_common+0x2f89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f6b, 0x2f89, x86_l_2f89);
x86_l_2f6d:
	/* 0x2f6d: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_2f74:
	/* 0x2f74: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_2f79:
	/* 0x2f79: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2f7c:
	/* 0x2f7c: call   2f81 <trace_chmod_common+0x2f81> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_2f81:
	/* 0x2f81: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2f83:
	/* 0x2f83: js     2f89 <trace_chmod_common+0x2f89> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f83, 0x2f89, x86_l_2f89);
x86_l_2f85:
	/* 0x2f85: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2f89:
	/* 0x2f89: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2f91:
	/* 0x2f91: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2f96:
	/* 0x2f96: jb     2f9d <trace_chmod_common+0x2f9d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2f96, 0x2f9d, x86_l_2f9d);
x86_l_2f98:
	/* 0x2f98: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2f9d:
	/* 0x2f9d: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_2fa2:
	/* 0x2fa2: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2fa6:
	/* 0x2fa6: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_2fad:
	/* 0x2fad: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2fb2:
	/* 0x2fb2: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2fb5:
	/* 0x2fb5: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2fb8:
	/* 0x2fb8: call   2fbd <trace_chmod_common+0x2fbd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2fbd:
	/* 0x2fbd: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_2fc4:
	/* 0x2fc4: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fc5:
	/* 0x2fc5: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fc7:
	/* 0x2fc7: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fc9:
	/* 0x2fc9: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fcb:
	/* 0x2fcb: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fcd:
	/* 0x2fcd: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2fce:
	/* 0x2fce: jmp    3081 <trace_chmod_common+0x3081> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2fd3:
	/* 0x2fd3: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2fd6:
	/* 0x2fd6: jne    3079 <trace_chmod_common+0x3079> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fd6, 0x3079, x86_l_3079);
x86_l_2fdc:
	/* 0x2fdc: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fdf:
	/* 0x2fdf: je     3079 <trace_chmod_common+0x3079> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fdf, 0x3079, x86_l_3079);
x86_l_2fe5:
	/* 0x2fe5: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fe9:
	/* 0x2fe9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fec:
	/* 0x2fec: jns    302f <trace_chmod_common+0x302f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fec, 0x302f, x86_l_302f);
x86_l_2fee:
	/* 0x2fee: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff1:
	/* 0x2ff1: jmp    3031 <trace_chmod_common+0x3031> */
	X86_SIM_X86_JMP(0x2ff1, 0x3031, x86_l_3031);
x86_l_2ff3:
	/* 0x2ff3: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2ff6:
	/* 0x2ff6: je     3079 <trace_chmod_common+0x3079> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ff6, 0x3079, x86_l_3079);
x86_l_2ffc:
	/* 0x2ffc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3002:
	/* 0x3002: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3005:
	/* 0x3005: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3008:
	/* 0x3008: jns    304e <trace_chmod_common+0x304e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3008, 0x304e, x86_l_304e);
x86_l_300a:
	/* 0x300a: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_300e:
	/* 0x300e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3010:
	/* 0x3010: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3013:
	/* 0x3013: je     305a <trace_chmod_common+0x305a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3013, 0x305a, x86_l_305a);
x86_l_3015:
	/* 0x3015: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3019:
	/* 0x3019: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_301e:
	/* 0x301e: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3022:
	/* 0x3022: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_3025:
	/* 0x3025: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3028:
	/* 0x3028: jne    3010 <trace_chmod_common+0x3010> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3028, 0x3010, x86_l_3010);
x86_l_302a:
	/* 0x302a: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_302d:
	/* 0x302d: jmp    305e <trace_chmod_common+0x305e> */
	X86_SIM_X86_JMP(0x302d, 0x305e, x86_l_305e);
x86_l_302f:
	/* 0x302f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3031:
	/* 0x3031: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3034:
	/* 0x3034: jns    303b <trace_chmod_common+0x303b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3034, 0x303b, x86_l_303b);
x86_l_3036:
	/* 0x3036: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3039:
	/* 0x3039: jmp    303d <trace_chmod_common+0x303d> */
	X86_SIM_X86_JMP(0x3039, 0x303d, x86_l_303d);
x86_l_303b:
	/* 0x303b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_303d:
	/* 0x303d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3040:
	/* 0x3040: jns    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3040, 0x28ae, x86_l_28ae);
x86_l_3046:
	/* 0x3046: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3049:
	/* 0x3049: jmp    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JMP(0x3049, 0x28ae, x86_l_28ae);
x86_l_304e:
	/* 0x304e: mov    r15,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_3051:
	/* 0x3051: mov    r13,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3055:
	/* 0x3055: jmp    111a <trace_chmod_common+0x111a> */
	X86_SIM_X86_JMP(0x3055, 0x111a, x86_l_111a);
x86_l_305a:
	/* 0x305a: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_305e:
	/* 0x305e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_3062:
	/* 0x3062: jl     3079 <trace_chmod_common+0x3079> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3062, 0x3079, x86_l_3079);
x86_l_3064:
	/* 0x3064: lea    eax,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3067:
	/* 0x3067: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_306c:
	/* 0x306c: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_3071:
	/* 0x3071: sub    ebx,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_3074:
	/* 0x3074: jmp    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JMP(0x3074, 0x28ae, x86_l_28ae);
x86_l_3079:
	/* 0x3079: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_307c:
	/* 0x307c: jmp    28ae <trace_chmod_common+0x28ae> */
	X86_SIM_X86_JMP(0x307c, 0x28ae, x86_l_28ae);
x86_l_3081:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
