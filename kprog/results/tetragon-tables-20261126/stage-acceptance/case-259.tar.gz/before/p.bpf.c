#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 280U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(5) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(18) M(19) M(20) M(21) M(24) M(25) M(26) M(27) M(28)
#include "../x86_sim_local_bpf.h"

extern __u8 args_map[] __ksym;
extern __u8 binary_filter_version[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kretprobe/do_init_module")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xe8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 232ULL);
x86_l_11:
	/* 0x11: mov    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: movabs rbx,0x2fa00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 3272765079552ULL);
x86_l_1e:
	/* 0x1e: call   23 <trace_ret_do_init_module+0x23> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_23:
	/* 0x23: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_25:
	/* 0x25: or     rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_28:
	/* 0x28: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2d:
	/* 0x2d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)args_map));
x86_l_34:
	/* 0x34: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_39:
	/* 0x39: call   3e <trace_ret_do_init_module+0x3e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3e:
	/* 0x3e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41:
	/* 0x41: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41, 0x1cc1, x86_l_1cc1);
x86_l_47:
	/* 0x47: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a:
	/* 0x4a: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_52:
	/* 0x52: call   57 <trace_ret_do_init_module+0x57> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_57:
	/* 0x57: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_59:
	/* 0x59: or     rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c:
	/* 0x5c: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_61:
	/* 0x61: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)args_map));
x86_l_68:
	/* 0x68: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6d:
	/* 0x6d: call   72 <trace_ret_do_init_module+0x72> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_72:
	/* 0x72: mov    DWORD PTR [rsp+0xbc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 807453851648ULL);
x86_l_7d:
	/* 0x7d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_84:
	/* 0x84: lea    rsi,[rsp+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_8c:
	/* 0x8c: call   91 <trace_ret_do_init_module+0x91> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_91:
	/* 0x91: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_94:
	/* 0x94: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x94, 0x1cc1, x86_l_1cc1);
x86_l_9a:
	/* 0x9a: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d:
	/* 0x9d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_a4:
	/* 0xa4: lea    rsi,[rsp+0xbc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 188ULL);
x86_l_ac:
	/* 0xac: call   b1 <trace_ret_do_init_module+0xb1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b1:
	/* 0xb1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4:
	/* 0xb4: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4, 0x1cc1, x86_l_1cc1);
x86_l_ba:
	/* 0xba: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd:
	/* 0xbd: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c0:
	/* 0xc0: mov    WORD PTR [r13+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_ca:
	/* 0xca: mov    BYTE PTR [r13+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_d2:
	/* 0xd2: mov    QWORD PTR [r13+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_dd:
	/* 0xdd: mov    QWORD PTR [r13+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_e8:
	/* 0xe8: mov    QWORD PTR [r13+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_f3:
	/* 0xf3: mov    QWORD PTR [r13+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [r13+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_109:
	/* 0x109: mov    QWORD PTR [r13+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_114:
	/* 0x114: mov    QWORD PTR [r13+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_11f:
	/* 0x11f: mov    QWORD PTR [r13+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_12a:
	/* 0x12a: call   12f <trace_ret_do_init_module+0x12f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_12f:
	/* 0x12f: mov    QWORD PTR [r13+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [r13+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_13e:
	/* 0x13e: mov    QWORD PTR [r13+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_146:
	/* 0x146: mov    QWORD PTR [r13+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_14e:
	/* 0x14e: mov    QWORD PTR [r13+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_156:
	/* 0x156: mov    QWORD PTR [r13+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_15e:
	/* 0x15e: mov    QWORD PTR [r13+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_166:
	/* 0x166: mov    QWORD PTR [r13+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_16e:
	/* 0x16e: mov    QWORD PTR [r13+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_176:
	/* 0x176: mov    QWORD PTR [r13+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_17e:
	/* 0x17e: mov    QWORD PTR [r13+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_186:
	/* 0x186: mov    QWORD PTR [r13+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_18e:
	/* 0x18e: mov    QWORD PTR [r13+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_196:
	/* 0x196: mov    QWORD PTR [r13+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_19e:
	/* 0x19e: call   1a3 <trace_ret_do_init_module+0x1a3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1a3:
	/* 0x1a3: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a7:
	/* 0x1a7: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1ab:
	/* 0x1ab: mov    DWORD PTR [r13+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1af:
	/* 0x1af: mov    DWORD PTR [r13+0x70],0x310 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337936ULL);
x86_l_1b7:
	/* 0x1b7: call   1bc <trace_ret_do_init_module+0x1bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_1bc:
	/* 0x1bc: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c0:
	/* 0x1c0: call   1c5 <trace_ret_do_init_module+0x1c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_1c5:
	/* 0x1c5: mov    WORD PTR [r13+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_1ca:
	/* 0x1ca: call   1cf <trace_ret_do_init_module+0x1cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_1cf:
	/* 0x1cf: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d2:
	/* 0x1d2: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1d6:
	/* 0x1d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d9:
	/* 0x1d9: jns    1ea <trace_ret_do_init_module+0x1ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d9, 0x1ea, x86_l_1ea);
x86_l_1db:
	/* 0x1db: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dd:
	/* 0x1dd: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1e2:
	/* 0x1e2: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_1e8:
	/* 0x1e8: jne    227 <trace_ret_do_init_module+0x227> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e8, 0x227, x86_l_227);
x86_l_1ea:
	/* 0x1ea: call   1ef <trace_ret_do_init_module+0x1ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_1ef:
	/* 0x1ef: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f2:
	/* 0x1f2: call   1f7 <trace_ret_do_init_module+0x1f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_1f7:
	/* 0x1f7: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_1fb:
	/* 0x1fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fe:
	/* 0x1fe: jns    20e <trace_ret_do_init_module+0x20e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fe, 0x20e, x86_l_20e);
x86_l_200:
	/* 0x200: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203:
	/* 0x203: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_207:
	/* 0x207: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_20a:
	/* 0x20a: js     219 <trace_ret_do_init_module+0x219> */
	X86_SIM_X86_JCC(X86_CC_S, 0x20a, 0x219, x86_l_219);
x86_l_20c:
	/* 0x20c: jmp    223 <trace_ret_do_init_module+0x223> */
	X86_SIM_X86_JMP(0x20c, 0x223, x86_l_223);
x86_l_20e:
	/* 0x20e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210:
	/* 0x210: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_214:
	/* 0x214: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_217:
	/* 0x217: jns    223 <trace_ret_do_init_module+0x223> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x217, 0x223, x86_l_223);
x86_l_219:
	/* 0x219: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b:
	/* 0x21b: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_21d:
	/* 0x21d: jne    2b0 <trace_ret_do_init_module+0x2b0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21d, 0x2b0, x86_l_2b0);
x86_l_223:
	/* 0x223: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_227:
	/* 0x227: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_22b:
	/* 0x22b: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_22f:
	/* 0x22f: mov    DWORD PTR [rsp+0xb8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_236:
	/* 0x236: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_23d:
	/* 0x23d: lea    rsi,[rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_245:
	/* 0x245: call   24a <trace_ret_do_init_module+0x24a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24a:
	/* 0x24a: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_252:
	/* 0x252: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_255:
	/* 0x255: je     2d7 <trace_ret_do_init_module+0x2d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x255, 0x2d7, x86_l_2d7);
x86_l_25b:
	/* 0x25b: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_25f:
	/* 0x25f: mov    DWORD PTR [rsp+0xb4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_266:
	/* 0x266: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_26d:
	/* 0x26d: lea    rsi,[rsp+0xb4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_275:
	/* 0x275: call   27a <trace_ret_do_init_module+0x27a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27a:
	/* 0x27a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27f:
	/* 0x27f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_282:
	/* 0x282: mov    QWORD PTR [rsp+0x20],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_287:
	/* 0x287: mov    QWORD PTR [rsp+0x8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28c:
	/* 0x28c: mov    QWORD PTR [rsp+0xc8],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_294:
	/* 0x294: je     35d <trace_ret_do_init_module+0x35d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x294, 0x35d, x86_l_35d);
x86_l_29a:
	/* 0x29a: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_2a0:
	/* 0x2a0: jne    7d1 <trace_ret_do_init_module+0x7d1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a0, 0x7d1, x86_l_7d1);
x86_l_2a6:
	/* 0x2a6: call   2ab <trace_ret_do_init_module+0x2ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_2ab:
	/* 0x2ab: jmp    829 <trace_ret_do_init_module+0x829> */
	X86_SIM_X86_JMP(0x2ab, 0x829, x86_l_829);
x86_l_2b0:
	/* 0x2b0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_2b7:
	/* 0x2b7: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2bc:
	/* 0x2bc: call   2c1 <trace_ret_do_init_module+0x2c1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c1:
	/* 0x2c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c4:
	/* 0x2c4: je     2cd <trace_ret_do_init_module+0x2cd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c4, 0x2cd, x86_l_2cd);
x86_l_2c6:
	/* 0x2c6: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c8:
	/* 0x2c8: jmp    227 <trace_ret_do_init_module+0x227> */
	X86_SIM_X86_JMP(0x2c8, 0x227, x86_l_227);
x86_l_2cd:
	/* 0x2cd: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2d2:
	/* 0x2d2: jmp    227 <trace_ret_do_init_module+0x227> */
	X86_SIM_X86_JMP(0x2d2, 0x227, x86_l_227);
x86_l_2d7:
	/* 0x2d7: mov    eax,DWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2de:
	/* 0x2de: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e2:
	/* 0x2e2: mov    DWORD PTR [rsp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_2ea:
	/* 0x2ea: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_2f1:
	/* 0x2f1: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2f6:
	/* 0x2f6: call   2fb <trace_ret_do_init_module+0x2fb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2fb:
	/* 0x2fb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fe:
	/* 0x2fe: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fe, 0x1cc1, x86_l_1cc1);
x86_l_304:
	/* 0x304: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_307:
	/* 0x307: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_30b:
	/* 0x30b: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_30f:
	/* 0x30f: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_314:
	/* 0x314: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_317:
	/* 0x317: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_319:
	/* 0x319: call   31e <trace_ret_do_init_module+0x31e> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_31e:
	/* 0x31e: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_325:
	/* 0x325: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_32a:
	/* 0x32a: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_32f:
	/* 0x32f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_332:
	/* 0x332: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_335:
	/* 0x335: call   33a <trace_ret_do_init_module+0x33a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_33a:
	/* 0x33a: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_33f:
	/* 0x33f: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_342:
	/* 0x342: call   347 <trace_ret_do_init_module+0x347> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_347:
	/* 0x347: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_34f:
	/* 0x34f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_352:
	/* 0x352: jne    25b <trace_ret_do_init_module+0x25b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x352, 0x25b, x86_l_25b);
x86_l_358:
	/* 0x358: jmp    1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JMP(0x358, 0x1cc1, x86_l_1cc1);
x86_l_35d:
	/* 0x35d: mov    eax,DWORD PTR [rsp+0xb4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 180ULL);
x86_l_364:
	/* 0x364: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_368:
	/* 0x368: mov    DWORD PTR [rsp+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_370:
	/* 0x370: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_377:
	/* 0x377: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_37c:
	/* 0x37c: call   381 <trace_ret_do_init_module+0x381> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_381:
	/* 0x381: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_384:
	/* 0x384: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x384, 0x1cc1, x86_l_1cc1);
x86_l_38a:
	/* 0x38a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38d:
	/* 0x38d: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_391:
	/* 0x391: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_395:
	/* 0x395: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_39a:
	/* 0x39a: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_39d:
	/* 0x39d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_39f:
	/* 0x39f: call   3a4 <trace_ret_do_init_module+0x3a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_3a4:
	/* 0x3a4: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_3ab:
	/* 0x3ab: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3b0:
	/* 0x3b0: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3b5:
	/* 0x3b5: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3b8:
	/* 0x3b8: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3bb:
	/* 0x3bb: call   3c0 <trace_ret_do_init_module+0x3c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_3c0:
	/* 0x3c0: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3c5:
	/* 0x3c5: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3c8:
	/* 0x3c8: call   3cd <trace_ret_do_init_module+0x3cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3cd:
	/* 0x3cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d0:
	/* 0x3d0: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3d0, 0x1cc1, x86_l_1cc1);
x86_l_3d6:
	/* 0x3d6: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_3dd:
	/* 0x3dd: lea    r8,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3e1:
	/* 0x3e1: mov    rcx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3e4:
	/* 0x3e4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3e7:
	/* 0x3e7: jns    3ee <trace_ret_do_init_module+0x3ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e7, 0x3ee, x86_l_3ee);
x86_l_3e9:
	/* 0x3e9: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ec:
	/* 0x3ec: jmp    3f1 <trace_ret_do_init_module+0x3f1> */
	X86_SIM_X86_JMP(0x3ec, 0x3f1, x86_l_3f1);
x86_l_3ee:
	/* 0x3ee: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f1:
	/* 0x3f1: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f5:
	/* 0x3f5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3f8:
	/* 0x3f8: jns    3ff <trace_ret_do_init_module+0x3ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3f8, 0x3ff, x86_l_3ff);
x86_l_3fa:
	/* 0x3fa: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3fd:
	/* 0x3fd: jmp    401 <trace_ret_do_init_module+0x401> */
	X86_SIM_X86_JMP(0x3fd, 0x401, x86_l_401);
x86_l_3ff:
	/* 0x3ff: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_401:
	/* 0x401: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_405:
	/* 0x405: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_407:
	/* 0x407: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_40a:
	/* 0x40a: jns    411 <trace_ret_do_init_module+0x411> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x40a, 0x411, x86_l_411);
x86_l_40c:
	/* 0x40c: mov    rbp,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_40f:
	/* 0x40f: jmp    413 <trace_ret_do_init_module+0x413> */
	X86_SIM_X86_JMP(0x40f, 0x413, x86_l_413);
x86_l_411:
	/* 0x411: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_413:
	/* 0x413: lea    rdx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_417:
	/* 0x417: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_41a:
	/* 0x41a: jns    41e <trace_ret_do_init_module+0x41e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x41a, 0x41e, x86_l_41e);
x86_l_41c:
	/* 0x41c: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41e:
	/* 0x41e: mov    DWORD PTR [rax+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_421:
	/* 0x421: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_425:
	/* 0x425: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_428:
	/* 0x428: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_42a:
	/* 0x42a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_42d:
	/* 0x42d: jns    434 <trace_ret_do_init_module+0x434> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x42d, 0x434, x86_l_434);
x86_l_42f:
	/* 0x42f: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_432:
	/* 0x432: jmp    436 <trace_ret_do_init_module+0x436> */
	X86_SIM_X86_JMP(0x432, 0x436, x86_l_436);
x86_l_434:
	/* 0x434: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_436:
	/* 0x436: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_439:
	/* 0x439: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_43c:
	/* 0x43c: jns    440 <trace_ret_do_init_module+0x440> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x43c, 0x440, x86_l_440);
x86_l_43e:
	/* 0x43e: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_440:
	/* 0x440: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_442:
	/* 0x442: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_446:
	/* 0x446: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_449:
	/* 0x449: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_44d:
	/* 0x44d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_44f:
	/* 0x44f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_452:
	/* 0x452: jns    456 <trace_ret_do_init_module+0x456> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x452, 0x456, x86_l_456);
x86_l_454:
	/* 0x454: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_456:
	/* 0x456: mov    DWORD PTR [rax+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_459:
	/* 0x459: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_45c:
	/* 0x45c: jns    463 <trace_ret_do_init_module+0x463> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x45c, 0x463, x86_l_463);
x86_l_45e:
	/* 0x45e: mov    rdx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_461:
	/* 0x461: jmp    465 <trace_ret_do_init_module+0x465> */
	X86_SIM_X86_JMP(0x461, 0x465, x86_l_465);
x86_l_463:
	/* 0x463: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_465:
	/* 0x465: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_469:
	/* 0x469: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_46b:
	/* 0x46b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_46e:
	/* 0x46e: jns    475 <trace_ret_do_init_module+0x475> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x46e, 0x475, x86_l_475);
x86_l_470:
	/* 0x470: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_473:
	/* 0x473: jmp    477 <trace_ret_do_init_module+0x477> */
	X86_SIM_X86_JMP(0x473, 0x477, x86_l_477);
x86_l_475:
	/* 0x475: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_477:
	/* 0x477: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_47a:
	/* 0x47a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_47d:
	/* 0x47d: jns    481 <trace_ret_do_init_module+0x481> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x47d, 0x481, x86_l_481);
x86_l_47f:
	/* 0x47f: mov    edi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_481:
	/* 0x481: mov    esi,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_483:
	/* 0x483: shl    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_487:
	/* 0x487: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_48a:
	/* 0x48a: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_48e:
	/* 0x48e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_490:
	/* 0x490: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_493:
	/* 0x493: jns    497 <trace_ret_do_init_module+0x497> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x493, 0x497, x86_l_497);
x86_l_495:
	/* 0x495: mov    esi,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_497:
	/* 0x497: mov    DWORD PTR [rax+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_49a:
	/* 0x49a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_49c:
	/* 0x49c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_49f:
	/* 0x49f: jns    4a6 <trace_ret_do_init_module+0x4a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x49f, 0x4a6, x86_l_4a6);
x86_l_4a1:
	/* 0x4a1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4a4:
	/* 0x4a4: jmp    4a8 <trace_ret_do_init_module+0x4a8> */
	X86_SIM_X86_JMP(0x4a4, 0x4a8, x86_l_4a8);
x86_l_4a6:
	/* 0x4a6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4a8:
	/* 0x4a8: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4ab:
	/* 0x4ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: jns    4b2 <trace_ret_do_init_module+0x4b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ae, 0x4b2, x86_l_4b2);
x86_l_4b0:
	/* 0x4b0: mov    esi,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b2:
	/* 0x4b2: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_4b4:
	/* 0x4b4: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_4b8:
	/* 0x4b8: add    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_4bb:
	/* 0x4bb: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4bf:
	/* 0x4bf: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4c2:
	/* 0x4c2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4c5:
	/* 0x4c5: jns    4cc <trace_ret_do_init_module+0x4cc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4c5, 0x4cc, x86_l_4cc);
x86_l_4c7:
	/* 0x4c7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ca:
	/* 0x4ca: jmp    4ce <trace_ret_do_init_module+0x4ce> */
	X86_SIM_X86_JMP(0x4ca, 0x4ce, x86_l_4ce);
x86_l_4cc:
	/* 0x4cc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ce:
	/* 0x4ce: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_4d2:
	/* 0x4d2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4d5:
	/* 0x4d5: jns    4da <trace_ret_do_init_module+0x4da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4d5, 0x4da, x86_l_4da);
x86_l_4d7:
	/* 0x4d7: mov    r8d,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4da:
	/* 0x4da: lea    rcx,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4de:
	/* 0x4de: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_4e1:
	/* 0x4e1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e3:
	/* 0x4e3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4e6:
	/* 0x4e6: jns    4ed <trace_ret_do_init_module+0x4ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4e6, 0x4ed, x86_l_4ed);
x86_l_4e8:
	/* 0x4e8: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4eb:
	/* 0x4eb: jmp    4ef <trace_ret_do_init_module+0x4ef> */
	X86_SIM_X86_JMP(0x4eb, 0x4ef, x86_l_4ef);
x86_l_4ed:
	/* 0x4ed: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ef:
	/* 0x4ef: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_4f2:
	/* 0x4f2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4f5:
	/* 0x4f5: jns    4f9 <trace_ret_do_init_module+0x4f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4f5, 0x4f9, x86_l_4f9);
x86_l_4f7:
	/* 0x4f7: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4f9:
	/* 0x4f9: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4fb:
	/* 0x4fb: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_4ff:
	/* 0x4ff: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_502:
	/* 0x502: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_506:
	/* 0x506: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_508:
	/* 0x508: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_50b:
	/* 0x50b: jns    512 <trace_ret_do_init_module+0x512> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x50b, 0x512, x86_l_512);
x86_l_50d:
	/* 0x50d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_510:
	/* 0x510: jmp    514 <trace_ret_do_init_module+0x514> */
	X86_SIM_X86_JMP(0x510, 0x514, x86_l_514);
x86_l_512:
	/* 0x512: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_514:
	/* 0x514: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_518:
	/* 0x518: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_51b:
	/* 0x51b: jns    51f <trace_ret_do_init_module+0x51f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x51b, 0x51f, x86_l_51f);
x86_l_51d:
	/* 0x51d: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_51f:
	/* 0x51f: cmp    r8d,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_522:
	/* 0x522: jne    555 <trace_ret_do_init_module+0x555> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x522, 0x555, x86_l_555);
x86_l_524:
	/* 0x524: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_526:
	/* 0x526: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_529:
	/* 0x529: jns    530 <trace_ret_do_init_module+0x530> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x529, 0x530, x86_l_530);
x86_l_52b:
	/* 0x52b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_52e:
	/* 0x52e: jmp    532 <trace_ret_do_init_module+0x532> */
	X86_SIM_X86_JMP(0x52e, 0x532, x86_l_532);
x86_l_530:
	/* 0x530: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_532:
	/* 0x532: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_535:
	/* 0x535: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_538:
	/* 0x538: jns    53c <trace_ret_do_init_module+0x53c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x538, 0x53c, x86_l_53c);
x86_l_53a:
	/* 0x53a: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53c:
	/* 0x53c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_53e:
	/* 0x53e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_542:
	/* 0x542: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_545:
	/* 0x545: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_549:
	/* 0x549: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_54b:
	/* 0x54b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_54e:
	/* 0x54e: jns    552 <trace_ret_do_init_module+0x552> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x54e, 0x552, x86_l_552);
x86_l_550:
	/* 0x550: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_552:
	/* 0x552: mov    DWORD PTR [rax+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_555:
	/* 0x555: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_55a:
	/* 0x55a: mov    DWORD PTR [rax+0x30],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_55e:
	/* 0x55e: lea    r12,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_565:
	/* 0x565: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_568:
	/* 0x568: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56b:
	/* 0x56b: jns    572 <trace_ret_do_init_module+0x572> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x56b, 0x572, x86_l_572);
x86_l_56d:
	/* 0x56d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_570:
	/* 0x570: jmp    574 <trace_ret_do_init_module+0x574> */
	X86_SIM_X86_JMP(0x570, 0x574, x86_l_574);
x86_l_572:
	/* 0x572: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_574:
	/* 0x574: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_578:
	/* 0x578: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57a:
	/* 0x57a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_57d:
	/* 0x57d: jns    584 <trace_ret_do_init_module+0x584> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x57d, 0x584, x86_l_584);
x86_l_57f:
	/* 0x57f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_582:
	/* 0x582: jmp    586 <trace_ret_do_init_module+0x586> */
	X86_SIM_X86_JMP(0x582, 0x586, x86_l_586);
x86_l_584:
	/* 0x584: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_586:
	/* 0x586: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_589:
	/* 0x589: jns    58d <trace_ret_do_init_module+0x58d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x589, 0x58d, x86_l_58d);
x86_l_58b:
	/* 0x58b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_58d:
	/* 0x58d: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_592:
	/* 0x592: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_596:
	/* 0x596: call   59b <trace_ret_do_init_module+0x59b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_59b:
	/* 0x59b: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_59f:
	/* 0x59f: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5a3:
	/* 0x5a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5a6:
	/* 0x5a6: jns    5ad <trace_ret_do_init_module+0x5ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5a6, 0x5ad, x86_l_5ad);
x86_l_5a8:
	/* 0x5a8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5ab:
	/* 0x5ab: jmp    5af <trace_ret_do_init_module+0x5af> */
	X86_SIM_X86_JMP(0x5ab, 0x5af, x86_l_5af);
x86_l_5ad:
	/* 0x5ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5af:
	/* 0x5af: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5b4:
	/* 0x5b4: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5b7:
	/* 0x5b7: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_5bb:
	/* 0x5bb: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5be:
	/* 0x5be: jns    5c5 <trace_ret_do_init_module+0x5c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5be, 0x5c5, x86_l_5c5);
x86_l_5c0:
	/* 0x5c0: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c3:
	/* 0x5c3: jmp    5c7 <trace_ret_do_init_module+0x5c7> */
	X86_SIM_X86_JMP(0x5c3, 0x5c7, x86_l_5c7);
x86_l_5c5:
	/* 0x5c5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5c7:
	/* 0x5c7: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5cc:
	/* 0x5cc: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_5d0:
	/* 0x5d0: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_5d4:
	/* 0x5d4: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_5d7:
	/* 0x5d7: jns    5df <trace_ret_do_init_module+0x5df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5d7, 0x5df, x86_l_5df);
x86_l_5d9:
	/* 0x5d9: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5dd:
	/* 0x5dd: jmp    5e1 <trace_ret_do_init_module+0x5e1> */
	X86_SIM_X86_JMP(0x5dd, 0x5e1, x86_l_5e1);
x86_l_5df:
	/* 0x5df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5e1:
	/* 0x5e1: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5e6:
	/* 0x5e6: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_5ea:
	/* 0x5ea: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5ed:
	/* 0x5ed: jns    5f9 <trace_ret_do_init_module+0x5f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5ed, 0x5f9, x86_l_5f9);
x86_l_5ef:
	/* 0x5ef: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5f1:
	/* 0x5f1: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_5f3:
	/* 0x5f3: je     5f9 <trace_ret_do_init_module+0x5f9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f3, 0x5f9, x86_l_5f9);
x86_l_5f5:
	/* 0x5f5: or     BYTE PTR [rcx+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_5f9:
	/* 0x5f9: lea    rdi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_5fd:
	/* 0x5fd: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_605:
	/* 0x605: mov    QWORD PTR [rcx+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_60d:
	/* 0x60d: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_612:
	/* 0x612: call   617 <trace_ret_do_init_module+0x617> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_617:
	/* 0x617: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_61a:
	/* 0x61a: jns    622 <trace_ret_do_init_module+0x622> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x61a, 0x622, x86_l_622);
x86_l_61c:
	/* 0x61c: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_620:
	/* 0x620: jmp    624 <trace_ret_do_init_module+0x624> */
	X86_SIM_X86_JMP(0x620, 0x624, x86_l_624);
x86_l_622:
	/* 0x622: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_624:
	/* 0x624: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_629:
	/* 0x629: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62c:
	/* 0x62c: jns    633 <trace_ret_do_init_module+0x633> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x62c, 0x633, x86_l_633);
x86_l_62e:
	/* 0x62e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_631:
	/* 0x631: jmp    635 <trace_ret_do_init_module+0x635> */
	X86_SIM_X86_JMP(0x631, 0x635, x86_l_635);
x86_l_633:
	/* 0x633: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_635:
	/* 0x635: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_638:
	/* 0x638: jns    685 <trace_ret_do_init_module+0x685> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x638, 0x685, x86_l_685);
x86_l_63a:
	/* 0x63a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_63d:
	/* 0x63d: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_642:
	/* 0x642: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_646:
	/* 0x646: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_64b:
	/* 0x64b: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_64f:
	/* 0x64f: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_654:
	/* 0x654: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_658:
	/* 0x658: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_65d:
	/* 0x65d: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_661:
	/* 0x661: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_666:
	/* 0x666: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_66a:
	/* 0x66a: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_66f:
	/* 0x66f: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_673:
	/* 0x673: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_678:
	/* 0x678: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_67c:
	/* 0x67c: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_681:
	/* 0x681: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_685:
	/* 0x685: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_68a:
	/* 0x68a: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_68e:
	/* 0x68e: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_693:
	/* 0x693: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_696:
	/* 0x696: jns    7b1 <trace_ret_do_init_module+0x7b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x696, 0x7b1, x86_l_7b1);
x86_l_69c:
	/* 0x69c: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_69f:
	/* 0x69f: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6a1:
	/* 0x6a1: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_6a3:
	/* 0x6a3: je     7c0 <trace_ret_do_init_module+0x7c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6a3, 0x7c0, x86_l_7c0);
x86_l_6a9:
	/* 0x6a9: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_6ad:
	/* 0x6ad: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b2:
	/* 0x6b2: mov    BYTE PTR [rdx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_6b5:
	/* 0x6b5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6b7:
	/* 0x6b7: je     7c0 <trace_ret_do_init_module+0x7c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b7, 0x7c0, x86_l_7c0);
x86_l_6bd:
	/* 0x6bd: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_6c1:
	/* 0x6c1: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6c6:
	/* 0x6c6: mov    BYTE PTR [rdx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_6c9:
	/* 0x6c9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6cb:
	/* 0x6cb: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6cb, 0x7aa, x86_l_7aa);
x86_l_6d1:
	/* 0x6d1: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_6d5:
	/* 0x6d5: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6da:
	/* 0x6da: mov    BYTE PTR [rdx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_6dd:
	/* 0x6dd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6df:
	/* 0x6df: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6df, 0x7aa, x86_l_7aa);
x86_l_6e5:
	/* 0x6e5: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_6e9:
	/* 0x6e9: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6ee:
	/* 0x6ee: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_6f1:
	/* 0x6f1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_6f3:
	/* 0x6f3: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6f3, 0x7aa, x86_l_7aa);
x86_l_6f9:
	/* 0x6f9: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_6fd:
	/* 0x6fd: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_702:
	/* 0x702: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_705:
	/* 0x705: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_707:
	/* 0x707: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x707, 0x7aa, x86_l_7aa);
x86_l_70d:
	/* 0x70d: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_711:
	/* 0x711: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_716:
	/* 0x716: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_719:
	/* 0x719: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_71b:
	/* 0x71b: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x71b, 0x7aa, x86_l_7aa);
x86_l_721:
	/* 0x721: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_725:
	/* 0x725: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_72a:
	/* 0x72a: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_72d:
	/* 0x72d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_72f:
	/* 0x72f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x72f, 0x7aa, x86_l_7aa);
x86_l_731:
	/* 0x731: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_735:
	/* 0x735: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_73a:
	/* 0x73a: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_73d:
	/* 0x73d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_73f:
	/* 0x73f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73f, 0x7aa, x86_l_7aa);
x86_l_741:
	/* 0x741: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_745:
	/* 0x745: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_74a:
	/* 0x74a: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_74d:
	/* 0x74d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_74f:
	/* 0x74f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x74f, 0x7aa, x86_l_7aa);
x86_l_751:
	/* 0x751: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_755:
	/* 0x755: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_75a:
	/* 0x75a: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_75d:
	/* 0x75d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_75f:
	/* 0x75f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x75f, 0x7aa, x86_l_7aa);
x86_l_761:
	/* 0x761: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_765:
	/* 0x765: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_76a:
	/* 0x76a: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_76d:
	/* 0x76d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_76f:
	/* 0x76f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76f, 0x7aa, x86_l_7aa);
x86_l_771:
	/* 0x771: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_775:
	/* 0x775: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_77a:
	/* 0x77a: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_77d:
	/* 0x77d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_77f:
	/* 0x77f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x77f, 0x7aa, x86_l_7aa);
x86_l_781:
	/* 0x781: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_785:
	/* 0x785: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_78a:
	/* 0x78a: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_78d:
	/* 0x78d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_78f:
	/* 0x78f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x78f, 0x7aa, x86_l_7aa);
x86_l_791:
	/* 0x791: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_795:
	/* 0x795: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_79a:
	/* 0x79a: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_79d:
	/* 0x79d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_79f:
	/* 0x79f: je     7aa <trace_ret_do_init_module+0x7aa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x79f, 0x7aa, x86_l_7aa);
x86_l_7a1:
	/* 0x7a1: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7a6:
	/* 0x7a6: mov    BYTE PTR [rax+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_7aa:
	/* 0x7aa: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_7af:
	/* 0x7af: jmp    7c0 <trace_ret_do_init_module+0x7c0> */
	X86_SIM_X86_JMP(0x7af, 0x7c0, x86_l_7c0);
x86_l_7b1:
	/* 0x7b1: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_7b9:
	/* 0x7b9: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7c0:
	/* 0x7c0: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7c5:
	/* 0x7c5: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_7cb:
	/* 0x7cb: je     2a6 <trace_ret_do_init_module+0x2a6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7cb, 0x2a6, x86_l_2a6);
x86_l_7d1:
	/* 0x7d1: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_7d6:
	/* 0x7d6: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_7dd:
	/* 0x7dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e0:
	/* 0x7e0: jns    7fa <trace_ret_do_init_module+0x7fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7e0, 0x7fa, x86_l_7fa);
x86_l_7e2:
	/* 0x7e2: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e5:
	/* 0x7e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7e8:
	/* 0x7e8: js     801 <trace_ret_do_init_module+0x801> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7e8, 0x801, x86_l_801);
x86_l_7ea:
	/* 0x7ea: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7ec:
	/* 0x7ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ef:
	/* 0x7ef: js     809 <trace_ret_do_init_module+0x809> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7ef, 0x809, x86_l_809);
x86_l_7f1:
	/* 0x7f1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7f3:
	/* 0x7f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f6:
	/* 0x7f6: js     811 <trace_ret_do_init_module+0x811> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7f6, 0x811, x86_l_811);
x86_l_7f8:
	/* 0x7f8: jmp    827 <trace_ret_do_init_module+0x827> */
	X86_SIM_X86_JMP(0x7f8, 0x827, x86_l_827);
x86_l_7fa:
	/* 0x7fa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7fc:
	/* 0x7fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7ff:
	/* 0x7ff: jns    7ea <trace_ret_do_init_module+0x7ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ff, 0x7ea, x86_l_7ea);
x86_l_801:
	/* 0x801: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_804:
	/* 0x804: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_807:
	/* 0x807: jns    7f1 <trace_ret_do_init_module+0x7f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x807, 0x7f1, x86_l_7f1);
x86_l_809:
	/* 0x809: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_80c:
	/* 0x80c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_80f:
	/* 0x80f: jns    827 <trace_ret_do_init_module+0x827> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x80f, 0x827, x86_l_827);
x86_l_811:
	/* 0x811: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_814:
	/* 0x814: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_817:
	/* 0x817: je     827 <trace_ret_do_init_module+0x827> */
	X86_SIM_X86_JCC(X86_CC_E, 0x817, 0x827, x86_l_827);
x86_l_819:
	/* 0x819: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_81d:
	/* 0x81d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_820:
	/* 0x820: jns    827 <trace_ret_do_init_module+0x827> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x820, 0x827, x86_l_827);
x86_l_822:
	/* 0x822: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_825:
	/* 0x825: jmp    829 <trace_ret_do_init_module+0x829> */
	X86_SIM_X86_JMP(0x825, 0x829, x86_l_829);
x86_l_827:
	/* 0x827: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_829:
	/* 0x829: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_82d:
	/* 0x82d: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_832:
	/* 0x832: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_836:
	/* 0x836: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_83a:
	/* 0x83a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_841:
	/* 0x841: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_846:
	/* 0x846: call   84b <trace_ret_do_init_module+0x84b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_84b:
	/* 0x84b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_84e:
	/* 0x84e: je     86b <trace_ret_do_init_module+0x86b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x84e, 0x86b, x86_l_86b);
x86_l_850:
	/* 0x850: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_853:
	/* 0x853: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_858:
	/* 0x858: mov    BYTE PTR [rcx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_85e:
	/* 0x85e: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_861:
	/* 0x861: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_864:
	/* 0x864: jne    86b <trace_ret_do_init_module+0x86b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x864, 0x86b, x86_l_86b);
x86_l_866:
	/* 0x866: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_86b:
	/* 0x86b: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_870:
	/* 0x870: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_876:
	/* 0x876: jne    2dbd <trace_ret_do_init_module+0x2dbd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x876, 0x2dbd, x86_l_2dbd);
x86_l_87c:
	/* 0x87c: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_887:
	/* 0x887: mov    DWORD PTR [rsp+0x40],0x310 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907728ULL);
x86_l_88f:
	/* 0x88f: mov    WORD PTR [rsp+0x34],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_894:
	/* 0x894: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_89b:
	/* 0x89b: lea    rsi,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_8a0:
	/* 0x8a0: call   8a5 <trace_ret_do_init_module+0x8a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8a5:
	/* 0x8a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a8:
	/* 0x8a8: je     913 <trace_ret_do_init_module+0x913> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a8, 0x913, x86_l_913);
x86_l_8aa:
	/* 0x8aa: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_8af:
	/* 0x8af: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8b2:
	/* 0x8b2: call   8b7 <trace_ret_do_init_module+0x8b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8b7:
	/* 0x8b7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ba:
	/* 0x8ba: je     913 <trace_ret_do_init_module+0x913> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ba, 0x913, x86_l_913);
x86_l_8bc:
	/* 0x8bc: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8c0:
	/* 0x8c0: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_8c7:
	/* 0x8c7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8ca:
	/* 0x8ca: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_8d1:
	/* 0x8d1: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8d5:
	/* 0x8d5: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8d9:
	/* 0x8d9: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_8e0:
	/* 0x8e0: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_8e7:
	/* 0x8e7: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8eb:
	/* 0x8eb: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_8f2:
	/* 0x8f2: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8f6:
	/* 0x8f6: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_8fd:
	/* 0x8fd: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_901:
	/* 0x901: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_908:
	/* 0x908: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_90c:
	/* 0x90c: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_913:
	/* 0x913: lea    rax,[r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_917:
	/* 0x917: mov    QWORD PTR [rsp+0xe0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_91f:
	/* 0x91f: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_926:
	/* 0x926: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_92d:
	/* 0x92d: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_931:
	/* 0x931: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_935:
	/* 0x935: jne    93e <trace_ret_do_init_module+0x93e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x935, 0x93e, x86_l_93e);
x86_l_937:
	/* 0x937: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_939:
	/* 0x939: jmp    11d4 <trace_ret_do_init_module+0x11d4> */
	X86_SIM_X86_JMP(0x939, 0x11d4, x86_l_11d4);
x86_l_93e:
	/* 0x93e: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_945:
	/* 0x945: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_948:
	/* 0x948: je     ae2 <trace_ret_do_init_module+0xae2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x948, 0xae2, x86_l_ae2);
x86_l_94e:
	/* 0x94e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_953:
	/* 0x953: movzx  ecx,BYTE PTR [rdx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_95a:
	/* 0x95a: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_95d:
	/* 0x95d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_95f:
	/* 0x95f: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_962:
	/* 0x962: sete   sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_966:
	/* 0x966: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_969:
	/* 0x969: neg    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_96c:
	/* 0x96c: xor    rsi,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_973:
	/* 0x973: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_976:
	/* 0x976: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_97d:
	/* 0x97d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_980:
	/* 0x980: je     9a1 <trace_ret_do_init_module+0x9a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x980, 0x9a1, x86_l_9a1);
x86_l_982:
	/* 0x982: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_984:
	/* 0x984: cmp    BYTE PTR [rdx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_98b:
	/* 0x98b: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_98e:
	/* 0x98e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_991:
	/* 0x991: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_994:
	/* 0x994: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_99b:
	/* 0x99b: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_99e:
	/* 0x99e: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9a1:
	/* 0x9a1: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_9a8:
	/* 0x9a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ab:
	/* 0x9ab: je     9c7 <trace_ret_do_init_module+0x9c7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ab, 0x9c7, x86_l_9c7);
x86_l_9ad:
	/* 0x9ad: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_9b1:
	/* 0x9b1: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9b4:
	/* 0x9b4: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_9b7:
	/* 0x9b7: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_9ba:
	/* 0x9ba: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_9c1:
	/* 0x9c1: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9c4:
	/* 0x9c4: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9c7:
	/* 0x9c7: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_9ce:
	/* 0x9ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9d1:
	/* 0x9d1: je     9f2 <trace_ret_do_init_module+0x9f2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d1, 0x9f2, x86_l_9f2);
x86_l_9d3:
	/* 0x9d3: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9d6:
	/* 0x9d6: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_9de:
	/* 0x9de: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_9e2:
	/* 0x9e2: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_9e5:
	/* 0x9e5: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_9ec:
	/* 0x9ec: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_9ef:
	/* 0x9ef: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_9f2:
	/* 0x9f2: movzx  r13d,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_9f7:
	/* 0x9f7: mov    r12,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_9fe:
	/* 0x9fe: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_a01:
	/* 0xa01: mov    WORD PTR [rsp+0x38],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_a07:
	/* 0xa07: je     b57 <trace_ret_do_init_module+0xb57> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa07, 0xb57, x86_l_b57);
x86_l_a0d:
	/* 0xa0d: mov    QWORD PTR [rsp+0xa0],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_a15:
	/* 0xa15: mov    rax,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_a1c:
	/* 0xa1c: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_a24:
	/* 0xa24: mov    rbx,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_a2b:
	/* 0xa2b: mov    rax,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_a32:
	/* 0xa32: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a37:
	/* 0xa37: mov    WORD PTR [rsp+0x40],r13w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a3d:
	/* 0xa3d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_a44:
	/* 0xa44: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a49:
	/* 0xa49: call   a4e <trace_ret_do_init_module+0xa4e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a4e:
	/* 0xa4e: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a51:
	/* 0xa51: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_a55:
	/* 0xa55: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a5a:
	/* 0xa5a: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a61:
	/* 0xa61: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a64:
	/* 0xa64: je     a84 <trace_ret_do_init_module+0xa84> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa64, 0xa84, x86_l_a84);
x86_l_a66:
	/* 0xa66: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a6b:
	/* 0xa6b: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a6e:
	/* 0xa6e: call   a73 <trace_ret_do_init_module+0xa73> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a73:
	/* 0xa73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a76:
	/* 0xa76: je     a84 <trace_ret_do_init_module+0xa84> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa76, 0xa84, x86_l_a84);
x86_l_a78:
	/* 0xa78: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a7b:
	/* 0xa7b: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a7f:
	/* 0xa7f: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a82:
	/* 0xa82: jmp    a87 <trace_ret_do_init_module+0xa87> */
	X86_SIM_X86_JMP(0xa82, 0xa87, x86_l_a87);
x86_l_a84:
	/* 0xa84: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a87:
	/* 0xa87: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a8c:
	/* 0xa8c: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a91:
	/* 0xa91: dec    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_a94:
	/* 0xa94: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a97:
	/* 0xa97: jb     aaf <trace_ret_do_init_module+0xaaf> */
	X86_SIM_X86_JCC(X86_CC_B, 0xa97, 0xaaf, x86_l_aaf);
x86_l_a99:
	/* 0xa99: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a9d:
	/* 0xa9d: je     aa4 <trace_ret_do_init_module+0xaa4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa9d, 0xaa4, x86_l_aa4);
x86_l_a9f:
	/* 0xa9f: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_aa2:
	/* 0xaa2: jbe    aaf <trace_ret_do_init_module+0xaaf> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xaa2, 0xaaf, x86_l_aaf);
x86_l_aa4:
	/* 0xaa4: and    rbp,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 192ULL);
x86_l_aac:
	/* 0xaac: or     r13,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_aaf:
	/* 0xaaf: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ab3:
	/* 0xab3: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ab8:
	/* 0xab8: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_abf:
	/* 0xabf: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ac2:
	/* 0xac2: je     b03 <trace_ret_do_init_module+0xb03> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac2, 0xb03, x86_l_b03);
x86_l_ac4:
	/* 0xac4: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ac9:
	/* 0xac9: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_acc:
	/* 0xacc: call   ad1 <trace_ret_do_init_module+0xad1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad1:
	/* 0xad1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ad4:
	/* 0xad4: je     b1c <trace_ret_do_init_module+0xb1c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad4, 0xb1c, x86_l_b1c);
x86_l_ad6:
	/* 0xad6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ad9:
	/* 0xad9: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_add:
	/* 0xadd: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ae0:
	/* 0xae0: jmp    b1e <trace_ret_do_init_module+0xb1e> */
	X86_SIM_X86_JMP(0xae0, 0xb1e, x86_l_b1e);
x86_l_ae2:
	/* 0xae2: mov    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ae9:
	/* 0xae9: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_aee:
	/* 0xaee: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_af5:
	/* 0xaf5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af8:
	/* 0xaf8: jne    982 <trace_ret_do_init_module+0x982> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaf8, 0x982, x86_l_982);
x86_l_afe:
	/* 0xafe: jmp    9a1 <trace_ret_do_init_module+0x9a1> */
	X86_SIM_X86_JMP(0xafe, 0x9a1, x86_l_9a1);
x86_l_b03:
	/* 0xb03: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b05:
	/* 0xb05: mov    rsi,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_b0d:
	/* 0xb0d: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b10:
	/* 0xb10: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b15:
	/* 0xb15: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b18:
	/* 0xb18: jae    b38 <trace_ret_do_init_module+0xb38> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xb18, 0xb38, x86_l_b38);
x86_l_b1a:
	/* 0xb1a: jmp    b4e <trace_ret_do_init_module+0xb4e> */
	X86_SIM_X86_JMP(0xb1a, 0xb4e, x86_l_b4e);
x86_l_b1c:
	/* 0xb1c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b1e:
	/* 0xb1e: mov    rsi,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_b26:
	/* 0xb26: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b2b:
	/* 0xb2b: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b2e:
	/* 0xb2e: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b33:
	/* 0xb33: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b36:
	/* 0xb36: jb     b4e <trace_ret_do_init_module+0xb4e> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb36, 0xb4e, x86_l_b4e);
x86_l_b38:
	/* 0xb38: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b3c:
	/* 0xb3c: je     b43 <trace_ret_do_init_module+0xb43> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb3c, 0xb43, x86_l_b43);
x86_l_b3e:
	/* 0xb3e: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b41:
	/* 0xb41: jbe    b4e <trace_ret_do_init_module+0xb4e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xb41, 0xb4e, x86_l_b4e);
x86_l_b43:
	/* 0xb43: and    rbp,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 192ULL);
x86_l_b4b:
	/* 0xb4b: or     rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b4e:
	/* 0xb4e: or     r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b51:
	/* 0xb51: or     r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b54:
	/* 0xb54: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b57:
	/* 0xb57: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_b5f:
	/* 0xb5f: je     bf9 <trace_ret_do_init_module+0xbf9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5f, 0xbf9, x86_l_bf9);
x86_l_b65:
	/* 0xb65: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_b68:
	/* 0xb68: call   b6d <trace_ret_do_init_module+0xb6d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_b6d:
	/* 0xb6d: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b71:
	/* 0xb71: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_b78:
	/* 0xb78: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_b7f:
	/* 0xb7f: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b84:
	/* 0xb84: mov    r13,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_b8b:
	/* 0xb8b: mov    r12,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_b92:
	/* 0xb92: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_b97:
	/* 0xb97: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b9c:
	/* 0xb9c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_ba3:
	/* 0xba3: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ba8:
	/* 0xba8: call   bad <trace_ret_do_init_module+0xbad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bad:
	/* 0xbad: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bb1:
	/* 0xbb1: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bb6:
	/* 0xbb6: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bbd:
	/* 0xbbd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bc0:
	/* 0xbc0: je     be0 <trace_ret_do_init_module+0xbe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc0, 0xbe0, x86_l_be0);
x86_l_bc2:
	/* 0xbc2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bc7:
	/* 0xbc7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bca:
	/* 0xbca: call   bcf <trace_ret_do_init_module+0xbcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bcf:
	/* 0xbcf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd2:
	/* 0xbd2: je     be0 <trace_ret_do_init_module+0xbe0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd2, 0xbe0, x86_l_be0);
x86_l_bd4:
	/* 0xbd4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd7:
	/* 0xbd7: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bdb:
	/* 0xbdb: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bde:
	/* 0xbde: jmp    be2 <trace_ret_do_init_module+0xbe2> */
	X86_SIM_X86_JMP(0xbde, 0xbe2, x86_l_be2);
x86_l_be0:
	/* 0xbe0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_be2:
	/* 0xbe2: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_be5:
	/* 0xbe5: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_bea:
	/* 0xbea: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_bed:
	/* 0xbed: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bf0:
	/* 0xbf0: jae    c0d <trace_ret_do_init_module+0xc0d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xbf0, 0xc0d, x86_l_c0d);
x86_l_bf2:
	/* 0xbf2: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bf7:
	/* 0xbf7: jmp    c25 <trace_ret_do_init_module+0xc25> */
	X86_SIM_X86_JMP(0xbf7, 0xc25, x86_l_c25);
x86_l_bf9:
	/* 0xbf9: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bfe:
	/* 0xbfe: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_c06:
	/* 0xc06: jne    c3c <trace_ret_do_init_module+0xc3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc06, 0xc3c, x86_l_c3c);
x86_l_c08:
	/* 0xc08: jmp    ce2 <trace_ret_do_init_module+0xce2> */
	X86_SIM_X86_JMP(0xc08, 0xce2, x86_l_ce2);
x86_l_c0d:
	/* 0xc0d: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c11:
	/* 0xc11: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c16:
	/* 0xc16: je     c1d <trace_ret_do_init_module+0xc1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc16, 0xc1d, x86_l_c1d);
x86_l_c18:
	/* 0xc18: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c1b:
	/* 0xc1b: jbe    c25 <trace_ret_do_init_module+0xc25> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xc1b, 0xc25, x86_l_c25);
x86_l_c1d:
	/* 0xc1d: and    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 24ULL);
x86_l_c22:
	/* 0xc22: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c25:
	/* 0xc25: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c28:
	/* 0xc28: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_c2b:
	/* 0xc2b: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c2e:
	/* 0xc2e: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_c36:
	/* 0xc36: je     ce2 <trace_ret_do_init_module+0xce2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc36, 0xce2, x86_l_ce2);
x86_l_c3c:
	/* 0xc3c: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_c41:
	/* 0xc41: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_c48:
	/* 0xc48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c4b:
	/* 0xc4b: jns    c52 <trace_ret_do_init_module+0xc52> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc4b, 0xc52, x86_l_c52);
x86_l_c4d:
	/* 0xc4d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c50:
	/* 0xc50: jmp    c54 <trace_ret_do_init_module+0xc54> */
	X86_SIM_X86_JMP(0xc50, 0xc54, x86_l_c54);
x86_l_c52:
	/* 0xc52: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c54:
	/* 0xc54: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_c58:
	/* 0xc58: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c5a:
	/* 0xc5a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c5d:
	/* 0xc5d: jns    c6c <trace_ret_do_init_module+0xc6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc5d, 0xc6c, x86_l_c6c);
x86_l_c5f:
	/* 0xc5f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c62:
	/* 0xc62: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c65:
	/* 0xc65: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c68:
	/* 0xc68: js     c76 <trace_ret_do_init_module+0xc76> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc68, 0xc76, x86_l_c76);
x86_l_c6a:
	/* 0xc6a: jmp    c78 <trace_ret_do_init_module+0xc78> */
	X86_SIM_X86_JMP(0xc6a, 0xc78, x86_l_c78);
x86_l_c6c:
	/* 0xc6c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c6e:
	/* 0xc6e: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_c71:
	/* 0xc71: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c74:
	/* 0xc74: jns    c78 <trace_ret_do_init_module+0xc78> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc74, 0xc78, x86_l_c78);
x86_l_c76:
	/* 0xc76: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c78:
	/* 0xc78: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_c7c:
	/* 0xc7c: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_c83:
	/* 0xc83: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_c8a:
	/* 0xc8a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c8d:
	/* 0xc8d: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_c92:
	/* 0xc92: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c97:
	/* 0xc97: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_c9e:
	/* 0xc9e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ca3:
	/* 0xca3: call   ca8 <trace_ret_do_init_module+0xca8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ca8:
	/* 0xca8: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_caf:
	/* 0xcaf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cb2:
	/* 0xcb2: je     cd1 <trace_ret_do_init_module+0xcd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcb2, 0xcd1, x86_l_cd1);
x86_l_cb4:
	/* 0xcb4: lea    rsi,[r13+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_cb8:
	/* 0xcb8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cbb:
	/* 0xcbb: call   cc0 <trace_ret_do_init_module+0xcc0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_cc0:
	/* 0xcc0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cc3:
	/* 0xcc3: je     cd1 <trace_ret_do_init_module+0xcd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcc3, 0xcd1, x86_l_cd1);
x86_l_cc5:
	/* 0xcc5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc8:
	/* 0xcc8: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ccc:
	/* 0xccc: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ccf:
	/* 0xccf: jmp    cd3 <trace_ret_do_init_module+0xcd3> */
	X86_SIM_X86_JMP(0xccf, 0xcd3, x86_l_cd3);
x86_l_cd1:
	/* 0xcd1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cd3:
	/* 0xcd3: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cd6:
	/* 0xcd6: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cd9:
	/* 0xcd9: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cdc:
	/* 0xcdc: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_cdf:
	/* 0xcdf: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ce2:
	/* 0xce2: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_cea:
	/* 0xcea: je     dae <trace_ret_do_init_module+0xdae> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcea, 0xdae, x86_l_dae);
x86_l_cf0:
	/* 0xcf0: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_cf7:
	/* 0xcf7: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_cfb:
	/* 0xcfb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cfd:
	/* 0xcfd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d00:
	/* 0xd00: jns    d0f <trace_ret_do_init_module+0xd0f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd00, 0xd0f, x86_l_d0f);
x86_l_d02:
	/* 0xd02: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d05:
	/* 0xd05: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d08:
	/* 0xd08: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d0b:
	/* 0xd0b: js     d19 <trace_ret_do_init_module+0xd19> */
	X86_SIM_X86_JCC(X86_CC_S, 0xd0b, 0xd19, x86_l_d19);
x86_l_d0d:
	/* 0xd0d: jmp    d1b <trace_ret_do_init_module+0xd1b> */
	X86_SIM_X86_JMP(0xd0d, 0xd1b, x86_l_d1b);
x86_l_d0f:
	/* 0xd0f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d11:
	/* 0xd11: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d14:
	/* 0xd14: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d17:
	/* 0xd17: jns    d1b <trace_ret_do_init_module+0xd1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd17, 0xd1b, x86_l_d1b);
x86_l_d19:
	/* 0xd19: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d1b:
	/* 0xd1b: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d1d:
	/* 0xd1d: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_d21:
	/* 0xd21: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d24:
	/* 0xd24: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_d28:
	/* 0xd28: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d2a:
	/* 0xd2a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d2d:
	/* 0xd2d: jns    d34 <trace_ret_do_init_module+0xd34> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd2d, 0xd34, x86_l_d34);
x86_l_d2f:
	/* 0xd2f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d32:
	/* 0xd32: jmp    d36 <trace_ret_do_init_module+0xd36> */
	X86_SIM_X86_JMP(0xd32, 0xd36, x86_l_d36);
x86_l_d34:
	/* 0xd34: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d36:
	/* 0xd36: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_d39:
	/* 0xd39: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_d3d:
	/* 0xd3d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d40:
	/* 0xd40: jns    d44 <trace_ret_do_init_module+0xd44> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd40, 0xd44, x86_l_d44);
x86_l_d42:
	/* 0xd42: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d44:
	/* 0xd44: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d48:
	/* 0xd48: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_d4f:
	/* 0xd4f: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_d56:
	/* 0xd56: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_d59:
	/* 0xd59: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_d5e:
	/* 0xd5e: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d63:
	/* 0xd63: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_d6a:
	/* 0xd6a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d6f:
	/* 0xd6f: call   d74 <trace_ret_do_init_module+0xd74> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d74:
	/* 0xd74: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_d7b:
	/* 0xd7b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d7e:
	/* 0xd7e: je     d9d <trace_ret_do_init_module+0xd9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7e, 0xd9d, x86_l_d9d);
x86_l_d80:
	/* 0xd80: lea    rsi,[r13+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_d84:
	/* 0xd84: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d87:
	/* 0xd87: call   d8c <trace_ret_do_init_module+0xd8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d8c:
	/* 0xd8c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d8f:
	/* 0xd8f: je     d9d <trace_ret_do_init_module+0xd9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd8f, 0xd9d, x86_l_d9d);
x86_l_d91:
	/* 0xd91: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d94:
	/* 0xd94: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d98:
	/* 0xd98: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_d9b:
	/* 0xd9b: jmp    d9f <trace_ret_do_init_module+0xd9f> */
	X86_SIM_X86_JMP(0xd9b, 0xd9f, x86_l_d9f);
x86_l_d9d:
	/* 0xd9d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d9f:
	/* 0xd9f: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_da2:
	/* 0xda2: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_da5:
	/* 0xda5: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_da8:
	/* 0xda8: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_dab:
	/* 0xdab: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_dae:
	/* 0xdae: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_db6:
	/* 0xdb6: je     f9f <trace_ret_do_init_module+0xf9f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdb6, 0xf9f, x86_l_f9f);
x86_l_dbc:
	/* 0xdbc: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_dc1:
	/* 0xdc1: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_dc8:
	/* 0xdc8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dcb:
	/* 0xdcb: jns    de1 <trace_ret_do_init_module+0xde1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdcb, 0xde1, x86_l_de1);
x86_l_dcd:
	/* 0xdcd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dd0:
	/* 0xdd0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd3:
	/* 0xdd3: js     de8 <trace_ret_do_init_module+0xde8> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdd3, 0xde8, x86_l_de8);
x86_l_dd5:
	/* 0xdd5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd7:
	/* 0xdd7: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_dda:
	/* 0xdda: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ddd:
	/* 0xddd: js     df3 <trace_ret_do_init_module+0xdf3> */
	X86_SIM_X86_JCC(X86_CC_S, 0xddd, 0xdf3, x86_l_df3);
x86_l_ddf:
	/* 0xddf: jmp    e3e <trace_ret_do_init_module+0xe3e> */
	X86_SIM_X86_JMP(0xddf, 0xe3e, x86_l_e3e);
x86_l_de1:
	/* 0xde1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_de3:
	/* 0xde3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_de6:
	/* 0xde6: jns    dd5 <trace_ret_do_init_module+0xdd5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde6, 0xdd5, x86_l_dd5);
x86_l_de8:
	/* 0xde8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_deb:
	/* 0xdeb: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_dee:
	/* 0xdee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_df1:
	/* 0xdf1: jns    e3e <trace_ret_do_init_module+0xe3e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdf1, 0xe3e, x86_l_e3e);
x86_l_df3:
	/* 0xdf3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_df6:
	/* 0xdf6: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_dfb:
	/* 0xdfb: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dff:
	/* 0xdff: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_e04:
	/* 0xe04: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e08:
	/* 0xe08: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_e0d:
	/* 0xe0d: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e11:
	/* 0xe11: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_e16:
	/* 0xe16: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e1a:
	/* 0xe1a: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_e1f:
	/* 0xe1f: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_e23:
	/* 0xe23: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_e28:
	/* 0xe28: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e2c:
	/* 0xe2c: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_e31:
	/* 0xe31: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_e35:
	/* 0xe35: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_e3a:
	/* 0xe3a: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_e3e:
	/* 0xe3e: lea    r15,[r13+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_e42:
	/* 0xe42: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e47:
	/* 0xe47: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4a:
	/* 0xe4a: jns    f26 <trace_ret_do_init_module+0xf26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe4a, 0xf26, x86_l_f26);
x86_l_e50:
	/* 0xe50: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_e53:
	/* 0xe53: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e56:
	/* 0xe56: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e58:
	/* 0xe58: movzx  edx,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_e5d:
	/* 0xe5d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe5d, 0xf3a, x86_l_f3a);
x86_l_e63:
	/* 0xe63: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_e67:
	/* 0xe67: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_e6b:
	/* 0xe6b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e6d:
	/* 0xe6d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe6d, 0xf3a, x86_l_f3a);
x86_l_e73:
	/* 0xe73: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_e77:
	/* 0xe77: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_e7b:
	/* 0xe7b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e7d:
	/* 0xe7d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe7d, 0xf3a, x86_l_f3a);
x86_l_e83:
	/* 0xe83: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_e87:
	/* 0xe87: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_e8b:
	/* 0xe8b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e8d:
	/* 0xe8d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8d, 0xf3a, x86_l_f3a);
x86_l_e93:
	/* 0xe93: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_e97:
	/* 0xe97: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_e9b:
	/* 0xe9b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_e9d:
	/* 0xe9d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe9d, 0xf3a, x86_l_f3a);
x86_l_ea3:
	/* 0xea3: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_ea7:
	/* 0xea7: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_eab:
	/* 0xeab: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ead:
	/* 0xead: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xead, 0xf3a, x86_l_f3a);
x86_l_eb3:
	/* 0xeb3: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_eb7:
	/* 0xeb7: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_ebb:
	/* 0xebb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ebd:
	/* 0xebd: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xebd, 0xf3a, x86_l_f3a);
x86_l_ebf:
	/* 0xebf: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_ec3:
	/* 0xec3: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_ec7:
	/* 0xec7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ec9:
	/* 0xec9: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec9, 0xf3a, x86_l_f3a);
x86_l_ecb:
	/* 0xecb: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_ecf:
	/* 0xecf: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_ed3:
	/* 0xed3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ed5:
	/* 0xed5: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed5, 0xf3a, x86_l_f3a);
x86_l_ed7:
	/* 0xed7: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_edb:
	/* 0xedb: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_edf:
	/* 0xedf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ee1:
	/* 0xee1: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xee1, 0xf3a, x86_l_f3a);
x86_l_ee3:
	/* 0xee3: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_ee7:
	/* 0xee7: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_eeb:
	/* 0xeeb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_eed:
	/* 0xeed: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xeed, 0xf3a, x86_l_f3a);
x86_l_eef:
	/* 0xeef: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_ef3:
	/* 0xef3: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_ef7:
	/* 0xef7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_ef9:
	/* 0xef9: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xef9, 0xf3a, x86_l_f3a);
x86_l_efb:
	/* 0xefb: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_eff:
	/* 0xeff: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_f03:
	/* 0xf03: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_f05:
	/* 0xf05: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf05, 0xf3a, x86_l_f3a);
x86_l_f07:
	/* 0xf07: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_f0b:
	/* 0xf0b: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_f0f:
	/* 0xf0f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_f11:
	/* 0xf11: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf11, 0xf3a, x86_l_f3a);
x86_l_f13:
	/* 0xf13: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_f17:
	/* 0xf17: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_f1b:
	/* 0xf1b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_f1d:
	/* 0xf1d: je     f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf1d, 0xf3a, x86_l_f3a);
x86_l_f1f:
	/* 0xf1f: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_f24:
	/* 0xf24: jmp    f3a <trace_ret_do_init_module+0xf3a> */
	X86_SIM_X86_JMP(0xf24, 0xf3a, x86_l_f3a);
x86_l_f26:
	/* 0xf26: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_f2e:
	/* 0xf2e: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f35:
	/* 0xf35: movzx  edx,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_f3a:
	/* 0xf3a: mov    rbx,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_f41:
	/* 0xf41: mov    r12,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_f48:
	/* 0xf48: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f4b:
	/* 0xf4b: mov    WORD PTR [rsp+0x40],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f50:
	/* 0xf50: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_f57:
	/* 0xf57: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f5c:
	/* 0xf5c: call   f61 <trace_ret_do_init_module+0xf61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f61:
	/* 0xf61: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_f68:
	/* 0xf68: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f6b:
	/* 0xf6b: je     f89 <trace_ret_do_init_module+0xf89> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf6b, 0xf89, x86_l_f89);
x86_l_f6d:
	/* 0xf6d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f70:
	/* 0xf70: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_f73:
	/* 0xf73: call   f78 <trace_ret_do_init_module+0xf78> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f78:
	/* 0xf78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f7b:
	/* 0xf7b: je     f89 <trace_ret_do_init_module+0xf89> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf7b, 0xf89, x86_l_f89);
x86_l_f7d:
	/* 0xf7d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f80:
	/* 0xf80: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f84:
	/* 0xf84: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f87:
	/* 0xf87: jmp    f8b <trace_ret_do_init_module+0xf8b> */
	X86_SIM_X86_JMP(0xf87, 0xf8b, x86_l_f8b);
x86_l_f89:
	/* 0xf89: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f8b:
	/* 0xf8b: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f8e:
	/* 0xf8e: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f91:
	/* 0xf91: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f94:
	/* 0xf94: or     r13,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_f97:
	/* 0xf97: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f9a:
	/* 0xf9a: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f9f:
	/* 0xf9f: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_fa7:
	/* 0xfa7: je     1022 <trace_ret_do_init_module+0x1022> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfa7, 0x1022, x86_l_1022);
x86_l_fa9:
	/* 0xfa9: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_fac:
	/* 0xfac: lea    r15,[r13+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_fb0:
	/* 0xfb0: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fb3:
	/* 0xfb3: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_fb8:
	/* 0xfb8: call   fbd <trace_ret_do_init_module+0xfbd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_fbd:
	/* 0xfbd: mov    rbx,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_fc4:
	/* 0xfc4: mov    r12,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_fcb:
	/* 0xfcb: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fce:
	/* 0xfce: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_fd3:
	/* 0xfd3: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fd8:
	/* 0xfd8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_fdf:
	/* 0xfdf: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fe4:
	/* 0xfe4: call   fe9 <trace_ret_do_init_module+0xfe9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fe9:
	/* 0xfe9: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ff0:
	/* 0xff0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ff3:
	/* 0xff3: je     1011 <trace_ret_do_init_module+0x1011> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff3, 0x1011, x86_l_1011);
x86_l_ff5:
	/* 0xff5: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ff8:
	/* 0xff8: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ffb:
	/* 0xffb: call   1000 <trace_ret_do_init_module+0x1000> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1000:
	/* 0x1000: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1003:
	/* 0x1003: je     1011 <trace_ret_do_init_module+0x1011> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1003, 0x1011, x86_l_1011);
x86_l_1005:
	/* 0x1005: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1008:
	/* 0x1008: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_100c:
	/* 0x100c: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_100f:
	/* 0x100f: jmp    1013 <trace_ret_do_init_module+0x1013> */
	X86_SIM_X86_JMP(0x100f, 0x1013, x86_l_1013);
x86_l_1011:
	/* 0x1011: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1013:
	/* 0x1013: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1016:
	/* 0x1016: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1019:
	/* 0x1019: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_101c:
	/* 0x101c: or     r13,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_101f:
	/* 0x101f: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1022:
	/* 0x1022: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1029:
	/* 0x1029: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_102c:
	/* 0x102c: je     1099 <trace_ret_do_init_module+0x1099> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102c, 0x1099, x86_l_1099);
x86_l_102e:
	/* 0x102e: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1031:
	/* 0x1031: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1035:
	/* 0x1035: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1039:
	/* 0x1039: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1040:
	/* 0x1040: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1043:
	/* 0x1043: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_1048:
	/* 0x1048: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_104d:
	/* 0x104d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_1054:
	/* 0x1054: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1059:
	/* 0x1059: call   105e <trace_ret_do_init_module+0x105e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_105e:
	/* 0x105e: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1065:
	/* 0x1065: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1068:
	/* 0x1068: je     1088 <trace_ret_do_init_module+0x1088> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1068, 0x1088, x86_l_1088);
x86_l_106a:
	/* 0x106a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_106f:
	/* 0x106f: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1072:
	/* 0x1072: call   1077 <trace_ret_do_init_module+0x1077> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1077:
	/* 0x1077: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_107a:
	/* 0x107a: je     1088 <trace_ret_do_init_module+0x1088> */
	X86_SIM_X86_JCC(X86_CC_E, 0x107a, 0x1088, x86_l_1088);
x86_l_107c:
	/* 0x107c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_107f:
	/* 0x107f: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1083:
	/* 0x1083: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1086:
	/* 0x1086: jmp    108a <trace_ret_do_init_module+0x108a> */
	X86_SIM_X86_JMP(0x1086, 0x108a, x86_l_108a);
x86_l_1088:
	/* 0x1088: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108a:
	/* 0x108a: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_108d:
	/* 0x108d: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1090:
	/* 0x1090: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1093:
	/* 0x1093: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1096:
	/* 0x1096: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1099:
	/* 0x1099: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_10a0:
	/* 0x10a0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10a3:
	/* 0x10a3: je     110b <trace_ret_do_init_module+0x110b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10a3, 0x110b, x86_l_110b);
x86_l_10a5:
	/* 0x10a5: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10a8:
	/* 0x10a8: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_10af:
	/* 0x10af: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_10b2:
	/* 0x10b2: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_10b7:
	/* 0x10b7: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_10bc:
	/* 0x10bc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_10c3:
	/* 0x10c3: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_10c8:
	/* 0x10c8: call   10cd <trace_ret_do_init_module+0x10cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10cd:
	/* 0x10cd: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_10d4:
	/* 0x10d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10d7:
	/* 0x10d7: je     10fa <trace_ret_do_init_module+0x10fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10d7, 0x10fa, x86_l_10fa);
x86_l_10d9:
	/* 0x10d9: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10dc:
	/* 0x10dc: mov    rsi,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_10e4:
	/* 0x10e4: call   10e9 <trace_ret_do_init_module+0x10e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10e9:
	/* 0x10e9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10ec:
	/* 0x10ec: je     10fa <trace_ret_do_init_module+0x10fa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10ec, 0x10fa, x86_l_10fa);
x86_l_10ee:
	/* 0x10ee: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10f1:
	/* 0x10f1: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10f5:
	/* 0x10f5: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_10f8:
	/* 0x10f8: jmp    10fc <trace_ret_do_init_module+0x10fc> */
	X86_SIM_X86_JMP(0x10f8, 0x10fc, x86_l_10fc);
x86_l_10fa:
	/* 0x10fa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10fc:
	/* 0x10fc: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_10ff:
	/* 0x10ff: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1102:
	/* 0x1102: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1105:
	/* 0x1105: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1108:
	/* 0x1108: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_110b:
	/* 0x110b: mov    rbx,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_1112:
	/* 0x1112: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1115:
	/* 0x1115: movzx  eax,WORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 56ULL);
x86_l_111a:
	/* 0x111a: je     11a1 <trace_ret_do_init_module+0x11a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x111a, 0x11a1, x86_l_11a1);
x86_l_1120:
	/* 0x1120: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1123:
	/* 0x1123: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_112a:
	/* 0x112a: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_112d:
	/* 0x112d: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1132:
	/* 0x1132: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_1139:
	/* 0x1139: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_113e:
	/* 0x113e: call   1143 <trace_ret_do_init_module+0x1143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1143:
	/* 0x1143: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_114a:
	/* 0x114a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_114d:
	/* 0x114d: je     1190 <trace_ret_do_init_module+0x1190> */
	X86_SIM_X86_JCC(X86_CC_E, 0x114d, 0x1190, x86_l_1190);
x86_l_114f:
	/* 0x114f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1152:
	/* 0x1152: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_115a:
	/* 0x115a: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_115e:
	/* 0x115e: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1161:
	/* 0x1161: call   1166 <trace_ret_do_init_module+0x1166> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1166:
	/* 0x1166: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1169:
	/* 0x1169: jne    1184 <trace_ret_do_init_module+0x1184> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1169, 0x1184, x86_l_1184);
x86_l_116b:
	/* 0x116b: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1173:
	/* 0x1173: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1177:
	/* 0x1177: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_117a:
	/* 0x117a: call   117f <trace_ret_do_init_module+0x117f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_117f:
	/* 0x117f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1182:
	/* 0x1182: je     1190 <trace_ret_do_init_module+0x1190> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1182, 0x1190, x86_l_1190);
x86_l_1184:
	/* 0x1184: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1187:
	/* 0x1187: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_118b:
	/* 0x118b: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_118e:
	/* 0x118e: jmp    1192 <trace_ret_do_init_module+0x1192> */
	X86_SIM_X86_JMP(0x118e, 0x1192, x86_l_1192);
x86_l_1190:
	/* 0x1190: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1192:
	/* 0x1192: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1195:
	/* 0x1195: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1198:
	/* 0x1198: or     r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_119b:
	/* 0x119b: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_119e:
	/* 0x119e: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_11a1:
	/* 0x11a1: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_11a8:
	/* 0x11a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11ab:
	/* 0x11ab: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_11b0:
	/* 0x11b0: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11b5:
	/* 0x11b5: je     11c6 <trace_ret_do_init_module+0x11c6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11b5, 0x11c6, x86_l_11c6);
x86_l_11b7:
	/* 0x11b7: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_11bf:
	/* 0x11bf: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_11c3:
	/* 0x11c3: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_11c6:
	/* 0x11c6: and    rsi,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_11cd:
	/* 0x11cd: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_11d4:
	/* 0x11d4: lea    rbx,[r13+0x7d8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_11db:
	/* 0x11db: lea    rcx,[r13+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11df:
	/* 0x11df: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_11e4:
	/* 0x11e4: and    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_11e7:
	/* 0x11e7: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_11ee:
	/* 0x11ee: je     1b5d <trace_ret_do_init_module+0x1b5d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11ee, 0x1b5d, x86_l_1b5d);
x86_l_11f4:
	/* 0x11f4: mov    DWORD PTR [rsp+0x34],0x40000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 224412041216ULL);
x86_l_11fc:
	/* 0x11fc: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_1206:
	/* 0x1206: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_120e:
	/* 0x120e: mov    QWORD PTR [rbx+0x38],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244813135871ULL);
x86_l_1216:
	/* 0x1216: mov    QWORD PTR [rbx+0x30],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 210453397503ULL);
x86_l_121e:
	/* 0x121e: mov    QWORD PTR [rbx+0x28],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176093659135ULL);
x86_l_1226:
	/* 0x1226: mov    QWORD PTR [rbx+0x20],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 141733920767ULL);
x86_l_122e:
	/* 0x122e: mov    QWORD PTR [rbx+0x18],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 107374182399ULL);
x86_l_1236:
	/* 0x1236: mov    QWORD PTR [rbx+0x10],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 73014444031ULL);
x86_l_123e:
	/* 0x123e: mov    QWORD PTR [rbx+0x8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_1246:
	/* 0x1246: mov    QWORD PTR [rbx],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4294967295ULL);
x86_l_124d:
	/* 0x124d: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1255:
	/* 0x1255: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_125a:
	/* 0x125a: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_125e:
	/* 0x125e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1261:
	/* 0x1261: jns    127c <trace_ret_do_init_module+0x127c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1261, 0x127c, x86_l_127c);
x86_l_1263:
	/* 0x1263: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1266:
	/* 0x1266: movzx  r12d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_126e:
	/* 0x126e: cmp    r12,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 32000ULL);
x86_l_1275:
	/* 0x1275: jb     1294 <trace_ret_do_init_module+0x1294> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1275, 0x1294, x86_l_1294);
x86_l_1277:
	/* 0x1277: jmp    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JMP(0x1277, 0x1451, x86_l_1451);
x86_l_127c:
	/* 0x127c: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_127f:
	/* 0x127f: movzx  r12d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1287:
	/* 0x1287: cmp    r12,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 32000ULL);
x86_l_128e:
	/* 0x128e: jae    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x128e, 0x1451, x86_l_1451);
x86_l_1294:
	/* 0x1294: mov    BYTE PTR [r14+r12*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R12, 0), 588410519552ULL);
x86_l_129d:
	/* 0x129d: cmp    r12d,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_12a4:
	/* 0x12a4: jbe    12c8 <trace_ret_do_init_module+0x12c8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x12a4, 0x12c8, x86_l_12c8);
x86_l_12a6:
	/* 0x12a6: movzx  r12d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_12ae:
	/* 0x12ae: mov    DWORD PTR [rsp+0x40],0x38 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907000ULL);
x86_l_12b6:
	/* 0x12b6: movzx  r12d,r12w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_12ba:
	/* 0x12ba: cmp    r12d,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 27899ULL);
x86_l_12c1:
	/* 0x12c1: jbe    132e <trace_ret_do_init_module+0x132e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x12c1, 0x132e, x86_l_132e);
x86_l_12c3:
	/* 0x12c3: jmp    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JMP(0x12c3, 0x1451, x86_l_1451);
x86_l_12c8:
	/* 0x12c8: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_12cc:
	/* 0x12cc: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_12d3:
	/* 0x12d3: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12d8:
	/* 0x12d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12db:
	/* 0x12db: jns    12ee <trace_ret_do_init_module+0x12ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12db, 0x12ee, x86_l_12ee);
x86_l_12dd:
	/* 0x12dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12e0:
	/* 0x12e0: jns    13dd <trace_ret_do_init_module+0x13dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12e0, 0x13dd, x86_l_13dd);
x86_l_12e6:
	/* 0x12e6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12e9:
	/* 0x12e9: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12ec:
	/* 0x12ec: jmp    1302 <trace_ret_do_init_module+0x1302> */
	X86_SIM_X86_JMP(0x12ec, 0x1302, x86_l_1302);
x86_l_12ee:
	/* 0x12ee: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12f3:
	/* 0x12f3: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_12f8:
	/* 0x12f8: call   12fd <trace_ret_do_init_module+0x12fd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_12fd:
	/* 0x12fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1300:
	/* 0x1300: js     12a6 <trace_ret_do_init_module+0x12a6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1300, 0x12a6, x86_l_12a6);
x86_l_1302:
	/* 0x1302: add    r12d,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_1306:
	/* 0x1306: mov    WORD PTR [r14+0x7d8a],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_130e:
	/* 0x130e: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1315:
	/* 0x1315: mov    DWORD PTR [rsp+0x40],0x38 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907000ULL);
x86_l_131d:
	/* 0x131d: movzx  r12d,r12w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1321:
	/* 0x1321: cmp    r12d,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 27899ULL);
x86_l_1328:
	/* 0x1328: ja     1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1328, 0x1451, x86_l_1451);
x86_l_132e:
	/* 0x132e: mov    BYTE PTR [r14+r12*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R12, 0), 588410519553ULL);
x86_l_1337:
	/* 0x1337: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_133b:
	/* 0x133b: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1342:
	/* 0x1342: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1347:
	/* 0x1347: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_134a:
	/* 0x134a: jns    135b <trace_ret_do_init_module+0x135b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x134a, 0x135b, x86_l_135b);
x86_l_134c:
	/* 0x134c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_134f:
	/* 0x134f: jns    13e9 <trace_ret_do_init_module+0x13e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x134f, 0x13e9, x86_l_13e9);
x86_l_1355:
	/* 0x1355: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1357:
	/* 0x1357: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1359:
	/* 0x1359: jmp    1373 <trace_ret_do_init_module+0x1373> */
	X86_SIM_X86_JMP(0x1359, 0x1373, x86_l_1373);
x86_l_135b:
	/* 0x135b: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1360:
	/* 0x1360: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1365:
	/* 0x1365: call   136a <trace_ret_do_init_module+0x136a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_136a:
	/* 0x136a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_136d:
	/* 0x136d: jne    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x136d, 0x1451, x86_l_1451);
x86_l_1373:
	/* 0x1373: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_137b:
	/* 0x137b: lea    rdx,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_137f:
	/* 0x137f: mov    esi,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1383:
	/* 0x1383: cmp    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1389:
	/* 0x1389: jb     1398 <trace_ret_do_init_module+0x1398> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1389, 0x1398, x86_l_1398);
x86_l_138b:
	/* 0x138b: mov    DWORD PTR [rsp+0x40],0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877911039ULL);
x86_l_1393:
	/* 0x1393: mov    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_1398:
	/* 0x1398: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_139c:
	/* 0x139c: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_13a3:
	/* 0x13a3: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13a6:
	/* 0x13a6: jns    13f1 <trace_ret_do_init_module+0x13f1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13a6, 0x13f1, x86_l_13f1);
x86_l_13a8:
	/* 0x13a8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13ab:
	/* 0x13ab: jns    13fd <trace_ret_do_init_module+0x13fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13ab, 0x13fd, x86_l_13fd);
x86_l_13ad:
	/* 0x13ad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13af:
	/* 0x13af: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_13b2:
	/* 0x13b2: jb     13c9 <trace_ret_do_init_module+0x13c9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x13b2, 0x13c9, x86_l_13c9);
x86_l_13b4:
	/* 0x13b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13b6:
	/* 0x13b6: mov    rcx,QWORD PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_13ba:
	/* 0x13ba: mov    QWORD PTR [rdi+rax*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_13be:
	/* 0x13be: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_13c2:
	/* 0x13c2: lea    ecx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13c5:
	/* 0x13c5: cmp    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13c7:
	/* 0x13c7: jbe    13b6 <trace_ret_do_init_module+0x13b6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x13c7, 0x13b6, x86_l_13b6);
x86_l_13c9:
	/* 0x13c9: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_13cd:
	/* 0x13cd: jne    1408 <trace_ret_do_init_module+0x1408> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13cd, 0x1408, x86_l_1408);
x86_l_13cf:
	/* 0x13cf: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_13d3:
	/* 0x13d3: jne    141b <trace_ret_do_init_module+0x141b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13d3, 0x141b, x86_l_141b);
x86_l_13d5:
	/* 0x13d5: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_13d9:
	/* 0x13d9: jne    1430 <trace_ret_do_init_module+0x1430> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13d9, 0x1430, x86_l_1430);
x86_l_13db:
	/* 0x13db: jmp    1439 <trace_ret_do_init_module+0x1439> */
	X86_SIM_X86_JMP(0x13db, 0x1439, x86_l_1439);
x86_l_13dd:
	/* 0x13dd: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e4:
	/* 0x13e4: jmp    12a6 <trace_ret_do_init_module+0x12a6> */
	X86_SIM_X86_JMP(0x13e4, 0x12a6, x86_l_12a6);
x86_l_13e9:
	/* 0x13e9: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ef:
	/* 0x13ef: jmp    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JMP(0x13ef, 0x1451, x86_l_1451);
x86_l_13f1:
	/* 0x13f1: call   13f6 <trace_ret_do_init_module+0x13f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_13f6:
	/* 0x13f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13f9:
	/* 0x13f9: jne    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13f9, 0x1451, x86_l_1451);
x86_l_13fb:
	/* 0x13fb: jmp    1439 <trace_ret_do_init_module+0x1439> */
	X86_SIM_X86_JMP(0x13fb, 0x1439, x86_l_1439);
x86_l_13fd:
	/* 0x13fd: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13ff:
	/* 0x13ff: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1401:
	/* 0x1401: call   1406 <trace_ret_do_init_module+0x1406> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1406:
	/* 0x1406: jmp    1451 <trace_ret_do_init_module+0x1451> */
	X86_SIM_X86_JMP(0x1406, 0x1451, x86_l_1451);
x86_l_1408:
	/* 0x1408: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_140a:
	/* 0x140a: mov    r8d,DWORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_140e:
	/* 0x140e: mov    DWORD PTR [rdi+rcx*1],r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1412:
	/* 0x1412: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1415:
	/* 0x1415: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1419:
	/* 0x1419: je     13d5 <trace_ret_do_init_module+0x13d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1419, 0x13d5, x86_l_13d5);
x86_l_141b:
	/* 0x141b: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_141d:
	/* 0x141d: movzx  r8d,WORD PTR [rdx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_1422:
	/* 0x1422: mov    WORD PTR [rdi+rcx*1],r8w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R8, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1427:
	/* 0x1427: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_142a:
	/* 0x142a: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_142e:
	/* 0x142e: je     1439 <trace_ret_do_init_module+0x1439> */
	X86_SIM_X86_JCC(X86_CC_E, 0x142e, 0x1439, x86_l_1439);
x86_l_1430:
	/* 0x1430: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1432:
	/* 0x1432: movzx  ecx,BYTE PTR [rdx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_1436:
	/* 0x1436: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1439:
	/* 0x1439: add    r12,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 5ULL);
x86_l_143d:
	/* 0x143d: add    r12d,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_1442:
	/* 0x1442: mov    WORD PTR [r14+0x7d8a],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_144a:
	/* 0x144a: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1451:
	/* 0x1451: movzx  r12d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1459:
	/* 0x1459: cmp    r12,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 32000ULL);
x86_l_1460:
	/* 0x1460: jae    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1460, 0x1616, x86_l_1616);
x86_l_1466:
	/* 0x1466: mov    BYTE PTR [r14+r12*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R12, 0), 588410519554ULL);
x86_l_146f:
	/* 0x146f: cmp    r12d,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_1476:
	/* 0x1476: jbe    149a <trace_ret_do_init_module+0x149a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1476, 0x149a, x86_l_149a);
x86_l_1478:
	/* 0x1478: movzx  r12d,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1480:
	/* 0x1480: mov    DWORD PTR [rsp+0x40],0x19 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906969ULL);
x86_l_1488:
	/* 0x1488: movzx  r12d,r12w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_148c:
	/* 0x148c: cmp    r12d,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 27899ULL);
x86_l_1493:
	/* 0x1493: jbe    14fe <trace_ret_do_init_module+0x14fe> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1493, 0x14fe, x86_l_14fe);
x86_l_1495:
	/* 0x1495: jmp    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JMP(0x1495, 0x1616, x86_l_1616);
x86_l_149a:
	/* 0x149a: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_149e:
	/* 0x149e: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_14a5:
	/* 0x14a5: lea    rax,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_14aa:
	/* 0x14aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14ad:
	/* 0x14ad: jns    14be <trace_ret_do_init_module+0x14be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14ad, 0x14be, x86_l_14be);
x86_l_14af:
	/* 0x14af: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14b2:
	/* 0x14b2: jns    15a1 <trace_ret_do_init_module+0x15a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14b2, 0x15a1, x86_l_15a1);
x86_l_14b8:
	/* 0x14b8: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ba:
	/* 0x14ba: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14bc:
	/* 0x14bc: jmp    14d2 <trace_ret_do_init_module+0x14d2> */
	X86_SIM_X86_JMP(0x14bc, 0x14d2, x86_l_14d2);
x86_l_14be:
	/* 0x14be: lea    rdx,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_14c3:
	/* 0x14c3: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_14c8:
	/* 0x14c8: call   14cd <trace_ret_do_init_module+0x14cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14cd:
	/* 0x14cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14d0:
	/* 0x14d0: js     1478 <trace_ret_do_init_module+0x1478> */
	X86_SIM_X86_JCC(X86_CC_S, 0x14d0, 0x1478, x86_l_1478);
x86_l_14d2:
	/* 0x14d2: add    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_14d6:
	/* 0x14d6: mov    WORD PTR [r14+0x7d8a],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_14de:
	/* 0x14de: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_14e5:
	/* 0x14e5: mov    DWORD PTR [rsp+0x40],0x19 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906969ULL);
x86_l_14ed:
	/* 0x14ed: movzx  r12d,r12w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_14f1:
	/* 0x14f1: cmp    r12d,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 27899ULL);
x86_l_14f8:
	/* 0x14f8: ja     1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14f8, 0x1616, x86_l_1616);
x86_l_14fe:
	/* 0x14fe: mov    BYTE PTR [r14+r12*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R12, 0), 588410519555ULL);
x86_l_1507:
	/* 0x1507: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_150b:
	/* 0x150b: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1512:
	/* 0x1512: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1517:
	/* 0x1517: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_151a:
	/* 0x151a: jns    152b <trace_ret_do_init_module+0x152b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x151a, 0x152b, x86_l_152b);
x86_l_151c:
	/* 0x151c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_151f:
	/* 0x151f: jns    15ac <trace_ret_do_init_module+0x15ac> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x151f, 0x15ac, x86_l_15ac);
x86_l_1525:
	/* 0x1525: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1527:
	/* 0x1527: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1529:
	/* 0x1529: jmp    1543 <trace_ret_do_init_module+0x1543> */
	X86_SIM_X86_JMP(0x1529, 0x1543, x86_l_1543);
x86_l_152b:
	/* 0x152b: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1530:
	/* 0x1530: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1535:
	/* 0x1535: call   153a <trace_ret_do_init_module+0x153a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_153a:
	/* 0x153a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153d:
	/* 0x153d: jne    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x153d, 0x1616, x86_l_1616);
x86_l_1543:
	/* 0x1543: mov    esi,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1547:
	/* 0x1547: cmp    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_154d:
	/* 0x154d: jb     155c <trace_ret_do_init_module+0x155c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x154d, 0x155c, x86_l_155c);
x86_l_154f:
	/* 0x154f: mov    DWORD PTR [rsp+0x40],0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877911039ULL);
x86_l_1557:
	/* 0x1557: mov    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4095ULL);
x86_l_155c:
	/* 0x155c: lea    rdi,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1560:
	/* 0x1560: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1567:
	/* 0x1567: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_156a:
	/* 0x156a: jns    15b4 <trace_ret_do_init_module+0x15b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156a, 0x15b4, x86_l_15b4);
x86_l_156c:
	/* 0x156c: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_156f:
	/* 0x156f: jns    15c3 <trace_ret_do_init_module+0x15c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x156f, 0x15c3, x86_l_15c3);
x86_l_1571:
	/* 0x1571: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1573:
	/* 0x1573: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1576:
	/* 0x1576: jb     158d <trace_ret_do_init_module+0x158d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1576, 0x158d, x86_l_158d);
x86_l_1578:
	/* 0x1578: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157a:
	/* 0x157a: mov    rcx,QWORD PTR [r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_157e:
	/* 0x157e: mov    QWORD PTR [rdi+rax*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1582:
	/* 0x1582: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1586:
	/* 0x1586: lea    ecx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1589:
	/* 0x1589: cmp    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_158b:
	/* 0x158b: jbe    157a <trace_ret_do_init_module+0x157a> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x158b, 0x157a, x86_l_157a);
x86_l_158d:
	/* 0x158d: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1591:
	/* 0x1591: jne    15ce <trace_ret_do_init_module+0x15ce> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1591, 0x15ce, x86_l_15ce);
x86_l_1593:
	/* 0x1593: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1597:
	/* 0x1597: jne    15e0 <trace_ret_do_init_module+0x15e0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1597, 0x15e0, x86_l_15e0);
x86_l_1599:
	/* 0x1599: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_159d:
	/* 0x159d: jne    15f4 <trace_ret_do_init_module+0x15f4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x159d, 0x15f4, x86_l_15f4);
x86_l_159f:
	/* 0x159f: jmp    15fe <trace_ret_do_init_module+0x15fe> */
	X86_SIM_X86_JMP(0x159f, 0x15fe, x86_l_15fe);
x86_l_15a1:
	/* 0x15a1: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15a7:
	/* 0x15a7: jmp    1478 <trace_ret_do_init_module+0x1478> */
	X86_SIM_X86_JMP(0x15a7, 0x1478, x86_l_1478);
x86_l_15ac:
	/* 0x15ac: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b2:
	/* 0x15b2: jmp    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JMP(0x15b2, 0x1616, x86_l_1616);
x86_l_15b4:
	/* 0x15b4: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_15b7:
	/* 0x15b7: call   15bc <trace_ret_do_init_module+0x15bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15bc:
	/* 0x15bc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15bf:
	/* 0x15bf: jne    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15bf, 0x1616, x86_l_1616);
x86_l_15c1:
	/* 0x15c1: jmp    15fe <trace_ret_do_init_module+0x15fe> */
	X86_SIM_X86_JMP(0x15c1, 0x15fe, x86_l_15fe);
x86_l_15c3:
	/* 0x15c3: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_15c5:
	/* 0x15c5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c7:
	/* 0x15c7: call   15cc <trace_ret_do_init_module+0x15cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_15cc:
	/* 0x15cc: jmp    1616 <trace_ret_do_init_module+0x1616> */
	X86_SIM_X86_JMP(0x15cc, 0x1616, x86_l_1616);
x86_l_15ce:
	/* 0x15ce: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15d0:
	/* 0x15d0: mov    edx,DWORD PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_15d4:
	/* 0x15d4: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_15d7:
	/* 0x15d7: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_15da:
	/* 0x15da: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_15de:
	/* 0x15de: je     1599 <trace_ret_do_init_module+0x1599> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15de, 0x1599, x86_l_1599);
x86_l_15e0:
	/* 0x15e0: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15e2:
	/* 0x15e2: movzx  edx,WORD PTR [r15+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_15e7:
	/* 0x15e7: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_15eb:
	/* 0x15eb: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_15ee:
	/* 0x15ee: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_15f2:
	/* 0x15f2: je     15fe <trace_ret_do_init_module+0x15fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15f2, 0x15fe, x86_l_15fe);
x86_l_15f4:
	/* 0x15f4: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15f6:
	/* 0x15f6: movzx  ecx,BYTE PTR [r15+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_15fb:
	/* 0x15fb: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_15fe:
	/* 0x15fe: add    r12,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 5ULL);
x86_l_1602:
	/* 0x1602: add    r12d,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 64ULL);
x86_l_1607:
	/* 0x1607: mov    WORD PTR [r14+0x7d8a],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_160f:
	/* 0x160f: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1616:
	/* 0x1616: mov    r15,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_161d:
	/* 0x161d: lea    rcx,[r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1621:
	/* 0x1621: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1624:
	/* 0x1624: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1627:
	/* 0x1627: jns    1639 <trace_ret_do_init_module+0x1639> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1627, 0x1639, x86_l_1639);
x86_l_1629:
	/* 0x1629: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162c:
	/* 0x162c: lea    rax,[rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1630:
	/* 0x1630: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1633:
	/* 0x1633: js     1644 <trace_ret_do_init_module+0x1644> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1633, 0x1644, x86_l_1644);
x86_l_1635:
	/* 0x1635: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1637:
	/* 0x1637: jmp    1647 <trace_ret_do_init_module+0x1647> */
	X86_SIM_X86_JMP(0x1637, 0x1647, x86_l_1647);
x86_l_1639:
	/* 0x1639: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_163b:
	/* 0x163b: lea    rax,[rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_163f:
	/* 0x163f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1642:
	/* 0x1642: jns    1635 <trace_ret_do_init_module+0x1635> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1642, 0x1635, x86_l_1635);
x86_l_1644:
	/* 0x1644: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1647:
	/* 0x1647: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_164b:
	/* 0x164b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_164d:
	/* 0x164d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1650:
	/* 0x1650: jns    1661 <trace_ret_do_init_module+0x1661> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1650, 0x1661, x86_l_1661);
x86_l_1652:
	/* 0x1652: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1655:
	/* 0x1655: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_165a:
	/* 0x165a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_165d:
	/* 0x165d: js     166e <trace_ret_do_init_module+0x166e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x165d, 0x166e, x86_l_166e);
x86_l_165f:
	/* 0x165f: jmp    1670 <trace_ret_do_init_module+0x1670> */
	X86_SIM_X86_JMP(0x165f, 0x1670, x86_l_1670);
x86_l_1661:
	/* 0x1661: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1664:
	/* 0x1664: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1669:
	/* 0x1669: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_166c:
	/* 0x166c: jns    1670 <trace_ret_do_init_module+0x1670> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x166c, 0x1670, x86_l_1670);
x86_l_166e:
	/* 0x166e: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1670:
	/* 0x1670: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1674:
	/* 0x1674: lea    rax,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1678:
	/* 0x1678: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_167b:
	/* 0x167b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_167d:
	/* 0x167d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1680:
	/* 0x1680: jns    168f <trace_ret_do_init_module+0x168f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1680, 0x168f, x86_l_168f);
x86_l_1682:
	/* 0x1682: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1685:
	/* 0x1685: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1688:
	/* 0x1688: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_168b:
	/* 0x168b: js     1699 <trace_ret_do_init_module+0x1699> */
	X86_SIM_X86_JCC(X86_CC_S, 0x168b, 0x1699, x86_l_1699);
x86_l_168d:
	/* 0x168d: jmp    169b <trace_ret_do_init_module+0x169b> */
	X86_SIM_X86_JMP(0x168d, 0x169b, x86_l_169b);
x86_l_168f:
	/* 0x168f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1691:
	/* 0x1691: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1694:
	/* 0x1694: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1697:
	/* 0x1697: jns    169b <trace_ret_do_init_module+0x169b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1697, 0x169b, x86_l_169b);
x86_l_1699:
	/* 0x1699: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_169b:
	/* 0x169b: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_169d:
	/* 0x169d: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16a1:
	/* 0x16a1: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16a4:
	/* 0x16a4: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16a8:
	/* 0x16a8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16aa:
	/* 0x16aa: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16ad:
	/* 0x16ad: jns    16b1 <trace_ret_do_init_module+0x16b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ad, 0x16b1, x86_l_16b1);
x86_l_16af:
	/* 0x16af: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16b1:
	/* 0x16b1: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_16b5:
	/* 0x16b5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16b8:
	/* 0x16b8: jns    16bf <trace_ret_do_init_module+0x16bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16b8, 0x16bf, x86_l_16bf);
x86_l_16ba:
	/* 0x16ba: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16bd:
	/* 0x16bd: jmp    16c1 <trace_ret_do_init_module+0x16c1> */
	X86_SIM_X86_JMP(0x16bd, 0x16c1, x86_l_16c1);
x86_l_16bf:
	/* 0x16bf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c1:
	/* 0x16c1: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_16c5:
	/* 0x16c5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c7:
	/* 0x16c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16ca:
	/* 0x16ca: jns    16d9 <trace_ret_do_init_module+0x16d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ca, 0x16d9, x86_l_16d9);
x86_l_16cc:
	/* 0x16cc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16cf:
	/* 0x16cf: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16d2:
	/* 0x16d2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16d5:
	/* 0x16d5: js     16e3 <trace_ret_do_init_module+0x16e3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16d5, 0x16e3, x86_l_16e3);
x86_l_16d7:
	/* 0x16d7: jmp    16e5 <trace_ret_do_init_module+0x16e5> */
	X86_SIM_X86_JMP(0x16d7, 0x16e5, x86_l_16e5);
x86_l_16d9:
	/* 0x16d9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16db:
	/* 0x16db: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16de:
	/* 0x16de: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16e1:
	/* 0x16e1: jns    16e5 <trace_ret_do_init_module+0x16e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e1, 0x16e5, x86_l_16e5);
x86_l_16e3:
	/* 0x16e3: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e5:
	/* 0x16e5: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16e7:
	/* 0x16e7: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_16eb:
	/* 0x16eb: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16ee:
	/* 0x16ee: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16f2:
	/* 0x16f2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16f4:
	/* 0x16f4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16f7:
	/* 0x16f7: jns    16fb <trace_ret_do_init_module+0x16fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f7, 0x16fb, x86_l_16fb);
x86_l_16f9:
	/* 0x16f9: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16fb:
	/* 0x16fb: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_16ff:
	/* 0x16ff: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1701:
	/* 0x1701: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1704:
	/* 0x1704: jns    1713 <trace_ret_do_init_module+0x1713> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1704, 0x1713, x86_l_1713);
x86_l_1706:
	/* 0x1706: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1709:
	/* 0x1709: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_170c:
	/* 0x170c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_170f:
	/* 0x170f: js     171d <trace_ret_do_init_module+0x171d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x170f, 0x171d, x86_l_171d);
x86_l_1711:
	/* 0x1711: jmp    171f <trace_ret_do_init_module+0x171f> */
	X86_SIM_X86_JMP(0x1711, 0x171f, x86_l_171f);
x86_l_1713:
	/* 0x1713: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1715:
	/* 0x1715: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1718:
	/* 0x1718: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_171b:
	/* 0x171b: jns    171f <trace_ret_do_init_module+0x171f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x171b, 0x171f, x86_l_171f);
x86_l_171d:
	/* 0x171d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_171f:
	/* 0x171f: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1721:
	/* 0x1721: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1725:
	/* 0x1725: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1728:
	/* 0x1728: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_172c:
	/* 0x172c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_172e:
	/* 0x172e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1731:
	/* 0x1731: jns    1741 <trace_ret_do_init_module+0x1741> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1731, 0x1741, x86_l_1741);
x86_l_1733:
	/* 0x1733: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1736:
	/* 0x1736: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_173a:
	/* 0x173a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_173d:
	/* 0x173d: js     174c <trace_ret_do_init_module+0x174c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x173d, 0x174c, x86_l_174c);
x86_l_173f:
	/* 0x173f: jmp    174e <trace_ret_do_init_module+0x174e> */
	X86_SIM_X86_JMP(0x173f, 0x174e, x86_l_174e);
x86_l_1741:
	/* 0x1741: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1743:
	/* 0x1743: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1747:
	/* 0x1747: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_174a:
	/* 0x174a: jns    174e <trace_ret_do_init_module+0x174e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x174a, 0x174e, x86_l_174e);
x86_l_174c:
	/* 0x174c: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_174e:
	/* 0x174e: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1753:
	/* 0x1753: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1756:
	/* 0x1756: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1758:
	/* 0x1758: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_175b:
	/* 0x175b: jns    176a <trace_ret_do_init_module+0x176a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175b, 0x176a, x86_l_176a);
x86_l_175d:
	/* 0x175d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1760:
	/* 0x1760: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1763:
	/* 0x1763: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1766:
	/* 0x1766: js     1774 <trace_ret_do_init_module+0x1774> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1766, 0x1774, x86_l_1774);
x86_l_1768:
	/* 0x1768: jmp    1776 <trace_ret_do_init_module+0x1776> */
	X86_SIM_X86_JMP(0x1768, 0x1776, x86_l_1776);
x86_l_176a:
	/* 0x176a: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_176c:
	/* 0x176c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_176f:
	/* 0x176f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1772:
	/* 0x1772: jns    1776 <trace_ret_do_init_module+0x1776> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1772, 0x1776, x86_l_1776);
x86_l_1774:
	/* 0x1774: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1776:
	/* 0x1776: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1778:
	/* 0x1778: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_177c:
	/* 0x177c: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_177f:
	/* 0x177f: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1783:
	/* 0x1783: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1785:
	/* 0x1785: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1788:
	/* 0x1788: jns    1798 <trace_ret_do_init_module+0x1798> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1788, 0x1798, x86_l_1798);
x86_l_178a:
	/* 0x178a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_178d:
	/* 0x178d: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1791:
	/* 0x1791: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1794:
	/* 0x1794: js     17a3 <trace_ret_do_init_module+0x17a3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1794, 0x17a3, x86_l_17a3);
x86_l_1796:
	/* 0x1796: jmp    17a5 <trace_ret_do_init_module+0x17a5> */
	X86_SIM_X86_JMP(0x1796, 0x17a5, x86_l_17a5);
x86_l_1798:
	/* 0x1798: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_179a:
	/* 0x179a: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_179e:
	/* 0x179e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17a1:
	/* 0x17a1: jns    17a5 <trace_ret_do_init_module+0x17a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17a1, 0x17a5, x86_l_17a5);
x86_l_17a3:
	/* 0x17a3: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a5:
	/* 0x17a5: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17a7:
	/* 0x17a7: jne    17e3 <trace_ret_do_init_module+0x17e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17a7, 0x17e3, x86_l_17e3);
x86_l_17a9:
	/* 0x17a9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17ab:
	/* 0x17ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17ae:
	/* 0x17ae: jns    17bd <trace_ret_do_init_module+0x17bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ae, 0x17bd, x86_l_17bd);
x86_l_17b0:
	/* 0x17b0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b3:
	/* 0x17b3: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17b6:
	/* 0x17b6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17b9:
	/* 0x17b9: js     17c7 <trace_ret_do_init_module+0x17c7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x17b9, 0x17c7, x86_l_17c7);
x86_l_17bb:
	/* 0x17bb: jmp    17c9 <trace_ret_do_init_module+0x17c9> */
	X86_SIM_X86_JMP(0x17bb, 0x17c9, x86_l_17c9);
x86_l_17bd:
	/* 0x17bd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17bf:
	/* 0x17bf: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17c2:
	/* 0x17c2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17c5:
	/* 0x17c5: jns    17c9 <trace_ret_do_init_module+0x17c9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c5, 0x17c9, x86_l_17c9);
x86_l_17c7:
	/* 0x17c7: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c9:
	/* 0x17c9: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17cb:
	/* 0x17cb: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_17cf:
	/* 0x17cf: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17d2:
	/* 0x17d2: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17d6:
	/* 0x17d6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17d8:
	/* 0x17d8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17db:
	/* 0x17db: jns    17df <trace_ret_do_init_module+0x17df> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17db, 0x17df, x86_l_17df);
x86_l_17dd:
	/* 0x17dd: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17df:
	/* 0x17df: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17e3:
	/* 0x17e3: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_17e7:
	/* 0x17e7: lea    r13,[r15+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_17ee:
	/* 0x17ee: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17f1:
	/* 0x17f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f4:
	/* 0x17f4: jns    17fb <trace_ret_do_init_module+0x17fb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17f4, 0x17fb, x86_l_17fb);
x86_l_17f6:
	/* 0x17f6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17f9:
	/* 0x17f9: jmp    17fd <trace_ret_do_init_module+0x17fd> */
	X86_SIM_X86_JMP(0x17f9, 0x17fd, x86_l_17fd);
x86_l_17fb:
	/* 0x17fb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17fd:
	/* 0x17fd: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1801:
	/* 0x1801: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1803:
	/* 0x1803: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1806:
	/* 0x1806: jns    1812 <trace_ret_do_init_module+0x1812> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1806, 0x1812, x86_l_1812);
x86_l_1808:
	/* 0x1808: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180b:
	/* 0x180b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_180e:
	/* 0x180e: js     1819 <trace_ret_do_init_module+0x1819> */
	X86_SIM_X86_JCC(X86_CC_S, 0x180e, 0x1819, x86_l_1819);
x86_l_1810:
	/* 0x1810: jmp    181b <trace_ret_do_init_module+0x181b> */
	X86_SIM_X86_JMP(0x1810, 0x181b, x86_l_181b);
x86_l_1812:
	/* 0x1812: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1814:
	/* 0x1814: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1817:
	/* 0x1817: jns    181b <trace_ret_do_init_module+0x181b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1817, 0x181b, x86_l_181b);
x86_l_1819:
	/* 0x1819: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_181b:
	/* 0x181b: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_181f:
	/* 0x181f: call   1824 <trace_ret_do_init_module+0x1824> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1824:
	/* 0x1824: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1828:
	/* 0x1828: lea    rax,[r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_182c:
	/* 0x182c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_182f:
	/* 0x182f: jns    1836 <trace_ret_do_init_module+0x1836> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x182f, 0x1836, x86_l_1836);
x86_l_1831:
	/* 0x1831: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1834:
	/* 0x1834: jmp    1838 <trace_ret_do_init_module+0x1838> */
	X86_SIM_X86_JMP(0x1834, 0x1838, x86_l_1838);
x86_l_1836:
	/* 0x1836: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1838:
	/* 0x1838: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_183d:
	/* 0x183d: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1840:
	/* 0x1840: add    rbp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1844:
	/* 0x1844: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1847:
	/* 0x1847: jns    184f <trace_ret_do_init_module+0x184f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1847, 0x184f, x86_l_184f);
x86_l_1849:
	/* 0x1849: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_184d:
	/* 0x184d: jmp    1851 <trace_ret_do_init_module+0x1851> */
	X86_SIM_X86_JMP(0x184d, 0x1851, x86_l_1851);
x86_l_184f:
	/* 0x184f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1851:
	/* 0x1851: mov    rbp,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1859:
	/* 0x1859: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_185d:
	/* 0x185d: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1861:
	/* 0x1861: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1864:
	/* 0x1864: jns    186c <trace_ret_do_init_module+0x186c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1864, 0x186c, x86_l_186c);
x86_l_1866:
	/* 0x1866: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_186a:
	/* 0x186a: jmp    186e <trace_ret_do_init_module+0x186e> */
	X86_SIM_X86_JMP(0x186a, 0x186e, x86_l_186e);
x86_l_186c:
	/* 0x186c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_186e:
	/* 0x186e: mov    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1873:
	/* 0x1873: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1877:
	/* 0x1877: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_187a:
	/* 0x187a: jns    1888 <trace_ret_do_init_module+0x1888> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x187a, 0x1888, x86_l_1888);
x86_l_187c:
	/* 0x187c: mov    eax,DWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_187f:
	/* 0x187f: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1881:
	/* 0x1881: je     1888 <trace_ret_do_init_module+0x1888> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1881, 0x1888, x86_l_1888);
x86_l_1883:
	/* 0x1883: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_1888:
	/* 0x1888: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_188d:
	/* 0x188d: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1891:
	/* 0x1891: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_1899:
	/* 0x1899: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_18a1:
	/* 0x18a1: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_18a6:
	/* 0x18a6: call   18ab <trace_ret_do_init_module+0x18ab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_18ab:
	/* 0x18ab: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18ae:
	/* 0x18ae: jns    18c7 <trace_ret_do_init_module+0x18c7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18ae, 0x18c7, x86_l_18c7);
x86_l_18b0:
	/* 0x18b0: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18b4:
	/* 0x18b4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18b7:
	/* 0x18b7: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18bc:
	/* 0x18bc: js     18d3 <trace_ret_do_init_module+0x18d3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18bc, 0x18d3, x86_l_18d3);
x86_l_18be:
	/* 0x18be: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c0:
	/* 0x18c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c3:
	/* 0x18c3: js     18db <trace_ret_do_init_module+0x18db> */
	X86_SIM_X86_JCC(X86_CC_S, 0x18c3, 0x18db, x86_l_18db);
x86_l_18c5:
	/* 0x18c5: jmp    1926 <trace_ret_do_init_module+0x1926> */
	X86_SIM_X86_JMP(0x18c5, 0x1926, x86_l_1926);
x86_l_18c7:
	/* 0x18c7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c9:
	/* 0x18c9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18cc:
	/* 0x18cc: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18d1:
	/* 0x18d1: jns    18be <trace_ret_do_init_module+0x18be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18d1, 0x18be, x86_l_18be);
x86_l_18d3:
	/* 0x18d3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d6:
	/* 0x18d6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18d9:
	/* 0x18d9: jns    1926 <trace_ret_do_init_module+0x1926> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18d9, 0x1926, x86_l_1926);
x86_l_18db:
	/* 0x18db: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18de:
	/* 0x18de: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_18e3:
	/* 0x18e3: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18e7:
	/* 0x18e7: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_18ec:
	/* 0x18ec: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18f0:
	/* 0x18f0: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18f5:
	/* 0x18f5: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18f9:
	/* 0x18f9: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18fe:
	/* 0x18fe: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1902:
	/* 0x1902: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1907:
	/* 0x1907: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_190b:
	/* 0x190b: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1910:
	/* 0x1910: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1914:
	/* 0x1914: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1919:
	/* 0x1919: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_191d:
	/* 0x191d: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1922:
	/* 0x1922: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1926:
	/* 0x1926: lea    rcx,[r13+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_192a:
	/* 0x192a: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_192f:
	/* 0x192f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1932:
	/* 0x1932: jns    1a08 <trace_ret_do_init_module+0x1a08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1932, 0x1a08, x86_l_1a08);
x86_l_1938:
	/* 0x1938: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_193b:
	/* 0x193b: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_193d:
	/* 0x193d: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_193f:
	/* 0x193f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x193f, 0x1a17, x86_l_1a17);
x86_l_1945:
	/* 0x1945: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1949:
	/* 0x1949: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_194d:
	/* 0x194d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_194f:
	/* 0x194f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x194f, 0x1a17, x86_l_1a17);
x86_l_1955:
	/* 0x1955: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1959:
	/* 0x1959: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_195d:
	/* 0x195d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_195f:
	/* 0x195f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x195f, 0x1a17, x86_l_1a17);
x86_l_1965:
	/* 0x1965: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1969:
	/* 0x1969: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_196d:
	/* 0x196d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_196f:
	/* 0x196f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x196f, 0x1a17, x86_l_1a17);
x86_l_1975:
	/* 0x1975: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1979:
	/* 0x1979: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_197d:
	/* 0x197d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_197f:
	/* 0x197f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x197f, 0x1a17, x86_l_1a17);
x86_l_1985:
	/* 0x1985: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_1989:
	/* 0x1989: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_198d:
	/* 0x198d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_198f:
	/* 0x198f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x198f, 0x1a17, x86_l_1a17);
x86_l_1995:
	/* 0x1995: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_1999:
	/* 0x1999: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_199d:
	/* 0x199d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_199f:
	/* 0x199f: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x199f, 0x1a17, x86_l_1a17);
x86_l_19a1:
	/* 0x19a1: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_19a5:
	/* 0x19a5: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_19a9:
	/* 0x19a9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19ab:
	/* 0x19ab: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ab, 0x1a17, x86_l_1a17);
x86_l_19ad:
	/* 0x19ad: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19b1:
	/* 0x19b1: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_19b5:
	/* 0x19b5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19b7:
	/* 0x19b7: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19b7, 0x1a17, x86_l_1a17);
x86_l_19b9:
	/* 0x19b9: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_19bd:
	/* 0x19bd: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_19c1:
	/* 0x19c1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19c3:
	/* 0x19c3: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19c3, 0x1a17, x86_l_1a17);
x86_l_19c5:
	/* 0x19c5: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_19c9:
	/* 0x19c9: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_19cd:
	/* 0x19cd: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19cf:
	/* 0x19cf: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19cf, 0x1a17, x86_l_1a17);
x86_l_19d1:
	/* 0x19d1: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_19d5:
	/* 0x19d5: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_19d9:
	/* 0x19d9: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19db:
	/* 0x19db: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19db, 0x1a17, x86_l_1a17);
x86_l_19dd:
	/* 0x19dd: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_19e1:
	/* 0x19e1: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_19e5:
	/* 0x19e5: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19e7:
	/* 0x19e7: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e7, 0x1a17, x86_l_1a17);
x86_l_19e9:
	/* 0x19e9: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_19ed:
	/* 0x19ed: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_19f1:
	/* 0x19f1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19f3:
	/* 0x19f3: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19f3, 0x1a17, x86_l_1a17);
x86_l_19f5:
	/* 0x19f5: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_19f9:
	/* 0x19f9: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_19fd:
	/* 0x19fd: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_19ff:
	/* 0x19ff: je     1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19ff, 0x1a17, x86_l_1a17);
x86_l_1a01:
	/* 0x1a01: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_1a06:
	/* 0x1a06: jmp    1a17 <trace_ret_do_init_module+0x1a17> */
	X86_SIM_X86_JMP(0x1a06, 0x1a17, x86_l_1a17);
x86_l_1a08:
	/* 0x1a08: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1a10:
	/* 0x1a10: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a17:
	/* 0x1a17: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1a1c:
	/* 0x1a1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a1f:
	/* 0x1a1f: jns    1a99 <trace_ret_do_init_module+0x1a99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a1f, 0x1a99, x86_l_1a99);
x86_l_1a21:
	/* 0x1a21: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a24:
	/* 0x1a24: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a29:
	/* 0x1a29: mov    QWORD PTR [rdx],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a2c:
	/* 0x1a2c: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a30:
	/* 0x1a30: mov    QWORD PTR [rdx+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a34:
	/* 0x1a34: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a38:
	/* 0x1a38: mov    QWORD PTR [rdx+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a3c:
	/* 0x1a3c: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a40:
	/* 0x1a40: mov    QWORD PTR [rdx+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a44:
	/* 0x1a44: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a48:
	/* 0x1a48: mov    QWORD PTR [rdx+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a4c:
	/* 0x1a4c: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a50:
	/* 0x1a50: mov    QWORD PTR [rdx+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a54:
	/* 0x1a54: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a58:
	/* 0x1a58: mov    QWORD PTR [rdx+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a5c:
	/* 0x1a5c: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1a60:
	/* 0x1a60: mov    QWORD PTR [rdx+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1a64:
	/* 0x1a64: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1a68:
	/* 0x1a68: mov    QWORD PTR [rdx+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1a6c:
	/* 0x1a6c: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1a70:
	/* 0x1a70: mov    QWORD PTR [rdx+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1a74:
	/* 0x1a74: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a78:
	/* 0x1a78: mov    QWORD PTR [rdx+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a7c:
	/* 0x1a7c: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1a80:
	/* 0x1a80: mov    QWORD PTR [rdx+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1a84:
	/* 0x1a84: mov    rax,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a88:
	/* 0x1a88: mov    QWORD PTR [rdx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1a8c:
	/* 0x1a8c: test   BYTE PTR [r12+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_1a92:
	/* 0x1a92: jne    1b0d <trace_ret_do_init_module+0x1b0d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a92, 0x1b0d, x86_l_1b0d);
x86_l_1a94:
	/* 0x1a94: jmp    1b29 <trace_ret_do_init_module+0x1b29> */
	X86_SIM_X86_JMP(0x1a94, 0x1b29, x86_l_1b29);
x86_l_1a99:
	/* 0x1a99: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a9e:
	/* 0x1a9e: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_1aa6:
	/* 0x1aa6: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_1aae:
	/* 0x1aae: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_1ab6:
	/* 0x1ab6: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1abe:
	/* 0x1abe: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1ac6:
	/* 0x1ac6: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_1ace:
	/* 0x1ace: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1ad6:
	/* 0x1ad6: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1ade:
	/* 0x1ade: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1ae6:
	/* 0x1ae6: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1aee:
	/* 0x1aee: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1af6:
	/* 0x1af6: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1afe:
	/* 0x1afe: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b05:
	/* 0x1b05: test   BYTE PTR [r12+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_1b0b:
	/* 0x1b0b: je     1b29 <trace_ret_do_init_module+0x1b29> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b0b, 0x1b29, x86_l_1b29);
x86_l_1b0d:
	/* 0x1b0d: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_1b14:
	/* 0x1b14: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1b19:
	/* 0x1b19: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b1c:
	/* 0x1b1c: call   1b21 <trace_ret_do_init_module+0x1b21> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_1b21:
	/* 0x1b21: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b23:
	/* 0x1b23: js     1b29 <trace_ret_do_init_module+0x1b29> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b23, 0x1b29, x86_l_1b29);
x86_l_1b25:
	/* 0x1b25: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1b29:
	/* 0x1b29: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1b31:
	/* 0x1b31: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1b36:
	/* 0x1b36: jb     1b3d <trace_ret_do_init_module+0x1b3d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b36, 0x1b3d, x86_l_1b3d);
x86_l_1b38:
	/* 0x1b38: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_1b3d:
	/* 0x1b3d: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_1b42:
	/* 0x1b42: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1b46:
	/* 0x1b46: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_1b4d:
	/* 0x1b4d: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_1b52:
	/* 0x1b52: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b55:
	/* 0x1b55: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1b58:
	/* 0x1b58: call   1b5d <trace_ret_do_init_module+0x1b5d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_1b5d:
	/* 0x1b5d: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1b65:
	/* 0x1b65: add    rax,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_1b69:
	/* 0x1b69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b6c:
	/* 0x1b6c: jns    1b73 <trace_ret_do_init_module+0x1b73> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b6c, 0x1b73, x86_l_1b73);
x86_l_1b6e:
	/* 0x1b6e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b71:
	/* 0x1b71: jmp    1b75 <trace_ret_do_init_module+0x1b75> */
	X86_SIM_X86_JMP(0x1b71, 0x1b75, x86_l_1b75);
x86_l_1b73:
	/* 0x1b73: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b75:
	/* 0x1b75: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1b7d:
	/* 0x1b7d: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1b81:
	/* 0x1b81: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b84:
	/* 0x1b84: mov    QWORD PTR [rsp+0xc0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1b8c:
	/* 0x1b8c: jns    1b93 <trace_ret_do_init_module+0x1b93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b8c, 0x1b93, x86_l_1b93);
x86_l_1b8e:
	/* 0x1b8e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b91:
	/* 0x1b91: jmp    1b95 <trace_ret_do_init_module+0x1b95> */
	X86_SIM_X86_JMP(0x1b91, 0x1b95, x86_l_1b95);
x86_l_1b93:
	/* 0x1b93: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b95:
	/* 0x1b95: mov    QWORD PTR [rsp+0xa0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1b9d:
	/* 0x1b9d: mov    DWORD PTR [r14+0x70],0x2fa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337914ULL);
x86_l_1ba5:
	/* 0x1ba5: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_1baf:
	/* 0x1baf: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_1bb7:
	/* 0x1bb7: mov    QWORD PTR [rbx+0x38],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244813135871ULL);
x86_l_1bbf:
	/* 0x1bbf: mov    QWORD PTR [rbx+0x30],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 210453397503ULL);
x86_l_1bc7:
	/* 0x1bc7: mov    QWORD PTR [rbx+0x28],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176093659135ULL);
x86_l_1bcf:
	/* 0x1bcf: mov    QWORD PTR [rbx+0x20],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 141733920767ULL);
x86_l_1bd7:
	/* 0x1bd7: mov    QWORD PTR [rbx+0x18],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 107374182399ULL);
x86_l_1bdf:
	/* 0x1bdf: mov    QWORD PTR [rbx+0x10],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 73014444031ULL);
x86_l_1be7:
	/* 0x1be7: mov    QWORD PTR [rbx+0x8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_1bef:
	/* 0x1bef: mov    QWORD PTR [rbx],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4294967295ULL);
x86_l_1bf6:
	/* 0x1bf6: mov    QWORD PTR [r14+0x7dd8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138370961375231ULL);
x86_l_1c01:
	/* 0x1c01: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_1c06:
	/* 0x1c06: mov    DWORD PTR [rsp+0x40],0x2fa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907706ULL);
x86_l_1c0e:
	/* 0x1c0e: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c13:
	/* 0x1c13: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_1c1a:
	/* 0x1c1a: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c1f:
	/* 0x1c1f: call   1c24 <trace_ret_do_init_module+0x1c24> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c24:
	/* 0x1c24: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c27:
	/* 0x1c27: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c27, 0x1cc1, x86_l_1cc1);
x86_l_1c2d:
	/* 0x1c2d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c32:
	/* 0x1c32: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c35:
	/* 0x1c35: call   1c3a <trace_ret_do_init_module+0x1c3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c3a:
	/* 0x1c3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c3d:
	/* 0x1c3d: je     1cc1 <trace_ret_do_init_module+0x1cc1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c3d, 0x1cc1, x86_l_1cc1);
x86_l_1c43:
	/* 0x1c43: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c47:
	/* 0x1c47: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_1c4e:
	/* 0x1c4e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c51:
	/* 0x1c51: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_1c58:
	/* 0x1c58: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1c5f:
	/* 0x1c5f: mov    rdx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1c63:
	/* 0x1c63: mov    QWORD PTR [r14+0x7e10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_1c6a:
	/* 0x1c6a: mov    rdx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c6e:
	/* 0x1c6e: mov    QWORD PTR [r14+0x7e08],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_1c75:
	/* 0x1c75: mov    rdx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c79:
	/* 0x1c79: mov    QWORD PTR [r14+0x7e00],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_1c80:
	/* 0x1c80: mov    rdx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c84:
	/* 0x1c84: mov    QWORD PTR [r14+0x7df8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_1c8b:
	/* 0x1c8b: mov    rdx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c8f:
	/* 0x1c8f: mov    rax,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c93:
	/* 0x1c93: mov    QWORD PTR [r14+0x7df0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_1c9a:
	/* 0x1c9a: mov    QWORD PTR [r14+0x7de8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_1ca1:
	/* 0x1ca1: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ca5:
	/* 0x1ca5: cmp    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1ca9:
	/* 0x1ca9: jne    1cd9 <trace_ret_do_init_module+0x1cd9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ca9, 0x1cd9, x86_l_1cd9);
x86_l_1cab:
	/* 0x1cab: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cad:
	/* 0x1cad: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1caf:
	/* 0x1caf: and    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1cb2:
	/* 0x1cb2: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1cb9:
	/* 0x1cb9: jne    2554 <trace_ret_do_init_module+0x2554> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cb9, 0x2554, x86_l_2554);
x86_l_1cbf:
	/* 0x1cbf: jmp    1cc3 <trace_ret_do_init_module+0x1cc3> */
	X86_SIM_X86_JMP(0x1cbf, 0x1cc3, x86_l_1cc3);
x86_l_1cc1:
	/* 0x1cc1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cc3:
	/* 0x1cc3: add    rsp,0xe8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 232ULL);
x86_l_1cca:
	/* 0x1cca: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ccb:
	/* 0x1ccb: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ccd:
	/* 0x1ccd: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1ccf:
	/* 0x1ccf: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cd1:
	/* 0x1cd1: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cd3:
	/* 0x1cd3: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1cd4:
	/* 0x1cd4: jmp    2f89 <trace_ret_do_init_module+0x2f89> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1cd9:
	/* 0x1cd9: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_1ce0:
	/* 0x1ce0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ce3:
	/* 0x1ce3: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ce8:
	/* 0x1ce8: je     1f64 <trace_ret_do_init_module+0x1f64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce8, 0x1f64, x86_l_1f64);
x86_l_1cee:
	/* 0x1cee: movzx  ecx,BYTE PTR [rdx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_1cf5:
	/* 0x1cf5: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_1cf8:
	/* 0x1cf8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cfa:
	/* 0x1cfa: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1cfd:
	/* 0x1cfd: sete   sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d01:
	/* 0x1d01: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1d04:
	/* 0x1d04: neg    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1d07:
	/* 0x1d07: xor    rsi,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_1d0e:
	/* 0x1d0e: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1d11:
	/* 0x1d11: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1d18:
	/* 0x1d18: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d1b:
	/* 0x1d1b: je     1d3c <trace_ret_do_init_module+0x1d3c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d1b, 0x1d3c, x86_l_1d3c);
x86_l_1d1d:
	/* 0x1d1d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d1f:
	/* 0x1d1f: cmp    BYTE PTR [rdx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_1d26:
	/* 0x1d26: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d29:
	/* 0x1d29: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1d2c:
	/* 0x1d2c: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1d2f:
	/* 0x1d2f: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_1d36:
	/* 0x1d36: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1d39:
	/* 0x1d39: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1d3c:
	/* 0x1d3c: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1d43:
	/* 0x1d43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d46:
	/* 0x1d46: je     1d62 <trace_ret_do_init_module+0x1d62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d46, 0x1d62, x86_l_1d62);
x86_l_1d48:
	/* 0x1d48: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_1d4c:
	/* 0x1d4c: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1d4f:
	/* 0x1d4f: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_1d52:
	/* 0x1d52: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1d55:
	/* 0x1d55: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_1d5c:
	/* 0x1d5c: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1d5f:
	/* 0x1d5f: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1d62:
	/* 0x1d62: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_1d69:
	/* 0x1d69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d6c:
	/* 0x1d6c: je     1d8d <trace_ret_do_init_module+0x1d8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d6c, 0x1d8d, x86_l_1d8d);
x86_l_1d6e:
	/* 0x1d6e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1d71:
	/* 0x1d71: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1d79:
	/* 0x1d79: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1d7d:
	/* 0x1d7d: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_1d80:
	/* 0x1d80: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_1d87:
	/* 0x1d87: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1d8a:
	/* 0x1d8a: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1d8d:
	/* 0x1d8d: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_1d92:
	/* 0x1d92: mov    r12,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1d99:
	/* 0x1d99: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1d9c:
	/* 0x1d9c: mov    WORD PTR [rsp+0x18],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1da1:
	/* 0x1da1: je     1ebf <trace_ret_do_init_module+0x1ebf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1da1, 0x1ebf, x86_l_1ebf);
x86_l_1da7:
	/* 0x1da7: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1daf:
	/* 0x1daf: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_1db6:
	/* 0x1db6: mov    QWORD PTR [rsp+0xd0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1dbe:
	/* 0x1dbe: mov    r13,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1dc5:
	/* 0x1dc5: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_1dcc:
	/* 0x1dcc: mov    QWORD PTR [rsp+0xd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1dd4:
	/* 0x1dd4: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dd9:
	/* 0x1dd9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_1de0:
	/* 0x1de0: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1de5:
	/* 0x1de5: call   1dea <trace_ret_do_init_module+0x1dea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1dea:
	/* 0x1dea: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ded:
	/* 0x1ded: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1df1:
	/* 0x1df1: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1df6:
	/* 0x1df6: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1dfd:
	/* 0x1dfd: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e00:
	/* 0x1e00: je     1e20 <trace_ret_do_init_module+0x1e20> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e00, 0x1e20, x86_l_1e20);
x86_l_1e02:
	/* 0x1e02: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e07:
	/* 0x1e07: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e0a:
	/* 0x1e0a: call   1e0f <trace_ret_do_init_module+0x1e0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e0f:
	/* 0x1e0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e12:
	/* 0x1e12: je     1e20 <trace_ret_do_init_module+0x1e20> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e12, 0x1e20, x86_l_1e20);
x86_l_1e14:
	/* 0x1e14: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e17:
	/* 0x1e17: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e1b:
	/* 0x1e1b: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1e1e:
	/* 0x1e1e: jmp    1e23 <trace_ret_do_init_module+0x1e23> */
	X86_SIM_X86_JMP(0x1e1e, 0x1e23, x86_l_1e23);
x86_l_1e20:
	/* 0x1e20: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e23:
	/* 0x1e23: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e28:
	/* 0x1e28: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_1e2b:
	/* 0x1e2b: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e2e:
	/* 0x1e2e: jb     1e4e <trace_ret_do_init_module+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e2e, 0x1e4e, x86_l_1e4e);
x86_l_1e30:
	/* 0x1e30: mov    rcx,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1e38:
	/* 0x1e38: cmp    rcx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1e3c:
	/* 0x1e3c: je     1e43 <trace_ret_do_init_module+0x1e43> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e3c, 0x1e43, x86_l_1e43);
x86_l_1e3e:
	/* 0x1e3e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e41:
	/* 0x1e41: jbe    1e4e <trace_ret_do_init_module+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1e41, 0x1e4e, x86_l_1e4e);
x86_l_1e43:
	/* 0x1e43: and    rbp,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_1e4b:
	/* 0x1e4b: or     r15,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1e4e:
	/* 0x1e4e: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e52:
	/* 0x1e52: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e57:
	/* 0x1e57: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1e5e:
	/* 0x1e5e: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e61:
	/* 0x1e61: je     1e81 <trace_ret_do_init_module+0x1e81> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e61, 0x1e81, x86_l_1e81);
x86_l_1e63:
	/* 0x1e63: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e68:
	/* 0x1e68: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1e6b:
	/* 0x1e6b: call   1e70 <trace_ret_do_init_module+0x1e70> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e70:
	/* 0x1e70: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e73:
	/* 0x1e73: je     1e81 <trace_ret_do_init_module+0x1e81> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e73, 0x1e81, x86_l_1e81);
x86_l_1e75:
	/* 0x1e75: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e78:
	/* 0x1e78: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e7c:
	/* 0x1e7c: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1e7f:
	/* 0x1e7f: jmp    1e83 <trace_ret_do_init_module+0x1e83> */
	X86_SIM_X86_JMP(0x1e7f, 0x1e83, x86_l_1e83);
x86_l_1e81:
	/* 0x1e81: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e83:
	/* 0x1e83: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1e8b:
	/* 0x1e8b: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1e8e:
	/* 0x1e8e: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e93:
	/* 0x1e93: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e96:
	/* 0x1e96: jb     1eb6 <trace_ret_do_init_module+0x1eb6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e96, 0x1eb6, x86_l_1eb6);
x86_l_1e98:
	/* 0x1e98: mov    rdx,QWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1ea0:
	/* 0x1ea0: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1ea4:
	/* 0x1ea4: je     1eab <trace_ret_do_init_module+0x1eab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ea4, 0x1eab, x86_l_1eab);
x86_l_1ea6:
	/* 0x1ea6: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ea9:
	/* 0x1ea9: jbe    1eb6 <trace_ret_do_init_module+0x1eb6> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1ea9, 0x1eb6, x86_l_1eb6);
x86_l_1eab:
	/* 0x1eab: and    rbp,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 208ULL);
x86_l_1eb3:
	/* 0x1eb3: or     rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1eb6:
	/* 0x1eb6: or     r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1eb9:
	/* 0x1eb9: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1ebc:
	/* 0x1ebc: and    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1ebf:
	/* 0x1ebf: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_1ec7:
	/* 0x1ec7: je     1f80 <trace_ret_do_init_module+0x1f80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec7, 0x1f80, x86_l_1f80);
x86_l_1ecd:
	/* 0x1ecd: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ed0:
	/* 0x1ed0: call   1ed5 <trace_ret_do_init_module+0x1ed5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1ed5:
	/* 0x1ed5: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ed9:
	/* 0x1ed9: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1ee0:
	/* 0x1ee0: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1ee7:
	/* 0x1ee7: mov    QWORD PTR [rsp+0x90],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1eef:
	/* 0x1eef: mov    r13,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_1ef6:
	/* 0x1ef6: mov    r12,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1efd:
	/* 0x1efd: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_1f02:
	/* 0x1f02: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f07:
	/* 0x1f07: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_1f0e:
	/* 0x1f0e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f13:
	/* 0x1f13: call   1f18 <trace_ret_do_init_module+0x1f18> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f18:
	/* 0x1f18: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f1c:
	/* 0x1f1c: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f21:
	/* 0x1f21: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1f28:
	/* 0x1f28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f2b:
	/* 0x1f2b: je     1f4b <trace_ret_do_init_module+0x1f4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f2b, 0x1f4b, x86_l_1f4b);
x86_l_1f2d:
	/* 0x1f2d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f32:
	/* 0x1f32: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f35:
	/* 0x1f35: call   1f3a <trace_ret_do_init_module+0x1f3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1f3a:
	/* 0x1f3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f3d:
	/* 0x1f3d: je     1f4b <trace_ret_do_init_module+0x1f4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f3d, 0x1f4b, x86_l_1f4b);
x86_l_1f3f:
	/* 0x1f3f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f42:
	/* 0x1f42: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f46:
	/* 0x1f46: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1f49:
	/* 0x1f49: jmp    1f4d <trace_ret_do_init_module+0x1f4d> */
	X86_SIM_X86_JMP(0x1f49, 0x1f4d, x86_l_1f4d);
x86_l_1f4b:
	/* 0x1f4b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4d:
	/* 0x1f4d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1f50:
	/* 0x1f50: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f55:
	/* 0x1f55: dec    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_1f58:
	/* 0x1f58: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f5b:
	/* 0x1f5b: jae    1f87 <trace_ret_do_init_module+0x1f87> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1f5b, 0x1f87, x86_l_1f87);
x86_l_1f5d:
	/* 0x1f5d: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f62:
	/* 0x1f62: jmp    1fa2 <trace_ret_do_init_module+0x1fa2> */
	X86_SIM_X86_JMP(0x1f62, 0x1fa2, x86_l_1fa2);
x86_l_1f64:
	/* 0x1f64: mov    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1f6b:
	/* 0x1f6b: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1f72:
	/* 0x1f72: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f75:
	/* 0x1f75: jne    1d1d <trace_ret_do_init_module+0x1d1d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f75, 0x1d1d, x86_l_1d1d);
x86_l_1f7b:
	/* 0x1f7b: jmp    1d3c <trace_ret_do_init_module+0x1d3c> */
	X86_SIM_X86_JMP(0x1f7b, 0x1d3c, x86_l_1d3c);
x86_l_1f80:
	/* 0x1f80: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f85:
	/* 0x1f85: jmp    1fab <trace_ret_do_init_module+0x1fab> */
	X86_SIM_X86_JMP(0x1f85, 0x1fab, x86_l_1fab);
x86_l_1f87:
	/* 0x1f87: cmp    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1f8b:
	/* 0x1f8b: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f90:
	/* 0x1f90: je     1f97 <trace_ret_do_init_module+0x1f97> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f90, 0x1f97, x86_l_1f97);
x86_l_1f92:
	/* 0x1f92: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1f95:
	/* 0x1f95: jbe    1fa2 <trace_ret_do_init_module+0x1fa2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x1f95, 0x1fa2, x86_l_1fa2);
x86_l_1f97:
	/* 0x1f97: and    r15,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 144ULL);
x86_l_1f9f:
	/* 0x1f9f: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1fa2:
	/* 0x1fa2: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_1fa5:
	/* 0x1fa5: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1fa8:
	/* 0x1fa8: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1fab:
	/* 0x1fab: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_1fb3:
	/* 0x1fb3: je     2057 <trace_ret_do_init_module+0x2057> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fb3, 0x2057, x86_l_2057);
x86_l_1fb9:
	/* 0x1fb9: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1fbe:
	/* 0x1fbe: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_1fc5:
	/* 0x1fc5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fc8:
	/* 0x1fc8: jns    1fcf <trace_ret_do_init_module+0x1fcf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fc8, 0x1fcf, x86_l_1fcf);
x86_l_1fca:
	/* 0x1fca: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fcd:
	/* 0x1fcd: jmp    1fd1 <trace_ret_do_init_module+0x1fd1> */
	X86_SIM_X86_JMP(0x1fcd, 0x1fd1, x86_l_1fd1);
x86_l_1fcf:
	/* 0x1fcf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fd1:
	/* 0x1fd1: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1fd5:
	/* 0x1fd5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fd7:
	/* 0x1fd7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fda:
	/* 0x1fda: jns    1fe1 <trace_ret_do_init_module+0x1fe1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fda, 0x1fe1, x86_l_1fe1);
x86_l_1fdc:
	/* 0x1fdc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fdf:
	/* 0x1fdf: jmp    1fe3 <trace_ret_do_init_module+0x1fe3> */
	X86_SIM_X86_JMP(0x1fdf, 0x1fe3, x86_l_1fe3);
x86_l_1fe1:
	/* 0x1fe1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fe3:
	/* 0x1fe3: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1fe6:
	/* 0x1fe6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fe9:
	/* 0x1fe9: jns    1fed <trace_ret_do_init_module+0x1fed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fe9, 0x1fed, x86_l_1fed);
x86_l_1feb:
	/* 0x1feb: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fed:
	/* 0x1fed: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1ff1:
	/* 0x1ff1: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1ff8:
	/* 0x1ff8: mov    r15,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_1fff:
	/* 0x1fff: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2002:
	/* 0x2002: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_2007:
	/* 0x2007: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_200c:
	/* 0x200c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_2013:
	/* 0x2013: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2018:
	/* 0x2018: call   201d <trace_ret_do_init_module+0x201d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_201d:
	/* 0x201d: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2024:
	/* 0x2024: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2027:
	/* 0x2027: je     2046 <trace_ret_do_init_module+0x2046> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2027, 0x2046, x86_l_2046);
x86_l_2029:
	/* 0x2029: lea    rsi,[r13+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_202d:
	/* 0x202d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2030:
	/* 0x2030: call   2035 <trace_ret_do_init_module+0x2035> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2035:
	/* 0x2035: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2038:
	/* 0x2038: je     2046 <trace_ret_do_init_module+0x2046> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2038, 0x2046, x86_l_2046);
x86_l_203a:
	/* 0x203a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203d:
	/* 0x203d: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2041:
	/* 0x2041: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2044:
	/* 0x2044: jmp    2048 <trace_ret_do_init_module+0x2048> */
	X86_SIM_X86_JMP(0x2044, 0x2048, x86_l_2048);
x86_l_2046:
	/* 0x2046: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2048:
	/* 0x2048: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_204b:
	/* 0x204b: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_204e:
	/* 0x204e: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2051:
	/* 0x2051: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2054:
	/* 0x2054: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2057:
	/* 0x2057: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_205f:
	/* 0x205f: je     211b <trace_ret_do_init_module+0x211b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x205f, 0x211b, x86_l_211b);
x86_l_2065:
	/* 0x2065: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_206c:
	/* 0x206c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2070:
	/* 0x2070: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2072:
	/* 0x2072: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2075:
	/* 0x2075: jns    207c <trace_ret_do_init_module+0x207c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2075, 0x207c, x86_l_207c);
x86_l_2077:
	/* 0x2077: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_207a:
	/* 0x207a: jmp    207e <trace_ret_do_init_module+0x207e> */
	X86_SIM_X86_JMP(0x207a, 0x207e, x86_l_207e);
x86_l_207c:
	/* 0x207c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_207e:
	/* 0x207e: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2081:
	/* 0x2081: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2084:
	/* 0x2084: jns    2088 <trace_ret_do_init_module+0x2088> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2084, 0x2088, x86_l_2088);
x86_l_2086:
	/* 0x2086: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2088:
	/* 0x2088: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_208a:
	/* 0x208a: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_208e:
	/* 0x208e: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2091:
	/* 0x2091: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2095:
	/* 0x2095: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2097:
	/* 0x2097: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_209a:
	/* 0x209a: jns    20a1 <trace_ret_do_init_module+0x20a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x209a, 0x20a1, x86_l_20a1);
x86_l_209c:
	/* 0x209c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_209f:
	/* 0x209f: jmp    20a3 <trace_ret_do_init_module+0x20a3> */
	X86_SIM_X86_JMP(0x209f, 0x20a3, x86_l_20a3);
x86_l_20a1:
	/* 0x20a1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20a3:
	/* 0x20a3: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20a6:
	/* 0x20a6: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_20aa:
	/* 0x20aa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_20ad:
	/* 0x20ad: jns    20b1 <trace_ret_do_init_module+0x20b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20ad, 0x20b1, x86_l_20b1);
x86_l_20af:
	/* 0x20af: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20b1:
	/* 0x20b1: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_20b5:
	/* 0x20b5: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_20bc:
	/* 0x20bc: mov    r15,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_20c3:
	/* 0x20c3: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_20c6:
	/* 0x20c6: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_20cb:
	/* 0x20cb: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_20d0:
	/* 0x20d0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_20d7:
	/* 0x20d7: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_20dc:
	/* 0x20dc: call   20e1 <trace_ret_do_init_module+0x20e1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20e1:
	/* 0x20e1: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_20e8:
	/* 0x20e8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20eb:
	/* 0x20eb: je     210a <trace_ret_do_init_module+0x210a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20eb, 0x210a, x86_l_210a);
x86_l_20ed:
	/* 0x20ed: lea    rsi,[r13+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_20f1:
	/* 0x20f1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20f4:
	/* 0x20f4: call   20f9 <trace_ret_do_init_module+0x20f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20f9:
	/* 0x20f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20fc:
	/* 0x20fc: je     210a <trace_ret_do_init_module+0x210a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20fc, 0x210a, x86_l_210a);
x86_l_20fe:
	/* 0x20fe: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2101:
	/* 0x2101: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2105:
	/* 0x2105: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2108:
	/* 0x2108: jmp    210c <trace_ret_do_init_module+0x210c> */
	X86_SIM_X86_JMP(0x2108, 0x210c, x86_l_210c);
x86_l_210a:
	/* 0x210a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210c:
	/* 0x210c: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_210f:
	/* 0x210f: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2112:
	/* 0x2112: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2115:
	/* 0x2115: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2118:
	/* 0x2118: and    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_211b:
	/* 0x211b: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_2123:
	/* 0x2123: je     2308 <trace_ret_do_init_module+0x2308> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2123, 0x2308, x86_l_2308);
x86_l_2129:
	/* 0x2129: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_212e:
	/* 0x212e: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_2135:
	/* 0x2135: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2138:
	/* 0x2138: jns    2146 <trace_ret_do_init_module+0x2146> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2138, 0x2146, x86_l_2146);
x86_l_213a:
	/* 0x213a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_213d:
	/* 0x213d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2140:
	/* 0x2140: js     214d <trace_ret_do_init_module+0x214d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2140, 0x214d, x86_l_214d);
x86_l_2142:
	/* 0x2142: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2144:
	/* 0x2144: jmp    2150 <trace_ret_do_init_module+0x2150> */
	X86_SIM_X86_JMP(0x2144, 0x2150, x86_l_2150);
x86_l_2146:
	/* 0x2146: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2148:
	/* 0x2148: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_214b:
	/* 0x214b: jns    2142 <trace_ret_do_init_module+0x2142> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x214b, 0x2142, x86_l_2142);
x86_l_214d:
	/* 0x214d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2150:
	/* 0x2150: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2158:
	/* 0x2158: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_215b:
	/* 0x215b: jns    21a8 <trace_ret_do_init_module+0x21a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x215b, 0x21a8, x86_l_21a8);
x86_l_215d:
	/* 0x215d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2160:
	/* 0x2160: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2165:
	/* 0x2165: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2169:
	/* 0x2169: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_216e:
	/* 0x216e: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2172:
	/* 0x2172: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2177:
	/* 0x2177: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_217b:
	/* 0x217b: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2180:
	/* 0x2180: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2184:
	/* 0x2184: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2189:
	/* 0x2189: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_218d:
	/* 0x218d: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2192:
	/* 0x2192: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2196:
	/* 0x2196: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_219b:
	/* 0x219b: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_219f:
	/* 0x219f: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_21a4:
	/* 0x21a4: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_21a8:
	/* 0x21a8: lea    rbx,[r13+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_21ac:
	/* 0x21ac: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_21b1:
	/* 0x21b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b4:
	/* 0x21b4: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_21b9:
	/* 0x21b9: jns    228f <trace_ret_do_init_module+0x228f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21b9, 0x228f, x86_l_228f);
x86_l_21bf:
	/* 0x21bf: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21c2:
	/* 0x21c2: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c4:
	/* 0x21c4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_21c6:
	/* 0x21c6: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21c6, 0x229e, x86_l_229e);
x86_l_21cc:
	/* 0x21cc: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_21d0:
	/* 0x21d0: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_21d4:
	/* 0x21d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_21d6:
	/* 0x21d6: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21d6, 0x229e, x86_l_229e);
x86_l_21dc:
	/* 0x21dc: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_21e0:
	/* 0x21e0: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_21e4:
	/* 0x21e4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_21e6:
	/* 0x21e6: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e6, 0x229e, x86_l_229e);
x86_l_21ec:
	/* 0x21ec: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_21f0:
	/* 0x21f0: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_21f4:
	/* 0x21f4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_21f6:
	/* 0x21f6: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21f6, 0x229e, x86_l_229e);
x86_l_21fc:
	/* 0x21fc: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2200:
	/* 0x2200: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2204:
	/* 0x2204: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2206:
	/* 0x2206: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2206, 0x229e, x86_l_229e);
x86_l_220c:
	/* 0x220c: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2210:
	/* 0x2210: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2214:
	/* 0x2214: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2216:
	/* 0x2216: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2216, 0x229e, x86_l_229e);
x86_l_221c:
	/* 0x221c: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2220:
	/* 0x2220: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2224:
	/* 0x2224: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2226:
	/* 0x2226: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2226, 0x229e, x86_l_229e);
x86_l_2228:
	/* 0x2228: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_222c:
	/* 0x222c: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_2230:
	/* 0x2230: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2232:
	/* 0x2232: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2232, 0x229e, x86_l_229e);
x86_l_2234:
	/* 0x2234: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2238:
	/* 0x2238: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_223c:
	/* 0x223c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_223e:
	/* 0x223e: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x223e, 0x229e, x86_l_229e);
x86_l_2240:
	/* 0x2240: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2244:
	/* 0x2244: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_2248:
	/* 0x2248: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_224a:
	/* 0x224a: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x224a, 0x229e, x86_l_229e);
x86_l_224c:
	/* 0x224c: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2250:
	/* 0x2250: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_2254:
	/* 0x2254: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2256:
	/* 0x2256: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2256, 0x229e, x86_l_229e);
x86_l_2258:
	/* 0x2258: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_225c:
	/* 0x225c: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_2260:
	/* 0x2260: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2262:
	/* 0x2262: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2262, 0x229e, x86_l_229e);
x86_l_2264:
	/* 0x2264: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2268:
	/* 0x2268: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_226c:
	/* 0x226c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_226e:
	/* 0x226e: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x226e, 0x229e, x86_l_229e);
x86_l_2270:
	/* 0x2270: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2274:
	/* 0x2274: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_2278:
	/* 0x2278: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_227a:
	/* 0x227a: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x227a, 0x229e, x86_l_229e);
x86_l_227c:
	/* 0x227c: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2280:
	/* 0x2280: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_2284:
	/* 0x2284: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2286:
	/* 0x2286: je     229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2286, 0x229e, x86_l_229e);
x86_l_2288:
	/* 0x2288: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_228d:
	/* 0x228d: jmp    229e <trace_ret_do_init_module+0x229e> */
	X86_SIM_X86_JMP(0x228d, 0x229e, x86_l_229e);
x86_l_228f:
	/* 0x228f: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2297:
	/* 0x2297: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_229e:
	/* 0x229e: mov    r15,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_22a5:
	/* 0x22a5: mov    r12,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_22ac:
	/* 0x22ac: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_22af:
	/* 0x22af: mov    WORD PTR [rsp+0x40],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22b4:
	/* 0x22b4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_22bb:
	/* 0x22bb: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22c0:
	/* 0x22c0: call   22c5 <trace_ret_do_init_module+0x22c5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22c5:
	/* 0x22c5: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_22cc:
	/* 0x22cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22cf:
	/* 0x22cf: je     22ed <trace_ret_do_init_module+0x22ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22cf, 0x22ed, x86_l_22ed);
x86_l_22d1:
	/* 0x22d1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22d4:
	/* 0x22d4: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_22d7:
	/* 0x22d7: call   22dc <trace_ret_do_init_module+0x22dc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22dc:
	/* 0x22dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22df:
	/* 0x22df: je     22ed <trace_ret_do_init_module+0x22ed> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22df, 0x22ed, x86_l_22ed);
x86_l_22e1:
	/* 0x22e1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22e4:
	/* 0x22e4: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e8:
	/* 0x22e8: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_22eb:
	/* 0x22eb: jmp    22ef <trace_ret_do_init_module+0x22ef> */
	X86_SIM_X86_JMP(0x22eb, 0x22ef, x86_l_22ef);
x86_l_22ed:
	/* 0x22ed: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22ef:
	/* 0x22ef: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_22f7:
	/* 0x22f7: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_22fa:
	/* 0x22fa: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_22fd:
	/* 0x22fd: or     r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2300:
	/* 0x2300: and    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2303:
	/* 0x2303: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2308:
	/* 0x2308: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_2310:
	/* 0x2310: je     23a4 <trace_ret_do_init_module+0x23a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2310, 0x23a4, x86_l_23a4);
x86_l_2316:
	/* 0x2316: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2319:
	/* 0x2319: lea    rbx,[r13+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_231d:
	/* 0x231d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2320:
	/* 0x2320: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2325:
	/* 0x2325: call   232a <trace_ret_do_init_module+0x232a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_232a:
	/* 0x232a: mov    r15,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_2331:
	/* 0x2331: mov    r12,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_2338:
	/* 0x2338: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_233b:
	/* 0x233b: movzx  eax,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_2340:
	/* 0x2340: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2345:
	/* 0x2345: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_234c:
	/* 0x234c: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2351:
	/* 0x2351: call   2356 <trace_ret_do_init_module+0x2356> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2356:
	/* 0x2356: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_235d:
	/* 0x235d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2360:
	/* 0x2360: je     237e <trace_ret_do_init_module+0x237e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2360, 0x237e, x86_l_237e);
x86_l_2362:
	/* 0x2362: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2365:
	/* 0x2365: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2368:
	/* 0x2368: call   236d <trace_ret_do_init_module+0x236d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_236d:
	/* 0x236d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2370:
	/* 0x2370: je     237e <trace_ret_do_init_module+0x237e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2370, 0x237e, x86_l_237e);
x86_l_2372:
	/* 0x2372: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2375:
	/* 0x2375: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2379:
	/* 0x2379: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_237c:
	/* 0x237c: jmp    2380 <trace_ret_do_init_module+0x2380> */
	X86_SIM_X86_JMP(0x237c, 0x2380, x86_l_2380);
x86_l_237e:
	/* 0x237e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2380:
	/* 0x2380: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_2385:
	/* 0x2385: or     r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2388:
	/* 0x2388: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_238b:
	/* 0x238b: or     r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_238e:
	/* 0x238e: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2391:
	/* 0x2391: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2396:
	/* 0x2396: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_239d:
	/* 0x239d: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_23a0:
	/* 0x23a0: jne    23b8 <trace_ret_do_init_module+0x23b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23a0, 0x23b8, x86_l_23b8);
x86_l_23a2:
	/* 0x23a2: jmp    241d <trace_ret_do_init_module+0x241d> */
	X86_SIM_X86_JMP(0x23a2, 0x241d, x86_l_241d);
x86_l_23a4:
	/* 0x23a4: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23a7:
	/* 0x23a7: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_23ac:
	/* 0x23ac: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_23b3:
	/* 0x23b3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_23b6:
	/* 0x23b6: je     241d <trace_ret_do_init_module+0x241d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23b6, 0x241d, x86_l_241d);
x86_l_23b8:
	/* 0x23b8: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23bc:
	/* 0x23bc: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_23c0:
	/* 0x23c0: mov    r15,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_23c7:
	/* 0x23c7: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_23ca:
	/* 0x23ca: mov    WORD PTR [rsp+0x28],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23cf:
	/* 0x23cf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_23d6:
	/* 0x23d6: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23db:
	/* 0x23db: call   23e0 <trace_ret_do_init_module+0x23e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_23e0:
	/* 0x23e0: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_23e7:
	/* 0x23e7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23ea:
	/* 0x23ea: je     240a <trace_ret_do_init_module+0x240a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23ea, 0x240a, x86_l_240a);
x86_l_23ec:
	/* 0x23ec: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_23f1:
	/* 0x23f1: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23f4:
	/* 0x23f4: call   23f9 <trace_ret_do_init_module+0x23f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_23f9:
	/* 0x23f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23fc:
	/* 0x23fc: je     240a <trace_ret_do_init_module+0x240a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23fc, 0x240a, x86_l_240a);
x86_l_23fe:
	/* 0x23fe: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2401:
	/* 0x2401: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2405:
	/* 0x2405: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2408:
	/* 0x2408: jmp    240c <trace_ret_do_init_module+0x240c> */
	X86_SIM_X86_JMP(0x2408, 0x240c, x86_l_240c);
x86_l_240a:
	/* 0x240a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_240c:
	/* 0x240c: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_2411:
	/* 0x2411: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2414:
	/* 0x2414: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2417:
	/* 0x2417: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_241a:
	/* 0x241a: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_241d:
	/* 0x241d: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_2424:
	/* 0x2424: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2427:
	/* 0x2427: je     2489 <trace_ret_do_init_module+0x2489> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2427, 0x2489, x86_l_2489);
x86_l_2429:
	/* 0x2429: mov    r15,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_2430:
	/* 0x2430: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2433:
	/* 0x2433: mov    WORD PTR [rsp+0x40],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2438:
	/* 0x2438: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_243f:
	/* 0x243f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2444:
	/* 0x2444: call   2449 <trace_ret_do_init_module+0x2449> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2449:
	/* 0x2449: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_2450:
	/* 0x2450: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2453:
	/* 0x2453: je     2476 <trace_ret_do_init_module+0x2476> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2453, 0x2476, x86_l_2476);
x86_l_2455:
	/* 0x2455: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2458:
	/* 0x2458: mov    rsi,QWORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2460:
	/* 0x2460: call   2465 <trace_ret_do_init_module+0x2465> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2465:
	/* 0x2465: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2468:
	/* 0x2468: je     2476 <trace_ret_do_init_module+0x2476> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2468, 0x2476, x86_l_2476);
x86_l_246a:
	/* 0x246a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_246d:
	/* 0x246d: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2471:
	/* 0x2471: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2474:
	/* 0x2474: jmp    2478 <trace_ret_do_init_module+0x2478> */
	X86_SIM_X86_JMP(0x2474, 0x2478, x86_l_2478);
x86_l_2476:
	/* 0x2476: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2478:
	/* 0x2478: movzx  edx,WORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_247d:
	/* 0x247d: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2480:
	/* 0x2480: and    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2483:
	/* 0x2483: or     r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2486:
	/* 0x2486: and    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2489:
	/* 0x2489: mov    r15,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_2490:
	/* 0x2490: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2493:
	/* 0x2493: je     2519 <trace_ret_do_init_module+0x2519> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2493, 0x2519, x86_l_2519);
x86_l_2499:
	/* 0x2499: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_24a0:
	/* 0x24a0: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_24a3:
	/* 0x24a3: mov    WORD PTR [rsp+0x40],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_24a8:
	/* 0x24a8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_24af:
	/* 0x24af: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_24b4:
	/* 0x24b4: call   24b9 <trace_ret_do_init_module+0x24b9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24b9:
	/* 0x24b9: mov    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_24c0:
	/* 0x24c0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24c3:
	/* 0x24c3: je     2506 <trace_ret_do_init_module+0x2506> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24c3, 0x2506, x86_l_2506);
x86_l_24c5:
	/* 0x24c5: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24c8:
	/* 0x24c8: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_24d0:
	/* 0x24d0: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24d4:
	/* 0x24d4: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24d7:
	/* 0x24d7: call   24dc <trace_ret_do_init_module+0x24dc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24dc:
	/* 0x24dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24df:
	/* 0x24df: jne    24fa <trace_ret_do_init_module+0x24fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24df, 0x24fa, x86_l_24fa);
x86_l_24e1:
	/* 0x24e1: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_24e9:
	/* 0x24e9: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ed:
	/* 0x24ed: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24f0:
	/* 0x24f0: call   24f5 <trace_ret_do_init_module+0x24f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24f5:
	/* 0x24f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24f8:
	/* 0x24f8: je     2506 <trace_ret_do_init_module+0x2506> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24f8, 0x2506, x86_l_2506);
x86_l_24fa:
	/* 0x24fa: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fd:
	/* 0x24fd: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2501:
	/* 0x2501: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_2504:
	/* 0x2504: jmp    2508 <trace_ret_do_init_module+0x2508> */
	X86_SIM_X86_JMP(0x2504, 0x2508, x86_l_2508);
x86_l_2506:
	/* 0x2506: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2508:
	/* 0x2508: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_250b:
	/* 0x250b: and    r13,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_250e:
	/* 0x250e: or     r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2511:
	/* 0x2511: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2514:
	/* 0x2514: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2519:
	/* 0x2519: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_2520:
	/* 0x2520: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2523:
	/* 0x2523: je     2534 <trace_ret_do_init_module+0x2534> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2523, 0x2534, x86_l_2534);
x86_l_2525:
	/* 0x2525: mov    rcx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_252d:
	/* 0x252d: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_2531:
	/* 0x2531: or     rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2534:
	/* 0x2534: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2536:
	/* 0x2536: and    rbp,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_253d:
	/* 0x253d: mov    rcx,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2544:
	/* 0x2544: and    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2547:
	/* 0x2547: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_254e:
	/* 0x254e: je     1cc3 <trace_ret_do_init_module+0x1cc3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x254e, 0x1cc3, x86_l_1cc3);
x86_l_2554:
	/* 0x2554: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_255c:
	/* 0x255c: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2562:
	/* 0x2562: mov    rbp,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_256a:
	/* 0x256a: ja     2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JCC(X86_CC_A, 0x256a, 0x2802, x86_l_2802);
x86_l_2570:
	/* 0x2570: mov    BYTE PTR [r14+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_2579:
	/* 0x2579: movzx  esi,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2581:
	/* 0x2581: mov    WORD PTR [r14+0x7d8c],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2589:
	/* 0x2589: cmp    rsi,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2590:
	/* 0x2590: ja     2642 <trace_ret_do_init_module+0x2642> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2590, 0x2642, x86_l_2642);
x86_l_2596:
	/* 0x2596: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_259e:
	/* 0x259e: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_25a2:
	/* 0x25a2: lea    rdi,[rsi+r13*1+0x8e] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 142ULL);
x86_l_25aa:
	/* 0x25aa: jns    25d3 <trace_ret_do_init_module+0x25d3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25aa, 0x25d3, x86_l_25d3);
x86_l_25ac:
	/* 0x25ac: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25af:
	/* 0x25af: jns    25e6 <trace_ret_do_init_module+0x25e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25af, 0x25e6, x86_l_25e6);
x86_l_25b1:
	/* 0x25b1: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_25b4:
	/* 0x25b4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b6:
	/* 0x25b6: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_25bd:
	/* 0x25bd: je     25fc <trace_ret_do_init_module+0x25fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25bd, 0x25fc, x86_l_25fc);
x86_l_25bf:
	/* 0x25bf: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25c3:
	/* 0x25c3: movzx  edx,BYTE PTR [rsi+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_25c7:
	/* 0x25c7: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_25ca:
	/* 0x25ca: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25cd:
	/* 0x25cd: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_25cf:
	/* 0x25cf: jne    25b6 <trace_ret_do_init_module+0x25b6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25cf, 0x25b6, x86_l_25b6);
x86_l_25d1:
	/* 0x25d1: jmp    25dd <trace_ret_do_init_module+0x25dd> */
	X86_SIM_X86_JMP(0x25d1, 0x25dd, x86_l_25dd);
x86_l_25d3:
	/* 0x25d3: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_25d8:
	/* 0x25d8: call   25dd <trace_ret_do_init_module+0x25dd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_25dd:
	/* 0x25dd: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e0:
	/* 0x25e0: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_25e2:
	/* 0x25e2: jg     260d <trace_ret_do_init_module+0x260d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x25e2, 0x260d, x86_l_260d);
x86_l_25e4:
	/* 0x25e4: jmp    25f2 <trace_ret_do_init_module+0x25f2> */
	X86_SIM_X86_JMP(0x25e4, 0x25f2, x86_l_25f2);
x86_l_25e6:
	/* 0x25e6: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_25eb:
	/* 0x25eb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25ed:
	/* 0x25ed: call   25f2 <trace_ret_do_init_module+0x25f2> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_25f2:
	/* 0x25f2: movzx  esi,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_25fa:
	/* 0x25fa: jmp    2642 <trace_ret_do_init_module+0x2642> */
	X86_SIM_X86_JMP(0x25fa, 0x2642, x86_l_2642);
x86_l_25fc:
	/* 0x25fc: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2603:
	/* 0x2603: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2608:
	/* 0x2608: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_260d:
	/* 0x260d: movzx  esi,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2615:
	/* 0x2615: cmp    rsi,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_261c:
	/* 0x261c: ja     2642 <trace_ret_do_init_module+0x2642> */
	X86_SIM_X86_JCC(X86_CC_A, 0x261c, 0x2642, x86_l_2642);
x86_l_261e:
	/* 0x261e: mov    DWORD PTR [rsi+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_2626:
	/* 0x2626: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_262e:
	/* 0x262e: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2631:
	/* 0x2631: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2639:
	/* 0x2639: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2640:
	/* 0x2640: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2642:
	/* 0x2642: movzx  eax,si */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RSI, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2645:
	/* 0x2645: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_264a:
	/* 0x264a: jbe    2659 <trace_ret_do_init_module+0x2659> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x264a, 0x2659, x86_l_2659);
x86_l_264c:
	/* 0x264c: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2654:
	/* 0x2654: jmp    272b <trace_ret_do_init_module+0x272b> */
	X86_SIM_X86_JMP(0x2654, 0x272b, x86_l_272b);
x86_l_2659:
	/* 0x2659: mov    BYTE PTR [r14+rax*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519553ULL);
x86_l_2662:
	/* 0x2662: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_266a:
	/* 0x266a: mov    WORD PTR [r14+0x7d8e],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32142ULL);
x86_l_2672:
	/* 0x2672: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2679:
	/* 0x2679: ja     272b <trace_ret_do_init_module+0x272b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2679, 0x272b, x86_l_272b);
x86_l_267f:
	/* 0x267f: lea    rdi,[rdx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2683:
	/* 0x2683: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_268a:
	/* 0x268a: mov    rsi,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2692:
	/* 0x2692: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2695:
	/* 0x2695: jns    26bb <trace_ret_do_init_module+0x26bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2695, 0x26bb, x86_l_26bb);
x86_l_2697:
	/* 0x2697: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_269a:
	/* 0x269a: jns    26d4 <trace_ret_do_init_module+0x26d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x269a, 0x26d4, x86_l_26d4);
x86_l_269c:
	/* 0x269c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269e:
	/* 0x269e: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_26a5:
	/* 0x26a5: je     26e5 <trace_ret_do_init_module+0x26e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26a5, 0x26e5, x86_l_26e5);
x86_l_26a7:
	/* 0x26a7: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26ab:
	/* 0x26ab: movzx  edx,BYTE PTR [rsi+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_26af:
	/* 0x26af: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_26b2:
	/* 0x26b2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26b5:
	/* 0x26b5: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_26b7:
	/* 0x26b7: jne    269e <trace_ret_do_init_module+0x269e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26b7, 0x269e, x86_l_269e);
x86_l_26b9:
	/* 0x26b9: jmp    26c8 <trace_ret_do_init_module+0x26c8> */
	X86_SIM_X86_JMP(0x26b9, 0x26c8, x86_l_26c8);
x86_l_26bb:
	/* 0x26bb: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26be:
	/* 0x26be: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_26c3:
	/* 0x26c3: call   26c8 <trace_ret_do_init_module+0x26c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_26c8:
	/* 0x26c8: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26cb:
	/* 0x26cb: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_26cd:
	/* 0x26cd: jg     26f6 <trace_ret_do_init_module+0x26f6> */
	X86_SIM_X86_JCC(X86_CC_G, 0x26cd, 0x26f6, x86_l_26f6);
x86_l_26cf:
	/* 0x26cf: jmp    264c <trace_ret_do_init_module+0x264c> */
	X86_SIM_X86_JMP(0x26cf, 0x264c, x86_l_264c);
x86_l_26d4:
	/* 0x26d4: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_26d9:
	/* 0x26d9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26db:
	/* 0x26db: call   26e0 <trace_ret_do_init_module+0x26e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_26e0:
	/* 0x26e0: jmp    264c <trace_ret_do_init_module+0x264c> */
	X86_SIM_X86_JMP(0x26e0, 0x264c, x86_l_264c);
x86_l_26e5:
	/* 0x26e5: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_26ec:
	/* 0x26ec: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_26f1:
	/* 0x26f1: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_26f6:
	/* 0x26f6: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_26fe:
	/* 0x26fe: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2705:
	/* 0x2705: ja     272b <trace_ret_do_init_module+0x272b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2705, 0x272b, x86_l_272b);
x86_l_2707:
	/* 0x2707: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_270f:
	/* 0x270f: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2717:
	/* 0x2717: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_271a:
	/* 0x271a: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2722:
	/* 0x2722: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2729:
	/* 0x2729: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_272b:
	/* 0x272b: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_272e:
	/* 0x272e: cmp    eax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 31999ULL);
x86_l_2733:
	/* 0x2733: ja     2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2733, 0x2802, x86_l_2802);
x86_l_2739:
	/* 0x2739: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_2742:
	/* 0x2742: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_274a:
	/* 0x274a: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_2752:
	/* 0x2752: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2758:
	/* 0x2758: ja     2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2758, 0x2802, x86_l_2802);
x86_l_275e:
	/* 0x275e: lea    rdi,[rax+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2762:
	/* 0x2762: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2769:
	/* 0x2769: mov    rdx,QWORD PTR [rsp+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2771:
	/* 0x2771: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2774:
	/* 0x2774: jns    279d <trace_ret_do_init_module+0x279d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2774, 0x279d, x86_l_279d);
x86_l_2776:
	/* 0x2776: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2779:
	/* 0x2779: jns    27b0 <trace_ret_do_init_module+0x27b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2779, 0x27b0, x86_l_27b0);
x86_l_277b:
	/* 0x277b: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_277e:
	/* 0x277e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2780:
	/* 0x2780: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2787:
	/* 0x2787: je     27be <trace_ret_do_init_module+0x27be> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2787, 0x27be, x86_l_27be);
x86_l_2789:
	/* 0x2789: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_278d:
	/* 0x278d: movzx  edx,BYTE PTR [rsi+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2791:
	/* 0x2791: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2794:
	/* 0x2794: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2797:
	/* 0x2797: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2799:
	/* 0x2799: jne    2780 <trace_ret_do_init_module+0x2780> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2799, 0x2780, x86_l_2780);
x86_l_279b:
	/* 0x279b: jmp    27a7 <trace_ret_do_init_module+0x27a7> */
	X86_SIM_X86_JMP(0x279b, 0x27a7, x86_l_27a7);
x86_l_279d:
	/* 0x279d: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_27a2:
	/* 0x27a2: call   27a7 <trace_ret_do_init_module+0x27a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_27a7:
	/* 0x27a7: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27aa:
	/* 0x27aa: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_27ac:
	/* 0x27ac: jg     27cf <trace_ret_do_init_module+0x27cf> */
	X86_SIM_X86_JCC(X86_CC_G, 0x27ac, 0x27cf, x86_l_27cf);
x86_l_27ae:
	/* 0x27ae: jmp    2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JMP(0x27ae, 0x2802, x86_l_2802);
x86_l_27b0:
	/* 0x27b0: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_27b5:
	/* 0x27b5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b7:
	/* 0x27b7: call   27bc <trace_ret_do_init_module+0x27bc> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_27bc:
	/* 0x27bc: jmp    2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JMP(0x27bc, 0x2802, x86_l_2802);
x86_l_27be:
	/* 0x27be: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_27c5:
	/* 0x27c5: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_27ca:
	/* 0x27ca: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_27cf:
	/* 0x27cf: movzx  edx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_27d7:
	/* 0x27d7: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_27de:
	/* 0x27de: ja     2802 <trace_ret_do_init_module+0x2802> */
	X86_SIM_X86_JCC(X86_CC_A, 0x27de, 0x2802, x86_l_2802);
x86_l_27e0:
	/* 0x27e0: mov    DWORD PTR [rdx+r14*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_27e8:
	/* 0x27e8: add    cx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_27f0:
	/* 0x27f0: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_27f3:
	/* 0x27f3: mov    WORD PTR [r14+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_27fb:
	/* 0x27fb: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2802:
	/* 0x2802: mov    eax,DWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2805:
	/* 0x2805: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2809:
	/* 0x2809: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2811:
	/* 0x2811: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2818:
	/* 0x2818: ja     2879 <trace_ret_do_init_module+0x2879> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2818, 0x2879, x86_l_2879);
x86_l_281a:
	/* 0x281a: mov    BYTE PTR [r14+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_2823:
	/* 0x2823: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2829:
	/* 0x2829: ja     2879 <trace_ret_do_init_module+0x2879> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2829, 0x2879, x86_l_2879);
x86_l_282b:
	/* 0x282b: lea    rdi,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_282f:
	/* 0x282f: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2836:
	/* 0x2836: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_283b:
	/* 0x283b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_283e:
	/* 0x283e: jns    284b <trace_ret_do_init_module+0x284b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x283e, 0x284b, x86_l_284b);
x86_l_2840:
	/* 0x2840: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2843:
	/* 0x2843: jns    2873 <trace_ret_do_init_module+0x2873> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2843, 0x2873, x86_l_2873);
x86_l_2845:
	/* 0x2845: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2847:
	/* 0x2847: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2849:
	/* 0x2849: jmp    285f <trace_ret_do_init_module+0x285f> */
	X86_SIM_X86_JMP(0x2849, 0x285f, x86_l_285f);
x86_l_284b:
	/* 0x284b: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2850:
	/* 0x2850: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2855:
	/* 0x2855: call   285a <trace_ret_do_init_module+0x285a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_285a:
	/* 0x285a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_285d:
	/* 0x285d: js     2879 <trace_ret_do_init_module+0x2879> */
	X86_SIM_X86_JCC(X86_CC_S, 0x285d, 0x2879, x86_l_2879);
x86_l_285f:
	/* 0x285f: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2862:
	/* 0x2862: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_286a:
	/* 0x286a: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2871:
	/* 0x2871: jmp    2879 <trace_ret_do_init_module+0x2879> */
	X86_SIM_X86_JMP(0x2871, 0x2879, x86_l_2879);
x86_l_2873:
	/* 0x2873: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2879:
	/* 0x2879: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2880:
	/* 0x2880: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2884:
	/* 0x2884: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2887:
	/* 0x2887: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_288a:
	/* 0x288a: jns    289c <trace_ret_do_init_module+0x289c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x288a, 0x289c, x86_l_289c);
x86_l_288c:
	/* 0x288c: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_288f:
	/* 0x288f: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2893:
	/* 0x2893: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2896:
	/* 0x2896: js     28a8 <trace_ret_do_init_module+0x28a8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2896, 0x28a8, x86_l_28a8);
x86_l_2898:
	/* 0x2898: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_289a:
	/* 0x289a: jmp    28ab <trace_ret_do_init_module+0x28ab> */
	X86_SIM_X86_JMP(0x289a, 0x28ab, x86_l_28ab);
x86_l_289c:
	/* 0x289c: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_289f:
	/* 0x289f: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_28a3:
	/* 0x28a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a6:
	/* 0x28a6: jns    2898 <trace_ret_do_init_module+0x2898> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28a6, 0x2898, x86_l_2898);
x86_l_28a8:
	/* 0x28a8: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ab:
	/* 0x28ab: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_28af:
	/* 0x28af: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b1:
	/* 0x28b1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28b4:
	/* 0x28b4: jns    28c5 <trace_ret_do_init_module+0x28c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b4, 0x28c5, x86_l_28c5);
x86_l_28b6:
	/* 0x28b6: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b9:
	/* 0x28b9: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_28be:
	/* 0x28be: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28c1:
	/* 0x28c1: js     28d2 <trace_ret_do_init_module+0x28d2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28c1, 0x28d2, x86_l_28d2);
x86_l_28c3:
	/* 0x28c3: jmp    28d4 <trace_ret_do_init_module+0x28d4> */
	X86_SIM_X86_JMP(0x28c3, 0x28d4, x86_l_28d4);
x86_l_28c5:
	/* 0x28c5: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c8:
	/* 0x28c8: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_28cd:
	/* 0x28cd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28d0:
	/* 0x28d0: jns    28d4 <trace_ret_do_init_module+0x28d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28d0, 0x28d4, x86_l_28d4);
x86_l_28d2:
	/* 0x28d2: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d4:
	/* 0x28d4: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_28d8:
	/* 0x28d8: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28dc:
	/* 0x28dc: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28df:
	/* 0x28df: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28e1:
	/* 0x28e1: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28e4:
	/* 0x28e4: jns    28f3 <trace_ret_do_init_module+0x28f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28e4, 0x28f3, x86_l_28f3);
x86_l_28e6:
	/* 0x28e6: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28e9:
	/* 0x28e9: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28ec:
	/* 0x28ec: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28ef:
	/* 0x28ef: js     28fd <trace_ret_do_init_module+0x28fd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ef, 0x28fd, x86_l_28fd);
x86_l_28f1:
	/* 0x28f1: jmp    28ff <trace_ret_do_init_module+0x28ff> */
	X86_SIM_X86_JMP(0x28f1, 0x28ff, x86_l_28ff);
x86_l_28f3:
	/* 0x28f3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28f5:
	/* 0x28f5: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28f8:
	/* 0x28f8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28fb:
	/* 0x28fb: jns    28ff <trace_ret_do_init_module+0x28ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28fb, 0x28ff, x86_l_28ff);
x86_l_28fd:
	/* 0x28fd: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28ff:
	/* 0x28ff: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2901:
	/* 0x2901: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2905:
	/* 0x2905: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2908:
	/* 0x2908: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_290c:
	/* 0x290c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_290e:
	/* 0x290e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2911:
	/* 0x2911: jns    2915 <trace_ret_do_init_module+0x2915> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2911, 0x2915, x86_l_2915);
x86_l_2913:
	/* 0x2913: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2915:
	/* 0x2915: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2919:
	/* 0x2919: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_291c:
	/* 0x291c: jns    2923 <trace_ret_do_init_module+0x2923> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x291c, 0x2923, x86_l_2923);
x86_l_291e:
	/* 0x291e: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2921:
	/* 0x2921: jmp    2925 <trace_ret_do_init_module+0x2925> */
	X86_SIM_X86_JMP(0x2921, 0x2925, x86_l_2925);
x86_l_2923:
	/* 0x2923: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2925:
	/* 0x2925: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2929:
	/* 0x2929: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_292b:
	/* 0x292b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_292e:
	/* 0x292e: jns    293d <trace_ret_do_init_module+0x293d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x292e, 0x293d, x86_l_293d);
x86_l_2930:
	/* 0x2930: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2933:
	/* 0x2933: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2936:
	/* 0x2936: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2939:
	/* 0x2939: js     2947 <trace_ret_do_init_module+0x2947> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2939, 0x2947, x86_l_2947);
x86_l_293b:
	/* 0x293b: jmp    2949 <trace_ret_do_init_module+0x2949> */
	X86_SIM_X86_JMP(0x293b, 0x2949, x86_l_2949);
x86_l_293d:
	/* 0x293d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_293f:
	/* 0x293f: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2942:
	/* 0x2942: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2945:
	/* 0x2945: jns    2949 <trace_ret_do_init_module+0x2949> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2945, 0x2949, x86_l_2949);
x86_l_2947:
	/* 0x2947: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2949:
	/* 0x2949: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_294b:
	/* 0x294b: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_294f:
	/* 0x294f: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2952:
	/* 0x2952: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2956:
	/* 0x2956: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2958:
	/* 0x2958: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_295b:
	/* 0x295b: jns    295f <trace_ret_do_init_module+0x295f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x295b, 0x295f, x86_l_295f);
x86_l_295d:
	/* 0x295d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_295f:
	/* 0x295f: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2963:
	/* 0x2963: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2965:
	/* 0x2965: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2968:
	/* 0x2968: jns    2977 <trace_ret_do_init_module+0x2977> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2968, 0x2977, x86_l_2977);
x86_l_296a:
	/* 0x296a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_296d:
	/* 0x296d: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2970:
	/* 0x2970: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2973:
	/* 0x2973: js     2981 <trace_ret_do_init_module+0x2981> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2973, 0x2981, x86_l_2981);
x86_l_2975:
	/* 0x2975: jmp    2983 <trace_ret_do_init_module+0x2983> */
	X86_SIM_X86_JMP(0x2975, 0x2983, x86_l_2983);
x86_l_2977:
	/* 0x2977: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2979:
	/* 0x2979: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_297c:
	/* 0x297c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_297f:
	/* 0x297f: jns    2983 <trace_ret_do_init_module+0x2983> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x297f, 0x2983, x86_l_2983);
x86_l_2981:
	/* 0x2981: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2983:
	/* 0x2983: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2985:
	/* 0x2985: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2989:
	/* 0x2989: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_298c:
	/* 0x298c: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2990:
	/* 0x2990: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2992:
	/* 0x2992: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2995:
	/* 0x2995: jns    29a5 <trace_ret_do_init_module+0x29a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2995, 0x29a5, x86_l_29a5);
x86_l_2997:
	/* 0x2997: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_299a:
	/* 0x299a: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_299e:
	/* 0x299e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29a1:
	/* 0x29a1: js     29b0 <trace_ret_do_init_module+0x29b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29a1, 0x29b0, x86_l_29b0);
x86_l_29a3:
	/* 0x29a3: jmp    29b2 <trace_ret_do_init_module+0x29b2> */
	X86_SIM_X86_JMP(0x29a3, 0x29b2, x86_l_29b2);
x86_l_29a5:
	/* 0x29a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29a7:
	/* 0x29a7: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_29ab:
	/* 0x29ab: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29ae:
	/* 0x29ae: jns    29b2 <trace_ret_do_init_module+0x29b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ae, 0x29b2, x86_l_29b2);
x86_l_29b0:
	/* 0x29b0: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b2:
	/* 0x29b2: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29b7:
	/* 0x29b7: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29ba:
	/* 0x29ba: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29bc:
	/* 0x29bc: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29bf:
	/* 0x29bf: jns    29ce <trace_ret_do_init_module+0x29ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29bf, 0x29ce, x86_l_29ce);
x86_l_29c1:
	/* 0x29c1: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c4:
	/* 0x29c4: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29c7:
	/* 0x29c7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29ca:
	/* 0x29ca: js     29d8 <trace_ret_do_init_module+0x29d8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29ca, 0x29d8, x86_l_29d8);
x86_l_29cc:
	/* 0x29cc: jmp    29da <trace_ret_do_init_module+0x29da> */
	X86_SIM_X86_JMP(0x29cc, 0x29da, x86_l_29da);
x86_l_29ce:
	/* 0x29ce: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d0:
	/* 0x29d0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29d3:
	/* 0x29d3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29d6:
	/* 0x29d6: jns    29da <trace_ret_do_init_module+0x29da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29d6, 0x29da, x86_l_29da);
x86_l_29d8:
	/* 0x29d8: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29da:
	/* 0x29da: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_29dc:
	/* 0x29dc: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_29e0:
	/* 0x29e0: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_29e3:
	/* 0x29e3: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29e7:
	/* 0x29e7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e9:
	/* 0x29e9: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29ec:
	/* 0x29ec: jns    29fc <trace_ret_do_init_module+0x29fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ec, 0x29fc, x86_l_29fc);
x86_l_29ee:
	/* 0x29ee: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f1:
	/* 0x29f1: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_29f5:
	/* 0x29f5: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29f8:
	/* 0x29f8: js     2a07 <trace_ret_do_init_module+0x2a07> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29f8, 0x2a07, x86_l_2a07);
x86_l_29fa:
	/* 0x29fa: jmp    2a09 <trace_ret_do_init_module+0x2a09> */
	X86_SIM_X86_JMP(0x29fa, 0x2a09, x86_l_2a09);
x86_l_29fc:
	/* 0x29fc: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29fe:
	/* 0x29fe: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2a02:
	/* 0x2a02: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a05:
	/* 0x2a05: jns    2a09 <trace_ret_do_init_module+0x2a09> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a05, 0x2a09, x86_l_2a09);
x86_l_2a07:
	/* 0x2a07: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a09:
	/* 0x2a09: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2a0b:
	/* 0x2a0b: jne    2a3f <trace_ret_do_init_module+0x2a3f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a0b, 0x2a3f, x86_l_2a3f);
x86_l_2a0d:
	/* 0x2a0d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a0f:
	/* 0x2a0f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a12:
	/* 0x2a12: jns    2a19 <trace_ret_do_init_module+0x2a19> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a12, 0x2a19, x86_l_2a19);
x86_l_2a14:
	/* 0x2a14: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a17:
	/* 0x2a17: jmp    2a1b <trace_ret_do_init_module+0x2a1b> */
	X86_SIM_X86_JMP(0x2a17, 0x2a1b, x86_l_2a1b);
x86_l_2a19:
	/* 0x2a19: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a1b:
	/* 0x2a1b: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a1e:
	/* 0x2a1e: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2a21:
	/* 0x2a21: jns    2a25 <trace_ret_do_init_module+0x2a25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a21, 0x2a25, x86_l_2a25);
x86_l_2a23:
	/* 0x2a23: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a25:
	/* 0x2a25: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2a27:
	/* 0x2a27: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2a2b:
	/* 0x2a2b: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a2e:
	/* 0x2a2e: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2a32:
	/* 0x2a32: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a34:
	/* 0x2a34: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a37:
	/* 0x2a37: jns    2a3b <trace_ret_do_init_module+0x2a3b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a37, 0x2a3b, x86_l_2a3b);
x86_l_2a39:
	/* 0x2a39: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a3b:
	/* 0x2a3b: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a3f:
	/* 0x2a3f: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a43:
	/* 0x2a43: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2a4a:
	/* 0x2a4a: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2a4d:
	/* 0x2a4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a50:
	/* 0x2a50: jns    2a57 <trace_ret_do_init_module+0x2a57> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a50, 0x2a57, x86_l_2a57);
x86_l_2a52:
	/* 0x2a52: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a55:
	/* 0x2a55: jmp    2a59 <trace_ret_do_init_module+0x2a59> */
	X86_SIM_X86_JMP(0x2a55, 0x2a59, x86_l_2a59);
x86_l_2a57:
	/* 0x2a57: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a59:
	/* 0x2a59: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2a5d:
	/* 0x2a5d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a5f:
	/* 0x2a5f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a62:
	/* 0x2a62: jns    2a6e <trace_ret_do_init_module+0x2a6e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a62, 0x2a6e, x86_l_2a6e);
x86_l_2a64:
	/* 0x2a64: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a67:
	/* 0x2a67: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a6a:
	/* 0x2a6a: js     2a75 <trace_ret_do_init_module+0x2a75> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a6a, 0x2a75, x86_l_2a75);
x86_l_2a6c:
	/* 0x2a6c: jmp    2a77 <trace_ret_do_init_module+0x2a77> */
	X86_SIM_X86_JMP(0x2a6c, 0x2a77, x86_l_2a77);
x86_l_2a6e:
	/* 0x2a6e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a70:
	/* 0x2a70: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2a73:
	/* 0x2a73: jns    2a77 <trace_ret_do_init_module+0x2a77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a73, 0x2a77, x86_l_2a77);
x86_l_2a75:
	/* 0x2a75: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a77:
	/* 0x2a77: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2a7b:
	/* 0x2a7b: call   2a80 <trace_ret_do_init_module+0x2a80> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2a80:
	/* 0x2a80: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a84:
	/* 0x2a84: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2a88:
	/* 0x2a88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a8b:
	/* 0x2a8b: jns    2a92 <trace_ret_do_init_module+0x2a92> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a8b, 0x2a92, x86_l_2a92);
x86_l_2a8d:
	/* 0x2a8d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a90:
	/* 0x2a90: jmp    2a94 <trace_ret_do_init_module+0x2a94> */
	X86_SIM_X86_JMP(0x2a90, 0x2a94, x86_l_2a94);
x86_l_2a92:
	/* 0x2a92: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a94:
	/* 0x2a94: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a99:
	/* 0x2a99: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a9c:
	/* 0x2a9c: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2aa0:
	/* 0x2aa0: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2aa3:
	/* 0x2aa3: jns    2aaa <trace_ret_do_init_module+0x2aaa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aa3, 0x2aaa, x86_l_2aaa);
x86_l_2aa5:
	/* 0x2aa5: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aa8:
	/* 0x2aa8: jmp    2aac <trace_ret_do_init_module+0x2aac> */
	X86_SIM_X86_JMP(0x2aa8, 0x2aac, x86_l_2aac);
x86_l_2aaa:
	/* 0x2aaa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aac:
	/* 0x2aac: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2ab0:
	/* 0x2ab0: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2ab4:
	/* 0x2ab4: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2ab7:
	/* 0x2ab7: jns    2abf <trace_ret_do_init_module+0x2abf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ab7, 0x2abf, x86_l_2abf);
x86_l_2ab9:
	/* 0x2ab9: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2abd:
	/* 0x2abd: jmp    2ac1 <trace_ret_do_init_module+0x2ac1> */
	X86_SIM_X86_JMP(0x2abd, 0x2ac1, x86_l_2ac1);
x86_l_2abf:
	/* 0x2abf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ac1:
	/* 0x2ac1: mov    r15,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ac6:
	/* 0x2ac6: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2acb:
	/* 0x2acb: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2acf:
	/* 0x2acf: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2ad2:
	/* 0x2ad2: jns    2adf <trace_ret_do_init_module+0x2adf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad2, 0x2adf, x86_l_2adf);
x86_l_2ad4:
	/* 0x2ad4: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad6:
	/* 0x2ad6: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2ad8:
	/* 0x2ad8: je     2adf <trace_ret_do_init_module+0x2adf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ad8, 0x2adf, x86_l_2adf);
x86_l_2ada:
	/* 0x2ada: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_2adf:
	/* 0x2adf: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ae4:
	/* 0x2ae4: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_2ae8:
	/* 0x2ae8: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_2af0:
	/* 0x2af0: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_2af8:
	/* 0x2af8: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2afd:
	/* 0x2afd: call   2b02 <trace_ret_do_init_module+0x2b02> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_2b02:
	/* 0x2b02: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2b05:
	/* 0x2b05: jns    2b0d <trace_ret_do_init_module+0x2b0d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b05, 0x2b0d, x86_l_2b0d);
x86_l_2b07:
	/* 0x2b07: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b0b:
	/* 0x2b0b: jmp    2b0f <trace_ret_do_init_module+0x2b0f> */
	X86_SIM_X86_JMP(0x2b0b, 0x2b0f, x86_l_2b0f);
x86_l_2b0d:
	/* 0x2b0d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b0f:
	/* 0x2b0f: mov    rsi,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b14:
	/* 0x2b14: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b17:
	/* 0x2b17: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b1c:
	/* 0x2b1c: jns    2b28 <trace_ret_do_init_module+0x2b28> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b1c, 0x2b28, x86_l_2b28);
x86_l_2b1e:
	/* 0x2b1e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b21:
	/* 0x2b21: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b24:
	/* 0x2b24: js     2b2f <trace_ret_do_init_module+0x2b2f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b24, 0x2b2f, x86_l_2b2f);
x86_l_2b26:
	/* 0x2b26: jmp    2b70 <trace_ret_do_init_module+0x2b70> */
	X86_SIM_X86_JMP(0x2b26, 0x2b70, x86_l_2b70);
x86_l_2b28:
	/* 0x2b28: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b2a:
	/* 0x2b2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b2d:
	/* 0x2b2d: jns    2b70 <trace_ret_do_init_module+0x2b70> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b2d, 0x2b70, x86_l_2b70);
x86_l_2b2f:
	/* 0x2b2f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b32:
	/* 0x2b32: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b37:
	/* 0x2b37: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b3b:
	/* 0x2b3b: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2b40:
	/* 0x2b40: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b44:
	/* 0x2b44: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b49:
	/* 0x2b49: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b4d:
	/* 0x2b4d: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2b52:
	/* 0x2b52: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b56:
	/* 0x2b56: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2b5b:
	/* 0x2b5b: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2b5f:
	/* 0x2b5f: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2b64:
	/* 0x2b64: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b68:
	/* 0x2b68: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2b6c:
	/* 0x2b6c: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2b70:
	/* 0x2b70: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_2b74:
	/* 0x2b74: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b79:
	/* 0x2b79: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b7c:
	/* 0x2b7c: jns    2c52 <trace_ret_do_init_module+0x2c52> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b7c, 0x2c52, x86_l_2c52);
x86_l_2b82:
	/* 0x2b82: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2b85:
	/* 0x2b85: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b87:
	/* 0x2b87: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2b89:
	/* 0x2b89: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b89, 0x2c61, x86_l_2c61);
x86_l_2b8f:
	/* 0x2b8f: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2b93:
	/* 0x2b93: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_2b97:
	/* 0x2b97: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2b99:
	/* 0x2b99: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b99, 0x2c61, x86_l_2c61);
x86_l_2b9f:
	/* 0x2b9f: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_2ba3:
	/* 0x2ba3: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_2ba7:
	/* 0x2ba7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2ba9:
	/* 0x2ba9: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ba9, 0x2c61, x86_l_2c61);
x86_l_2baf:
	/* 0x2baf: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_2bb3:
	/* 0x2bb3: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_2bb7:
	/* 0x2bb7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2bb9:
	/* 0x2bb9: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bb9, 0x2c61, x86_l_2c61);
x86_l_2bbf:
	/* 0x2bbf: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2bc3:
	/* 0x2bc3: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2bc7:
	/* 0x2bc7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2bc9:
	/* 0x2bc9: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bc9, 0x2c61, x86_l_2c61);
x86_l_2bcf:
	/* 0x2bcf: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_2bd3:
	/* 0x2bd3: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_2bd7:
	/* 0x2bd7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2bd9:
	/* 0x2bd9: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bd9, 0x2c61, x86_l_2c61);
x86_l_2bdf:
	/* 0x2bdf: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_2be3:
	/* 0x2be3: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_2be7:
	/* 0x2be7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2be9:
	/* 0x2be9: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2be9, 0x2c61, x86_l_2c61);
x86_l_2beb:
	/* 0x2beb: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_2bef:
	/* 0x2bef: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_2bf3:
	/* 0x2bf3: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2bf5:
	/* 0x2bf5: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bf5, 0x2c61, x86_l_2c61);
x86_l_2bf7:
	/* 0x2bf7: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_2bfb:
	/* 0x2bfb: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_2bff:
	/* 0x2bff: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c01:
	/* 0x2c01: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c01, 0x2c61, x86_l_2c61);
x86_l_2c03:
	/* 0x2c03: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_2c07:
	/* 0x2c07: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_2c0b:
	/* 0x2c0b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c0d:
	/* 0x2c0d: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c0d, 0x2c61, x86_l_2c61);
x86_l_2c0f:
	/* 0x2c0f: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_2c13:
	/* 0x2c13: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_2c17:
	/* 0x2c17: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c19:
	/* 0x2c19: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c19, 0x2c61, x86_l_2c61);
x86_l_2c1b:
	/* 0x2c1b: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_2c1f:
	/* 0x2c1f: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_2c23:
	/* 0x2c23: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c25:
	/* 0x2c25: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c25, 0x2c61, x86_l_2c61);
x86_l_2c27:
	/* 0x2c27: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_2c2b:
	/* 0x2c2b: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2c2f:
	/* 0x2c2f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c31:
	/* 0x2c31: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c31, 0x2c61, x86_l_2c61);
x86_l_2c33:
	/* 0x2c33: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_2c37:
	/* 0x2c37: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_2c3b:
	/* 0x2c3b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_2c3d:
	/* 0x2c3d: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c3d, 0x2c61, x86_l_2c61);
x86_l_2c3f:
	/* 0x2c3f: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_2c43:
	/* 0x2c43: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_2c47:
	/* 0x2c47: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2c49:
	/* 0x2c49: je     2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c49, 0x2c61, x86_l_2c61);
x86_l_2c4b:
	/* 0x2c4b: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_2c50:
	/* 0x2c50: jmp    2c61 <trace_ret_do_init_module+0x2c61> */
	X86_SIM_X86_JMP(0x2c50, 0x2c61, x86_l_2c61);
x86_l_2c52:
	/* 0x2c52: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2c5a:
	/* 0x2c5a: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c61:
	/* 0x2c61: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c64:
	/* 0x2c64: jns    2ced <trace_ret_do_init_module+0x2ced> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c64, 0x2ced, x86_l_2ced);
x86_l_2c6a:
	/* 0x2c6a: mov    rax,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c6d:
	/* 0x2c6d: mov    QWORD PTR [r12],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c71:
	/* 0x2c71: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c75:
	/* 0x2c75: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c7a:
	/* 0x2c7a: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c7e:
	/* 0x2c7e: mov    QWORD PTR [r12+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c83:
	/* 0x2c83: mov    rax,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c87:
	/* 0x2c87: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c8c:
	/* 0x2c8c: mov    rax,QWORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c90:
	/* 0x2c90: mov    QWORD PTR [r12+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c95:
	/* 0x2c95: mov    rax,QWORD PTR [rsi+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2c99:
	/* 0x2c99: mov    QWORD PTR [r12+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2c9e:
	/* 0x2c9e: mov    rax,QWORD PTR [rsi+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ca2:
	/* 0x2ca2: mov    QWORD PTR [r12+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ca7:
	/* 0x2ca7: mov    rax,QWORD PTR [rsi+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2cab:
	/* 0x2cab: mov    QWORD PTR [r12+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2cb0:
	/* 0x2cb0: mov    rax,QWORD PTR [rsi+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2cb4:
	/* 0x2cb4: mov    QWORD PTR [r12+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2cb9:
	/* 0x2cb9: mov    rax,QWORD PTR [rsi+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2cbd:
	/* 0x2cbd: mov    QWORD PTR [r12+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2cc2:
	/* 0x2cc2: mov    rax,QWORD PTR [rsi+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2cc6:
	/* 0x2cc6: mov    QWORD PTR [r12+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2ccb:
	/* 0x2ccb: mov    rax,QWORD PTR [rsi+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2ccf:
	/* 0x2ccf: mov    QWORD PTR [r12+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2cd4:
	/* 0x2cd4: mov    rax,QWORD PTR [rsi+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2cd8:
	/* 0x2cd8: mov    QWORD PTR [r12+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2cdd:
	/* 0x2cdd: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_2ce2:
	/* 0x2ce2: jne    2d68 <trace_ret_do_init_module+0x2d68> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ce2, 0x2d68, x86_l_2d68);
x86_l_2ce8:
	/* 0x2ce8: jmp    2d84 <trace_ret_do_init_module+0x2d84> */
	X86_SIM_X86_JMP(0x2ce8, 0x2d84, x86_l_2d84);
x86_l_2ced:
	/* 0x2ced: mov    QWORD PTR [r12+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_2cf6:
	/* 0x2cf6: mov    QWORD PTR [r12+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_2cff:
	/* 0x2cff: mov    QWORD PTR [r12+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_2d08:
	/* 0x2d08: mov    QWORD PTR [r12+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_2d11:
	/* 0x2d11: mov    QWORD PTR [r12+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2d1a:
	/* 0x2d1a: mov    QWORD PTR [r12+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_2d23:
	/* 0x2d23: mov    QWORD PTR [r12+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2d2c:
	/* 0x2d2c: mov    QWORD PTR [r12+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_2d35:
	/* 0x2d35: mov    QWORD PTR [r12+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2d3e:
	/* 0x2d3e: mov    QWORD PTR [r12+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2d47:
	/* 0x2d47: mov    QWORD PTR [r12+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2d50:
	/* 0x2d50: mov    QWORD PTR [r12+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2d59:
	/* 0x2d59: mov    QWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d61:
	/* 0x2d61: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_2d66:
	/* 0x2d66: je     2d84 <trace_ret_do_init_module+0x2d84> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d66, 0x2d84, x86_l_2d84);
x86_l_2d68:
	/* 0x2d68: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_2d6f:
	/* 0x2d6f: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_2d74:
	/* 0x2d74: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d77:
	/* 0x2d77: call   2d7c <trace_ret_do_init_module+0x2d7c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_2d7c:
	/* 0x2d7c: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d7e:
	/* 0x2d7e: js     2d84 <trace_ret_do_init_module+0x2d84> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2d7e, 0x2d84, x86_l_2d84);
x86_l_2d80:
	/* 0x2d80: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2d84:
	/* 0x2d84: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d8c:
	/* 0x2d8c: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2d91:
	/* 0x2d91: jb     2d98 <trace_ret_do_init_module+0x2d98> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d91, 0x2d98, x86_l_2d98);
x86_l_2d93:
	/* 0x2d93: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_2d98:
	/* 0x2d98: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_2d9d:
	/* 0x2d9d: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2da1:
	/* 0x2da1: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_2da8:
	/* 0x2da8: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_2dad:
	/* 0x2dad: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2db0:
	/* 0x2db0: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2db3:
	/* 0x2db3: call   2db8 <trace_ret_do_init_module+0x2db8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_2db8:
	/* 0x2db8: jmp    1cc3 <trace_ret_do_init_module+0x1cc3> */
	X86_SIM_X86_JMP(0x2db8, 0x1cc3, x86_l_1cc3);
x86_l_2dbd:
	/* 0x2dbd: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2dc0:
	/* 0x2dc0: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2dc4:
	/* 0x2dc4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dc7:
	/* 0x2dc7: jns    2f6c <trace_ret_do_init_module+0x2f6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2dc7, 0x2f6c, x86_l_2f6c);
x86_l_2dcd:
	/* 0x2dcd: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dd0:
	/* 0x2dd0: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_2dd7:
	/* 0x2dd7: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ddb:
	/* 0x2ddb: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_2de2:
	/* 0x2de2: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2de6:
	/* 0x2de6: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_2ded:
	/* 0x2ded: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2df1:
	/* 0x2df1: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_2df8:
	/* 0x2df8: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2dfc:
	/* 0x2dfc: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_2e03:
	/* 0x2e03: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2e07:
	/* 0x2e07: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_2e0e:
	/* 0x2e0e: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e12:
	/* 0x2e12: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_2e19:
	/* 0x2e19: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2e1d:
	/* 0x2e1d: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_2e24:
	/* 0x2e24: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2e28:
	/* 0x2e28: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_2e2f:
	/* 0x2e2f: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2e33:
	/* 0x2e33: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_2e3a:
	/* 0x2e3a: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2e3e:
	/* 0x2e3e: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_2e45:
	/* 0x2e45: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2e49:
	/* 0x2e49: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_2e50:
	/* 0x2e50: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2e54:
	/* 0x2e54: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_2e5b:
	/* 0x2e5b: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2e5f:
	/* 0x2e5f: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_2e66:
	/* 0x2e66: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2e6a:
	/* 0x2e6a: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_2e71:
	/* 0x2e71: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2e75:
	/* 0x2e75: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_2e7c:
	/* 0x2e7c: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2e83:
	/* 0x2e83: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_2e8a:
	/* 0x2e8a: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2e91:
	/* 0x2e91: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_2e98:
	/* 0x2e98: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2e9f:
	/* 0x2e9f: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_2ea6:
	/* 0x2ea6: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2ead:
	/* 0x2ead: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_2eb4:
	/* 0x2eb4: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_2ebb:
	/* 0x2ebb: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_2ec2:
	/* 0x2ec2: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2ec9:
	/* 0x2ec9: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_2ed0:
	/* 0x2ed0: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_2ed7:
	/* 0x2ed7: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_2ede:
	/* 0x2ede: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2ee5:
	/* 0x2ee5: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_2eec:
	/* 0x2eec: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2ef3:
	/* 0x2ef3: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_2efa:
	/* 0x2efa: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_2f01:
	/* 0x2f01: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_2f08:
	/* 0x2f08: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2f0f:
	/* 0x2f0f: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_2f16:
	/* 0x2f16: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2f1d:
	/* 0x2f1d: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_2f24:
	/* 0x2f24: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2f2b:
	/* 0x2f2b: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_2f32:
	/* 0x2f32: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2f39:
	/* 0x2f39: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_2f40:
	/* 0x2f40: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_2f47:
	/* 0x2f47: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_2f4e:
	/* 0x2f4e: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2f55:
	/* 0x2f55: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_2f5c:
	/* 0x2f5c: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2f62:
	/* 0x2f62: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_2f67:
	/* 0x2f67: jmp    87c <trace_ret_do_init_module+0x87c> */
	X86_SIM_X86_JMP(0x2f67, 0x87c, x86_l_87c);
x86_l_2f6c:
	/* 0x2f6c: add    r13,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_2f73:
	/* 0x2f73: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_2f78:
	/* 0x2f78: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2f7b:
	/* 0x2f7b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f7d:
	/* 0x2f7d: call   2f82 <trace_ret_do_init_module+0x2f82> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_2f82:
	/* 0x2f82: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f84:
	/* 0x2f84: jmp    1cc3 <trace_ret_do_init_module+0x1cc3> */
	X86_SIM_X86_JMP(0x2f84, 0x1cc3, x86_l_1cc3);
x86_l_2f89:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
