#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 72U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1)
#include "../x86_sim_local_bpf.h"

extern __u8 execve_heap[] __ksym;
extern __u8 execve_map[] __ksym;
extern __u8 tg_execve_joined_info_map[] __ksym;
extern __u8 tg_execve_joined_info_map_stats[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/security_bprm_committing_creds")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_e:
	/* 0xe: mov    r15,QWORD PTR [rdi+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_12:
	/* 0x12: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1a:
	/* 0x1a: call   1f <tg_kp_bprm_committing_creds+0x1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1f:
	/* 0x1f: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22:
	/* 0x22: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26:
	/* 0x26: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a:
	/* 0x2a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_31:
	/* 0x31: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_36:
	/* 0x36: call   3b <tg_kp_bprm_committing_creds+0x3b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3b:
	/* 0x3b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3e:
	/* 0x3e: je     2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3e, 0x2d5, x86_l_2d5);
x86_l_44:
	/* 0x44: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_heap));
x86_l_4b:
	/* 0x4b: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_50:
	/* 0x50: call   55 <tg_kp_bprm_committing_creds+0x55> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_55:
	/* 0x55: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58:
	/* 0x58: je     2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x58, 0x2d5, x86_l_2d5);
x86_l_5e:
	/* 0x5e: mov    QWORD PTR [rax+0x1008],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17626545782784ULL);
x86_l_69:
	/* 0x69: mov    QWORD PTR [rax+0x1000],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17592186044416ULL);
x86_l_74:
	/* 0x74: lea    rcx,[r15+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_78:
	/* 0x78: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7b:
	/* 0x7b: jns    2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7b, 0x2d5, x86_l_2d5);
x86_l_81:
	/* 0x81: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84:
	/* 0x84: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_88:
	/* 0x88: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8b:
	/* 0x8b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_8e:
	/* 0x8e: jns    ab <tg_kp_bprm_committing_creds+0xab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e, 0xab, x86_l_ab);
x86_l_90:
	/* 0x90: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_93:
	/* 0x93: add    rdx,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_97:
	/* 0x97: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_9a:
	/* 0x9a: js     b6 <tg_kp_bprm_committing_creds+0xb6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x9a, 0xb6, x86_l_b6);
x86_l_9c:
	/* 0x9c: mov    DWORD PTR [rax+0x1004],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17609365913600ULL);
x86_l_a6:
	/* 0xa6: jmp    2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JMP(0xa6, 0x2d5, x86_l_2d5);
x86_l_ab:
	/* 0xab: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ad:
	/* 0xad: add    rdx,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_b1:
	/* 0xb1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b4:
	/* 0xb4: jns    9c <tg_kp_bprm_committing_creds+0x9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb4, 0x9c, x86_l_9c);
x86_l_b6:
	/* 0xb6: mov    edx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b8:
	/* 0xb8: mov    DWORD PTR [rax+0x1004],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4100ULL);
x86_l_be:
	/* 0xbe: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_c1:
	/* 0xc1: jns    df <tg_kp_bprm_committing_creds+0xdf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc1, 0xdf, x86_l_df);
x86_l_c3:
	/* 0xc3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c6:
	/* 0xc6: add    rcx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_ca:
	/* 0xca: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cd:
	/* 0xcd: js     ea <tg_kp_bprm_committing_creds+0xea> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcd, 0xea, x86_l_ea);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rax+0x1008],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17626545782784ULL);
x86_l_da:
	/* 0xda: jmp    2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JMP(0xda, 0x2d5, x86_l_2d5);
x86_l_df:
	/* 0xdf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e1:
	/* 0xe1: add    rcx,0x40 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 64ULL);
x86_l_e5:
	/* 0xe5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e8:
	/* 0xe8: jns    cf <tg_kp_bprm_committing_creds+0xcf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe8, 0xcf, x86_l_cf);
x86_l_ea:
	/* 0xea: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed:
	/* 0xed: add    r14,0x1000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4096ULL);
x86_l_f4:
	/* 0xf4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7:
	/* 0xf7: mov    QWORD PTR [rax+0x1008],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4104ULL);
x86_l_fe:
	/* 0xfe: lea    rcx,[r15+0x54] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_102:
	/* 0x102: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_105:
	/* 0x105: jns    270 <tg_kp_bprm_committing_creds+0x270> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x105, 0x270, x86_l_270);
x86_l_10b:
	/* 0x10b: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10d:
	/* 0x10d: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_10f:
	/* 0x10f: je     270 <tg_kp_bprm_committing_creds+0x270> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10f, 0x270, x86_l_270);
x86_l_115:
	/* 0x115: add    r15,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_119:
	/* 0x119: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11c:
	/* 0x11c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11f:
	/* 0x11f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_122:
	/* 0x122: jns    129 <tg_kp_bprm_committing_creds+0x129> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x122, 0x129, x86_l_129);
x86_l_124:
	/* 0x124: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_127:
	/* 0x127: jmp    12b <tg_kp_bprm_committing_creds+0x12b> */
	X86_SIM_X86_JMP(0x127, 0x12b, x86_l_12b);
x86_l_129:
	/* 0x129: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12b:
	/* 0x12b: add    rcx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_12f:
	/* 0x12f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_132:
	/* 0x132: jns    137 <tg_kp_bprm_committing_creds+0x137> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x132, 0x137, x86_l_137);
x86_l_134:
	/* 0x134: mov    r12d,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137:
	/* 0x137: mov    rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_13a:
	/* 0x13a: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13d:
	/* 0x13d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_140:
	/* 0x140: jns    147 <tg_kp_bprm_committing_creds+0x147> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x140, 0x147, x86_l_147);
x86_l_142:
	/* 0x142: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_145:
	/* 0x145: jmp    149 <tg_kp_bprm_committing_creds+0x149> */
	X86_SIM_X86_JMP(0x145, 0x149, x86_l_149);
x86_l_147:
	/* 0x147: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_149:
	/* 0x149: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14c:
	/* 0x14c: add    rcx,0x1c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 28ULL);
x86_l_150:
	/* 0x150: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_153:
	/* 0x153: jns    158 <tg_kp_bprm_committing_creds+0x158> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x153, 0x158, x86_l_158);
x86_l_155:
	/* 0x155: mov    r13d,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158:
	/* 0x158: call   15d <tg_kp_bprm_committing_creds+0x15d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_15d:
	/* 0x15d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_160:
	/* 0x160: add    rcx,0xd00 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3328ULL);
x86_l_167:
	/* 0x167: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16a:
	/* 0x16a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c:
	/* 0x16c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16f:
	/* 0x16f: jns    176 <tg_kp_bprm_committing_creds+0x176> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f, 0x176, x86_l_176);
x86_l_171:
	/* 0x171: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_174:
	/* 0x174: jmp    178 <tg_kp_bprm_committing_creds+0x178> */
	X86_SIM_X86_JMP(0x174, 0x178, x86_l_178);
x86_l_176:
	/* 0x176: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_178:
	/* 0x178: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17c:
	/* 0x17c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_182:
	/* 0x182: jns    186 <tg_kp_bprm_committing_creds+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x182, 0x186, x86_l_186);
x86_l_184:
	/* 0x184: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_186:
	/* 0x186: mov    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_189:
	/* 0x189: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b:
	/* 0x18b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: jns    195 <tg_kp_bprm_committing_creds+0x195> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18e, 0x195, x86_l_195);
x86_l_190:
	/* 0x190: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_193:
	/* 0x193: jmp    197 <tg_kp_bprm_committing_creds+0x197> */
	X86_SIM_X86_JMP(0x193, 0x197, x86_l_197);
x86_l_195:
	/* 0x195: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_197:
	/* 0x197: add    rdi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_19b:
	/* 0x19b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_19e:
	/* 0x19e: jns    1a2 <tg_kp_bprm_committing_creds+0x1a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19e, 0x1a2, x86_l_1a2);
x86_l_1a0:
	/* 0x1a0: mov    esi,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a2:
	/* 0x1a2: cmp    r12d,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1a5:
	/* 0x1a5: je     1d2 <tg_kp_bprm_committing_creds+0x1d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a5, 0x1d2, x86_l_1d2);
x86_l_1a7:
	/* 0x1a7: or     BYTE PTR [r14],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 1ULL);
x86_l_1ab:
	/* 0x1ab: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ae:
	/* 0x1ae: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b1:
	/* 0x1b1: jns    1b8 <tg_kp_bprm_committing_creds+0x1b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b1, 0x1b8, x86_l_1b8);
x86_l_1b3:
	/* 0x1b3: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b6:
	/* 0x1b6: jmp    1ba <tg_kp_bprm_committing_creds+0x1ba> */
	X86_SIM_X86_JMP(0x1b6, 0x1ba, x86_l_1ba);
x86_l_1b8:
	/* 0x1b8: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ba:
	/* 0x1ba: add    rdi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1be:
	/* 0x1be: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c1:
	/* 0x1c1: jns    1d2 <tg_kp_bprm_committing_creds+0x1d2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c1, 0x1d2, x86_l_1d2);
x86_l_1c3:
	/* 0x1c3: mov    edi,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c5:
	/* 0x1c5: test   edi,edi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1c7:
	/* 0x1c7: je     1d2 <tg_kp_bprm_committing_creds+0x1d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c7, 0x1d2, x86_l_1d2);
x86_l_1c9:
	/* 0x1c9: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_1cc:
	/* 0x1cc: jne    1d2 <tg_kp_bprm_committing_creds+0x1d2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cc, 0x1d2, x86_l_1d2);
x86_l_1ce:
	/* 0x1ce: or     BYTE PTR [r14],0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 8ULL);
x86_l_1d2:
	/* 0x1d2: cmp    r13d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1d5:
	/* 0x1d5: je     202 <tg_kp_bprm_committing_creds+0x202> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d5, 0x202, x86_l_202);
x86_l_1d7:
	/* 0x1d7: or     BYTE PTR [r14],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 2ULL);
x86_l_1db:
	/* 0x1db: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1de:
	/* 0x1de: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e1:
	/* 0x1e1: jns    1e8 <tg_kp_bprm_committing_creds+0x1e8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e1, 0x1e8, x86_l_1e8);
x86_l_1e3:
	/* 0x1e3: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e6:
	/* 0x1e6: jmp    1ea <tg_kp_bprm_committing_creds+0x1ea> */
	X86_SIM_X86_JMP(0x1e6, 0x1ea, x86_l_1ea);
x86_l_1e8:
	/* 0x1e8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ea:
	/* 0x1ea: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1ee:
	/* 0x1ee: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f1:
	/* 0x1f1: jns    202 <tg_kp_bprm_committing_creds+0x202> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f1, 0x202, x86_l_202);
x86_l_1f3:
	/* 0x1f3: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5:
	/* 0x1f5: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1f7:
	/* 0x1f7: je     202 <tg_kp_bprm_committing_creds+0x202> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7, 0x202, x86_l_202);
x86_l_1f9:
	/* 0x1f9: test   r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1fc:
	/* 0x1fc: jne    202 <tg_kp_bprm_committing_creds+0x202> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fc, 0x202, x86_l_202);
x86_l_1fe:
	/* 0x1fe: or     BYTE PTR [r14],0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 16ULL);
x86_l_202:
	/* 0x202: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_205:
	/* 0x205: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_208:
	/* 0x208: jns    20f <tg_kp_bprm_committing_creds+0x20f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x208, 0x20f, x86_l_20f);
x86_l_20a:
	/* 0x20a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20d:
	/* 0x20d: jmp    211 <tg_kp_bprm_committing_creds+0x211> */
	X86_SIM_X86_JMP(0x20d, 0x211, x86_l_211);
x86_l_20f:
	/* 0x20f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_211:
	/* 0x211: add    rsi,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_215:
	/* 0x215: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_218:
	/* 0x218: jns    222 <tg_kp_bprm_committing_creds+0x222> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x218, 0x222, x86_l_222);
x86_l_21a:
	/* 0x21a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21d:
	/* 0x21d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_220:
	/* 0x220: jne    270 <tg_kp_bprm_committing_creds+0x270> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x220, 0x270, x86_l_270);
x86_l_222:
	/* 0x222: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_225:
	/* 0x225: jns    22c <tg_kp_bprm_committing_creds+0x22c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x225, 0x22c, x86_l_22c);
x86_l_227:
	/* 0x227: mov    rsi,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22a:
	/* 0x22a: jmp    22e <tg_kp_bprm_committing_creds+0x22e> */
	X86_SIM_X86_JMP(0x22a, 0x22e, x86_l_22e);
x86_l_22c:
	/* 0x22c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22e:
	/* 0x22e: add    rsi,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_232:
	/* 0x232: mov    rcx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_239:
	/* 0x239: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23c:
	/* 0x23c: jns    244 <tg_kp_bprm_committing_creds+0x244> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c, 0x244, x86_l_244);
x86_l_23e:
	/* 0x23e: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241:
	/* 0x241: not    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_244:
	/* 0x244: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_247:
	/* 0x247: jns    24e <tg_kp_bprm_committing_creds+0x24e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x247, 0x24e, x86_l_24e);
x86_l_249:
	/* 0x249: mov    rsi,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c:
	/* 0x24c: jmp    250 <tg_kp_bprm_committing_creds+0x250> */
	X86_SIM_X86_JMP(0x24c, 0x250, x86_l_250);
x86_l_24e:
	/* 0x24e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_250:
	/* 0x250: add    rsi,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_254:
	/* 0x254: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_257:
	/* 0x257: jns    25e <tg_kp_bprm_committing_creds+0x25e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x257, 0x25e, x86_l_25e);
x86_l_259:
	/* 0x259: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25c:
	/* 0x25c: jmp    260 <tg_kp_bprm_committing_creds+0x260> */
	X86_SIM_X86_JMP(0x25c, 0x260, x86_l_260);
x86_l_25e:
	/* 0x25e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_260:
	/* 0x260: cmp    r12d,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_263:
	/* 0x263: jne    270 <tg_kp_bprm_committing_creds+0x270> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x263, 0x270, x86_l_270);
x86_l_265:
	/* 0x265: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_268:
	/* 0x268: je     270 <tg_kp_bprm_committing_creds+0x270> */
	X86_SIM_X86_JCC(X86_CC_E, 0x268, 0x270, x86_l_270);
x86_l_26a:
	/* 0x26a: or     BYTE PTR [r14],0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 4ULL);
x86_l_26e:
	/* 0x26e: jmp    276 <tg_kp_bprm_committing_creds+0x276> */
	X86_SIM_X86_JMP(0x26e, 0x276, x86_l_276);
x86_l_270:
	/* 0x270: cmp    DWORD PTR [r14],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274:
	/* 0x274: je     29f <tg_kp_bprm_committing_creds+0x29f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x274, 0x29f, x86_l_29f);
x86_l_276:
	/* 0x276: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27b:
	/* 0x27b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map));
x86_l_282:
	/* 0x282: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_287:
	/* 0x287: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_28a:
	/* 0x28a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c:
	/* 0x28c: call   291 <tg_kp_bprm_committing_creds+0x291> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_291:
	/* 0x291: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_293:
	/* 0x293: je     2b4 <tg_kp_bprm_committing_creds+0x2b4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x293, 0x2b4, x86_l_2b4);
x86_l_295:
	/* 0x295: mov    DWORD PTR [rsp+0x4],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869185ULL);
x86_l_29d:
	/* 0x29d: jmp    2bc <tg_kp_bprm_committing_creds+0x2bc> */
	X86_SIM_X86_JMP(0x29d, 0x2bc, x86_l_2bc);
x86_l_29f:
	/* 0x29f: cmp    DWORD PTR [rax+0x1004],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17609365913600ULL);
x86_l_2a6:
	/* 0x2a6: jne    2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a6, 0x2d5, x86_l_2d5);
x86_l_2a8:
	/* 0x2a8: cmp    QWORD PTR [rax+0x1008],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 17626545782784ULL);
x86_l_2b0:
	/* 0x2b0: jne    276 <tg_kp_bprm_committing_creds+0x276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b0, 0x276, x86_l_276);
x86_l_2b2:
	/* 0x2b2: jmp    2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JMP(0x2b2, 0x2d5, x86_l_2d5);
x86_l_2b4:
	/* 0x2b4: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_2bc:
	/* 0x2bc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_execve_joined_info_map_stats));
x86_l_2c3:
	/* 0x2c3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c8:
	/* 0x2c8: call   2cd <tg_kp_bprm_committing_creds+0x2cd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2cd:
	/* 0x2cd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d0:
	/* 0x2d0: je     2d5 <tg_kp_bprm_committing_creds+0x2d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d0, 0x2d5, x86_l_2d5);
x86_l_2d2:
	/* 0x2d2: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2d5:
	/* 0x2d5: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2d9:
	/* 0x2d9: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2da:
	/* 0x2da: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2dc:
	/* 0x2dc: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2de:
	/* 0x2de: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2e0:
	/* 0x2e0: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2e2:
	/* 0x2e2: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2e3:
	/* 0x2e3: jmp    2e8 <tg_kp_bprm_committing_creds+0x2e8> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2e8:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
