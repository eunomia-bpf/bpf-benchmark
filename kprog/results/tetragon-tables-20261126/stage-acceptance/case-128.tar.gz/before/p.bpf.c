#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 120U
#define X86_SIM_STACK_VALUE_WORDS(M) M(3) M(6)
#include "../x86_sim_local_bpf.h"

extern __u8 cgroup_rate_map[] __ksym;
extern __u8 cgroup_rate_options_map[] __ksym;
extern __u8 execve_calls[] __ksym;
extern __u8 execve_msg_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
extern __u8 throttle_heap_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMCPY, X86_OP_CALL_MEMCPY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_DIV, X86_OP_DIV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("tracepoint")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_msg_heap_map));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25:
	/* 0x25: call   2a <execve_rate+0x2a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     35c <execve_rate+0x35c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0x35c, x86_l_35c);
x86_l_33:
	/* 0x33: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_37:
	/* 0x37: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a:
	/* 0x3a: mov    rax,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3e:
	/* 0x3e: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_43:
	/* 0x43: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_4b:
	/* 0x4b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_rate_options_map));
x86_l_52:
	/* 0x52: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_57:
	/* 0x57: call   5c <execve_rate+0x5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c:
	/* 0x5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: je     348 <execve_rate+0x348> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5f, 0x348, x86_l_348);
x86_l_65:
	/* 0x65: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_69:
	/* 0x69: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_6c:
	/* 0x6c: je     348 <execve_rate+0x348> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c, 0x348, x86_l_348);
x86_l_72:
	/* 0x72: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_75:
	/* 0x75: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_rate_map));
x86_l_7c:
	/* 0x7c: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_81:
	/* 0x81: call   86 <execve_rate+0x86> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_86:
	/* 0x86: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89:
	/* 0x89: je     c3 <execve_rate+0xc3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x89, 0xc3, x86_l_c3);
x86_l_8b:
	/* 0x8b: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e:
	/* 0x8e: mov    rsi,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_92:
	/* 0x92: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_95:
	/* 0x95: sub    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_98:
	/* 0x98: cmp    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9b:
	/* 0x9b: jbe    eb <execve_rate+0xeb> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x9b, 0xeb, x86_l_eb);
x86_l_9d:
	/* 0x9d: lea    rcx,[r12+r12*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R12, 0), 0ULL);
x86_l_a1:
	/* 0xa1: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a4:
	/* 0xa4: jbe    f4 <execve_rate+0xf4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa4, 0xf4, x86_l_f4);
x86_l_a6:
	/* 0xa6: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a9:
	/* 0xa9: or     rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ac:
	/* 0xac: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_b0:
	/* 0xb0: je     13b <execve_rate+0x13b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb0, 0x13b, x86_l_13b);
x86_l_b6:
	/* 0xb6: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_b9:
	/* 0xb9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bb:
	/* 0xbb: div    r12 */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_be:
	/* 0xbe: jmp    143 <execve_rate+0x143> */
	X86_SIM_X86_JMP(0xbe, 0x143, x86_l_143);
x86_l_c3:
	/* 0xc3: mov    QWORD PTR [rsp+0x20],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953473ULL);
x86_l_cc:
	/* 0xcc: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_d5:
	/* 0xd5: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d8:
	/* 0xd8: or     rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_db:
	/* 0xdb: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_df:
	/* 0xdf: je     fc <execve_rate+0xfc> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf, 0xfc, x86_l_fc);
x86_l_e1:
	/* 0xe1: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_e4:
	/* 0xe4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e6:
	/* 0xe6: div    r12 */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_e9:
	/* 0xe9: jmp    104 <execve_rate+0x104> */
	X86_SIM_X86_JMP(0xe9, 0x104, x86_l_104);
x86_l_eb:
	/* 0xeb: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee:
	/* 0xee: mov    rdx,QWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f2:
	/* 0xf2: jmp    155 <execve_rate+0x155> */
	X86_SIM_X86_JMP(0xf2, 0x155, x86_l_155);
x86_l_f4:
	/* 0xf4: mov    rdx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f7:
	/* 0xf7: add    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fa:
	/* 0xfa: jmp    14b <execve_rate+0x14b> */
	X86_SIM_X86_JMP(0xfa, 0x14b, x86_l_14b);
x86_l_fc:
	/* 0xfc: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_ff:
	/* 0xff: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_101:
	/* 0x101: div    r12d */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_104:
	/* 0x104: sub    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_107:
	/* 0x107: mov    QWORD PTR [rsp+0x30],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10c:
	/* 0x10c: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_115:
	/* 0x115: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_11e:
	/* 0x11e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_rate_map));
x86_l_125:
	/* 0x125: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_12a:
	/* 0x12a: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_12f:
	/* 0x12f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_131:
	/* 0x131: call   136 <execve_rate+0x136> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_136:
	/* 0x136: jmp    348 <execve_rate+0x348> */
	X86_SIM_X86_JMP(0x136, 0x348, x86_l_348);
x86_l_13b:
	/* 0x13b: mov    eax,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_13e:
	/* 0x13e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_140:
	/* 0x140: div    r12d */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_143:
	/* 0x143: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_146:
	/* 0x146: sub    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_149:
	/* 0x149: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14b:
	/* 0x14b: mov    QWORD PTR [r14+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14f:
	/* 0x14f: mov    QWORD PTR [r14+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_153:
	/* 0x153: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_155:
	/* 0x155: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_158:
	/* 0x158: mov    QWORD PTR [r14],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b:
	/* 0x15b: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_15e:
	/* 0x15e: sub    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_161:
	/* 0x161: add    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_164:
	/* 0x164: imul   rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_IMUL, 0);
x86_l_168:
	/* 0x168: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16b:
	/* 0x16b: or     rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_16e:
	/* 0x16e: shr    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_172:
	/* 0x172: je     18d <execve_rate+0x18d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172, 0x18d, x86_l_18d);
x86_l_174:
	/* 0x174: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_176:
	/* 0x176: div    r12 */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_179:
	/* 0x179: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17c:
	/* 0x17c: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_180:
	/* 0x180: cmp    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_185:
	/* 0x185: jne    35c <execve_rate+0x35c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x185, 0x35c, x86_l_35c);
x86_l_18b:
	/* 0x18b: jmp    1a4 <execve_rate+0x1a4> */
	X86_SIM_X86_JMP(0x18b, 0x1a4, x86_l_1a4);
x86_l_18d:
	/* 0x18d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18f:
	/* 0x18f: div    r12d */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_192:
	/* 0x192: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_195:
	/* 0x195: mov    QWORD PTR [r14+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_199:
	/* 0x199: cmp    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_19e:
	/* 0x19e: jne    35c <execve_rate+0x35c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x19e, 0x35c, x86_l_35c);
x86_l_1a4:
	/* 0x1a4: cmp    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 0ULL);
x86_l_1a8:
	/* 0x1a8: jb     348 <execve_rate+0x348> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a8, 0x348, x86_l_348);
x86_l_1ae:
	/* 0x1ae: mov    QWORD PTR [r14+0x20],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b2:
	/* 0x1b2: mov    DWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1ba:
	/* 0x1ba: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)throttle_heap_map));
x86_l_1c1:
	/* 0x1c1: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c6:
	/* 0x1c6: call   1cb <execve_rate+0x1cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cb:
	/* 0x1cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ce:
	/* 0x1ce: je     341 <execve_rate+0x341> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce, 0x341, x86_l_341);
x86_l_1d4:
	/* 0x1d4: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d7:
	/* 0x1d7: mov    DWORD PTR [rax+0x4],0xa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869344ULL);
x86_l_1de:
	/* 0x1de: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1e1:
	/* 0x1e1: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1e5:
	/* 0x1e5: mov    QWORD PTR [rax+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e9:
	/* 0x1e9: mov    WORD PTR [rax],0x1b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 27ULL);
x86_l_1ee:
	/* 0x1ee: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f1:
	/* 0x1f1: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1f5:
	/* 0x1f5: mov    edx,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1fa:
	/* 0x1fa: call   1ff <execve_rate+0x1ff> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMCPY, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 144ULL);
x86_l_1ff:
	/* 0x1ff: mov    DWORD PTR [rsp+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_207:
	/* 0x207: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_20e:
	/* 0x20e: lea    rsi,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_213:
	/* 0x213: call   218 <execve_rate+0x218> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_218:
	/* 0x218: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b:
	/* 0x21b: je     293 <execve_rate+0x293> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b, 0x293, x86_l_293);
x86_l_21d:
	/* 0x21d: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_221:
	/* 0x221: je     293 <execve_rate+0x293> */
	X86_SIM_X86_JCC(X86_CC_E, 0x221, 0x293, x86_l_293);
x86_l_223:
	/* 0x223: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_22a:
	/* 0x22a: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_22f:
	/* 0x22f: mov    r8d,0xa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 160ULL);
x86_l_235:
	/* 0x235: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_238:
	/* 0x238: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_23b:
	/* 0x23b: call   240 <execve_rate+0x240> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_240:
	/* 0x240: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_243:
	/* 0x243: jns    341 <execve_rate+0x341> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x243, 0x341, x86_l_341);
x86_l_249:
	/* 0x249: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24c:
	/* 0x24c: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_254:
	/* 0x254: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_25b:
	/* 0x25b: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_260:
	/* 0x260: call   265 <execve_rate+0x265> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_265:
	/* 0x265: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_268:
	/* 0x268: je     341 <execve_rate+0x341> */
	X86_SIM_X86_JCC(X86_CC_E, 0x268, 0x341, x86_l_341);
x86_l_26e:
	/* 0x26e: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_272:
	/* 0x272: jg     30d <execve_rate+0x30d> */
	X86_SIM_X86_JCC(X86_CC_G, 0x272, 0x30d, x86_l_30d);
x86_l_278:
	/* 0x278: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_27c:
	/* 0x27c: je     327 <execve_rate+0x327> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c, 0x327, x86_l_327);
x86_l_282:
	/* 0x282: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_286:
	/* 0x286: jne    2e5 <execve_rate+0x2e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x286, 0x2e5, x86_l_2e5);
x86_l_288:
	/* 0x288: add    rax,0x608 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1544ULL);
x86_l_28e:
	/* 0x28e: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x28e, 0x33d, x86_l_33d);
x86_l_293:
	/* 0x293: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_29a:
	/* 0x29a: mov    edx,0xa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 160ULL);
x86_l_29f:
	/* 0x29f: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2a2:
	/* 0x2a2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a4:
	/* 0x2a4: call   2a9 <execve_rate+0x2a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_2a9:
	/* 0x2a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ac:
	/* 0x2ac: jns    341 <execve_rate+0x341> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ac, 0x341, x86_l_341);
x86_l_2b2:
	/* 0x2b2: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b5:
	/* 0x2b5: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2bd:
	/* 0x2bd: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_2c4:
	/* 0x2c4: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c9:
	/* 0x2c9: call   2ce <execve_rate+0x2ce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ce:
	/* 0x2ce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d1:
	/* 0x2d1: je     341 <execve_rate+0x341> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d1, 0x341, x86_l_341);
x86_l_2d3:
	/* 0x2d3: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_2d7:
	/* 0x2d7: jg     2f3 <execve_rate+0x2f3> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2d7, 0x2f3, x86_l_2f3);
x86_l_2d9:
	/* 0x2d9: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_2dd:
	/* 0x2dd: je     327 <execve_rate+0x327> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dd, 0x327, x86_l_327);
x86_l_2df:
	/* 0x2df: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_2e3:
	/* 0x2e3: je     288 <execve_rate+0x288> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e3, 0x288, x86_l_288);
x86_l_2e5:
	/* 0x2e5: cmp    r15,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_2e9:
	/* 0x2e9: jne    31f <execve_rate+0x31f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e9, 0x31f, x86_l_31f);
x86_l_2eb:
	/* 0x2eb: add    rax,0x600 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1536ULL);
x86_l_2f1:
	/* 0x2f1: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x2f1, 0x33d, x86_l_33d);
x86_l_2f3:
	/* 0x2f3: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_2f7:
	/* 0x2f7: je     32f <execve_rate+0x32f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f7, 0x32f, x86_l_32f);
x86_l_2f9:
	/* 0x2f9: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_2fd:
	/* 0x2fd: je     337 <execve_rate+0x337> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fd, 0x337, x86_l_337);
x86_l_2ff:
	/* 0x2ff: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_303:
	/* 0x303: jne    31f <execve_rate+0x31f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x303, 0x31f, x86_l_31f);
x86_l_305:
	/* 0x305: add    rax,0x5f0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1520ULL);
x86_l_30b:
	/* 0x30b: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x30b, 0x33d, x86_l_33d);
x86_l_30d:
	/* 0x30d: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_311:
	/* 0x311: je     32f <execve_rate+0x32f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x311, 0x32f, x86_l_32f);
x86_l_313:
	/* 0x313: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_317:
	/* 0x317: je     337 <execve_rate+0x337> */
	X86_SIM_X86_JCC(X86_CC_E, 0x317, 0x337, x86_l_337);
x86_l_319:
	/* 0x319: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_31d:
	/* 0x31d: je     305 <execve_rate+0x305> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31d, 0x305, x86_l_305);
x86_l_31f:
	/* 0x31f: add    rax,0x5e8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1512ULL);
x86_l_325:
	/* 0x325: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x325, 0x33d, x86_l_33d);
x86_l_327:
	/* 0x327: add    rax,0x610 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1552ULL);
x86_l_32d:
	/* 0x32d: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x32d, 0x33d, x86_l_33d);
x86_l_32f:
	/* 0x32f: add    rax,0x618 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1560ULL);
x86_l_335:
	/* 0x335: jmp    33d <execve_rate+0x33d> */
	X86_SIM_X86_JMP(0x335, 0x33d, x86_l_33d);
x86_l_337:
	/* 0x337: add    rax,0x5f8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 1528ULL);
x86_l_33d:
	/* 0x33d: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_341:
	/* 0x341: cmp    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_346:
	/* 0x346: jne    35c <execve_rate+0x35c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x346, 0x35c, x86_l_35c);
x86_l_348:
	/* 0x348: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_calls));
x86_l_34f:
	/* 0x34f: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_352:
	/* 0x352: mov    edx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_357:
	/* 0x357: call   35c <execve_rate+0x35c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_35c:
	/* 0x35c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35e:
	/* 0x35e: add    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_362:
	/* 0x362: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_363:
	/* 0x363: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_365:
	/* 0x365: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_367:
	/* 0x367: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_369:
	/* 0x369: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_36b:
	/* 0x36b: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_36c:
	/* 0x36c: jmp    371 <execve_rate+0x371> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_371:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
