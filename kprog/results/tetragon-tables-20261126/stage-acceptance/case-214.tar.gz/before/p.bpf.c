#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 232U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(18) M(19) M(22)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 fd_arg_path_map[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 sys_enter_tails[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/sys_enter_submit")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0xac],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 738734374912ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_2e:
	/* 0x2e: call   33 <sys_enter_submit+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x32f7, x86_l_32f7);
x86_l_3c:
	/* 0x3c: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0xac] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 172ULL);
x86_l_4e:
	/* 0x4e: call   53 <sys_enter_submit+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x32f7, x86_l_32f7);
x86_l_5c:
	/* 0x5c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [r15+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6c:
	/* 0x6c: mov    BYTE PTR [r15+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_74:
	/* 0x74: mov    QWORD PTR [r15+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7f:
	/* 0x7f: mov    QWORD PTR [r15+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_8a:
	/* 0x8a: mov    QWORD PTR [r15+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_95:
	/* 0x95: mov    QWORD PTR [r15+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_a0:
	/* 0xa0: mov    QWORD PTR [r15+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_ab:
	/* 0xab: mov    QWORD PTR [r15+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b6:
	/* 0xb6: mov    QWORD PTR [r15+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_c1:
	/* 0xc1: mov    QWORD PTR [r15+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_cc:
	/* 0xcc: call   d1 <sys_enter_submit+0xd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_d1:
	/* 0xd1: mov    QWORD PTR [r15+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d8:
	/* 0xd8: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_e0:
	/* 0xe0: mov    QWORD PTR [r15+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e8:
	/* 0xe8: mov    QWORD PTR [r15+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_f0:
	/* 0xf0: mov    QWORD PTR [r15+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f8:
	/* 0xf8: mov    QWORD PTR [r15+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_100:
	/* 0x100: mov    QWORD PTR [r15+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_108:
	/* 0x108: mov    QWORD PTR [r15+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_110:
	/* 0x110: mov    QWORD PTR [r15+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_118:
	/* 0x118: mov    QWORD PTR [r15+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_120:
	/* 0x120: mov    QWORD PTR [r15+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_128:
	/* 0x128: mov    QWORD PTR [r15+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_130:
	/* 0x130: mov    QWORD PTR [r15+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_138:
	/* 0x138: mov    QWORD PTR [r15+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_140:
	/* 0x140: call   145 <sys_enter_submit+0x145> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_145:
	/* 0x145: mov    DWORD PTR [r15+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_149:
	/* 0x149: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [r15+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_151:
	/* 0x151: mov    DWORD PTR [r15+0x70],0x31b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337947ULL);
x86_l_159:
	/* 0x159: call   15e <sys_enter_submit+0x15e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_15e:
	/* 0x15e: mov    QWORD PTR [r15],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_161:
	/* 0x161: call   166 <sys_enter_submit+0x166> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_166:
	/* 0x166: mov    WORD PTR [r15+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_16b:
	/* 0x16b: call   170 <sys_enter_submit+0x170> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_170:
	/* 0x170: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_173:
	/* 0x173: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_177:
	/* 0x177: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17a:
	/* 0x17a: jns    18b <sys_enter_submit+0x18b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17a, 0x18b, x86_l_18b);
x86_l_17c:
	/* 0x17c: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17e:
	/* 0x17e: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_183:
	/* 0x183: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_189:
	/* 0x189: jne    1c8 <sys_enter_submit+0x1c8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x189, 0x1c8, x86_l_1c8);
x86_l_18b:
	/* 0x18b: call   190 <sys_enter_submit+0x190> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_190:
	/* 0x190: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_193:
	/* 0x193: call   198 <sys_enter_submit+0x198> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_198:
	/* 0x198: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_19c:
	/* 0x19c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19f:
	/* 0x19f: jns    1af <sys_enter_submit+0x1af> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19f, 0x1af, x86_l_1af);
x86_l_1a1:
	/* 0x1a1: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a4:
	/* 0x1a4: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1a8:
	/* 0x1a8: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1ab:
	/* 0x1ab: js     1ba <sys_enter_submit+0x1ba> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ab, 0x1ba, x86_l_1ba);
x86_l_1ad:
	/* 0x1ad: jmp    1c4 <sys_enter_submit+0x1c4> */
	X86_SIM_X86_JMP(0x1ad, 0x1c4, x86_l_1c4);
x86_l_1af:
	/* 0x1af: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b1:
	/* 0x1b1: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1b5:
	/* 0x1b5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b8:
	/* 0x1b8: jns    1c4 <sys_enter_submit+0x1c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b8, 0x1c4, x86_l_1c4);
x86_l_1ba:
	/* 0x1ba: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bc:
	/* 0x1bc: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1be:
	/* 0x1be: jne    557 <sys_enter_submit+0x557> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1be, 0x557, x86_l_557);
x86_l_1c4:
	/* 0x1c4: mov    eax,DWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1c8:
	/* 0x1c8: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1cc:
	/* 0x1cc: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d0:
	/* 0x1d0: mov    DWORD PTR [rsp+0xa8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d7:
	/* 0x1d7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1de:
	/* 0x1de: lea    rsi,[rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1e6:
	/* 0x1e6: call   1eb <sys_enter_submit+0x1eb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1eb:
	/* 0x1eb: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f0:
	/* 0x1f0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f3:
	/* 0x1f3: je     10cf <sys_enter_submit+0x10cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f3, 0x10cf, x86_l_10cf);
x86_l_1f9:
	/* 0x1f9: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1fd:
	/* 0x1fd: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_204:
	/* 0x204: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_20b:
	/* 0x20b: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_213:
	/* 0x213: call   218 <sys_enter_submit+0x218> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_218:
	/* 0x218: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b:
	/* 0x21b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21e:
	/* 0x21e: je     115e <sys_enter_submit+0x115e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e, 0x115e, x86_l_115e);
x86_l_224:
	/* 0x224: test   BYTE PTR [rbp+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_228:
	/* 0x228: jne    231 <sys_enter_submit+0x231> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x228, 0x231, x86_l_231);
x86_l_22a:
	/* 0x22a: call   22f <sys_enter_submit+0x22f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_22f:
	/* 0x22f: jmp    289 <sys_enter_submit+0x289> */
	X86_SIM_X86_JMP(0x22f, 0x289, x86_l_289);
x86_l_231:
	/* 0x231: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_236:
	/* 0x236: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_23d:
	/* 0x23d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_240:
	/* 0x240: jns    25a <sys_enter_submit+0x25a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x240, 0x25a, x86_l_25a);
x86_l_242:
	/* 0x242: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_245:
	/* 0x245: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_248:
	/* 0x248: js     261 <sys_enter_submit+0x261> */
	X86_SIM_X86_JCC(X86_CC_S, 0x248, 0x261, x86_l_261);
x86_l_24a:
	/* 0x24a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24c:
	/* 0x24c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24f:
	/* 0x24f: js     269 <sys_enter_submit+0x269> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24f, 0x269, x86_l_269);
x86_l_251:
	/* 0x251: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_253:
	/* 0x253: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_256:
	/* 0x256: js     271 <sys_enter_submit+0x271> */
	X86_SIM_X86_JCC(X86_CC_S, 0x256, 0x271, x86_l_271);
x86_l_258:
	/* 0x258: jmp    287 <sys_enter_submit+0x287> */
	X86_SIM_X86_JMP(0x258, 0x287, x86_l_287);
x86_l_25a:
	/* 0x25a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25c:
	/* 0x25c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25f:
	/* 0x25f: jns    24a <sys_enter_submit+0x24a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25f, 0x24a, x86_l_24a);
x86_l_261:
	/* 0x261: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264:
	/* 0x264: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_267:
	/* 0x267: jns    251 <sys_enter_submit+0x251> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x267, 0x251, x86_l_251);
x86_l_269:
	/* 0x269: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c:
	/* 0x26c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26f:
	/* 0x26f: jns    287 <sys_enter_submit+0x287> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f, 0x287, x86_l_287);
x86_l_271:
	/* 0x271: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274:
	/* 0x274: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_277:
	/* 0x277: je     287 <sys_enter_submit+0x287> */
	X86_SIM_X86_JCC(X86_CC_E, 0x277, 0x287, x86_l_287);
x86_l_279:
	/* 0x279: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_27d:
	/* 0x27d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_280:
	/* 0x280: jns    287 <sys_enter_submit+0x287> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x280, 0x287, x86_l_287);
x86_l_282:
	/* 0x282: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_285:
	/* 0x285: jmp    289 <sys_enter_submit+0x289> */
	X86_SIM_X86_JMP(0x285, 0x289, x86_l_289);
x86_l_287:
	/* 0x287: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_289:
	/* 0x289: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28d:
	/* 0x28d: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_292:
	/* 0x292: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_296:
	/* 0x296: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_29d:
	/* 0x29d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2a2:
	/* 0x2a2: call   2a7 <sys_enter_submit+0x2a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a7:
	/* 0x2a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aa:
	/* 0x2aa: je     2c4 <sys_enter_submit+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2aa, 0x2c4, x86_l_2c4);
x86_l_2ac:
	/* 0x2ac: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2af:
	/* 0x2af: mov    BYTE PTR [r12+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2b7:
	/* 0x2b7: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2ba:
	/* 0x2ba: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2bd:
	/* 0x2bd: jne    2c4 <sys_enter_submit+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bd, 0x2c4, x86_l_2c4);
x86_l_2bf:
	/* 0x2bf: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2c4:
	/* 0x2c4: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2c9:
	/* 0x2c9: cmp    ax,WORD PTR [rbp+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RBP, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2cd:
	/* 0x2cd: jne    1205 <sys_enter_submit+0x1205> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cd, 0x1205, x86_l_1205);
x86_l_2d3:
	/* 0x2d3: mov    QWORD PTR [r14+0x80],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 554050781183ULL);
x86_l_2de:
	/* 0x2de: lea    rcx,[r15+0x7d8c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2e5:
	/* 0x2e5: mov    edx,DWORD PTR [r12+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2ea:
	/* 0x2ea: mov    DWORD PTR [r14+0x70],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2ee:
	/* 0x2ee: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_2f8:
	/* 0x2f8: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_300:
	/* 0x300: mov    QWORD PTR [rcx+0x38],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 244813135871ULL);
x86_l_308:
	/* 0x308: mov    QWORD PTR [rcx+0x30],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 210453397503ULL);
x86_l_310:
	/* 0x310: mov    QWORD PTR [rcx+0x28],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176093659135ULL);
x86_l_318:
	/* 0x318: mov    QWORD PTR [rcx+0x20],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 141733920767ULL);
x86_l_320:
	/* 0x320: mov    QWORD PTR [rcx+0x18],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 107374182399ULL);
x86_l_328:
	/* 0x328: mov    QWORD PTR [rcx+0x10],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 73014444031ULL);
x86_l_330:
	/* 0x330: mov    QWORD PTR [rcx+0x8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 38654705663ULL);
x86_l_338:
	/* 0x338: mov    QWORD PTR [rcx],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4294967295ULL);
x86_l_33f:
	/* 0x33f: mov    QWORD PTR [r14+0x7dd8],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138370961375231ULL);
x86_l_34a:
	/* 0x34a: mov    DWORD PTR [rsp+0x40],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_34e:
	/* 0x34e: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_353:
	/* 0x353: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_35a:
	/* 0x35a: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_35f:
	/* 0x35f: call   364 <sys_enter_submit+0x364> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_364:
	/* 0x364: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_367:
	/* 0x367: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x367, 0x32f7, x86_l_32f7);
x86_l_36d:
	/* 0x36d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_372:
	/* 0x372: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_375:
	/* 0x375: call   37a <sys_enter_submit+0x37a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_37a:
	/* 0x37a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_37d:
	/* 0x37d: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x37d, 0x32f7, x86_l_32f7);
x86_l_383:
	/* 0x383: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_387:
	/* 0x387: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_38e:
	/* 0x38e: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_391:
	/* 0x391: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_398:
	/* 0x398: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_39f:
	/* 0x39f: mov    rdx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_3a3:
	/* 0x3a3: mov    QWORD PTR [r14+0x7e10],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_3aa:
	/* 0x3aa: mov    rdx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3ae:
	/* 0x3ae: mov    QWORD PTR [r14+0x7e08],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_3b5:
	/* 0x3b5: mov    rdx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3b9:
	/* 0x3b9: mov    QWORD PTR [r14+0x7e00],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_3c0:
	/* 0x3c0: mov    rdx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3c4:
	/* 0x3c4: mov    QWORD PTR [r14+0x7df8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_3cb:
	/* 0x3cb: mov    rdx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3cf:
	/* 0x3cf: mov    rax,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d3:
	/* 0x3d3: mov    QWORD PTR [r14+0x7df0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_3da:
	/* 0x3da: mov    QWORD PTR [r14+0x7de8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_3e1:
	/* 0x3e1: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3e4:
	/* 0x3e4: cmp    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_3e8:
	/* 0x3e8: mov    QWORD PTR [rsp],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ec:
	/* 0x3ec: jne    405 <sys_enter_submit+0x405> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3ec, 0x405, x86_l_405);
x86_l_3ee:
	/* 0x3ee: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f0:
	/* 0x3f0: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_3f3:
	/* 0x3f3: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3fa:
	/* 0x3fa: jne    d4e <sys_enter_submit+0xd4e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3fa, 0xd4e, x86_l_d4e);
x86_l_400:
	/* 0x400: jmp    32e3 <sys_enter_submit+0x32e3> */
	X86_SIM_X86_JMP(0x400, 0x32e3, x86_l_32e3);
x86_l_405:
	/* 0x405: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_40c:
	/* 0x40c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_40f:
	/* 0x40f: je     5d8 <sys_enter_submit+0x5d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x40f, 0x5d8, x86_l_5d8);
x86_l_415:
	/* 0x415: movzx  ecx,BYTE PTR [r12+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_41e:
	/* 0x41e: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_421:
	/* 0x421: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_423:
	/* 0x423: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_426:
	/* 0x426: sete   sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_42a:
	/* 0x42a: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_42d:
	/* 0x42d: neg    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_430:
	/* 0x430: xor    rsi,QWORD PTR [r14+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_437:
	/* 0x437: or     rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_43a:
	/* 0x43a: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_441:
	/* 0x441: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_444:
	/* 0x444: je     467 <sys_enter_submit+0x467> */
	X86_SIM_X86_JCC(X86_CC_E, 0x444, 0x467, x86_l_467);
x86_l_446:
	/* 0x446: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_448:
	/* 0x448: cmp    BYTE PTR [r12+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_451:
	/* 0x451: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_454:
	/* 0x454: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_457:
	/* 0x457: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_45a:
	/* 0x45a: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_461:
	/* 0x461: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_464:
	/* 0x464: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_467:
	/* 0x467: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_46e:
	/* 0x46e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_471:
	/* 0x471: je     48d <sys_enter_submit+0x48d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x471, 0x48d, x86_l_48d);
x86_l_473:
	/* 0x473: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_477:
	/* 0x477: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_47a:
	/* 0x47a: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_47d:
	/* 0x47d: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_480:
	/* 0x480: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_487:
	/* 0x487: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_48a:
	/* 0x48a: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_48d:
	/* 0x48d: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_494:
	/* 0x494: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_497:
	/* 0x497: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_49c:
	/* 0x49c: je     4ba <sys_enter_submit+0x4ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x49c, 0x4ba, x86_l_4ba);
x86_l_49e:
	/* 0x49e: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4a1:
	/* 0x4a1: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_4a6:
	/* 0x4a6: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_4aa:
	/* 0x4aa: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_4ad:
	/* 0x4ad: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_4b4:
	/* 0x4b4: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_4b7:
	/* 0x4b7: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_4ba:
	/* 0x4ba: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4bf:
	/* 0x4bf: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_4c4:
	/* 0x4c4: mov    r13,QWORD PTR [r14+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_4cb:
	/* 0x4cb: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_4ce:
	/* 0x4ce: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_4d3:
	/* 0x4d3: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4d8:
	/* 0x4d8: je     655 <sys_enter_submit+0x655> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d8, 0x655, x86_l_655);
x86_l_4de:
	/* 0x4de: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_4e6:
	/* 0x4e6: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_4ed:
	/* 0x4ed: mov    QWORD PTR [rsp+0xb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_4f5:
	/* 0x4f5: mov    r12,QWORD PTR [r14+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_4fc:
	/* 0x4fc: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_503:
	/* 0x503: mov    QWORD PTR [rsp+0x98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_50b:
	/* 0x50b: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_510:
	/* 0x510: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_517:
	/* 0x517: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_51c:
	/* 0x51c: call   521 <sys_enter_submit+0x521> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_521:
	/* 0x521: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_524:
	/* 0x524: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_528:
	/* 0x528: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_52d:
	/* 0x52d: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_534:
	/* 0x534: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_537:
	/* 0x537: je     578 <sys_enter_submit+0x578> */
	X86_SIM_X86_JCC(X86_CC_E, 0x537, 0x578, x86_l_578);
x86_l_539:
	/* 0x539: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_53e:
	/* 0x53e: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_541:
	/* 0x541: call   546 <sys_enter_submit+0x546> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_546:
	/* 0x546: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_549:
	/* 0x549: je     578 <sys_enter_submit+0x578> */
	X86_SIM_X86_JCC(X86_CC_E, 0x549, 0x578, x86_l_578);
x86_l_54b:
	/* 0x54b: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_54e:
	/* 0x54e: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_552:
	/* 0x552: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_555:
	/* 0x555: jmp    57a <sys_enter_submit+0x57a> */
	X86_SIM_X86_JMP(0x555, 0x57a, x86_l_57a);
x86_l_557:
	/* 0x557: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_55e:
	/* 0x55e: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_563:
	/* 0x563: call   568 <sys_enter_submit+0x568> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_568:
	/* 0x568: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56b:
	/* 0x56b: je     5f4 <sys_enter_submit+0x5f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56b, 0x5f4, x86_l_5f4);
x86_l_571:
	/* 0x571: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_573:
	/* 0x573: jmp    1c8 <sys_enter_submit+0x1c8> */
	X86_SIM_X86_JMP(0x573, 0x1c8, x86_l_1c8);
x86_l_578:
	/* 0x578: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_57a:
	/* 0x57a: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_582:
	/* 0x582: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_587:
	/* 0x587: dec    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_58a:
	/* 0x58a: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_58d:
	/* 0x58d: jb     5a5 <sys_enter_submit+0x5a5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x58d, 0x5a5, x86_l_5a5);
x86_l_58f:
	/* 0x58f: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_593:
	/* 0x593: je     59a <sys_enter_submit+0x59a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x593, 0x59a, x86_l_59a);
x86_l_595:
	/* 0x595: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_598:
	/* 0x598: jbe    5a5 <sys_enter_submit+0x5a5> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x598, 0x5a5, x86_l_5a5);
x86_l_59a:
	/* 0x59a: and    r15,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 176ULL);
x86_l_5a2:
	/* 0x5a2: or     rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5a5:
	/* 0x5a5: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_5a9:
	/* 0x5a9: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5ae:
	/* 0x5ae: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5b5:
	/* 0x5b5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5b8:
	/* 0x5b8: je     5fe <sys_enter_submit+0x5fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b8, 0x5fe, x86_l_5fe);
x86_l_5ba:
	/* 0x5ba: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5bf:
	/* 0x5bf: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5c2:
	/* 0x5c2: call   5c7 <sys_enter_submit+0x5c7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5c7:
	/* 0x5c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ca:
	/* 0x5ca: je     617 <sys_enter_submit+0x617> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ca, 0x617, x86_l_617);
x86_l_5cc:
	/* 0x5cc: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5cf:
	/* 0x5cf: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5d3:
	/* 0x5d3: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5d6:
	/* 0x5d6: jmp    619 <sys_enter_submit+0x619> */
	X86_SIM_X86_JMP(0x5d6, 0x619, x86_l_619);
x86_l_5d8:
	/* 0x5d8: mov    rsi,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5df:
	/* 0x5df: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_5e6:
	/* 0x5e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5e9:
	/* 0x5e9: jne    446 <sys_enter_submit+0x446> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5e9, 0x446, x86_l_446);
x86_l_5ef:
	/* 0x5ef: jmp    467 <sys_enter_submit+0x467> */
	X86_SIM_X86_JMP(0x5ef, 0x467, x86_l_467);
x86_l_5f4:
	/* 0x5f4: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_5f9:
	/* 0x5f9: jmp    1c8 <sys_enter_submit+0x1c8> */
	X86_SIM_X86_JMP(0x5f9, 0x1c8, x86_l_1c8);
x86_l_5fe:
	/* 0x5fe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_600:
	/* 0x600: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_608:
	/* 0x608: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_60b:
	/* 0x60b: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_610:
	/* 0x610: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_613:
	/* 0x613: jae    636 <sys_enter_submit+0x636> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x613, 0x636, x86_l_636);
x86_l_615:
	/* 0x615: jmp    64c <sys_enter_submit+0x64c> */
	X86_SIM_X86_JMP(0x615, 0x64c, x86_l_64c);
x86_l_617:
	/* 0x617: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_619:
	/* 0x619: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_621:
	/* 0x621: mov    rdx,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_629:
	/* 0x629: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_62c:
	/* 0x62c: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_631:
	/* 0x631: cmp    r12,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_634:
	/* 0x634: jb     64c <sys_enter_submit+0x64c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x634, 0x64c, x86_l_64c);
x86_l_636:
	/* 0x636: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_63a:
	/* 0x63a: je     641 <sys_enter_submit+0x641> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63a, 0x641, x86_l_641);
x86_l_63c:
	/* 0x63c: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_63f:
	/* 0x63f: jbe    64c <sys_enter_submit+0x64c> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x63f, 0x64c, x86_l_64c);
x86_l_641:
	/* 0x641: and    r15,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 176ULL);
x86_l_649:
	/* 0x649: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_64c:
	/* 0x64c: or     rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_64f:
	/* 0x64f: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_652:
	/* 0x652: and    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_655:
	/* 0x655: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_65d:
	/* 0x65d: je     730 <sys_enter_submit+0x730> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65d, 0x730, x86_l_730);
x86_l_663:
	/* 0x663: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_66b:
	/* 0x66b: call   670 <sys_enter_submit+0x670> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_670:
	/* 0x670: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_674:
	/* 0x674: mov    rbx,QWORD PTR [r14+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_67b:
	/* 0x67b: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_682:
	/* 0x682: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_68a:
	/* 0x68a: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_691:
	/* 0x691: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_698:
	/* 0x698: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_69d:
	/* 0x69d: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6a2:
	/* 0x6a2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_6a9:
	/* 0x6a9: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6ae:
	/* 0x6ae: call   6b3 <sys_enter_submit+0x6b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6b3:
	/* 0x6b3: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6b7:
	/* 0x6b7: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6bc:
	/* 0x6bc: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6c3:
	/* 0x6c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c6:
	/* 0x6c6: je     6e6 <sys_enter_submit+0x6e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c6, 0x6e6, x86_l_6e6);
x86_l_6c8:
	/* 0x6c8: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6cd:
	/* 0x6cd: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d0:
	/* 0x6d0: call   6d5 <sys_enter_submit+0x6d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d5:
	/* 0x6d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d8:
	/* 0x6d8: je     6e6 <sys_enter_submit+0x6e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6d8, 0x6e6, x86_l_6e6);
x86_l_6da:
	/* 0x6da: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6dd:
	/* 0x6dd: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6e1:
	/* 0x6e1: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6e4:
	/* 0x6e4: jmp    6e8 <sys_enter_submit+0x6e8> */
	X86_SIM_X86_JMP(0x6e4, 0x6e8, x86_l_6e8);
x86_l_6e6:
	/* 0x6e6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e8:
	/* 0x6e8: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_6eb:
	/* 0x6eb: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_6f0:
	/* 0x6f0: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_6f3:
	/* 0x6f3: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f6:
	/* 0x6f6: jb     70e <sys_enter_submit+0x70e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x6f6, 0x70e, x86_l_70e);
x86_l_6f8:
	/* 0x6f8: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_6fc:
	/* 0x6fc: je     703 <sys_enter_submit+0x703> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6fc, 0x703, x86_l_703);
x86_l_6fe:
	/* 0x6fe: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_701:
	/* 0x701: jbe    70e <sys_enter_submit+0x70e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x701, 0x70e, x86_l_70e);
x86_l_703:
	/* 0x703: and    r12,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 152ULL);
x86_l_70b:
	/* 0x70b: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_70e:
	/* 0x70e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_713:
	/* 0x713: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_716:
	/* 0x716: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_71e:
	/* 0x71e: and    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_721:
	/* 0x721: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_729:
	/* 0x729: jne    743 <sys_enter_submit+0x743> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x729, 0x743, x86_l_743);
x86_l_72b:
	/* 0x72b: jmp    7f3 <sys_enter_submit+0x7f3> */
	X86_SIM_X86_JMP(0x72b, 0x7f3, x86_l_7f3);
x86_l_730:
	/* 0x730: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_735:
	/* 0x735: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_73d:
	/* 0x73d: je     7f3 <sys_enter_submit+0x7f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x73d, 0x7f3, x86_l_7f3);
x86_l_743:
	/* 0x743: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_748:
	/* 0x748: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_74f:
	/* 0x74f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_752:
	/* 0x752: jns    759 <sys_enter_submit+0x759> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x752, 0x759, x86_l_759);
x86_l_754:
	/* 0x754: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_757:
	/* 0x757: jmp    75b <sys_enter_submit+0x75b> */
	X86_SIM_X86_JMP(0x757, 0x75b, x86_l_75b);
x86_l_759:
	/* 0x759: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_75b:
	/* 0x75b: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_75f:
	/* 0x75f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_761:
	/* 0x761: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_764:
	/* 0x764: jns    773 <sys_enter_submit+0x773> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x764, 0x773, x86_l_773);
x86_l_766:
	/* 0x766: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_769:
	/* 0x769: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_76c:
	/* 0x76c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_76f:
	/* 0x76f: js     77d <sys_enter_submit+0x77d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x76f, 0x77d, x86_l_77d);
x86_l_771:
	/* 0x771: jmp    77f <sys_enter_submit+0x77f> */
	X86_SIM_X86_JMP(0x771, 0x77f, x86_l_77f);
x86_l_773:
	/* 0x773: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_775:
	/* 0x775: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_778:
	/* 0x778: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_77b:
	/* 0x77b: jns    77f <sys_enter_submit+0x77f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x77b, 0x77f, x86_l_77f);
x86_l_77d:
	/* 0x77d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_77f:
	/* 0x77f: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_783:
	/* 0x783: mov    rbx,QWORD PTR [r14+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_78a:
	/* 0x78a: mov    r12,QWORD PTR [r14+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_791:
	/* 0x791: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_794:
	/* 0x794: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_799:
	/* 0x799: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_79e:
	/* 0x79e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_7a5:
	/* 0x7a5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7aa:
	/* 0x7aa: call   7af <sys_enter_submit+0x7af> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7af:
	/* 0x7af: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7b6:
	/* 0x7b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7b9:
	/* 0x7b9: je     7dd <sys_enter_submit+0x7dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b9, 0x7dd, x86_l_7dd);
x86_l_7bb:
	/* 0x7bb: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7c0:
	/* 0x7c0: lea    rsi,[rcx+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7c4:
	/* 0x7c4: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7c7:
	/* 0x7c7: call   7cc <sys_enter_submit+0x7cc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7cc:
	/* 0x7cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7cf:
	/* 0x7cf: je     7dd <sys_enter_submit+0x7dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7cf, 0x7dd, x86_l_7dd);
x86_l_7d1:
	/* 0x7d1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7d4:
	/* 0x7d4: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7d8:
	/* 0x7d8: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7db:
	/* 0x7db: jmp    7df <sys_enter_submit+0x7df> */
	X86_SIM_X86_JMP(0x7db, 0x7df, x86_l_7df);
x86_l_7dd:
	/* 0x7dd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7df:
	/* 0x7df: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7e2:
	/* 0x7e2: and    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7e5:
	/* 0x7e5: or     r15,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_7e8:
	/* 0x7e8: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7eb:
	/* 0x7eb: and    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_7ee:
	/* 0x7ee: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7f3:
	/* 0x7f3: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_7fb:
	/* 0x7fb: je     8c9 <sys_enter_submit+0x8c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7fb, 0x8c9, x86_l_8c9);
x86_l_801:
	/* 0x801: mov    rcx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_808:
	/* 0x808: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_80c:
	/* 0x80c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_80e:
	/* 0x80e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_811:
	/* 0x811: jns    820 <sys_enter_submit+0x820> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x811, 0x820, x86_l_820);
x86_l_813:
	/* 0x813: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_816:
	/* 0x816: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_819:
	/* 0x819: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_81c:
	/* 0x81c: js     82a <sys_enter_submit+0x82a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x81c, 0x82a, x86_l_82a);
x86_l_81e:
	/* 0x81e: jmp    82c <sys_enter_submit+0x82c> */
	X86_SIM_X86_JMP(0x81e, 0x82c, x86_l_82c);
x86_l_820:
	/* 0x820: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_822:
	/* 0x822: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_825:
	/* 0x825: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_828:
	/* 0x828: jns    82c <sys_enter_submit+0x82c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x828, 0x82c, x86_l_82c);
x86_l_82a:
	/* 0x82a: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_82c:
	/* 0x82c: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_82e:
	/* 0x82e: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_832:
	/* 0x832: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_835:
	/* 0x835: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_839:
	/* 0x839: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_83b:
	/* 0x83b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_83e:
	/* 0x83e: jns    845 <sys_enter_submit+0x845> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83e, 0x845, x86_l_845);
x86_l_840:
	/* 0x840: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_843:
	/* 0x843: jmp    847 <sys_enter_submit+0x847> */
	X86_SIM_X86_JMP(0x843, 0x847, x86_l_847);
x86_l_845:
	/* 0x845: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_847:
	/* 0x847: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_84a:
	/* 0x84a: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_84e:
	/* 0x84e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_851:
	/* 0x851: jns    855 <sys_enter_submit+0x855> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x851, 0x855, x86_l_855);
x86_l_853:
	/* 0x853: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_855:
	/* 0x855: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_859:
	/* 0x859: mov    rbx,QWORD PTR [r14+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_860:
	/* 0x860: mov    r12,QWORD PTR [r14+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_867:
	/* 0x867: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_86a:
	/* 0x86a: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_86f:
	/* 0x86f: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_874:
	/* 0x874: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_87b:
	/* 0x87b: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_880:
	/* 0x880: call   885 <sys_enter_submit+0x885> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_885:
	/* 0x885: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_88c:
	/* 0x88c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88f:
	/* 0x88f: je     8b3 <sys_enter_submit+0x8b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x88f, 0x8b3, x86_l_8b3);
x86_l_891:
	/* 0x891: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_896:
	/* 0x896: lea    rsi,[rcx+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_89a:
	/* 0x89a: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_89d:
	/* 0x89d: call   8a2 <sys_enter_submit+0x8a2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8a2:
	/* 0x8a2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a5:
	/* 0x8a5: je     8b3 <sys_enter_submit+0x8b3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a5, 0x8b3, x86_l_8b3);
x86_l_8a7:
	/* 0x8a7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8aa:
	/* 0x8aa: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8ae:
	/* 0x8ae: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_8b1:
	/* 0x8b1: jmp    8b5 <sys_enter_submit+0x8b5> */
	X86_SIM_X86_JMP(0x8b1, 0x8b5, x86_l_8b5);
x86_l_8b3:
	/* 0x8b3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8b5:
	/* 0x8b5: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8b8:
	/* 0x8b8: and    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8bb:
	/* 0x8bb: or     r15,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_8be:
	/* 0x8be: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_8c1:
	/* 0x8c1: and    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8c4:
	/* 0x8c4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8c9:
	/* 0x8c9: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_8d1:
	/* 0x8d1: je     ac3 <sys_enter_submit+0xac3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8d1, 0xac3, x86_l_ac3);
x86_l_8d7:
	/* 0x8d7: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8dc:
	/* 0x8dc: add    rax,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_8e3:
	/* 0x8e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e6:
	/* 0x8e6: jns    901 <sys_enter_submit+0x901> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e6, 0x901, x86_l_901);
x86_l_8e8:
	/* 0x8e8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8eb:
	/* 0x8eb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8ee:
	/* 0x8ee: js     908 <sys_enter_submit+0x908> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8ee, 0x908, x86_l_908);
x86_l_8f0:
	/* 0x8f0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8f2:
	/* 0x8f2: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_8fa:
	/* 0x8fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8fd:
	/* 0x8fd: js     918 <sys_enter_submit+0x918> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8fd, 0x918, x86_l_918);
x86_l_8ff:
	/* 0x8ff: jmp    963 <sys_enter_submit+0x963> */
	X86_SIM_X86_JMP(0x8ff, 0x963, x86_l_963);
x86_l_901:
	/* 0x901: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_903:
	/* 0x903: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_906:
	/* 0x906: jns    8f0 <sys_enter_submit+0x8f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x906, 0x8f0, x86_l_8f0);
x86_l_908:
	/* 0x908: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_90b:
	/* 0x90b: mov    QWORD PTR [rsp+0x90],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_913:
	/* 0x913: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_916:
	/* 0x916: jns    963 <sys_enter_submit+0x963> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x916, 0x963, x86_l_963);
x86_l_918:
	/* 0x918: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_91b:
	/* 0x91b: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_920:
	/* 0x920: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_924:
	/* 0x924: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_929:
	/* 0x929: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_92d:
	/* 0x92d: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_932:
	/* 0x932: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_936:
	/* 0x936: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_93b:
	/* 0x93b: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_93f:
	/* 0x93f: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_944:
	/* 0x944: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_948:
	/* 0x948: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_94d:
	/* 0x94d: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_951:
	/* 0x951: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_956:
	/* 0x956: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_95a:
	/* 0x95a: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_95f:
	/* 0x95f: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_963:
	/* 0x963: lea    rbx,[rdx+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_967:
	/* 0x967: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_96c:
	/* 0x96c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_96f:
	/* 0x96f: movzx  edx,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_974:
	/* 0x974: jns    a4a <sys_enter_submit+0xa4a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x974, 0xa4a, x86_l_a4a);
x86_l_97a:
	/* 0x97a: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_97d:
	/* 0x97d: mov    BYTE PTR [rbx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_97f:
	/* 0x97f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_981:
	/* 0x981: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x981, 0xa59, x86_l_a59);
x86_l_987:
	/* 0x987: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_98b:
	/* 0x98b: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_98f:
	/* 0x98f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_991:
	/* 0x991: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x991, 0xa59, x86_l_a59);
x86_l_997:
	/* 0x997: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_99b:
	/* 0x99b: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_99f:
	/* 0x99f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9a1:
	/* 0x9a1: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a1, 0xa59, x86_l_a59);
x86_l_9a7:
	/* 0x9a7: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_9ab:
	/* 0x9ab: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_9af:
	/* 0x9af: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9b1:
	/* 0x9b1: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9b1, 0xa59, x86_l_a59);
x86_l_9b7:
	/* 0x9b7: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_9bb:
	/* 0x9bb: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_9bf:
	/* 0x9bf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9c1:
	/* 0x9c1: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9c1, 0xa59, x86_l_a59);
x86_l_9c7:
	/* 0x9c7: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_9cb:
	/* 0x9cb: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_9cf:
	/* 0x9cf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9d1:
	/* 0x9d1: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d1, 0xa59, x86_l_a59);
x86_l_9d7:
	/* 0x9d7: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_9db:
	/* 0x9db: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_9df:
	/* 0x9df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9e1:
	/* 0x9e1: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e1, 0xa59, x86_l_a59);
x86_l_9e3:
	/* 0x9e3: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_9e7:
	/* 0x9e7: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_9eb:
	/* 0x9eb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9ed:
	/* 0x9ed: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9ed, 0xa59, x86_l_a59);
x86_l_9ef:
	/* 0x9ef: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_9f3:
	/* 0x9f3: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_9f7:
	/* 0x9f7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_9f9:
	/* 0x9f9: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f9, 0xa59, x86_l_a59);
x86_l_9fb:
	/* 0x9fb: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_9ff:
	/* 0x9ff: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_a03:
	/* 0xa03: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a05:
	/* 0xa05: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa05, 0xa59, x86_l_a59);
x86_l_a07:
	/* 0xa07: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_a0b:
	/* 0xa0b: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_a0f:
	/* 0xa0f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a11:
	/* 0xa11: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa11, 0xa59, x86_l_a59);
x86_l_a13:
	/* 0xa13: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_a17:
	/* 0xa17: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_a1b:
	/* 0xa1b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a1d:
	/* 0xa1d: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa1d, 0xa59, x86_l_a59);
x86_l_a1f:
	/* 0xa1f: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_a23:
	/* 0xa23: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_a27:
	/* 0xa27: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a29:
	/* 0xa29: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa29, 0xa59, x86_l_a59);
x86_l_a2b:
	/* 0xa2b: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_a2f:
	/* 0xa2f: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_a33:
	/* 0xa33: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_a35:
	/* 0xa35: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa35, 0xa59, x86_l_a59);
x86_l_a37:
	/* 0xa37: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_a3b:
	/* 0xa3b: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_a3f:
	/* 0xa3f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_a41:
	/* 0xa41: je     a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa41, 0xa59, x86_l_a59);
x86_l_a43:
	/* 0xa43: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_a48:
	/* 0xa48: jmp    a59 <sys_enter_submit+0xa59> */
	X86_SIM_X86_JMP(0xa48, 0xa59, x86_l_a59);
x86_l_a4a:
	/* 0xa4a: mov    QWORD PTR [rbx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_a52:
	/* 0xa52: mov    QWORD PTR [rbx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a59:
	/* 0xa59: mov    r12,QWORD PTR [r14+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_a60:
	/* 0xa60: mov    r13,QWORD PTR [r14+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_a67:
	/* 0xa67: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a6a:
	/* 0xa6a: mov    WORD PTR [rsp+0x40],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a6f:
	/* 0xa6f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_a76:
	/* 0xa76: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_a7b:
	/* 0xa7b: call   a80 <sys_enter_submit+0xa80> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a80:
	/* 0xa80: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a87:
	/* 0xa87: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a8a:
	/* 0xa8a: je     aa8 <sys_enter_submit+0xaa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa8a, 0xaa8, x86_l_aa8);
x86_l_a8c:
	/* 0xa8c: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a8f:
	/* 0xa8f: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a92:
	/* 0xa92: call   a97 <sys_enter_submit+0xa97> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a97:
	/* 0xa97: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a9a:
	/* 0xa9a: je     aa8 <sys_enter_submit+0xaa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa9a, 0xaa8, x86_l_aa8);
x86_l_a9c:
	/* 0xa9c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a9f:
	/* 0xa9f: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aa3:
	/* 0xaa3: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_aa6:
	/* 0xaa6: jmp    aaa <sys_enter_submit+0xaaa> */
	X86_SIM_X86_JMP(0xaa6, 0xaaa, x86_l_aaa);
x86_l_aa8:
	/* 0xaa8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aaa:
	/* 0xaaa: mov    rsi,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_ab2:
	/* 0xab2: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_ab5:
	/* 0xab5: and    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_ab8:
	/* 0xab8: or     r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_abb:
	/* 0xabb: and    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_abe:
	/* 0xabe: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ac3:
	/* 0xac3: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_acb:
	/* 0xacb: je     bed <sys_enter_submit+0xbed> */
	X86_SIM_X86_JCC(X86_CC_E, 0xacb, 0xbed, x86_l_bed);
x86_l_ad1:
	/* 0xad1: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_ad4:
	/* 0xad4: lea    rbx,[rdx+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_ad8:
	/* 0xad8: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_adb:
	/* 0xadb: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_ae0:
	/* 0xae0: call   ae5 <sys_enter_submit+0xae5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_ae5:
	/* 0xae5: mov    r12,QWORD PTR [r14+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_aec:
	/* 0xaec: mov    r13,QWORD PTR [r14+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_af3:
	/* 0xaf3: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_af6:
	/* 0xaf6: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_afb:
	/* 0xafb: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b00:
	/* 0xb00: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_b07:
	/* 0xb07: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b0c:
	/* 0xb0c: call   b11 <sys_enter_submit+0xb11> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b11:
	/* 0xb11: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b18:
	/* 0xb18: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b1b:
	/* 0xb1b: je     b39 <sys_enter_submit+0xb39> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb1b, 0xb39, x86_l_b39);
x86_l_b1d:
	/* 0xb1d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b20:
	/* 0xb20: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b23:
	/* 0xb23: call   b28 <sys_enter_submit+0xb28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b28:
	/* 0xb28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b2b:
	/* 0xb2b: je     b39 <sys_enter_submit+0xb39> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2b, 0xb39, x86_l_b39);
x86_l_b2d:
	/* 0xb2d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b30:
	/* 0xb30: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b34:
	/* 0xb34: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b37:
	/* 0xb37: jmp    b3b <sys_enter_submit+0xb3b> */
	X86_SIM_X86_JMP(0xb37, 0xb3b, x86_l_b3b);
x86_l_b39:
	/* 0xb39: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b3b:
	/* 0xb3b: movzx  esi,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_b40:
	/* 0xb40: or     r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b43:
	/* 0xb43: and    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b46:
	/* 0xb46: or     r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b49:
	/* 0xb49: and    rbp,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b4c:
	/* 0xb4c: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_b4f:
	/* 0xb4f: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_b56:
	/* 0xb56: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b59:
	/* 0xb59: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_b5e:
	/* 0xb5e: je     c0a <sys_enter_submit+0xc0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5e, 0xc0a, x86_l_c0a);
x86_l_b64:
	/* 0xb64: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b68:
	/* 0xb68: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b6c:
	/* 0xb6c: mov    r12,QWORD PTR [r14+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_b73:
	/* 0xb73: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b76:
	/* 0xb76: mov    WORD PTR [rsp+0x30],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b7b:
	/* 0xb7b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_b82:
	/* 0xb82: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b87:
	/* 0xb87: call   b8c <sys_enter_submit+0xb8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b8c:
	/* 0xb8c: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b93:
	/* 0xb93: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b96:
	/* 0xb96: je     bb6 <sys_enter_submit+0xbb6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb96, 0xbb6, x86_l_bb6);
x86_l_b98:
	/* 0xb98: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_b9d:
	/* 0xb9d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba0:
	/* 0xba0: call   ba5 <sys_enter_submit+0xba5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ba5:
	/* 0xba5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ba8:
	/* 0xba8: je     bb6 <sys_enter_submit+0xbb6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xba8, 0xbb6, x86_l_bb6);
x86_l_baa:
	/* 0xbaa: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bad:
	/* 0xbad: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bb1:
	/* 0xbb1: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bb4:
	/* 0xbb4: jmp    bb8 <sys_enter_submit+0xbb8> */
	X86_SIM_X86_JMP(0xbb4, 0xbb8, x86_l_bb8);
x86_l_bb6:
	/* 0xbb6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bb8:
	/* 0xbb8: movzx  esi,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_bbd:
	/* 0xbbd: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bc0:
	/* 0xbc0: and    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bc3:
	/* 0xbc3: or     r15,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bc6:
	/* 0xbc6: and    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bc9:
	/* 0xbc9: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_bd0:
	/* 0xbd0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bd3:
	/* 0xbd3: jne    c16 <sys_enter_submit+0xc16> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbd3, 0xc16, x86_l_c16);
x86_l_bd5:
	/* 0xbd5: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_bd8:
	/* 0xbd8: mov    r12,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_bdf:
	/* 0xbdf: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_be2:
	/* 0xbe2: jne    c8a <sys_enter_submit+0xc8a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbe2, 0xc8a, x86_l_c8a);
x86_l_be8:
	/* 0xbe8: jmp    d0a <sys_enter_submit+0xd0a> */
	X86_SIM_X86_JMP(0xbe8, 0xd0a, x86_l_d0a);
x86_l_bed:
	/* 0xbed: mov    r13,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_bf0:
	/* 0xbf0: movzx  esi,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_bf5:
	/* 0xbf5: mov    rbx,QWORD PTR [r14+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_bfc:
	/* 0xbfc: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_bff:
	/* 0xbff: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_c04:
	/* 0xc04: jne    b64 <sys_enter_submit+0xb64> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc04, 0xb64, x86_l_b64);
x86_l_c0a:
	/* 0xc0a: mov    rbx,QWORD PTR [r14+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_c11:
	/* 0xc11: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c14:
	/* 0xc14: je     bd5 <sys_enter_submit+0xbd5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc14, 0xbd5, x86_l_bd5);
x86_l_c16:
	/* 0xc16: mov    r12,QWORD PTR [r14+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_c1d:
	/* 0xc1d: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c20:
	/* 0xc20: mov    WORD PTR [rsp+0x40],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c25:
	/* 0xc25: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_c2c:
	/* 0xc2c: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c31:
	/* 0xc31: call   c36 <sys_enter_submit+0xc36> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c36:
	/* 0xc36: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_c3d:
	/* 0xc3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c40:
	/* 0xc40: je     c64 <sys_enter_submit+0xc64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc40, 0xc64, x86_l_c64);
x86_l_c42:
	/* 0xc42: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c47:
	/* 0xc47: lea    rsi,[rcx+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_c4b:
	/* 0xc4b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c4e:
	/* 0xc4e: call   c53 <sys_enter_submit+0xc53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c53:
	/* 0xc53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c56:
	/* 0xc56: je     c64 <sys_enter_submit+0xc64> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc56, 0xc64, x86_l_c64);
x86_l_c58:
	/* 0xc58: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5b:
	/* 0xc5b: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c5f:
	/* 0xc5f: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c62:
	/* 0xc62: jmp    c66 <sys_enter_submit+0xc66> */
	X86_SIM_X86_JMP(0xc62, 0xc66, x86_l_c66);
x86_l_c64:
	/* 0xc64: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c66:
	/* 0xc66: movzx  esi,WORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_c6b:
	/* 0xc6b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c6e:
	/* 0xc6e: and    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c71:
	/* 0xc71: or     r15,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c74:
	/* 0xc74: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c77:
	/* 0xc77: and    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c7a:
	/* 0xc7a: mov    r12,QWORD PTR [r14+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_c81:
	/* 0xc81: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c84:
	/* 0xc84: je     d0a <sys_enter_submit+0xd0a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc84, 0xd0a, x86_l_d0a);
x86_l_c8a:
	/* 0xc8a: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_c8d:
	/* 0xc8d: mov    r13,QWORD PTR [r14+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_c94:
	/* 0xc94: not    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c97:
	/* 0xc97: mov    WORD PTR [rsp+0x40],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c9c:
	/* 0xc9c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_ca3:
	/* 0xca3: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ca8:
	/* 0xca8: call   cad <sys_enter_submit+0xcad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_cad:
	/* 0xcad: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_cb4:
	/* 0xcb4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cb7:
	/* 0xcb7: je     cf4 <sys_enter_submit+0xcf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcb7, 0xcf4, x86_l_cf4);
x86_l_cb9:
	/* 0xcb9: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cbc:
	/* 0xcbc: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cc1:
	/* 0xcc1: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_cc5:
	/* 0xcc5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_cc8:
	/* 0xcc8: call   ccd <sys_enter_submit+0xccd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ccd:
	/* 0xccd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cd0:
	/* 0xcd0: jne    ce8 <sys_enter_submit+0xce8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcd0, 0xce8, x86_l_ce8);
x86_l_cd2:
	/* 0xcd2: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cd7:
	/* 0xcd7: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_cdb:
	/* 0xcdb: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_cde:
	/* 0xcde: call   ce3 <sys_enter_submit+0xce3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ce3:
	/* 0xce3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce6:
	/* 0xce6: je     cf4 <sys_enter_submit+0xcf4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xce6, 0xcf4, x86_l_cf4);
x86_l_ce8:
	/* 0xce8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ceb:
	/* 0xceb: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cef:
	/* 0xcef: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_cf2:
	/* 0xcf2: jmp    cf6 <sys_enter_submit+0xcf6> */
	X86_SIM_X86_JMP(0xcf2, 0xcf6, x86_l_cf6);
x86_l_cf4:
	/* 0xcf4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf6:
	/* 0xcf6: or     rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cf9:
	/* 0xcf9: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_cfc:
	/* 0xcfc: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cff:
	/* 0xcff: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_d02:
	/* 0xd02: and    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d05:
	/* 0xd05: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_d0a:
	/* 0xd0a: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d0f:
	/* 0xd0f: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_d16:
	/* 0xd16: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d19:
	/* 0xd19: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_d1e:
	/* 0xd1e: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d22:
	/* 0xd22: je     d30 <sys_enter_submit+0xd30> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd22, 0xd30, x86_l_d30);
x86_l_d24:
	/* 0xd24: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d29:
	/* 0xd29: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_d2d:
	/* 0xd2d: or     rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_d30:
	/* 0xd30: and    rdx,QWORD PTR [r14+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_d37:
	/* 0xd37: mov    rcx,QWORD PTR [r14+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d3e:
	/* 0xd3e: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_d41:
	/* 0xd41: mov    QWORD PTR [r14+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d48:
	/* 0xd48: je     32e3 <sys_enter_submit+0x32e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd48, 0x32e3, x86_l_32e3);
x86_l_d4e:
	/* 0xd4e: test   BYTE PTR [rbp+0x4],0x40 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869248ULL);
x86_l_d52:
	/* 0xd52: je     2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd52, 0x2d5a, x86_l_2d5a);
x86_l_d58:
	/* 0xd58: mov    eax,DWORD PTR [r12+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_d5d:
	/* 0xd5d: cmp    eax,0xd8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 216ULL);
x86_l_d62:
	/* 0xd62: jle    db0 <sys_enter_submit+0xdb0> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xd62, 0xdb0, x86_l_db0);
x86_l_d64:
	/* 0xd64: lea    ecx,[rax-0x118] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551336ULL);
x86_l_d6a:
	/* 0xd6a: cmp    ecx,0x34 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 52ULL);
x86_l_d6d:
	/* 0xd6d: jbe    dfd <sys_enter_submit+0xdfd> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xd6d, 0xdfd, x86_l_dfd);
x86_l_d73:
	/* 0xd73: lea    ecx,[rax-0xd9] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551399ULL);
x86_l_d79:
	/* 0xd79: cmp    ecx,0x3d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 61ULL);
x86_l_d7c:
	/* 0xd7c: ja     d92 <sys_enter_submit+0xd92> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd7c, 0xd92, x86_l_d92);
x86_l_d7e:
	/* 0xd7e: movabs rdx,0x301e7f6000008011 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 3467348813415481361ULL);
x86_l_d88:
	/* 0xd88: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_d8c:
	/* 0xd8c: jb     e11 <sys_enter_submit+0xe11> */
	X86_SIM_X86_JCC(X86_CC_B, 0xd8c, 0xe11, x86_l_e11);
x86_l_d92:
	/* 0xd92: lea    ecx,[rax-0x1a8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551192ULL);
x86_l_d98:
	/* 0xd98: cmp    ecx,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_d9b:
	/* 0xd9b: ja     2d5f <sys_enter_submit+0x2d5f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd9b, 0x2d5f, x86_l_2d5f);
x86_l_da1:
	/* 0xda1: mov    edx,0x16fa39d */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24093597ULL);
x86_l_da6:
	/* 0xda6: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_da9:
	/* 0xda9: jb     e11 <sys_enter_submit+0xe11> */
	X86_SIM_X86_JCC(X86_CC_B, 0xda9, 0xe11, x86_l_e11);
x86_l_dab:
	/* 0xdab: jmp    2d5f <sys_enter_submit+0x2d5f> */
	X86_SIM_X86_JMP(0xdab, 0x2d5f, x86_l_2d5f);
x86_l_db0:
	/* 0xdb0: cmp    eax,0x37 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 55ULL);
x86_l_db3:
	/* 0xdb3: ja     dc7 <sys_enter_submit+0xdc7> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdb3, 0xdc7, x86_l_dc7);
x86_l_db5:
	/* 0xdb5: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_db7:
	/* 0xdb7: movabs rdx,0xdffc01001f032b */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 63046001033675563ULL);
x86_l_dc1:
	/* 0xdc1: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dc5:
	/* 0xdc5: jb     e11 <sys_enter_submit+0xe11> */
	X86_SIM_X86_JCC(X86_CC_B, 0xdc5, 0xe11, x86_l_e11);
x86_l_dc7:
	/* 0xdc7: lea    ecx,[rax-0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551544ULL);
x86_l_dca:
	/* 0xdca: cmp    ecx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_dcd:
	/* 0xdcd: ja     dd9 <sys_enter_submit+0xdd9> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdcd, 0xdd9, x86_l_dd9);
x86_l_dcf:
	/* 0xdcf: mov    edx,0x28026f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2622063ULL);
x86_l_dd4:
	/* 0xdd4: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_dd7:
	/* 0xdd7: jb     e11 <sys_enter_submit+0xe11> */
	X86_SIM_X86_JCC(X86_CC_B, 0xdd7, 0xe11, x86_l_e11);
x86_l_dd9:
	/* 0xdd9: lea    ecx,[rax-0x8a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551478ULL);
x86_l_ddf:
	/* 0xddf: cmp    ecx,0x3d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 61ULL);
x86_l_de2:
	/* 0xde2: ja     2d5f <sys_enter_submit+0x2d5f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xde2, 0x2d5f, x86_l_2d5f);
x86_l_de8:
	/* 0xde8: movabs rdx,0x2492000000000001 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 2635168731965161473ULL);
x86_l_df2:
	/* 0xdf2: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_df6:
	/* 0xdf6: jb     e11 <sys_enter_submit+0xe11> */
	X86_SIM_X86_JCC(X86_CC_B, 0xdf6, 0xe11, x86_l_e11);
x86_l_df8:
	/* 0xdf8: jmp    2d5f <sys_enter_submit+0x2d5f> */
	X86_SIM_X86_JMP(0xdf8, 0x2d5f, x86_l_2d5f);
x86_l_dfd:
	/* 0xdfd: movabs rdx,0x1184021d8d83e7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4930219224695783ULL);
x86_l_e07:
	/* 0xe07: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e0b:
	/* 0xe0b: jae    d73 <sys_enter_submit+0xd73> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xe0b, 0xd73, x86_l_d73);
x86_l_e11:
	/* 0xe11: cmp    eax,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_e14:
	/* 0xe14: je     e35 <sys_enter_submit+0xe35> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe14, 0xe35, x86_l_e35);
x86_l_e16:
	/* 0xe16: cmp    eax,0x12a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 298ULL);
x86_l_e1b:
	/* 0xe1b: je     e2b <sys_enter_submit+0xe2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe1b, 0xe2b, x86_l_e2b);
x86_l_e1d:
	/* 0xe1d: cmp    eax,0x10a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 266ULL);
x86_l_e22:
	/* 0xe22: jne    e3f <sys_enter_submit+0xe3f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe22, 0xe3f, x86_l_e3f);
x86_l_e24:
	/* 0xe24: lea    rax,[r12+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_e29:
	/* 0xe29: jmp    e44 <sys_enter_submit+0xe44> */
	X86_SIM_X86_JMP(0xe29, 0xe44, x86_l_e44);
x86_l_e2b:
	/* 0xe2b: lea    rax,[r12+0x88] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_e33:
	/* 0xe33: jmp    e44 <sys_enter_submit+0xe44> */
	X86_SIM_X86_JMP(0xe33, 0xe44, x86_l_e44);
x86_l_e35:
	/* 0xe35: lea    rax,[r12+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_e3d:
	/* 0xe3d: jmp    e44 <sys_enter_submit+0xe44> */
	X86_SIM_X86_JMP(0xe3d, 0xe44, x86_l_e44);
x86_l_e3f:
	/* 0xe3f: lea    rax,[r12+0x70] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_e44:
	/* 0xe44: mov    ebx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e46:
	/* 0xe46: call   e4b <sys_enter_submit+0xe4b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_e4b:
	/* 0xe4b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4e:
	/* 0xe4e: je     2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4e, 0x2d5a, x86_l_2d5a);
x86_l_e54:
	/* 0xe54: sub    rax,0xffffffffffffff80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 18446744073709551488ULL);
x86_l_e58:
	/* 0xe58: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e5b:
	/* 0xe5b: jns    e69 <sys_enter_submit+0xe69> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe5b, 0xe69, x86_l_e69);
x86_l_e5d:
	/* 0xe5d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e60:
	/* 0xe60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e63:
	/* 0xe63: js     e70 <sys_enter_submit+0xe70> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe63, 0xe70, x86_l_e70);
x86_l_e65:
	/* 0xe65: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e67:
	/* 0xe67: jmp    e73 <sys_enter_submit+0xe73> */
	X86_SIM_X86_JMP(0xe67, 0xe73, x86_l_e73);
x86_l_e69:
	/* 0xe69: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e6b:
	/* 0xe6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e6e:
	/* 0xe6e: jns    e65 <sys_enter_submit+0xe65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe6e, 0xe65, x86_l_e65);
x86_l_e70:
	/* 0xe70: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e73:
	/* 0xe73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e76:
	/* 0xe76: jns    2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe76, 0x2d5a, x86_l_2d5a);
x86_l_e7c:
	/* 0xe7c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e7f:
	/* 0xe7f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e82:
	/* 0xe82: je     2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe82, 0x2d5a, x86_l_2d5a);
x86_l_e88:
	/* 0xe88: lea    rax,[rax+rbx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBX, 3), 0ULL);
x86_l_e8c:
	/* 0xe8c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e8f:
	/* 0xe8f: jns    2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe8f, 0x2d5a, x86_l_2d5a);
x86_l_e95:
	/* 0xe95: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e98:
	/* 0xe98: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_e9b:
	/* 0xe9b: je     2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe9b, 0x2d5a, x86_l_2d5a);
x86_l_ea1:
	/* 0xea1: mov    rax,QWORD PTR [r12+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_ea9:
	/* 0xea9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_eae:
	/* 0xeae: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_eb7:
	/* 0xeb7: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_ec0:
	/* 0xec0: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_ec9:
	/* 0xec9: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_ed2:
	/* 0xed2: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_edb:
	/* 0xedb: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_ee4:
	/* 0xee4: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_eed:
	/* 0xeed: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_ef6:
	/* 0xef6: mov    DWORD PTR [rsp+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_efe:
	/* 0xefe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_f05:
	/* 0xf05: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_f0a:
	/* 0xf0a: call   f0f <sys_enter_submit+0xf0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f0f:
	/* 0xf0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f12:
	/* 0xf12: je     f27 <sys_enter_submit+0xf27> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf12, 0xf27, x86_l_f27);
x86_l_f14:
	/* 0xf14: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f19:
	/* 0xf19: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f1d:
	/* 0xf1d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f20:
	/* 0xf20: jns    f2e <sys_enter_submit+0xf2e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf20, 0xf2e, x86_l_f2e);
x86_l_f22:
	/* 0xf22: mov    rbp,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f25:
	/* 0xf25: jmp    f30 <sys_enter_submit+0xf30> */
	X86_SIM_X86_JMP(0xf25, 0xf30, x86_l_f30);
x86_l_f27:
	/* 0xf27: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f29:
	/* 0xf29: jmp    2cd5 <sys_enter_submit+0x2cd5> */
	X86_SIM_X86_JMP(0xf29, 0x2cd5, x86_l_2cd5);
x86_l_f2e:
	/* 0xf2e: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f30:
	/* 0xf30: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_f33:
	/* 0xf33: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f36:
	/* 0xf36: jns    f43 <sys_enter_submit+0xf43> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf36, 0xf43, x86_l_f43);
x86_l_f38:
	/* 0xf38: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3a:
	/* 0xf3a: test   cl,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_f3d:
	/* 0xf3d: jne    1049 <sys_enter_submit+0x1049> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf3d, 0x1049, x86_l_1049);
x86_l_f43:
	/* 0xf43: add    rbx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_f47:
	/* 0xf47: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f4a:
	/* 0xf4a: jns    f51 <sys_enter_submit+0xf51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf4a, 0xf51, x86_l_f51);
x86_l_f4c:
	/* 0xf4c: mov    r8,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f4f:
	/* 0xf4f: jmp    f54 <sys_enter_submit+0xf54> */
	X86_SIM_X86_JMP(0xf4f, 0xf54, x86_l_f54);
x86_l_f51:
	/* 0xf51: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f54:
	/* 0xf54: lea    r11,[r8-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_f58:
	/* 0xf58: mov    rdx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_f5b:
	/* 0xf5b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f5e:
	/* 0xf5e: jns    f65 <sys_enter_submit+0xf65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf5e, 0xf65, x86_l_f65);
x86_l_f60:
	/* 0xf60: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f63:
	/* 0xf63: jmp    f67 <sys_enter_submit+0xf67> */
	X86_SIM_X86_JMP(0xf63, 0xf67, x86_l_f67);
x86_l_f65:
	/* 0xf65: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f67:
	/* 0xf67: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_f6a:
	/* 0xf6a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f6d:
	/* 0xf6d: jns    f74 <sys_enter_submit+0xf74> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf6d, 0xf74, x86_l_f74);
x86_l_f6f:
	/* 0xf6f: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f72:
	/* 0xf72: jmp    f76 <sys_enter_submit+0xf76> */
	X86_SIM_X86_JMP(0xf72, 0xf76, x86_l_f76);
x86_l_f74:
	/* 0xf74: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f76:
	/* 0xf76: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f7a:
	/* 0xf7a: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f7d:
	/* 0xf7d: jns    f84 <sys_enter_submit+0xf84> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf7d, 0xf84, x86_l_f84);
x86_l_f7f:
	/* 0xf7f: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f82:
	/* 0xf82: jmp    f86 <sys_enter_submit+0xf86> */
	X86_SIM_X86_JMP(0xf82, 0xf86, x86_l_f86);
x86_l_f84:
	/* 0xf84: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f86:
	/* 0xf86: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f89:
	/* 0xf89: je     1022 <sys_enter_submit+0x1022> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf89, 0x1022, x86_l_1022);
x86_l_f8f:
	/* 0xf8f: cmp    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f92:
	/* 0xf92: je     1022 <sys_enter_submit+0x1022> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf92, 0x1022, x86_l_1022);
x86_l_f98:
	/* 0xf98: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f9c:
	/* 0xf9c: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f9f:
	/* 0xf9f: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_fa5:
	/* 0xfa5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fa8:
	/* 0xfa8: jns    fb1 <sys_enter_submit+0xfb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfa8, 0xfb1, x86_l_fb1);
x86_l_faa:
	/* 0xfaa: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fad:
	/* 0xfad: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fb1:
	/* 0xfb1: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fb5:
	/* 0xfb5: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_fb8:
	/* 0xfb8: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fbf:
	/* 0xfbf: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_fc2:
	/* 0xfc2: je     1410 <sys_enter_submit+0x1410> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc2, 0x1410, x86_l_1410);
x86_l_fc8:
	/* 0xfc8: mov    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_fcb:
	/* 0xfcb: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_fcd:
	/* 0xfcd: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_fd3:
	/* 0xfd3: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_fd6:
	/* 0xfd6: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_fdb:
	/* 0xfdb: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_fde:
	/* 0xfde: jns    10a4 <sys_enter_submit+0x10a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfde, 0x10a4, x86_l_10a4);
x86_l_fe4:
	/* 0xfe4: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fe9:
	/* 0xfe9: mov    rsi,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_fec:
	/* 0xfec: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fef:
	/* 0xfef: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_ff2:
	/* 0xff2: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ff6:
	/* 0xff6: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ff8:
	/* 0xff8: cmp    r11,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ffb:
	/* 0xffb: je     13db <sys_enter_submit+0x13db> */
	X86_SIM_X86_JCC(X86_CC_E, 0xffb, 0x13db, x86_l_13db);
x86_l_1001:
	/* 0x1001: lea    r15,[rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1005:
	/* 0x1005: movzx  r12d,BYTE PTR [r10+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RBX, 0, X86_WIDTH_8), 0ULL);
x86_l_100a:
	/* 0x100a: mov    BYTE PTR [rdi+rbx*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_100e:
	/* 0x100e: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1011:
	/* 0x1011: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1014:
	/* 0x1014: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1018:
	/* 0x1018: jne    ff8 <sys_enter_submit+0xff8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1018, 0xff8, x86_l_ff8);
x86_l_101a:
	/* 0x101a: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_101d:
	/* 0x101d: jmp    13e0 <sys_enter_submit+0x13e0> */
	X86_SIM_X86_JMP(0x101d, 0x13e0, x86_l_13e0);
x86_l_1022:
	/* 0x1022: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1025:
	/* 0x1025: jne    1410 <sys_enter_submit+0x1410> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1025, 0x1410, x86_l_1410);
x86_l_102b:
	/* 0x102b: cmp    r11,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_102e:
	/* 0x102e: je     1410 <sys_enter_submit+0x1410> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102e, 0x1410, x86_l_1410);
x86_l_1034:
	/* 0x1034: add    r8,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_1038:
	/* 0x1038: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_103b:
	/* 0x103b: jns    13b2 <sys_enter_submit+0x13b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x103b, 0x13b2, x86_l_13b2);
x86_l_1041:
	/* 0x1041: mov    rsi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1044:
	/* 0x1044: jmp    13b4 <sys_enter_submit+0x13b4> */
	X86_SIM_X86_JMP(0x1044, 0x13b4, x86_l_13b4);
x86_l_1049:
	/* 0x1049: lea    rcx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_1050:
	/* 0x1050: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1052:
	/* 0x1052: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1055:
	/* 0x1055: jns    1080 <sys_enter_submit+0x1080> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1055, 0x1080, x86_l_1080);
x86_l_1057:
	/* 0x1057: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1059:
	/* 0x1059: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_105e:
	/* 0x105e: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_1065:
	/* 0x1065: je     1477 <sys_enter_submit+0x1477> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1065, 0x1477, x86_l_1477);
x86_l_106b:
	/* 0x106b: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_106f:
	/* 0x106f: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1073:
	/* 0x1073: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1076:
	/* 0x1076: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_1079:
	/* 0x1079: jne    105e <sys_enter_submit+0x105e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1079, 0x105e, x86_l_105e);
x86_l_107b:
	/* 0x107b: jmp    2ccc <sys_enter_submit+0x2ccc> */
	X86_SIM_X86_JMP(0x107b, 0x2ccc, x86_l_2ccc);
x86_l_1080:
	/* 0x1080: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1085:
	/* 0x1085: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1088:
	/* 0x1088: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_108a:
	/* 0x108a: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_108d:
	/* 0x108d: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1090:
	/* 0x1090: call   1095 <sys_enter_submit+0x1095> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_1095:
	/* 0x1095: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1098:
	/* 0x1098: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_109b:
	/* 0x109b: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_109f:
	/* 0x109f: jmp    2cc7 <sys_enter_submit+0x2cc7> */
	X86_SIM_X86_JMP(0x109f, 0x2cc7, x86_l_2cc7);
x86_l_10a4:
	/* 0x10a4: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10a9:
	/* 0x10a9: mov    edx,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_10ac:
	/* 0x10ac: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ae:
	/* 0x10ae: call   10b3 <sys_enter_submit+0x10b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_10b3:
	/* 0x10b3: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_10b6:
	/* 0x10b6: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10bb:
	/* 0x10bb: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10be:
	/* 0x10be: cmp    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_10c4:
	/* 0x10c4: jne    2cb2 <sys_enter_submit+0x2cb2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10c4, 0x2cb2, x86_l_2cb2);
x86_l_10ca:
	/* 0x10ca: jmp    1410 <sys_enter_submit+0x1410> */
	X86_SIM_X86_JMP(0x10ca, 0x1410, x86_l_1410);
x86_l_10cf:
	/* 0x10cf: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10d2:
	/* 0x10d2: mov    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10d5:
	/* 0x10d5: mov    eax,DWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_10dc:
	/* 0x10dc: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10e0:
	/* 0x10e0: mov    DWORD PTR [rsp+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_10e8:
	/* 0x10e8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_10ef:
	/* 0x10ef: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_10f4:
	/* 0x10f4: call   10f9 <sys_enter_submit+0x10f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10f9:
	/* 0x10f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10fc:
	/* 0x10fc: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10fc, 0x32f7, x86_l_32f7);
x86_l_1102:
	/* 0x1102: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1105:
	/* 0x1105: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1109:
	/* 0x1109: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_110d:
	/* 0x110d: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_1112:
	/* 0x1112: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1115:
	/* 0x1115: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1117:
	/* 0x1117: call   111c <sys_enter_submit+0x111c> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_111c:
	/* 0x111c: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1123:
	/* 0x1123: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1128:
	/* 0x1128: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_112d:
	/* 0x112d: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1130:
	/* 0x1130: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1133:
	/* 0x1133: call   1138 <sys_enter_submit+0x1138> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1138:
	/* 0x1138: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_113d:
	/* 0x113d: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1140:
	/* 0x1140: call   1145 <sys_enter_submit+0x1145> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1145:
	/* 0x1145: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_114a:
	/* 0x114a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_114d:
	/* 0x114d: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1150:
	/* 0x1150: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1153:
	/* 0x1153: jne    1f9 <sys_enter_submit+0x1f9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1153, 0x1f9, x86_l_1f9);
x86_l_1159:
	/* 0x1159: jmp    32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JMP(0x1159, 0x32f7, x86_l_32f7);
x86_l_115e:
	/* 0x115e: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1163:
	/* 0x1163: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1168:
	/* 0x1168: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_116f:
	/* 0x116f: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1173:
	/* 0x1173: mov    DWORD PTR [rsp+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_117b:
	/* 0x117b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1182:
	/* 0x1182: lea    rsi,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_1187:
	/* 0x1187: call   118c <sys_enter_submit+0x118c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_118c:
	/* 0x118c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_118f:
	/* 0x118f: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x118f, 0x32f7, x86_l_32f7);
x86_l_1195:
	/* 0x1195: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1198:
	/* 0x1198: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_119c:
	/* 0x119c: mov    DWORD PTR [rsp+0x40],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11a0:
	/* 0x11a0: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_11a5:
	/* 0x11a5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11a8:
	/* 0x11a8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11aa:
	/* 0x11aa: call   11af <sys_enter_submit+0x11af> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_11af:
	/* 0x11af: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_11b6:
	/* 0x11b6: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11bb:
	/* 0x11bb: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_11c0:
	/* 0x11c0: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_11c3:
	/* 0x11c3: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_11c6:
	/* 0x11c6: call   11cb <sys_enter_submit+0x11cb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_11cb:
	/* 0x11cb: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_11d0:
	/* 0x11d0: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_11d3:
	/* 0x11d3: call   11d8 <sys_enter_submit+0x11d8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11d8:
	/* 0x11d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11db:
	/* 0x11db: je     32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11db, 0x32f7, x86_l_32f7);
x86_l_11e1:
	/* 0x11e1: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11e6:
	/* 0x11e6: mov    r15,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_11ed:
	/* 0x11ed: lea    r8,[r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_11f1:
	/* 0x11f1: mov    rcx,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_11f4:
	/* 0x11f4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11f7:
	/* 0x11f7: jns    1572 <sys_enter_submit+0x1572> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11f7, 0x1572, x86_l_1572);
x86_l_11fd:
	/* 0x11fd: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1200:
	/* 0x1200: jmp    1574 <sys_enter_submit+0x1574> */
	X86_SIM_X86_JMP(0x1200, 0x1574, x86_l_1574);
x86_l_1205:
	/* 0x1205: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1208:
	/* 0x1208: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_120c:
	/* 0x120c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_120f:
	/* 0x120f: jns    1557 <sys_enter_submit+0x1557> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x120f, 0x1557, x86_l_1557);
x86_l_1215:
	/* 0x1215: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1218:
	/* 0x1218: mov    QWORD PTR [r14+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_121f:
	/* 0x121f: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1223:
	/* 0x1223: mov    QWORD PTR [r14+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_122a:
	/* 0x122a: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_122e:
	/* 0x122e: mov    QWORD PTR [r14+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_1235:
	/* 0x1235: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1239:
	/* 0x1239: mov    QWORD PTR [r14+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1240:
	/* 0x1240: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1244:
	/* 0x1244: mov    QWORD PTR [r14+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_124b:
	/* 0x124b: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_124f:
	/* 0x124f: mov    QWORD PTR [r14+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1256:
	/* 0x1256: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_125a:
	/* 0x125a: mov    QWORD PTR [r14+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1261:
	/* 0x1261: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1265:
	/* 0x1265: mov    QWORD PTR [r14+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_126c:
	/* 0x126c: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1270:
	/* 0x1270: mov    QWORD PTR [r14+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_1277:
	/* 0x1277: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_127b:
	/* 0x127b: mov    QWORD PTR [r14+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_1282:
	/* 0x1282: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1286:
	/* 0x1286: mov    QWORD PTR [r14+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_128d:
	/* 0x128d: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1291:
	/* 0x1291: mov    QWORD PTR [r14+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_1298:
	/* 0x1298: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_129c:
	/* 0x129c: mov    QWORD PTR [r14+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_12a3:
	/* 0x12a3: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_12a7:
	/* 0x12a7: mov    QWORD PTR [r14+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_12ae:
	/* 0x12ae: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_12b2:
	/* 0x12b2: mov    QWORD PTR [r14+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_12b9:
	/* 0x12b9: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_12bd:
	/* 0x12bd: mov    QWORD PTR [r14+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_12c4:
	/* 0x12c4: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_12cb:
	/* 0x12cb: mov    QWORD PTR [r14+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_12d2:
	/* 0x12d2: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_12d9:
	/* 0x12d9: mov    QWORD PTR [r14+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_12e0:
	/* 0x12e0: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_12e7:
	/* 0x12e7: mov    QWORD PTR [r14+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_12ee:
	/* 0x12ee: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_12f5:
	/* 0x12f5: mov    QWORD PTR [r14+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_12fc:
	/* 0x12fc: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_1303:
	/* 0x1303: mov    QWORD PTR [r14+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_130a:
	/* 0x130a: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1311:
	/* 0x1311: mov    QWORD PTR [r14+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1318:
	/* 0x1318: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_131f:
	/* 0x131f: mov    QWORD PTR [r14+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_1326:
	/* 0x1326: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_132d:
	/* 0x132d: mov    QWORD PTR [r14+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_1334:
	/* 0x1334: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_133b:
	/* 0x133b: mov    QWORD PTR [r14+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_1342:
	/* 0x1342: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1349:
	/* 0x1349: mov    QWORD PTR [r14+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_1350:
	/* 0x1350: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1357:
	/* 0x1357: mov    QWORD PTR [r14+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_135e:
	/* 0x135e: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1365:
	/* 0x1365: mov    QWORD PTR [r14+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_136c:
	/* 0x136c: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_1373:
	/* 0x1373: mov    QWORD PTR [r14+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_137a:
	/* 0x137a: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1381:
	/* 0x1381: mov    QWORD PTR [r14+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_1388:
	/* 0x1388: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_138f:
	/* 0x138f: mov    QWORD PTR [r14+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_1396:
	/* 0x1396: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_139d:
	/* 0x139d: mov    QWORD PTR [r14+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_13a4:
	/* 0x13a4: movzx  eax,WORD PTR [rbp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_13a8:
	/* 0x13a8: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_13ad:
	/* 0x13ad: jmp    2d3 <sys_enter_submit+0x2d3> */
	X86_SIM_X86_JMP(0x13ad, 0x2d3, x86_l_2d3);
x86_l_13b2:
	/* 0x13b2: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13b4:
	/* 0x13b4: test   r11,r11 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_13b7:
	/* 0x13b7: jns    13be <sys_enter_submit+0x13be> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13b7, 0x13be, x86_l_13be);
x86_l_13b9:
	/* 0x13b9: mov    r11,QWORD PTR [r11] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13bc:
	/* 0x13bc: jmp    13c1 <sys_enter_submit+0x13c1> */
	X86_SIM_X86_JMP(0x13bc, 0x13c1, x86_l_13c1);
x86_l_13be:
	/* 0x13be: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13c1:
	/* 0x13c1: mov    rdx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_13c4:
	/* 0x13c4: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13c7:
	/* 0x13c7: jns    13ce <sys_enter_submit+0x13ce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x13c7, 0x13ce, x86_l_13ce);
x86_l_13c9:
	/* 0x13c9: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13cc:
	/* 0x13cc: jmp    13d0 <sys_enter_submit+0x13d0> */
	X86_SIM_X86_JMP(0x13cc, 0x13d0, x86_l_13d0);
x86_l_13ce:
	/* 0x13ce: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13d0:
	/* 0x13d0: lea    r8,[r11+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13d4:
	/* 0x13d4: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_13d9:
	/* 0x13d9: jmp    1403 <sys_enter_submit+0x1403> */
	X86_SIM_X86_JMP(0x13d9, 0x1403, x86_l_1403);
x86_l_13db:
	/* 0x13db: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_13e0:
	/* 0x13e0: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_13e4:
	/* 0x13e4: mov    r15,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_13e7:
	/* 0x13e7: jl     1410 <sys_enter_submit+0x1410> */
	X86_SIM_X86_JCC(X86_CC_L, 0x13e7, 0x1410, x86_l_1410);
x86_l_13e9:
	/* 0x13e9: mov    r11,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_13ec:
	/* 0x13ec: mov    BYTE PTR [rax+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_13f3:
	/* 0x13f3: mov    ebx,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_13f8:
	/* 0x13f8: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_13fb:
	/* 0x13fb: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_13fe:
	/* 0x13fe: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1403:
	/* 0x1403: mov    rdi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1406:
	/* 0x1406: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1409:
	/* 0x1409: jns    1485 <sys_enter_submit+0x1485> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1409, 0x1485, x86_l_1485);
x86_l_140b:
	/* 0x140b: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_140e:
	/* 0x140e: jmp    1487 <sys_enter_submit+0x1487> */
	X86_SIM_X86_JMP(0x140e, 0x1487, x86_l_1487);
x86_l_1410:
	/* 0x1410: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1414:
	/* 0x1414: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1417:
	/* 0x1417: jns    1423 <sys_enter_submit+0x1423> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1417, 0x1423, x86_l_1423);
x86_l_1419:
	/* 0x1419: mov    rcx,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_141d:
	/* 0x141d: mov    rcx,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1421:
	/* 0x1421: jmp    1425 <sys_enter_submit+0x1425> */
	X86_SIM_X86_JMP(0x1421, 0x1425, x86_l_1425);
x86_l_1423:
	/* 0x1423: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1425:
	/* 0x1425: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1428:
	/* 0x1428: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_142d:
	/* 0x142d: jns    1451 <sys_enter_submit+0x1451> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x142d, 0x1451, x86_l_1451);
x86_l_142f:
	/* 0x142f: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1431:
	/* 0x1431: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1433:
	/* 0x1433: cmp    rdx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_143a:
	/* 0x143a: je     1477 <sys_enter_submit+0x1477> */
	X86_SIM_X86_JCC(X86_CC_E, 0x143a, 0x1477, x86_l_1477);
x86_l_143c:
	/* 0x143c: movzx  esi,BYTE PTR [rcx+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_8), 0ULL);
x86_l_1440:
	/* 0x1440: mov    BYTE PTR [rax+rdx*1],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1444:
	/* 0x1444: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1447:
	/* 0x1447: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_144a:
	/* 0x144a: jne    1433 <sys_enter_submit+0x1433> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x144a, 0x1433, x86_l_1433);
x86_l_144c:
	/* 0x144c: jmp    2ccc <sys_enter_submit+0x2ccc> */
	X86_SIM_X86_JMP(0x144c, 0x2ccc, x86_l_2ccc);
x86_l_1451:
	/* 0x1451: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1453:
	/* 0x1453: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_1458:
	/* 0x1458: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_145b:
	/* 0x145b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_145d:
	/* 0x145d: mov    r12,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1460:
	/* 0x1460: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1463:
	/* 0x1463: call   1468 <sys_enter_submit+0x1468> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_1468:
	/* 0x1468: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_146b:
	/* 0x146b: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_146e:
	/* 0x146e: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1472:
	/* 0x1472: jmp    2ccc <sys_enter_submit+0x2ccc> */
	X86_SIM_X86_JMP(0x1472, 0x2ccc, x86_l_2ccc);
x86_l_1477:
	/* 0x1477: mov    BYTE PTR [rax+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_147e:
	/* 0x147e: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1480:
	/* 0x1480: jmp    2ccc <sys_enter_submit+0x2ccc> */
	X86_SIM_X86_JMP(0x1480, 0x2ccc, x86_l_2ccc);
x86_l_1485:
	/* 0x1485: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1487:
	/* 0x1487: lea    r9,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R9, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_148b:
	/* 0x148b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_148e:
	/* 0x148e: jns    1495 <sys_enter_submit+0x1495> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x148e, 0x1495, x86_l_1495);
x86_l_1490:
	/* 0x1490: mov    rbp,QWORD PTR [r9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1493:
	/* 0x1493: jmp    1497 <sys_enter_submit+0x1497> */
	X86_SIM_X86_JMP(0x1493, 0x1497, x86_l_1497);
x86_l_1495:
	/* 0x1495: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1497:
	/* 0x1497: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_149a:
	/* 0x149a: je     1530 <sys_enter_submit+0x1530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x149a, 0x1530, x86_l_1530);
x86_l_14a0:
	/* 0x14a0: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_14a3:
	/* 0x14a3: je     1530 <sys_enter_submit+0x1530> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14a3, 0x1530, x86_l_1530);
x86_l_14a9:
	/* 0x14a9: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_14ad:
	/* 0x14ad: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14b0:
	/* 0x14b0: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_14b6:
	/* 0x14b6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14b9:
	/* 0x14b9: jns    14c2 <sys_enter_submit+0x14c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14b9, 0x14c2, x86_l_14c2);
x86_l_14bb:
	/* 0x14bb: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14be:
	/* 0x14be: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14c2:
	/* 0x14c2: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14c6:
	/* 0x14c6: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_14c9:
	/* 0x14c9: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_14d0:
	/* 0x14d0: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_14d2:
	/* 0x14d2: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_14d5:
	/* 0x14d5: jb     2cb2 <sys_enter_submit+0x2cb2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x14d5, 0x2cb2, x86_l_2cb2);
x86_l_14db:
	/* 0x14db: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_14de:
	/* 0x14de: je     10bb <sys_enter_submit+0x10bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14de, 0x10bb, x86_l_10bb);
x86_l_14e4:
	/* 0x14e4: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_14ea:
	/* 0x14ea: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_14ed:
	/* 0x14ed: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_14f0:
	/* 0x14f0: jns    19ae <sys_enter_submit+0x19ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x14f0, 0x19ae, x86_l_19ae);
x86_l_14f6:
	/* 0x14f6: mov    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_14f9:
	/* 0x14f9: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14fe:
	/* 0x14fe: mov    QWORD PTR [rsp+0x20],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1503:
	/* 0x1503: lea    r11d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1507:
	/* 0x1507: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_150a:
	/* 0x150a: cmp    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_150d:
	/* 0x150d: je     19d3 <sys_enter_submit+0x19d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x150d, 0x19d3, x86_l_19d3);
x86_l_1513:
	/* 0x1513: lea    r12,[r15+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1517:
	/* 0x1517: movzx  r13d,BYTE PTR [r10+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R15, 0, X86_WIDTH_8), 0ULL);
x86_l_151c:
	/* 0x151c: mov    BYTE PTR [rdi+r15*1],r13b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R13, X86_WIDTH_8, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_1520:
	/* 0x1520: mov    r15,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1523:
	/* 0x1523: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_1526:
	/* 0x1526: jne    150a <sys_enter_submit+0x150a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1526, 0x150a, x86_l_150a);
x86_l_1528:
	/* 0x1528: mov    r9d,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_152b:
	/* 0x152b: jmp    19d8 <sys_enter_submit+0x19d8> */
	X86_SIM_X86_JMP(0x152b, 0x19d8, x86_l_19d8);
x86_l_1530:
	/* 0x1530: cmp    rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1533:
	/* 0x1533: jne    10bb <sys_enter_submit+0x10bb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1533, 0x10bb, x86_l_10bb);
x86_l_1539:
	/* 0x1539: cmp    r11,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_153c:
	/* 0x153c: je     10bb <sys_enter_submit+0x10bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x153c, 0x10bb, x86_l_10bb);
x86_l_1542:
	/* 0x1542: lea    rdx,[r11+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1546:
	/* 0x1546: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1549:
	/* 0x1549: jns    16cd <sys_enter_submit+0x16cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1549, 0x16cd, x86_l_16cd);
x86_l_154f:
	/* 0x154f: mov    rbp,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1552:
	/* 0x1552: jmp    16cf <sys_enter_submit+0x16cf> */
	X86_SIM_X86_JMP(0x1552, 0x16cf, x86_l_16cf);
x86_l_1557:
	/* 0x1557: add    r15,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_155e:
	/* 0x155e: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1563:
	/* 0x1563: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1566:
	/* 0x1566: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1568:
	/* 0x1568: call   156d <sys_enter_submit+0x156d> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_156d:
	/* 0x156d: jmp    32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_X86_JMP(0x156d, 0x32f7, x86_l_32f7);
x86_l_1572:
	/* 0x1572: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1574:
	/* 0x1574: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1579:
	/* 0x1579: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_157e:
	/* 0x157e: add    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1582:
	/* 0x1582: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1585:
	/* 0x1585: jns    158c <sys_enter_submit+0x158c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1585, 0x158c, x86_l_158c);
x86_l_1587:
	/* 0x1587: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_158a:
	/* 0x158a: jmp    158e <sys_enter_submit+0x158e> */
	X86_SIM_X86_JMP(0x158a, 0x158e, x86_l_158e);
x86_l_158c:
	/* 0x158c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_158e:
	/* 0x158e: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1592:
	/* 0x1592: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1596:
	/* 0x1596: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1598:
	/* 0x1598: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_159b:
	/* 0x159b: jns    15a2 <sys_enter_submit+0x15a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x159b, 0x15a2, x86_l_15a2);
x86_l_159d:
	/* 0x159d: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15a0:
	/* 0x15a0: jmp    15a5 <sys_enter_submit+0x15a5> */
	X86_SIM_X86_JMP(0x15a0, 0x15a5, x86_l_15a5);
x86_l_15a2:
	/* 0x15a2: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15a5:
	/* 0x15a5: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_15aa:
	/* 0x15aa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15ad:
	/* 0x15ad: jns    15b1 <sys_enter_submit+0x15b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ad, 0x15b1, x86_l_15b1);
x86_l_15af:
	/* 0x15af: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b1:
	/* 0x15b1: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15b5:
	/* 0x15b5: mov    DWORD PTR [rax+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_15b8:
	/* 0x15b8: lea    rcx,[r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15bc:
	/* 0x15bc: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15bf:
	/* 0x15bf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c1:
	/* 0x15c1: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15c4:
	/* 0x15c4: jns    15cb <sys_enter_submit+0x15cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c4, 0x15cb, x86_l_15cb);
x86_l_15c6:
	/* 0x15c6: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15c9:
	/* 0x15c9: jmp    15cd <sys_enter_submit+0x15cd> */
	X86_SIM_X86_JMP(0x15c9, 0x15cd, x86_l_15cd);
x86_l_15cb:
	/* 0x15cb: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15cd:
	/* 0x15cd: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15d0:
	/* 0x15d0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_15d3:
	/* 0x15d3: jns    15d7 <sys_enter_submit+0x15d7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15d3, 0x15d7, x86_l_15d7);
x86_l_15d5:
	/* 0x15d5: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d7:
	/* 0x15d7: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_15d9:
	/* 0x15d9: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15dd:
	/* 0x15dd: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15e0:
	/* 0x15e0: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_15e4:
	/* 0x15e4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15e6:
	/* 0x15e6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15e9:
	/* 0x15e9: jns    15ed <sys_enter_submit+0x15ed> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15e9, 0x15ed, x86_l_15ed);
x86_l_15eb:
	/* 0x15eb: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ed:
	/* 0x15ed: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15f1:
	/* 0x15f1: mov    DWORD PTR [rax+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_15f4:
	/* 0x15f4: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_15f7:
	/* 0x15f7: jns    15fe <sys_enter_submit+0x15fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15f7, 0x15fe, x86_l_15fe);
x86_l_15f9:
	/* 0x15f9: mov    rdx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15fc:
	/* 0x15fc: jmp    1600 <sys_enter_submit+0x1600> */
	X86_SIM_X86_JMP(0x15fc, 0x1600, x86_l_1600);
x86_l_15fe:
	/* 0x15fe: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1600:
	/* 0x1600: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1604:
	/* 0x1604: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1606:
	/* 0x1606: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1609:
	/* 0x1609: jns    1610 <sys_enter_submit+0x1610> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1609, 0x1610, x86_l_1610);
x86_l_160b:
	/* 0x160b: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160e:
	/* 0x160e: jmp    1612 <sys_enter_submit+0x1612> */
	X86_SIM_X86_JMP(0x160e, 0x1612, x86_l_1612);
x86_l_1610:
	/* 0x1610: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1612:
	/* 0x1612: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1615:
	/* 0x1615: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1618:
	/* 0x1618: jns    161c <sys_enter_submit+0x161c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1618, 0x161c, x86_l_161c);
x86_l_161a:
	/* 0x161a: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_161c:
	/* 0x161c: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_161e:
	/* 0x161e: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1622:
	/* 0x1622: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1625:
	/* 0x1625: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1629:
	/* 0x1629: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_162b:
	/* 0x162b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_162e:
	/* 0x162e: jns    1632 <sys_enter_submit+0x1632> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x162e, 0x1632, x86_l_1632);
x86_l_1630:
	/* 0x1630: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1632:
	/* 0x1632: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1636:
	/* 0x1636: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1639:
	/* 0x1639: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_163b:
	/* 0x163b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_163e:
	/* 0x163e: jns    1645 <sys_enter_submit+0x1645> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x163e, 0x1645, x86_l_1645);
x86_l_1640:
	/* 0x1640: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1643:
	/* 0x1643: jmp    1647 <sys_enter_submit+0x1647> */
	X86_SIM_X86_JMP(0x1643, 0x1647, x86_l_1647);
x86_l_1645:
	/* 0x1645: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1647:
	/* 0x1647: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_164a:
	/* 0x164a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_164d:
	/* 0x164d: jns    1651 <sys_enter_submit+0x1651> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x164d, 0x1651, x86_l_1651);
x86_l_164f:
	/* 0x164f: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1651:
	/* 0x1651: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1653:
	/* 0x1653: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1657:
	/* 0x1657: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_165a:
	/* 0x165a: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_165e:
	/* 0x165e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1660:
	/* 0x1660: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1663:
	/* 0x1663: jns    166a <sys_enter_submit+0x166a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1663, 0x166a, x86_l_166a);
x86_l_1665:
	/* 0x1665: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1668:
	/* 0x1668: jmp    166c <sys_enter_submit+0x166c> */
	X86_SIM_X86_JMP(0x1668, 0x166c, x86_l_166c);
x86_l_166a:
	/* 0x166a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_166c:
	/* 0x166c: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1670:
	/* 0x1670: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1673:
	/* 0x1673: jns    1677 <sys_enter_submit+0x1677> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1673, 0x1677, x86_l_1677);
x86_l_1675:
	/* 0x1675: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1677:
	/* 0x1677: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_167c:
	/* 0x167c: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_167f:
	/* 0x167f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1681:
	/* 0x1681: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1684:
	/* 0x1684: jns    168b <sys_enter_submit+0x168b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1684, 0x168b, x86_l_168b);
x86_l_1686:
	/* 0x1686: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1689:
	/* 0x1689: jmp    168d <sys_enter_submit+0x168d> */
	X86_SIM_X86_JMP(0x1689, 0x168d, x86_l_168d);
x86_l_168b:
	/* 0x168b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_168d:
	/* 0x168d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1690:
	/* 0x1690: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1693:
	/* 0x1693: jns    1697 <sys_enter_submit+0x1697> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1693, 0x1697, x86_l_1697);
x86_l_1695:
	/* 0x1695: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1697:
	/* 0x1697: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1699:
	/* 0x1699: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_169d:
	/* 0x169d: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_16a0:
	/* 0x16a0: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_16a4:
	/* 0x16a4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a6:
	/* 0x16a6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16a9:
	/* 0x16a9: jns    16b0 <sys_enter_submit+0x16b0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16a9, 0x16b0, x86_l_16b0);
x86_l_16ab:
	/* 0x16ab: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16ae:
	/* 0x16ae: jmp    16b2 <sys_enter_submit+0x16b2> */
	X86_SIM_X86_JMP(0x16ae, 0x16b2, x86_l_16b2);
x86_l_16b0:
	/* 0x16b0: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16b2:
	/* 0x16b2: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_16b6:
	/* 0x16b6: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16b9:
	/* 0x16b9: jns    16bd <sys_enter_submit+0x16bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16b9, 0x16bd, x86_l_16bd);
x86_l_16bb:
	/* 0x16bb: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16bd:
	/* 0x16bd: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_16bf:
	/* 0x16bf: jne    172c <sys_enter_submit+0x172c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16bf, 0x172c, x86_l_172c);
x86_l_16c1:
	/* 0x16c1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c3:
	/* 0x16c3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16c6:
	/* 0x16c6: jns    1703 <sys_enter_submit+0x1703> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16c6, 0x1703, x86_l_1703);
x86_l_16c8:
	/* 0x16c8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16cb:
	/* 0x16cb: jmp    1705 <sys_enter_submit+0x1705> */
	X86_SIM_X86_JMP(0x16cb, 0x1705, x86_l_1705);
x86_l_16cd:
	/* 0x16cd: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16cf:
	/* 0x16cf: test   r11,r11 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_16d2:
	/* 0x16d2: jns    16d9 <sys_enter_submit+0x16d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16d2, 0x16d9, x86_l_16d9);
x86_l_16d4:
	/* 0x16d4: mov    r11,QWORD PTR [r11] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16d7:
	/* 0x16d7: jmp    16dc <sys_enter_submit+0x16dc> */
	X86_SIM_X86_JMP(0x16d7, 0x16dc, x86_l_16dc);
x86_l_16d9:
	/* 0x16d9: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16dc:
	/* 0x16dc: mov    rdx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_16df:
	/* 0x16df: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16e2:
	/* 0x16e2: jns    16e9 <sys_enter_submit+0x16e9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16e2, 0x16e9, x86_l_16e9);
x86_l_16e4:
	/* 0x16e4: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e7:
	/* 0x16e7: jmp    16eb <sys_enter_submit+0x16eb> */
	X86_SIM_X86_JMP(0x16e7, 0x16eb, x86_l_16eb);
x86_l_16e9:
	/* 0x16e9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16eb:
	/* 0x16eb: lea    r8,[r11+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16ef:
	/* 0x16ef: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_16f2:
	/* 0x16f2: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16f5:
	/* 0x16f5: jns    1a0f <sys_enter_submit+0x1a0f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f5, 0x1a0f, x86_l_1a0f);
x86_l_16fb:
	/* 0x16fb: mov    rdi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16fe:
	/* 0x16fe: jmp    1a11 <sys_enter_submit+0x1a11> */
	X86_SIM_X86_JMP(0x16fe, 0x1a11, x86_l_1a11);
x86_l_1703:
	/* 0x1703: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1705:
	/* 0x1705: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1708:
	/* 0x1708: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_170b:
	/* 0x170b: jns    170f <sys_enter_submit+0x170f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x170b, 0x170f, x86_l_170f);
x86_l_170d:
	/* 0x170d: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_170f:
	/* 0x170f: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1711:
	/* 0x1711: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1715:
	/* 0x1715: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1718:
	/* 0x1718: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_171c:
	/* 0x171c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_171e:
	/* 0x171e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1721:
	/* 0x1721: jns    1725 <sys_enter_submit+0x1725> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1721, 0x1725, x86_l_1725);
x86_l_1723:
	/* 0x1723: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1725:
	/* 0x1725: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1729:
	/* 0x1729: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_172c:
	/* 0x172c: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1730:
	/* 0x1730: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1733:
	/* 0x1733: lea    rbx,[r15+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_173a:
	/* 0x173a: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_173d:
	/* 0x173d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1740:
	/* 0x1740: jns    1747 <sys_enter_submit+0x1747> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1740, 0x1747, x86_l_1747);
x86_l_1742:
	/* 0x1742: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1745:
	/* 0x1745: jmp    1749 <sys_enter_submit+0x1749> */
	X86_SIM_X86_JMP(0x1745, 0x1749, x86_l_1749);
x86_l_1747:
	/* 0x1747: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1749:
	/* 0x1749: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_174d:
	/* 0x174d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_174f:
	/* 0x174f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1752:
	/* 0x1752: jns    1759 <sys_enter_submit+0x1759> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1752, 0x1759, x86_l_1759);
x86_l_1754:
	/* 0x1754: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1757:
	/* 0x1757: jmp    175b <sys_enter_submit+0x175b> */
	X86_SIM_X86_JMP(0x1757, 0x175b, x86_l_175b);
x86_l_1759:
	/* 0x1759: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_175b:
	/* 0x175b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_175e:
	/* 0x175e: jns    1762 <sys_enter_submit+0x1762> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175e, 0x1762, x86_l_1762);
x86_l_1760:
	/* 0x1760: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1762:
	/* 0x1762: mov    rbp,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1766:
	/* 0x1766: mov    DWORD PTR [rbp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1769:
	/* 0x1769: call   176e <sys_enter_submit+0x176e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_176e:
	/* 0x176e: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1771:
	/* 0x1771: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1774:
	/* 0x1774: lea    rax,[r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1778:
	/* 0x1778: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177b:
	/* 0x177b: jns    1782 <sys_enter_submit+0x1782> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x177b, 0x1782, x86_l_1782);
x86_l_177d:
	/* 0x177d: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1780:
	/* 0x1780: jmp    1784 <sys_enter_submit+0x1784> */
	X86_SIM_X86_JMP(0x1780, 0x1784, x86_l_1784);
x86_l_1782:
	/* 0x1782: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1784:
	/* 0x1784: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1788:
	/* 0x1788: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_178b:
	/* 0x178b: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1790:
	/* 0x1790: add    rax,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1794:
	/* 0x1794: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1797:
	/* 0x1797: jns    179e <sys_enter_submit+0x179e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1797, 0x179e, x86_l_179e);
x86_l_1799:
	/* 0x1799: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179c:
	/* 0x179c: jmp    17a0 <sys_enter_submit+0x17a0> */
	X86_SIM_X86_JMP(0x179c, 0x17a0, x86_l_17a0);
x86_l_179e:
	/* 0x179e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a0:
	/* 0x17a0: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_17a5:
	/* 0x17a5: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17a9:
	/* 0x17a9: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_17ad:
	/* 0x17ad: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_17b1:
	/* 0x17b1: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17b4:
	/* 0x17b4: jns    17bc <sys_enter_submit+0x17bc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17b4, 0x17bc, x86_l_17bc);
x86_l_17b6:
	/* 0x17b6: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ba:
	/* 0x17ba: jmp    17be <sys_enter_submit+0x17be> */
	X86_SIM_X86_JMP(0x17ba, 0x17be, x86_l_17be);
x86_l_17bc:
	/* 0x17bc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17be:
	/* 0x17be: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c2:
	/* 0x17c2: mov    QWORD PTR [r12+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_17c7:
	/* 0x17c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17ca:
	/* 0x17ca: jns    17d8 <sys_enter_submit+0x17d8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ca, 0x17d8, x86_l_17d8);
x86_l_17cc:
	/* 0x17cc: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17ce:
	/* 0x17ce: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_17d0:
	/* 0x17d0: je     17d8 <sys_enter_submit+0x17d8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17d0, 0x17d8, x86_l_17d8);
x86_l_17d2:
	/* 0x17d2: or     BYTE PTR [r12+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_17d8:
	/* 0x17d8: lea    rdi,[r12+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_17dd:
	/* 0x17dd: mov    QWORD PTR [r12+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_17e6:
	/* 0x17e6: mov    QWORD PTR [r12+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_17ef:
	/* 0x17ef: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_17f4:
	/* 0x17f4: call   17f9 <sys_enter_submit+0x17f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_17f9:
	/* 0x17f9: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17fc:
	/* 0x17fc: jns    1803 <sys_enter_submit+0x1803> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17fc, 0x1803, x86_l_1803);
x86_l_17fe:
	/* 0x17fe: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1801:
	/* 0x1801: jmp    1805 <sys_enter_submit+0x1805> */
	X86_SIM_X86_JMP(0x1801, 0x1805, x86_l_1805);
x86_l_1803:
	/* 0x1803: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1805:
	/* 0x1805: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1808:
	/* 0x1808: jns    180f <sys_enter_submit+0x180f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1808, 0x180f, x86_l_180f);
x86_l_180a:
	/* 0x180a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180d:
	/* 0x180d: jmp    1811 <sys_enter_submit+0x1811> */
	X86_SIM_X86_JMP(0x180d, 0x1811, x86_l_1811);
x86_l_180f:
	/* 0x180f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1811:
	/* 0x1811: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1814:
	/* 0x1814: jns    1861 <sys_enter_submit+0x1861> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1814, 0x1861, x86_l_1861);
x86_l_1816:
	/* 0x1816: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1819:
	/* 0x1819: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_181e:
	/* 0x181e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1822:
	/* 0x1822: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1827:
	/* 0x1827: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_182b:
	/* 0x182b: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1830:
	/* 0x1830: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1834:
	/* 0x1834: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1839:
	/* 0x1839: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_183d:
	/* 0x183d: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1842:
	/* 0x1842: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1846:
	/* 0x1846: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_184b:
	/* 0x184b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_184f:
	/* 0x184f: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1854:
	/* 0x1854: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1858:
	/* 0x1858: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_185d:
	/* 0x185d: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1861:
	/* 0x1861: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1864:
	/* 0x1864: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_1868:
	/* 0x1868: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_186d:
	/* 0x186d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1870:
	/* 0x1870: jns    1995 <sys_enter_submit+0x1995> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1870, 0x1995, x86_l_1995);
x86_l_1876:
	/* 0x1876: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1879:
	/* 0x1879: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_187b:
	/* 0x187b: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_187d:
	/* 0x187d: je     19a4 <sys_enter_submit+0x19a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x187d, 0x19a4, x86_l_19a4);
x86_l_1883:
	/* 0x1883: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1887:
	/* 0x1887: mov    BYTE PTR [r12+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_188c:
	/* 0x188c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_188e:
	/* 0x188e: je     19a4 <sys_enter_submit+0x19a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x188e, 0x19a4, x86_l_19a4);
x86_l_1894:
	/* 0x1894: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1898:
	/* 0x1898: mov    BYTE PTR [r12+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_189d:
	/* 0x189d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_189f:
	/* 0x189f: je     19a4 <sys_enter_submit+0x19a4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x189f, 0x19a4, x86_l_19a4);
x86_l_18a5:
	/* 0x18a5: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_18a9:
	/* 0x18a9: mov    BYTE PTR [r12+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_18ae:
	/* 0x18ae: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18b0:
	/* 0x18b0: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b0, 0x19bb, x86_l_19bb);
x86_l_18b6:
	/* 0x18b6: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_18ba:
	/* 0x18ba: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18be:
	/* 0x18be: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_18c1:
	/* 0x18c1: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18c3:
	/* 0x18c3: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18c3, 0x19bb, x86_l_19bb);
x86_l_18c9:
	/* 0x18c9: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_18cd:
	/* 0x18cd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d1:
	/* 0x18d1: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_18d4:
	/* 0x18d4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18d6:
	/* 0x18d6: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18d6, 0x19bb, x86_l_19bb);
x86_l_18dc:
	/* 0x18dc: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_18e0:
	/* 0x18e0: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18e4:
	/* 0x18e4: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_18e7:
	/* 0x18e7: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18e9:
	/* 0x18e9: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e9, 0x19bb, x86_l_19bb);
x86_l_18ef:
	/* 0x18ef: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_18f3:
	/* 0x18f3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18f7:
	/* 0x18f7: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_18fa:
	/* 0x18fa: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_18fc:
	/* 0x18fc: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18fc, 0x19bb, x86_l_19bb);
x86_l_1902:
	/* 0x1902: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_1906:
	/* 0x1906: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_190a:
	/* 0x190a: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_190d:
	/* 0x190d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_190f:
	/* 0x190f: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x190f, 0x19bb, x86_l_19bb);
x86_l_1915:
	/* 0x1915: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_1919:
	/* 0x1919: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_191d:
	/* 0x191d: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_1920:
	/* 0x1920: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1922:
	/* 0x1922: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1922, 0x19bb, x86_l_19bb);
x86_l_1928:
	/* 0x1928: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_192c:
	/* 0x192c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1930:
	/* 0x1930: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_1933:
	/* 0x1933: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1935:
	/* 0x1935: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1935, 0x19bb, x86_l_19bb);
x86_l_193b:
	/* 0x193b: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_193f:
	/* 0x193f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1943:
	/* 0x1943: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1946:
	/* 0x1946: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1948:
	/* 0x1948: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1948, 0x19bb, x86_l_19bb);
x86_l_194a:
	/* 0x194a: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_194e:
	/* 0x194e: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1952:
	/* 0x1952: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1955:
	/* 0x1955: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1957:
	/* 0x1957: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1957, 0x19bb, x86_l_19bb);
x86_l_1959:
	/* 0x1959: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_195d:
	/* 0x195d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1961:
	/* 0x1961: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1964:
	/* 0x1964: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1966:
	/* 0x1966: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1966, 0x19bb, x86_l_19bb);
x86_l_1968:
	/* 0x1968: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_196c:
	/* 0x196c: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1970:
	/* 0x1970: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1973:
	/* 0x1973: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1975:
	/* 0x1975: je     19bb <sys_enter_submit+0x19bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1975, 0x19bb, x86_l_19bb);
x86_l_1977:
	/* 0x1977: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_197b:
	/* 0x197b: mov    BYTE PTR [r12+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_1981:
	/* 0x1981: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1986:
	/* 0x1986: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_198b:
	/* 0x198b: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1990:
	/* 0x1990: jmp    224 <sys_enter_submit+0x224> */
	X86_SIM_X86_JMP(0x1990, 0x224, x86_l_224);
x86_l_1995:
	/* 0x1995: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_199d:
	/* 0x199d: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19a4:
	/* 0x19a4: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19a9:
	/* 0x19a9: jmp    224 <sys_enter_submit+0x224> */
	X86_SIM_X86_JMP(0x19a9, 0x224, x86_l_224);
x86_l_19ae:
	/* 0x19ae: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19b3:
	/* 0x19b3: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_19b6:
	/* 0x19b6: jmp    10a9 <sys_enter_submit+0x10a9> */
	X86_SIM_X86_JMP(0x19b6, 0x10a9, x86_l_10a9);
x86_l_19bb:
	/* 0x19bb: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19c0:
	/* 0x19c0: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19c5:
	/* 0x19c5: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19ca:
	/* 0x19ca: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19ce:
	/* 0x19ce: jmp    224 <sys_enter_submit+0x224> */
	X86_SIM_X86_JMP(0x19ce, 0x224, x86_l_224);
x86_l_19d3:
	/* 0x19d3: mov    BYTE PTR [rdi+r11*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_19d8:
	/* 0x19d8: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_19dc:
	/* 0x19dc: jl     1ae4 <sys_enter_submit+0x1ae4> */
	X86_SIM_X86_JCC(X86_CC_L, 0x19dc, 0x1ae4, x86_l_1ae4);
x86_l_19e2:
	/* 0x19e2: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_19e5:
	/* 0x19e5: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_19eb:
	/* 0x19eb: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_19ef:
	/* 0x19ef: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_19f2:
	/* 0x19f2: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19f7:
	/* 0x19f7: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19fc:
	/* 0x19fc: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a00:
	/* 0x1a00: mov    r11,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a03:
	/* 0x1a03: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1a06:
	/* 0x1a06: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a09:
	/* 0x1a09: js     16fb <sys_enter_submit+0x16fb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a09, 0x16fb, x86_l_16fb);
x86_l_1a0f:
	/* 0x1a0f: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a11:
	/* 0x1a11: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a15:
	/* 0x1a15: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a18:
	/* 0x1a18: jns    1a1f <sys_enter_submit+0x1a1f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a18, 0x1a1f, x86_l_1a1f);
x86_l_1a1a:
	/* 0x1a1a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a1d:
	/* 0x1a1d: jmp    1a21 <sys_enter_submit+0x1a21> */
	X86_SIM_X86_JMP(0x1a1d, 0x1a21, x86_l_1a21);
x86_l_1a1f:
	/* 0x1a1f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a21:
	/* 0x1a21: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a24:
	/* 0x1a24: je     1ab7 <sys_enter_submit+0x1ab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a24, 0x1ab7, x86_l_1ab7);
x86_l_1a2a:
	/* 0x1a2a: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1a2d:
	/* 0x1a2d: je     1ab7 <sys_enter_submit+0x1ab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a2d, 0x1ab7, x86_l_1ab7);
x86_l_1a33:
	/* 0x1a33: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a37:
	/* 0x1a37: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a3a:
	/* 0x1a3a: mov    r10d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1a40:
	/* 0x1a40: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a43:
	/* 0x1a43: jns    1a4c <sys_enter_submit+0x1a4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a43, 0x1a4c, x86_l_1a4c);
x86_l_1a45:
	/* 0x1a45: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a48:
	/* 0x1a48: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a4c:
	/* 0x1a4c: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1a50:
	/* 0x1a50: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1a53:
	/* 0x1a53: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1a5a:
	/* 0x1a5a: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1a5c:
	/* 0x1a5c: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1a5f:
	/* 0x1a5f: jb     2cb2 <sys_enter_submit+0x2cb2> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1a5f, 0x2cb2, x86_l_2cb2);
x86_l_1a65:
	/* 0x1a65: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a6a:
	/* 0x1a6a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1a6d:
	/* 0x1a6d: je     1b1f <sys_enter_submit+0x1b1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a6d, 0x1b1f, x86_l_1b1f);
x86_l_1a73:
	/* 0x1a73: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1a79:
	/* 0x1a79: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a7e:
	/* 0x1a7e: add    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a81:
	/* 0x1a81: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1a84:
	/* 0x1a84: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1a84, 0x2aa9, x86_l_2aa9);
x86_l_1a8a:
	/* 0x1a8a: mov    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1a8d:
	/* 0x1a8d: lea    eax,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1a91:
	/* 0x1a91: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a94:
	/* 0x1a94: cmp    rax,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1a97:
	/* 0x1a97: je     1b27 <sys_enter_submit+0x1b27> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a97, 0x1b27, x86_l_1b27);
x86_l_1a9d:
	/* 0x1a9d: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1aa1:
	/* 0x1aa1: movzx  r12d,BYTE PTR [r10+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R10, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1aa6:
	/* 0x1aa6: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1aaa:
	/* 0x1aaa: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1aad:
	/* 0x1aad: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1ab0:
	/* 0x1ab0: jne    1a94 <sys_enter_submit+0x1a94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ab0, 0x1a94, x86_l_1a94);
x86_l_1ab2:
	/* 0x1ab2: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1ab5:
	/* 0x1ab5: jmp    1b2b <sys_enter_submit+0x1b2b> */
	X86_SIM_X86_JMP(0x1ab5, 0x1b2b, x86_l_1b2b);
x86_l_1ab7:
	/* 0x1ab7: cmp    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1aba:
	/* 0x1aba: jne    1adc <sys_enter_submit+0x1adc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1aba, 0x1adc, x86_l_1adc);
x86_l_1abc:
	/* 0x1abc: cmp    r11,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R11, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1abf:
	/* 0x1abf: je     1adc <sys_enter_submit+0x1adc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1abf, 0x1adc, x86_l_1adc);
x86_l_1ac1:
	/* 0x1ac1: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ac6:
	/* 0x1ac6: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1acb:
	/* 0x1acb: mov    rcx,r11 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ace:
	/* 0x1ace: lea    rax,[r11+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ad2:
	/* 0x1ad2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ad5:
	/* 0x1ad5: jns    1aee <sys_enter_submit+0x1aee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ad5, 0x1aee, x86_l_1aee);
x86_l_1ad7:
	/* 0x1ad7: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ada:
	/* 0x1ada: jmp    1af0 <sys_enter_submit+0x1af0> */
	X86_SIM_X86_JMP(0x1ada, 0x1af0, x86_l_1af0);
x86_l_1adc:
	/* 0x1adc: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1adf:
	/* 0x1adf: jmp    10bb <sys_enter_submit+0x10bb> */
	X86_SIM_X86_JMP(0x1adf, 0x10bb, x86_l_10bb);
x86_l_1ae4:
	/* 0x1ae4: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ae9:
	/* 0x1ae9: jmp    2c51 <sys_enter_submit+0x2c51> */
	X86_SIM_X86_JMP(0x1ae9, 0x2c51, x86_l_2c51);
x86_l_1aee:
	/* 0x1aee: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1af0:
	/* 0x1af0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1af3:
	/* 0x1af3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1af6:
	/* 0x1af6: jns    1afd <sys_enter_submit+0x1afd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af6, 0x1afd, x86_l_1afd);
x86_l_1af8:
	/* 0x1af8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1afb:
	/* 0x1afb: jmp    1aff <sys_enter_submit+0x1aff> */
	X86_SIM_X86_JMP(0x1afb, 0x1aff, x86_l_1aff);
x86_l_1afd:
	/* 0x1afd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aff:
	/* 0x1aff: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b02:
	/* 0x1b02: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b05:
	/* 0x1b05: jns    1b0c <sys_enter_submit+0x1b0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b05, 0x1b0c, x86_l_1b0c);
x86_l_1b07:
	/* 0x1b07: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b0a:
	/* 0x1b0a: jmp    1b0e <sys_enter_submit+0x1b0e> */
	X86_SIM_X86_JMP(0x1b0a, 0x1b0e, x86_l_1b0e);
x86_l_1b0c:
	/* 0x1b0c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b0e:
	/* 0x1b0e: lea    rax,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b12:
	/* 0x1b12: mov    r8,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b15:
	/* 0x1b15: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b18:
	/* 0x1b18: jns    1b55 <sys_enter_submit+0x1b55> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b18, 0x1b55, x86_l_1b55);
x86_l_1b1a:
	/* 0x1b1a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b1d:
	/* 0x1b1d: jmp    1b57 <sys_enter_submit+0x1b57> */
	X86_SIM_X86_JMP(0x1b1d, 0x1b57, x86_l_1b57);
x86_l_1b1f:
	/* 0x1b1f: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b22:
	/* 0x1b22: jmp    2c51 <sys_enter_submit+0x2c51> */
	X86_SIM_X86_JMP(0x1b22, 0x2c51, x86_l_2c51);
x86_l_1b27:
	/* 0x1b27: mov    BYTE PTR [rdi+rax*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1b2b:
	/* 0x1b2b: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1b2f:
	/* 0x1b2f: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1b2f, 0x2c49, x86_l_2c49);
x86_l_1b35:
	/* 0x1b35: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b38:
	/* 0x1b38: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1b3e:
	/* 0x1b3e: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b43:
	/* 0x1b43: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1b47:
	/* 0x1b47: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b4a:
	/* 0x1b4a: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1b4d:
	/* 0x1b4d: mov    r8,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b50:
	/* 0x1b50: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b53:
	/* 0x1b53: js     1b1a <sys_enter_submit+0x1b1a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b53, 0x1b1a, x86_l_1b1a);
x86_l_1b55:
	/* 0x1b55: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b57:
	/* 0x1b57: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b5b:
	/* 0x1b5b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b5e:
	/* 0x1b5e: jns    1b65 <sys_enter_submit+0x1b65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b5e, 0x1b65, x86_l_1b65);
x86_l_1b60:
	/* 0x1b60: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b63:
	/* 0x1b63: jmp    1b67 <sys_enter_submit+0x1b67> */
	X86_SIM_X86_JMP(0x1b63, 0x1b67, x86_l_1b67);
x86_l_1b65:
	/* 0x1b65: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b67:
	/* 0x1b67: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1b6a:
	/* 0x1b6a: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b6d:
	/* 0x1b6d: je     1be8 <sys_enter_submit+0x1be8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b6d, 0x1be8, x86_l_1be8);
x86_l_1b6f:
	/* 0x1b6f: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1b72:
	/* 0x1b72: je     1be8 <sys_enter_submit+0x1be8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b72, 0x1be8, x86_l_1be8);
x86_l_1b74:
	/* 0x1b74: add    rdi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1b78:
	/* 0x1b78: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b7b:
	/* 0x1b7b: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1b80:
	/* 0x1b80: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b83:
	/* 0x1b83: jns    1b8c <sys_enter_submit+0x1b8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b83, 0x1b8c, x86_l_1b8c);
x86_l_1b85:
	/* 0x1b85: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b88:
	/* 0x1b88: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b8c:
	/* 0x1b8c: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b90:
	/* 0x1b90: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1b93:
	/* 0x1b93: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b9a:
	/* 0x1b9a: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1b9c:
	/* 0x1b9c: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b9f:
	/* 0x1b9f: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b9f, 0x2ca4, x86_l_2ca4);
x86_l_1ba5:
	/* 0x1ba5: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1ba8:
	/* 0x1ba8: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ba8, 0x2c4c, x86_l_2c4c);
x86_l_1bae:
	/* 0x1bae: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1bb4:
	/* 0x1bb4: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1bb9:
	/* 0x1bb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bbc:
	/* 0x1bbc: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bbc, 0x2aa6, x86_l_2aa6);
x86_l_1bc2:
	/* 0x1bc2: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bc6:
	/* 0x1bc6: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bc9:
	/* 0x1bc9: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1bcc:
	/* 0x1bcc: je     1c39 <sys_enter_submit+0x1c39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bcc, 0x1c39, x86_l_1c39);
x86_l_1bce:
	/* 0x1bce: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1bd2:
	/* 0x1bd2: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1bd7:
	/* 0x1bd7: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1bdb:
	/* 0x1bdb: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1bde:
	/* 0x1bde: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1be1:
	/* 0x1be1: jne    1bc9 <sys_enter_submit+0x1bc9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1be1, 0x1bc9, x86_l_1bc9);
x86_l_1be3:
	/* 0x1be3: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1be6:
	/* 0x1be6: jmp    1c3e <sys_enter_submit+0x1c3e> */
	X86_SIM_X86_JMP(0x1be6, 0x1c3e, x86_l_1c3e);
x86_l_1be8:
	/* 0x1be8: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1beb:
	/* 0x1beb: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1beb, 0x2c4c, x86_l_2c4c);
x86_l_1bf1:
	/* 0x1bf1: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bf4:
	/* 0x1bf4: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bf4, 0x2c4c, x86_l_2c4c);
x86_l_1bfa:
	/* 0x1bfa: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bfe:
	/* 0x1bfe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c01:
	/* 0x1c01: jns    1c08 <sys_enter_submit+0x1c08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c01, 0x1c08, x86_l_1c08);
x86_l_1c03:
	/* 0x1c03: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c06:
	/* 0x1c06: jmp    1c0a <sys_enter_submit+0x1c0a> */
	X86_SIM_X86_JMP(0x1c06, 0x1c0a, x86_l_1c0a);
x86_l_1c08:
	/* 0x1c08: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c0a:
	/* 0x1c0a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c0d:
	/* 0x1c0d: jns    1c17 <sys_enter_submit+0x1c17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c0d, 0x1c17, x86_l_1c17);
x86_l_1c0f:
	/* 0x1c0f: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c12:
	/* 0x1c12: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c15:
	/* 0x1c15: jmp    1c19 <sys_enter_submit+0x1c19> */
	X86_SIM_X86_JMP(0x1c15, 0x1c19, x86_l_1c19);
x86_l_1c17:
	/* 0x1c17: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c19:
	/* 0x1c19: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c1c:
	/* 0x1c1c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c1f:
	/* 0x1c1f: jns    1c26 <sys_enter_submit+0x1c26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c1f, 0x1c26, x86_l_1c26);
x86_l_1c21:
	/* 0x1c21: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c24:
	/* 0x1c24: jmp    1c28 <sys_enter_submit+0x1c28> */
	X86_SIM_X86_JMP(0x1c24, 0x1c28, x86_l_1c28);
x86_l_1c26:
	/* 0x1c26: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c28:
	/* 0x1c28: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c2c:
	/* 0x1c2c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1c2f:
	/* 0x1c2f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c32:
	/* 0x1c32: jns    1c65 <sys_enter_submit+0x1c65> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c32, 0x1c65, x86_l_1c65);
x86_l_1c34:
	/* 0x1c34: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c37:
	/* 0x1c37: jmp    1c67 <sys_enter_submit+0x1c67> */
	X86_SIM_X86_JMP(0x1c37, 0x1c67, x86_l_1c67);
x86_l_1c39:
	/* 0x1c39: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1c3e:
	/* 0x1c3e: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1c42:
	/* 0x1c42: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1c42, 0x2c4c, x86_l_2c4c);
x86_l_1c48:
	/* 0x1c48: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c4b:
	/* 0x1c4b: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1c51:
	/* 0x1c51: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c56:
	/* 0x1c56: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_1c5a:
	/* 0x1c5a: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c5d:
	/* 0x1c5d: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1c60:
	/* 0x1c60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c63:
	/* 0x1c63: js     1c34 <sys_enter_submit+0x1c34> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1c63, 0x1c34, x86_l_1c34);
x86_l_1c65:
	/* 0x1c65: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c67:
	/* 0x1c67: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c6b:
	/* 0x1c6b: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c6e:
	/* 0x1c6e: jns    1c75 <sys_enter_submit+0x1c75> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c6e, 0x1c75, x86_l_1c75);
x86_l_1c70:
	/* 0x1c70: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c73:
	/* 0x1c73: jmp    1c77 <sys_enter_submit+0x1c77> */
	X86_SIM_X86_JMP(0x1c73, 0x1c77, x86_l_1c77);
x86_l_1c75:
	/* 0x1c75: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c77:
	/* 0x1c77: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c7a:
	/* 0x1c7a: je     1cf5 <sys_enter_submit+0x1cf5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c7a, 0x1cf5, x86_l_1cf5);
x86_l_1c7c:
	/* 0x1c7c: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1c7f:
	/* 0x1c7f: je     1cf5 <sys_enter_submit+0x1cf5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c7f, 0x1cf5, x86_l_1cf5);
x86_l_1c81:
	/* 0x1c81: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c85:
	/* 0x1c85: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c88:
	/* 0x1c88: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c8d:
	/* 0x1c8d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c90:
	/* 0x1c90: jns    1c99 <sys_enter_submit+0x1c99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c90, 0x1c99, x86_l_1c99);
x86_l_1c92:
	/* 0x1c92: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c95:
	/* 0x1c95: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c99:
	/* 0x1c99: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c9d:
	/* 0x1c9d: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1ca0:
	/* 0x1ca0: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1ca7:
	/* 0x1ca7: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1ca9:
	/* 0x1ca9: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1cac:
	/* 0x1cac: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cac, 0x2ca4, x86_l_2ca4);
x86_l_1cb2:
	/* 0x1cb2: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1cb5:
	/* 0x1cb5: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cb5, 0x2c49, x86_l_2c49);
x86_l_1cbb:
	/* 0x1cbb: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1cc1:
	/* 0x1cc1: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1cc6:
	/* 0x1cc6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc9:
	/* 0x1cc9: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc9, 0x2aa9, x86_l_2aa9);
x86_l_1ccf:
	/* 0x1ccf: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1cd3:
	/* 0x1cd3: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cd6:
	/* 0x1cd6: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1cd9:
	/* 0x1cd9: je     1d46 <sys_enter_submit+0x1d46> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd9, 0x1d46, x86_l_1d46);
x86_l_1cdb:
	/* 0x1cdb: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1cdf:
	/* 0x1cdf: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1ce4:
	/* 0x1ce4: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ce8:
	/* 0x1ce8: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1ceb:
	/* 0x1ceb: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1cee:
	/* 0x1cee: jne    1cd6 <sys_enter_submit+0x1cd6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cee, 0x1cd6, x86_l_1cd6);
x86_l_1cf0:
	/* 0x1cf0: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1cf3:
	/* 0x1cf3: jmp    1d4b <sys_enter_submit+0x1d4b> */
	X86_SIM_X86_JMP(0x1cf3, 0x1d4b, x86_l_1d4b);
x86_l_1cf5:
	/* 0x1cf5: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cf8:
	/* 0x1cf8: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cf8, 0x2c49, x86_l_2c49);
x86_l_1cfe:
	/* 0x1cfe: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1d01:
	/* 0x1d01: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d01, 0x2c49, x86_l_2c49);
x86_l_1d07:
	/* 0x1d07: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d0b:
	/* 0x1d0b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d0e:
	/* 0x1d0e: jns    1d15 <sys_enter_submit+0x1d15> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d0e, 0x1d15, x86_l_1d15);
x86_l_1d10:
	/* 0x1d10: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d13:
	/* 0x1d13: jmp    1d17 <sys_enter_submit+0x1d17> */
	X86_SIM_X86_JMP(0x1d13, 0x1d17, x86_l_1d17);
x86_l_1d15:
	/* 0x1d15: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d17:
	/* 0x1d17: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d1a:
	/* 0x1d1a: jns    1d24 <sys_enter_submit+0x1d24> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1a, 0x1d24, x86_l_1d24);
x86_l_1d1c:
	/* 0x1d1c: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d1f:
	/* 0x1d1f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d22:
	/* 0x1d22: jmp    1d26 <sys_enter_submit+0x1d26> */
	X86_SIM_X86_JMP(0x1d22, 0x1d26, x86_l_1d26);
x86_l_1d24:
	/* 0x1d24: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d26:
	/* 0x1d26: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d29:
	/* 0x1d29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d2c:
	/* 0x1d2c: jns    1d33 <sys_enter_submit+0x1d33> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d2c, 0x1d33, x86_l_1d33);
x86_l_1d2e:
	/* 0x1d2e: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d31:
	/* 0x1d31: jmp    1d35 <sys_enter_submit+0x1d35> */
	X86_SIM_X86_JMP(0x1d31, 0x1d35, x86_l_1d35);
x86_l_1d33:
	/* 0x1d33: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d35:
	/* 0x1d35: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d39:
	/* 0x1d39: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d3c:
	/* 0x1d3c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d3f:
	/* 0x1d3f: jns    1d72 <sys_enter_submit+0x1d72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d3f, 0x1d72, x86_l_1d72);
x86_l_1d41:
	/* 0x1d41: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d44:
	/* 0x1d44: jmp    1d74 <sys_enter_submit+0x1d74> */
	X86_SIM_X86_JMP(0x1d44, 0x1d74, x86_l_1d74);
x86_l_1d46:
	/* 0x1d46: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1d4b:
	/* 0x1d4b: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1d4f:
	/* 0x1d4f: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d4f, 0x2c49, x86_l_2c49);
x86_l_1d55:
	/* 0x1d55: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d58:
	/* 0x1d58: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d5e:
	/* 0x1d5e: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d63:
	/* 0x1d63: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1d67:
	/* 0x1d67: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d6a:
	/* 0x1d6a: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d6d:
	/* 0x1d6d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d70:
	/* 0x1d70: js     1d41 <sys_enter_submit+0x1d41> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d70, 0x1d41, x86_l_1d41);
x86_l_1d72:
	/* 0x1d72: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d74:
	/* 0x1d74: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d78:
	/* 0x1d78: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d7b:
	/* 0x1d7b: jns    1d82 <sys_enter_submit+0x1d82> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d7b, 0x1d82, x86_l_1d82);
x86_l_1d7d:
	/* 0x1d7d: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d80:
	/* 0x1d80: jmp    1d84 <sys_enter_submit+0x1d84> */
	X86_SIM_X86_JMP(0x1d80, 0x1d84, x86_l_1d84);
x86_l_1d82:
	/* 0x1d82: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d84:
	/* 0x1d84: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d87:
	/* 0x1d87: je     1e02 <sys_enter_submit+0x1e02> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d87, 0x1e02, x86_l_1e02);
x86_l_1d89:
	/* 0x1d89: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1d8c:
	/* 0x1d8c: je     1e02 <sys_enter_submit+0x1e02> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d8c, 0x1e02, x86_l_1e02);
x86_l_1d8e:
	/* 0x1d8e: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d92:
	/* 0x1d92: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d95:
	/* 0x1d95: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d9a:
	/* 0x1d9a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d9d:
	/* 0x1d9d: jns    1da6 <sys_enter_submit+0x1da6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d9d, 0x1da6, x86_l_1da6);
x86_l_1d9f:
	/* 0x1d9f: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1da2:
	/* 0x1da2: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1da6:
	/* 0x1da6: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1daa:
	/* 0x1daa: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1dad:
	/* 0x1dad: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1db4:
	/* 0x1db4: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1db6:
	/* 0x1db6: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1db9:
	/* 0x1db9: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1db9, 0x2ca4, x86_l_2ca4);
x86_l_1dbf:
	/* 0x1dbf: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1dc2:
	/* 0x1dc2: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dc2, 0x2c4c, x86_l_2c4c);
x86_l_1dc8:
	/* 0x1dc8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1dce:
	/* 0x1dce: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1dd3:
	/* 0x1dd3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dd6:
	/* 0x1dd6: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dd6, 0x2aa6, x86_l_2aa6);
x86_l_1ddc:
	/* 0x1ddc: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1de0:
	/* 0x1de0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de3:
	/* 0x1de3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1de6:
	/* 0x1de6: je     1e53 <sys_enter_submit+0x1e53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de6, 0x1e53, x86_l_1e53);
x86_l_1de8:
	/* 0x1de8: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1dec:
	/* 0x1dec: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1df1:
	/* 0x1df1: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1df5:
	/* 0x1df5: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1df8:
	/* 0x1df8: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1dfb:
	/* 0x1dfb: jne    1de3 <sys_enter_submit+0x1de3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dfb, 0x1de3, x86_l_1de3);
x86_l_1dfd:
	/* 0x1dfd: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1e00:
	/* 0x1e00: jmp    1e58 <sys_enter_submit+0x1e58> */
	X86_SIM_X86_JMP(0x1e00, 0x1e58, x86_l_1e58);
x86_l_1e02:
	/* 0x1e02: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e05:
	/* 0x1e05: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e05, 0x2c4c, x86_l_2c4c);
x86_l_1e0b:
	/* 0x1e0b: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e0e:
	/* 0x1e0e: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e0e, 0x2c4c, x86_l_2c4c);
x86_l_1e14:
	/* 0x1e14: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e18:
	/* 0x1e18: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e1b:
	/* 0x1e1b: jns    1e22 <sys_enter_submit+0x1e22> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e1b, 0x1e22, x86_l_1e22);
x86_l_1e1d:
	/* 0x1e1d: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e20:
	/* 0x1e20: jmp    1e24 <sys_enter_submit+0x1e24> */
	X86_SIM_X86_JMP(0x1e20, 0x1e24, x86_l_1e24);
x86_l_1e22:
	/* 0x1e22: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e24:
	/* 0x1e24: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e27:
	/* 0x1e27: jns    1e31 <sys_enter_submit+0x1e31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e27, 0x1e31, x86_l_1e31);
x86_l_1e29:
	/* 0x1e29: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e2c:
	/* 0x1e2c: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e2f:
	/* 0x1e2f: jmp    1e33 <sys_enter_submit+0x1e33> */
	X86_SIM_X86_JMP(0x1e2f, 0x1e33, x86_l_1e33);
x86_l_1e31:
	/* 0x1e31: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e33:
	/* 0x1e33: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e36:
	/* 0x1e36: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e39:
	/* 0x1e39: jns    1e40 <sys_enter_submit+0x1e40> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e39, 0x1e40, x86_l_1e40);
x86_l_1e3b:
	/* 0x1e3b: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e3e:
	/* 0x1e3e: jmp    1e42 <sys_enter_submit+0x1e42> */
	X86_SIM_X86_JMP(0x1e3e, 0x1e42, x86_l_1e42);
x86_l_1e40:
	/* 0x1e40: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e42:
	/* 0x1e42: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e46:
	/* 0x1e46: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e49:
	/* 0x1e49: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e4c:
	/* 0x1e4c: jns    1e7f <sys_enter_submit+0x1e7f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e4c, 0x1e7f, x86_l_1e7f);
x86_l_1e4e:
	/* 0x1e4e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e51:
	/* 0x1e51: jmp    1e81 <sys_enter_submit+0x1e81> */
	X86_SIM_X86_JMP(0x1e51, 0x1e81, x86_l_1e81);
x86_l_1e53:
	/* 0x1e53: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e58:
	/* 0x1e58: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e5c:
	/* 0x1e5c: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e5c, 0x2c4c, x86_l_2c4c);
x86_l_1e62:
	/* 0x1e62: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e65:
	/* 0x1e65: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1e6b:
	/* 0x1e6b: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e70:
	/* 0x1e70: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_1e74:
	/* 0x1e74: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e77:
	/* 0x1e77: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1e7a:
	/* 0x1e7a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e7d:
	/* 0x1e7d: js     1e4e <sys_enter_submit+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e7d, 0x1e4e, x86_l_1e4e);
x86_l_1e7f:
	/* 0x1e7f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e81:
	/* 0x1e81: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e85:
	/* 0x1e85: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e88:
	/* 0x1e88: jns    1e8f <sys_enter_submit+0x1e8f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e88, 0x1e8f, x86_l_1e8f);
x86_l_1e8a:
	/* 0x1e8a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8d:
	/* 0x1e8d: jmp    1e91 <sys_enter_submit+0x1e91> */
	X86_SIM_X86_JMP(0x1e8d, 0x1e91, x86_l_1e91);
x86_l_1e8f:
	/* 0x1e8f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e91:
	/* 0x1e91: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e94:
	/* 0x1e94: je     1f0f <sys_enter_submit+0x1f0f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e94, 0x1f0f, x86_l_1f0f);
x86_l_1e96:
	/* 0x1e96: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e99:
	/* 0x1e99: je     1f0f <sys_enter_submit+0x1f0f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e99, 0x1f0f, x86_l_1f0f);
x86_l_1e9b:
	/* 0x1e9b: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e9f:
	/* 0x1e9f: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ea2:
	/* 0x1ea2: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1ea7:
	/* 0x1ea7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1eaa:
	/* 0x1eaa: jns    1eb3 <sys_enter_submit+0x1eb3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eaa, 0x1eb3, x86_l_1eb3);
x86_l_1eac:
	/* 0x1eac: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eaf:
	/* 0x1eaf: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eb3:
	/* 0x1eb3: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1eb7:
	/* 0x1eb7: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1eba:
	/* 0x1eba: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1ec1:
	/* 0x1ec1: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1ec3:
	/* 0x1ec3: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1ec6:
	/* 0x1ec6: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ec6, 0x2ca4, x86_l_2ca4);
x86_l_1ecc:
	/* 0x1ecc: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1ecf:
	/* 0x1ecf: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ecf, 0x2c49, x86_l_2c49);
x86_l_1ed5:
	/* 0x1ed5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1edb:
	/* 0x1edb: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1ee0:
	/* 0x1ee0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ee3:
	/* 0x1ee3: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ee3, 0x2aa9, x86_l_2aa9);
x86_l_1ee9:
	/* 0x1ee9: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eed:
	/* 0x1eed: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ef0:
	/* 0x1ef0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ef3:
	/* 0x1ef3: je     1f60 <sys_enter_submit+0x1f60> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef3, 0x1f60, x86_l_1f60);
x86_l_1ef5:
	/* 0x1ef5: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ef9:
	/* 0x1ef9: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1efe:
	/* 0x1efe: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1f02:
	/* 0x1f02: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1f05:
	/* 0x1f05: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1f08:
	/* 0x1f08: jne    1ef0 <sys_enter_submit+0x1ef0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f08, 0x1ef0, x86_l_1ef0);
x86_l_1f0a:
	/* 0x1f0a: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1f0d:
	/* 0x1f0d: jmp    1f65 <sys_enter_submit+0x1f65> */
	X86_SIM_X86_JMP(0x1f0d, 0x1f65, x86_l_1f65);
x86_l_1f0f:
	/* 0x1f0f: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f12:
	/* 0x1f12: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f12, 0x2c49, x86_l_2c49);
x86_l_1f18:
	/* 0x1f18: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1f1b:
	/* 0x1f1b: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f1b, 0x2c49, x86_l_2c49);
x86_l_1f21:
	/* 0x1f21: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f25:
	/* 0x1f25: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f28:
	/* 0x1f28: jns    1f2f <sys_enter_submit+0x1f2f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f28, 0x1f2f, x86_l_1f2f);
x86_l_1f2a:
	/* 0x1f2a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f2d:
	/* 0x1f2d: jmp    1f31 <sys_enter_submit+0x1f31> */
	X86_SIM_X86_JMP(0x1f2d, 0x1f31, x86_l_1f31);
x86_l_1f2f:
	/* 0x1f2f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f31:
	/* 0x1f31: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f34:
	/* 0x1f34: jns    1f3e <sys_enter_submit+0x1f3e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f34, 0x1f3e, x86_l_1f3e);
x86_l_1f36:
	/* 0x1f36: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f39:
	/* 0x1f39: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f3c:
	/* 0x1f3c: jmp    1f40 <sys_enter_submit+0x1f40> */
	X86_SIM_X86_JMP(0x1f3c, 0x1f40, x86_l_1f40);
x86_l_1f3e:
	/* 0x1f3e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f40:
	/* 0x1f40: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f43:
	/* 0x1f43: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f46:
	/* 0x1f46: jns    1f4d <sys_enter_submit+0x1f4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f46, 0x1f4d, x86_l_1f4d);
x86_l_1f48:
	/* 0x1f48: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f4b:
	/* 0x1f4b: jmp    1f4f <sys_enter_submit+0x1f4f> */
	X86_SIM_X86_JMP(0x1f4b, 0x1f4f, x86_l_1f4f);
x86_l_1f4d:
	/* 0x1f4d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f4f:
	/* 0x1f4f: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f53:
	/* 0x1f53: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f56:
	/* 0x1f56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f59:
	/* 0x1f59: jns    1f8c <sys_enter_submit+0x1f8c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f59, 0x1f8c, x86_l_1f8c);
x86_l_1f5b:
	/* 0x1f5b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5e:
	/* 0x1f5e: jmp    1f8e <sys_enter_submit+0x1f8e> */
	X86_SIM_X86_JMP(0x1f5e, 0x1f8e, x86_l_1f8e);
x86_l_1f60:
	/* 0x1f60: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1f65:
	/* 0x1f65: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f69:
	/* 0x1f69: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f69, 0x2c49, x86_l_2c49);
x86_l_1f6f:
	/* 0x1f6f: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f72:
	/* 0x1f72: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f78:
	/* 0x1f78: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f7d:
	/* 0x1f7d: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1f81:
	/* 0x1f81: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f84:
	/* 0x1f84: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f87:
	/* 0x1f87: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f8a:
	/* 0x1f8a: js     1f5b <sys_enter_submit+0x1f5b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f8a, 0x1f5b, x86_l_1f5b);
x86_l_1f8c:
	/* 0x1f8c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8e:
	/* 0x1f8e: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f92:
	/* 0x1f92: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f95:
	/* 0x1f95: jns    1f9c <sys_enter_submit+0x1f9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f95, 0x1f9c, x86_l_1f9c);
x86_l_1f97:
	/* 0x1f97: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f9a:
	/* 0x1f9a: jmp    1f9e <sys_enter_submit+0x1f9e> */
	X86_SIM_X86_JMP(0x1f9a, 0x1f9e, x86_l_1f9e);
x86_l_1f9c:
	/* 0x1f9c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f9e:
	/* 0x1f9e: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fa1:
	/* 0x1fa1: je     201c <sys_enter_submit+0x201c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa1, 0x201c, x86_l_201c);
x86_l_1fa3:
	/* 0x1fa3: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1fa6:
	/* 0x1fa6: je     201c <sys_enter_submit+0x201c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fa6, 0x201c, x86_l_201c);
x86_l_1fa8:
	/* 0x1fa8: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fac:
	/* 0x1fac: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1faf:
	/* 0x1faf: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1fb4:
	/* 0x1fb4: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1fb7:
	/* 0x1fb7: jns    1fc0 <sys_enter_submit+0x1fc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb7, 0x1fc0, x86_l_1fc0);
x86_l_1fb9:
	/* 0x1fb9: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fbc:
	/* 0x1fbc: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fc0:
	/* 0x1fc0: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1fc4:
	/* 0x1fc4: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1fc7:
	/* 0x1fc7: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1fce:
	/* 0x1fce: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1fd0:
	/* 0x1fd0: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fd3:
	/* 0x1fd3: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1fd3, 0x2ca4, x86_l_2ca4);
x86_l_1fd9:
	/* 0x1fd9: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1fdc:
	/* 0x1fdc: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fdc, 0x2c4c, x86_l_2c4c);
x86_l_1fe2:
	/* 0x1fe2: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1fe8:
	/* 0x1fe8: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1fed:
	/* 0x1fed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ff0:
	/* 0x1ff0: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ff0, 0x2aa6, x86_l_2aa6);
x86_l_1ff6:
	/* 0x1ff6: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1ffa:
	/* 0x1ffa: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ffd:
	/* 0x1ffd: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2000:
	/* 0x2000: je     206d <sys_enter_submit+0x206d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2000, 0x206d, x86_l_206d);
x86_l_2002:
	/* 0x2002: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2006:
	/* 0x2006: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_200b:
	/* 0x200b: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_200f:
	/* 0x200f: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2012:
	/* 0x2012: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2015:
	/* 0x2015: jne    1ffd <sys_enter_submit+0x1ffd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2015, 0x1ffd, x86_l_1ffd);
x86_l_2017:
	/* 0x2017: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_201a:
	/* 0x201a: jmp    2072 <sys_enter_submit+0x2072> */
	X86_SIM_X86_JMP(0x201a, 0x2072, x86_l_2072);
x86_l_201c:
	/* 0x201c: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_201f:
	/* 0x201f: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x201f, 0x2c4c, x86_l_2c4c);
x86_l_2025:
	/* 0x2025: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2028:
	/* 0x2028: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2028, 0x2c4c, x86_l_2c4c);
x86_l_202e:
	/* 0x202e: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2032:
	/* 0x2032: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2035:
	/* 0x2035: jns    203c <sys_enter_submit+0x203c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2035, 0x203c, x86_l_203c);
x86_l_2037:
	/* 0x2037: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_203a:
	/* 0x203a: jmp    203e <sys_enter_submit+0x203e> */
	X86_SIM_X86_JMP(0x203a, 0x203e, x86_l_203e);
x86_l_203c:
	/* 0x203c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_203e:
	/* 0x203e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2041:
	/* 0x2041: jns    204b <sys_enter_submit+0x204b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2041, 0x204b, x86_l_204b);
x86_l_2043:
	/* 0x2043: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2046:
	/* 0x2046: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2049:
	/* 0x2049: jmp    204d <sys_enter_submit+0x204d> */
	X86_SIM_X86_JMP(0x2049, 0x204d, x86_l_204d);
x86_l_204b:
	/* 0x204b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_204d:
	/* 0x204d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2050:
	/* 0x2050: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2053:
	/* 0x2053: jns    205a <sys_enter_submit+0x205a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2053, 0x205a, x86_l_205a);
x86_l_2055:
	/* 0x2055: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2058:
	/* 0x2058: jmp    205c <sys_enter_submit+0x205c> */
	X86_SIM_X86_JMP(0x2058, 0x205c, x86_l_205c);
x86_l_205a:
	/* 0x205a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_205c:
	/* 0x205c: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2060:
	/* 0x2060: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2063:
	/* 0x2063: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2066:
	/* 0x2066: jns    2099 <sys_enter_submit+0x2099> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2066, 0x2099, x86_l_2099);
x86_l_2068:
	/* 0x2068: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_206b:
	/* 0x206b: jmp    209b <sys_enter_submit+0x209b> */
	X86_SIM_X86_JMP(0x206b, 0x209b, x86_l_209b);
x86_l_206d:
	/* 0x206d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2072:
	/* 0x2072: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2076:
	/* 0x2076: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2076, 0x2c4c, x86_l_2c4c);
x86_l_207c:
	/* 0x207c: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_207f:
	/* 0x207f: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2085:
	/* 0x2085: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_208a:
	/* 0x208a: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_208e:
	/* 0x208e: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2091:
	/* 0x2091: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2094:
	/* 0x2094: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2097:
	/* 0x2097: js     2068 <sys_enter_submit+0x2068> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2097, 0x2068, x86_l_2068);
x86_l_2099:
	/* 0x2099: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_209b:
	/* 0x209b: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_209f:
	/* 0x209f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20a2:
	/* 0x20a2: jns    20a9 <sys_enter_submit+0x20a9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20a2, 0x20a9, x86_l_20a9);
x86_l_20a4:
	/* 0x20a4: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20a7:
	/* 0x20a7: jmp    20ab <sys_enter_submit+0x20ab> */
	X86_SIM_X86_JMP(0x20a7, 0x20ab, x86_l_20ab);
x86_l_20a9:
	/* 0x20a9: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20ab:
	/* 0x20ab: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20ae:
	/* 0x20ae: je     2129 <sys_enter_submit+0x2129> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ae, 0x2129, x86_l_2129);
x86_l_20b0:
	/* 0x20b0: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_20b3:
	/* 0x20b3: je     2129 <sys_enter_submit+0x2129> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b3, 0x2129, x86_l_2129);
x86_l_20b5:
	/* 0x20b5: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20b9:
	/* 0x20b9: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20bc:
	/* 0x20bc: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_20c1:
	/* 0x20c1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20c4:
	/* 0x20c4: jns    20cd <sys_enter_submit+0x20cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20c4, 0x20cd, x86_l_20cd);
x86_l_20c6:
	/* 0x20c6: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20c9:
	/* 0x20c9: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20cd:
	/* 0x20cd: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_20d1:
	/* 0x20d1: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20d4:
	/* 0x20d4: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20db:
	/* 0x20db: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_20dd:
	/* 0x20dd: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20e0:
	/* 0x20e0: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20e0, 0x2ca4, x86_l_2ca4);
x86_l_20e6:
	/* 0x20e6: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_20e9:
	/* 0x20e9: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20e9, 0x2c49, x86_l_2c49);
x86_l_20ef:
	/* 0x20ef: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20f5:
	/* 0x20f5: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_20fa:
	/* 0x20fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20fd:
	/* 0x20fd: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20fd, 0x2aa9, x86_l_2aa9);
x86_l_2103:
	/* 0x2103: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2107:
	/* 0x2107: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210a:
	/* 0x210a: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_210d:
	/* 0x210d: je     217a <sys_enter_submit+0x217a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x210d, 0x217a, x86_l_217a);
x86_l_210f:
	/* 0x210f: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2113:
	/* 0x2113: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2118:
	/* 0x2118: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_211c:
	/* 0x211c: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_211f:
	/* 0x211f: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2122:
	/* 0x2122: jne    210a <sys_enter_submit+0x210a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2122, 0x210a, x86_l_210a);
x86_l_2124:
	/* 0x2124: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2127:
	/* 0x2127: jmp    217f <sys_enter_submit+0x217f> */
	X86_SIM_X86_JMP(0x2127, 0x217f, x86_l_217f);
x86_l_2129:
	/* 0x2129: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_212c:
	/* 0x212c: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x212c, 0x2c49, x86_l_2c49);
x86_l_2132:
	/* 0x2132: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2135:
	/* 0x2135: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2135, 0x2c49, x86_l_2c49);
x86_l_213b:
	/* 0x213b: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_213f:
	/* 0x213f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2142:
	/* 0x2142: jns    2149 <sys_enter_submit+0x2149> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2142, 0x2149, x86_l_2149);
x86_l_2144:
	/* 0x2144: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2147:
	/* 0x2147: jmp    214b <sys_enter_submit+0x214b> */
	X86_SIM_X86_JMP(0x2147, 0x214b, x86_l_214b);
x86_l_2149:
	/* 0x2149: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214b:
	/* 0x214b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_214e:
	/* 0x214e: jns    2158 <sys_enter_submit+0x2158> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x214e, 0x2158, x86_l_2158);
x86_l_2150:
	/* 0x2150: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2153:
	/* 0x2153: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2156:
	/* 0x2156: jmp    215a <sys_enter_submit+0x215a> */
	X86_SIM_X86_JMP(0x2156, 0x215a, x86_l_215a);
x86_l_2158:
	/* 0x2158: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215a:
	/* 0x215a: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_215d:
	/* 0x215d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2160:
	/* 0x2160: jns    2167 <sys_enter_submit+0x2167> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2160, 0x2167, x86_l_2167);
x86_l_2162:
	/* 0x2162: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2165:
	/* 0x2165: jmp    2169 <sys_enter_submit+0x2169> */
	X86_SIM_X86_JMP(0x2165, 0x2169, x86_l_2169);
x86_l_2167:
	/* 0x2167: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2169:
	/* 0x2169: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_216d:
	/* 0x216d: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2170:
	/* 0x2170: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2173:
	/* 0x2173: jns    21a6 <sys_enter_submit+0x21a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2173, 0x21a6, x86_l_21a6);
x86_l_2175:
	/* 0x2175: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2178:
	/* 0x2178: jmp    21a8 <sys_enter_submit+0x21a8> */
	X86_SIM_X86_JMP(0x2178, 0x21a8, x86_l_21a8);
x86_l_217a:
	/* 0x217a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_217f:
	/* 0x217f: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2183:
	/* 0x2183: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2183, 0x2c49, x86_l_2c49);
x86_l_2189:
	/* 0x2189: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_218c:
	/* 0x218c: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2192:
	/* 0x2192: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2197:
	/* 0x2197: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_219b:
	/* 0x219b: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_219e:
	/* 0x219e: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_21a1:
	/* 0x21a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21a4:
	/* 0x21a4: js     2175 <sys_enter_submit+0x2175> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21a4, 0x2175, x86_l_2175);
x86_l_21a6:
	/* 0x21a6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21a8:
	/* 0x21a8: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21ac:
	/* 0x21ac: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21af:
	/* 0x21af: jns    21b6 <sys_enter_submit+0x21b6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21af, 0x21b6, x86_l_21b6);
x86_l_21b1:
	/* 0x21b1: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21b4:
	/* 0x21b4: jmp    21b8 <sys_enter_submit+0x21b8> */
	X86_SIM_X86_JMP(0x21b4, 0x21b8, x86_l_21b8);
x86_l_21b6:
	/* 0x21b6: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b8:
	/* 0x21b8: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21bb:
	/* 0x21bb: je     2236 <sys_enter_submit+0x2236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21bb, 0x2236, x86_l_2236);
x86_l_21bd:
	/* 0x21bd: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_21c0:
	/* 0x21c0: je     2236 <sys_enter_submit+0x2236> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21c0, 0x2236, x86_l_2236);
x86_l_21c2:
	/* 0x21c2: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21c6:
	/* 0x21c6: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21c9:
	/* 0x21c9: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_21ce:
	/* 0x21ce: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21d1:
	/* 0x21d1: jns    21da <sys_enter_submit+0x21da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21d1, 0x21da, x86_l_21da);
x86_l_21d3:
	/* 0x21d3: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21d6:
	/* 0x21d6: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21da:
	/* 0x21da: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_21de:
	/* 0x21de: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21e1:
	/* 0x21e1: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_21e8:
	/* 0x21e8: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_21ea:
	/* 0x21ea: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21ed:
	/* 0x21ed: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x21ed, 0x2ca4, x86_l_2ca4);
x86_l_21f3:
	/* 0x21f3: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_21f6:
	/* 0x21f6: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21f6, 0x2c4c, x86_l_2c4c);
x86_l_21fc:
	/* 0x21fc: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2202:
	/* 0x2202: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2207:
	/* 0x2207: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_220a:
	/* 0x220a: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x220a, 0x2aa6, x86_l_2aa6);
x86_l_2210:
	/* 0x2210: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2214:
	/* 0x2214: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2217:
	/* 0x2217: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_221a:
	/* 0x221a: je     2287 <sys_enter_submit+0x2287> */
	X86_SIM_X86_JCC(X86_CC_E, 0x221a, 0x2287, x86_l_2287);
x86_l_221c:
	/* 0x221c: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2220:
	/* 0x2220: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2225:
	/* 0x2225: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2229:
	/* 0x2229: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_222c:
	/* 0x222c: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_222f:
	/* 0x222f: jne    2217 <sys_enter_submit+0x2217> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x222f, 0x2217, x86_l_2217);
x86_l_2231:
	/* 0x2231: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2234:
	/* 0x2234: jmp    228c <sys_enter_submit+0x228c> */
	X86_SIM_X86_JMP(0x2234, 0x228c, x86_l_228c);
x86_l_2236:
	/* 0x2236: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2239:
	/* 0x2239: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2239, 0x2c4c, x86_l_2c4c);
x86_l_223f:
	/* 0x223f: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2242:
	/* 0x2242: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2242, 0x2c4c, x86_l_2c4c);
x86_l_2248:
	/* 0x2248: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_224c:
	/* 0x224c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_224f:
	/* 0x224f: jns    2256 <sys_enter_submit+0x2256> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x224f, 0x2256, x86_l_2256);
x86_l_2251:
	/* 0x2251: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2254:
	/* 0x2254: jmp    2258 <sys_enter_submit+0x2258> */
	X86_SIM_X86_JMP(0x2254, 0x2258, x86_l_2258);
x86_l_2256:
	/* 0x2256: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2258:
	/* 0x2258: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_225b:
	/* 0x225b: jns    2265 <sys_enter_submit+0x2265> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x225b, 0x2265, x86_l_2265);
x86_l_225d:
	/* 0x225d: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2260:
	/* 0x2260: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2263:
	/* 0x2263: jmp    2267 <sys_enter_submit+0x2267> */
	X86_SIM_X86_JMP(0x2263, 0x2267, x86_l_2267);
x86_l_2265:
	/* 0x2265: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2267:
	/* 0x2267: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_226a:
	/* 0x226a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_226d:
	/* 0x226d: jns    2274 <sys_enter_submit+0x2274> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x226d, 0x2274, x86_l_2274);
x86_l_226f:
	/* 0x226f: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2272:
	/* 0x2272: jmp    2276 <sys_enter_submit+0x2276> */
	X86_SIM_X86_JMP(0x2272, 0x2276, x86_l_2276);
x86_l_2274:
	/* 0x2274: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2276:
	/* 0x2276: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_227a:
	/* 0x227a: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_227d:
	/* 0x227d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2280:
	/* 0x2280: jns    22b3 <sys_enter_submit+0x22b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2280, 0x22b3, x86_l_22b3);
x86_l_2282:
	/* 0x2282: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2285:
	/* 0x2285: jmp    22b5 <sys_enter_submit+0x22b5> */
	X86_SIM_X86_JMP(0x2285, 0x22b5, x86_l_22b5);
x86_l_2287:
	/* 0x2287: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_228c:
	/* 0x228c: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2290:
	/* 0x2290: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2290, 0x2c4c, x86_l_2c4c);
x86_l_2296:
	/* 0x2296: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2299:
	/* 0x2299: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_229f:
	/* 0x229f: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22a4:
	/* 0x22a4: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_22a8:
	/* 0x22a8: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22ab:
	/* 0x22ab: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_22ae:
	/* 0x22ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22b1:
	/* 0x22b1: js     2282 <sys_enter_submit+0x2282> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22b1, 0x2282, x86_l_2282);
x86_l_22b3:
	/* 0x22b3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22b5:
	/* 0x22b5: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22b9:
	/* 0x22b9: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22bc:
	/* 0x22bc: jns    22c3 <sys_enter_submit+0x22c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22bc, 0x22c3, x86_l_22c3);
x86_l_22be:
	/* 0x22be: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22c1:
	/* 0x22c1: jmp    22c5 <sys_enter_submit+0x22c5> */
	X86_SIM_X86_JMP(0x22c1, 0x22c5, x86_l_22c5);
x86_l_22c3:
	/* 0x22c3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22c5:
	/* 0x22c5: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22c8:
	/* 0x22c8: je     2343 <sys_enter_submit+0x2343> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c8, 0x2343, x86_l_2343);
x86_l_22ca:
	/* 0x22ca: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22cd:
	/* 0x22cd: je     2343 <sys_enter_submit+0x2343> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22cd, 0x2343, x86_l_2343);
x86_l_22cf:
	/* 0x22cf: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22d3:
	/* 0x22d3: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22d6:
	/* 0x22d6: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_22db:
	/* 0x22db: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_22de:
	/* 0x22de: jns    22e7 <sys_enter_submit+0x22e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22de, 0x22e7, x86_l_22e7);
x86_l_22e0:
	/* 0x22e0: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22e3:
	/* 0x22e3: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e7:
	/* 0x22e7: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_22eb:
	/* 0x22eb: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_22ee:
	/* 0x22ee: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_22f5:
	/* 0x22f5: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_22f7:
	/* 0x22f7: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22fa:
	/* 0x22fa: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22fa, 0x2ca4, x86_l_2ca4);
x86_l_2300:
	/* 0x2300: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2303:
	/* 0x2303: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2303, 0x2c49, x86_l_2c49);
x86_l_2309:
	/* 0x2309: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_230f:
	/* 0x230f: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2314:
	/* 0x2314: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2317:
	/* 0x2317: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2317, 0x2aa9, x86_l_2aa9);
x86_l_231d:
	/* 0x231d: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2321:
	/* 0x2321: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2324:
	/* 0x2324: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2327:
	/* 0x2327: je     2394 <sys_enter_submit+0x2394> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2327, 0x2394, x86_l_2394);
x86_l_2329:
	/* 0x2329: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_232d:
	/* 0x232d: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2332:
	/* 0x2332: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2336:
	/* 0x2336: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2339:
	/* 0x2339: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_233c:
	/* 0x233c: jne    2324 <sys_enter_submit+0x2324> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x233c, 0x2324, x86_l_2324);
x86_l_233e:
	/* 0x233e: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2341:
	/* 0x2341: jmp    2399 <sys_enter_submit+0x2399> */
	X86_SIM_X86_JMP(0x2341, 0x2399, x86_l_2399);
x86_l_2343:
	/* 0x2343: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2346:
	/* 0x2346: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2346, 0x2c49, x86_l_2c49);
x86_l_234c:
	/* 0x234c: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_234f:
	/* 0x234f: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234f, 0x2c49, x86_l_2c49);
x86_l_2355:
	/* 0x2355: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2359:
	/* 0x2359: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_235c:
	/* 0x235c: jns    2363 <sys_enter_submit+0x2363> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x235c, 0x2363, x86_l_2363);
x86_l_235e:
	/* 0x235e: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2361:
	/* 0x2361: jmp    2365 <sys_enter_submit+0x2365> */
	X86_SIM_X86_JMP(0x2361, 0x2365, x86_l_2365);
x86_l_2363:
	/* 0x2363: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2365:
	/* 0x2365: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2368:
	/* 0x2368: jns    2372 <sys_enter_submit+0x2372> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2368, 0x2372, x86_l_2372);
x86_l_236a:
	/* 0x236a: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_236d:
	/* 0x236d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2370:
	/* 0x2370: jmp    2374 <sys_enter_submit+0x2374> */
	X86_SIM_X86_JMP(0x2370, 0x2374, x86_l_2374);
x86_l_2372:
	/* 0x2372: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2374:
	/* 0x2374: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2377:
	/* 0x2377: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_237a:
	/* 0x237a: jns    2381 <sys_enter_submit+0x2381> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x237a, 0x2381, x86_l_2381);
x86_l_237c:
	/* 0x237c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_237f:
	/* 0x237f: jmp    2383 <sys_enter_submit+0x2383> */
	X86_SIM_X86_JMP(0x237f, 0x2383, x86_l_2383);
x86_l_2381:
	/* 0x2381: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2383:
	/* 0x2383: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2387:
	/* 0x2387: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_238a:
	/* 0x238a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_238d:
	/* 0x238d: jns    23c0 <sys_enter_submit+0x23c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x238d, 0x23c0, x86_l_23c0);
x86_l_238f:
	/* 0x238f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2392:
	/* 0x2392: jmp    23c2 <sys_enter_submit+0x23c2> */
	X86_SIM_X86_JMP(0x2392, 0x23c2, x86_l_23c2);
x86_l_2394:
	/* 0x2394: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2399:
	/* 0x2399: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_239d:
	/* 0x239d: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x239d, 0x2c49, x86_l_2c49);
x86_l_23a3:
	/* 0x23a3: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23a6:
	/* 0x23a6: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23ac:
	/* 0x23ac: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23b1:
	/* 0x23b1: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_23b5:
	/* 0x23b5: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23b8:
	/* 0x23b8: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_23bb:
	/* 0x23bb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23be:
	/* 0x23be: js     238f <sys_enter_submit+0x238f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x23be, 0x238f, x86_l_238f);
x86_l_23c0:
	/* 0x23c0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23c2:
	/* 0x23c2: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23c6:
	/* 0x23c6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23c9:
	/* 0x23c9: jns    23d0 <sys_enter_submit+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23c9, 0x23d0, x86_l_23d0);
x86_l_23cb:
	/* 0x23cb: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ce:
	/* 0x23ce: jmp    23d2 <sys_enter_submit+0x23d2> */
	X86_SIM_X86_JMP(0x23ce, 0x23d2, x86_l_23d2);
x86_l_23d0:
	/* 0x23d0: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23d2:
	/* 0x23d2: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23d5:
	/* 0x23d5: je     2450 <sys_enter_submit+0x2450> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23d5, 0x2450, x86_l_2450);
x86_l_23d7:
	/* 0x23d7: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_23da:
	/* 0x23da: je     2450 <sys_enter_submit+0x2450> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23da, 0x2450, x86_l_2450);
x86_l_23dc:
	/* 0x23dc: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23e0:
	/* 0x23e0: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23e3:
	/* 0x23e3: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_23e8:
	/* 0x23e8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23eb:
	/* 0x23eb: jns    23f4 <sys_enter_submit+0x23f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23eb, 0x23f4, x86_l_23f4);
x86_l_23ed:
	/* 0x23ed: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23f0:
	/* 0x23f0: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23f4:
	/* 0x23f4: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_23f8:
	/* 0x23f8: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_23fb:
	/* 0x23fb: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2402:
	/* 0x2402: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2404:
	/* 0x2404: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2407:
	/* 0x2407: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2407, 0x2ca4, x86_l_2ca4);
x86_l_240d:
	/* 0x240d: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2410:
	/* 0x2410: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2410, 0x2c4c, x86_l_2c4c);
x86_l_2416:
	/* 0x2416: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_241c:
	/* 0x241c: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2421:
	/* 0x2421: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2424:
	/* 0x2424: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2424, 0x2aa6, x86_l_2aa6);
x86_l_242a:
	/* 0x242a: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_242e:
	/* 0x242e: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2431:
	/* 0x2431: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2434:
	/* 0x2434: je     24a1 <sys_enter_submit+0x24a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2434, 0x24a1, x86_l_24a1);
x86_l_2436:
	/* 0x2436: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_243a:
	/* 0x243a: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_243f:
	/* 0x243f: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2443:
	/* 0x2443: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2446:
	/* 0x2446: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2449:
	/* 0x2449: jne    2431 <sys_enter_submit+0x2431> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2449, 0x2431, x86_l_2431);
x86_l_244b:
	/* 0x244b: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_244e:
	/* 0x244e: jmp    24a6 <sys_enter_submit+0x24a6> */
	X86_SIM_X86_JMP(0x244e, 0x24a6, x86_l_24a6);
x86_l_2450:
	/* 0x2450: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2453:
	/* 0x2453: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2453, 0x2c4c, x86_l_2c4c);
x86_l_2459:
	/* 0x2459: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_245c:
	/* 0x245c: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x245c, 0x2c4c, x86_l_2c4c);
x86_l_2462:
	/* 0x2462: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2466:
	/* 0x2466: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2469:
	/* 0x2469: jns    2470 <sys_enter_submit+0x2470> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2469, 0x2470, x86_l_2470);
x86_l_246b:
	/* 0x246b: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_246e:
	/* 0x246e: jmp    2472 <sys_enter_submit+0x2472> */
	X86_SIM_X86_JMP(0x246e, 0x2472, x86_l_2472);
x86_l_2470:
	/* 0x2470: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2472:
	/* 0x2472: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2475:
	/* 0x2475: jns    247f <sys_enter_submit+0x247f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2475, 0x247f, x86_l_247f);
x86_l_2477:
	/* 0x2477: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_247a:
	/* 0x247a: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_247d:
	/* 0x247d: jmp    2481 <sys_enter_submit+0x2481> */
	X86_SIM_X86_JMP(0x247d, 0x2481, x86_l_2481);
x86_l_247f:
	/* 0x247f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2481:
	/* 0x2481: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2484:
	/* 0x2484: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2487:
	/* 0x2487: jns    248e <sys_enter_submit+0x248e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2487, 0x248e, x86_l_248e);
x86_l_2489:
	/* 0x2489: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_248c:
	/* 0x248c: jmp    2490 <sys_enter_submit+0x2490> */
	X86_SIM_X86_JMP(0x248c, 0x2490, x86_l_2490);
x86_l_248e:
	/* 0x248e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2490:
	/* 0x2490: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2494:
	/* 0x2494: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2497:
	/* 0x2497: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_249a:
	/* 0x249a: jns    24cd <sys_enter_submit+0x24cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x249a, 0x24cd, x86_l_24cd);
x86_l_249c:
	/* 0x249c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_249f:
	/* 0x249f: jmp    24cf <sys_enter_submit+0x24cf> */
	X86_SIM_X86_JMP(0x249f, 0x24cf, x86_l_24cf);
x86_l_24a1:
	/* 0x24a1: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_24a6:
	/* 0x24a6: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_24aa:
	/* 0x24aa: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x24aa, 0x2c4c, x86_l_2c4c);
x86_l_24b0:
	/* 0x24b0: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_24b3:
	/* 0x24b3: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_24b9:
	/* 0x24b9: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24be:
	/* 0x24be: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_24c2:
	/* 0x24c2: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_24c5:
	/* 0x24c5: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_24c8:
	/* 0x24c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24cb:
	/* 0x24cb: js     249c <sys_enter_submit+0x249c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x24cb, 0x249c, x86_l_249c);
x86_l_24cd:
	/* 0x24cd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24cf:
	/* 0x24cf: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24d3:
	/* 0x24d3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24d6:
	/* 0x24d6: jns    24dd <sys_enter_submit+0x24dd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24d6, 0x24dd, x86_l_24dd);
x86_l_24d8:
	/* 0x24d8: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24db:
	/* 0x24db: jmp    24df <sys_enter_submit+0x24df> */
	X86_SIM_X86_JMP(0x24db, 0x24df, x86_l_24df);
x86_l_24dd:
	/* 0x24dd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24df:
	/* 0x24df: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24e2:
	/* 0x24e2: je     255d <sys_enter_submit+0x255d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24e2, 0x255d, x86_l_255d);
x86_l_24e4:
	/* 0x24e4: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24e7:
	/* 0x24e7: je     255d <sys_enter_submit+0x255d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24e7, 0x255d, x86_l_255d);
x86_l_24e9:
	/* 0x24e9: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ed:
	/* 0x24ed: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24f0:
	/* 0x24f0: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_24f5:
	/* 0x24f5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24f8:
	/* 0x24f8: jns    2501 <sys_enter_submit+0x2501> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f8, 0x2501, x86_l_2501);
x86_l_24fa:
	/* 0x24fa: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fd:
	/* 0x24fd: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2501:
	/* 0x2501: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2505:
	/* 0x2505: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2508:
	/* 0x2508: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_250f:
	/* 0x250f: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2511:
	/* 0x2511: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2514:
	/* 0x2514: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2514, 0x2ca4, x86_l_2ca4);
x86_l_251a:
	/* 0x251a: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_251d:
	/* 0x251d: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x251d, 0x2c49, x86_l_2c49);
x86_l_2523:
	/* 0x2523: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2529:
	/* 0x2529: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_252e:
	/* 0x252e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2531:
	/* 0x2531: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2531, 0x2aa9, x86_l_2aa9);
x86_l_2537:
	/* 0x2537: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_253b:
	/* 0x253b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_253e:
	/* 0x253e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2541:
	/* 0x2541: je     25ae <sys_enter_submit+0x25ae> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2541, 0x25ae, x86_l_25ae);
x86_l_2543:
	/* 0x2543: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2547:
	/* 0x2547: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_254c:
	/* 0x254c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2550:
	/* 0x2550: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2553:
	/* 0x2553: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2556:
	/* 0x2556: jne    253e <sys_enter_submit+0x253e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2556, 0x253e, x86_l_253e);
x86_l_2558:
	/* 0x2558: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_255b:
	/* 0x255b: jmp    25b3 <sys_enter_submit+0x25b3> */
	X86_SIM_X86_JMP(0x255b, 0x25b3, x86_l_25b3);
x86_l_255d:
	/* 0x255d: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2560:
	/* 0x2560: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2560, 0x2c49, x86_l_2c49);
x86_l_2566:
	/* 0x2566: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2569:
	/* 0x2569: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2569, 0x2c49, x86_l_2c49);
x86_l_256f:
	/* 0x256f: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2573:
	/* 0x2573: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2576:
	/* 0x2576: jns    257d <sys_enter_submit+0x257d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2576, 0x257d, x86_l_257d);
x86_l_2578:
	/* 0x2578: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_257b:
	/* 0x257b: jmp    257f <sys_enter_submit+0x257f> */
	X86_SIM_X86_JMP(0x257b, 0x257f, x86_l_257f);
x86_l_257d:
	/* 0x257d: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_257f:
	/* 0x257f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2582:
	/* 0x2582: jns    258c <sys_enter_submit+0x258c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2582, 0x258c, x86_l_258c);
x86_l_2584:
	/* 0x2584: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2587:
	/* 0x2587: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_258a:
	/* 0x258a: jmp    258e <sys_enter_submit+0x258e> */
	X86_SIM_X86_JMP(0x258a, 0x258e, x86_l_258e);
x86_l_258c:
	/* 0x258c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258e:
	/* 0x258e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2591:
	/* 0x2591: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2594:
	/* 0x2594: jns    259b <sys_enter_submit+0x259b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2594, 0x259b, x86_l_259b);
x86_l_2596:
	/* 0x2596: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2599:
	/* 0x2599: jmp    259d <sys_enter_submit+0x259d> */
	X86_SIM_X86_JMP(0x2599, 0x259d, x86_l_259d);
x86_l_259b:
	/* 0x259b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_259d:
	/* 0x259d: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25a1:
	/* 0x25a1: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_25a4:
	/* 0x25a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25a7:
	/* 0x25a7: jns    25da <sys_enter_submit+0x25da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25a7, 0x25da, x86_l_25da);
x86_l_25a9:
	/* 0x25a9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25ac:
	/* 0x25ac: jmp    25dc <sys_enter_submit+0x25dc> */
	X86_SIM_X86_JMP(0x25ac, 0x25dc, x86_l_25dc);
x86_l_25ae:
	/* 0x25ae: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_25b3:
	/* 0x25b3: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_25b7:
	/* 0x25b7: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x25b7, 0x2c49, x86_l_2c49);
x86_l_25bd:
	/* 0x25bd: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25c0:
	/* 0x25c0: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_25c6:
	/* 0x25c6: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25cb:
	/* 0x25cb: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_25cf:
	/* 0x25cf: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_25d2:
	/* 0x25d2: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_25d5:
	/* 0x25d5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25d8:
	/* 0x25d8: js     25a9 <sys_enter_submit+0x25a9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25d8, 0x25a9, x86_l_25a9);
x86_l_25da:
	/* 0x25da: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25dc:
	/* 0x25dc: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25e0:
	/* 0x25e0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_25e3:
	/* 0x25e3: jns    25ea <sys_enter_submit+0x25ea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25e3, 0x25ea, x86_l_25ea);
x86_l_25e5:
	/* 0x25e5: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25e8:
	/* 0x25e8: jmp    25ec <sys_enter_submit+0x25ec> */
	X86_SIM_X86_JMP(0x25e8, 0x25ec, x86_l_25ec);
x86_l_25ea:
	/* 0x25ea: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25ec:
	/* 0x25ec: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25ef:
	/* 0x25ef: je     266a <sys_enter_submit+0x266a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ef, 0x266a, x86_l_266a);
x86_l_25f1:
	/* 0x25f1: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_25f4:
	/* 0x25f4: je     266a <sys_enter_submit+0x266a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f4, 0x266a, x86_l_266a);
x86_l_25f6:
	/* 0x25f6: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25fa:
	/* 0x25fa: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25fd:
	/* 0x25fd: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2602:
	/* 0x2602: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2605:
	/* 0x2605: jns    260e <sys_enter_submit+0x260e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2605, 0x260e, x86_l_260e);
x86_l_2607:
	/* 0x2607: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260a:
	/* 0x260a: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_260e:
	/* 0x260e: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2612:
	/* 0x2612: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2615:
	/* 0x2615: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_261c:
	/* 0x261c: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_261e:
	/* 0x261e: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2621:
	/* 0x2621: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2621, 0x2ca4, x86_l_2ca4);
x86_l_2627:
	/* 0x2627: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_262a:
	/* 0x262a: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x262a, 0x2c4c, x86_l_2c4c);
x86_l_2630:
	/* 0x2630: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2636:
	/* 0x2636: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_263b:
	/* 0x263b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263e:
	/* 0x263e: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x263e, 0x2aa6, x86_l_2aa6);
x86_l_2644:
	/* 0x2644: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2648:
	/* 0x2648: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_264b:
	/* 0x264b: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_264e:
	/* 0x264e: je     26bb <sys_enter_submit+0x26bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x264e, 0x26bb, x86_l_26bb);
x86_l_2650:
	/* 0x2650: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2654:
	/* 0x2654: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2659:
	/* 0x2659: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_265d:
	/* 0x265d: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2660:
	/* 0x2660: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2663:
	/* 0x2663: jne    264b <sys_enter_submit+0x264b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2663, 0x264b, x86_l_264b);
x86_l_2665:
	/* 0x2665: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2668:
	/* 0x2668: jmp    26c0 <sys_enter_submit+0x26c0> */
	X86_SIM_X86_JMP(0x2668, 0x26c0, x86_l_26c0);
x86_l_266a:
	/* 0x266a: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_266d:
	/* 0x266d: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x266d, 0x2c4c, x86_l_2c4c);
x86_l_2673:
	/* 0x2673: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2676:
	/* 0x2676: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2676, 0x2c4c, x86_l_2c4c);
x86_l_267c:
	/* 0x267c: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2680:
	/* 0x2680: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2683:
	/* 0x2683: jns    268a <sys_enter_submit+0x268a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2683, 0x268a, x86_l_268a);
x86_l_2685:
	/* 0x2685: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2688:
	/* 0x2688: jmp    268c <sys_enter_submit+0x268c> */
	X86_SIM_X86_JMP(0x2688, 0x268c, x86_l_268c);
x86_l_268a:
	/* 0x268a: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_268c:
	/* 0x268c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_268f:
	/* 0x268f: jns    2699 <sys_enter_submit+0x2699> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x268f, 0x2699, x86_l_2699);
x86_l_2691:
	/* 0x2691: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2694:
	/* 0x2694: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2697:
	/* 0x2697: jmp    269b <sys_enter_submit+0x269b> */
	X86_SIM_X86_JMP(0x2697, 0x269b, x86_l_269b);
x86_l_2699:
	/* 0x2699: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_269b:
	/* 0x269b: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_269e:
	/* 0x269e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a1:
	/* 0x26a1: jns    26a8 <sys_enter_submit+0x26a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26a1, 0x26a8, x86_l_26a8);
x86_l_26a3:
	/* 0x26a3: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a6:
	/* 0x26a6: jmp    26aa <sys_enter_submit+0x26aa> */
	X86_SIM_X86_JMP(0x26a6, 0x26aa, x86_l_26aa);
x86_l_26a8:
	/* 0x26a8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26aa:
	/* 0x26aa: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26ae:
	/* 0x26ae: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26b1:
	/* 0x26b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26b4:
	/* 0x26b4: jns    26e7 <sys_enter_submit+0x26e7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26b4, 0x26e7, x86_l_26e7);
x86_l_26b6:
	/* 0x26b6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b9:
	/* 0x26b9: jmp    26e9 <sys_enter_submit+0x26e9> */
	X86_SIM_X86_JMP(0x26b9, 0x26e9, x86_l_26e9);
x86_l_26bb:
	/* 0x26bb: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_26c0:
	/* 0x26c0: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_26c4:
	/* 0x26c4: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x26c4, 0x2c4c, x86_l_2c4c);
x86_l_26ca:
	/* 0x26ca: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26cd:
	/* 0x26cd: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_26d3:
	/* 0x26d3: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26d8:
	/* 0x26d8: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_26dc:
	/* 0x26dc: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26df:
	/* 0x26df: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_26e2:
	/* 0x26e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26e5:
	/* 0x26e5: js     26b6 <sys_enter_submit+0x26b6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x26e5, 0x26b6, x86_l_26b6);
x86_l_26e7:
	/* 0x26e7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26e9:
	/* 0x26e9: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26ed:
	/* 0x26ed: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26f0:
	/* 0x26f0: jns    26f7 <sys_enter_submit+0x26f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f0, 0x26f7, x86_l_26f7);
x86_l_26f2:
	/* 0x26f2: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26f5:
	/* 0x26f5: jmp    26f9 <sys_enter_submit+0x26f9> */
	X86_SIM_X86_JMP(0x26f5, 0x26f9, x86_l_26f9);
x86_l_26f7:
	/* 0x26f7: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26f9:
	/* 0x26f9: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26fc:
	/* 0x26fc: je     2777 <sys_enter_submit+0x2777> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26fc, 0x2777, x86_l_2777);
x86_l_26fe:
	/* 0x26fe: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2701:
	/* 0x2701: je     2777 <sys_enter_submit+0x2777> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2701, 0x2777, x86_l_2777);
x86_l_2703:
	/* 0x2703: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2707:
	/* 0x2707: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_270a:
	/* 0x270a: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_270f:
	/* 0x270f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2712:
	/* 0x2712: jns    271b <sys_enter_submit+0x271b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2712, 0x271b, x86_l_271b);
x86_l_2714:
	/* 0x2714: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2717:
	/* 0x2717: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_271b:
	/* 0x271b: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_271f:
	/* 0x271f: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2722:
	/* 0x2722: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2729:
	/* 0x2729: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_272b:
	/* 0x272b: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_272e:
	/* 0x272e: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x272e, 0x2ca4, x86_l_2ca4);
x86_l_2734:
	/* 0x2734: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2737:
	/* 0x2737: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2737, 0x2c49, x86_l_2c49);
x86_l_273d:
	/* 0x273d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2743:
	/* 0x2743: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2748:
	/* 0x2748: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_274b:
	/* 0x274b: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x274b, 0x2aa9, x86_l_2aa9);
x86_l_2751:
	/* 0x2751: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2755:
	/* 0x2755: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2758:
	/* 0x2758: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_275b:
	/* 0x275b: je     27c8 <sys_enter_submit+0x27c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x275b, 0x27c8, x86_l_27c8);
x86_l_275d:
	/* 0x275d: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2761:
	/* 0x2761: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2766:
	/* 0x2766: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_276a:
	/* 0x276a: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_276d:
	/* 0x276d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2770:
	/* 0x2770: jne    2758 <sys_enter_submit+0x2758> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2770, 0x2758, x86_l_2758);
x86_l_2772:
	/* 0x2772: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2775:
	/* 0x2775: jmp    27cd <sys_enter_submit+0x27cd> */
	X86_SIM_X86_JMP(0x2775, 0x27cd, x86_l_27cd);
x86_l_2777:
	/* 0x2777: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_277a:
	/* 0x277a: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x277a, 0x2c49, x86_l_2c49);
x86_l_2780:
	/* 0x2780: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2783:
	/* 0x2783: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2783, 0x2c49, x86_l_2c49);
x86_l_2789:
	/* 0x2789: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_278d:
	/* 0x278d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2790:
	/* 0x2790: jns    2797 <sys_enter_submit+0x2797> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2790, 0x2797, x86_l_2797);
x86_l_2792:
	/* 0x2792: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2795:
	/* 0x2795: jmp    2799 <sys_enter_submit+0x2799> */
	X86_SIM_X86_JMP(0x2795, 0x2799, x86_l_2799);
x86_l_2797:
	/* 0x2797: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2799:
	/* 0x2799: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_279c:
	/* 0x279c: jns    27a6 <sys_enter_submit+0x27a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x279c, 0x27a6, x86_l_27a6);
x86_l_279e:
	/* 0x279e: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27a1:
	/* 0x27a1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27a4:
	/* 0x27a4: jmp    27a8 <sys_enter_submit+0x27a8> */
	X86_SIM_X86_JMP(0x27a4, 0x27a8, x86_l_27a8);
x86_l_27a6:
	/* 0x27a6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27a8:
	/* 0x27a8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27ab:
	/* 0x27ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27ae:
	/* 0x27ae: jns    27b5 <sys_enter_submit+0x27b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27ae, 0x27b5, x86_l_27b5);
x86_l_27b0:
	/* 0x27b0: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27b3:
	/* 0x27b3: jmp    27b7 <sys_enter_submit+0x27b7> */
	X86_SIM_X86_JMP(0x27b3, 0x27b7, x86_l_27b7);
x86_l_27b5:
	/* 0x27b5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b7:
	/* 0x27b7: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27bb:
	/* 0x27bb: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_27be:
	/* 0x27be: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27c1:
	/* 0x27c1: jns    27f4 <sys_enter_submit+0x27f4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27c1, 0x27f4, x86_l_27f4);
x86_l_27c3:
	/* 0x27c3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c6:
	/* 0x27c6: jmp    27f6 <sys_enter_submit+0x27f6> */
	X86_SIM_X86_JMP(0x27c6, 0x27f6, x86_l_27f6);
x86_l_27c8:
	/* 0x27c8: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_27cd:
	/* 0x27cd: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_27d1:
	/* 0x27d1: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x27d1, 0x2c49, x86_l_2c49);
x86_l_27d7:
	/* 0x27d7: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27da:
	/* 0x27da: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_27e0:
	/* 0x27e0: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27e5:
	/* 0x27e5: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_27e9:
	/* 0x27e9: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27ec:
	/* 0x27ec: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_27ef:
	/* 0x27ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27f2:
	/* 0x27f2: js     27c3 <sys_enter_submit+0x27c3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x27f2, 0x27c3, x86_l_27c3);
x86_l_27f4:
	/* 0x27f4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27f6:
	/* 0x27f6: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27fa:
	/* 0x27fa: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27fd:
	/* 0x27fd: jns    2804 <sys_enter_submit+0x2804> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27fd, 0x2804, x86_l_2804);
x86_l_27ff:
	/* 0x27ff: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2802:
	/* 0x2802: jmp    2806 <sys_enter_submit+0x2806> */
	X86_SIM_X86_JMP(0x2802, 0x2806, x86_l_2806);
x86_l_2804:
	/* 0x2804: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2806:
	/* 0x2806: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2809:
	/* 0x2809: je     2884 <sys_enter_submit+0x2884> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2809, 0x2884, x86_l_2884);
x86_l_280b:
	/* 0x280b: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_280e:
	/* 0x280e: je     2884 <sys_enter_submit+0x2884> */
	X86_SIM_X86_JCC(X86_CC_E, 0x280e, 0x2884, x86_l_2884);
x86_l_2810:
	/* 0x2810: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2814:
	/* 0x2814: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2817:
	/* 0x2817: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_281c:
	/* 0x281c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_281f:
	/* 0x281f: jns    2828 <sys_enter_submit+0x2828> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x281f, 0x2828, x86_l_2828);
x86_l_2821:
	/* 0x2821: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2824:
	/* 0x2824: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2828:
	/* 0x2828: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_282c:
	/* 0x282c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_282f:
	/* 0x282f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2836:
	/* 0x2836: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2838:
	/* 0x2838: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_283b:
	/* 0x283b: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x283b, 0x2ca4, x86_l_2ca4);
x86_l_2841:
	/* 0x2841: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2844:
	/* 0x2844: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2844, 0x2c4c, x86_l_2c4c);
x86_l_284a:
	/* 0x284a: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2850:
	/* 0x2850: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2855:
	/* 0x2855: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2858:
	/* 0x2858: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2858, 0x2aa6, x86_l_2aa6);
x86_l_285e:
	/* 0x285e: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2862:
	/* 0x2862: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2865:
	/* 0x2865: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2868:
	/* 0x2868: je     28d5 <sys_enter_submit+0x28d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2868, 0x28d5, x86_l_28d5);
x86_l_286a:
	/* 0x286a: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_286e:
	/* 0x286e: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2873:
	/* 0x2873: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2877:
	/* 0x2877: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_287a:
	/* 0x287a: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_287d:
	/* 0x287d: jne    2865 <sys_enter_submit+0x2865> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x287d, 0x2865, x86_l_2865);
x86_l_287f:
	/* 0x287f: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2882:
	/* 0x2882: jmp    28da <sys_enter_submit+0x28da> */
	X86_SIM_X86_JMP(0x2882, 0x28da, x86_l_28da);
x86_l_2884:
	/* 0x2884: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2887:
	/* 0x2887: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2887, 0x2c4c, x86_l_2c4c);
x86_l_288d:
	/* 0x288d: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2890:
	/* 0x2890: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2890, 0x2c4c, x86_l_2c4c);
x86_l_2896:
	/* 0x2896: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_289a:
	/* 0x289a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_289d:
	/* 0x289d: jns    28a4 <sys_enter_submit+0x28a4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x289d, 0x28a4, x86_l_28a4);
x86_l_289f:
	/* 0x289f: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a2:
	/* 0x28a2: jmp    28a6 <sys_enter_submit+0x28a6> */
	X86_SIM_X86_JMP(0x28a2, 0x28a6, x86_l_28a6);
x86_l_28a4:
	/* 0x28a4: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28a6:
	/* 0x28a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28a9:
	/* 0x28a9: jns    28b3 <sys_enter_submit+0x28b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28a9, 0x28b3, x86_l_28b3);
x86_l_28ab:
	/* 0x28ab: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28ae:
	/* 0x28ae: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b1:
	/* 0x28b1: jmp    28b5 <sys_enter_submit+0x28b5> */
	X86_SIM_X86_JMP(0x28b1, 0x28b5, x86_l_28b5);
x86_l_28b3:
	/* 0x28b3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28b5:
	/* 0x28b5: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_28b8:
	/* 0x28b8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28bb:
	/* 0x28bb: jns    28c2 <sys_enter_submit+0x28c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28bb, 0x28c2, x86_l_28c2);
x86_l_28bd:
	/* 0x28bd: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28c0:
	/* 0x28c0: jmp    28c4 <sys_enter_submit+0x28c4> */
	X86_SIM_X86_JMP(0x28c0, 0x28c4, x86_l_28c4);
x86_l_28c2:
	/* 0x28c2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c4:
	/* 0x28c4: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28c8:
	/* 0x28c8: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_28cb:
	/* 0x28cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28ce:
	/* 0x28ce: jns    2901 <sys_enter_submit+0x2901> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28ce, 0x2901, x86_l_2901);
x86_l_28d0:
	/* 0x28d0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d3:
	/* 0x28d3: jmp    2903 <sys_enter_submit+0x2903> */
	X86_SIM_X86_JMP(0x28d3, 0x2903, x86_l_2903);
x86_l_28d5:
	/* 0x28d5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_28da:
	/* 0x28da: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_28de:
	/* 0x28de: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x28de, 0x2c4c, x86_l_2c4c);
x86_l_28e4:
	/* 0x28e4: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_28e7:
	/* 0x28e7: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_28ed:
	/* 0x28ed: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28f2:
	/* 0x28f2: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_28f6:
	/* 0x28f6: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_28f9:
	/* 0x28f9: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_28fc:
	/* 0x28fc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28ff:
	/* 0x28ff: js     28d0 <sys_enter_submit+0x28d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28ff, 0x28d0, x86_l_28d0);
x86_l_2901:
	/* 0x2901: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2903:
	/* 0x2903: lea    rsi,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2907:
	/* 0x2907: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_290a:
	/* 0x290a: jns    2911 <sys_enter_submit+0x2911> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x290a, 0x2911, x86_l_2911);
x86_l_290c:
	/* 0x290c: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_290f:
	/* 0x290f: jmp    2913 <sys_enter_submit+0x2913> */
	X86_SIM_X86_JMP(0x290f, 0x2913, x86_l_2913);
x86_l_2911:
	/* 0x2911: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2913:
	/* 0x2913: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2916:
	/* 0x2916: je     2991 <sys_enter_submit+0x2991> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2916, 0x2991, x86_l_2991);
x86_l_2918:
	/* 0x2918: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_291b:
	/* 0x291b: je     2991 <sys_enter_submit+0x2991> */
	X86_SIM_X86_JCC(X86_CC_E, 0x291b, 0x2991, x86_l_2991);
x86_l_291d:
	/* 0x291d: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2921:
	/* 0x2921: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2924:
	/* 0x2924: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2929:
	/* 0x2929: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_292c:
	/* 0x292c: jns    2935 <sys_enter_submit+0x2935> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x292c, 0x2935, x86_l_2935);
x86_l_292e:
	/* 0x292e: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2931:
	/* 0x2931: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2935:
	/* 0x2935: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2939:
	/* 0x2939: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_293c:
	/* 0x293c: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2943:
	/* 0x2943: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2945:
	/* 0x2945: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2948:
	/* 0x2948: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2948, 0x2ca4, x86_l_2ca4);
x86_l_294e:
	/* 0x294e: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2951:
	/* 0x2951: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2951, 0x2c49, x86_l_2c49);
x86_l_2957:
	/* 0x2957: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_295d:
	/* 0x295d: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2962:
	/* 0x2962: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2965:
	/* 0x2965: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2965, 0x2aa9, x86_l_2aa9);
x86_l_296b:
	/* 0x296b: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_296f:
	/* 0x296f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2972:
	/* 0x2972: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2975:
	/* 0x2975: je     29e2 <sys_enter_submit+0x29e2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2975, 0x29e2, x86_l_29e2);
x86_l_2977:
	/* 0x2977: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_297b:
	/* 0x297b: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2980:
	/* 0x2980: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2984:
	/* 0x2984: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2987:
	/* 0x2987: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_298a:
	/* 0x298a: jne    2972 <sys_enter_submit+0x2972> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x298a, 0x2972, x86_l_2972);
x86_l_298c:
	/* 0x298c: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_298f:
	/* 0x298f: jmp    29e7 <sys_enter_submit+0x29e7> */
	X86_SIM_X86_JMP(0x298f, 0x29e7, x86_l_29e7);
x86_l_2991:
	/* 0x2991: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2994:
	/* 0x2994: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2994, 0x2c49, x86_l_2c49);
x86_l_299a:
	/* 0x299a: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_299d:
	/* 0x299d: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x299d, 0x2c49, x86_l_2c49);
x86_l_29a3:
	/* 0x29a3: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29a7:
	/* 0x29a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29aa:
	/* 0x29aa: jns    29b1 <sys_enter_submit+0x29b1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29aa, 0x29b1, x86_l_29b1);
x86_l_29ac:
	/* 0x29ac: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29af:
	/* 0x29af: jmp    29b3 <sys_enter_submit+0x29b3> */
	X86_SIM_X86_JMP(0x29af, 0x29b3, x86_l_29b3);
x86_l_29b1:
	/* 0x29b1: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29b3:
	/* 0x29b3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29b6:
	/* 0x29b6: jns    29c0 <sys_enter_submit+0x29c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29b6, 0x29c0, x86_l_29c0);
x86_l_29b8:
	/* 0x29b8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29bb:
	/* 0x29bb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29be:
	/* 0x29be: jmp    29c2 <sys_enter_submit+0x29c2> */
	X86_SIM_X86_JMP(0x29be, 0x29c2, x86_l_29c2);
x86_l_29c0:
	/* 0x29c0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c2:
	/* 0x29c2: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29c5:
	/* 0x29c5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29c8:
	/* 0x29c8: jns    29cf <sys_enter_submit+0x29cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29c8, 0x29cf, x86_l_29cf);
x86_l_29ca:
	/* 0x29ca: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29cd:
	/* 0x29cd: jmp    29d1 <sys_enter_submit+0x29d1> */
	X86_SIM_X86_JMP(0x29cd, 0x29d1, x86_l_29d1);
x86_l_29cf:
	/* 0x29cf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29d1:
	/* 0x29d1: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29d5:
	/* 0x29d5: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_29d8:
	/* 0x29d8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29db:
	/* 0x29db: jns    2a0e <sys_enter_submit+0x2a0e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29db, 0x2a0e, x86_l_2a0e);
x86_l_29dd:
	/* 0x29dd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29e0:
	/* 0x29e0: jmp    2a10 <sys_enter_submit+0x2a10> */
	X86_SIM_X86_JMP(0x29e0, 0x2a10, x86_l_2a10);
x86_l_29e2:
	/* 0x29e2: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_29e7:
	/* 0x29e7: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_29eb:
	/* 0x29eb: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x29eb, 0x2c49, x86_l_2c49);
x86_l_29f1:
	/* 0x29f1: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29f4:
	/* 0x29f4: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_29fa:
	/* 0x29fa: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29ff:
	/* 0x29ff: mov    BYTE PTR [rax+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2a03:
	/* 0x2a03: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a06:
	/* 0x2a06: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2a09:
	/* 0x2a09: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a0c:
	/* 0x2a0c: js     29dd <sys_enter_submit+0x29dd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2a0c, 0x29dd, x86_l_29dd);
x86_l_2a0e:
	/* 0x2a0e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a10:
	/* 0x2a10: lea    rdi,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a14:
	/* 0x2a14: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a17:
	/* 0x2a17: jns    2a1e <sys_enter_submit+0x2a1e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a17, 0x2a1e, x86_l_2a1e);
x86_l_2a19:
	/* 0x2a19: mov    rbp,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a1c:
	/* 0x2a1c: jmp    2a20 <sys_enter_submit+0x2a20> */
	X86_SIM_X86_JMP(0x2a1c, 0x2a20, x86_l_2a20);
x86_l_2a1e:
	/* 0x2a1e: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a20:
	/* 0x2a20: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a23:
	/* 0x2a23: je     2ab7 <sys_enter_submit+0x2ab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a23, 0x2ab7, x86_l_2ab7);
x86_l_2a29:
	/* 0x2a29: cmp    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2a2c:
	/* 0x2a2c: je     2ab7 <sys_enter_submit+0x2ab7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a2c, 0x2ab7, x86_l_2ab7);
x86_l_2a32:
	/* 0x2a32: lea    rdi,[rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a36:
	/* 0x2a36: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a39:
	/* 0x2a39: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2a3e:
	/* 0x2a3e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a41:
	/* 0x2a41: jns    2a4a <sys_enter_submit+0x2a4a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a41, 0x2a4a, x86_l_2a4a);
x86_l_2a43:
	/* 0x2a43: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a46:
	/* 0x2a46: mov    rax,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a4a:
	/* 0x2a4a: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2a4e:
	/* 0x2a4e: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a51:
	/* 0x2a51: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a58:
	/* 0x2a58: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2a5a:
	/* 0x2a5a: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a5d:
	/* 0x2a5d: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a5d, 0x2ca4, x86_l_2ca4);
x86_l_2a63:
	/* 0x2a63: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2a66:
	/* 0x2a66: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a66, 0x2c4c, x86_l_2c4c);
x86_l_2a6c:
	/* 0x2a6c: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a72:
	/* 0x2a72: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2a77:
	/* 0x2a77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a7a:
	/* 0x2a7a: jns    2aa6 <sys_enter_submit+0x2aa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a7a, 0x2aa6, x86_l_2aa6);
x86_l_2a7c:
	/* 0x2a7c: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a80:
	/* 0x2a80: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a83:
	/* 0x2a83: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2a86:
	/* 0x2a86: je     2b08 <sys_enter_submit+0x2b08> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a86, 0x2b08, x86_l_2b08);
x86_l_2a8c:
	/* 0x2a8c: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a90:
	/* 0x2a90: movzx  r12d,BYTE PTR [rax+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2a95:
	/* 0x2a95: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2a99:
	/* 0x2a99: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2a9c:
	/* 0x2a9c: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2a9f:
	/* 0x2a9f: jne    2a83 <sys_enter_submit+0x2a83> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a9f, 0x2a83, x86_l_2a83);
x86_l_2aa1:
	/* 0x2aa1: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2aa4:
	/* 0x2aa4: jmp    2b0d <sys_enter_submit+0x2b0d> */
	X86_SIM_X86_JMP(0x2aa4, 0x2b0d, x86_l_2b0d);
x86_l_2aa6:
	/* 0x2aa6: mov    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2aa9:
	/* 0x2aa9: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2aae:
	/* 0x2aae: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab2:
	/* 0x2ab2: jmp    10a9 <sys_enter_submit+0x10a9> */
	X86_SIM_X86_JMP(0x2ab2, 0x10a9, x86_l_10a9);
x86_l_2ab7:
	/* 0x2ab7: cmp    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aba:
	/* 0x2aba: jne    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aba, 0x2c4c, x86_l_2c4c);
x86_l_2ac0:
	/* 0x2ac0: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ac3:
	/* 0x2ac3: je     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ac3, 0x2c4c, x86_l_2c4c);
x86_l_2ac9:
	/* 0x2ac9: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2acd:
	/* 0x2acd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ad0:
	/* 0x2ad0: jns    2ad7 <sys_enter_submit+0x2ad7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad0, 0x2ad7, x86_l_2ad7);
x86_l_2ad2:
	/* 0x2ad2: mov    rbp,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad5:
	/* 0x2ad5: jmp    2ad9 <sys_enter_submit+0x2ad9> */
	X86_SIM_X86_JMP(0x2ad5, 0x2ad9, x86_l_2ad9);
x86_l_2ad7:
	/* 0x2ad7: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ad9:
	/* 0x2ad9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2adc:
	/* 0x2adc: jns    2ae6 <sys_enter_submit+0x2ae6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2adc, 0x2ae6, x86_l_2ae6);
x86_l_2ade:
	/* 0x2ade: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ae1:
	/* 0x2ae1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae4:
	/* 0x2ae4: jmp    2ae8 <sys_enter_submit+0x2ae8> */
	X86_SIM_X86_JMP(0x2ae4, 0x2ae8, x86_l_2ae8);
x86_l_2ae6:
	/* 0x2ae6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ae8:
	/* 0x2ae8: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2aeb:
	/* 0x2aeb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aee:
	/* 0x2aee: jns    2af5 <sys_enter_submit+0x2af5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aee, 0x2af5, x86_l_2af5);
x86_l_2af0:
	/* 0x2af0: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2af3:
	/* 0x2af3: jmp    2af7 <sys_enter_submit+0x2af7> */
	X86_SIM_X86_JMP(0x2af3, 0x2af7, x86_l_2af7);
x86_l_2af5:
	/* 0x2af5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2af7:
	/* 0x2af7: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2afb:
	/* 0x2afb: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2afe:
	/* 0x2afe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b01:
	/* 0x2b01: jns    2b34 <sys_enter_submit+0x2b34> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b01, 0x2b34, x86_l_2b34);
x86_l_2b03:
	/* 0x2b03: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b06:
	/* 0x2b06: jmp    2b36 <sys_enter_submit+0x2b36> */
	X86_SIM_X86_JMP(0x2b06, 0x2b36, x86_l_2b36);
x86_l_2b08:
	/* 0x2b08: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2b0d:
	/* 0x2b0d: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2b11:
	/* 0x2b11: jl     2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2b11, 0x2c4c, x86_l_2c4c);
x86_l_2b17:
	/* 0x2b17: lea    esi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2b1a:
	/* 0x2b1a: and    esi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b20:
	/* 0x2b20: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b25:
	/* 0x2b25: mov    BYTE PTR [rax+rsi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 47ULL);
x86_l_2b29:
	/* 0x2b29: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b2c:
	/* 0x2b2c: mov    rax,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2b2f:
	/* 0x2b2f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b32:
	/* 0x2b32: js     2b03 <sys_enter_submit+0x2b03> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b32, 0x2b03, x86_l_2b03);
x86_l_2b34:
	/* 0x2b34: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b36:
	/* 0x2b36: lea    rax,[rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b3a:
	/* 0x2b3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b3d:
	/* 0x2b3d: jns    2b44 <sys_enter_submit+0x2b44> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b3d, 0x2b44, x86_l_2b44);
x86_l_2b3f:
	/* 0x2b3f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b42:
	/* 0x2b42: jmp    2b46 <sys_enter_submit+0x2b46> */
	X86_SIM_X86_JMP(0x2b42, 0x2b46, x86_l_2b46);
x86_l_2b44:
	/* 0x2b44: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b46:
	/* 0x2b46: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b49:
	/* 0x2b49: je     2bc4 <sys_enter_submit+0x2bc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b49, 0x2bc4, x86_l_2bc4);
x86_l_2b4b:
	/* 0x2b4b: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b4e:
	/* 0x2b4e: je     2bc4 <sys_enter_submit+0x2bc4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b4e, 0x2bc4, x86_l_2bc4);
x86_l_2b50:
	/* 0x2b50: lea    rdi,[rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b54:
	/* 0x2b54: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b57:
	/* 0x2b57: mov    esi,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2b5c:
	/* 0x2b5c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2b5f:
	/* 0x2b5f: jns    2b68 <sys_enter_submit+0x2b68> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b5f, 0x2b68, x86_l_2b68);
x86_l_2b61:
	/* 0x2b61: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b64:
	/* 0x2b64: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b68:
	/* 0x2b68: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b6c:
	/* 0x2b6c: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b6f:
	/* 0x2b6f: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2b76:
	/* 0x2b76: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2b78:
	/* 0x2b78: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b7b:
	/* 0x2b7b: jb     2ca4 <sys_enter_submit+0x2ca4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b7b, 0x2ca4, x86_l_2ca4);
x86_l_2b81:
	/* 0x2b81: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_2b84:
	/* 0x2b84: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b84, 0x2c49, x86_l_2c49);
x86_l_2b8a:
	/* 0x2b8a: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b90:
	/* 0x2b90: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_2b95:
	/* 0x2b95: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b98:
	/* 0x2b98: jns    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b98, 0x2aa9, x86_l_2aa9);
x86_l_2b9e:
	/* 0x2b9e: lea    r10d,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ba2:
	/* 0x2ba2: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ba5:
	/* 0x2ba5: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2ba8:
	/* 0x2ba8: je     2c14 <sys_enter_submit+0x2c14> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ba8, 0x2c14, x86_l_2c14);
x86_l_2baa:
	/* 0x2baa: lea    r15,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2bae:
	/* 0x2bae: movzx  r12d,BYTE PTR [rsi+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2bb3:
	/* 0x2bb3: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2bb7:
	/* 0x2bb7: mov    r11,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2bba:
	/* 0x2bba: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2bbd:
	/* 0x2bbd: jne    2ba5 <sys_enter_submit+0x2ba5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bbd, 0x2ba5, x86_l_2ba5);
x86_l_2bbf:
	/* 0x2bbf: mov    r9d,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_2bc2:
	/* 0x2bc2: jmp    2c19 <sys_enter_submit+0x2c19> */
	X86_SIM_X86_JMP(0x2bc2, 0x2c19, x86_l_2c19);
x86_l_2bc4:
	/* 0x2bc4: cmp    rbp,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2bc7:
	/* 0x2bc7: jne    2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bc7, 0x2c49, x86_l_2c49);
x86_l_2bcd:
	/* 0x2bcd: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2bd0:
	/* 0x2bd0: je     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bd0, 0x2c49, x86_l_2c49);
x86_l_2bd2:
	/* 0x2bd2: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bd6:
	/* 0x2bd6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bd9:
	/* 0x2bd9: jns    2be0 <sys_enter_submit+0x2be0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bd9, 0x2be0, x86_l_2be0);
x86_l_2bdb:
	/* 0x2bdb: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bde:
	/* 0x2bde: jmp    2be2 <sys_enter_submit+0x2be2> */
	X86_SIM_X86_JMP(0x2bde, 0x2be2, x86_l_2be2);
x86_l_2be0:
	/* 0x2be0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2be2:
	/* 0x2be2: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2be5:
	/* 0x2be5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2be8:
	/* 0x2be8: jns    2bf2 <sys_enter_submit+0x2bf2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2be8, 0x2bf2, x86_l_2bf2);
x86_l_2bea:
	/* 0x2bea: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2bed:
	/* 0x2bed: mov    rcx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bf0:
	/* 0x2bf0: jmp    2bf4 <sys_enter_submit+0x2bf4> */
	X86_SIM_X86_JMP(0x2bf0, 0x2bf4, x86_l_2bf4);
x86_l_2bf2:
	/* 0x2bf2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bf4:
	/* 0x2bf4: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bf7:
	/* 0x2bf7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2bfa:
	/* 0x2bfa: jns    2c01 <sys_enter_submit+0x2c01> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bfa, 0x2c01, x86_l_2c01);
x86_l_2bfc:
	/* 0x2bfc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bff:
	/* 0x2bff: jmp    2c03 <sys_enter_submit+0x2c03> */
	X86_SIM_X86_JMP(0x2bff, 0x2c03, x86_l_2c03);
x86_l_2c01:
	/* 0x2c01: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c03:
	/* 0x2c03: lea    r8,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c07:
	/* 0x2c07: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2c0a:
	/* 0x2c0a: jns    2c39 <sys_enter_submit+0x2c39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c0a, 0x2c39, x86_l_2c39);
x86_l_2c0c:
	/* 0x2c0c: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2c0f:
	/* 0x2c0f: mov    rdi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c12:
	/* 0x2c12: jmp    2c3b <sys_enter_submit+0x2c3b> */
	X86_SIM_X86_JMP(0x2c12, 0x2c3b, x86_l_2c3b);
x86_l_2c14:
	/* 0x2c14: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2c19:
	/* 0x2c19: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c1d:
	/* 0x2c1d: jl     2c49 <sys_enter_submit+0x2c49> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2c1d, 0x2c49, x86_l_2c49);
x86_l_2c1f:
	/* 0x2c1f: lea    edi,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2c22:
	/* 0x2c22: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2c28:
	/* 0x2c28: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c2d:
	/* 0x2c2d: mov    BYTE PTR [rsi+rdi*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2c31:
	/* 0x2c31: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2c34:
	/* 0x2c34: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2c37:
	/* 0x2c37: js     2c0c <sys_enter_submit+0x2c0c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c37, 0x2c0c, x86_l_2c0c);
x86_l_2c39:
	/* 0x2c39: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c3b:
	/* 0x2c3b: lea    rsi,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c3f:
	/* 0x2c3f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c42:
	/* 0x2c42: jns    2c5f <sys_enter_submit+0x2c5f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c42, 0x2c5f, x86_l_2c5f);
x86_l_2c44:
	/* 0x2c44: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c47:
	/* 0x2c47: jmp    2c61 <sys_enter_submit+0x2c61> */
	X86_SIM_X86_JMP(0x2c47, 0x2c61, x86_l_2c61);
x86_l_2c49:
	/* 0x2c49: mov    rsi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2c4c:
	/* 0x2c4c: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c51:
	/* 0x2c51: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c56:
	/* 0x2c56: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c5a:
	/* 0x2c5a: jmp    10bb <sys_enter_submit+0x10bb> */
	X86_SIM_X86_JMP(0x2c5a, 0x10bb, x86_l_10bb);
x86_l_2c5f:
	/* 0x2c5f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c61:
	/* 0x2c61: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2c64:
	/* 0x2c64: je     330f <sys_enter_submit+0x330f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c64, 0x330f, x86_l_330f);
x86_l_2c6a:
	/* 0x2c6a: cmp    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2c6d:
	/* 0x2c6d: je     330f <sys_enter_submit+0x330f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c6d, 0x330f, x86_l_330f);
x86_l_2c73:
	/* 0x2c73: lea    rdx,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c77:
	/* 0x2c77: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c7a:
	/* 0x2c7a: mov    ecx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2c7f:
	/* 0x2c7f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2c82:
	/* 0x2c82: jns    2c8b <sys_enter_submit+0x2c8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c82, 0x2c8b, x86_l_2c8b);
x86_l_2c84:
	/* 0x2c84: mov    r9,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c87:
	/* 0x2c87: mov    rcx,QWORD PTR [rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c8b:
	/* 0x2c8b: shr    r9,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2c8f:
	/* 0x2c8f: inc    r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2c92:
	/* 0x2c92: and    r9d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2c99:
	/* 0x2c99: mov    edi,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2c9b:
	/* 0x2c9b: sub    edi,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2c9e:
	/* 0x2c9e: jae    332f <sys_enter_submit+0x332f> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2c9e, 0x332f, x86_l_332f);
x86_l_2ca4:
	/* 0x2ca4: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ca9:
	/* 0x2ca9: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cae:
	/* 0x2cae: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2cb2:
	/* 0x2cb2: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2cb4:
	/* 0x2cb4: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2cb6:
	/* 0x2cb6: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2cbc:
	/* 0x2cbc: mov    BYTE PTR [rax+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2cc0:
	/* 0x2cc0: mov    BYTE PTR [rax+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2cc7:
	/* 0x2cc7: mov    rbp,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ccc:
	/* 0x2ccc: and    ebx,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2cd2:
	/* 0x2cd2: add    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2cd5:
	/* 0x2cd5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cd8:
	/* 0x2cd8: jns    2cf3 <sys_enter_submit+0x2cf3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cd8, 0x2cf3, x86_l_2cf3);
x86_l_2cda:
	/* 0x2cda: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2cdc:
	/* 0x2cdc: cmp    rcx,0x3f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 63ULL);
x86_l_2ce0:
	/* 0x2ce0: je     2d3d <sys_enter_submit+0x2d3d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ce0, 0x2d3d, x86_l_2d3d);
x86_l_2ce2:
	/* 0x2ce2: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2ce6:
	/* 0x2ce6: mov    BYTE PTR [rsp+rcx*1+0x40],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 64ULL);
x86_l_2cea:
	/* 0x2cea: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_2ced:
	/* 0x2ced: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2cef:
	/* 0x2cef: jne    2cdc <sys_enter_submit+0x2cdc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2cef, 0x2cdc, x86_l_2cdc);
x86_l_2cf1:
	/* 0x2cf1: jmp    2d42 <sys_enter_submit+0x2d42> */
	X86_SIM_X86_JMP(0x2cf1, 0x2d42, x86_l_2d42);
x86_l_2cf3:
	/* 0x2cf3: mov    QWORD PTR [rsp+0x78],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 515396075520ULL);
x86_l_2cfc:
	/* 0x2cfc: mov    QWORD PTR [rsp+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_2d05:
	/* 0x2d05: mov    QWORD PTR [rsp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_2d0e:
	/* 0x2d0e: mov    QWORD PTR [rsp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_2d17:
	/* 0x2d17: mov    QWORD PTR [rsp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_2d20:
	/* 0x2d20: mov    QWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_2d29:
	/* 0x2d29: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_2d32:
	/* 0x2d32: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_2d3b:
	/* 0x2d3b: jmp    2d42 <sys_enter_submit+0x2d42> */
	X86_SIM_X86_JMP(0x2d3b, 0x2d42, x86_l_2d42);
x86_l_2d3d:
	/* 0x2d3d: mov    BYTE PTR [rsp+0x7f],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 545460846592ULL);
x86_l_2d42:
	/* 0x2d42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)fd_arg_path_map));
x86_l_2d49:
	/* 0x2d49: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2d4e:
	/* 0x2d4e: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2d53:
	/* 0x2d53: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d55:
	/* 0x2d55: call   2d5a <sys_enter_submit+0x2d5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2d5a:
	/* 0x2d5a: mov    eax,DWORD PTR [r12+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2d5f:
	/* 0x2d5f: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2d62:
	/* 0x2d62: je     32e3 <sys_enter_submit+0x32e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d62, 0x32e3, x86_l_32e3);
x86_l_2d68:
	/* 0x2d68: cmp    BYTE PTR [r12+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_2d71:
	/* 0x2d71: jne    32e3 <sys_enter_submit+0x32e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d71, 0x32e3, x86_l_32e3);
x86_l_2d77:
	/* 0x2d77: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d7f:
	/* 0x2d7f: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2d86:
	/* 0x2d86: ja     2de0 <sys_enter_submit+0x2de0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d86, 0x2de0, x86_l_2de0);
x86_l_2d88:
	/* 0x2d88: mov    BYTE PTR [r14+rbx*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519552ULL);
x86_l_2d91:
	/* 0x2d91: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2d97:
	/* 0x2d97: ja     2de0 <sys_enter_submit+0x2de0> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d97, 0x2de0, x86_l_2de0);
x86_l_2d99:
	/* 0x2d99: add    r12,0x70 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 112ULL);
x86_l_2d9d:
	/* 0x2d9d: lea    rdi,[rbx+r15*1+0x8a] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R15, 0), 138ULL);
x86_l_2da5:
	/* 0x2da5: jns    2db4 <sys_enter_submit+0x2db4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2da5, 0x2db4, x86_l_2db4);
x86_l_2da7:
	/* 0x2da7: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2daa:
	/* 0x2daa: jns    2dda <sys_enter_submit+0x2dda> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2daa, 0x2dda, x86_l_2dda);
x86_l_2dac:
	/* 0x2dac: mov    eax,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db0:
	/* 0x2db0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db2:
	/* 0x2db2: jmp    2dc6 <sys_enter_submit+0x2dc6> */
	X86_SIM_X86_JMP(0x2db2, 0x2dc6, x86_l_2dc6);
x86_l_2db4:
	/* 0x2db4: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2db9:
	/* 0x2db9: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2dbc:
	/* 0x2dbc: call   2dc1 <sys_enter_submit+0x2dc1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2dc1:
	/* 0x2dc1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2dc4:
	/* 0x2dc4: js     2de0 <sys_enter_submit+0x2de0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2dc4, 0x2de0, x86_l_2de0);
x86_l_2dc6:
	/* 0x2dc6: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2dc9:
	/* 0x2dc9: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2dd1:
	/* 0x2dd1: inc    BYTE PTR [r14+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2dd8:
	/* 0x2dd8: jmp    2de0 <sys_enter_submit+0x2de0> */
	X86_SIM_X86_JMP(0x2dd8, 0x2de0, x86_l_2de0);
x86_l_2dda:
	/* 0x2dda: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de0:
	/* 0x2de0: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2de5:
	/* 0x2de5: mov    r8,QWORD PTR [r14+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2dec:
	/* 0x2dec: lea    rcx,[r8+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2df0:
	/* 0x2df0: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2df3:
	/* 0x2df3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2df6:
	/* 0x2df6: jns    2e08 <sys_enter_submit+0x2e08> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2df6, 0x2e08, x86_l_2e08);
x86_l_2df8:
	/* 0x2df8: mov    rdi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dfb:
	/* 0x2dfb: lea    rax,[rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2dff:
	/* 0x2dff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e02:
	/* 0x2e02: js     2e13 <sys_enter_submit+0x2e13> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e02, 0x2e13, x86_l_2e13);
x86_l_2e04:
	/* 0x2e04: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e06:
	/* 0x2e06: jmp    2e16 <sys_enter_submit+0x2e16> */
	X86_SIM_X86_JMP(0x2e06, 0x2e16, x86_l_2e16);
x86_l_2e08:
	/* 0x2e08: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e0a:
	/* 0x2e0a: lea    rax,[rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e0e:
	/* 0x2e0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e11:
	/* 0x2e11: jns    2e04 <sys_enter_submit+0x2e04> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e11, 0x2e04, x86_l_2e04);
x86_l_2e13:
	/* 0x2e13: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e16:
	/* 0x2e16: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2e1a:
	/* 0x2e1a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e1c:
	/* 0x2e1c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e1f:
	/* 0x2e1f: jns    2e26 <sys_enter_submit+0x2e26> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1f, 0x2e26, x86_l_2e26);
x86_l_2e21:
	/* 0x2e21: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e24:
	/* 0x2e24: jmp    2e29 <sys_enter_submit+0x2e29> */
	X86_SIM_X86_JMP(0x2e24, 0x2e29, x86_l_2e29);
x86_l_2e26:
	/* 0x2e26: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e29:
	/* 0x2e29: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2e2e:
	/* 0x2e2e: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e31:
	/* 0x2e31: jns    2e35 <sys_enter_submit+0x2e35> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e31, 0x2e35, x86_l_2e35);
x86_l_2e33:
	/* 0x2e33: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e35:
	/* 0x2e35: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2e39:
	/* 0x2e39: lea    rax,[r8+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e3d:
	/* 0x2e3d: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e40:
	/* 0x2e40: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e42:
	/* 0x2e42: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e45:
	/* 0x2e45: mov    QWORD PTR [rsp+0x10],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e4a:
	/* 0x2e4a: jns    2e51 <sys_enter_submit+0x2e51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e4a, 0x2e51, x86_l_2e51);
x86_l_2e4c:
	/* 0x2e4c: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e4f:
	/* 0x2e4f: jmp    2e53 <sys_enter_submit+0x2e53> */
	X86_SIM_X86_JMP(0x2e4f, 0x2e53, x86_l_2e53);
x86_l_2e51:
	/* 0x2e51: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e53:
	/* 0x2e53: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e56:
	/* 0x2e56: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2e59:
	/* 0x2e59: jns    2e5d <sys_enter_submit+0x2e5d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e59, 0x2e5d, x86_l_2e5d);
x86_l_2e5b:
	/* 0x2e5b: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e5d:
	/* 0x2e5d: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2e5f:
	/* 0x2e5f: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2e63:
	/* 0x2e63: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e66:
	/* 0x2e66: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2e6a:
	/* 0x2e6a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e6c:
	/* 0x2e6c: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e6f:
	/* 0x2e6f: jns    2e73 <sys_enter_submit+0x2e73> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e6f, 0x2e73, x86_l_2e73);
x86_l_2e71:
	/* 0x2e71: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e73:
	/* 0x2e73: mov    DWORD PTR [r14+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2e77:
	/* 0x2e77: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e7a:
	/* 0x2e7a: jns    2e81 <sys_enter_submit+0x2e81> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e7a, 0x2e81, x86_l_2e81);
x86_l_2e7c:
	/* 0x2e7c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e7f:
	/* 0x2e7f: jmp    2e83 <sys_enter_submit+0x2e83> */
	X86_SIM_X86_JMP(0x2e7f, 0x2e83, x86_l_2e83);
x86_l_2e81:
	/* 0x2e81: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e83:
	/* 0x2e83: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e87:
	/* 0x2e87: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e89:
	/* 0x2e89: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e8c:
	/* 0x2e8c: jns    2e93 <sys_enter_submit+0x2e93> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e8c, 0x2e93, x86_l_2e93);
x86_l_2e8e:
	/* 0x2e8e: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e91:
	/* 0x2e91: jmp    2e95 <sys_enter_submit+0x2e95> */
	X86_SIM_X86_JMP(0x2e91, 0x2e95, x86_l_2e95);
x86_l_2e93:
	/* 0x2e93: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e95:
	/* 0x2e95: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2e98:
	/* 0x2e98: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2e9b:
	/* 0x2e9b: jns    2e9f <sys_enter_submit+0x2e9f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e9b, 0x2e9f, x86_l_2e9f);
x86_l_2e9d:
	/* 0x2e9d: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e9f:
	/* 0x2e9f: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2ea1:
	/* 0x2ea1: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2ea5:
	/* 0x2ea5: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2ea8:
	/* 0x2ea8: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2eac:
	/* 0x2eac: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eae:
	/* 0x2eae: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2eb1:
	/* 0x2eb1: jns    2eb5 <sys_enter_submit+0x2eb5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2eb1, 0x2eb5, x86_l_2eb5);
x86_l_2eb3:
	/* 0x2eb3: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb5:
	/* 0x2eb5: mov    DWORD PTR [r14+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2eb9:
	/* 0x2eb9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ebb:
	/* 0x2ebb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ebe:
	/* 0x2ebe: jns    2ec5 <sys_enter_submit+0x2ec5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ebe, 0x2ec5, x86_l_2ec5);
x86_l_2ec0:
	/* 0x2ec0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ec3:
	/* 0x2ec3: jmp    2ec7 <sys_enter_submit+0x2ec7> */
	X86_SIM_X86_JMP(0x2ec3, 0x2ec7, x86_l_2ec7);
x86_l_2ec5:
	/* 0x2ec5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ec7:
	/* 0x2ec7: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2eca:
	/* 0x2eca: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ecd:
	/* 0x2ecd: jns    2ed1 <sys_enter_submit+0x2ed1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ecd, 0x2ed1, x86_l_2ed1);
x86_l_2ecf:
	/* 0x2ecf: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ed1:
	/* 0x2ed1: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2ed3:
	/* 0x2ed3: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2ed7:
	/* 0x2ed7: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2eda:
	/* 0x2eda: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2ede:
	/* 0x2ede: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ee0:
	/* 0x2ee0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ee3:
	/* 0x2ee3: jns    2eea <sys_enter_submit+0x2eea> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ee3, 0x2eea, x86_l_2eea);
x86_l_2ee5:
	/* 0x2ee5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee8:
	/* 0x2ee8: jmp    2eec <sys_enter_submit+0x2eec> */
	X86_SIM_X86_JMP(0x2ee8, 0x2eec, x86_l_2eec);
x86_l_2eea:
	/* 0x2eea: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2eec:
	/* 0x2eec: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2ef0:
	/* 0x2ef0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ef3:
	/* 0x2ef3: jns    2ef7 <sys_enter_submit+0x2ef7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ef3, 0x2ef7, x86_l_2ef7);
x86_l_2ef5:
	/* 0x2ef5: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef7:
	/* 0x2ef7: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2efc:
	/* 0x2efc: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2eff:
	/* 0x2eff: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f01:
	/* 0x2f01: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f04:
	/* 0x2f04: jns    2f0b <sys_enter_submit+0x2f0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f04, 0x2f0b, x86_l_2f0b);
x86_l_2f06:
	/* 0x2f06: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f09:
	/* 0x2f09: jmp    2f0d <sys_enter_submit+0x2f0d> */
	X86_SIM_X86_JMP(0x2f09, 0x2f0d, x86_l_2f0d);
x86_l_2f0b:
	/* 0x2f0b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f0d:
	/* 0x2f0d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f10:
	/* 0x2f10: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2f13:
	/* 0x2f13: jns    2f17 <sys_enter_submit+0x2f17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f13, 0x2f17, x86_l_2f17);
x86_l_2f15:
	/* 0x2f15: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f17:
	/* 0x2f17: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f19:
	/* 0x2f19: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f1d:
	/* 0x2f1d: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f20:
	/* 0x2f20: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f24:
	/* 0x2f24: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f26:
	/* 0x2f26: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f29:
	/* 0x2f29: jns    2f30 <sys_enter_submit+0x2f30> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f29, 0x2f30, x86_l_2f30);
x86_l_2f2b:
	/* 0x2f2b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f2e:
	/* 0x2f2e: jmp    2f32 <sys_enter_submit+0x2f32> */
	X86_SIM_X86_JMP(0x2f2e, 0x2f32, x86_l_2f32);
x86_l_2f30:
	/* 0x2f30: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f32:
	/* 0x2f32: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_2f36:
	/* 0x2f36: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f39:
	/* 0x2f39: jns    2f3d <sys_enter_submit+0x2f3d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f39, 0x2f3d, x86_l_2f3d);
x86_l_2f3b:
	/* 0x2f3b: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f3d:
	/* 0x2f3d: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f3f:
	/* 0x2f3f: jne    2f73 <sys_enter_submit+0x2f73> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f3f, 0x2f73, x86_l_2f73);
x86_l_2f41:
	/* 0x2f41: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f43:
	/* 0x2f43: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f46:
	/* 0x2f46: jns    2f4d <sys_enter_submit+0x2f4d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f46, 0x2f4d, x86_l_2f4d);
x86_l_2f48:
	/* 0x2f48: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f4b:
	/* 0x2f4b: jmp    2f4f <sys_enter_submit+0x2f4f> */
	X86_SIM_X86_JMP(0x2f4b, 0x2f4f, x86_l_2f4f);
x86_l_2f4d:
	/* 0x2f4d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f4f:
	/* 0x2f4f: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f52:
	/* 0x2f52: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2f55:
	/* 0x2f55: jns    2f59 <sys_enter_submit+0x2f59> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f55, 0x2f59, x86_l_2f59);
x86_l_2f57:
	/* 0x2f57: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f59:
	/* 0x2f59: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2f5b:
	/* 0x2f5b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_2f5f:
	/* 0x2f5f: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2f62:
	/* 0x2f62: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f66:
	/* 0x2f66: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f68:
	/* 0x2f68: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f6b:
	/* 0x2f6b: jns    2f6f <sys_enter_submit+0x2f6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f6b, 0x2f6f, x86_l_2f6f);
x86_l_2f6d:
	/* 0x2f6d: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f6f:
	/* 0x2f6f: mov    DWORD PTR [r14+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f73:
	/* 0x2f73: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2f77:
	/* 0x2f77: lea    rbx,[r8+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2f7e:
	/* 0x2f7e: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2f81:
	/* 0x2f81: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f84:
	/* 0x2f84: jns    2f8b <sys_enter_submit+0x2f8b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f84, 0x2f8b, x86_l_2f8b);
x86_l_2f86:
	/* 0x2f86: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f89:
	/* 0x2f89: jmp    2f8d <sys_enter_submit+0x2f8d> */
	X86_SIM_X86_JMP(0x2f89, 0x2f8d, x86_l_2f8d);
x86_l_2f8b:
	/* 0x2f8b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f8d:
	/* 0x2f8d: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f91:
	/* 0x2f91: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f93:
	/* 0x2f93: mov    r15,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2f96:
	/* 0x2f96: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f99:
	/* 0x2f99: jns    2fa0 <sys_enter_submit+0x2fa0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f99, 0x2fa0, x86_l_2fa0);
x86_l_2f9b:
	/* 0x2f9b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f9e:
	/* 0x2f9e: jmp    2fa2 <sys_enter_submit+0x2fa2> */
	X86_SIM_X86_JMP(0x2f9e, 0x2fa2, x86_l_2fa2);
x86_l_2fa0:
	/* 0x2fa0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fa2:
	/* 0x2fa2: mov    r13,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2fa5:
	/* 0x2fa5: mov    QWORD PTR [rsp+0x18],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2faa:
	/* 0x2faa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fad:
	/* 0x2fad: jns    2fb1 <sys_enter_submit+0x2fb1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fad, 0x2fb1, x86_l_2fb1);
x86_l_2faf:
	/* 0x2faf: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fb1:
	/* 0x2fb1: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fb6:
	/* 0x2fb6: lea    rbp,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fba:
	/* 0x2fba: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2fbe:
	/* 0x2fbe: call   2fc3 <sys_enter_submit+0x2fc3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_2fc3:
	/* 0x2fc3: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2fc7:
	/* 0x2fc7: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2fca:
	/* 0x2fca: lea    rax,[r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2fce:
	/* 0x2fce: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fd1:
	/* 0x2fd1: jns    2fd8 <sys_enter_submit+0x2fd8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd1, 0x2fd8, x86_l_2fd8);
x86_l_2fd3:
	/* 0x2fd3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd6:
	/* 0x2fd6: jmp    2fda <sys_enter_submit+0x2fda> */
	X86_SIM_X86_JMP(0x2fd6, 0x2fda, x86_l_2fda);
x86_l_2fd8:
	/* 0x2fd8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fda:
	/* 0x2fda: mov    r13,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2fdd:
	/* 0x2fdd: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fe2:
	/* 0x2fe2: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe6:
	/* 0x2fe6: add    rdx,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_2fea:
	/* 0x2fea: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fed:
	/* 0x2fed: jns    2ff4 <sys_enter_submit+0x2ff4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fed, 0x2ff4, x86_l_2ff4);
x86_l_2fef:
	/* 0x2fef: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ff2:
	/* 0x2ff2: jmp    2ff6 <sys_enter_submit+0x2ff6> */
	X86_SIM_X86_JMP(0x2ff2, 0x2ff6, x86_l_2ff6);
x86_l_2ff4:
	/* 0x2ff4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ff6:
	/* 0x2ff6: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ffb:
	/* 0x2ffb: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2fff:
	/* 0x2fff: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_3003:
	/* 0x3003: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3006:
	/* 0x3006: jns    300e <sys_enter_submit+0x300e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3006, 0x300e, x86_l_300e);
x86_l_3008:
	/* 0x3008: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_300c:
	/* 0x300c: jmp    3010 <sys_enter_submit+0x3010> */
	X86_SIM_X86_JMP(0x300c, 0x3010, x86_l_3010);
x86_l_300e:
	/* 0x300e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3010:
	/* 0x3010: mov    r12,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3014:
	/* 0x3014: mov    QWORD PTR [r14+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3018:
	/* 0x3018: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_301b:
	/* 0x301b: jns    3028 <sys_enter_submit+0x3028> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x301b, 0x3028, x86_l_3028);
x86_l_301d:
	/* 0x301d: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_301f:
	/* 0x301f: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3021:
	/* 0x3021: je     3028 <sys_enter_submit+0x3028> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3021, 0x3028, x86_l_3028);
x86_l_3023:
	/* 0x3023: or     BYTE PTR [r14+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_3028:
	/* 0x3028: lea    rdi,[r15+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_302c:
	/* 0x302c: mov    QWORD PTR [r14+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_3034:
	/* 0x3034: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_303c:
	/* 0x303c: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3041:
	/* 0x3041: call   3046 <sys_enter_submit+0x3046> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_3046:
	/* 0x3046: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3049:
	/* 0x3049: jns    3057 <sys_enter_submit+0x3057> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3049, 0x3057, x86_l_3057);
x86_l_304b:
	/* 0x304b: mov    rax,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_304e:
	/* 0x304e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3051:
	/* 0x3051: js     305e <sys_enter_submit+0x305e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3051, 0x305e, x86_l_305e);
x86_l_3053:
	/* 0x3053: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3055:
	/* 0x3055: jmp    3061 <sys_enter_submit+0x3061> */
	X86_SIM_X86_JMP(0x3055, 0x3061, x86_l_3061);
x86_l_3057:
	/* 0x3057: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3059:
	/* 0x3059: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_305c:
	/* 0x305c: jns    3053 <sys_enter_submit+0x3053> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x305c, 0x3053, x86_l_3053);
x86_l_305e:
	/* 0x305e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3061:
	/* 0x3061: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3064:
	/* 0x3064: jns    30a7 <sys_enter_submit+0x30a7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3064, 0x30a7, x86_l_30a7);
x86_l_3066:
	/* 0x3066: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3069:
	/* 0x3069: mov    QWORD PTR [rsp+0x40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_306e:
	/* 0x306e: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3072:
	/* 0x3072: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3077:
	/* 0x3077: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_307b:
	/* 0x307b: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3080:
	/* 0x3080: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3084:
	/* 0x3084: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3089:
	/* 0x3089: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_308d:
	/* 0x308d: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3092:
	/* 0x3092: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3096:
	/* 0x3096: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_309b:
	/* 0x309b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_309f:
	/* 0x309f: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30a3:
	/* 0x30a3: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_30a7:
	/* 0x30a7: add    r15,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_30ab:
	/* 0x30ab: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_30b0:
	/* 0x30b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30b3:
	/* 0x30b3: jns    318a <sys_enter_submit+0x318a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30b3, 0x318a, x86_l_318a);
x86_l_30b9:
	/* 0x30b9: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_30bc:
	/* 0x30bc: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30bf:
	/* 0x30bf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30c1:
	/* 0x30c1: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30c1, 0x3199, x86_l_3199);
x86_l_30c7:
	/* 0x30c7: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_30cb:
	/* 0x30cb: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_30cf:
	/* 0x30cf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30d1:
	/* 0x30d1: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30d1, 0x3199, x86_l_3199);
x86_l_30d7:
	/* 0x30d7: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_30db:
	/* 0x30db: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_30df:
	/* 0x30df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30e1:
	/* 0x30e1: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30e1, 0x3199, x86_l_3199);
x86_l_30e7:
	/* 0x30e7: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_30eb:
	/* 0x30eb: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_30ef:
	/* 0x30ef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_30f1:
	/* 0x30f1: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30f1, 0x3199, x86_l_3199);
x86_l_30f7:
	/* 0x30f7: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_30fb:
	/* 0x30fb: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_30ff:
	/* 0x30ff: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3101:
	/* 0x3101: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3101, 0x3199, x86_l_3199);
x86_l_3107:
	/* 0x3107: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_310b:
	/* 0x310b: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_310f:
	/* 0x310f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3111:
	/* 0x3111: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3111, 0x3199, x86_l_3199);
x86_l_3117:
	/* 0x3117: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_311b:
	/* 0x311b: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_311f:
	/* 0x311f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3121:
	/* 0x3121: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3121, 0x3199, x86_l_3199);
x86_l_3123:
	/* 0x3123: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3127:
	/* 0x3127: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_312b:
	/* 0x312b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_312d:
	/* 0x312d: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x312d, 0x3199, x86_l_3199);
x86_l_312f:
	/* 0x312f: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_3133:
	/* 0x3133: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_3137:
	/* 0x3137: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3139:
	/* 0x3139: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3139, 0x3199, x86_l_3199);
x86_l_313b:
	/* 0x313b: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_313f:
	/* 0x313f: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_3143:
	/* 0x3143: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3145:
	/* 0x3145: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3145, 0x3199, x86_l_3199);
x86_l_3147:
	/* 0x3147: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_314b:
	/* 0x314b: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_314f:
	/* 0x314f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3151:
	/* 0x3151: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3151, 0x3199, x86_l_3199);
x86_l_3153:
	/* 0x3153: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_3157:
	/* 0x3157: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_315b:
	/* 0x315b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_315d:
	/* 0x315d: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x315d, 0x3199, x86_l_3199);
x86_l_315f:
	/* 0x315f: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_3163:
	/* 0x3163: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3167:
	/* 0x3167: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3169:
	/* 0x3169: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3169, 0x3199, x86_l_3199);
x86_l_316b:
	/* 0x316b: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_316f:
	/* 0x316f: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_3173:
	/* 0x3173: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3175:
	/* 0x3175: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3175, 0x3199, x86_l_3199);
x86_l_3177:
	/* 0x3177: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_317b:
	/* 0x317b: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_317f:
	/* 0x317f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_3181:
	/* 0x3181: je     3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3181, 0x3199, x86_l_3199);
x86_l_3183:
	/* 0x3183: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_3188:
	/* 0x3188: jmp    3199 <sys_enter_submit+0x3199> */
	X86_SIM_X86_JMP(0x3188, 0x3199, x86_l_3199);
x86_l_318a:
	/* 0x318a: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3192:
	/* 0x3192: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3199:
	/* 0x3199: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_319c:
	/* 0x319c: jns    3214 <sys_enter_submit+0x3214> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x319c, 0x3214, x86_l_3214);
x86_l_319e:
	/* 0x319e: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31a2:
	/* 0x31a2: mov    QWORD PTR [r12],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31a6:
	/* 0x31a6: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31aa:
	/* 0x31aa: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31af:
	/* 0x31af: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31b3:
	/* 0x31b3: mov    QWORD PTR [r12+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31b8:
	/* 0x31b8: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31bc:
	/* 0x31bc: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31c1:
	/* 0x31c1: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_31c5:
	/* 0x31c5: mov    QWORD PTR [r12+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_31ca:
	/* 0x31ca: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31ce:
	/* 0x31ce: mov    QWORD PTR [r12+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31d3:
	/* 0x31d3: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31d7:
	/* 0x31d7: mov    QWORD PTR [r12+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31dc:
	/* 0x31dc: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31e0:
	/* 0x31e0: mov    QWORD PTR [r12+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_31e5:
	/* 0x31e5: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31e9:
	/* 0x31e9: mov    QWORD PTR [r12+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31ee:
	/* 0x31ee: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_31f2:
	/* 0x31f2: mov    QWORD PTR [r12+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_31f7:
	/* 0x31f7: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_31fb:
	/* 0x31fb: mov    QWORD PTR [r12+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3200:
	/* 0x3200: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3204:
	/* 0x3204: mov    QWORD PTR [r12+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3209:
	/* 0x3209: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_320d:
	/* 0x320d: mov    QWORD PTR [r12+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3212:
	/* 0x3212: jmp    3288 <sys_enter_submit+0x3288> */
	X86_SIM_X86_JMP(0x3212, 0x3288, x86_l_3288);
x86_l_3214:
	/* 0x3214: mov    QWORD PTR [r12+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_321d:
	/* 0x321d: mov    QWORD PTR [r12+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_3226:
	/* 0x3226: mov    QWORD PTR [r12+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_322f:
	/* 0x322f: mov    QWORD PTR [r12+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_3238:
	/* 0x3238: mov    QWORD PTR [r12+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3241:
	/* 0x3241: mov    QWORD PTR [r12+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_324a:
	/* 0x324a: mov    QWORD PTR [r12+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3253:
	/* 0x3253: mov    QWORD PTR [r12+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_325c:
	/* 0x325c: mov    QWORD PTR [r12+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_3265:
	/* 0x3265: mov    QWORD PTR [r12+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_326e:
	/* 0x326e: mov    QWORD PTR [r12+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3277:
	/* 0x3277: mov    QWORD PTR [r12+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_3280:
	/* 0x3280: mov    QWORD PTR [r12],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3288:
	/* 0x3288: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_328d:
	/* 0x328d: test   BYTE PTR [rax+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_3291:
	/* 0x3291: je     32af <sys_enter_submit+0x32af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3291, 0x32af, x86_l_32af);
x86_l_3293:
	/* 0x3293: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_329a:
	/* 0x329a: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_329f:
	/* 0x329f: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_32a2:
	/* 0x32a2: call   32a7 <sys_enter_submit+0x32a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_32a7:
	/* 0x32a7: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_32a9:
	/* 0x32a9: js     32af <sys_enter_submit+0x32af> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32a9, 0x32af, x86_l_32af);
x86_l_32ab:
	/* 0x32ab: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_32af:
	/* 0x32af: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_32b7:
	/* 0x32b7: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_32bc:
	/* 0x32bc: jb     32c3 <sys_enter_submit+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x32bc, 0x32c3, x86_l_32c3);
x86_l_32be:
	/* 0x32be: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_32c3:
	/* 0x32c3: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_32c8:
	/* 0x32c8: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_32cc:
	/* 0x32cc: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_32d3:
	/* 0x32d3: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_32d8:
	/* 0x32d8: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_32db:
	/* 0x32db: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_32de:
	/* 0x32de: call   32e3 <sys_enter_submit+0x32e3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_32e3:
	/* 0x32e3: mov    edx,DWORD PTR [r12+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_32e8:
	/* 0x32e8: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_enter_tails));
x86_l_32ef:
	/* 0x32ef: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_32f2:
	/* 0x32f2: call   32f7 <sys_enter_submit+0x32f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_32f7:
	/* 0x32f7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32f9:
	/* 0x32f9: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_3300:
	/* 0x3300: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3301:
	/* 0x3301: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3303:
	/* 0x3303: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3305:
	/* 0x3305: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3307:
	/* 0x3307: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3309:
	/* 0x3309: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_330a:
	/* 0x330a: jmp    33c4 <sys_enter_submit+0x33c4> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_330f:
	/* 0x330f: cmp    rax,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3312:
	/* 0x3312: jne    33bc <sys_enter_submit+0x33bc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3312, 0x33bc, x86_l_33bc);
x86_l_3318:
	/* 0x3318: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_331b:
	/* 0x331b: je     33bc <sys_enter_submit+0x33bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x331b, 0x33bc, x86_l_33bc);
x86_l_3321:
	/* 0x3321: lea    rax,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3325:
	/* 0x3325: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3328:
	/* 0x3328: jns    336e <sys_enter_submit+0x336e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3328, 0x336e, x86_l_336e);
x86_l_332a:
	/* 0x332a: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_332d:
	/* 0x332d: jmp    3370 <sys_enter_submit+0x3370> */
	X86_SIM_X86_JMP(0x332d, 0x3370, x86_l_3370);
x86_l_332f:
	/* 0x332f: test   r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_3332:
	/* 0x3332: je     33bc <sys_enter_submit+0x33bc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3332, 0x33bc, x86_l_33bc);
x86_l_3338:
	/* 0x3338: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_333e:
	/* 0x333e: add    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_3343:
	/* 0x3343: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3346:
	/* 0x3346: jns    3390 <sys_enter_submit+0x3390> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3346, 0x3390, x86_l_3390);
x86_l_3348:
	/* 0x3348: lea    edx,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_334c:
	/* 0x334c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_334f:
	/* 0x334f: cmp    rdx,r8 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_3352:
	/* 0x3352: je     3398 <sys_enter_submit+0x3398> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3352, 0x3398, x86_l_3398);
x86_l_3354:
	/* 0x3354: lea    r10,[r8+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3358:
	/* 0x3358: movzx  r11d,BYTE PTR [rcx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_8), 0ULL);
x86_l_335d:
	/* 0x335d: mov    BYTE PTR [rdi+r8*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_3361:
	/* 0x3361: mov    r8,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_3364:
	/* 0x3364: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3367:
	/* 0x3367: jne    334f <sys_enter_submit+0x334f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3367, 0x334f, x86_l_334f);
x86_l_3369:
	/* 0x3369: mov    r9d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_336c:
	/* 0x336c: jmp    339c <sys_enter_submit+0x339c> */
	X86_SIM_X86_JMP(0x336c, 0x339c, x86_l_339c);
x86_l_336e:
	/* 0x336e: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3370:
	/* 0x3370: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3373:
	/* 0x3373: jns    337d <sys_enter_submit+0x337d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3373, 0x337d, x86_l_337d);
x86_l_3375:
	/* 0x3375: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3378:
	/* 0x3378: mov    rax,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_337b:
	/* 0x337b: jmp    337f <sys_enter_submit+0x337f> */
	X86_SIM_X86_JMP(0x337b, 0x337f, x86_l_337f);
x86_l_337d:
	/* 0x337d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_337f:
	/* 0x337f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3382:
	/* 0x3382: jns    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3382, 0x2c4c, x86_l_2c4c);
x86_l_3388:
	/* 0x3388: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_338b:
	/* 0x338b: jmp    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JMP(0x338b, 0x2c4c, x86_l_2c4c);
x86_l_3390:
	/* 0x3390: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3393:
	/* 0x3393: jmp    2aa9 <sys_enter_submit+0x2aa9> */
	X86_SIM_X86_JMP(0x3393, 0x2aa9, x86_l_2aa9);
x86_l_3398:
	/* 0x3398: mov    BYTE PTR [rdi+rdx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_339c:
	/* 0x339c: cmp    r9d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_33a0:
	/* 0x33a0: jl     33bc <sys_enter_submit+0x33bc> */
	X86_SIM_X86_JCC(X86_CC_L, 0x33a0, 0x33bc, x86_l_33bc);
x86_l_33a2:
	/* 0x33a2: lea    ecx,[rbx-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_33a5:
	/* 0x33a5: and    ecx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_33ab:
	/* 0x33ab: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33b0:
	/* 0x33b0: mov    BYTE PTR [rax+rcx*1],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_33b4:
	/* 0x33b4: sub    ebx,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R9, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_33b7:
	/* 0x33b7: jmp    2c51 <sys_enter_submit+0x2c51> */
	X86_SIM_X86_JMP(0x33b7, 0x2c51, x86_l_2c51);
x86_l_33bc:
	/* 0x33bc: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33bf:
	/* 0x33bf: jmp    2c4c <sys_enter_submit+0x2c4c> */
	X86_SIM_X86_JMP(0x33bf, 0x2c4c, x86_l_2c4c);
x86_l_33c4:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
