#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 232U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(19) M(21) M(22)
#include "../x86_sim_local_bpf.h"

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 stack_addresses[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 14: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 14, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 12: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 12, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 13: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 13, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 8: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 8, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 9: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 9, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 10: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 10, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 11: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 11, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_IMM, X86_OP_ALU_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET, X86_OP_CALL_MEMSET)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_IMM, X86_OP_TEST_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/utimes_common")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 184ULL);
x86_l_11:
	/* 0x11: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x98],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 652835028992ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)event_data_map));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2e:
	/* 0x2e: call   33 <trace_utimes_common+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x1356, x86_l_1356);
x86_l_3c:
	/* 0x3c: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)config_map));
x86_l_46:
	/* 0x46: lea    rsi,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_4e:
	/* 0x4e: call   53 <trace_utimes_common+0x53> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_56:
	/* 0x56: je     1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x1356, x86_l_1356);
x86_l_5c:
	/* 0x5c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5f:
	/* 0x5f: mov    r13,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    WORD PTR [rbp+0x7d8a],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_6b:
	/* 0x6b: mov    BYTE PTR [rbp+0x88],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_72:
	/* 0x72: mov    QWORD PTR [rbp+0x7d8c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7d:
	/* 0x7d: mov    QWORD PTR [rbp+0x7d94],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_88:
	/* 0x88: mov    QWORD PTR [rbp+0x7d9c],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_93:
	/* 0x93: mov    QWORD PTR [rbp+0x7da4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9e:
	/* 0x9e: mov    QWORD PTR [rbp+0x7dac],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a9:
	/* 0xa9: mov    QWORD PTR [rbp+0x7db4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b4:
	/* 0xb4: mov    QWORD PTR [rbp+0x7dbc],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_bf:
	/* 0xbf: mov    QWORD PTR [rbp+0x7dc4],0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_ca:
	/* 0xca: call   cf <trace_utimes_common+0xcf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_cf:
	/* 0xcf: mov    QWORD PTR [rbp+0x7dd0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d6:
	/* 0xd6: mov    QWORD PTR [rbp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_de:
	/* 0xde: mov    QWORD PTR [rbp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e6:
	/* 0xe6: mov    QWORD PTR [rbp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ee:
	/* 0xee: mov    QWORD PTR [rbp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f6:
	/* 0xf6: mov    QWORD PTR [rbp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_fe:
	/* 0xfe: mov    QWORD PTR [rbp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_106:
	/* 0x106: mov    QWORD PTR [rbp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10e:
	/* 0x10e: mov    QWORD PTR [rbp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_116:
	/* 0x116: mov    QWORD PTR [rbp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11e:
	/* 0x11e: mov    QWORD PTR [rbp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_126:
	/* 0x126: mov    QWORD PTR [rbp+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12e:
	/* 0x12e: mov    QWORD PTR [rbp+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_136:
	/* 0x136: mov    QWORD PTR [rbp+0x68],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13e:
	/* 0x13e: call   143 <trace_utimes_common+0x143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_143:
	/* 0x143: mov    DWORD PTR [rbp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146:
	/* 0x146: shr    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14a:
	/* 0x14a: mov    DWORD PTR [rbp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_14d:
	/* 0x14d: mov    DWORD PTR [rbp+0x70],0x306 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337926ULL);
x86_l_154:
	/* 0x154: call   159 <trace_utimes_common+0x159> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_159:
	/* 0x159: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15d:
	/* 0x15d: call   162 <trace_utimes_common+0x162> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_smp_processor_id);
x86_l_162:
	/* 0x162: mov    WORD PTR [rbp+0x7c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_166:
	/* 0x166: call   16b <trace_utimes_common+0x16b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_16b:
	/* 0x16b: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16e:
	/* 0x16e: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_172:
	/* 0x172: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_175:
	/* 0x175: jns    186 <trace_utimes_common+0x186> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x175, 0x186, x86_l_186);
x86_l_177:
	/* 0x177: mov    ecx,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179:
	/* 0x179: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_17e:
	/* 0x17e: test   ecx,0x200000 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2097152ULL);
x86_l_184:
	/* 0x184: jne    1c3 <trace_utimes_common+0x1c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x184, 0x1c3, x86_l_1c3);
x86_l_186:
	/* 0x186: call   18b <trace_utimes_common+0x18b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task_btf);
x86_l_18b:
	/* 0x18b: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18e:
	/* 0x18e: call   193 <trace_utimes_common+0x193> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_task_pt_regs);
x86_l_193:
	/* 0x193: add    rax,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_197:
	/* 0x197: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a:
	/* 0x19a: jns    1aa <trace_utimes_common+0x1aa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x19a, 0x1aa, x86_l_1aa);
x86_l_19c:
	/* 0x19c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19f:
	/* 0x19f: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a3:
	/* 0x1a3: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1a6:
	/* 0x1a6: js     1b5 <trace_utimes_common+0x1b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a6, 0x1b5, x86_l_1b5);
x86_l_1a8:
	/* 0x1a8: jmp    1bf <trace_utimes_common+0x1bf> */
	X86_SIM_X86_JMP(0x1a8, 0x1bf, x86_l_1bf);
x86_l_1aa:
	/* 0x1aa: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac:
	/* 0x1ac: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1b0:
	/* 0x1b0: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1b3:
	/* 0x1b3: jns    1bf <trace_utimes_common+0x1bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3, 0x1bf, x86_l_1bf);
x86_l_1b5:
	/* 0x1b5: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7:
	/* 0x1b7: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1b9:
	/* 0x1b9: jne    54c <trace_utimes_common+0x54c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b9, 0x54c, x86_l_54c);
x86_l_1bf:
	/* 0x1bf: mov    eax,DWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1c3:
	/* 0x1c3: mov    DWORD PTR [r13+0x74],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_1c7:
	/* 0x1c7: mov    eax,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1cb:
	/* 0x1cb: mov    DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1cf:
	/* 0x1cf: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_1d6:
	/* 0x1d6: lea    rsi,[rsp+0x44] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1db:
	/* 0x1db: call   1e0 <trace_utimes_common+0x1e0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1e0:
	/* 0x1e0: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e4:
	/* 0x1e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e7:
	/* 0x1e7: je     1242 <trace_utimes_common+0x1242> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e7, 0x1242, x86_l_1242);
x86_l_1ed:
	/* 0x1ed: mov    eax,DWORD PTR [r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f1:
	/* 0x1f1: mov    DWORD PTR [rsp+0xa4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_1f8:
	/* 0x1f8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_1ff:
	/* 0x1ff: lea    rsi,[rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_207:
	/* 0x207: call   20c <trace_utimes_common+0x20c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20c:
	/* 0x20c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20f:
	/* 0x20f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_212:
	/* 0x212: mov    QWORD PTR [rsp+0x30],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_217:
	/* 0x217: mov    QWORD PTR [rsp+0x10],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21c:
	/* 0x21c: mov    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_21f:
	/* 0x21f: mov    QWORD PTR [rsp+0x28],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_224:
	/* 0x224: je     12c1 <trace_utimes_common+0x12c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x224, 0x12c1, x86_l_12c1);
x86_l_22a:
	/* 0x22a: test   BYTE PTR [r12+0x4],0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_230:
	/* 0x230: jne    239 <trace_utimes_common+0x239> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x230, 0x239, x86_l_239);
x86_l_232:
	/* 0x232: call   237 <trace_utimes_common+0x237> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_cgroup_id);
x86_l_237:
	/* 0x237: jmp    291 <trace_utimes_common+0x291> */
	X86_SIM_X86_JMP(0x237, 0x291, x86_l_291);
x86_l_239:
	/* 0x239: mov    eax,0x98 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 152ULL);
x86_l_23e:
	/* 0x23e: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_245:
	/* 0x245: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_248:
	/* 0x248: jns    262 <trace_utimes_common+0x262> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x248, 0x262, x86_l_262);
x86_l_24a:
	/* 0x24a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d:
	/* 0x24d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_250:
	/* 0x250: js     269 <trace_utimes_common+0x269> */
	X86_SIM_X86_JCC(X86_CC_S, 0x250, 0x269, x86_l_269);
x86_l_252:
	/* 0x252: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_254:
	/* 0x254: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_257:
	/* 0x257: js     271 <trace_utimes_common+0x271> */
	X86_SIM_X86_JCC(X86_CC_S, 0x257, 0x271, x86_l_271);
x86_l_259:
	/* 0x259: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b:
	/* 0x25b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e:
	/* 0x25e: js     279 <trace_utimes_common+0x279> */
	X86_SIM_X86_JCC(X86_CC_S, 0x25e, 0x279, x86_l_279);
x86_l_260:
	/* 0x260: jmp    28f <trace_utimes_common+0x28f> */
	X86_SIM_X86_JMP(0x260, 0x28f, x86_l_28f);
x86_l_262:
	/* 0x262: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_264:
	/* 0x264: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_267:
	/* 0x267: jns    252 <trace_utimes_common+0x252> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x267, 0x252, x86_l_252);
x86_l_269:
	/* 0x269: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c:
	/* 0x26c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26f:
	/* 0x26f: jns    259 <trace_utimes_common+0x259> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26f, 0x259, x86_l_259);
x86_l_271:
	/* 0x271: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274:
	/* 0x274: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_277:
	/* 0x277: jns    28f <trace_utimes_common+0x28f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x277, 0x28f, x86_l_28f);
x86_l_279:
	/* 0x279: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c:
	/* 0x27c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27f:
	/* 0x27f: je     28f <trace_utimes_common+0x28f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f, 0x28f, x86_l_28f);
x86_l_281:
	/* 0x281: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_285:
	/* 0x285: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_288:
	/* 0x288: jns    28f <trace_utimes_common+0x28f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x288, 0x28f, x86_l_28f);
x86_l_28a:
	/* 0x28a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d:
	/* 0x28d: jmp    291 <trace_utimes_common+0x291> */
	X86_SIM_X86_JMP(0x28d, 0x291, x86_l_291);
x86_l_28f:
	/* 0x28f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_291:
	/* 0x291: mov    QWORD PTR [r13+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_295:
	/* 0x295: mov    QWORD PTR [rbx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_299:
	/* 0x299: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_29d:
	/* 0x29d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)containers_map));
x86_l_2a4:
	/* 0x2a4: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a9:
	/* 0x2a9: call   2ae <trace_utimes_common+0x2ae> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ae:
	/* 0x2ae: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b1:
	/* 0x2b1: je     2c9 <trace_utimes_common+0x2c9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b1, 0x2c9, x86_l_2c9);
x86_l_2b3:
	/* 0x2b3: movzx  eax,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2b6:
	/* 0x2b6: mov    BYTE PTR [rbx+0xb1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_2bc:
	/* 0x2bc: or     eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_2bf:
	/* 0x2bf: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2c2:
	/* 0x2c2: jne    2c9 <trace_utimes_common+0x2c9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c2, 0x2c9, x86_l_2c9);
x86_l_2c4:
	/* 0x2c4: or     BYTE PTR [r13+0x5c],0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_2c9:
	/* 0x2c9: movzx  eax,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_2ce:
	/* 0x2ce: cmp    ax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R12, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2d4:
	/* 0x2d4: jne    135d <trace_utimes_common+0x135d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d4, 0x135d, x86_l_135d);
x86_l_2da:
	/* 0x2da: mov    QWORD PTR [r13+0x7dd8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_2e5:
	/* 0x2e5: mov    DWORD PTR [rsp+0x50],0x306 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597384454ULL);
x86_l_2ed:
	/* 0x2ed: mov    WORD PTR [rsp+0x48],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2f2:
	/* 0x2f2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events_map_version));
x86_l_2f9:
	/* 0x2f9: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2fe:
	/* 0x2fe: call   303 <trace_utimes_common+0x303> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_303:
	/* 0x303: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_306:
	/* 0x306: je     371 <trace_utimes_common+0x371> */
	X86_SIM_X86_JCC(X86_CC_E, 0x306, 0x371, x86_l_371);
x86_l_308:
	/* 0x308: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_30d:
	/* 0x30d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_310:
	/* 0x310: call   315 <trace_utimes_common+0x315> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_315:
	/* 0x315: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_318:
	/* 0x318: je     371 <trace_utimes_common+0x371> */
	X86_SIM_X86_JCC(X86_CC_E, 0x318, 0x371, x86_l_371);
x86_l_31a:
	/* 0x31a: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31e:
	/* 0x31e: mov    QWORD PTR [r13+0x7de0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_325:
	/* 0x325: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_328:
	/* 0x328: mov    QWORD PTR [r13+0x7dd8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_32f:
	/* 0x32f: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_333:
	/* 0x333: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_337:
	/* 0x337: mov    QWORD PTR [r13+0x7de8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_33e:
	/* 0x33e: mov    QWORD PTR [r13+0x7df0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_345:
	/* 0x345: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_349:
	/* 0x349: mov    QWORD PTR [r13+0x7df8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_350:
	/* 0x350: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_354:
	/* 0x354: mov    QWORD PTR [r13+0x7e00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_35b:
	/* 0x35b: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_35f:
	/* 0x35f: mov    QWORD PTR [r13+0x7e08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_366:
	/* 0x366: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_36a:
	/* 0x36a: mov    QWORD PTR [r13+0x7e10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_371:
	/* 0x371: mov    rax,QWORD PTR [r13+0x7dd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_378:
	/* 0x378: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_37f:
	/* 0x37f: mov    ecx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_383:
	/* 0x383: cmp    ecx,DWORD PTR [r13+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_387:
	/* 0x387: mov    QWORD PTR [rsp+0xb0],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_38f:
	/* 0x38f: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_394:
	/* 0x394: jne    3b3 <trace_utimes_common+0x3b3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x394, 0x3b3, x86_l_3b3);
x86_l_396:
	/* 0x396: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_399:
	/* 0x399: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_39c:
	/* 0x39c: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_3a3:
	/* 0x3a3: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_3a8:
	/* 0x3a8: jne    c43 <trace_utimes_common+0xc43> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a8, 0xc43, x86_l_c43);
x86_l_3ae:
	/* 0x3ae: jmp    34e9 <trace_utimes_common+0x34e9> */
	X86_SIM_X86_JMP(0x3ae, 0x34e9, x86_l_34e9);
x86_l_3b3:
	/* 0x3b3: mov    rax,QWORD PTR [r13+0x7e50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_3ba:
	/* 0x3ba: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3bd:
	/* 0x3bd: je     56d <trace_utimes_common+0x56d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3bd, 0x56d, x86_l_56d);
x86_l_3c3:
	/* 0x3c3: movzx  ecx,BYTE PTR [rbx+0xb1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_3ca:
	/* 0x3ca: and    cl,0xfd */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_3cd:
	/* 0x3cd: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d0:
	/* 0x3d0: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_3d3:
	/* 0x3d3: sete   r12b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3d7:
	/* 0x3d7: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_3da:
	/* 0x3da: neg    r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_3dd:
	/* 0x3dd: xor    r12,QWORD PTR [r13+0x7ec0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_3e4:
	/* 0x3e4: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_3e7:
	/* 0x3e7: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_3ee:
	/* 0x3ee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f1:
	/* 0x3f1: je     412 <trace_utimes_common+0x412> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f1, 0x412, x86_l_412);
x86_l_3f3:
	/* 0x3f3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f5:
	/* 0x3f5: cmp    BYTE PTR [rbx+0xb1],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_3fc:
	/* 0x3fc: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_3ff:
	/* 0x3ff: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_402:
	/* 0x402: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_405:
	/* 0x405: xor    rcx,QWORD PTR [r13+0x7ec8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_40c:
	/* 0x40c: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_40f:
	/* 0x40f: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_412:
	/* 0x412: mov    rax,QWORD PTR [r13+0x7e60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_419:
	/* 0x419: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41c:
	/* 0x41c: je     438 <trace_utimes_common+0x438> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41c, 0x438, x86_l_438);
x86_l_41e:
	/* 0x41e: mov    ecx,DWORD PTR [r13+0x5c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_422:
	/* 0x422: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_425:
	/* 0x425: and    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_428:
	/* 0x428: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_42b:
	/* 0x42b: xor    rcx,QWORD PTR [r13+0x7ed0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_432:
	/* 0x432: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_435:
	/* 0x435: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_438:
	/* 0x438: mov    rax,QWORD PTR [r13+0x7e68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_43f:
	/* 0x43f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_442:
	/* 0x442: je     45f <trace_utimes_common+0x45f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x442, 0x45f, x86_l_45f);
x86_l_444:
	/* 0x444: not    rax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_447:
	/* 0x447: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_44b:
	/* 0x44b: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_44f:
	/* 0x44f: neg    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_452:
	/* 0x452: xor    rcx,QWORD PTR [r13+0x7ed8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_459:
	/* 0x459: or     rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_45c:
	/* 0x45c: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_45f:
	/* 0x45f: movzx  r14d,WORD PTR [r13+0x7e] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_464:
	/* 0x464: mov    rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_467:
	/* 0x467: mov    r13,QWORD PTR [r13+0x7e20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_46e:
	/* 0x46e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_471:
	/* 0x471: mov    WORD PTR [rsp+0x8],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_477:
	/* 0x477: je     5d3 <trace_utimes_common+0x5d3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x477, 0x5d3, x86_l_5d3);
x86_l_47d:
	/* 0x47d: mov    rax,QWORD PTR [rbx+0x7e90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_484:
	/* 0x484: mov    QWORD PTR [rsp+0xa8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_48c:
	/* 0x48c: mov    rbp,QWORD PTR [rbx+0x7f08] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_493:
	/* 0x493: mov    rax,QWORD PTR [rbx+0x7f10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_49a:
	/* 0x49a: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_49f:
	/* 0x49f: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4a5:
	/* 0x4a5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_filter_version));
x86_l_4ac:
	/* 0x4ac: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4b1:
	/* 0x4b1: call   4b6 <trace_utimes_common+0x4b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4b6:
	/* 0x4b6: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b9:
	/* 0x4b9: mov    eax,DWORD PTR [rbx+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_4bc:
	/* 0x4bc: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4c1:
	/* 0x4c1: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_4c8:
	/* 0x4c8: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4cb:
	/* 0x4cb: je     4eb <trace_utimes_common+0x4eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4cb, 0x4eb, x86_l_4eb);
x86_l_4cd:
	/* 0x4cd: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4d2:
	/* 0x4d2: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_4d5:
	/* 0x4d5: call   4da <trace_utimes_common+0x4da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4da:
	/* 0x4da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4dd:
	/* 0x4dd: je     4eb <trace_utimes_common+0x4eb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4dd, 0x4eb, x86_l_4eb);
x86_l_4df:
	/* 0x4df: mov    rbx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e2:
	/* 0x4e2: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_4e6:
	/* 0x4e6: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_4e9:
	/* 0x4e9: jmp    4ed <trace_utimes_common+0x4ed> */
	X86_SIM_X86_JMP(0x4e9, 0x4ed, x86_l_4ed);
x86_l_4eb:
	/* 0x4eb: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4ed:
	/* 0x4ed: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4f2:
	/* 0x4f2: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_4f7:
	/* 0x4f7: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_4fa:
	/* 0x4fa: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4fd:
	/* 0x4fd: jb     515 <trace_utimes_common+0x515> */
	X86_SIM_X86_JCC(X86_CC_B, 0x4fd, 0x515, x86_l_515);
x86_l_4ff:
	/* 0x4ff: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_503:
	/* 0x503: je     50a <trace_utimes_common+0x50a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x503, 0x50a, x86_l_50a);
x86_l_505:
	/* 0x505: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_508:
	/* 0x508: jbe    515 <trace_utimes_common+0x515> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x508, 0x515, x86_l_515);
x86_l_50a:
	/* 0x50a: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_512:
	/* 0x512: or     rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_515:
	/* 0x515: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_51a:
	/* 0x51a: mov    eax,DWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_51d:
	/* 0x51d: mov    QWORD PTR [rsp+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_522:
	/* 0x522: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_529:
	/* 0x529: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_52c:
	/* 0x52c: je     589 <trace_utimes_common+0x589> */
	X86_SIM_X86_JCC(X86_CC_E, 0x52c, 0x589, x86_l_589);
x86_l_52e:
	/* 0x52e: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_533:
	/* 0x533: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_536:
	/* 0x536: call   53b <trace_utimes_common+0x53b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_53b:
	/* 0x53b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_53e:
	/* 0x53e: je     59a <trace_utimes_common+0x59a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x53e, 0x59a, x86_l_59a);
x86_l_540:
	/* 0x540: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_543:
	/* 0x543: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_547:
	/* 0x547: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_54a:
	/* 0x54a: jmp    59c <trace_utimes_common+0x59c> */
	X86_SIM_X86_JMP(0x54a, 0x59c, x86_l_59c);
x86_l_54c:
	/* 0x54c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_553:
	/* 0x553: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_558:
	/* 0x558: call   55d <trace_utimes_common+0x55d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_55d:
	/* 0x55d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_560:
	/* 0x560: je     dce <trace_utimes_common+0xdce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x560, 0xdce, x86_l_dce);
x86_l_566:
	/* 0x566: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_568:
	/* 0x568: jmp    1c3 <trace_utimes_common+0x1c3> */
	X86_SIM_X86_JMP(0x568, 0x1c3, x86_l_1c3);
x86_l_56d:
	/* 0x56d: mov    r12,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_574:
	/* 0x574: mov    rax,QWORD PTR [r13+0x7e58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_57b:
	/* 0x57b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_57e:
	/* 0x57e: jne    3f3 <trace_utimes_common+0x3f3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x57e, 0x3f3, x86_l_3f3);
x86_l_584:
	/* 0x584: jmp    412 <trace_utimes_common+0x412> */
	X86_SIM_X86_JMP(0x584, 0x412, x86_l_412);
x86_l_589:
	/* 0x589: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_58b:
	/* 0x58b: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_58e:
	/* 0x58e: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_593:
	/* 0x593: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_596:
	/* 0x596: jae    5ae <trace_utimes_common+0x5ae> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x596, 0x5ae, x86_l_5ae);
x86_l_598:
	/* 0x598: jmp    5c4 <trace_utimes_common+0x5c4> */
	X86_SIM_X86_JMP(0x598, 0x5c4, x86_l_5c4);
x86_l_59a:
	/* 0x59a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_59c:
	/* 0x59c: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5a1:
	/* 0x5a1: not    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_5a4:
	/* 0x5a4: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_5a9:
	/* 0x5a9: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ac:
	/* 0x5ac: jb     5c4 <trace_utimes_common+0x5c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5ac, 0x5c4, x86_l_5c4);
x86_l_5ae:
	/* 0x5ae: cmp    rdx,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_5b2:
	/* 0x5b2: je     5b9 <trace_utimes_common+0x5b9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5b2, 0x5b9, x86_l_5b9);
x86_l_5b4:
	/* 0x5b4: cmp    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_5b7:
	/* 0x5b7: jbe    5c4 <trace_utimes_common+0x5c4> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5b7, 0x5c4, x86_l_5c4);
x86_l_5b9:
	/* 0x5b9: and    r14,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 168ULL);
x86_l_5c1:
	/* 0x5c1: or     rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R14, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c4:
	/* 0x5c4: or     rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5c7:
	/* 0x5c7: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_5ca:
	/* 0x5ca: and    r12,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_5cd:
	/* 0x5cd: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_5d3:
	/* 0x5d3: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5d8:
	/* 0x5d8: cmp    QWORD PTR [r13+0x7e18],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_5e0:
	/* 0x5e0: je     67e <trace_utimes_common+0x67e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5e0, 0x67e, x86_l_67e);
x86_l_5e6:
	/* 0x5e6: call   5eb <trace_utimes_common+0x5eb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_5eb:
	/* 0x5eb: mov    DWORD PTR [r13+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5ef:
	/* 0x5ef: mov    rbx,QWORD PTR [r13+0x7e18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_5f6:
	/* 0x5f6: mov    rax,QWORD PTR [r13+0x7e88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_5fd:
	/* 0x5fd: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_602:
	/* 0x602: mov    rbp,QWORD PTR [r13+0x7ef8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_609:
	/* 0x609: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_60c:
	/* 0x60c: mov    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_60f:
	/* 0x60f: mov    r13,QWORD PTR [r13+0x7f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_616:
	/* 0x616: mov    WORD PTR [rsp+0x50],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_61b:
	/* 0x61b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uid_filter_version));
x86_l_622:
	/* 0x622: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_627:
	/* 0x627: call   62c <trace_utimes_common+0x62c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_62c:
	/* 0x62c: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_630:
	/* 0x630: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_635:
	/* 0x635: mov    r15,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_63c:
	/* 0x63c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_63f:
	/* 0x63f: je     65f <trace_utimes_common+0x65f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x63f, 0x65f, x86_l_65f);
x86_l_641:
	/* 0x641: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_646:
	/* 0x646: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_649:
	/* 0x649: call   64e <trace_utimes_common+0x64e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_64e:
	/* 0x64e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_651:
	/* 0x651: je     65f <trace_utimes_common+0x65f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x651, 0x65f, x86_l_65f);
x86_l_653:
	/* 0x653: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_656:
	/* 0x656: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_65a:
	/* 0x65a: not    r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_65d:
	/* 0x65d: jmp    661 <trace_utimes_common+0x661> */
	X86_SIM_X86_JMP(0x65d, 0x661, x86_l_661);
x86_l_65f:
	/* 0x65f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_661:
	/* 0x661: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_667:
	/* 0x667: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_66a:
	/* 0x66a: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_66f:
	/* 0x66f: dec    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_672:
	/* 0x672: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_675:
	/* 0x675: jae    692 <trace_utimes_common+0x692> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x675, 0x692, x86_l_692);
x86_l_677:
	/* 0x677: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_67c:
	/* 0x67c: jmp    6aa <trace_utimes_common+0x6aa> */
	X86_SIM_X86_JMP(0x67c, 0x6aa, x86_l_6aa);
x86_l_67e:
	/* 0x67e: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_683:
	/* 0x683: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_68b:
	/* 0x68b: jne    6c3 <trace_utimes_common+0x6c3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x68b, 0x6c3, x86_l_6c3);
x86_l_68d:
	/* 0x68d: jmp    762 <trace_utimes_common+0x762> */
	X86_SIM_X86_JMP(0x68d, 0x762, x86_l_762);
x86_l_692:
	/* 0x692: cmp    r13,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_696:
	/* 0x696: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_69b:
	/* 0x69b: je     6a2 <trace_utimes_common+0x6a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x69b, 0x6a2, x86_l_6a2);
x86_l_69d:
	/* 0x69d: cmp    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6a0:
	/* 0x6a0: jbe    6aa <trace_utimes_common+0x6aa> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x6a0, 0x6aa, x86_l_6aa);
x86_l_6a2:
	/* 0x6a2: and    r15,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 24ULL);
x86_l_6a7:
	/* 0x6a7: or     rcx,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6aa:
	/* 0x6aa: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_6ad:
	/* 0x6ad: and    r12,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_6b0:
	/* 0x6b0: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6b5:
	/* 0x6b5: cmp    QWORD PTR [r13+0x7e28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_6bd:
	/* 0x6bd: je     762 <trace_utimes_common+0x762> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6bd, 0x762, x86_l_762);
x86_l_6c3:
	/* 0x6c3: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_6c8:
	/* 0x6c8: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_6cf:
	/* 0x6cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d2:
	/* 0x6d2: jns    6d9 <trace_utimes_common+0x6d9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6d2, 0x6d9, x86_l_6d9);
x86_l_6d4:
	/* 0x6d4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6d7:
	/* 0x6d7: jmp    6db <trace_utimes_common+0x6db> */
	X86_SIM_X86_JMP(0x6d7, 0x6db, x86_l_6db);
x86_l_6d9:
	/* 0x6d9: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6db:
	/* 0x6db: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6df:
	/* 0x6df: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6e1:
	/* 0x6e1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6e4:
	/* 0x6e4: jns    6f0 <trace_utimes_common+0x6f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6e4, 0x6f0, x86_l_6f0);
x86_l_6e6:
	/* 0x6e6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6e9:
	/* 0x6e9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6ec:
	/* 0x6ec: js     6f7 <trace_utimes_common+0x6f7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x6ec, 0x6f7, x86_l_6f7);
x86_l_6ee:
	/* 0x6ee: jmp    6f9 <trace_utimes_common+0x6f9> */
	X86_SIM_X86_JMP(0x6ee, 0x6f9, x86_l_6f9);
x86_l_6f0:
	/* 0x6f0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6f2:
	/* 0x6f2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_6f5:
	/* 0x6f5: jns    6f9 <trace_utimes_common+0x6f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6f5, 0x6f9, x86_l_6f9);
x86_l_6f7:
	/* 0x6f7: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6f9:
	/* 0x6f9: mov    DWORD PTR [r13+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_6fd:
	/* 0x6fd: mov    rbx,QWORD PTR [r13+0x7e28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_704:
	/* 0x704: mov    r15,QWORD PTR [r13+0x7e98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_70b:
	/* 0x70b: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_70e:
	/* 0x70e: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_714:
	/* 0x714: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_71b:
	/* 0x71b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_720:
	/* 0x720: call   725 <trace_utimes_common+0x725> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_725:
	/* 0x725: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_72c:
	/* 0x72c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_72f:
	/* 0x72f: je     74e <trace_utimes_common+0x74e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x72f, 0x74e, x86_l_74e);
x86_l_731:
	/* 0x731: lea    rsi,[rbp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_735:
	/* 0x735: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_738:
	/* 0x738: call   73d <trace_utimes_common+0x73d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_73d:
	/* 0x73d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_740:
	/* 0x740: je     74e <trace_utimes_common+0x74e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x740, 0x74e, x86_l_74e);
x86_l_742:
	/* 0x742: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_745:
	/* 0x745: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_749:
	/* 0x749: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_74c:
	/* 0x74c: jmp    750 <trace_utimes_common+0x750> */
	X86_SIM_X86_JMP(0x74c, 0x750, x86_l_750);
x86_l_74e:
	/* 0x74e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_750:
	/* 0x750: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_753:
	/* 0x753: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_756:
	/* 0x756: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_759:
	/* 0x759: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_75c:
	/* 0x75c: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_762:
	/* 0x762: cmp    QWORD PTR [r13+0x7e30],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_76a:
	/* 0x76a: je     833 <trace_utimes_common+0x833> */
	X86_SIM_X86_JCC(X86_CC_E, 0x76a, 0x833, x86_l_833);
x86_l_770:
	/* 0x770: mov    rcx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_777:
	/* 0x777: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_77b:
	/* 0x77b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_77d:
	/* 0x77d: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_780:
	/* 0x780: jns    78f <trace_utimes_common+0x78f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x780, 0x78f, x86_l_78f);
x86_l_782:
	/* 0x782: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_785:
	/* 0x785: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_788:
	/* 0x788: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_78b:
	/* 0x78b: js     799 <trace_utimes_common+0x799> */
	X86_SIM_X86_JCC(X86_CC_S, 0x78b, 0x799, x86_l_799);
x86_l_78d:
	/* 0x78d: jmp    79b <trace_utimes_common+0x79b> */
	X86_SIM_X86_JMP(0x78d, 0x79b, x86_l_79b);
x86_l_78f:
	/* 0x78f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_791:
	/* 0x791: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_794:
	/* 0x794: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_797:
	/* 0x797: jns    79b <trace_utimes_common+0x79b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x797, 0x79b, x86_l_79b);
x86_l_799:
	/* 0x799: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_79b:
	/* 0x79b: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_79d:
	/* 0x79d: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_7a1:
	/* 0x7a1: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_7a4:
	/* 0x7a4: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_7a8:
	/* 0x7a8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7aa:
	/* 0x7aa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7ad:
	/* 0x7ad: jns    7bd <trace_utimes_common+0x7bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7ad, 0x7bd, x86_l_7bd);
x86_l_7af:
	/* 0x7af: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7b2:
	/* 0x7b2: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7b6:
	/* 0x7b6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7b9:
	/* 0x7b9: js     7c8 <trace_utimes_common+0x7c8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7b9, 0x7c8, x86_l_7c8);
x86_l_7bb:
	/* 0x7bb: jmp    7ca <trace_utimes_common+0x7ca> */
	X86_SIM_X86_JMP(0x7bb, 0x7ca, x86_l_7ca);
x86_l_7bd:
	/* 0x7bd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7bf:
	/* 0x7bf: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_7c3:
	/* 0x7c3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_7c6:
	/* 0x7c6: jns    7ca <trace_utimes_common+0x7ca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7c6, 0x7ca, x86_l_7ca);
x86_l_7c8:
	/* 0x7c8: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ca:
	/* 0x7ca: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_7ce:
	/* 0x7ce: mov    rbx,QWORD PTR [r13+0x7e30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_7d5:
	/* 0x7d5: mov    r15,QWORD PTR [r13+0x7ea0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_7dc:
	/* 0x7dc: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_7df:
	/* 0x7df: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7e5:
	/* 0x7e5: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_7ec:
	/* 0x7ec: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_7f1:
	/* 0x7f1: call   7f6 <trace_utimes_common+0x7f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7f6:
	/* 0x7f6: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7fd:
	/* 0x7fd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_800:
	/* 0x800: je     81f <trace_utimes_common+0x81f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x800, 0x81f, x86_l_81f);
x86_l_802:
	/* 0x802: lea    rsi,[rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_806:
	/* 0x806: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_809:
	/* 0x809: call   80e <trace_utimes_common+0x80e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_80e:
	/* 0x80e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_811:
	/* 0x811: je     81f <trace_utimes_common+0x81f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x811, 0x81f, x86_l_81f);
x86_l_813:
	/* 0x813: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_816:
	/* 0x816: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_81a:
	/* 0x81a: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_81d:
	/* 0x81d: jmp    821 <trace_utimes_common+0x821> */
	X86_SIM_X86_JMP(0x81d, 0x821, x86_l_821);
x86_l_81f:
	/* 0x81f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_821:
	/* 0x821: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_824:
	/* 0x824: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_827:
	/* 0x827: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_82a:
	/* 0x82a: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_82d:
	/* 0x82d: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_833:
	/* 0x833: cmp    QWORD PTR [r13+0x7e38],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_83b:
	/* 0x83b: je     a1e <trace_utimes_common+0xa1e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x83b, 0xa1e, x86_l_a1e);
x86_l_841:
	/* 0x841: mov    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_846:
	/* 0x846: add    rax,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_84d:
	/* 0x84d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_850:
	/* 0x850: jns    863 <trace_utimes_common+0x863> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x850, 0x863, x86_l_863);
x86_l_852:
	/* 0x852: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_855:
	/* 0x855: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_858:
	/* 0x858: js     86a <trace_utimes_common+0x86a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x858, 0x86a, x86_l_86a);
x86_l_85a:
	/* 0x85a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_85c:
	/* 0x85c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85f:
	/* 0x85f: js     872 <trace_utimes_common+0x872> */
	X86_SIM_X86_JCC(X86_CC_S, 0x85f, 0x872, x86_l_872);
x86_l_861:
	/* 0x861: jmp    8c3 <trace_utimes_common+0x8c3> */
	X86_SIM_X86_JMP(0x861, 0x8c3, x86_l_8c3);
x86_l_863:
	/* 0x863: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_865:
	/* 0x865: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_868:
	/* 0x868: jns    85a <trace_utimes_common+0x85a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x868, 0x85a, x86_l_85a);
x86_l_86a:
	/* 0x86a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_86d:
	/* 0x86d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_870:
	/* 0x870: jns    8c3 <trace_utimes_common+0x8c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x870, 0x8c3, x86_l_8c3);
x86_l_872:
	/* 0x872: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_875:
	/* 0x875: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_87a:
	/* 0x87a: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_87e:
	/* 0x87e: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_883:
	/* 0x883: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_887:
	/* 0x887: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_88c:
	/* 0x88c: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_890:
	/* 0x890: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_895:
	/* 0x895: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_899:
	/* 0x899: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_89e:
	/* 0x89e: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_8a2:
	/* 0x8a2: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_8a7:
	/* 0x8a7: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8ab:
	/* 0x8ab: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8b3:
	/* 0x8b3: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_8b7:
	/* 0x8b7: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_8bf:
	/* 0x8bf: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_8c3:
	/* 0x8c3: lea    r15,[rbp+0x4c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_8c7:
	/* 0x8c7: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8cc:
	/* 0x8cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8cf:
	/* 0x8cf: jns    9a6 <trace_utimes_common+0x9a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8cf, 0x9a6, x86_l_9a6);
x86_l_8d5:
	/* 0x8d5: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_8d8:
	/* 0x8d8: mov    BYTE PTR [r15],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8db:
	/* 0x8db: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8dd:
	/* 0x8dd: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8dd, 0x9b5, x86_l_9b5);
x86_l_8e3:
	/* 0x8e3: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_8e7:
	/* 0x8e7: mov    BYTE PTR [r13+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_8eb:
	/* 0x8eb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8ed:
	/* 0x8ed: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8ed, 0x9b5, x86_l_9b5);
x86_l_8f3:
	/* 0x8f3: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_8f7:
	/* 0x8f7: mov    BYTE PTR [r13+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_8fb:
	/* 0x8fb: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_8fd:
	/* 0x8fd: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8fd, 0x9b5, x86_l_9b5);
x86_l_903:
	/* 0x903: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_907:
	/* 0x907: mov    BYTE PTR [r13+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_90b:
	/* 0x90b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_90d:
	/* 0x90d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x90d, 0x9b5, x86_l_9b5);
x86_l_913:
	/* 0x913: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_917:
	/* 0x917: mov    BYTE PTR [r13+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_91b:
	/* 0x91b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_91d:
	/* 0x91d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x91d, 0x9b5, x86_l_9b5);
x86_l_923:
	/* 0x923: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_927:
	/* 0x927: mov    BYTE PTR [r13+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_92b:
	/* 0x92b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_92d:
	/* 0x92d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x92d, 0x9b5, x86_l_9b5);
x86_l_933:
	/* 0x933: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_937:
	/* 0x937: mov    BYTE PTR [r13+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_93b:
	/* 0x93b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_93d:
	/* 0x93d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x93d, 0x9b5, x86_l_9b5);
x86_l_93f:
	/* 0x93f: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_943:
	/* 0x943: mov    BYTE PTR [r13+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_947:
	/* 0x947: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_949:
	/* 0x949: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x949, 0x9b5, x86_l_9b5);
x86_l_94b:
	/* 0x94b: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_94f:
	/* 0x94f: mov    BYTE PTR [r13+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_953:
	/* 0x953: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_955:
	/* 0x955: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x955, 0x9b5, x86_l_9b5);
x86_l_957:
	/* 0x957: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_95b:
	/* 0x95b: mov    BYTE PTR [r13+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_95f:
	/* 0x95f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_961:
	/* 0x961: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x961, 0x9b5, x86_l_9b5);
x86_l_963:
	/* 0x963: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_967:
	/* 0x967: mov    BYTE PTR [r13+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_96b:
	/* 0x96b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_96d:
	/* 0x96d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x96d, 0x9b5, x86_l_9b5);
x86_l_96f:
	/* 0x96f: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_973:
	/* 0x973: mov    BYTE PTR [r13+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_977:
	/* 0x977: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_979:
	/* 0x979: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x979, 0x9b5, x86_l_9b5);
x86_l_97b:
	/* 0x97b: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_97f:
	/* 0x97f: mov    BYTE PTR [r13+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_983:
	/* 0x983: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_985:
	/* 0x985: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x985, 0x9b5, x86_l_9b5);
x86_l_987:
	/* 0x987: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_98b:
	/* 0x98b: mov    BYTE PTR [r13+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_98f:
	/* 0x98f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_991:
	/* 0x991: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x991, 0x9b5, x86_l_9b5);
x86_l_993:
	/* 0x993: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_997:
	/* 0x997: mov    BYTE PTR [r13+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_99b:
	/* 0x99b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_99d:
	/* 0x99d: je     9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99d, 0x9b5, x86_l_9b5);
x86_l_99f:
	/* 0x99f: mov    BYTE PTR [r13+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_9a4:
	/* 0x9a4: jmp    9b5 <trace_utimes_common+0x9b5> */
	X86_SIM_X86_JMP(0x9a4, 0x9b5, x86_l_9b5);
x86_l_9a6:
	/* 0x9a6: mov    QWORD PTR [r15+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_9ae:
	/* 0x9ae: mov    QWORD PTR [r15],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9b5:
	/* 0x9b5: mov    rbx,QWORD PTR [r13+0x7e38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_9bc:
	/* 0x9bc: mov    r13,QWORD PTR [r13+0x7ea8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_9c3:
	/* 0x9c3: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_9c6:
	/* 0x9c6: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_9cc:
	/* 0x9cc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_9d3:
	/* 0x9d3: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_9d8:
	/* 0x9d8: call   9dd <trace_utimes_common+0x9dd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9dd:
	/* 0x9dd: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_9e4:
	/* 0x9e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9e7:
	/* 0x9e7: je     a05 <trace_utimes_common+0xa05> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9e7, 0xa05, x86_l_a05);
x86_l_9e9:
	/* 0x9e9: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9ec:
	/* 0x9ec: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_9ef:
	/* 0x9ef: call   9f4 <trace_utimes_common+0x9f4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9f4:
	/* 0x9f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9f7:
	/* 0x9f7: je     a05 <trace_utimes_common+0xa05> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f7, 0xa05, x86_l_a05);
x86_l_9f9:
	/* 0x9f9: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9fc:
	/* 0x9fc: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a00:
	/* 0xa00: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a03:
	/* 0xa03: jmp    a07 <trace_utimes_common+0xa07> */
	X86_SIM_X86_JMP(0xa03, 0xa07, x86_l_a07);
x86_l_a05:
	/* 0xa05: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a07:
	/* 0xa07: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a0a:
	/* 0xa0a: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a0d:
	/* 0xa0d: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a10:
	/* 0xa10: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a13:
	/* 0xa13: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a18:
	/* 0xa18: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_a1e:
	/* 0xa1e: cmp    QWORD PTR [r13+0x7e40],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_a26:
	/* 0xa26: je     aa2 <trace_utimes_common+0xaa2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa26, 0xaa2, x86_l_aa2);
x86_l_a28:
	/* 0xa28: lea    r15,[rbp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_a2c:
	/* 0xa2c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a2f:
	/* 0xa2f: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_a34:
	/* 0xa34: call   a39 <trace_utimes_common+0xa39> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_a39:
	/* 0xa39: mov    rbx,QWORD PTR [r13+0x7e40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_a40:
	/* 0xa40: mov    r13,QWORD PTR [r13+0x7eb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_a47:
	/* 0xa47: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a4a:
	/* 0xa4a: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a50:
	/* 0xa50: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)comm_filter_version));
x86_l_a57:
	/* 0xa57: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a5c:
	/* 0xa5c: call   a61 <trace_utimes_common+0xa61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a61:
	/* 0xa61: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_a68:
	/* 0xa68: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a6b:
	/* 0xa6b: je     a89 <trace_utimes_common+0xa89> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa6b, 0xa89, x86_l_a89);
x86_l_a6d:
	/* 0xa6d: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a70:
	/* 0xa70: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a73:
	/* 0xa73: call   a78 <trace_utimes_common+0xa78> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_a78:
	/* 0xa78: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a7b:
	/* 0xa7b: je     a89 <trace_utimes_common+0xa89> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7b, 0xa89, x86_l_a89);
x86_l_a7d:
	/* 0xa7d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a80:
	/* 0xa80: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a84:
	/* 0xa84: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a87:
	/* 0xa87: jmp    a8b <trace_utimes_common+0xa8b> */
	X86_SIM_X86_JMP(0xa87, 0xa8b, x86_l_a8b);
x86_l_a89:
	/* 0xa89: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a8b:
	/* 0xa8b: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a8e:
	/* 0xa8e: and    r14,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a91:
	/* 0xa91: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_a94:
	/* 0xa94: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a97:
	/* 0xa97: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a9c:
	/* 0xa9c: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_aa2:
	/* 0xaa2: mov    rbx,QWORD PTR [r13+0x7e48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_aa9:
	/* 0xaa9: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_aac:
	/* 0xaac: je     b15 <trace_utimes_common+0xb15> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaac, 0xb15, x86_l_b15);
x86_l_aae:
	/* 0xaae: mov    eax,DWORD PTR [r13+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ab2:
	/* 0xab2: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ab6:
	/* 0xab6: mov    r15,QWORD PTR [r13+0x7eb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_abd:
	/* 0xabd: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ac0:
	/* 0xac0: mov    WORD PTR [rsp+0x38],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ac6:
	/* 0xac6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_acd:
	/* 0xacd: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ad2:
	/* 0xad2: call   ad7 <trace_utimes_common+0xad7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ad7:
	/* 0xad7: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_ade:
	/* 0xade: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae1:
	/* 0xae1: je     b01 <trace_utimes_common+0xb01> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae1, 0xb01, x86_l_b01);
x86_l_ae3:
	/* 0xae3: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ae8:
	/* 0xae8: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aeb:
	/* 0xaeb: call   af0 <trace_utimes_common+0xaf0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_af0:
	/* 0xaf0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af3:
	/* 0xaf3: je     b01 <trace_utimes_common+0xb01> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaf3, 0xb01, x86_l_b01);
x86_l_af5:
	/* 0xaf5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af8:
	/* 0xaf8: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_afc:
	/* 0xafc: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_aff:
	/* 0xaff: jmp    b03 <trace_utimes_common+0xb03> */
	X86_SIM_X86_JMP(0xaff, 0xb03, x86_l_b03);
x86_l_b01:
	/* 0xb01: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b03:
	/* 0xb03: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b06:
	/* 0xb06: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b09:
	/* 0xb09: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b0c:
	/* 0xb0c: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b0f:
	/* 0xb0f: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_b15:
	/* 0xb15: mov    rbx,QWORD PTR [r13+0x7e70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_b1c:
	/* 0xb1c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b1f:
	/* 0xb1f: je     b7f <trace_utimes_common+0xb7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb1f, 0xb7f, x86_l_b7f);
x86_l_b21:
	/* 0xb21: mov    r15,QWORD PTR [r13+0x7ee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_b28:
	/* 0xb28: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b2b:
	/* 0xb2b: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b31:
	/* 0xb31: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_tree_map_version));
x86_l_b38:
	/* 0xb38: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b3d:
	/* 0xb3d: call   b42 <trace_utimes_common+0xb42> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b42:
	/* 0xb42: mov    r14,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_b49:
	/* 0xb49: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4c:
	/* 0xb4c: je     b6b <trace_utimes_common+0xb6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4c, 0xb6b, x86_l_b6b);
x86_l_b4e:
	/* 0xb4e: lea    rsi,[rbp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_b52:
	/* 0xb52: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b55:
	/* 0xb55: call   b5a <trace_utimes_common+0xb5a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b5a:
	/* 0xb5a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b5d:
	/* 0xb5d: je     b6b <trace_utimes_common+0xb6b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb5d, 0xb6b, x86_l_b6b);
x86_l_b5f:
	/* 0xb5f: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b62:
	/* 0xb62: mov    r14,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b66:
	/* 0xb66: not    r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b69:
	/* 0xb69: jmp    b6d <trace_utimes_common+0xb6d> */
	X86_SIM_X86_JMP(0xb69, 0xb6d, x86_l_b6d);
x86_l_b6b:
	/* 0xb6b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b6d:
	/* 0xb6d: or     rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b70:
	/* 0xb70: and    r14,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b73:
	/* 0xb73: or     r14,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_b76:
	/* 0xb76: and    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_b79:
	/* 0xb79: movzx  r14d,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_b7f:
	/* 0xb7f: mov    rbx,QWORD PTR [r13+0x7e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_b86:
	/* 0xb86: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b89:
	/* 0xb89: je     c04 <trace_utimes_common+0xc04> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb89, 0xc04, x86_l_c04);
x86_l_b8b:
	/* 0xb8b: mov    r13,QWORD PTR [r13+0x7ee8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_b92:
	/* 0xb92: not    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b95:
	/* 0xb95: mov    WORD PTR [rsp+0x50],r14w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_b9b:
	/* 0xb9b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)binary_filter_version));
x86_l_ba2:
	/* 0xba2: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_ba7:
	/* 0xba7: call   bac <trace_utimes_common+0xbac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bac:
	/* 0xbac: mov    rbp,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_bb3:
	/* 0xbb3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bb6:
	/* 0xbb6: je     bf1 <trace_utimes_common+0xbf1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb6, 0xbf1, x86_l_bf1);
x86_l_bb8:
	/* 0xbb8: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bbb:
	/* 0xbbb: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bbf:
	/* 0xbbf: lea    rsi,[rax+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_bc3:
	/* 0xbc3: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bc6:
	/* 0xbc6: call   bcb <trace_utimes_common+0xbcb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_bcb:
	/* 0xbcb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bce:
	/* 0xbce: jne    be5 <trace_utimes_common+0xbe5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbce, 0xbe5, x86_l_be5);
x86_l_bd0:
	/* 0xbd0: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd4:
	/* 0xbd4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bd8:
	/* 0xbd8: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bdb:
	/* 0xbdb: call   be0 <trace_utimes_common+0xbe0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_be0:
	/* 0xbe0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be3:
	/* 0xbe3: je     bf1 <trace_utimes_common+0xbf1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe3, 0xbf1, x86_l_bf1);
x86_l_be5:
	/* 0xbe5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_be8:
	/* 0xbe8: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bec:
	/* 0xbec: not    rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bef:
	/* 0xbef: jmp    bf3 <trace_utimes_common+0xbf3> */
	X86_SIM_X86_JMP(0xbef, 0xbf3, x86_l_bf3);
x86_l_bf1:
	/* 0xbf1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_bf3:
	/* 0xbf3: or     rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bf6:
	/* 0xbf6: and    rbp,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bf9:
	/* 0xbf9: or     rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_bfc:
	/* 0xbfc: and    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_bff:
	/* 0xbff: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_c04:
	/* 0xc04: mov    rax,QWORD PTR [r13+0x7e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_c0b:
	/* 0xc0b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c0e:
	/* 0xc0e: mov    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c13:
	/* 0xc13: je     c20 <trace_utimes_common+0xc20> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc13, 0xc20, x86_l_c20);
x86_l_c15:
	/* 0xc15: mov    rcx,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c19:
	/* 0xc19: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_c1d:
	/* 0xc1d: or     r12,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_c20:
	/* 0xc20: and    r12,QWORD PTR [r13+0x7ef0] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_R13, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_c27:
	/* 0xc27: mov    rax,QWORD PTR [r13+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c2e:
	/* 0xc2e: and    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c31:
	/* 0xc31: mov    QWORD PTR [r13+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c38:
	/* 0xc38: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_c3d:
	/* 0xc3d: je     34e9 <trace_utimes_common+0x34e9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc3d, 0x34e9, x86_l_34e9);
x86_l_c43:
	/* 0xc43: mov    rbx,QWORD PTR [r14+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_c47:
	/* 0xc47: mov    r15,QWORD PTR [r14+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_c4b:
	/* 0xc4b: mov    DWORD PTR [rsp+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_c53:
	/* 0xc53: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)bufs));
x86_l_c5a:
	/* 0xc5a: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_c5f:
	/* 0xc5f: call   c64 <trace_utimes_common+0xc64> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c64:
	/* 0xc64: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c67:
	/* 0xc67: je     c8b <trace_utimes_common+0xc8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc67, 0xc8b, x86_l_c8b);
x86_l_c69:
	/* 0xc69: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6c:
	/* 0xc6c: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c6f:
	/* 0xc6f: je     11e4 <trace_utimes_common+0x11e4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc6f, 0x11e4, x86_l_11e4);
x86_l_c75:
	/* 0xc75: lea    rax,[r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c79:
	/* 0xc79: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c7c:
	/* 0xc7c: jns    ca1 <trace_utimes_common+0xca1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc7c, 0xca1, x86_l_ca1);
x86_l_c7e:
	/* 0xc7e: mov    r10,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c81:
	/* 0xc81: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_c84:
	/* 0xc84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c87:
	/* 0xc87: js     cac <trace_utimes_common+0xcac> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc87, 0xcac, x86_l_cac);
x86_l_c89:
	/* 0xc89: jmp    cb6 <trace_utimes_common+0xcb6> */
	X86_SIM_X86_JMP(0xc89, 0xcb6, x86_l_cb6);
x86_l_c8b:
	/* 0xc8b: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c8d:
	/* 0xc8d: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_c91:
	/* 0xc91: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c94:
	/* 0xc94: js     2ba3 <trace_utimes_common+0x2ba3> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc94, 0x2ba3, x86_l_2ba3);
x86_l_c9a:
	/* 0xc9a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c9c:
	/* 0xc9c: jmp    2ba6 <trace_utimes_common+0x2ba6> */
	X86_SIM_X86_JMP(0xc9c, 0x2ba6, x86_l_2ba6);
x86_l_ca1:
	/* 0xca1: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ca4:
	/* 0xca4: mov    rax,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_ca7:
	/* 0xca7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_caa:
	/* 0xcaa: jns    cb6 <trace_utimes_common+0xcb6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcaa, 0xcb6, x86_l_cb6);
x86_l_cac:
	/* 0xcac: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cae:
	/* 0xcae: test   al,0x20 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 32ULL);
x86_l_cb0:
	/* 0xcb0: jne    dd8 <trace_utimes_common+0xdd8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcb0, 0xdd8, x86_l_dd8);
x86_l_cb6:
	/* 0xcb6: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_cb9:
	/* 0xcb9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cbc:
	/* 0xcbc: jns    cc3 <trace_utimes_common+0xcc3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcbc, 0xcc3, x86_l_cc3);
x86_l_cbe:
	/* 0xcbe: mov    rsi,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cc1:
	/* 0xcc1: jmp    cc5 <trace_utimes_common+0xcc5> */
	X86_SIM_X86_JMP(0xcc1, 0xcc5, x86_l_cc5);
x86_l_cc3:
	/* 0xcc3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cc5:
	/* 0xcc5: lea    rax,[rsi-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_cc9:
	/* 0xcc9: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ccc:
	/* 0xccc: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ccf:
	/* 0xccf: jns    cf3 <trace_utimes_common+0xcf3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xccf, 0xcf3, x86_l_cf3);
x86_l_cd1:
	/* 0xcd1: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd4:
	/* 0xcd4: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_cd7:
	/* 0xcd7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cda:
	/* 0xcda: js     cfd <trace_utimes_common+0xcfd> */
	X86_SIM_X86_JCC(X86_CC_S, 0xcda, 0xcfd, x86_l_cfd);
x86_l_cdc:
	/* 0xcdc: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cde:
	/* 0xcde: lea    rdx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ce2:
	/* 0xce2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_ce5:
	/* 0xce5: js     d09 <trace_utimes_common+0xd09> */
	X86_SIM_X86_JCC(X86_CC_S, 0xce5, 0xd09, x86_l_d09);
x86_l_ce7:
	/* 0xce7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ce9:
	/* 0xce9: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_cec:
	/* 0xcec: jne    d15 <trace_utimes_common+0xd15> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcec, 0xd15, x86_l_d15);
x86_l_cee:
	/* 0xcee: jmp    d9d <trace_utimes_common+0xd9d> */
	X86_SIM_X86_JMP(0xcee, 0xd9d, x86_l_d9d);
x86_l_cf3:
	/* 0xcf3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cf5:
	/* 0xcf5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_cf8:
	/* 0xcf8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_cfb:
	/* 0xcfb: jns    cdc <trace_utimes_common+0xcdc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcfb, 0xcdc, x86_l_cdc);
x86_l_cfd:
	/* 0xcfd: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d00:
	/* 0xd00: lea    rdx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d04:
	/* 0xd04: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d07:
	/* 0xd07: jns    ce7 <trace_utimes_common+0xce7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd07, 0xce7, x86_l_ce7);
x86_l_d09:
	/* 0xd09: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d0c:
	/* 0xd0c: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d0f:
	/* 0xd0f: je     d9d <trace_utimes_common+0xd9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd0f, 0xd9d, x86_l_d9d);
x86_l_d15:
	/* 0xd15: cmp    r10,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_d18:
	/* 0xd18: je     d9d <trace_utimes_common+0xd9d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd18, 0xd9d, x86_l_d9d);
x86_l_d1e:
	/* 0xd1e: lea    rdi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d22:
	/* 0xd22: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d25:
	/* 0xd25: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_d2b:
	/* 0xd2b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_d2e:
	/* 0xd2e: jns    d37 <trace_utimes_common+0xd37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd2e, 0xd37, x86_l_d37);
x86_l_d30:
	/* 0xd30: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d33:
	/* 0xd33: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d37:
	/* 0xd37: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_d3b:
	/* 0xd3b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_d3e:
	/* 0xd3e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_d45:
	/* 0xd45: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_d48:
	/* 0xd48: je     1188 <trace_utimes_common+0x1188> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd48, 0x1188, x86_l_1188);
x86_l_d4e:
	/* 0xd4e: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d53:
	/* 0xd53: mov    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_d56:
	/* 0xd56: neg    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_d58:
	/* 0xd58: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_d5e:
	/* 0xd5e: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d61:
	/* 0xd61: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_d67:
	/* 0xd67: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_d6a:
	/* 0xd6a: jns    1169 <trace_utimes_common+0x1169> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd6a, 0x1169, x86_l_1169);
x86_l_d70:
	/* 0xd70: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_d74:
	/* 0xd74: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d77:
	/* 0xd77: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_d7a:
	/* 0xd7a: je     e46 <trace_utimes_common+0xe46> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7a, 0xe46, x86_l_e46);
x86_l_d80:
	/* 0xd80: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_d84:
	/* 0xd84: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_d89:
	/* 0xd89: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_d8d:
	/* 0xd8d: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_d90:
	/* 0xd90: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_d93:
	/* 0xd93: jne    d77 <trace_utimes_common+0xd77> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd93, 0xd77, x86_l_d77);
x86_l_d95:
	/* 0xd95: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_d98:
	/* 0xd98: jmp    e4b <trace_utimes_common+0xe4b> */
	X86_SIM_X86_JMP(0xd98, 0xe4b, x86_l_e4b);
x86_l_d9d:
	/* 0xd9d: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_da0:
	/* 0xda0: jne    1188 <trace_utimes_common+0x1188> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xda0, 0x1188, x86_l_1188);
x86_l_da6:
	/* 0xda6: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_da9:
	/* 0xda9: je     1188 <trace_utimes_common+0x1188> */
	X86_SIM_X86_JCC(X86_CC_E, 0xda9, 0x1188, x86_l_1188);
x86_l_daf:
	/* 0xdaf: add    rsi,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_db3:
	/* 0xdb3: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_db6:
	/* 0xdb6: jns    e0e <trace_utimes_common+0xe0e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xdb6, 0xe0e, x86_l_e0e);
x86_l_db8:
	/* 0xdb8: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_dbb:
	/* 0xdbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dbe:
	/* 0xdbe: js     e15 <trace_utimes_common+0xe15> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdbe, 0xe15, x86_l_e15);
x86_l_dc0:
	/* 0xdc0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dc2:
	/* 0xdc2: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dc5:
	/* 0xdc5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_dc8:
	/* 0xdc8: js     e20 <trace_utimes_common+0xe20> */
	X86_SIM_X86_JCC(X86_CC_S, 0xdc8, 0xe20, x86_l_e20);
x86_l_dca:
	/* 0xdca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dcc:
	/* 0xdcc: jmp    e23 <trace_utimes_common+0xe23> */
	X86_SIM_X86_JMP(0xdcc, 0xe23, x86_l_e23);
x86_l_dce:
	/* 0xdce: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_dd3:
	/* 0xdd3: jmp    1c3 <trace_utimes_common+0x1c3> */
	X86_SIM_X86_JMP(0xdd3, 0x1c3, x86_l_1c3);
x86_l_dd8:
	/* 0xdd8: lea    rax,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_ddf:
	/* 0xddf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_de2:
	/* 0xde2: jns    119d <trace_utimes_common+0x119d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xde2, 0x119d, x86_l_119d);
x86_l_de8:
	/* 0xde8: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_deb:
	/* 0xdeb: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ded:
	/* 0xded: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_df4:
	/* 0xdf4: je     11dd <trace_utimes_common+0x11dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdf4, 0x11dd, x86_l_11dd);
x86_l_dfa:
	/* 0xdfa: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_dfe:
	/* 0xdfe: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_e02:
	/* 0xe02: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e05:
	/* 0xe05: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_e07:
	/* 0xe07: jne    ded <trace_utimes_common+0xded> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe07, 0xded, x86_l_ded);
x86_l_e09:
	/* 0xe09: jmp    2b8c <trace_utimes_common+0x2b8c> */
	X86_SIM_X86_JMP(0xe09, 0x2b8c, x86_l_2b8c);
x86_l_e0e:
	/* 0xe0e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e10:
	/* 0xe10: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e13:
	/* 0xe13: jns    dc0 <trace_utimes_common+0xdc0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe13, 0xdc0, x86_l_dc0);
x86_l_e15:
	/* 0xe15: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e18:
	/* 0xe18: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e1b:
	/* 0xe1b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_e1e:
	/* 0xe1e: jns    dca <trace_utimes_common+0xdca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe1e, 0xdca, x86_l_dca);
x86_l_e20:
	/* 0xe20: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e23:
	/* 0xe23: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e27:
	/* 0xe27: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e2d:
	/* 0xe2d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e30:
	/* 0xe30: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e33:
	/* 0xe33: jns    e72 <trace_utimes_common+0xe72> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe33, 0xe72, x86_l_e72);
x86_l_e35:
	/* 0xe35: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e38:
	/* 0xe38: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e3c:
	/* 0xe3c: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e3f:
	/* 0xe3f: js     e7d <trace_utimes_common+0xe7d> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe3f, 0xe7d, x86_l_e7d);
x86_l_e41:
	/* 0xe41: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e44:
	/* 0xe44: jmp    e80 <trace_utimes_common+0xe80> */
	X86_SIM_X86_JMP(0xe44, 0xe80, x86_l_e80);
x86_l_e46:
	/* 0xe46: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_e4b:
	/* 0xe4b: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e4f:
	/* 0xe4f: mov    r10,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e54:
	/* 0xe54: jl     1188 <trace_utimes_common+0x1188> */
	X86_SIM_X86_JCC(X86_CC_L, 0xe54, 0x1188, x86_l_1188);
x86_l_e5a:
	/* 0xe5a: mov    BYTE PTR [rbp+0x3fff],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_e61:
	/* 0xe61: mov    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_e67:
	/* 0xe67: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_e6a:
	/* 0xe6a: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_e6d:
	/* 0xe6d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e70:
	/* 0xe70: js     e35 <trace_utimes_common+0xe35> */
	X86_SIM_X86_JCC(X86_CC_S, 0xe70, 0xe35, x86_l_e35);
x86_l_e72:
	/* 0xe72: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e74:
	/* 0xe74: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e78:
	/* 0xe78: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_e7b:
	/* 0xe7b: jns    e41 <trace_utimes_common+0xe41> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xe7b, 0xe41, x86_l_e41);
x86_l_e7d:
	/* 0xe7d: mov    r10,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e80:
	/* 0xe80: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_e83:
	/* 0xe83: je     f12 <trace_utimes_common+0xf12> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe83, 0xf12, x86_l_f12);
x86_l_e89:
	/* 0xe89: cmp    rdx,r10 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_e8c:
	/* 0xe8c: je     f12 <trace_utimes_common+0xf12> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8c, 0xf12, x86_l_f12);
x86_l_e92:
	/* 0xe92: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e96:
	/* 0xe96: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e99:
	/* 0xe99: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_e9f:
	/* 0xe9f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ea2:
	/* 0xea2: jns    eab <trace_utimes_common+0xeab> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xea2, 0xeab, x86_l_eab);
x86_l_ea4:
	/* 0xea4: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ea7:
	/* 0xea7: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_eab:
	/* 0xeab: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_eaf:
	/* 0xeaf: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_eb2:
	/* 0xeb2: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_eb9:
	/* 0xeb9: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_ebc:
	/* 0xebc: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_ebf:
	/* 0xebf: jb     2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_B, 0xebf, 0x2b75, x86_l_2b75);
x86_l_ec5:
	/* 0xec5: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_ec8:
	/* 0xec8: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec8, 0x1178, x86_l_1178);
x86_l_ece:
	/* 0xece: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_ed4:
	/* 0xed4: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_ed7:
	/* 0xed7: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_eda:
	/* 0xeda: jns    1164 <trace_utimes_common+0x1164> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xeda, 0x1164, x86_l_1164);
x86_l_ee0:
	/* 0xee0: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_ee5:
	/* 0xee5: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_ee8:
	/* 0xee8: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_eec:
	/* 0xeec: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_ef0:
	/* 0xef0: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ef3:
	/* 0xef3: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_ef6:
	/* 0xef6: je     f61 <trace_utimes_common+0xf61> */
	X86_SIM_X86_JCC(X86_CC_E, 0xef6, 0xf61, x86_l_f61);
x86_l_ef8:
	/* 0xef8: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_efc:
	/* 0xefc: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_f01:
	/* 0xf01: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_f05:
	/* 0xf05: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f08:
	/* 0xf08: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_f0b:
	/* 0xf0b: jne    ef3 <trace_utimes_common+0xef3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf0b, 0xef3, x86_l_ef3);
x86_l_f0d:
	/* 0xf0d: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_f10:
	/* 0xf10: jmp    f66 <trace_utimes_common+0xf66> */
	X86_SIM_X86_JMP(0xf10, 0xf66, x86_l_f66);
x86_l_f12:
	/* 0xf12: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f15:
	/* 0xf15: jne    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf15, 0x1178, x86_l_1178);
x86_l_f1b:
	/* 0xf1b: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f1e:
	/* 0xf1e: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf1e, 0x1178, x86_l_1178);
x86_l_f24:
	/* 0xf24: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f28:
	/* 0xf28: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f2b:
	/* 0xf2b: jns    f32 <trace_utimes_common+0xf32> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf2b, 0xf32, x86_l_f32);
x86_l_f2d:
	/* 0xf2d: mov    r10,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f30:
	/* 0xf30: jmp    f35 <trace_utimes_common+0xf35> */
	X86_SIM_X86_JMP(0xf30, 0xf35, x86_l_f35);
x86_l_f32:
	/* 0xf32: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f35:
	/* 0xf35: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f38:
	/* 0xf38: jns    f3f <trace_utimes_common+0xf3f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf38, 0xf3f, x86_l_f3f);
x86_l_f3a:
	/* 0xf3a: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f3d:
	/* 0xf3d: jmp    f41 <trace_utimes_common+0xf41> */
	X86_SIM_X86_JMP(0xf3d, 0xf41, x86_l_f41);
x86_l_f3f:
	/* 0xf3f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f41:
	/* 0xf41: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f44:
	/* 0xf44: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f47:
	/* 0xf47: jns    f4e <trace_utimes_common+0xf4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf47, 0xf4e, x86_l_f4e);
x86_l_f49:
	/* 0xf49: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f4c:
	/* 0xf4c: jmp    f50 <trace_utimes_common+0xf50> */
	X86_SIM_X86_JMP(0xf4c, 0xf50, x86_l_f50);
x86_l_f4e:
	/* 0xf4e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f50:
	/* 0xf50: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f54:
	/* 0xf54: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f57:
	/* 0xf57: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f5a:
	/* 0xf5a: jns    f96 <trace_utimes_common+0xf96> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf5a, 0xf96, x86_l_f96);
x86_l_f5c:
	/* 0xf5c: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f5f:
	/* 0xf5f: jmp    f98 <trace_utimes_common+0xf98> */
	X86_SIM_X86_JMP(0xf5f, 0xf98, x86_l_f98);
x86_l_f61:
	/* 0xf61: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_f66:
	/* 0xf66: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_f69:
	/* 0xf69: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_f6d:
	/* 0xf6d: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f71:
	/* 0xf71: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_f76:
	/* 0xf76: jl     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_L, 0xf76, 0x1178, x86_l_1178);
x86_l_f7c:
	/* 0xf7c: lea    edx,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_f80:
	/* 0xf80: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_f86:
	/* 0xf86: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_f8b:
	/* 0xf8b: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_f8e:
	/* 0xf8e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f91:
	/* 0xf91: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f94:
	/* 0xf94: js     f5c <trace_utimes_common+0xf5c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xf94, 0xf5c, x86_l_f5c);
x86_l_f96:
	/* 0xf96: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f98:
	/* 0xf98: lea    rdx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f9c:
	/* 0xf9c: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_f9f:
	/* 0xf9f: jns    fa6 <trace_utimes_common+0xfa6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xf9f, 0xfa6, x86_l_fa6);
x86_l_fa1:
	/* 0xfa1: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fa4:
	/* 0xfa4: jmp    fa8 <trace_utimes_common+0xfa8> */
	X86_SIM_X86_JMP(0xfa4, 0xfa8, x86_l_fa8);
x86_l_fa6:
	/* 0xfa6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa8:
	/* 0xfa8: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fab:
	/* 0xfab: je     103a <trace_utimes_common+0x103a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfab, 0x103a, x86_l_103a);
x86_l_fb1:
	/* 0xfb1: cmp    r10,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_fb4:
	/* 0xfb4: je     103a <trace_utimes_common+0x103a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb4, 0x103a, x86_l_103a);
x86_l_fba:
	/* 0xfba: lea    rdi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fbe:
	/* 0xfbe: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fc1:
	/* 0xfc1: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_fc7:
	/* 0xfc7: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_fca:
	/* 0xfca: jns    fd3 <trace_utimes_common+0xfd3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xfca, 0xfd3, x86_l_fd3);
x86_l_fcc:
	/* 0xfcc: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fcf:
	/* 0xfcf: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fd3:
	/* 0xfd3: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_fd7:
	/* 0xfd7: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_fda:
	/* 0xfda: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_fe1:
	/* 0xfe1: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_fe4:
	/* 0xfe4: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_fe7:
	/* 0xfe7: jb     2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_B, 0xfe7, 0x2b75, x86_l_2b75);
x86_l_fed:
	/* 0xfed: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_ff0:
	/* 0xff0: je     177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xff0, 0x177d, x86_l_177d);
x86_l_ff6:
	/* 0xff6: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ffb:
	/* 0xffb: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1001:
	/* 0x1001: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1004:
	/* 0x1004: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1007:
	/* 0x1007: jns    1169 <trace_utimes_common+0x1169> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1007, 0x1169, x86_l_1169);
x86_l_100d:
	/* 0x100d: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1011:
	/* 0x1011: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1015:
	/* 0x1015: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1018:
	/* 0x1018: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_101b:
	/* 0x101b: je     1088 <trace_utimes_common+0x1088> */
	X86_SIM_X86_JCC(X86_CC_E, 0x101b, 0x1088, x86_l_1088);
x86_l_101d:
	/* 0x101d: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1021:
	/* 0x1021: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1026:
	/* 0x1026: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_102a:
	/* 0x102a: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_102d:
	/* 0x102d: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1030:
	/* 0x1030: jne    1018 <trace_utimes_common+0x1018> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1030, 0x1018, x86_l_1018);
x86_l_1032:
	/* 0x1032: mov    r9,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1035:
	/* 0x1035: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1038:
	/* 0x1038: jmp    1090 <trace_utimes_common+0x1090> */
	X86_SIM_X86_JMP(0x1038, 0x1090, x86_l_1090);
x86_l_103a:
	/* 0x103a: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_103d:
	/* 0x103d: jne    177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x103d, 0x177d, x86_l_177d);
x86_l_1043:
	/* 0x1043: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1046:
	/* 0x1046: je     177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1046, 0x177d, x86_l_177d);
x86_l_104c:
	/* 0x104c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1050:
	/* 0x1050: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1053:
	/* 0x1053: jns    105a <trace_utimes_common+0x105a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1053, 0x105a, x86_l_105a);
x86_l_1055:
	/* 0x1055: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1058:
	/* 0x1058: jmp    105c <trace_utimes_common+0x105c> */
	X86_SIM_X86_JMP(0x1058, 0x105c, x86_l_105c);
x86_l_105a:
	/* 0x105a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_105c:
	/* 0x105c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_105f:
	/* 0x105f: jns    1066 <trace_utimes_common+0x1066> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x105f, 0x1066, x86_l_1066);
x86_l_1061:
	/* 0x1061: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1064:
	/* 0x1064: jmp    1068 <trace_utimes_common+0x1068> */
	X86_SIM_X86_JMP(0x1064, 0x1068, x86_l_1068);
x86_l_1066:
	/* 0x1066: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1068:
	/* 0x1068: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_106b:
	/* 0x106b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_106e:
	/* 0x106e: jns    1075 <trace_utimes_common+0x1075> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x106e, 0x1075, x86_l_1075);
x86_l_1070:
	/* 0x1070: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1073:
	/* 0x1073: jmp    1077 <trace_utimes_common+0x1077> */
	X86_SIM_X86_JMP(0x1073, 0x1077, x86_l_1077);
x86_l_1075:
	/* 0x1075: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1077:
	/* 0x1077: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_107b:
	/* 0x107b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_107e:
	/* 0x107e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1081:
	/* 0x1081: jns    10c0 <trace_utimes_common+0x10c0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1081, 0x10c0, x86_l_10c0);
x86_l_1083:
	/* 0x1083: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1086:
	/* 0x1086: jmp    10c2 <trace_utimes_common+0x10c2> */
	X86_SIM_X86_JMP(0x1086, 0x10c2, x86_l_10c2);
x86_l_1088:
	/* 0x1088: mov    r9,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_108b:
	/* 0x108b: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1090:
	/* 0x1090: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1095:
	/* 0x1095: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1099:
	/* 0x1099: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_109d:
	/* 0x109d: jl     1204 <trace_utimes_common+0x1204> */
	X86_SIM_X86_JCC(X86_CC_L, 0x109d, 0x1204, x86_l_1204);
x86_l_10a3:
	/* 0x10a3: lea    edi,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_10a7:
	/* 0x10a7: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_10ad:
	/* 0x10ad: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_10b2:
	/* 0x10b2: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_10b5:
	/* 0x10b5: mov    rcx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_10b8:
	/* 0x10b8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_10bb:
	/* 0x10bb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10be:
	/* 0x10be: js     1083 <trace_utimes_common+0x1083> */
	X86_SIM_X86_JCC(X86_CC_S, 0x10be, 0x1083, x86_l_1083);
x86_l_10c0:
	/* 0x10c0: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10c2:
	/* 0x10c2: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10c6:
	/* 0x10c6: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_10c9:
	/* 0x10c9: jns    10d0 <trace_utimes_common+0x10d0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10c9, 0x10d0, x86_l_10d0);
x86_l_10cb:
	/* 0x10cb: mov    r10,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10ce:
	/* 0x10ce: jmp    10d3 <trace_utimes_common+0x10d3> */
	X86_SIM_X86_JMP(0x10ce, 0x10d3, x86_l_10d3);
x86_l_10d0:
	/* 0x10d0: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10d3:
	/* 0x10d3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10d6:
	/* 0x10d6: je     11ec <trace_utimes_common+0x11ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10d6, 0x11ec, x86_l_11ec);
x86_l_10dc:
	/* 0x10dc: cmp    rdx,r10 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_10df:
	/* 0x10df: je     11ec <trace_utimes_common+0x11ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10df, 0x11ec, x86_l_11ec);
x86_l_10e5:
	/* 0x10e5: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10e9:
	/* 0x10e9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ec:
	/* 0x10ec: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_10f2:
	/* 0x10f2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_10f5:
	/* 0x10f5: jns    10fe <trace_utimes_common+0x10fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x10f5, 0x10fe, x86_l_10fe);
x86_l_10f7:
	/* 0x10f7: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10fa:
	/* 0x10fa: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10fe:
	/* 0x10fe: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1102:
	/* 0x1102: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1105:
	/* 0x1105: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_110c:
	/* 0x110c: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_110f:
	/* 0x110f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1112:
	/* 0x1112: jb     2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1112, 0x2b75, x86_l_2b75);
x86_l_1118:
	/* 0x1118: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_111b:
	/* 0x111b: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0x111b, 0x1178, x86_l_1178);
x86_l_111d:
	/* 0x111d: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1123:
	/* 0x1123: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1126:
	/* 0x1126: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1129:
	/* 0x1129: jns    1164 <trace_utimes_common+0x1164> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1129, 0x1164, x86_l_1164);
x86_l_112b:
	/* 0x112b: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1130:
	/* 0x1130: mov    rcx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1133:
	/* 0x1133: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1137:
	/* 0x1137: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_113b:
	/* 0x113b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_113e:
	/* 0x113e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1141:
	/* 0x1141: je     1688 <trace_utimes_common+0x1688> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1141, 0x1688, x86_l_1688);
x86_l_1147:
	/* 0x1147: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_114b:
	/* 0x114b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1150:
	/* 0x1150: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1154:
	/* 0x1154: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1157:
	/* 0x1157: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_115a:
	/* 0x115a: jne    113e <trace_utimes_common+0x113e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x115a, 0x113e, x86_l_113e);
x86_l_115c:
	/* 0x115c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_115f:
	/* 0x115f: jmp    168d <trace_utimes_common+0x168d> */
	X86_SIM_X86_JMP(0x115f, 0x168d, x86_l_168d);
x86_l_1164:
	/* 0x1164: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1169:
	/* 0x1169: mov    edx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_116c:
	/* 0x116c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_116e:
	/* 0x116e: call   1173 <trace_utimes_common+0x1173> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_1173:
	/* 0x1173: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1178:
	/* 0x1178: mov    r10,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_117b:
	/* 0x117b: cmp    r14d,0x4000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, 0, 16384ULL);
x86_l_1182:
	/* 0x1182: jne    2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1182, 0x2b75, x86_l_2b75);
x86_l_1188:
	/* 0x1188: add    r10,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_118c:
	/* 0x118c: test   r10,r10 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_118f:
	/* 0x118f: jns    11b4 <trace_utimes_common+0x11b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x118f, 0x11b4, x86_l_11b4);
x86_l_1191:
	/* 0x1191: mov    rax,QWORD PTR [r10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1194:
	/* 0x1194: mov    rax,QWORD PTR [r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1198:
	/* 0x1198: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_119b:
	/* 0x119b: js     11bb <trace_utimes_common+0x11bb> */
	X86_SIM_X86_JCC(X86_CC_S, 0x119b, 0x11bb, x86_l_11bb);
x86_l_119d:
	/* 0x119d: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11a0:
	/* 0x11a0: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_11a5:
	/* 0x11a5: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_11a8:
	/* 0x11a8: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11aa:
	/* 0x11aa: call   11af <trace_utimes_common+0x11af> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_11af:
	/* 0x11af: jmp    2b8c <trace_utimes_common+0x2b8c> */
	X86_SIM_X86_JMP(0x11af, 0x2b8c, x86_l_2b8c);
x86_l_11b4:
	/* 0x11b4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b6:
	/* 0x11b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11b9:
	/* 0x11b9: jns    119d <trace_utimes_common+0x119d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11b9, 0x119d, x86_l_119d);
x86_l_11bb:
	/* 0x11bb: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11be:
	/* 0x11be: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c0:
	/* 0x11c0: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_11c7:
	/* 0x11c7: je     11dd <trace_utimes_common+0x11dd> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11c7, 0x11dd, x86_l_11dd);
x86_l_11c9:
	/* 0x11c9: movzx  edx,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_11cd:
	/* 0x11cd: mov    BYTE PTR [rbp+rcx*1+0x0],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11d1:
	/* 0x11d1: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_11d4:
	/* 0x11d4: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_11d6:
	/* 0x11d6: jne    11c0 <trace_utimes_common+0x11c0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11d6, 0x11c0, x86_l_11c0);
x86_l_11d8:
	/* 0x11d8: jmp    2b8c <trace_utimes_common+0x2b8c> */
	X86_SIM_X86_JMP(0x11d8, 0x2b8c, x86_l_2b8c);
x86_l_11dd:
	/* 0x11dd: mov    BYTE PTR [rbp+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_11e4:
	/* 0x11e4: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11e7:
	/* 0x11e7: jmp    2b8c <trace_utimes_common+0x2b8c> */
	X86_SIM_X86_JMP(0x11e7, 0x2b8c, x86_l_2b8c);
x86_l_11ec:
	/* 0x11ec: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11ef:
	/* 0x11ef: jne    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11ef, 0x1178, x86_l_1178);
x86_l_11f1:
	/* 0x11f1: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11f4:
	/* 0x11f4: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11f4, 0x1178, x86_l_1178);
x86_l_11f6:
	/* 0x11f6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11fa:
	/* 0x11fa: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_11fd:
	/* 0x11fd: jns    120c <trace_utimes_common+0x120c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x11fd, 0x120c, x86_l_120c);
x86_l_11ff:
	/* 0x11ff: mov    r10,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1202:
	/* 0x1202: jmp    120f <trace_utimes_common+0x120f> */
	X86_SIM_X86_JMP(0x1202, 0x120f, x86_l_120f);
x86_l_1204:
	/* 0x1204: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1207:
	/* 0x1207: jmp    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JMP(0x1207, 0x1178, x86_l_1178);
x86_l_120c:
	/* 0x120c: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_120f:
	/* 0x120f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1212:
	/* 0x1212: jns    1219 <trace_utimes_common+0x1219> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1212, 0x1219, x86_l_1219);
x86_l_1214:
	/* 0x1214: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1217:
	/* 0x1217: jmp    121b <trace_utimes_common+0x121b> */
	X86_SIM_X86_JMP(0x1217, 0x121b, x86_l_121b);
x86_l_1219:
	/* 0x1219: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_121b:
	/* 0x121b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_121e:
	/* 0x121e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1221:
	/* 0x1221: jns    1228 <trace_utimes_common+0x1228> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1221, 0x1228, x86_l_1228);
x86_l_1223:
	/* 0x1223: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1226:
	/* 0x1226: jmp    122a <trace_utimes_common+0x122a> */
	X86_SIM_X86_JMP(0x1226, 0x122a, x86_l_122a);
x86_l_1228:
	/* 0x1228: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_122a:
	/* 0x122a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_122e:
	/* 0x122e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1231:
	/* 0x1231: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1234:
	/* 0x1234: jns    16c1 <trace_utimes_common+0x16c1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1234, 0x16c1, x86_l_16c1);
x86_l_123a:
	/* 0x123a: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_123d:
	/* 0x123d: jmp    16c3 <trace_utimes_common+0x16c3> */
	X86_SIM_X86_JMP(0x123d, 0x16c3, x86_l_16c3);
x86_l_1242:
	/* 0x1242: mov    eax,DWORD PTR [rsp+0x44] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1246:
	/* 0x1246: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_124a:
	/* 0x124a: mov    DWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_1252:
	/* 0x1252: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_1259:
	/* 0x1259: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_125e:
	/* 0x125e: call   1263 <trace_utimes_common+0x1263> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1263:
	/* 0x1263: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1266:
	/* 0x1266: je     1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1266, 0x1356, x86_l_1356);
x86_l_126c:
	/* 0x126c: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_126f:
	/* 0x126f: mov    eax,DWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1273:
	/* 0x1273: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1277:
	/* 0x1277: mov    edx,0x170 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 368ULL);
x86_l_127c:
	/* 0x127c: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_127f:
	/* 0x127f: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1281:
	/* 0x1281: call   1286 <trace_utimes_common+0x1286> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 368ULL);
x86_l_1286:
	/* 0x1286: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)proc_info_map));
x86_l_128d:
	/* 0x128d: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1292:
	/* 0x1292: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1297:
	/* 0x1297: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_129a:
	/* 0x129a: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_129d:
	/* 0x129d: call   12a2 <trace_utimes_common+0x12a2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_12a2:
	/* 0x12a2: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12a7:
	/* 0x12a7: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_12aa:
	/* 0x12aa: call   12af <trace_utimes_common+0x12af> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12af:
	/* 0x12af: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b3:
	/* 0x12b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12b6:
	/* 0x12b6: jne    1ed <trace_utimes_common+0x1ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12b6, 0x1ed, x86_l_1ed);
x86_l_12bc:
	/* 0x12bc: jmp    1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JMP(0x12bc, 0x1356, x86_l_1356);
x86_l_12c1:
	/* 0x12c1: mov    eax,DWORD PTR [rsp+0xa4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 164ULL);
x86_l_12c8:
	/* 0x12c8: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12cc:
	/* 0x12cc: mov    DWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_12d4:
	/* 0x12d4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)scratch_map));
x86_l_12db:
	/* 0x12db: lea    rsi,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_12e0:
	/* 0x12e0: call   12e5 <trace_utimes_common+0x12e5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12e5:
	/* 0x12e5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12e8:
	/* 0x12e8: je     1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12e8, 0x1356, x86_l_1356);
x86_l_12ea:
	/* 0x12ea: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12ed:
	/* 0x12ed: mov    eax,DWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12f1:
	/* 0x12f1: mov    DWORD PTR [rsp+0x50],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_12f5:
	/* 0x12f5: mov    edx,0xc8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 200ULL);
x86_l_12fa:
	/* 0x12fa: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_12fd:
	/* 0x12fd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12ff:
	/* 0x12ff: call   1304 <trace_utimes_common+0x1304> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 200ULL);
x86_l_1304:
	/* 0x1304: mov    r15,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)task_info_map));
x86_l_130b:
	/* 0x130b: lea    rsi,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1310:
	/* 0x1310: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1315:
	/* 0x1315: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1318:
	/* 0x1318: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_131b:
	/* 0x131b: call   1320 <trace_utimes_common+0x1320> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_1320:
	/* 0x1320: lea    rsi,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1325:
	/* 0x1325: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1328:
	/* 0x1328: call   132d <trace_utimes_common+0x132d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_132d:
	/* 0x132d: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1332:
	/* 0x1332: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1335:
	/* 0x1335: je     1356 <trace_utimes_common+0x1356> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1335, 0x1356, x86_l_1356);
x86_l_1337:
	/* 0x1337: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_133e:
	/* 0x133e: lea    rax,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1342:
	/* 0x1342: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1345:
	/* 0x1345: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1348:
	/* 0x1348: jns    1529 <trace_utimes_common+0x1529> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1348, 0x1529, x86_l_1529);
x86_l_134e:
	/* 0x134e: mov    r15,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1351:
	/* 0x1351: jmp    152c <trace_utimes_common+0x152c> */
	X86_SIM_X86_JMP(0x1351, 0x152c, x86_l_152c);
x86_l_1356:
	/* 0x1356: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1358:
	/* 0x1358: jmp    34e9 <trace_utimes_common+0x34e9> */
	X86_SIM_X86_JMP(0x1358, 0x34e9, x86_l_34e9);
x86_l_135d:
	/* 0x135d: mov    rax,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1360:
	/* 0x1360: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1364:
	/* 0x1364: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1367:
	/* 0x1367: jns    150c <trace_utimes_common+0x150c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1367, 0x150c, x86_l_150c);
x86_l_136d:
	/* 0x136d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1370:
	/* 0x1370: mov    QWORD PTR [r13+0x7e18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1377:
	/* 0x1377: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_137b:
	/* 0x137b: mov    QWORD PTR [r13+0x7e20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_1382:
	/* 0x1382: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1386:
	/* 0x1386: mov    QWORD PTR [r13+0x7e28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_138d:
	/* 0x138d: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1391:
	/* 0x1391: mov    QWORD PTR [r13+0x7e30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_1398:
	/* 0x1398: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_139c:
	/* 0x139c: mov    QWORD PTR [r13+0x7e38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_13a3:
	/* 0x13a3: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13a7:
	/* 0x13a7: mov    QWORD PTR [r13+0x7e40],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_13ae:
	/* 0x13ae: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13b2:
	/* 0x13b2: mov    QWORD PTR [r13+0x7e48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_13b9:
	/* 0x13b9: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_13bd:
	/* 0x13bd: mov    QWORD PTR [r13+0x7e50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_13c4:
	/* 0x13c4: mov    rcx,QWORD PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_13c8:
	/* 0x13c8: mov    QWORD PTR [r13+0x7e58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_13cf:
	/* 0x13cf: mov    rcx,QWORD PTR [rax+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_13d3:
	/* 0x13d3: mov    QWORD PTR [r13+0x7e60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_13da:
	/* 0x13da: mov    rcx,QWORD PTR [rax+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13de:
	/* 0x13de: mov    QWORD PTR [r13+0x7e68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_13e5:
	/* 0x13e5: mov    rcx,QWORD PTR [rax+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_13e9:
	/* 0x13e9: mov    QWORD PTR [r13+0x7e70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_13f0:
	/* 0x13f0: mov    rcx,QWORD PTR [rax+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_13f4:
	/* 0x13f4: mov    QWORD PTR [r13+0x7e78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_13fb:
	/* 0x13fb: mov    rcx,QWORD PTR [rax+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_13ff:
	/* 0x13ff: mov    QWORD PTR [r13+0x7e80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_1406:
	/* 0x1406: mov    rcx,QWORD PTR [rax+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_140a:
	/* 0x140a: mov    QWORD PTR [r13+0x7e88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_1411:
	/* 0x1411: mov    rcx,QWORD PTR [rax+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1415:
	/* 0x1415: mov    QWORD PTR [r13+0x7e90],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_141c:
	/* 0x141c: mov    rcx,QWORD PTR [rax+0x80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1423:
	/* 0x1423: mov    QWORD PTR [r13+0x7e98],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_142a:
	/* 0x142a: mov    rcx,QWORD PTR [rax+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1431:
	/* 0x1431: mov    QWORD PTR [r13+0x7ea0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_1438:
	/* 0x1438: mov    rcx,QWORD PTR [rax+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_143f:
	/* 0x143f: mov    QWORD PTR [r13+0x7ea8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_1446:
	/* 0x1446: mov    rcx,QWORD PTR [rax+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_144d:
	/* 0x144d: mov    QWORD PTR [r13+0x7eb0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1454:
	/* 0x1454: mov    rcx,QWORD PTR [rax+0xa0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_145b:
	/* 0x145b: mov    QWORD PTR [r13+0x7eb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_1462:
	/* 0x1462: mov    rcx,QWORD PTR [rax+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1469:
	/* 0x1469: mov    QWORD PTR [r13+0x7ec0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32448ULL);
x86_l_1470:
	/* 0x1470: mov    rcx,QWORD PTR [rax+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1477:
	/* 0x1477: mov    QWORD PTR [r13+0x7ec8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32456ULL);
x86_l_147e:
	/* 0x147e: mov    rcx,QWORD PTR [rax+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1485:
	/* 0x1485: mov    QWORD PTR [r13+0x7ed0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32464ULL);
x86_l_148c:
	/* 0x148c: mov    rcx,QWORD PTR [rax+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1493:
	/* 0x1493: mov    QWORD PTR [r13+0x7ed8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32472ULL);
x86_l_149a:
	/* 0x149a: mov    rcx,QWORD PTR [rax+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_14a1:
	/* 0x14a1: mov    QWORD PTR [r13+0x7ee0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_14a8:
	/* 0x14a8: mov    rcx,QWORD PTR [rax+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_14af:
	/* 0x14af: mov    QWORD PTR [r13+0x7ee8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_14b6:
	/* 0x14b6: mov    rcx,QWORD PTR [rax+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_14bd:
	/* 0x14bd: mov    QWORD PTR [r13+0x7ef0],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32496ULL);
x86_l_14c4:
	/* 0x14c4: mov    rcx,QWORD PTR [rax+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_14cb:
	/* 0x14cb: mov    QWORD PTR [r13+0x7ef8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_14d2:
	/* 0x14d2: mov    rcx,QWORD PTR [rax+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_14d9:
	/* 0x14d9: mov    QWORD PTR [r13+0x7f00],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_14e0:
	/* 0x14e0: mov    rcx,QWORD PTR [rax+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_14e7:
	/* 0x14e7: mov    QWORD PTR [r13+0x7f08],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_14ee:
	/* 0x14ee: mov    rax,QWORD PTR [rax+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_14f5:
	/* 0x14f5: mov    QWORD PTR [r13+0x7f10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_14fc:
	/* 0x14fc: movzx  eax,WORD PTR [r12+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1502:
	/* 0x1502: mov    WORD PTR [r13+0x7e],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1507:
	/* 0x1507: jmp    2da <trace_utimes_common+0x2da> */
	X86_SIM_X86_JMP(0x1507, 0x2da, x86_l_2da);
x86_l_150c:
	/* 0x150c: add    rbp,0x7e18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32280ULL);
x86_l_1513:
	/* 0x1513: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_1518:
	/* 0x1518: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_151b:
	/* 0x151b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_151d:
	/* 0x151d: call   1522 <trace_utimes_common+0x1522> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 256ULL);
x86_l_1522:
	/* 0x1522: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1524:
	/* 0x1524: jmp    34e9 <trace_utimes_common+0x34e9> */
	X86_SIM_X86_JMP(0x1524, 0x34e9, x86_l_34e9);
x86_l_1529:
	/* 0x1529: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_152c:
	/* 0x152c: lea    rcx,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1530:
	/* 0x1530: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1533:
	/* 0x1533: jns    153a <trace_utimes_common+0x153a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1533, 0x153a, x86_l_153a);
x86_l_1535:
	/* 0x1535: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1538:
	/* 0x1538: jmp    153c <trace_utimes_common+0x153c> */
	X86_SIM_X86_JMP(0x1538, 0x153c, x86_l_153c);
x86_l_153a:
	/* 0x153a: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_153c:
	/* 0x153c: mov    rbp,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_153f:
	/* 0x153f: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1543:
	/* 0x1543: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1545:
	/* 0x1545: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1548:
	/* 0x1548: jns    154f <trace_utimes_common+0x154f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1548, 0x154f, x86_l_154f);
x86_l_154a:
	/* 0x154a: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154d:
	/* 0x154d: jmp    1552 <trace_utimes_common+0x1552> */
	X86_SIM_X86_JMP(0x154d, 0x1552, x86_l_1552);
x86_l_154f:
	/* 0x154f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1552:
	/* 0x1552: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1557:
	/* 0x1557: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_155a:
	/* 0x155a: jns    155e <trace_utimes_common+0x155e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x155a, 0x155e, x86_l_155e);
x86_l_155c:
	/* 0x155c: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_155e:
	/* 0x155e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1563:
	/* 0x1563: mov    DWORD PTR [rdx+0x24],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1566:
	/* 0x1566: lea    rcx,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_156a:
	/* 0x156a: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_156d:
	/* 0x156d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156f:
	/* 0x156f: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1572:
	/* 0x1572: jns    1579 <trace_utimes_common+0x1579> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1572, 0x1579, x86_l_1579);
x86_l_1574:
	/* 0x1574: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1577:
	/* 0x1577: jmp    157b <trace_utimes_common+0x157b> */
	X86_SIM_X86_JMP(0x1577, 0x157b, x86_l_157b);
x86_l_1579:
	/* 0x1579: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_157b:
	/* 0x157b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1581:
	/* 0x1581: jns    1585 <trace_utimes_common+0x1585> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1581, 0x1585, x86_l_1585);
x86_l_1583:
	/* 0x1583: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1585:
	/* 0x1585: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1587:
	/* 0x1587: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_158b:
	/* 0x158b: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_158e:
	/* 0x158e: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1592:
	/* 0x1592: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1594:
	/* 0x1594: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1597:
	/* 0x1597: jns    159b <trace_utimes_common+0x159b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1597, 0x159b, x86_l_159b);
x86_l_1599:
	/* 0x1599: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_159b:
	/* 0x159b: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15a0:
	/* 0x15a0: mov    DWORD PTR [rsi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_15a3:
	/* 0x15a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15a6:
	/* 0x15a6: jns    15ad <trace_utimes_common+0x15ad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15a6, 0x15ad, x86_l_15ad);
x86_l_15a8:
	/* 0x15a8: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15ab:
	/* 0x15ab: jmp    15af <trace_utimes_common+0x15af> */
	X86_SIM_X86_JMP(0x15ab, 0x15af, x86_l_15af);
x86_l_15ad:
	/* 0x15ad: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15af:
	/* 0x15af: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15b3:
	/* 0x15b3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15b5:
	/* 0x15b5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15b8:
	/* 0x15b8: jns    15bf <trace_utimes_common+0x15bf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15b8, 0x15bf, x86_l_15bf);
x86_l_15ba:
	/* 0x15ba: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15bd:
	/* 0x15bd: jmp    15c1 <trace_utimes_common+0x15c1> */
	X86_SIM_X86_JMP(0x15bd, 0x15c1, x86_l_15c1);
x86_l_15bf:
	/* 0x15bf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15c1:
	/* 0x15c1: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15c4:
	/* 0x15c4: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_15c7:
	/* 0x15c7: jns    15cb <trace_utimes_common+0x15cb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15c7, 0x15cb, x86_l_15cb);
x86_l_15c9:
	/* 0x15c9: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15cb:
	/* 0x15cb: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_15cd:
	/* 0x15cd: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_15d1:
	/* 0x15d1: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_15d4:
	/* 0x15d4: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_15d8:
	/* 0x15d8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15da:
	/* 0x15da: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15dd:
	/* 0x15dd: jns    15e1 <trace_utimes_common+0x15e1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15dd, 0x15e1, x86_l_15e1);
x86_l_15df:
	/* 0x15df: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e1:
	/* 0x15e1: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15e6:
	/* 0x15e6: mov    DWORD PTR [rdx+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15e9:
	/* 0x15e9: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15eb:
	/* 0x15eb: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15ee:
	/* 0x15ee: jns    15f5 <trace_utimes_common+0x15f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15ee, 0x15f5, x86_l_15f5);
x86_l_15f0:
	/* 0x15f0: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15f3:
	/* 0x15f3: jmp    15f7 <trace_utimes_common+0x15f7> */
	X86_SIM_X86_JMP(0x15f3, 0x15f7, x86_l_15f7);
x86_l_15f5:
	/* 0x15f5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_15f7:
	/* 0x15f7: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15fd:
	/* 0x15fd: jns    1601 <trace_utimes_common+0x1601> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x15fd, 0x1601, x86_l_1601);
x86_l_15ff:
	/* 0x15ff: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1601:
	/* 0x1601: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1603:
	/* 0x1603: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1607:
	/* 0x1607: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_160a:
	/* 0x160a: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_160e:
	/* 0x160e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1610:
	/* 0x1610: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1613:
	/* 0x1613: jns    161a <trace_utimes_common+0x161a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1613, 0x161a, x86_l_161a);
x86_l_1615:
	/* 0x1615: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1618:
	/* 0x1618: jmp    161c <trace_utimes_common+0x161c> */
	X86_SIM_X86_JMP(0x1618, 0x161c, x86_l_161c);
x86_l_161a:
	/* 0x161a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_161c:
	/* 0x161c: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1620:
	/* 0x1620: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1623:
	/* 0x1623: jns    1627 <trace_utimes_common+0x1627> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1623, 0x1627, x86_l_1627);
x86_l_1625:
	/* 0x1625: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1627:
	/* 0x1627: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_162c:
	/* 0x162c: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_162f:
	/* 0x162f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1631:
	/* 0x1631: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1634:
	/* 0x1634: jns    163b <trace_utimes_common+0x163b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1634, 0x163b, x86_l_163b);
x86_l_1636:
	/* 0x1636: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1639:
	/* 0x1639: jmp    163d <trace_utimes_common+0x163d> */
	X86_SIM_X86_JMP(0x1639, 0x163d, x86_l_163d);
x86_l_163b:
	/* 0x163b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_163d:
	/* 0x163d: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1640:
	/* 0x1640: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1643:
	/* 0x1643: jns    1647 <trace_utimes_common+0x1647> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1643, 0x1647, x86_l_1647);
x86_l_1645:
	/* 0x1645: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1647:
	/* 0x1647: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1649:
	/* 0x1649: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_164d:
	/* 0x164d: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1650:
	/* 0x1650: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1654:
	/* 0x1654: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1656:
	/* 0x1656: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1659:
	/* 0x1659: jns    1660 <trace_utimes_common+0x1660> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1659, 0x1660, x86_l_1660);
x86_l_165b:
	/* 0x165b: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_165e:
	/* 0x165e: jmp    1662 <trace_utimes_common+0x1662> */
	X86_SIM_X86_JMP(0x165e, 0x1662, x86_l_1662);
x86_l_1660:
	/* 0x1660: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1662:
	/* 0x1662: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_1666:
	/* 0x1666: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1669:
	/* 0x1669: jns    166d <trace_utimes_common+0x166d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1669, 0x166d, x86_l_166d);
x86_l_166b:
	/* 0x166b: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_166d:
	/* 0x166d: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_166f:
	/* 0x166f: jne    17e4 <trace_utimes_common+0x17e4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x166f, 0x17e4, x86_l_17e4);
x86_l_1675:
	/* 0x1675: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1677:
	/* 0x1677: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_167a:
	/* 0x167a: jns    17ba <trace_utimes_common+0x17ba> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x167a, 0x17ba, x86_l_17ba);
x86_l_1680:
	/* 0x1680: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1683:
	/* 0x1683: jmp    17bc <trace_utimes_common+0x17bc> */
	X86_SIM_X86_JMP(0x1683, 0x17bc, x86_l_17bc);
x86_l_1688:
	/* 0x1688: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_168d:
	/* 0x168d: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1690:
	/* 0x1690: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1694:
	/* 0x1694: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1698:
	/* 0x1698: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_169d:
	/* 0x169d: jl     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_L, 0x169d, 0x1178, x86_l_1178);
x86_l_16a3:
	/* 0x16a3: lea    edx,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_16a7:
	/* 0x16a7: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_16ad:
	/* 0x16ad: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_16b2:
	/* 0x16b2: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_16b5:
	/* 0x16b5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_16b8:
	/* 0x16b8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16bb:
	/* 0x16bb: js     123a <trace_utimes_common+0x123a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x16bb, 0x123a, x86_l_123a);
x86_l_16c1:
	/* 0x16c1: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16c3:
	/* 0x16c3: lea    rdx,[r10+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16c7:
	/* 0x16c7: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16ca:
	/* 0x16ca: jns    16d1 <trace_utimes_common+0x16d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16ca, 0x16d1, x86_l_16d1);
x86_l_16cc:
	/* 0x16cc: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16cf:
	/* 0x16cf: jmp    16d3 <trace_utimes_common+0x16d3> */
	X86_SIM_X86_JMP(0x16cf, 0x16d3, x86_l_16d3);
x86_l_16d1:
	/* 0x16d1: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16d3:
	/* 0x16d3: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16d6:
	/* 0x16d6: je     1765 <trace_utimes_common+0x1765> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16d6, 0x1765, x86_l_1765);
x86_l_16dc:
	/* 0x16dc: cmp    r10,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_16df:
	/* 0x16df: je     1765 <trace_utimes_common+0x1765> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16df, 0x1765, x86_l_1765);
x86_l_16e5:
	/* 0x16e5: lea    rdi,[r10+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16e9:
	/* 0x16e9: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16ec:
	/* 0x16ec: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_16f2:
	/* 0x16f2: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_16f5:
	/* 0x16f5: jns    16fe <trace_utimes_common+0x16fe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x16f5, 0x16fe, x86_l_16fe);
x86_l_16f7:
	/* 0x16f7: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16fa:
	/* 0x16fa: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16fe:
	/* 0x16fe: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1702:
	/* 0x1702: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1705:
	/* 0x1705: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_170c:
	/* 0x170c: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_170f:
	/* 0x170f: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1712:
	/* 0x1712: jb     2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1712, 0x2b75, x86_l_2b75);
x86_l_1718:
	/* 0x1718: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_171b:
	/* 0x171b: je     177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x171b, 0x177d, x86_l_177d);
x86_l_171d:
	/* 0x171d: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1722:
	/* 0x1722: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1728:
	/* 0x1728: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_172b:
	/* 0x172b: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_172e:
	/* 0x172e: jns    1169 <trace_utimes_common+0x1169> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x172e, 0x1169, x86_l_1169);
x86_l_1734:
	/* 0x1734: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1738:
	/* 0x1738: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_173c:
	/* 0x173c: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_173f:
	/* 0x173f: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1742:
	/* 0x1742: je     1a89 <trace_utimes_common+0x1a89> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1742, 0x1a89, x86_l_1a89);
x86_l_1748:
	/* 0x1748: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_174c:
	/* 0x174c: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1751:
	/* 0x1751: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1755:
	/* 0x1755: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1758:
	/* 0x1758: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_175b:
	/* 0x175b: jne    173f <trace_utimes_common+0x173f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x175b, 0x173f, x86_l_173f);
x86_l_175d:
	/* 0x175d: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1760:
	/* 0x1760: jmp    1a8e <trace_utimes_common+0x1a8e> */
	X86_SIM_X86_JMP(0x1760, 0x1a8e, x86_l_1a8e);
x86_l_1765:
	/* 0x1765: cmp    r10,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1768:
	/* 0x1768: jne    177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1768, 0x177d, x86_l_177d);
x86_l_176a:
	/* 0x176a: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_176d:
	/* 0x176d: je     177d <trace_utimes_common+0x177d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x176d, 0x177d, x86_l_177d);
x86_l_176f:
	/* 0x176f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1773:
	/* 0x1773: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1776:
	/* 0x1776: jns    1785 <trace_utimes_common+0x1785> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1776, 0x1785, x86_l_1785);
x86_l_1778:
	/* 0x1778: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_177b:
	/* 0x177b: jmp    1787 <trace_utimes_common+0x1787> */
	X86_SIM_X86_JMP(0x177b, 0x1787, x86_l_1787);
x86_l_177d:
	/* 0x177d: mov    rdx,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1780:
	/* 0x1780: jmp    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JMP(0x1780, 0x1178, x86_l_1178);
x86_l_1785:
	/* 0x1785: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1787:
	/* 0x1787: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_178a:
	/* 0x178a: jns    1791 <trace_utimes_common+0x1791> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x178a, 0x1791, x86_l_1791);
x86_l_178c:
	/* 0x178c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_178f:
	/* 0x178f: jmp    1793 <trace_utimes_common+0x1793> */
	X86_SIM_X86_JMP(0x178f, 0x1793, x86_l_1793);
x86_l_1791:
	/* 0x1791: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1793:
	/* 0x1793: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1796:
	/* 0x1796: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1799:
	/* 0x1799: jns    17a0 <trace_utimes_common+0x17a0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1799, 0x17a0, x86_l_17a0);
x86_l_179b:
	/* 0x179b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_179e:
	/* 0x179e: jmp    17a2 <trace_utimes_common+0x17a2> */
	X86_SIM_X86_JMP(0x179e, 0x17a2, x86_l_17a2);
x86_l_17a0:
	/* 0x17a0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17a2:
	/* 0x17a2: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_17a6:
	/* 0x17a6: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17a9:
	/* 0x17a9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17ac:
	/* 0x17ac: jns    1abf <trace_utimes_common+0x1abf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17ac, 0x1abf, x86_l_1abf);
x86_l_17b2:
	/* 0x17b2: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17b5:
	/* 0x17b5: jmp    1ac1 <trace_utimes_common+0x1ac1> */
	X86_SIM_X86_JMP(0x17b5, 0x1ac1, x86_l_1ac1);
x86_l_17ba:
	/* 0x17ba: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17bc:
	/* 0x17bc: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_17bf:
	/* 0x17bf: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17c2:
	/* 0x17c2: jns    17c6 <trace_utimes_common+0x17c6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17c2, 0x17c6, x86_l_17c6);
x86_l_17c4:
	/* 0x17c4: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17c6:
	/* 0x17c6: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17c8:
	/* 0x17c8: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_17cc:
	/* 0x17cc: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17cf:
	/* 0x17cf: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_17d3:
	/* 0x17d3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17d5:
	/* 0x17d5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_17d8:
	/* 0x17d8: jns    17dc <trace_utimes_common+0x17dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17d8, 0x17dc, x86_l_17dc);
x86_l_17da:
	/* 0x17da: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17dc:
	/* 0x17dc: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17e1:
	/* 0x17e1: mov    DWORD PTR [rdx+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_17e4:
	/* 0x17e4: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_17e9:
	/* 0x17e9: mov    DWORD PTR [rcx+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_17ec:
	/* 0x17ec: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_17f3:
	/* 0x17f3: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17f6:
	/* 0x17f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f9:
	/* 0x17f9: jns    1800 <trace_utimes_common+0x1800> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x17f9, 0x1800, x86_l_1800);
x86_l_17fb:
	/* 0x17fb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_17fe:
	/* 0x17fe: jmp    1802 <trace_utimes_common+0x1802> */
	X86_SIM_X86_JMP(0x17fe, 0x1802, x86_l_1802);
x86_l_1800:
	/* 0x1800: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1802:
	/* 0x1802: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1806:
	/* 0x1806: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1808:
	/* 0x1808: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_180b:
	/* 0x180b: jns    1812 <trace_utimes_common+0x1812> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x180b, 0x1812, x86_l_1812);
x86_l_180d:
	/* 0x180d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1810:
	/* 0x1810: jmp    1814 <trace_utimes_common+0x1814> */
	X86_SIM_X86_JMP(0x1810, 0x1814, x86_l_1814);
x86_l_1812:
	/* 0x1812: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1814:
	/* 0x1814: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1817:
	/* 0x1817: jns    181b <trace_utimes_common+0x181b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1817, 0x181b, x86_l_181b);
x86_l_1819:
	/* 0x1819: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_181b:
	/* 0x181b: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1820:
	/* 0x1820: mov    DWORD PTR [r14+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1824:
	/* 0x1824: call   1829 <trace_utimes_common+0x1829> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1829:
	/* 0x1829: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_182d:
	/* 0x182d: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1831:
	/* 0x1831: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1834:
	/* 0x1834: jns    183b <trace_utimes_common+0x183b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1834, 0x183b, x86_l_183b);
x86_l_1836:
	/* 0x1836: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1839:
	/* 0x1839: jmp    183d <trace_utimes_common+0x183d> */
	X86_SIM_X86_JMP(0x1839, 0x183d, x86_l_183d);
x86_l_183b:
	/* 0x183b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_183d:
	/* 0x183d: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1842:
	/* 0x1842: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1845:
	/* 0x1845: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1849:
	/* 0x1849: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_184c:
	/* 0x184c: jns    1853 <trace_utimes_common+0x1853> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x184c, 0x1853, x86_l_1853);
x86_l_184e:
	/* 0x184e: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1851:
	/* 0x1851: jmp    1855 <trace_utimes_common+0x1855> */
	X86_SIM_X86_JMP(0x1851, 0x1855, x86_l_1855);
x86_l_1853:
	/* 0x1853: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1855:
	/* 0x1855: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_185a:
	/* 0x185a: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_185e:
	/* 0x185e: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_1862:
	/* 0x1862: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1865:
	/* 0x1865: jns    186d <trace_utimes_common+0x186d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1865, 0x186d, x86_l_186d);
x86_l_1867:
	/* 0x1867: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_186b:
	/* 0x186b: jmp    186f <trace_utimes_common+0x186f> */
	X86_SIM_X86_JMP(0x186b, 0x186f, x86_l_186f);
x86_l_186d:
	/* 0x186d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_186f:
	/* 0x186f: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1872:
	/* 0x1872: mov    r14,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1877:
	/* 0x1877: mov    QWORD PTR [r14+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_187b:
	/* 0x187b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_187e:
	/* 0x187e: jns    188b <trace_utimes_common+0x188b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x187e, 0x188b, x86_l_188b);
x86_l_1880:
	/* 0x1880: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1882:
	/* 0x1882: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1884:
	/* 0x1884: je     188b <trace_utimes_common+0x188b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1884, 0x188b, x86_l_188b);
x86_l_1886:
	/* 0x1886: or     BYTE PTR [r14+0x54],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_188b:
	/* 0x188b: lea    rdi,[r14+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_188f:
	/* 0x188f: mov    QWORD PTR [r14+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_1897:
	/* 0x1897: mov    QWORD PTR [r14+0x34],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_189f:
	/* 0x189f: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_18a4:
	/* 0x18a4: call   18a9 <trace_utimes_common+0x18a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_18a9:
	/* 0x18a9: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18ac:
	/* 0x18ac: mov    rbx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_18af:
	/* 0x18af: jns    18b7 <trace_utimes_common+0x18b7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18af, 0x18b7, x86_l_18b7);
x86_l_18b1:
	/* 0x18b1: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18b5:
	/* 0x18b5: jmp    18b9 <trace_utimes_common+0x18b9> */
	X86_SIM_X86_JMP(0x18b5, 0x18b9, x86_l_18b9);
x86_l_18b7:
	/* 0x18b7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b9:
	/* 0x18b9: mov    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18be:
	/* 0x18be: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18c3:
	/* 0x18c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18c6:
	/* 0x18c6: jns    18cd <trace_utimes_common+0x18cd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18c6, 0x18cd, x86_l_18cd);
x86_l_18c8:
	/* 0x18c8: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18cb:
	/* 0x18cb: jmp    18cf <trace_utimes_common+0x18cf> */
	X86_SIM_X86_JMP(0x18cb, 0x18cf, x86_l_18cf);
x86_l_18cd:
	/* 0x18cd: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18cf:
	/* 0x18cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18d2:
	/* 0x18d2: jns    1925 <trace_utimes_common+0x1925> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x18d2, 0x1925, x86_l_1925);
x86_l_18d4:
	/* 0x18d4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18d7:
	/* 0x18d7: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_18dc:
	/* 0x18dc: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18e0:
	/* 0x18e0: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_18e5:
	/* 0x18e5: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18e9:
	/* 0x18e9: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_18ee:
	/* 0x18ee: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18f2:
	/* 0x18f2: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_18f7:
	/* 0x18f7: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_18fb:
	/* 0x18fb: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1900:
	/* 0x1900: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1904:
	/* 0x1904: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1909:
	/* 0x1909: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_190d:
	/* 0x190d: mov    QWORD PTR [rsp+0x80],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1915:
	/* 0x1915: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1919:
	/* 0x1919: mov    QWORD PTR [rsp+0x88],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1921:
	/* 0x1921: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1925:
	/* 0x1925: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1928:
	/* 0x1928: add    rcx,0x44 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_192c:
	/* 0x192c: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1931:
	/* 0x1931: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1934:
	/* 0x1934: jns    1a54 <trace_utimes_common+0x1a54> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1934, 0x1a54, x86_l_1a54);
x86_l_193a:
	/* 0x193a: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_193d:
	/* 0x193d: mov    BYTE PTR [rcx],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_193f:
	/* 0x193f: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_1941:
	/* 0x1941: je     1a63 <trace_utimes_common+0x1a63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1941, 0x1a63, x86_l_1a63);
x86_l_1947:
	/* 0x1947: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_194b:
	/* 0x194b: mov    BYTE PTR [rbx+0x45],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 69ULL);
x86_l_194e:
	/* 0x194e: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1950:
	/* 0x1950: je     1a63 <trace_utimes_common+0x1a63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1950, 0x1a63, x86_l_1a63);
x86_l_1956:
	/* 0x1956: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_195a:
	/* 0x195a: mov    BYTE PTR [rbx+0x46],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_195d:
	/* 0x195d: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_195f:
	/* 0x195f: je     1a63 <trace_utimes_common+0x1a63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x195f, 0x1a63, x86_l_1a63);
x86_l_1965:
	/* 0x1965: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_1969:
	/* 0x1969: mov    BYTE PTR [rbx+0x47],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 71ULL);
x86_l_196c:
	/* 0x196c: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_196e:
	/* 0x196e: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x196e, 0x1a6d, x86_l_1a6d);
x86_l_1974:
	/* 0x1974: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_1978:
	/* 0x1978: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_197d:
	/* 0x197d: mov    BYTE PTR [rdx+0x48],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1980:
	/* 0x1980: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1982:
	/* 0x1982: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1982, 0x1a6d, x86_l_1a6d);
x86_l_1988:
	/* 0x1988: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_198c:
	/* 0x198c: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1991:
	/* 0x1991: mov    BYTE PTR [rdx+0x49],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 73ULL);
x86_l_1994:
	/* 0x1994: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1996:
	/* 0x1996: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1996, 0x1a6d, x86_l_1a6d);
x86_l_199c:
	/* 0x199c: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_19a0:
	/* 0x19a0: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19a5:
	/* 0x19a5: mov    BYTE PTR [rdx+0x4a],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 74ULL);
x86_l_19a8:
	/* 0x19a8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19aa:
	/* 0x19aa: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19aa, 0x1a6d, x86_l_1a6d);
x86_l_19b0:
	/* 0x19b0: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_19b4:
	/* 0x19b4: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19b9:
	/* 0x19b9: mov    BYTE PTR [rdx+0x4b],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 75ULL);
x86_l_19bc:
	/* 0x19bc: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19be:
	/* 0x19be: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19be, 0x1a6d, x86_l_1a6d);
x86_l_19c4:
	/* 0x19c4: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19c8:
	/* 0x19c8: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19cd:
	/* 0x19cd: mov    BYTE PTR [rdx+0x4c],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_19d0:
	/* 0x19d0: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19d2:
	/* 0x19d2: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19d2, 0x1a6d, x86_l_1a6d);
x86_l_19d8:
	/* 0x19d8: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_19dc:
	/* 0x19dc: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19e1:
	/* 0x19e1: mov    BYTE PTR [rdx+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_19e4:
	/* 0x19e4: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19e6:
	/* 0x19e6: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e6, 0x1a6d, x86_l_1a6d);
x86_l_19ec:
	/* 0x19ec: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_19f0:
	/* 0x19f0: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19f5:
	/* 0x19f5: mov    BYTE PTR [rdx+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_19f8:
	/* 0x19f8: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19fa:
	/* 0x19fa: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19fa, 0x1a6d, x86_l_1a6d);
x86_l_19fc:
	/* 0x19fc: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_1a00:
	/* 0x1a00: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a05:
	/* 0x1a05: mov    BYTE PTR [rdx+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_1a08:
	/* 0x1a08: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a0a:
	/* 0x1a0a: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a0a, 0x1a6d, x86_l_1a6d);
x86_l_1a0c:
	/* 0x1a0c: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_1a10:
	/* 0x1a10: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a15:
	/* 0x1a15: mov    BYTE PTR [rdx+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1a18:
	/* 0x1a18: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a1a:
	/* 0x1a1a: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a1a, 0x1a6d, x86_l_1a6d);
x86_l_1a1c:
	/* 0x1a1c: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_1a20:
	/* 0x1a20: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a25:
	/* 0x1a25: mov    BYTE PTR [rdx+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_1a28:
	/* 0x1a28: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_1a2a:
	/* 0x1a2a: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a2a, 0x1a6d, x86_l_1a6d);
x86_l_1a2c:
	/* 0x1a2c: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_1a30:
	/* 0x1a30: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a35:
	/* 0x1a35: mov    BYTE PTR [rcx+0x52],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_1a38:
	/* 0x1a38: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1a3a:
	/* 0x1a3a: je     1a6d <trace_utimes_common+0x1a6d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a3a, 0x1a6d, x86_l_1a6d);
x86_l_1a3c:
	/* 0x1a3c: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a41:
	/* 0x1a41: mov    BYTE PTR [rbx+0x53],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 356482285568ULL);
x86_l_1a45:
	/* 0x1a45: mov    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a4a:
	/* 0x1a4a: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a4f:
	/* 0x1a4f: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a52:
	/* 0x1a52: jmp    1a63 <trace_utimes_common+0x1a63> */
	X86_SIM_X86_JMP(0x1a52, 0x1a63, x86_l_1a63);
x86_l_1a54:
	/* 0x1a54: mov    QWORD PTR [rcx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1a5c:
	/* 0x1a5c: mov    QWORD PTR [rcx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a63:
	/* 0x1a63: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a68:
	/* 0x1a68: jmp    22a <trace_utimes_common+0x22a> */
	X86_SIM_X86_JMP(0x1a68, 0x22a, x86_l_22a);
x86_l_1a6d:
	/* 0x1a6d: mov    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a72:
	/* 0x1a72: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a77:
	/* 0x1a77: mov    r12,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1a7a:
	/* 0x1a7a: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1a7f:
	/* 0x1a7f: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a84:
	/* 0x1a84: jmp    22a <trace_utimes_common+0x22a> */
	X86_SIM_X86_JMP(0x1a84, 0x22a, x86_l_22a);
x86_l_1a89:
	/* 0x1a89: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1a8e:
	/* 0x1a8e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a92:
	/* 0x1a92: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1a92, 0x2b12, x86_l_2b12);
x86_l_1a98:
	/* 0x1a98: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a9c:
	/* 0x1a9c: lea    edi,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1aa0:
	/* 0x1aa0: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1aa6:
	/* 0x1aa6: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1aab:
	/* 0x1aab: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1aae:
	/* 0x1aae: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ab3:
	/* 0x1ab3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1ab6:
	/* 0x1ab6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ab9:
	/* 0x1ab9: js     17b2 <trace_utimes_common+0x17b2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1ab9, 0x17b2, x86_l_17b2);
x86_l_1abf:
	/* 0x1abf: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ac1:
	/* 0x1ac1: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ac5:
	/* 0x1ac5: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1ac8:
	/* 0x1ac8: jns    1acf <trace_utimes_common+0x1acf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ac8, 0x1acf, x86_l_1acf);
x86_l_1aca:
	/* 0x1aca: mov    r10,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1acd:
	/* 0x1acd: jmp    1ad2 <trace_utimes_common+0x1ad2> */
	X86_SIM_X86_JMP(0x1acd, 0x1ad2, x86_l_1ad2);
x86_l_1acf:
	/* 0x1acf: xor    r10d,r10d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R10, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ad2:
	/* 0x1ad2: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1ad5:
	/* 0x1ad5: je     1b66 <trace_utimes_common+0x1b66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ad5, 0x1b66, x86_l_1b66);
x86_l_1adb:
	/* 0x1adb: cmp    rdx,r10 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_1ade:
	/* 0x1ade: je     1b66 <trace_utimes_common+0x1b66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ade, 0x1b66, x86_l_1b66);
x86_l_1ae4:
	/* 0x1ae4: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ae8:
	/* 0x1ae8: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1aeb:
	/* 0x1aeb: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1af1:
	/* 0x1af1: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1af4:
	/* 0x1af4: jns    1afd <trace_utimes_common+0x1afd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1af4, 0x1afd, x86_l_1afd);
x86_l_1af6:
	/* 0x1af6: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1af9:
	/* 0x1af9: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1afd:
	/* 0x1afd: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1b01:
	/* 0x1b01: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1b04:
	/* 0x1b04: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1b0b:
	/* 0x1b0b: mov    edi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b0e:
	/* 0x1b0e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1b11:
	/* 0x1b11: jb     2b75 <trace_utimes_common+0x2b75> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b11, 0x2b75, x86_l_2b75);
x86_l_1b17:
	/* 0x1b17: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b1c:
	/* 0x1b1c: mov    QWORD PTR [rsp+0x8],r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R10, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b21:
	/* 0x1b21: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1b24:
	/* 0x1b24: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b24, 0x1178, x86_l_1178);
x86_l_1b2a:
	/* 0x1b2a: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b2e:
	/* 0x1b2e: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1b34:
	/* 0x1b34: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1b37:
	/* 0x1b37: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1b3a:
	/* 0x1b3a: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b3a, 0x2948, x86_l_2948);
x86_l_1b40:
	/* 0x1b40: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1b44:
	/* 0x1b44: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b47:
	/* 0x1b47: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1b4a:
	/* 0x1b4a: je     1bc2 <trace_utimes_common+0x1bc2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b4a, 0x1bc2, x86_l_1bc2);
x86_l_1b4c:
	/* 0x1b4c: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b50:
	/* 0x1b50: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1b55:
	/* 0x1b55: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1b59:
	/* 0x1b59: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1b5c:
	/* 0x1b5c: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1b5f:
	/* 0x1b5f: jne    1b47 <trace_utimes_common+0x1b47> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b5f, 0x1b47, x86_l_1b47);
x86_l_1b61:
	/* 0x1b61: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b64:
	/* 0x1b64: jmp    1bc7 <trace_utimes_common+0x1bc7> */
	X86_SIM_X86_JMP(0x1b64, 0x1bc7, x86_l_1bc7);
x86_l_1b66:
	/* 0x1b66: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1b69:
	/* 0x1b69: jne    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b69, 0x1178, x86_l_1178);
x86_l_1b6f:
	/* 0x1b6f: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b72:
	/* 0x1b72: je     1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b72, 0x1178, x86_l_1178);
x86_l_1b78:
	/* 0x1b78: mov    QWORD PTR [rsp],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b7c:
	/* 0x1b7c: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b80:
	/* 0x1b80: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b83:
	/* 0x1b83: jns    1b8a <trace_utimes_common+0x1b8a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b83, 0x1b8a, x86_l_1b8a);
x86_l_1b85:
	/* 0x1b85: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b88:
	/* 0x1b88: jmp    1b8c <trace_utimes_common+0x1b8c> */
	X86_SIM_X86_JMP(0x1b88, 0x1b8c, x86_l_1b8c);
x86_l_1b8a:
	/* 0x1b8a: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b8c:
	/* 0x1b8c: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b91:
	/* 0x1b91: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b94:
	/* 0x1b94: jns    1b9b <trace_utimes_common+0x1b9b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1b94, 0x1b9b, x86_l_1b9b);
x86_l_1b96:
	/* 0x1b96: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b99:
	/* 0x1b99: jmp    1b9d <trace_utimes_common+0x1b9d> */
	X86_SIM_X86_JMP(0x1b99, 0x1b9d, x86_l_1b9d);
x86_l_1b9b:
	/* 0x1b9b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1b9d:
	/* 0x1b9d: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ba0:
	/* 0x1ba0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ba3:
	/* 0x1ba3: jns    1baa <trace_utimes_common+0x1baa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ba3, 0x1baa, x86_l_1baa);
x86_l_1ba5:
	/* 0x1ba5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ba8:
	/* 0x1ba8: jmp    1bac <trace_utimes_common+0x1bac> */
	X86_SIM_X86_JMP(0x1ba8, 0x1bac, x86_l_1bac);
x86_l_1baa:
	/* 0x1baa: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bac:
	/* 0x1bac: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bb1:
	/* 0x1bb1: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bb5:
	/* 0x1bb5: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bb8:
	/* 0x1bb8: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bbb:
	/* 0x1bbb: jns    1bf2 <trace_utimes_common+0x1bf2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1bbb, 0x1bf2, x86_l_1bf2);
x86_l_1bbd:
	/* 0x1bbd: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bc0:
	/* 0x1bc0: jmp    1bf4 <trace_utimes_common+0x1bf4> */
	X86_SIM_X86_JMP(0x1bc0, 0x1bf4, x86_l_1bf4);
x86_l_1bc2:
	/* 0x1bc2: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1bc7:
	/* 0x1bc7: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1bcb:
	/* 0x1bcb: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1bcb, 0x2b17, x86_l_2b17);
x86_l_1bd1:
	/* 0x1bd1: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bd5:
	/* 0x1bd5: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1bd8:
	/* 0x1bd8: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1bde:
	/* 0x1bde: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1be3:
	/* 0x1be3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1be6:
	/* 0x1be6: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bea:
	/* 0x1bea: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1bed:
	/* 0x1bed: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1bf0:
	/* 0x1bf0: js     1bbd <trace_utimes_common+0x1bbd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1bf0, 0x1bbd, x86_l_1bbd);
x86_l_1bf2:
	/* 0x1bf2: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bf4:
	/* 0x1bf4: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bf9:
	/* 0x1bf9: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bfd:
	/* 0x1bfd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c00:
	/* 0x1c00: jns    1c07 <trace_utimes_common+0x1c07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c00, 0x1c07, x86_l_1c07);
x86_l_1c02:
	/* 0x1c02: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c05:
	/* 0x1c05: jmp    1c09 <trace_utimes_common+0x1c09> */
	X86_SIM_X86_JMP(0x1c05, 0x1c09, x86_l_1c09);
x86_l_1c07:
	/* 0x1c07: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c09:
	/* 0x1c09: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0e:
	/* 0x1c0e: cmp    rcx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c11:
	/* 0x1c11: je     1c8d <trace_utimes_common+0x1c8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c11, 0x1c8d, x86_l_1c8d);
x86_l_1c13:
	/* 0x1c13: cmp    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1c16:
	/* 0x1c16: je     1c8d <trace_utimes_common+0x1c8d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c16, 0x1c8d, x86_l_1c8d);
x86_l_1c18:
	/* 0x1c18: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c1c:
	/* 0x1c1c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c1f:
	/* 0x1c1f: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1c25:
	/* 0x1c25: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c28:
	/* 0x1c28: jns    1c31 <trace_utimes_common+0x1c31> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c28, 0x1c31, x86_l_1c31);
x86_l_1c2a:
	/* 0x1c2a: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c2d:
	/* 0x1c2d: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c31:
	/* 0x1c31: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1c35:
	/* 0x1c35: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1c38:
	/* 0x1c38: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1c3f:
	/* 0x1c3f: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c43:
	/* 0x1c43: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1c46:
	/* 0x1c46: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1c46, 0x2b6c, x86_l_2b6c);
x86_l_1c4c:
	/* 0x1c4c: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1c4f:
	/* 0x1c4f: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4f, 0x2b12, x86_l_2b12);
x86_l_1c55:
	/* 0x1c55: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1c5b:
	/* 0x1c5b: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1c5e:
	/* 0x1c5e: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1c61:
	/* 0x1c61: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c61, 0x294d, x86_l_294d);
x86_l_1c67:
	/* 0x1c67: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1c6b:
	/* 0x1c6b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c6e:
	/* 0x1c6e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1c71:
	/* 0x1c71: je     1ce2 <trace_utimes_common+0x1ce2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c71, 0x1ce2, x86_l_1ce2);
x86_l_1c73:
	/* 0x1c73: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c77:
	/* 0x1c77: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1c7c:
	/* 0x1c7c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1c80:
	/* 0x1c80: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c83:
	/* 0x1c83: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1c86:
	/* 0x1c86: jne    1c6e <trace_utimes_common+0x1c6e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c86, 0x1c6e, x86_l_1c6e);
x86_l_1c88:
	/* 0x1c88: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1c8b:
	/* 0x1c8b: jmp    1ce7 <trace_utimes_common+0x1ce7> */
	X86_SIM_X86_JMP(0x1c8b, 0x1ce7, x86_l_1ce7);
x86_l_1c8d:
	/* 0x1c8d: cmp    rcx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1c90:
	/* 0x1c90: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c90, 0x2b12, x86_l_2b12);
x86_l_1c96:
	/* 0x1c96: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1c9b:
	/* 0x1c9b: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c9b, 0x2b12, x86_l_2b12);
x86_l_1ca1:
	/* 0x1ca1: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ca5:
	/* 0x1ca5: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ca8:
	/* 0x1ca8: jns    1caf <trace_utimes_common+0x1caf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ca8, 0x1caf, x86_l_1caf);
x86_l_1caa:
	/* 0x1caa: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cad:
	/* 0x1cad: jmp    1cb1 <trace_utimes_common+0x1cb1> */
	X86_SIM_X86_JMP(0x1cad, 0x1cb1, x86_l_1cb1);
x86_l_1caf:
	/* 0x1caf: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cb1:
	/* 0x1cb1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cb4:
	/* 0x1cb4: jns    1cbb <trace_utimes_common+0x1cbb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cb4, 0x1cbb, x86_l_1cbb);
x86_l_1cb6:
	/* 0x1cb6: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cb9:
	/* 0x1cb9: jmp    1cbd <trace_utimes_common+0x1cbd> */
	X86_SIM_X86_JMP(0x1cb9, 0x1cbd, x86_l_1cbd);
x86_l_1cbb:
	/* 0x1cbb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cbd:
	/* 0x1cbd: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc0:
	/* 0x1cc0: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1cc3:
	/* 0x1cc3: jns    1cca <trace_utimes_common+0x1cca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cc3, 0x1cca, x86_l_1cca);
x86_l_1cc5:
	/* 0x1cc5: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cc8:
	/* 0x1cc8: jmp    1ccc <trace_utimes_common+0x1ccc> */
	X86_SIM_X86_JMP(0x1cc8, 0x1ccc, x86_l_1ccc);
x86_l_1cca:
	/* 0x1cca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ccc:
	/* 0x1ccc: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cd1:
	/* 0x1cd1: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cd5:
	/* 0x1cd5: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1cd8:
	/* 0x1cd8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1cdb:
	/* 0x1cdb: jns    1d13 <trace_utimes_common+0x1d13> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1cdb, 0x1d13, x86_l_1d13);
x86_l_1cdd:
	/* 0x1cdd: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ce0:
	/* 0x1ce0: jmp    1d15 <trace_utimes_common+0x1d15> */
	X86_SIM_X86_JMP(0x1ce0, 0x1d15, x86_l_1d15);
x86_l_1ce2:
	/* 0x1ce2: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1ce7:
	/* 0x1ce7: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1ceb:
	/* 0x1ceb: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1ceb, 0x2b12, x86_l_2b12);
x86_l_1cf1:
	/* 0x1cf1: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf5:
	/* 0x1cf5: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1cf9:
	/* 0x1cf9: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1cff:
	/* 0x1cff: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1d04:
	/* 0x1d04: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d07:
	/* 0x1d07: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d0b:
	/* 0x1d0b: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d0e:
	/* 0x1d0e: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d11:
	/* 0x1d11: js     1cdd <trace_utimes_common+0x1cdd> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d11, 0x1cdd, x86_l_1cdd);
x86_l_1d13:
	/* 0x1d13: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d15:
	/* 0x1d15: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d19:
	/* 0x1d19: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1d1c:
	/* 0x1d1c: jns    1d23 <trace_utimes_common+0x1d23> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d1c, 0x1d23, x86_l_1d23);
x86_l_1d1e:
	/* 0x1d1e: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d21:
	/* 0x1d21: jmp    1d25 <trace_utimes_common+0x1d25> */
	X86_SIM_X86_JMP(0x1d21, 0x1d25, x86_l_1d25);
x86_l_1d23:
	/* 0x1d23: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d25:
	/* 0x1d25: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d2a:
	/* 0x1d2a: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d2d:
	/* 0x1d2d: je     1daf <trace_utimes_common+0x1daf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d2d, 0x1daf, x86_l_1daf);
x86_l_1d33:
	/* 0x1d33: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_1d38:
	/* 0x1d38: je     1daf <trace_utimes_common+0x1daf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d38, 0x1daf, x86_l_1daf);
x86_l_1d3a:
	/* 0x1d3a: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d3e:
	/* 0x1d3e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d41:
	/* 0x1d41: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d47:
	/* 0x1d47: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d4a:
	/* 0x1d4a: jns    1d53 <trace_utimes_common+0x1d53> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d4a, 0x1d53, x86_l_1d53);
x86_l_1d4c:
	/* 0x1d4c: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d4f:
	/* 0x1d4f: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d53:
	/* 0x1d53: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1d57:
	/* 0x1d57: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1d5a:
	/* 0x1d5a: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1d61:
	/* 0x1d61: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d65:
	/* 0x1d65: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d68:
	/* 0x1d68: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1d68, 0x2b6c, x86_l_2b6c);
x86_l_1d6e:
	/* 0x1d6e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1d71:
	/* 0x1d71: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d71, 0x2b17, x86_l_2b17);
x86_l_1d77:
	/* 0x1d77: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d7d:
	/* 0x1d7d: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d80:
	/* 0x1d80: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1d83:
	/* 0x1d83: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d83, 0x2948, x86_l_2948);
x86_l_1d89:
	/* 0x1d89: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d8d:
	/* 0x1d8d: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d90:
	/* 0x1d90: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1d93:
	/* 0x1d93: je     1e09 <trace_utimes_common+0x1e09> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d93, 0x1e09, x86_l_1e09);
x86_l_1d95:
	/* 0x1d95: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1d99:
	/* 0x1d99: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1d9e:
	/* 0x1d9e: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1da2:
	/* 0x1da2: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1da5:
	/* 0x1da5: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1da8:
	/* 0x1da8: jne    1d90 <trace_utimes_common+0x1d90> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1da8, 0x1d90, x86_l_1d90);
x86_l_1daa:
	/* 0x1daa: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1dad:
	/* 0x1dad: jmp    1e0e <trace_utimes_common+0x1e0e> */
	X86_SIM_X86_JMP(0x1dad, 0x1e0e, x86_l_1e0e);
x86_l_1daf:
	/* 0x1daf: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1db2:
	/* 0x1db2: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1db2, 0x2b17, x86_l_2b17);
x86_l_1db8:
	/* 0x1db8: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1dbd:
	/* 0x1dbd: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1dbd, 0x2b17, x86_l_2b17);
x86_l_1dc3:
	/* 0x1dc3: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dc7:
	/* 0x1dc7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dca:
	/* 0x1dca: jns    1dd1 <trace_utimes_common+0x1dd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dca, 0x1dd1, x86_l_1dd1);
x86_l_1dcc:
	/* 0x1dcc: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dcf:
	/* 0x1dcf: jmp    1dd3 <trace_utimes_common+0x1dd3> */
	X86_SIM_X86_JMP(0x1dcf, 0x1dd3, x86_l_1dd3);
x86_l_1dd1:
	/* 0x1dd1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dd3:
	/* 0x1dd3: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dd8:
	/* 0x1dd8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ddb:
	/* 0x1ddb: jns    1de2 <trace_utimes_common+0x1de2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ddb, 0x1de2, x86_l_1de2);
x86_l_1ddd:
	/* 0x1ddd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1de0:
	/* 0x1de0: jmp    1de4 <trace_utimes_common+0x1de4> */
	X86_SIM_X86_JMP(0x1de0, 0x1de4, x86_l_1de4);
x86_l_1de2:
	/* 0x1de2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de4:
	/* 0x1de4: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1de7:
	/* 0x1de7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1dea:
	/* 0x1dea: jns    1df1 <trace_utimes_common+0x1df1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1dea, 0x1df1, x86_l_1df1);
x86_l_1dec:
	/* 0x1dec: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1def:
	/* 0x1def: jmp    1df3 <trace_utimes_common+0x1df3> */
	X86_SIM_X86_JMP(0x1def, 0x1df3, x86_l_1df3);
x86_l_1df1:
	/* 0x1df1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1df3:
	/* 0x1df3: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1df8:
	/* 0x1df8: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dfc:
	/* 0x1dfc: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1dff:
	/* 0x1dff: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e02:
	/* 0x1e02: jns    1e39 <trace_utimes_common+0x1e39> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e02, 0x1e39, x86_l_1e39);
x86_l_1e04:
	/* 0x1e04: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e07:
	/* 0x1e07: jmp    1e3b <trace_utimes_common+0x1e3b> */
	X86_SIM_X86_JMP(0x1e07, 0x1e3b, x86_l_1e3b);
x86_l_1e09:
	/* 0x1e09: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1e0e:
	/* 0x1e0e: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e12:
	/* 0x1e12: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1e12, 0x2b17, x86_l_2b17);
x86_l_1e18:
	/* 0x1e18: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e1c:
	/* 0x1e1c: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1e1f:
	/* 0x1e1f: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1e25:
	/* 0x1e25: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_1e2a:
	/* 0x1e2a: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e2d:
	/* 0x1e2d: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e31:
	/* 0x1e31: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1e34:
	/* 0x1e34: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e37:
	/* 0x1e37: js     1e04 <trace_utimes_common+0x1e04> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1e37, 0x1e04, x86_l_1e04);
x86_l_1e39:
	/* 0x1e39: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e3b:
	/* 0x1e3b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e40:
	/* 0x1e40: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e44:
	/* 0x1e44: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1e47:
	/* 0x1e47: jns    1e4e <trace_utimes_common+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e47, 0x1e4e, x86_l_1e4e);
x86_l_1e49:
	/* 0x1e49: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e4c:
	/* 0x1e4c: jmp    1e50 <trace_utimes_common+0x1e50> */
	X86_SIM_X86_JMP(0x1e4c, 0x1e50, x86_l_1e50);
x86_l_1e4e:
	/* 0x1e4e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e50:
	/* 0x1e50: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e55:
	/* 0x1e55: je     1edc <trace_utimes_common+0x1edc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e55, 0x1edc, x86_l_1edc);
x86_l_1e5b:
	/* 0x1e5b: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e60:
	/* 0x1e60: je     1edc <trace_utimes_common+0x1edc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e60, 0x1edc, x86_l_1edc);
x86_l_1e62:
	/* 0x1e62: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e67:
	/* 0x1e67: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e6b:
	/* 0x1e6b: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e6e:
	/* 0x1e6e: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1e74:
	/* 0x1e74: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1e77:
	/* 0x1e77: jns    1e80 <trace_utimes_common+0x1e80> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e77, 0x1e80, x86_l_1e80);
x86_l_1e79:
	/* 0x1e79: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e7c:
	/* 0x1e7c: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e80:
	/* 0x1e80: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1e84:
	/* 0x1e84: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1e87:
	/* 0x1e87: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1e8e:
	/* 0x1e8e: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e92:
	/* 0x1e92: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1e95:
	/* 0x1e95: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e95, 0x2b6c, x86_l_2b6c);
x86_l_1e9b:
	/* 0x1e9b: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1e9e:
	/* 0x1e9e: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e9e, 0x2b12, x86_l_2b12);
x86_l_1ea4:
	/* 0x1ea4: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1eaa:
	/* 0x1eaa: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1ead:
	/* 0x1ead: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1eb0:
	/* 0x1eb0: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1eb0, 0x294d, x86_l_294d);
x86_l_1eb6:
	/* 0x1eb6: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1eba:
	/* 0x1eba: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ebd:
	/* 0x1ebd: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1ec0:
	/* 0x1ec0: je     1f33 <trace_utimes_common+0x1f33> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ec0, 0x1f33, x86_l_1f33);
x86_l_1ec2:
	/* 0x1ec2: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ec6:
	/* 0x1ec6: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1ecb:
	/* 0x1ecb: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ecf:
	/* 0x1ecf: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ed2:
	/* 0x1ed2: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1ed5:
	/* 0x1ed5: jne    1ebd <trace_utimes_common+0x1ebd> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ed5, 0x1ebd, x86_l_1ebd);
x86_l_1ed7:
	/* 0x1ed7: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1eda:
	/* 0x1eda: jmp    1f38 <trace_utimes_common+0x1f38> */
	X86_SIM_X86_JMP(0x1eda, 0x1f38, x86_l_1f38);
x86_l_1edc:
	/* 0x1edc: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ee1:
	/* 0x1ee1: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ee1, 0x2b12, x86_l_2b12);
x86_l_1ee7:
	/* 0x1ee7: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1eec:
	/* 0x1eec: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1eec, 0x2b12, x86_l_2b12);
x86_l_1ef2:
	/* 0x1ef2: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ef6:
	/* 0x1ef6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ef9:
	/* 0x1ef9: jns    1f00 <trace_utimes_common+0x1f00> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ef9, 0x1f00, x86_l_1f00);
x86_l_1efb:
	/* 0x1efb: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1efe:
	/* 0x1efe: jmp    1f02 <trace_utimes_common+0x1f02> */
	X86_SIM_X86_JMP(0x1efe, 0x1f02, x86_l_1f02);
x86_l_1f00:
	/* 0x1f00: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f02:
	/* 0x1f02: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f05:
	/* 0x1f05: jns    1f0c <trace_utimes_common+0x1f0c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f05, 0x1f0c, x86_l_1f0c);
x86_l_1f07:
	/* 0x1f07: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f0a:
	/* 0x1f0a: jmp    1f0e <trace_utimes_common+0x1f0e> */
	X86_SIM_X86_JMP(0x1f0a, 0x1f0e, x86_l_1f0e);
x86_l_1f0c:
	/* 0x1f0c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f0e:
	/* 0x1f0e: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f11:
	/* 0x1f11: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1f14:
	/* 0x1f14: jns    1f1b <trace_utimes_common+0x1f1b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f14, 0x1f1b, x86_l_1f1b);
x86_l_1f16:
	/* 0x1f16: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f19:
	/* 0x1f19: jmp    1f1d <trace_utimes_common+0x1f1d> */
	X86_SIM_X86_JMP(0x1f19, 0x1f1d, x86_l_1f1d);
x86_l_1f1b:
	/* 0x1f1b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f1d:
	/* 0x1f1d: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f22:
	/* 0x1f22: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f26:
	/* 0x1f26: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f29:
	/* 0x1f29: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f2c:
	/* 0x1f2c: jns    1f64 <trace_utimes_common+0x1f64> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f2c, 0x1f64, x86_l_1f64);
x86_l_1f2e:
	/* 0x1f2e: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f31:
	/* 0x1f31: jmp    1f66 <trace_utimes_common+0x1f66> */
	X86_SIM_X86_JMP(0x1f31, 0x1f66, x86_l_1f66);
x86_l_1f33:
	/* 0x1f33: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_1f38:
	/* 0x1f38: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1f3c:
	/* 0x1f3c: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f3c, 0x2b12, x86_l_2b12);
x86_l_1f42:
	/* 0x1f42: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f46:
	/* 0x1f46: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f4a:
	/* 0x1f4a: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f50:
	/* 0x1f50: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_1f55:
	/* 0x1f55: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1f58:
	/* 0x1f58: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f5c:
	/* 0x1f5c: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1f5f:
	/* 0x1f5f: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f62:
	/* 0x1f62: js     1f2e <trace_utimes_common+0x1f2e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1f62, 0x1f2e, x86_l_1f2e);
x86_l_1f64:
	/* 0x1f64: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f66:
	/* 0x1f66: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f6a:
	/* 0x1f6a: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_1f6d:
	/* 0x1f6d: jns    1f74 <trace_utimes_common+0x1f74> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f6d, 0x1f74, x86_l_1f74);
x86_l_1f6f:
	/* 0x1f6f: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f72:
	/* 0x1f72: jmp    1f76 <trace_utimes_common+0x1f76> */
	X86_SIM_X86_JMP(0x1f72, 0x1f76, x86_l_1f76);
x86_l_1f74:
	/* 0x1f74: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f76:
	/* 0x1f76: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f7b:
	/* 0x1f7b: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f7e:
	/* 0x1f7e: je     2000 <trace_utimes_common+0x2000> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f7e, 0x2000, x86_l_2000);
x86_l_1f84:
	/* 0x1f84: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_1f89:
	/* 0x1f89: je     2000 <trace_utimes_common+0x2000> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f89, 0x2000, x86_l_2000);
x86_l_1f8b:
	/* 0x1f8b: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f8f:
	/* 0x1f8f: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f92:
	/* 0x1f92: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1f98:
	/* 0x1f98: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1f9b:
	/* 0x1f9b: jns    1fa4 <trace_utimes_common+0x1fa4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1f9b, 0x1fa4, x86_l_1fa4);
x86_l_1f9d:
	/* 0x1f9d: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fa0:
	/* 0x1fa0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fa4:
	/* 0x1fa4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_1fa8:
	/* 0x1fa8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1fab:
	/* 0x1fab: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1fb2:
	/* 0x1fb2: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fb6:
	/* 0x1fb6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1fb9:
	/* 0x1fb9: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1fb9, 0x2b6c, x86_l_2b6c);
x86_l_1fbf:
	/* 0x1fbf: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_1fc2:
	/* 0x1fc2: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc2, 0x2b17, x86_l_2b17);
x86_l_1fc8:
	/* 0x1fc8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1fce:
	/* 0x1fce: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fd1:
	/* 0x1fd1: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_1fd4:
	/* 0x1fd4: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd4, 0x2948, x86_l_2948);
x86_l_1fda:
	/* 0x1fda: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1fde:
	/* 0x1fde: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fe1:
	/* 0x1fe1: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_1fe4:
	/* 0x1fe4: je     205a <trace_utimes_common+0x205a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe4, 0x205a, x86_l_205a);
x86_l_1fe6:
	/* 0x1fe6: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1fea:
	/* 0x1fea: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1fef:
	/* 0x1fef: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_1ff3:
	/* 0x1ff3: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1ff6:
	/* 0x1ff6: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_1ff9:
	/* 0x1ff9: jne    1fe1 <trace_utimes_common+0x1fe1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ff9, 0x1fe1, x86_l_1fe1);
x86_l_1ffb:
	/* 0x1ffb: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ffe:
	/* 0x1ffe: jmp    205f <trace_utimes_common+0x205f> */
	X86_SIM_X86_JMP(0x1ffe, 0x205f, x86_l_205f);
x86_l_2000:
	/* 0x2000: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2003:
	/* 0x2003: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2003, 0x2b17, x86_l_2b17);
x86_l_2009:
	/* 0x2009: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_200e:
	/* 0x200e: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x200e, 0x2b17, x86_l_2b17);
x86_l_2014:
	/* 0x2014: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2018:
	/* 0x2018: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_201b:
	/* 0x201b: jns    2022 <trace_utimes_common+0x2022> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x201b, 0x2022, x86_l_2022);
x86_l_201d:
	/* 0x201d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2020:
	/* 0x2020: jmp    2024 <trace_utimes_common+0x2024> */
	X86_SIM_X86_JMP(0x2020, 0x2024, x86_l_2024);
x86_l_2022:
	/* 0x2022: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2024:
	/* 0x2024: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2029:
	/* 0x2029: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_202c:
	/* 0x202c: jns    2033 <trace_utimes_common+0x2033> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x202c, 0x2033, x86_l_2033);
x86_l_202e:
	/* 0x202e: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2031:
	/* 0x2031: jmp    2035 <trace_utimes_common+0x2035> */
	X86_SIM_X86_JMP(0x2031, 0x2035, x86_l_2035);
x86_l_2033:
	/* 0x2033: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2035:
	/* 0x2035: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2038:
	/* 0x2038: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_203b:
	/* 0x203b: jns    2042 <trace_utimes_common+0x2042> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x203b, 0x2042, x86_l_2042);
x86_l_203d:
	/* 0x203d: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2040:
	/* 0x2040: jmp    2044 <trace_utimes_common+0x2044> */
	X86_SIM_X86_JMP(0x2040, 0x2044, x86_l_2044);
x86_l_2042:
	/* 0x2042: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2044:
	/* 0x2044: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2049:
	/* 0x2049: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_204d:
	/* 0x204d: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2050:
	/* 0x2050: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2053:
	/* 0x2053: jns    208a <trace_utimes_common+0x208a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2053, 0x208a, x86_l_208a);
x86_l_2055:
	/* 0x2055: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2058:
	/* 0x2058: jmp    208c <trace_utimes_common+0x208c> */
	X86_SIM_X86_JMP(0x2058, 0x208c, x86_l_208c);
x86_l_205a:
	/* 0x205a: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_205f:
	/* 0x205f: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2063:
	/* 0x2063: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2063, 0x2b17, x86_l_2b17);
x86_l_2069:
	/* 0x2069: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_206d:
	/* 0x206d: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2070:
	/* 0x2070: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2076:
	/* 0x2076: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_207b:
	/* 0x207b: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_207e:
	/* 0x207e: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2082:
	/* 0x2082: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2085:
	/* 0x2085: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2088:
	/* 0x2088: js     2055 <trace_utimes_common+0x2055> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2088, 0x2055, x86_l_2055);
x86_l_208a:
	/* 0x208a: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_208c:
	/* 0x208c: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2091:
	/* 0x2091: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2095:
	/* 0x2095: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2098:
	/* 0x2098: jns    209f <trace_utimes_common+0x209f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2098, 0x209f, x86_l_209f);
x86_l_209a:
	/* 0x209a: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_209d:
	/* 0x209d: jmp    20a1 <trace_utimes_common+0x20a1> */
	X86_SIM_X86_JMP(0x209d, 0x20a1, x86_l_20a1);
x86_l_209f:
	/* 0x209f: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20a1:
	/* 0x20a1: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20a6:
	/* 0x20a6: je     212d <trace_utimes_common+0x212d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20a6, 0x212d, x86_l_212d);
x86_l_20ac:
	/* 0x20ac: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b1:
	/* 0x20b1: je     212d <trace_utimes_common+0x212d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20b1, 0x212d, x86_l_212d);
x86_l_20b3:
	/* 0x20b3: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b8:
	/* 0x20b8: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20bc:
	/* 0x20bc: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_20bf:
	/* 0x20bf: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_20c5:
	/* 0x20c5: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_20c8:
	/* 0x20c8: jns    20d1 <trace_utimes_common+0x20d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20c8, 0x20d1, x86_l_20d1);
x86_l_20ca:
	/* 0x20ca: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20cd:
	/* 0x20cd: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20d1:
	/* 0x20d1: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_20d5:
	/* 0x20d5: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20d8:
	/* 0x20d8: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20df:
	/* 0x20df: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20e3:
	/* 0x20e3: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_20e6:
	/* 0x20e6: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20e6, 0x2b6c, x86_l_2b6c);
x86_l_20ec:
	/* 0x20ec: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_20ef:
	/* 0x20ef: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20ef, 0x2b12, x86_l_2b12);
x86_l_20f5:
	/* 0x20f5: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_20fb:
	/* 0x20fb: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_20fe:
	/* 0x20fe: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2101:
	/* 0x2101: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2101, 0x294d, x86_l_294d);
x86_l_2107:
	/* 0x2107: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_210b:
	/* 0x210b: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_210e:
	/* 0x210e: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2111:
	/* 0x2111: je     2184 <trace_utimes_common+0x2184> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2111, 0x2184, x86_l_2184);
x86_l_2113:
	/* 0x2113: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2117:
	/* 0x2117: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_211c:
	/* 0x211c: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2120:
	/* 0x2120: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2123:
	/* 0x2123: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2126:
	/* 0x2126: jne    210e <trace_utimes_common+0x210e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2126, 0x210e, x86_l_210e);
x86_l_2128:
	/* 0x2128: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_212b:
	/* 0x212b: jmp    2189 <trace_utimes_common+0x2189> */
	X86_SIM_X86_JMP(0x212b, 0x2189, x86_l_2189);
x86_l_212d:
	/* 0x212d: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2132:
	/* 0x2132: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2132, 0x2b12, x86_l_2b12);
x86_l_2138:
	/* 0x2138: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_213d:
	/* 0x213d: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x213d, 0x2b12, x86_l_2b12);
x86_l_2143:
	/* 0x2143: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2147:
	/* 0x2147: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_214a:
	/* 0x214a: jns    2151 <trace_utimes_common+0x2151> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x214a, 0x2151, x86_l_2151);
x86_l_214c:
	/* 0x214c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_214f:
	/* 0x214f: jmp    2153 <trace_utimes_common+0x2153> */
	X86_SIM_X86_JMP(0x214f, 0x2153, x86_l_2153);
x86_l_2151:
	/* 0x2151: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2153:
	/* 0x2153: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2156:
	/* 0x2156: jns    215d <trace_utimes_common+0x215d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2156, 0x215d, x86_l_215d);
x86_l_2158:
	/* 0x2158: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_215b:
	/* 0x215b: jmp    215f <trace_utimes_common+0x215f> */
	X86_SIM_X86_JMP(0x215b, 0x215f, x86_l_215f);
x86_l_215d:
	/* 0x215d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_215f:
	/* 0x215f: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2162:
	/* 0x2162: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2165:
	/* 0x2165: jns    216c <trace_utimes_common+0x216c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2165, 0x216c, x86_l_216c);
x86_l_2167:
	/* 0x2167: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216a:
	/* 0x216a: jmp    216e <trace_utimes_common+0x216e> */
	X86_SIM_X86_JMP(0x216a, 0x216e, x86_l_216e);
x86_l_216c:
	/* 0x216c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_216e:
	/* 0x216e: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2173:
	/* 0x2173: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2177:
	/* 0x2177: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_217a:
	/* 0x217a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_217d:
	/* 0x217d: jns    21b5 <trace_utimes_common+0x21b5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x217d, 0x21b5, x86_l_21b5);
x86_l_217f:
	/* 0x217f: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2182:
	/* 0x2182: jmp    21b7 <trace_utimes_common+0x21b7> */
	X86_SIM_X86_JMP(0x2182, 0x21b7, x86_l_21b7);
x86_l_2184:
	/* 0x2184: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2189:
	/* 0x2189: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_218d:
	/* 0x218d: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x218d, 0x2b12, x86_l_2b12);
x86_l_2193:
	/* 0x2193: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2197:
	/* 0x2197: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_219b:
	/* 0x219b: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_21a1:
	/* 0x21a1: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_21a6:
	/* 0x21a6: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_21a9:
	/* 0x21a9: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21ad:
	/* 0x21ad: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21b0:
	/* 0x21b0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21b3:
	/* 0x21b3: js     217f <trace_utimes_common+0x217f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21b3, 0x217f, x86_l_217f);
x86_l_21b5:
	/* 0x21b5: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b7:
	/* 0x21b7: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21bb:
	/* 0x21bb: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_21be:
	/* 0x21be: jns    21c5 <trace_utimes_common+0x21c5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21be, 0x21c5, x86_l_21c5);
x86_l_21c0:
	/* 0x21c0: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21c3:
	/* 0x21c3: jmp    21c7 <trace_utimes_common+0x21c7> */
	X86_SIM_X86_JMP(0x21c3, 0x21c7, x86_l_21c7);
x86_l_21c5:
	/* 0x21c5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21c7:
	/* 0x21c7: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21cc:
	/* 0x21cc: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21cf:
	/* 0x21cf: je     2251 <trace_utimes_common+0x2251> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21cf, 0x2251, x86_l_2251);
x86_l_21d5:
	/* 0x21d5: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_21da:
	/* 0x21da: je     2251 <trace_utimes_common+0x2251> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21da, 0x2251, x86_l_2251);
x86_l_21dc:
	/* 0x21dc: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21e0:
	/* 0x21e0: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21e3:
	/* 0x21e3: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_21e9:
	/* 0x21e9: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21ec:
	/* 0x21ec: jns    21f5 <trace_utimes_common+0x21f5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21ec, 0x21f5, x86_l_21f5);
x86_l_21ee:
	/* 0x21ee: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21f1:
	/* 0x21f1: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21f5:
	/* 0x21f5: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_21f9:
	/* 0x21f9: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_21fc:
	/* 0x21fc: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2203:
	/* 0x2203: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2207:
	/* 0x2207: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_220a:
	/* 0x220a: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x220a, 0x2b6c, x86_l_2b6c);
x86_l_2210:
	/* 0x2210: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2213:
	/* 0x2213: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2213, 0x2b17, x86_l_2b17);
x86_l_2219:
	/* 0x2219: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_221f:
	/* 0x221f: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2222:
	/* 0x2222: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2225:
	/* 0x2225: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2225, 0x2948, x86_l_2948);
x86_l_222b:
	/* 0x222b: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_222f:
	/* 0x222f: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2232:
	/* 0x2232: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2235:
	/* 0x2235: je     22ab <trace_utimes_common+0x22ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2235, 0x22ab, x86_l_22ab);
x86_l_2237:
	/* 0x2237: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_223b:
	/* 0x223b: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2240:
	/* 0x2240: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2244:
	/* 0x2244: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2247:
	/* 0x2247: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_224a:
	/* 0x224a: jne    2232 <trace_utimes_common+0x2232> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x224a, 0x2232, x86_l_2232);
x86_l_224c:
	/* 0x224c: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_224f:
	/* 0x224f: jmp    22b0 <trace_utimes_common+0x22b0> */
	X86_SIM_X86_JMP(0x224f, 0x22b0, x86_l_22b0);
x86_l_2251:
	/* 0x2251: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2254:
	/* 0x2254: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2254, 0x2b17, x86_l_2b17);
x86_l_225a:
	/* 0x225a: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_225f:
	/* 0x225f: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x225f, 0x2b17, x86_l_2b17);
x86_l_2265:
	/* 0x2265: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2269:
	/* 0x2269: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_226c:
	/* 0x226c: jns    2273 <trace_utimes_common+0x2273> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x226c, 0x2273, x86_l_2273);
x86_l_226e:
	/* 0x226e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2271:
	/* 0x2271: jmp    2275 <trace_utimes_common+0x2275> */
	X86_SIM_X86_JMP(0x2271, 0x2275, x86_l_2275);
x86_l_2273:
	/* 0x2273: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2275:
	/* 0x2275: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_227a:
	/* 0x227a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_227d:
	/* 0x227d: jns    2284 <trace_utimes_common+0x2284> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x227d, 0x2284, x86_l_2284);
x86_l_227f:
	/* 0x227f: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2282:
	/* 0x2282: jmp    2286 <trace_utimes_common+0x2286> */
	X86_SIM_X86_JMP(0x2282, 0x2286, x86_l_2286);
x86_l_2284:
	/* 0x2284: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2286:
	/* 0x2286: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2289:
	/* 0x2289: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_228c:
	/* 0x228c: jns    2293 <trace_utimes_common+0x2293> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x228c, 0x2293, x86_l_2293);
x86_l_228e:
	/* 0x228e: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2291:
	/* 0x2291: jmp    2295 <trace_utimes_common+0x2295> */
	X86_SIM_X86_JMP(0x2291, 0x2295, x86_l_2295);
x86_l_2293:
	/* 0x2293: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2295:
	/* 0x2295: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_229a:
	/* 0x229a: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_229e:
	/* 0x229e: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22a1:
	/* 0x22a1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22a4:
	/* 0x22a4: jns    22db <trace_utimes_common+0x22db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22a4, 0x22db, x86_l_22db);
x86_l_22a6:
	/* 0x22a6: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22a9:
	/* 0x22a9: jmp    22dd <trace_utimes_common+0x22dd> */
	X86_SIM_X86_JMP(0x22a9, 0x22dd, x86_l_22dd);
x86_l_22ab:
	/* 0x22ab: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_22b0:
	/* 0x22b0: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_22b4:
	/* 0x22b4: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x22b4, 0x2b17, x86_l_2b17);
x86_l_22ba:
	/* 0x22ba: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22be:
	/* 0x22be: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_22c1:
	/* 0x22c1: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_22c7:
	/* 0x22c7: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_22cc:
	/* 0x22cc: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_22cf:
	/* 0x22cf: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22d3:
	/* 0x22d3: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_22d6:
	/* 0x22d6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22d9:
	/* 0x22d9: js     22a6 <trace_utimes_common+0x22a6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x22d9, 0x22a6, x86_l_22a6);
x86_l_22db:
	/* 0x22db: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22dd:
	/* 0x22dd: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e2:
	/* 0x22e2: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e6:
	/* 0x22e6: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_22e9:
	/* 0x22e9: jns    22f0 <trace_utimes_common+0x22f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x22e9, 0x22f0, x86_l_22f0);
x86_l_22eb:
	/* 0x22eb: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ee:
	/* 0x22ee: jmp    22f2 <trace_utimes_common+0x22f2> */
	X86_SIM_X86_JMP(0x22ee, 0x22f2, x86_l_22f2);
x86_l_22f0:
	/* 0x22f0: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22f2:
	/* 0x22f2: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22f7:
	/* 0x22f7: je     237e <trace_utimes_common+0x237e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22f7, 0x237e, x86_l_237e);
x86_l_22fd:
	/* 0x22fd: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2302:
	/* 0x2302: je     237e <trace_utimes_common+0x237e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2302, 0x237e, x86_l_237e);
x86_l_2304:
	/* 0x2304: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2309:
	/* 0x2309: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_230d:
	/* 0x230d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2310:
	/* 0x2310: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2316:
	/* 0x2316: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2319:
	/* 0x2319: jns    2322 <trace_utimes_common+0x2322> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2319, 0x2322, x86_l_2322);
x86_l_231b:
	/* 0x231b: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_231e:
	/* 0x231e: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2322:
	/* 0x2322: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2326:
	/* 0x2326: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2329:
	/* 0x2329: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2330:
	/* 0x2330: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2334:
	/* 0x2334: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2337:
	/* 0x2337: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2337, 0x2b6c, x86_l_2b6c);
x86_l_233d:
	/* 0x233d: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2340:
	/* 0x2340: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2340, 0x2b12, x86_l_2b12);
x86_l_2346:
	/* 0x2346: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_234c:
	/* 0x234c: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_234f:
	/* 0x234f: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2352:
	/* 0x2352: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2352, 0x294d, x86_l_294d);
x86_l_2358:
	/* 0x2358: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_235c:
	/* 0x235c: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_235f:
	/* 0x235f: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2362:
	/* 0x2362: je     23d5 <trace_utimes_common+0x23d5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2362, 0x23d5, x86_l_23d5);
x86_l_2364:
	/* 0x2364: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2368:
	/* 0x2368: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_236d:
	/* 0x236d: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2371:
	/* 0x2371: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2374:
	/* 0x2374: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2377:
	/* 0x2377: jne    235f <trace_utimes_common+0x235f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2377, 0x235f, x86_l_235f);
x86_l_2379:
	/* 0x2379: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_237c:
	/* 0x237c: jmp    23da <trace_utimes_common+0x23da> */
	X86_SIM_X86_JMP(0x237c, 0x23da, x86_l_23da);
x86_l_237e:
	/* 0x237e: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2383:
	/* 0x2383: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2383, 0x2b12, x86_l_2b12);
x86_l_2389:
	/* 0x2389: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_238e:
	/* 0x238e: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x238e, 0x2b12, x86_l_2b12);
x86_l_2394:
	/* 0x2394: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2398:
	/* 0x2398: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_239b:
	/* 0x239b: jns    23a2 <trace_utimes_common+0x23a2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x239b, 0x23a2, x86_l_23a2);
x86_l_239d:
	/* 0x239d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23a0:
	/* 0x23a0: jmp    23a4 <trace_utimes_common+0x23a4> */
	X86_SIM_X86_JMP(0x23a0, 0x23a4, x86_l_23a4);
x86_l_23a2:
	/* 0x23a2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23a4:
	/* 0x23a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23a7:
	/* 0x23a7: jns    23ae <trace_utimes_common+0x23ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23a7, 0x23ae, x86_l_23ae);
x86_l_23a9:
	/* 0x23a9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23ac:
	/* 0x23ac: jmp    23b0 <trace_utimes_common+0x23b0> */
	X86_SIM_X86_JMP(0x23ac, 0x23b0, x86_l_23b0);
x86_l_23ae:
	/* 0x23ae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23b0:
	/* 0x23b0: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23b3:
	/* 0x23b3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23b6:
	/* 0x23b6: jns    23bd <trace_utimes_common+0x23bd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23b6, 0x23bd, x86_l_23bd);
x86_l_23b8:
	/* 0x23b8: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23bb:
	/* 0x23bb: jmp    23bf <trace_utimes_common+0x23bf> */
	X86_SIM_X86_JMP(0x23bb, 0x23bf, x86_l_23bf);
x86_l_23bd:
	/* 0x23bd: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_23bf:
	/* 0x23bf: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23c4:
	/* 0x23c4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23c8:
	/* 0x23c8: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_23cb:
	/* 0x23cb: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_23ce:
	/* 0x23ce: jns    2406 <trace_utimes_common+0x2406> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x23ce, 0x2406, x86_l_2406);
x86_l_23d0:
	/* 0x23d0: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d3:
	/* 0x23d3: jmp    2408 <trace_utimes_common+0x2408> */
	X86_SIM_X86_JMP(0x23d3, 0x2408, x86_l_2408);
x86_l_23d5:
	/* 0x23d5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_23da:
	/* 0x23da: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_23de:
	/* 0x23de: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x23de, 0x2b12, x86_l_2b12);
x86_l_23e4:
	/* 0x23e4: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23e8:
	/* 0x23e8: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23ec:
	/* 0x23ec: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23f2:
	/* 0x23f2: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_23f7:
	/* 0x23f7: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_23fa:
	/* 0x23fa: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fe:
	/* 0x23fe: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2401:
	/* 0x2401: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2404:
	/* 0x2404: js     23d0 <trace_utimes_common+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2404, 0x23d0, x86_l_23d0);
x86_l_2406:
	/* 0x2406: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2408:
	/* 0x2408: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_240c:
	/* 0x240c: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_240f:
	/* 0x240f: jns    2416 <trace_utimes_common+0x2416> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x240f, 0x2416, x86_l_2416);
x86_l_2411:
	/* 0x2411: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2414:
	/* 0x2414: jmp    2418 <trace_utimes_common+0x2418> */
	X86_SIM_X86_JMP(0x2414, 0x2418, x86_l_2418);
x86_l_2416:
	/* 0x2416: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2418:
	/* 0x2418: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_241d:
	/* 0x241d: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2420:
	/* 0x2420: je     24a2 <trace_utimes_common+0x24a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2420, 0x24a2, x86_l_24a2);
x86_l_2426:
	/* 0x2426: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_242b:
	/* 0x242b: je     24a2 <trace_utimes_common+0x24a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x242b, 0x24a2, x86_l_24a2);
x86_l_242d:
	/* 0x242d: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2431:
	/* 0x2431: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2434:
	/* 0x2434: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_243a:
	/* 0x243a: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_243d:
	/* 0x243d: jns    2446 <trace_utimes_common+0x2446> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x243d, 0x2446, x86_l_2446);
x86_l_243f:
	/* 0x243f: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2442:
	/* 0x2442: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2446:
	/* 0x2446: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_244a:
	/* 0x244a: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_244d:
	/* 0x244d: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2454:
	/* 0x2454: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2458:
	/* 0x2458: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_245b:
	/* 0x245b: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x245b, 0x2b6c, x86_l_2b6c);
x86_l_2461:
	/* 0x2461: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2464:
	/* 0x2464: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2464, 0x2b17, x86_l_2b17);
x86_l_246a:
	/* 0x246a: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2470:
	/* 0x2470: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2473:
	/* 0x2473: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_2476:
	/* 0x2476: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2476, 0x2948, x86_l_2948);
x86_l_247c:
	/* 0x247c: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2480:
	/* 0x2480: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2483:
	/* 0x2483: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2486:
	/* 0x2486: je     24fc <trace_utimes_common+0x24fc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2486, 0x24fc, x86_l_24fc);
x86_l_2488:
	/* 0x2488: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_248c:
	/* 0x248c: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2491:
	/* 0x2491: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2495:
	/* 0x2495: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2498:
	/* 0x2498: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_249b:
	/* 0x249b: jne    2483 <trace_utimes_common+0x2483> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x249b, 0x2483, x86_l_2483);
x86_l_249d:
	/* 0x249d: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_24a0:
	/* 0x24a0: jmp    2501 <trace_utimes_common+0x2501> */
	X86_SIM_X86_JMP(0x24a0, 0x2501, x86_l_2501);
x86_l_24a2:
	/* 0x24a2: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_24a5:
	/* 0x24a5: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24a5, 0x2b17, x86_l_2b17);
x86_l_24ab:
	/* 0x24ab: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_24b0:
	/* 0x24b0: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24b0, 0x2b17, x86_l_2b17);
x86_l_24b6:
	/* 0x24b6: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24ba:
	/* 0x24ba: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24bd:
	/* 0x24bd: jns    24c4 <trace_utimes_common+0x24c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24bd, 0x24c4, x86_l_24c4);
x86_l_24bf:
	/* 0x24bf: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c2:
	/* 0x24c2: jmp    24c6 <trace_utimes_common+0x24c6> */
	X86_SIM_X86_JMP(0x24c2, 0x24c6, x86_l_24c6);
x86_l_24c4:
	/* 0x24c4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24c6:
	/* 0x24c6: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24cb:
	/* 0x24cb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24ce:
	/* 0x24ce: jns    24d5 <trace_utimes_common+0x24d5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24ce, 0x24d5, x86_l_24d5);
x86_l_24d0:
	/* 0x24d0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24d3:
	/* 0x24d3: jmp    24d7 <trace_utimes_common+0x24d7> */
	X86_SIM_X86_JMP(0x24d3, 0x24d7, x86_l_24d7);
x86_l_24d5:
	/* 0x24d5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24d7:
	/* 0x24d7: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24da:
	/* 0x24da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24dd:
	/* 0x24dd: jns    24e4 <trace_utimes_common+0x24e4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24dd, 0x24e4, x86_l_24e4);
x86_l_24df:
	/* 0x24df: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e2:
	/* 0x24e2: jmp    24e6 <trace_utimes_common+0x24e6> */
	X86_SIM_X86_JMP(0x24e2, 0x24e6, x86_l_24e6);
x86_l_24e4:
	/* 0x24e4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24e6:
	/* 0x24e6: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24eb:
	/* 0x24eb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24ef:
	/* 0x24ef: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_24f2:
	/* 0x24f2: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_24f5:
	/* 0x24f5: jns    252c <trace_utimes_common+0x252c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24f5, 0x252c, x86_l_252c);
x86_l_24f7:
	/* 0x24f7: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24fa:
	/* 0x24fa: jmp    252e <trace_utimes_common+0x252e> */
	X86_SIM_X86_JMP(0x24fa, 0x252e, x86_l_252e);
x86_l_24fc:
	/* 0x24fc: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2501:
	/* 0x2501: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2505:
	/* 0x2505: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2505, 0x2b17, x86_l_2b17);
x86_l_250b:
	/* 0x250b: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_250f:
	/* 0x250f: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2512:
	/* 0x2512: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2518:
	/* 0x2518: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_251d:
	/* 0x251d: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2520:
	/* 0x2520: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2524:
	/* 0x2524: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2527:
	/* 0x2527: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_252a:
	/* 0x252a: js     24f7 <trace_utimes_common+0x24f7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x252a, 0x24f7, x86_l_24f7);
x86_l_252c:
	/* 0x252c: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_252e:
	/* 0x252e: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2533:
	/* 0x2533: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2537:
	/* 0x2537: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_253a:
	/* 0x253a: jns    2541 <trace_utimes_common+0x2541> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x253a, 0x2541, x86_l_2541);
x86_l_253c:
	/* 0x253c: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_253f:
	/* 0x253f: jmp    2543 <trace_utimes_common+0x2543> */
	X86_SIM_X86_JMP(0x253f, 0x2543, x86_l_2543);
x86_l_2541:
	/* 0x2541: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2543:
	/* 0x2543: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2548:
	/* 0x2548: je     25cf <trace_utimes_common+0x25cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2548, 0x25cf, x86_l_25cf);
x86_l_254e:
	/* 0x254e: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2553:
	/* 0x2553: je     25cf <trace_utimes_common+0x25cf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2553, 0x25cf, x86_l_25cf);
x86_l_2555:
	/* 0x2555: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_255a:
	/* 0x255a: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_255e:
	/* 0x255e: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2561:
	/* 0x2561: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2567:
	/* 0x2567: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_256a:
	/* 0x256a: jns    2573 <trace_utimes_common+0x2573> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x256a, 0x2573, x86_l_2573);
x86_l_256c:
	/* 0x256c: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_256f:
	/* 0x256f: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2573:
	/* 0x2573: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2577:
	/* 0x2577: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_257a:
	/* 0x257a: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2581:
	/* 0x2581: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2585:
	/* 0x2585: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2588:
	/* 0x2588: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2588, 0x2b6c, x86_l_2b6c);
x86_l_258e:
	/* 0x258e: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2591:
	/* 0x2591: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2591, 0x2b12, x86_l_2b12);
x86_l_2597:
	/* 0x2597: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_259d:
	/* 0x259d: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_25a0:
	/* 0x25a0: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_25a3:
	/* 0x25a3: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25a3, 0x294d, x86_l_294d);
x86_l_25a9:
	/* 0x25a9: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_25ad:
	/* 0x25ad: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25b0:
	/* 0x25b0: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_25b3:
	/* 0x25b3: je     2626 <trace_utimes_common+0x2626> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25b3, 0x2626, x86_l_2626);
x86_l_25b5:
	/* 0x25b5: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25b9:
	/* 0x25b9: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_25be:
	/* 0x25be: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_25c2:
	/* 0x25c2: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_25c5:
	/* 0x25c5: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_25c8:
	/* 0x25c8: jne    25b0 <trace_utimes_common+0x25b0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25c8, 0x25b0, x86_l_25b0);
x86_l_25ca:
	/* 0x25ca: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_25cd:
	/* 0x25cd: jmp    262b <trace_utimes_common+0x262b> */
	X86_SIM_X86_JMP(0x25cd, 0x262b, x86_l_262b);
x86_l_25cf:
	/* 0x25cf: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25d4:
	/* 0x25d4: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25d4, 0x2b12, x86_l_2b12);
x86_l_25da:
	/* 0x25da: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_25df:
	/* 0x25df: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25df, 0x2b12, x86_l_2b12);
x86_l_25e5:
	/* 0x25e5: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25e9:
	/* 0x25e9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_25ec:
	/* 0x25ec: jns    25f3 <trace_utimes_common+0x25f3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25ec, 0x25f3, x86_l_25f3);
x86_l_25ee:
	/* 0x25ee: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25f1:
	/* 0x25f1: jmp    25f5 <trace_utimes_common+0x25f5> */
	X86_SIM_X86_JMP(0x25f1, 0x25f5, x86_l_25f5);
x86_l_25f3:
	/* 0x25f3: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_25f5:
	/* 0x25f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25f8:
	/* 0x25f8: jns    25ff <trace_utimes_common+0x25ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25f8, 0x25ff, x86_l_25ff);
x86_l_25fa:
	/* 0x25fa: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25fd:
	/* 0x25fd: jmp    2601 <trace_utimes_common+0x2601> */
	X86_SIM_X86_JMP(0x25fd, 0x2601, x86_l_2601);
x86_l_25ff:
	/* 0x25ff: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2601:
	/* 0x2601: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2604:
	/* 0x2604: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2607:
	/* 0x2607: jns    260e <trace_utimes_common+0x260e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2607, 0x260e, x86_l_260e);
x86_l_2609:
	/* 0x2609: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260c:
	/* 0x260c: jmp    2610 <trace_utimes_common+0x2610> */
	X86_SIM_X86_JMP(0x260c, 0x2610, x86_l_2610);
x86_l_260e:
	/* 0x260e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2610:
	/* 0x2610: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2615:
	/* 0x2615: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2619:
	/* 0x2619: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_261c:
	/* 0x261c: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_261f:
	/* 0x261f: jns    2657 <trace_utimes_common+0x2657> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x261f, 0x2657, x86_l_2657);
x86_l_2621:
	/* 0x2621: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2624:
	/* 0x2624: jmp    2659 <trace_utimes_common+0x2659> */
	X86_SIM_X86_JMP(0x2624, 0x2659, x86_l_2659);
x86_l_2626:
	/* 0x2626: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_262b:
	/* 0x262b: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_262f:
	/* 0x262f: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x262f, 0x2b12, x86_l_2b12);
x86_l_2635:
	/* 0x2635: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2639:
	/* 0x2639: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_263d:
	/* 0x263d: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2643:
	/* 0x2643: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2648:
	/* 0x2648: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_264b:
	/* 0x264b: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_264f:
	/* 0x264f: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2652:
	/* 0x2652: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2655:
	/* 0x2655: js     2621 <trace_utimes_common+0x2621> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2655, 0x2621, x86_l_2621);
x86_l_2657:
	/* 0x2657: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2659:
	/* 0x2659: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_265d:
	/* 0x265d: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_2660:
	/* 0x2660: jns    2667 <trace_utimes_common+0x2667> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2660, 0x2667, x86_l_2667);
x86_l_2662:
	/* 0x2662: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2665:
	/* 0x2665: jmp    2669 <trace_utimes_common+0x2669> */
	X86_SIM_X86_JMP(0x2665, 0x2669, x86_l_2669);
x86_l_2667:
	/* 0x2667: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2669:
	/* 0x2669: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_266e:
	/* 0x266e: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2671:
	/* 0x2671: je     26f3 <trace_utimes_common+0x26f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2671, 0x26f3, x86_l_26f3);
x86_l_2677:
	/* 0x2677: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_267c:
	/* 0x267c: je     26f3 <trace_utimes_common+0x26f3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x267c, 0x26f3, x86_l_26f3);
x86_l_267e:
	/* 0x267e: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2682:
	/* 0x2682: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2685:
	/* 0x2685: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_268b:
	/* 0x268b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_268e:
	/* 0x268e: jns    2697 <trace_utimes_common+0x2697> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x268e, 0x2697, x86_l_2697);
x86_l_2690:
	/* 0x2690: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2693:
	/* 0x2693: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2697:
	/* 0x2697: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_269b:
	/* 0x269b: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_269e:
	/* 0x269e: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_26a5:
	/* 0x26a5: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26a9:
	/* 0x26a9: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_26ac:
	/* 0x26ac: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x26ac, 0x2b6c, x86_l_2b6c);
x86_l_26b2:
	/* 0x26b2: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_26b5:
	/* 0x26b5: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26b5, 0x2b17, x86_l_2b17);
x86_l_26bb:
	/* 0x26bb: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_26c1:
	/* 0x26c1: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26c4:
	/* 0x26c4: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_26c7:
	/* 0x26c7: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x26c7, 0x2948, x86_l_2948);
x86_l_26cd:
	/* 0x26cd: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_26d1:
	/* 0x26d1: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26d4:
	/* 0x26d4: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_26d7:
	/* 0x26d7: je     274d <trace_utimes_common+0x274d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26d7, 0x274d, x86_l_274d);
x86_l_26d9:
	/* 0x26d9: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26dd:
	/* 0x26dd: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_26e2:
	/* 0x26e2: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_26e6:
	/* 0x26e6: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_26e9:
	/* 0x26e9: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_26ec:
	/* 0x26ec: jne    26d4 <trace_utimes_common+0x26d4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26ec, 0x26d4, x86_l_26d4);
x86_l_26ee:
	/* 0x26ee: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_26f1:
	/* 0x26f1: jmp    2752 <trace_utimes_common+0x2752> */
	X86_SIM_X86_JMP(0x26f1, 0x2752, x86_l_2752);
x86_l_26f3:
	/* 0x26f3: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_26f6:
	/* 0x26f6: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26f6, 0x2b17, x86_l_2b17);
x86_l_26fc:
	/* 0x26fc: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2701:
	/* 0x2701: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2701, 0x2b17, x86_l_2b17);
x86_l_2707:
	/* 0x2707: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_270b:
	/* 0x270b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_270e:
	/* 0x270e: jns    2715 <trace_utimes_common+0x2715> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x270e, 0x2715, x86_l_2715);
x86_l_2710:
	/* 0x2710: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2713:
	/* 0x2713: jmp    2717 <trace_utimes_common+0x2717> */
	X86_SIM_X86_JMP(0x2713, 0x2717, x86_l_2717);
x86_l_2715:
	/* 0x2715: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2717:
	/* 0x2717: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_271c:
	/* 0x271c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271f:
	/* 0x271f: jns    2726 <trace_utimes_common+0x2726> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x271f, 0x2726, x86_l_2726);
x86_l_2721:
	/* 0x2721: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2724:
	/* 0x2724: jmp    2728 <trace_utimes_common+0x2728> */
	X86_SIM_X86_JMP(0x2724, 0x2728, x86_l_2728);
x86_l_2726:
	/* 0x2726: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2728:
	/* 0x2728: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_272b:
	/* 0x272b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_272e:
	/* 0x272e: jns    2735 <trace_utimes_common+0x2735> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x272e, 0x2735, x86_l_2735);
x86_l_2730:
	/* 0x2730: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2733:
	/* 0x2733: jmp    2737 <trace_utimes_common+0x2737> */
	X86_SIM_X86_JMP(0x2733, 0x2737, x86_l_2737);
x86_l_2735:
	/* 0x2735: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2737:
	/* 0x2737: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_273c:
	/* 0x273c: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2740:
	/* 0x2740: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2743:
	/* 0x2743: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2746:
	/* 0x2746: jns    277d <trace_utimes_common+0x277d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2746, 0x277d, x86_l_277d);
x86_l_2748:
	/* 0x2748: mov    rdi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_274b:
	/* 0x274b: jmp    277f <trace_utimes_common+0x277f> */
	X86_SIM_X86_JMP(0x274b, 0x277f, x86_l_277f);
x86_l_274d:
	/* 0x274d: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2752:
	/* 0x2752: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2756:
	/* 0x2756: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2756, 0x2b17, x86_l_2b17);
x86_l_275c:
	/* 0x275c: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2760:
	/* 0x2760: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2763:
	/* 0x2763: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2769:
	/* 0x2769: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_276e:
	/* 0x276e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2771:
	/* 0x2771: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2775:
	/* 0x2775: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2778:
	/* 0x2778: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_277b:
	/* 0x277b: js     2748 <trace_utimes_common+0x2748> */
	X86_SIM_X86_JCC(X86_CC_S, 0x277b, 0x2748, x86_l_2748);
x86_l_277d:
	/* 0x277d: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_277f:
	/* 0x277f: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2784:
	/* 0x2784: lea    rdx,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2788:
	/* 0x2788: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_278b:
	/* 0x278b: jns    2792 <trace_utimes_common+0x2792> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x278b, 0x2792, x86_l_2792);
x86_l_278d:
	/* 0x278d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2790:
	/* 0x2790: jmp    2794 <trace_utimes_common+0x2794> */
	X86_SIM_X86_JMP(0x2790, 0x2794, x86_l_2794);
x86_l_2792:
	/* 0x2792: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2794:
	/* 0x2794: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2799:
	/* 0x2799: je     2820 <trace_utimes_common+0x2820> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2799, 0x2820, x86_l_2820);
x86_l_279f:
	/* 0x279f: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27a4:
	/* 0x27a4: je     2820 <trace_utimes_common+0x2820> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a4, 0x2820, x86_l_2820);
x86_l_27a6:
	/* 0x27a6: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27ab:
	/* 0x27ab: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27af:
	/* 0x27af: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_27b2:
	/* 0x27b2: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_27b8:
	/* 0x27b8: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_27bb:
	/* 0x27bb: jns    27c4 <trace_utimes_common+0x27c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27bb, 0x27c4, x86_l_27c4);
x86_l_27bd:
	/* 0x27bd: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27c0:
	/* 0x27c0: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27c4:
	/* 0x27c4: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_27c8:
	/* 0x27c8: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_27cb:
	/* 0x27cb: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_27d2:
	/* 0x27d2: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d6:
	/* 0x27d6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_27d9:
	/* 0x27d9: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27d9, 0x2b6c, x86_l_2b6c);
x86_l_27df:
	/* 0x27df: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_27e2:
	/* 0x27e2: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27e2, 0x2b12, x86_l_2b12);
x86_l_27e8:
	/* 0x27e8: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27ee:
	/* 0x27ee: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_27f1:
	/* 0x27f1: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_27f4:
	/* 0x27f4: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x27f4, 0x294d, x86_l_294d);
x86_l_27fa:
	/* 0x27fa: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27fe:
	/* 0x27fe: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2801:
	/* 0x2801: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2804:
	/* 0x2804: je     2877 <trace_utimes_common+0x2877> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2804, 0x2877, x86_l_2877);
x86_l_2806:
	/* 0x2806: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_280a:
	/* 0x280a: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_280f:
	/* 0x280f: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2813:
	/* 0x2813: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2816:
	/* 0x2816: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2819:
	/* 0x2819: jne    2801 <trace_utimes_common+0x2801> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2819, 0x2801, x86_l_2801);
x86_l_281b:
	/* 0x281b: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_281e:
	/* 0x281e: jmp    287c <trace_utimes_common+0x287c> */
	X86_SIM_X86_JMP(0x281e, 0x287c, x86_l_287c);
x86_l_2820:
	/* 0x2820: cmp    QWORD PTR [rsp+0x8],rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2825:
	/* 0x2825: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2825, 0x2b12, x86_l_2b12);
x86_l_282b:
	/* 0x282b: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2830:
	/* 0x2830: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2830, 0x2b12, x86_l_2b12);
x86_l_2836:
	/* 0x2836: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_283a:
	/* 0x283a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_283d:
	/* 0x283d: jns    2844 <trace_utimes_common+0x2844> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x283d, 0x2844, x86_l_2844);
x86_l_283f:
	/* 0x283f: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2842:
	/* 0x2842: jmp    2846 <trace_utimes_common+0x2846> */
	X86_SIM_X86_JMP(0x2842, 0x2846, x86_l_2846);
x86_l_2844:
	/* 0x2844: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2846:
	/* 0x2846: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2849:
	/* 0x2849: jns    2850 <trace_utimes_common+0x2850> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2849, 0x2850, x86_l_2850);
x86_l_284b:
	/* 0x284b: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_284e:
	/* 0x284e: jmp    2852 <trace_utimes_common+0x2852> */
	X86_SIM_X86_JMP(0x284e, 0x2852, x86_l_2852);
x86_l_2850:
	/* 0x2850: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2852:
	/* 0x2852: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2855:
	/* 0x2855: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2858:
	/* 0x2858: jns    285f <trace_utimes_common+0x285f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2858, 0x285f, x86_l_285f);
x86_l_285a:
	/* 0x285a: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_285d:
	/* 0x285d: jmp    2861 <trace_utimes_common+0x2861> */
	X86_SIM_X86_JMP(0x285d, 0x2861, x86_l_2861);
x86_l_285f:
	/* 0x285f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2861:
	/* 0x2861: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2866:
	/* 0x2866: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_286a:
	/* 0x286a: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_286d:
	/* 0x286d: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2870:
	/* 0x2870: jns    28a8 <trace_utimes_common+0x28a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2870, 0x28a8, x86_l_28a8);
x86_l_2872:
	/* 0x2872: mov    rdi,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2875:
	/* 0x2875: jmp    28aa <trace_utimes_common+0x28aa> */
	X86_SIM_X86_JMP(0x2875, 0x28aa, x86_l_28aa);
x86_l_2877:
	/* 0x2877: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_287c:
	/* 0x287c: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2880:
	/* 0x2880: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2880, 0x2b12, x86_l_2b12);
x86_l_2886:
	/* 0x2886: mov    r9,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_288a:
	/* 0x288a: lea    edi,[r9-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_288e:
	/* 0x288e: and    edi,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2894:
	/* 0x2894: mov    BYTE PTR [rbp+rdi*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDI, 0), 47ULL);
x86_l_2899:
	/* 0x2899: sub    r9d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_289c:
	/* 0x289c: mov    QWORD PTR [rsp],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28a0:
	/* 0x28a0: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_28a3:
	/* 0x28a3: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28a6:
	/* 0x28a6: js     2872 <trace_utimes_common+0x2872> */
	X86_SIM_X86_JCC(X86_CC_S, 0x28a6, 0x2872, x86_l_2872);
x86_l_28a8:
	/* 0x28a8: xor    edi,edi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28aa:
	/* 0x28aa: lea    r8,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28ae:
	/* 0x28ae: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_28b1:
	/* 0x28b1: jns    28b8 <trace_utimes_common+0x28b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28b1, 0x28b8, x86_l_28b8);
x86_l_28b3:
	/* 0x28b3: mov    rcx,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28b6:
	/* 0x28b6: jmp    28ba <trace_utimes_common+0x28ba> */
	X86_SIM_X86_JMP(0x28b6, 0x28ba, x86_l_28ba);
x86_l_28b8:
	/* 0x28b8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ba:
	/* 0x28ba: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28bf:
	/* 0x28bf: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28c2:
	/* 0x28c2: je     295b <trace_utimes_common+0x295b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c2, 0x295b, x86_l_295b);
x86_l_28c8:
	/* 0x28c8: cmp    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 8ULL);
x86_l_28cd:
	/* 0x28cd: je     295b <trace_utimes_common+0x295b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28cd, 0x295b, x86_l_295b);
x86_l_28d3:
	/* 0x28d3: lea    rdi,[rdx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28d7:
	/* 0x28d7: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28da:
	/* 0x28da: mov    r9d,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_28e0:
	/* 0x28e0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_28e3:
	/* 0x28e3: jns    28ec <trace_utimes_common+0x28ec> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x28e3, 0x28ec, x86_l_28ec);
x86_l_28e5:
	/* 0x28e5: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28e8:
	/* 0x28e8: mov    r9,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28ec:
	/* 0x28ec: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_28f0:
	/* 0x28f0: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28f3:
	/* 0x28f3: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28fa:
	/* 0x28fa: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28fe:
	/* 0x28fe: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2901:
	/* 0x2901: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2901, 0x2b6c, x86_l_2b6c);
x86_l_2907:
	/* 0x2907: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_290a:
	/* 0x290a: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x290a, 0x2b17, x86_l_2b17);
x86_l_2910:
	/* 0x2910: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2916:
	/* 0x2916: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2919:
	/* 0x2919: test   r9,r9 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_291c:
	/* 0x291c: jns    2948 <trace_utimes_common+0x2948> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x291c, 0x2948, x86_l_2948);
x86_l_291e:
	/* 0x291e: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2922:
	/* 0x2922: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2925:
	/* 0x2925: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2928:
	/* 0x2928: je     29b5 <trace_utimes_common+0x29b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2928, 0x29b5, x86_l_29b5);
x86_l_292e:
	/* 0x292e: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2932:
	/* 0x2932: movzx  r12d,BYTE PTR [r9+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2937:
	/* 0x2937: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_293b:
	/* 0x293b: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_293e:
	/* 0x293e: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2941:
	/* 0x2941: jne    2925 <trace_utimes_common+0x2925> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2941, 0x2925, x86_l_2925);
x86_l_2943:
	/* 0x2943: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2946:
	/* 0x2946: jmp    29ba <trace_utimes_common+0x29ba> */
	X86_SIM_X86_JMP(0x2946, 0x29ba, x86_l_29ba);
x86_l_2948:
	/* 0x2948: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_294d:
	/* 0x294d: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2952:
	/* 0x2952: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2956:
	/* 0x2956: jmp    1169 <trace_utimes_common+0x1169> */
	X86_SIM_X86_JMP(0x2956, 0x1169, x86_l_1169);
x86_l_295b:
	/* 0x295b: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_295e:
	/* 0x295e: jne    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x295e, 0x2b17, x86_l_2b17);
x86_l_2964:
	/* 0x2964: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2969:
	/* 0x2969: je     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2969, 0x2b17, x86_l_2b17);
x86_l_296f:
	/* 0x296f: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2973:
	/* 0x2973: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2976:
	/* 0x2976: jns    297d <trace_utimes_common+0x297d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2976, 0x297d, x86_l_297d);
x86_l_2978:
	/* 0x2978: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_297b:
	/* 0x297b: jmp    297f <trace_utimes_common+0x297f> */
	X86_SIM_X86_JMP(0x297b, 0x297f, x86_l_297f);
x86_l_297d:
	/* 0x297d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_297f:
	/* 0x297f: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2984:
	/* 0x2984: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2987:
	/* 0x2987: jns    298e <trace_utimes_common+0x298e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2987, 0x298e, x86_l_298e);
x86_l_2989:
	/* 0x2989: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_298c:
	/* 0x298c: jmp    2990 <trace_utimes_common+0x2990> */
	X86_SIM_X86_JMP(0x298c, 0x2990, x86_l_2990);
x86_l_298e:
	/* 0x298e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2990:
	/* 0x2990: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2993:
	/* 0x2993: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2996:
	/* 0x2996: jns    299d <trace_utimes_common+0x299d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2996, 0x299d, x86_l_299d);
x86_l_2998:
	/* 0x2998: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_299b:
	/* 0x299b: jmp    299f <trace_utimes_common+0x299f> */
	X86_SIM_X86_JMP(0x299b, 0x299f, x86_l_299f);
x86_l_299d:
	/* 0x299d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_299f:
	/* 0x299f: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29a4:
	/* 0x29a4: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29a8:
	/* 0x29a8: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29ab:
	/* 0x29ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29ae:
	/* 0x29ae: jns    29e5 <trace_utimes_common+0x29e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29ae, 0x29e5, x86_l_29e5);
x86_l_29b0:
	/* 0x29b0: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b3:
	/* 0x29b3: jmp    29e7 <trace_utimes_common+0x29e7> */
	X86_SIM_X86_JMP(0x29b3, 0x29e7, x86_l_29e7);
x86_l_29b5:
	/* 0x29b5: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_29ba:
	/* 0x29ba: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_29be:
	/* 0x29be: jl     2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_L, 0x29be, 0x2b17, x86_l_2b17);
x86_l_29c4:
	/* 0x29c4: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c8:
	/* 0x29c8: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_29cb:
	/* 0x29cb: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_29d1:
	/* 0x29d1: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_29d6:
	/* 0x29d6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_29d9:
	/* 0x29d9: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29dd:
	/* 0x29dd: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_29e0:
	/* 0x29e0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29e3:
	/* 0x29e3: js     29b0 <trace_utimes_common+0x29b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x29e3, 0x29b0, x86_l_29b0);
x86_l_29e5:
	/* 0x29e5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29e7:
	/* 0x29e7: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29ec:
	/* 0x29ec: lea    rdi,[rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_29f0:
	/* 0x29f0: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_29f3:
	/* 0x29f3: jns    29fa <trace_utimes_common+0x29fa> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29f3, 0x29fa, x86_l_29fa);
x86_l_29f5:
	/* 0x29f5: mov    r9,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f8:
	/* 0x29f8: jmp    29fd <trace_utimes_common+0x29fd> */
	X86_SIM_X86_JMP(0x29f8, 0x29fd, x86_l_29fd);
x86_l_29fa:
	/* 0x29fa: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29fd:
	/* 0x29fd: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a02:
	/* 0x2a02: je     2a88 <trace_utimes_common+0x2a88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a02, 0x2a88, x86_l_2a88);
x86_l_2a08:
	/* 0x2a08: cmp    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a0d:
	/* 0x2a0d: je     2a88 <trace_utimes_common+0x2a88> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a0d, 0x2a88, x86_l_2a88);
x86_l_2a0f:
	/* 0x2a0f: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a14:
	/* 0x2a14: lea    rdi,[rcx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a18:
	/* 0x2a18: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a1b:
	/* 0x2a1b: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2a20:
	/* 0x2a20: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2a23:
	/* 0x2a23: jns    2a2c <trace_utimes_common+0x2a2c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a23, 0x2a2c, x86_l_2a2c);
x86_l_2a25:
	/* 0x2a25: mov    r8,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a28:
	/* 0x2a28: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a2c:
	/* 0x2a2c: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2a30:
	/* 0x2a30: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a33:
	/* 0x2a33: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a3a:
	/* 0x2a3a: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a3e:
	/* 0x2a3e: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2a41:
	/* 0x2a41: jb     2b6c <trace_utimes_common+0x2b6c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a41, 0x2b6c, x86_l_2b6c);
x86_l_2a47:
	/* 0x2a47: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_2a4a:
	/* 0x2a4a: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a4a, 0x2b12, x86_l_2b12);
x86_l_2a50:
	/* 0x2a50: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a56:
	/* 0x2a56: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2a59:
	/* 0x2a59: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2a5c:
	/* 0x2a5c: jns    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2a5c, 0x294d, x86_l_294d);
x86_l_2a62:
	/* 0x2a62: lea    r10d,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a66:
	/* 0x2a66: xor    r11d,r11d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R11, X86_R11, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a69:
	/* 0x2a69: cmp    r10,r11 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R10, X86_R11, X86_WIDTH_64, 0, 0);
x86_l_2a6c:
	/* 0x2a6c: je     2ad9 <trace_utimes_common+0x2ad9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a6c, 0x2ad9, x86_l_2ad9);
x86_l_2a6e:
	/* 0x2a6e: lea    r14,[r11+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R11, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a72:
	/* 0x2a72: movzx  r12d,BYTE PTR [rdx+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_2a77:
	/* 0x2a77: mov    BYTE PTR [rdi+r11*1],r12b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R12, X86_WIDTH_8, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_2a7b:
	/* 0x2a7b: mov    r11,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R11, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2a7e:
	/* 0x2a7e: test   r12b,r12b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_8, 0, 0);
x86_l_2a81:
	/* 0x2a81: jne    2a69 <trace_utimes_common+0x2a69> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a81, 0x2a69, x86_l_2a69);
x86_l_2a83:
	/* 0x2a83: mov    r8d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2a86:
	/* 0x2a86: jmp    2ade <trace_utimes_common+0x2ade> */
	X86_SIM_X86_JMP(0x2a86, 0x2ade, x86_l_2ade);
x86_l_2a88:
	/* 0x2a88: cmp    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a8d:
	/* 0x2a8d: jne    2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a8d, 0x2b12, x86_l_2b12);
x86_l_2a93:
	/* 0x2a93: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2a98:
	/* 0x2a98: je     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a98, 0x2b12, x86_l_2b12);
x86_l_2a9a:
	/* 0x2a9a: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a9e:
	/* 0x2a9e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2aa1:
	/* 0x2aa1: jns    2aa8 <trace_utimes_common+0x2aa8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aa1, 0x2aa8, x86_l_2aa8);
x86_l_2aa3:
	/* 0x2aa3: mov    r9,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2aa6:
	/* 0x2aa6: jmp    2aab <trace_utimes_common+0x2aab> */
	X86_SIM_X86_JMP(0x2aa6, 0x2aab, x86_l_2aab);
x86_l_2aa8:
	/* 0x2aa8: xor    r9d,r9d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R9, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2aab:
	/* 0x2aab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aae:
	/* 0x2aae: jns    2ab5 <trace_utimes_common+0x2ab5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2aae, 0x2ab5, x86_l_2ab5);
x86_l_2ab0:
	/* 0x2ab0: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab3:
	/* 0x2ab3: jmp    2ab7 <trace_utimes_common+0x2ab7> */
	X86_SIM_X86_JMP(0x2ab3, 0x2ab7, x86_l_2ab7);
x86_l_2ab5:
	/* 0x2ab5: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ab7:
	/* 0x2ab7: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aba:
	/* 0x2aba: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2abd:
	/* 0x2abd: jns    2ac4 <trace_utimes_common+0x2ac4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2abd, 0x2ac4, x86_l_2ac4);
x86_l_2abf:
	/* 0x2abf: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ac2:
	/* 0x2ac2: jmp    2ac6 <trace_utimes_common+0x2ac6> */
	X86_SIM_X86_JMP(0x2ac2, 0x2ac6, x86_l_2ac6);
x86_l_2ac4:
	/* 0x2ac4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ac6:
	/* 0x2ac6: mov    QWORD PTR [rsp+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2acb:
	/* 0x2acb: lea    rsi,[rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2acf:
	/* 0x2acf: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2ad2:
	/* 0x2ad2: jns    2b02 <trace_utimes_common+0x2b02> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ad2, 0x2b02, x86_l_2b02);
x86_l_2ad4:
	/* 0x2ad4: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad7:
	/* 0x2ad7: jmp    2b04 <trace_utimes_common+0x2b04> */
	X86_SIM_X86_JMP(0x2ad7, 0x2b04, x86_l_2b04);
x86_l_2ad9:
	/* 0x2ad9: mov    BYTE PTR [rdi+r10*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_R10, 0), 0ULL);
x86_l_2ade:
	/* 0x2ade: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2ae2:
	/* 0x2ae2: jl     2b12 <trace_utimes_common+0x2b12> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ae2, 0x2b12, x86_l_2b12);
x86_l_2ae4:
	/* 0x2ae4: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae8:
	/* 0x2ae8: lea    edx,[rdi-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2aeb:
	/* 0x2aeb: and    edx,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2af1:
	/* 0x2af1: mov    BYTE PTR [rbp+rdx*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RDX, 0), 47ULL);
x86_l_2af6:
	/* 0x2af6: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2af9:
	/* 0x2af9: mov    QWORD PTR [rsp],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2afd:
	/* 0x2afd: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b00:
	/* 0x2b00: js     2ad4 <trace_utimes_common+0x2ad4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2b00, 0x2ad4, x86_l_2ad4);
x86_l_2b02:
	/* 0x2b02: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b04:
	/* 0x2b04: lea    rdx,[r9+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b08:
	/* 0x2b08: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b0b:
	/* 0x2b0b: jns    2b25 <trace_utimes_common+0x2b25> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b0b, 0x2b25, x86_l_2b25);
x86_l_2b0d:
	/* 0x2b0d: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b10:
	/* 0x2b10: jmp    2b27 <trace_utimes_common+0x2b27> */
	X86_SIM_X86_JMP(0x2b10, 0x2b27, x86_l_2b27);
x86_l_2b12:
	/* 0x2b12: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b17:
	/* 0x2b17: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b1c:
	/* 0x2b1c: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b20:
	/* 0x2b20: jmp    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JMP(0x2b20, 0x1178, x86_l_1178);
x86_l_2b25:
	/* 0x2b25: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b27:
	/* 0x2b27: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2b2a:
	/* 0x2b2a: je     34ff <trace_utimes_common+0x34ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b2a, 0x34ff, x86_l_34ff);
x86_l_2b30:
	/* 0x2b30: cmp    r9,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2b33:
	/* 0x2b33: je     34ff <trace_utimes_common+0x34ff> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b33, 0x34ff, x86_l_34ff);
x86_l_2b39:
	/* 0x2b39: lea    rcx,[r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b3d:
	/* 0x2b3d: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2b40:
	/* 0x2b40: mov    eax,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2b45:
	/* 0x2b45: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2b48:
	/* 0x2b48: jns    2b51 <trace_utimes_common+0x2b51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b48, 0x2b51, x86_l_2b51);
x86_l_2b4a:
	/* 0x2b4a: mov    r8,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b4d:
	/* 0x2b4d: mov    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b51:
	/* 0x2b51: shr    r8,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_2b55:
	/* 0x2b55: inc    r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2b58:
	/* 0x2b58: and    r8d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2b5f:
	/* 0x2b5f: mov    rdi,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b63:
	/* 0x2b63: sub    edi,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2b66:
	/* 0x2b66: jae    3521 <trace_utimes_common+0x3521> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b66, 0x3521, x86_l_3521);
x86_l_2b6c:
	/* 0x2b6c: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b71:
	/* 0x2b71: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b75:
	/* 0x2b75: dec    r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2b78:
	/* 0x2b78: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2b7b:
	/* 0x2b7b: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2b80:
	/* 0x2b80: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_2b85:
	/* 0x2b85: mov    BYTE PTR [rbp+0x3fff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_2b8c:
	/* 0x2b8c: and    r14d,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2b93:
	/* 0x2b93: add    rbp,r14 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_R14, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b96:
	/* 0x2b96: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2b9a:
	/* 0x2b9a: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2b9d:
	/* 0x2b9d: jns    c9a <trace_utimes_common+0xc9a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b9d, 0xc9a, x86_l_c9a);
x86_l_2ba3:
	/* 0x2ba3: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ba6:
	/* 0x2ba6: add    rax,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2baa:
	/* 0x2baa: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bad:
	/* 0x2bad: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bb0:
	/* 0x2bb0: jns    2bce <trace_utimes_common+0x2bce> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bb0, 0x2bce, x86_l_2bce);
x86_l_2bb2:
	/* 0x2bb2: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bb5:
	/* 0x2bb5: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2bb9:
	/* 0x2bb9: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bbc:
	/* 0x2bbc: js     2bd9 <trace_utimes_common+0x2bd9> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bbc, 0x2bd9, x86_l_2bd9);
x86_l_2bbe:
	/* 0x2bbe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bc0:
	/* 0x2bc0: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2bc5:
	/* 0x2bc5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bc8:
	/* 0x2bc8: js     2be6 <trace_utimes_common+0x2be6> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bc8, 0x2be6, x86_l_2be6);
x86_l_2bca:
	/* 0x2bca: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bcc:
	/* 0x2bcc: jmp    2be9 <trace_utimes_common+0x2be9> */
	X86_SIM_X86_JMP(0x2bcc, 0x2be9, x86_l_2be9);
x86_l_2bce:
	/* 0x2bce: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bd0:
	/* 0x2bd0: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2bd4:
	/* 0x2bd4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bd7:
	/* 0x2bd7: jns    2bbe <trace_utimes_common+0x2bbe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bd7, 0x2bbe, x86_l_2bbe);
x86_l_2bd9:
	/* 0x2bd9: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bdc:
	/* 0x2bdc: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2be1:
	/* 0x2be1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2be4:
	/* 0x2be4: jns    2bca <trace_utimes_common+0x2bca> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2be4, 0x2bca, x86_l_2bca);
x86_l_2be6:
	/* 0x2be6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2be9:
	/* 0x2be9: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2bed:
	/* 0x2bed: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bef:
	/* 0x2bef: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bf2:
	/* 0x2bf2: jns    2bfe <trace_utimes_common+0x2bfe> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2bf2, 0x2bfe, x86_l_2bfe);
x86_l_2bf4:
	/* 0x2bf4: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2bf7:
	/* 0x2bf7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2bfa:
	/* 0x2bfa: js     2c05 <trace_utimes_common+0x2c05> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2bfa, 0x2c05, x86_l_2c05);
x86_l_2bfc:
	/* 0x2bfc: jmp    2c07 <trace_utimes_common+0x2c07> */
	X86_SIM_X86_JMP(0x2bfc, 0x2c07, x86_l_2c07);
x86_l_2bfe:
	/* 0x2bfe: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c00:
	/* 0x2c00: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c03:
	/* 0x2c03: jns    2c07 <trace_utimes_common+0x2c07> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c03, 0x2c07, x86_l_2c07);
x86_l_2c05:
	/* 0x2c05: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c07:
	/* 0x2c07: mov    DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_2c0b:
	/* 0x2c0b: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c0e:
	/* 0x2c0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c11:
	/* 0x2c11: jns    2c2d <trace_utimes_common+0x2c2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c11, 0x2c2d, x86_l_2c2d);
x86_l_2c13:
	/* 0x2c13: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c16:
	/* 0x2c16: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c19:
	/* 0x2c19: js     2d06 <trace_utimes_common+0x2d06> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c19, 0x2d06, x86_l_2d06);
x86_l_2c1f:
	/* 0x2c1f: lea    rcx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c23:
	/* 0x2c23: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c26:
	/* 0x2c26: jns    2c38 <trace_utimes_common+0x2c38> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c26, 0x2c38, x86_l_2c38);
x86_l_2c28:
	/* 0x2c28: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c2b:
	/* 0x2c2b: jmp    2c3a <trace_utimes_common+0x2c3a> */
	X86_SIM_X86_JMP(0x2c2b, 0x2c3a, x86_l_2c3a);
x86_l_2c2d:
	/* 0x2c2d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c2f:
	/* 0x2c2f: lea    rcx,[rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c33:
	/* 0x2c33: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c36:
	/* 0x2c36: js     2c28 <trace_utimes_common+0x2c28> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c36, 0x2c28, x86_l_2c28);
x86_l_2c38:
	/* 0x2c38: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c3a:
	/* 0x2c3a: imul   rax,rax,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_2c41:
	/* 0x2c41: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c44:
	/* 0x2c44: mov    QWORD PTR [rsp+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2c49:
	/* 0x2c49: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c4d:
	/* 0x2c4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c50:
	/* 0x2c50: jns    2c6c <trace_utimes_common+0x2c6c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c50, 0x2c6c, x86_l_2c6c);
x86_l_2c52:
	/* 0x2c52: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c55:
	/* 0x2c55: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c58:
	/* 0x2c58: js     2d0d <trace_utimes_common+0x2d0d> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c58, 0x2d0d, x86_l_2d0d);
x86_l_2c5e:
	/* 0x2c5e: add    rbx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2c62:
	/* 0x2c62: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c65:
	/* 0x2c65: jns    2c77 <trace_utimes_common+0x2c77> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c65, 0x2c77, x86_l_2c77);
x86_l_2c67:
	/* 0x2c67: mov    rcx,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c6a:
	/* 0x2c6a: jmp    2c79 <trace_utimes_common+0x2c79> */
	X86_SIM_X86_JMP(0x2c6a, 0x2c79, x86_l_2c79);
x86_l_2c6c:
	/* 0x2c6c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c6e:
	/* 0x2c6e: add    rbx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2c72:
	/* 0x2c72: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2c75:
	/* 0x2c75: js     2c67 <trace_utimes_common+0x2c67> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2c75, 0x2c67, x86_l_2c67);
x86_l_2c77:
	/* 0x2c77: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2c79:
	/* 0x2c79: imul   rax,rax,0x3b9aca00 */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 1000000000ULL);
x86_l_2c80:
	/* 0x2c80: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c83:
	/* 0x2c83: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2c8b:
	/* 0x2c8b: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2c93:
	/* 0x2c93: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2c99:
	/* 0x2c99: ja     2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c99, 0x2da6, x86_l_2da6);
x86_l_2c9f:
	/* 0x2c9f: mov    BYTE PTR [r13+rax*1+0x89],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519552ULL);
x86_l_2ca8:
	/* 0x2ca8: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2cb0:
	/* 0x2cb0: mov    WORD PTR [r13+0x7d8c],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32140ULL);
x86_l_2cb8:
	/* 0x2cb8: cmp    rax,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2cbe:
	/* 0x2cbe: ja     2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2cbe, 0x2da6, x86_l_2da6);
x86_l_2cc4:
	/* 0x2cc4: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2cc9:
	/* 0x2cc9: lea    rdi,[rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2ccd:
	/* 0x2ccd: add    rdi,0x8e */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_2cd4:
	/* 0x2cd4: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2cd7:
	/* 0x2cd7: jns    2d2d <trace_utimes_common+0x2d2d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cd7, 0x2d2d, x86_l_2d2d);
x86_l_2cd9:
	/* 0x2cd9: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2cdc:
	/* 0x2cdc: jns    2d76 <trace_utimes_common+0x2d76> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cdc, 0x2d76, x86_l_2d76);
x86_l_2ce2:
	/* 0x2ce2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ce4:
	/* 0x2ce4: cmp    rcx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_2ceb:
	/* 0x2ceb: je     2d84 <trace_utimes_common+0x2d84> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ceb, 0x2d84, x86_l_2d84);
x86_l_2cf1:
	/* 0x2cf1: lea    rax,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2cf5:
	/* 0x2cf5: movzx  edx,BYTE PTR [rbp+rcx*1+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_2cfa:
	/* 0x2cfa: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_2cfd:
	/* 0x2cfd: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d00:
	/* 0x2d00: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_2d02:
	/* 0x2d02: jne    2ce4 <trace_utimes_common+0x2ce4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d02, 0x2ce4, x86_l_2ce4);
x86_l_2d04:
	/* 0x2d04: jmp    2d3a <trace_utimes_common+0x2d3a> */
	X86_SIM_X86_JMP(0x2d04, 0x2d3a, x86_l_2d3a);
x86_l_2d06:
	/* 0x2d06: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d08:
	/* 0x2d08: jmp    2c44 <trace_utimes_common+0x2c44> */
	X86_SIM_X86_JMP(0x2d08, 0x2c44, x86_l_2c44);
x86_l_2d0d:
	/* 0x2d0d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d0f:
	/* 0x2d0f: mov    QWORD PTR [rsp+0x98],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2d17:
	/* 0x2d17: movzx  eax,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d1f:
	/* 0x2d1f: cmp    rax,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2d25:
	/* 0x2d25: jbe    2c9f <trace_utimes_common+0x2c9f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2d25, 0x2c9f, x86_l_2c9f);
x86_l_2d2b:
	/* 0x2d2b: jmp    2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JMP(0x2d2b, 0x2da6, x86_l_2da6);
x86_l_2d2d:
	/* 0x2d2d: mov    esi,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d32:
	/* 0x2d32: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d35:
	/* 0x2d35: call   2d3a <trace_utimes_common+0x2d3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user_str);
x86_l_2d3a:
	/* 0x2d3a: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d3d:
	/* 0x2d3d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d3f:
	/* 0x2d3f: jle    2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x2d3f, 0x2da6, x86_l_2da6);
x86_l_2d41:
	/* 0x2d41: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d49:
	/* 0x2d49: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2d50:
	/* 0x2d50: ja     2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d50, 0x2da6, x86_l_2da6);
x86_l_2d52:
	/* 0x2d52: mov    DWORD PTR [rdx+r13*1+0x8a],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 138ULL);
x86_l_2d5a:
	/* 0x2d5a: add    cx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_R13, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_2d62:
	/* 0x2d62: add    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2d65:
	/* 0x2d65: mov    WORD PTR [r13+0x7d8a],cx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2d6d:
	/* 0x2d6d: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2d74:
	/* 0x2d74: jmp    2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JMP(0x2d74, 0x2da6, x86_l_2da6);
x86_l_2d76:
	/* 0x2d76: mov    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d7b:
	/* 0x2d7b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d7d:
	/* 0x2d7d: call   2d82 <trace_utimes_common+0x2d82> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2d82:
	/* 0x2d82: jmp    2da6 <trace_utimes_common+0x2da6> */
	X86_SIM_X86_JMP(0x2d82, 0x2da6, x86_l_2da6);
x86_l_2d84:
	/* 0x2d84: mov    BYTE PTR [rdi+0xfff],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17587891077120ULL);
x86_l_2d8b:
	/* 0x2d8b: mov    ecx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d90:
	/* 0x2d90: mov    eax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_2d95:
	/* 0x2d95: movzx  edx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2d9d:
	/* 0x2d9d: cmp    rdx,0x6cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 27899ULL);
x86_l_2da4:
	/* 0x2da4: jbe    2d52 <trace_utimes_common+0x2d52> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2da4, 0x2d52, x86_l_2d52);
x86_l_2da6:
	/* 0x2da6: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2dae:
	/* 0x2dae: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2db5:
	/* 0x2db5: mov    r14,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2dba:
	/* 0x2dba: ja     2e17 <trace_utimes_common+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dba, 0x2e17, x86_l_2e17);
x86_l_2dbc:
	/* 0x2dbc: mov    BYTE PTR [r13+rbx*1+0x89],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519553ULL);
x86_l_2dc5:
	/* 0x2dc5: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_2dcb:
	/* 0x2dcb: ja     2e17 <trace_utimes_common+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2dcb, 0x2e17, x86_l_2e17);
x86_l_2dcd:
	/* 0x2dcd: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2dd1:
	/* 0x2dd1: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2dd8:
	/* 0x2dd8: lea    rax,[rsp+0x44] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_2ddd:
	/* 0x2ddd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2de0:
	/* 0x2de0: jns    2df1 <trace_utimes_common+0x2df1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2de0, 0x2df1, x86_l_2df1);
x86_l_2de2:
	/* 0x2de2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2de5:
	/* 0x2de5: jns    2e83 <trace_utimes_common+0x2e83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2de5, 0x2e83, x86_l_2e83);
x86_l_2deb:
	/* 0x2deb: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ded:
	/* 0x2ded: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2def:
	/* 0x2def: jmp    2e05 <trace_utimes_common+0x2e05> */
	X86_SIM_X86_JMP(0x2def, 0x2e05, x86_l_2e05);
x86_l_2df1:
	/* 0x2df1: lea    rdx,[rsp+0x44] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_2df6:
	/* 0x2df6: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2dfb:
	/* 0x2dfb: call   2e00 <trace_utimes_common+0x2e00> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e00:
	/* 0x2e00: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e03:
	/* 0x2e03: js     2e17 <trace_utimes_common+0x2e17> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e03, 0x2e17, x86_l_2e17);
x86_l_2e05:
	/* 0x2e05: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2e08:
	/* 0x2e08: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e10:
	/* 0x2e10: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e17:
	/* 0x2e17: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e1f:
	/* 0x2e1f: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e26:
	/* 0x2e26: ja     2ea3 <trace_utimes_common+0x2ea3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e26, 0x2ea3, x86_l_2ea3);
x86_l_2e28:
	/* 0x2e28: mov    BYTE PTR [r13+rbx*1+0x89],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519554ULL);
x86_l_2e31:
	/* 0x2e31: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2e37:
	/* 0x2e37: ja     2ea3 <trace_utimes_common+0x2ea3> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2e37, 0x2ea3, x86_l_2ea3);
x86_l_2e39:
	/* 0x2e39: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2e3d:
	/* 0x2e3d: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2e44:
	/* 0x2e44: lea    rax,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2e49:
	/* 0x2e49: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e4c:
	/* 0x2e4c: jns    2e5b <trace_utimes_common+0x2e5b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e4c, 0x2e5b, x86_l_2e5b);
x86_l_2e4e:
	/* 0x2e4e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e51:
	/* 0x2e51: jns    2e9c <trace_utimes_common+0x2e9c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e51, 0x2e9c, x86_l_2e9c);
x86_l_2e53:
	/* 0x2e53: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e56:
	/* 0x2e56: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e59:
	/* 0x2e59: jmp    2e6f <trace_utimes_common+0x2e6f> */
	X86_SIM_X86_JMP(0x2e59, 0x2e6f, x86_l_2e6f);
x86_l_2e5b:
	/* 0x2e5b: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2e60:
	/* 0x2e60: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2e65:
	/* 0x2e65: call   2e6a <trace_utimes_common+0x2e6a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2e6a:
	/* 0x2e6a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e6d:
	/* 0x2e6d: js     2ea3 <trace_utimes_common+0x2ea3> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2e6d, 0x2ea3, x86_l_2ea3);
x86_l_2e6f:
	/* 0x2e6f: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2e72:
	/* 0x2e72: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2e7a:
	/* 0x2e7a: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2e81:
	/* 0x2e81: jmp    2ea3 <trace_utimes_common+0x2ea3> */
	X86_SIM_X86_JMP(0x2e81, 0x2ea3, x86_l_2ea3);
x86_l_2e83:
	/* 0x2e83: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e89:
	/* 0x2e89: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2e91:
	/* 0x2e91: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2e98:
	/* 0x2e98: jbe    2e28 <trace_utimes_common+0x2e28> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2e98, 0x2e28, x86_l_2e28);
x86_l_2e9a:
	/* 0x2e9a: jmp    2ea3 <trace_utimes_common+0x2ea3> */
	X86_SIM_X86_JMP(0x2e9a, 0x2ea3, x86_l_2ea3);
x86_l_2e9c:
	/* 0x2e9c: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea3:
	/* 0x2ea3: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2eab:
	/* 0x2eab: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2eb2:
	/* 0x2eb2: ja     2f11 <trace_utimes_common+0x2f11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2eb2, 0x2f11, x86_l_2f11);
x86_l_2eb4:
	/* 0x2eb4: mov    BYTE PTR [r13+rbx*1+0x89],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519555ULL);
x86_l_2ebd:
	/* 0x2ebd: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2ec3:
	/* 0x2ec3: ja     2f11 <trace_utimes_common+0x2f11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2ec3, 0x2f11, x86_l_2f11);
x86_l_2ec5:
	/* 0x2ec5: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2ec9:
	/* 0x2ec9: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2ed0:
	/* 0x2ed0: lea    rax,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2ed5:
	/* 0x2ed5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ed8:
	/* 0x2ed8: jns    2eeb <trace_utimes_common+0x2eeb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2ed8, 0x2eeb, x86_l_2eeb);
x86_l_2eda:
	/* 0x2eda: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2edd:
	/* 0x2edd: jns    2f87 <trace_utimes_common+0x2f87> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2edd, 0x2f87, x86_l_2f87);
x86_l_2ee3:
	/* 0x2ee3: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee6:
	/* 0x2ee6: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ee9:
	/* 0x2ee9: jmp    2eff <trace_utimes_common+0x2eff> */
	X86_SIM_X86_JMP(0x2ee9, 0x2eff, x86_l_2eff);
x86_l_2eeb:
	/* 0x2eeb: lea    rdx,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2ef0:
	/* 0x2ef0: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2ef5:
	/* 0x2ef5: call   2efa <trace_utimes_common+0x2efa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2efa:
	/* 0x2efa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2efd:
	/* 0x2efd: js     2f11 <trace_utimes_common+0x2f11> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2efd, 0x2f11, x86_l_2f11);
x86_l_2eff:
	/* 0x2eff: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2f02:
	/* 0x2f02: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2f0a:
	/* 0x2f0a: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2f11:
	/* 0x2f11: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2f19:
	/* 0x2f19: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2f20:
	/* 0x2f20: ja     2fa8 <trace_utimes_common+0x2fa8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2f20, 0x2fa8, x86_l_2fa8);
x86_l_2f26:
	/* 0x2f26: mov    BYTE PTR [r13+rbx*1+0x89],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_2f2f:
	/* 0x2f2f: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_2f35:
	/* 0x2f35: ja     2fa8 <trace_utimes_common+0x2fa8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2f35, 0x2fa8, x86_l_2fa8);
x86_l_2f37:
	/* 0x2f37: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2f3b:
	/* 0x2f3b: add    rdi,0x8a */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_2f42:
	/* 0x2f42: lea    rax,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2f4a:
	/* 0x2f4a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f4d:
	/* 0x2f4d: jns    2f5c <trace_utimes_common+0x2f5c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f4d, 0x2f5c, x86_l_2f5c);
x86_l_2f4f:
	/* 0x2f4f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f52:
	/* 0x2f52: jns    2fa1 <trace_utimes_common+0x2fa1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f52, 0x2fa1, x86_l_2fa1);
x86_l_2f54:
	/* 0x2f54: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f57:
	/* 0x2f57: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f5a:
	/* 0x2f5a: jmp    2f73 <trace_utimes_common+0x2f73> */
	X86_SIM_X86_JMP(0x2f5a, 0x2f73, x86_l_2f73);
x86_l_2f5c:
	/* 0x2f5c: lea    rdx,[rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2f64:
	/* 0x2f64: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2f69:
	/* 0x2f69: call   2f6e <trace_utimes_common+0x2f6e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2f6e:
	/* 0x2f6e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f71:
	/* 0x2f71: js     2fa8 <trace_utimes_common+0x2fa8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2f71, 0x2fa8, x86_l_2fa8);
x86_l_2f73:
	/* 0x2f73: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_2f76:
	/* 0x2f76: mov    WORD PTR [r13+0x7d8a],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_2f7e:
	/* 0x2f7e: inc    BYTE PTR [r13+0x88] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R13, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_2f85:
	/* 0x2f85: jmp    2fa8 <trace_utimes_common+0x2fa8> */
	X86_SIM_X86_JMP(0x2f85, 0x2fa8, x86_l_2fa8);
x86_l_2f87:
	/* 0x2f87: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f8e:
	/* 0x2f8e: movzx  ebx,WORD PTR [r13+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_2f96:
	/* 0x2f96: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_2f9d:
	/* 0x2f9d: jbe    2f26 <trace_utimes_common+0x2f26> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2f9d, 0x2f26, x86_l_2f26);
x86_l_2f9f:
	/* 0x2f9f: jmp    2fa8 <trace_utimes_common+0x2fa8> */
	X86_SIM_X86_JMP(0x2f9f, 0x2fa8, x86_l_2fa8);
x86_l_2fa1:
	/* 0x2fa1: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fa8:
	/* 0x2fa8: mov    rbx,QWORD PTR [r13+0x7dd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_2faf:
	/* 0x2faf: lea    rcx,[rbx+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2fb3:
	/* 0x2fb3: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2fb6:
	/* 0x2fb6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fb9:
	/* 0x2fb9: jns    2fcb <trace_utimes_common+0x2fcb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fb9, 0x2fcb, x86_l_2fcb);
x86_l_2fbb:
	/* 0x2fbb: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fbe:
	/* 0x2fbe: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2fc2:
	/* 0x2fc2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fc5:
	/* 0x2fc5: js     2fd7 <trace_utimes_common+0x2fd7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2fc5, 0x2fd7, x86_l_2fd7);
x86_l_2fc7:
	/* 0x2fc7: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fc9:
	/* 0x2fc9: jmp    2fda <trace_utimes_common+0x2fda> */
	X86_SIM_X86_JMP(0x2fc9, 0x2fda, x86_l_2fda);
x86_l_2fcb:
	/* 0x2fcb: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fce:
	/* 0x2fce: lea    rax,[r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2fd2:
	/* 0x2fd2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fd5:
	/* 0x2fd5: jns    2fc7 <trace_utimes_common+0x2fc7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fd5, 0x2fc7, x86_l_2fc7);
x86_l_2fd7:
	/* 0x2fd7: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fda:
	/* 0x2fda: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2fde:
	/* 0x2fde: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fe0:
	/* 0x2fe0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fe3:
	/* 0x2fe3: jns    2ff4 <trace_utimes_common+0x2ff4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fe3, 0x2ff4, x86_l_2ff4);
x86_l_2fe5:
	/* 0x2fe5: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fe8:
	/* 0x2fe8: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2fed:
	/* 0x2fed: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ff0:
	/* 0x2ff0: js     3001 <trace_utimes_common+0x3001> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ff0, 0x3001, x86_l_3001);
x86_l_2ff2:
	/* 0x2ff2: jmp    3003 <trace_utimes_common+0x3003> */
	X86_SIM_X86_JMP(0x2ff2, 0x3003, x86_l_3003);
x86_l_2ff4:
	/* 0x2ff4: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ff7:
	/* 0x2ff7: lea    rdx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2ffc:
	/* 0x2ffc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2fff:
	/* 0x2fff: jns    3003 <trace_utimes_common+0x3003> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2fff, 0x3003, x86_l_3003);
x86_l_3001:
	/* 0x3001: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3003:
	/* 0x3003: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_3007:
	/* 0x3007: lea    rax,[rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_300b:
	/* 0x300b: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_300e:
	/* 0x300e: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3010:
	/* 0x3010: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3013:
	/* 0x3013: jns    3022 <trace_utimes_common+0x3022> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3013, 0x3022, x86_l_3022);
x86_l_3015:
	/* 0x3015: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3018:
	/* 0x3018: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_301b:
	/* 0x301b: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_301e:
	/* 0x301e: js     302c <trace_utimes_common+0x302c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x301e, 0x302c, x86_l_302c);
x86_l_3020:
	/* 0x3020: jmp    302e <trace_utimes_common+0x302e> */
	X86_SIM_X86_JMP(0x3020, 0x302e, x86_l_302e);
x86_l_3022:
	/* 0x3022: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3024:
	/* 0x3024: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3027:
	/* 0x3027: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_302a:
	/* 0x302a: jns    302e <trace_utimes_common+0x302e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x302a, 0x302e, x86_l_302e);
x86_l_302c:
	/* 0x302c: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_302e:
	/* 0x302e: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_3030:
	/* 0x3030: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3034:
	/* 0x3034: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3037:
	/* 0x3037: add    rsi,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_303b:
	/* 0x303b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_303d:
	/* 0x303d: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3040:
	/* 0x3040: jns    3044 <trace_utimes_common+0x3044> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3040, 0x3044, x86_l_3044);
x86_l_3042:
	/* 0x3042: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3044:
	/* 0x3044: mov    DWORD PTR [r13+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_3048:
	/* 0x3048: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_304b:
	/* 0x304b: jns    3052 <trace_utimes_common+0x3052> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x304b, 0x3052, x86_l_3052);
x86_l_304d:
	/* 0x304d: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3050:
	/* 0x3050: jmp    3054 <trace_utimes_common+0x3054> */
	X86_SIM_X86_JMP(0x3050, 0x3054, x86_l_3054);
x86_l_3052:
	/* 0x3052: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3054:
	/* 0x3054: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3058:
	/* 0x3058: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_305a:
	/* 0x305a: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_305d:
	/* 0x305d: jns    306c <trace_utimes_common+0x306c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x305d, 0x306c, x86_l_306c);
x86_l_305f:
	/* 0x305f: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3062:
	/* 0x3062: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3065:
	/* 0x3065: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3068:
	/* 0x3068: js     3076 <trace_utimes_common+0x3076> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3068, 0x3076, x86_l_3076);
x86_l_306a:
	/* 0x306a: jmp    3078 <trace_utimes_common+0x3078> */
	X86_SIM_X86_JMP(0x306a, 0x3078, x86_l_3078);
x86_l_306c:
	/* 0x306c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_306e:
	/* 0x306e: mov    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3071:
	/* 0x3071: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3074:
	/* 0x3074: jns    3078 <trace_utimes_common+0x3078> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3074, 0x3078, x86_l_3078);
x86_l_3076:
	/* 0x3076: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3078:
	/* 0x3078: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_307a:
	/* 0x307a: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_307e:
	/* 0x307e: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3081:
	/* 0x3081: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3085:
	/* 0x3085: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3087:
	/* 0x3087: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_308a:
	/* 0x308a: jns    308e <trace_utimes_common+0x308e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x308a, 0x308e, x86_l_308e);
x86_l_308c:
	/* 0x308c: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_308e:
	/* 0x308e: mov    DWORD PTR [r13+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3092:
	/* 0x3092: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3094:
	/* 0x3094: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3097:
	/* 0x3097: jns    30a6 <trace_utimes_common+0x30a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3097, 0x30a6, x86_l_30a6);
x86_l_3099:
	/* 0x3099: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_309c:
	/* 0x309c: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_309f:
	/* 0x309f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_30a2:
	/* 0x30a2: js     30b0 <trace_utimes_common+0x30b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30a2, 0x30b0, x86_l_30b0);
x86_l_30a4:
	/* 0x30a4: jmp    30b2 <trace_utimes_common+0x30b2> */
	X86_SIM_X86_JMP(0x30a4, 0x30b2, x86_l_30b2);
x86_l_30a6:
	/* 0x30a6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30a8:
	/* 0x30a8: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30ab:
	/* 0x30ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_30ae:
	/* 0x30ae: jns    30b2 <trace_utimes_common+0x30b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30ae, 0x30b2, x86_l_30b2);
x86_l_30b0:
	/* 0x30b0: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30b2:
	/* 0x30b2: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_30b4:
	/* 0x30b4: shl    rcx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_30b8:
	/* 0x30b8: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_30bb:
	/* 0x30bb: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_30bf:
	/* 0x30bf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30c1:
	/* 0x30c1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30c4:
	/* 0x30c4: jns    30d4 <trace_utimes_common+0x30d4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30c4, 0x30d4, x86_l_30d4);
x86_l_30c6:
	/* 0x30c6: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30c9:
	/* 0x30c9: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_30cd:
	/* 0x30cd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30d0:
	/* 0x30d0: js     30df <trace_utimes_common+0x30df> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30d0, 0x30df, x86_l_30df);
x86_l_30d2:
	/* 0x30d2: jmp    30e1 <trace_utimes_common+0x30e1> */
	X86_SIM_X86_JMP(0x30d2, 0x30e1, x86_l_30e1);
x86_l_30d4:
	/* 0x30d4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30d6:
	/* 0x30d6: add    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_30da:
	/* 0x30da: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30dd:
	/* 0x30dd: jns    30e1 <trace_utimes_common+0x30e1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30dd, 0x30e1, x86_l_30e1);
x86_l_30df:
	/* 0x30df: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30e1:
	/* 0x30e1: lea    rcx,[r12+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30e6:
	/* 0x30e6: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30e9:
	/* 0x30e9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30eb:
	/* 0x30eb: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_30ee:
	/* 0x30ee: jns    30fd <trace_utimes_common+0x30fd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30ee, 0x30fd, x86_l_30fd);
x86_l_30f0:
	/* 0x30f0: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_30f3:
	/* 0x30f3: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_30f6:
	/* 0x30f6: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_30f9:
	/* 0x30f9: js     3107 <trace_utimes_common+0x3107> */
	X86_SIM_X86_JCC(X86_CC_S, 0x30f9, 0x3107, x86_l_3107);
x86_l_30fb:
	/* 0x30fb: jmp    3109 <trace_utimes_common+0x3109> */
	X86_SIM_X86_JMP(0x30fb, 0x3109, x86_l_3109);
x86_l_30fd:
	/* 0x30fd: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30ff:
	/* 0x30ff: mov    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3102:
	/* 0x3102: test   rdi,rdi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_3105:
	/* 0x3105: jns    3109 <trace_utimes_common+0x3109> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3105, 0x3109, x86_l_3109);
x86_l_3107:
	/* 0x3107: mov    edx,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3109:
	/* 0x3109: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_310b:
	/* 0x310b: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_310f:
	/* 0x310f: add    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3112:
	/* 0x3112: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3116:
	/* 0x3116: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3118:
	/* 0x3118: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_311b:
	/* 0x311b: jns    312b <trace_utimes_common+0x312b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x311b, 0x312b, x86_l_312b);
x86_l_311d:
	/* 0x311d: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3120:
	/* 0x3120: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3124:
	/* 0x3124: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3127:
	/* 0x3127: js     3136 <trace_utimes_common+0x3136> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3127, 0x3136, x86_l_3136);
x86_l_3129:
	/* 0x3129: jmp    3138 <trace_utimes_common+0x3138> */
	X86_SIM_X86_JMP(0x3129, 0x3138, x86_l_3138);
x86_l_312b:
	/* 0x312b: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_312d:
	/* 0x312d: add    rsi,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_3131:
	/* 0x3131: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3134:
	/* 0x3134: jns    3138 <trace_utimes_common+0x3138> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3134, 0x3138, x86_l_3138);
x86_l_3136:
	/* 0x3136: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3138:
	/* 0x3138: cmp    eax,edx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_313a:
	/* 0x313a: jne    3176 <trace_utimes_common+0x3176> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x313a, 0x3176, x86_l_3176);
x86_l_313c:
	/* 0x313c: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_313e:
	/* 0x313e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3141:
	/* 0x3141: jns    3150 <trace_utimes_common+0x3150> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3141, 0x3150, x86_l_3150);
x86_l_3143:
	/* 0x3143: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3146:
	/* 0x3146: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3149:
	/* 0x3149: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_314c:
	/* 0x314c: js     315a <trace_utimes_common+0x315a> */
	X86_SIM_X86_JCC(X86_CC_S, 0x314c, 0x315a, x86_l_315a);
x86_l_314e:
	/* 0x314e: jmp    315c <trace_utimes_common+0x315c> */
	X86_SIM_X86_JMP(0x314e, 0x315c, x86_l_315c);
x86_l_3150:
	/* 0x3150: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3152:
	/* 0x3152: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3155:
	/* 0x3155: test   rsi,rsi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3158:
	/* 0x3158: jns    315c <trace_utimes_common+0x315c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3158, 0x315c, x86_l_315c);
x86_l_315a:
	/* 0x315a: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_315c:
	/* 0x315c: mov    edx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_315e:
	/* 0x315e: shl    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3162:
	/* 0x3162: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3165:
	/* 0x3165: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3169:
	/* 0x3169: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_316b:
	/* 0x316b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_316e:
	/* 0x316e: jns    3172 <trace_utimes_common+0x3172> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x316e, 0x3172, x86_l_3172);
x86_l_3170:
	/* 0x3170: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3172:
	/* 0x3172: mov    DWORD PTR [r13+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3176:
	/* 0x3176: mov    DWORD PTR [r13+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_317a:
	/* 0x317a: lea    r13,[rbx+0x90] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_3181:
	/* 0x3181: mov    rax,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3184:
	/* 0x3184: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3187:
	/* 0x3187: jns    318e <trace_utimes_common+0x318e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3187, 0x318e, x86_l_318e);
x86_l_3189:
	/* 0x3189: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_318c:
	/* 0x318c: jmp    3190 <trace_utimes_common+0x3190> */
	X86_SIM_X86_JMP(0x318c, 0x3190, x86_l_3190);
x86_l_318e:
	/* 0x318e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3190:
	/* 0x3190: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3194:
	/* 0x3194: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3196:
	/* 0x3196: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3199:
	/* 0x3199: jns    31a5 <trace_utimes_common+0x31a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3199, 0x31a5, x86_l_31a5);
x86_l_319b:
	/* 0x319b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_319e:
	/* 0x319e: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31a1:
	/* 0x31a1: js     31ac <trace_utimes_common+0x31ac> */
	X86_SIM_X86_JCC(X86_CC_S, 0x31a1, 0x31ac, x86_l_31ac);
x86_l_31a3:
	/* 0x31a3: jmp    31ae <trace_utimes_common+0x31ae> */
	X86_SIM_X86_JMP(0x31a3, 0x31ae, x86_l_31ae);
x86_l_31a5:
	/* 0x31a5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31a7:
	/* 0x31a7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_31aa:
	/* 0x31aa: jns    31ae <trace_utimes_common+0x31ae> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31aa, 0x31ae, x86_l_31ae);
x86_l_31ac:
	/* 0x31ac: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31ae:
	/* 0x31ae: lea    rbp,[r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31b2:
	/* 0x31b2: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31b7:
	/* 0x31b7: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_31bb:
	/* 0x31bb: call   31c0 <trace_utimes_common+0x31c0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_31c0:
	/* 0x31c0: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_31c4:
	/* 0x31c4: lea    rax,[rbx+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_31c8:
	/* 0x31c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31cb:
	/* 0x31cb: jns    31d2 <trace_utimes_common+0x31d2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31cb, 0x31d2, x86_l_31d2);
x86_l_31cd:
	/* 0x31cd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d0:
	/* 0x31d0: jmp    31d4 <trace_utimes_common+0x31d4> */
	X86_SIM_X86_JMP(0x31d0, 0x31d4, x86_l_31d4);
x86_l_31d2:
	/* 0x31d2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31d4:
	/* 0x31d4: mov    QWORD PTR [rbp+0x0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d8:
	/* 0x31d8: add    r15,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_31dc:
	/* 0x31dc: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_31df:
	/* 0x31df: jns    31e6 <trace_utimes_common+0x31e6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31df, 0x31e6, x86_l_31e6);
x86_l_31e1:
	/* 0x31e1: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31e4:
	/* 0x31e4: jmp    31e8 <trace_utimes_common+0x31e8> */
	X86_SIM_X86_JMP(0x31e4, 0x31e8, x86_l_31e8);
x86_l_31e6:
	/* 0x31e6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31e8:
	/* 0x31e8: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31ed:
	/* 0x31ed: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_31f1:
	/* 0x31f1: add    r12,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_31f5:
	/* 0x31f5: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_31f8:
	/* 0x31f8: jns    3200 <trace_utimes_common+0x3200> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31f8, 0x3200, x86_l_3200);
x86_l_31fa:
	/* 0x31fa: mov    rax,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31fe:
	/* 0x31fe: jmp    3202 <trace_utimes_common+0x3202> */
	X86_SIM_X86_JMP(0x31fe, 0x3202, x86_l_3202);
x86_l_3200:
	/* 0x3200: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3202:
	/* 0x3202: mov    r15,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_320a:
	/* 0x320a: mov    rcx,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_320f:
	/* 0x320f: mov    QWORD PTR [rcx+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3213:
	/* 0x3213: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3216:
	/* 0x3216: jns    3222 <trace_utimes_common+0x3222> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3216, 0x3222, x86_l_3222);
x86_l_3218:
	/* 0x3218: mov    eax,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_321a:
	/* 0x321a: test   al,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_321c:
	/* 0x321c: je     3222 <trace_utimes_common+0x3222> */
	X86_SIM_X86_JCC(X86_CC_E, 0x321c, 0x3222, x86_l_3222);
x86_l_321e:
	/* 0x321e: or     BYTE PTR [rcx+0x5c],0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991234ULL);
x86_l_3222:
	/* 0x3222: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3227:
	/* 0x3227: lea    rdi,[rax+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_322b:
	/* 0x322b: mov    QWORD PTR [rcx+0x44],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 292057776128ULL);
x86_l_3233:
	/* 0x3233: mov    QWORD PTR [rcx+0x3c],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_323b:
	/* 0x323b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3240:
	/* 0x3240: call   3245 <trace_utimes_common+0x3245> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_3245:
	/* 0x3245: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_3248:
	/* 0x3248: jns    3250 <trace_utimes_common+0x3250> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3248, 0x3250, x86_l_3250);
x86_l_324a:
	/* 0x324a: mov    rax,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_324e:
	/* 0x324e: jmp    3252 <trace_utimes_common+0x3252> */
	X86_SIM_X86_JMP(0x324e, 0x3252, x86_l_3252);
x86_l_3250:
	/* 0x3250: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3252:
	/* 0x3252: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3257:
	/* 0x3257: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_325a:
	/* 0x325a: mov    r14,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_325f:
	/* 0x325f: jns    326b <trace_utimes_common+0x326b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x325f, 0x326b, x86_l_326b);
x86_l_3261:
	/* 0x3261: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3264:
	/* 0x3264: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3267:
	/* 0x3267: js     3272 <trace_utimes_common+0x3272> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3267, 0x3272, x86_l_3272);
x86_l_3269:
	/* 0x3269: jmp    32b3 <trace_utimes_common+0x32b3> */
	X86_SIM_X86_JMP(0x3269, 0x32b3, x86_l_32b3);
x86_l_326b:
	/* 0x326b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_326d:
	/* 0x326d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3270:
	/* 0x3270: jns    32b3 <trace_utimes_common+0x32b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3270, 0x32b3, x86_l_32b3);
x86_l_3272:
	/* 0x3272: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3275:
	/* 0x3275: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_327a:
	/* 0x327a: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_327e:
	/* 0x327e: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3283:
	/* 0x3283: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3287:
	/* 0x3287: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_328c:
	/* 0x328c: mov    rcx,QWORD PTR [rax+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3290:
	/* 0x3290: mov    QWORD PTR [rsp+0x68],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_3295:
	/* 0x3295: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3299:
	/* 0x3299: mov    QWORD PTR [rsp+0x70],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_329e:
	/* 0x329e: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_32a2:
	/* 0x32a2: mov    QWORD PTR [rsp+0x78],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_32a7:
	/* 0x32a7: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_32ab:
	/* 0x32ab: mov    rcx,QWORD PTR [rax+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_32af:
	/* 0x32af: movzx  eax,BYTE PTR [rax+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_32b3:
	/* 0x32b3: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_32b8:
	/* 0x32b8: add    rdx,0x4c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 76ULL);
x86_l_32bc:
	/* 0x32bc: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_32c1:
	/* 0x32c1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_32c4:
	/* 0x32c4: jns    339a <trace_utimes_common+0x339a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x32c4, 0x339a, x86_l_339a);
x86_l_32ca:
	/* 0x32ca: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_32cd:
	/* 0x32cd: mov    BYTE PTR [rdx],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32cf:
	/* 0x32cf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32d1:
	/* 0x32d1: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32d1, 0x33a9, x86_l_33a9);
x86_l_32d7:
	/* 0x32d7: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_32db:
	/* 0x32db: mov    BYTE PTR [r14+0x4d],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 77ULL);
x86_l_32df:
	/* 0x32df: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32e1:
	/* 0x32e1: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32e1, 0x33a9, x86_l_33a9);
x86_l_32e7:
	/* 0x32e7: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_32eb:
	/* 0x32eb: mov    BYTE PTR [r14+0x4e],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_32ef:
	/* 0x32ef: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_32f1:
	/* 0x32f1: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f1, 0x33a9, x86_l_33a9);
x86_l_32f7:
	/* 0x32f7: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_32fb:
	/* 0x32fb: mov    BYTE PTR [r14+0x4f],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 79ULL);
x86_l_32ff:
	/* 0x32ff: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3301:
	/* 0x3301: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3301, 0x33a9, x86_l_33a9);
x86_l_3307:
	/* 0x3307: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_330b:
	/* 0x330b: mov    BYTE PTR [r14+0x50],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_330f:
	/* 0x330f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3311:
	/* 0x3311: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3311, 0x33a9, x86_l_33a9);
x86_l_3317:
	/* 0x3317: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_331b:
	/* 0x331b: mov    BYTE PTR [r14+0x51],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 81ULL);
x86_l_331f:
	/* 0x331f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3321:
	/* 0x3321: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3321, 0x33a9, x86_l_33a9);
x86_l_3327:
	/* 0x3327: movzx  ecx,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_332b:
	/* 0x332b: mov    BYTE PTR [r14+0x52],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_332f:
	/* 0x332f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3331:
	/* 0x3331: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3331, 0x33a9, x86_l_33a9);
x86_l_3333:
	/* 0x3333: movzx  ecx,BYTE PTR [rax+0x7] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 7ULL);
x86_l_3337:
	/* 0x3337: mov    BYTE PTR [r14+0x53],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 83ULL);
x86_l_333b:
	/* 0x333b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_333d:
	/* 0x333d: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x333d, 0x33a9, x86_l_33a9);
x86_l_333f:
	/* 0x333f: movzx  ecx,BYTE PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_3343:
	/* 0x3343: mov    BYTE PTR [r14+0x54],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 84ULL);
x86_l_3347:
	/* 0x3347: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3349:
	/* 0x3349: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3349, 0x33a9, x86_l_33a9);
x86_l_334b:
	/* 0x334b: movzx  ecx,BYTE PTR [rax+0x9] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 9ULL);
x86_l_334f:
	/* 0x334f: mov    BYTE PTR [r14+0x55],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 85ULL);
x86_l_3353:
	/* 0x3353: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3355:
	/* 0x3355: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3355, 0x33a9, x86_l_33a9);
x86_l_3357:
	/* 0x3357: movzx  ecx,BYTE PTR [rax+0xa] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 10ULL);
x86_l_335b:
	/* 0x335b: mov    BYTE PTR [r14+0x56],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 86ULL);
x86_l_335f:
	/* 0x335f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3361:
	/* 0x3361: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3361, 0x33a9, x86_l_33a9);
x86_l_3363:
	/* 0x3363: movzx  ecx,BYTE PTR [rax+0xb] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 11ULL);
x86_l_3367:
	/* 0x3367: mov    BYTE PTR [r14+0x57],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 87ULL);
x86_l_336b:
	/* 0x336b: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_336d:
	/* 0x336d: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x336d, 0x33a9, x86_l_33a9);
x86_l_336f:
	/* 0x336f: movzx  ecx,BYTE PTR [rax+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_3373:
	/* 0x3373: mov    BYTE PTR [r14+0x58],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3377:
	/* 0x3377: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3379:
	/* 0x3379: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3379, 0x33a9, x86_l_33a9);
x86_l_337b:
	/* 0x337b: movzx  ecx,BYTE PTR [rax+0xd] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 13ULL);
x86_l_337f:
	/* 0x337f: mov    BYTE PTR [r14+0x59],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 89ULL);
x86_l_3383:
	/* 0x3383: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_3385:
	/* 0x3385: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3385, 0x33a9, x86_l_33a9);
x86_l_3387:
	/* 0x3387: movzx  eax,BYTE PTR [rax+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 14ULL);
x86_l_338b:
	/* 0x338b: mov    BYTE PTR [r14+0x5a],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90ULL);
x86_l_338f:
	/* 0x338f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_3391:
	/* 0x3391: je     33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3391, 0x33a9, x86_l_33a9);
x86_l_3393:
	/* 0x3393: mov    BYTE PTR [r14+0x5b],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 390842023936ULL);
x86_l_3398:
	/* 0x3398: jmp    33a9 <trace_utimes_common+0x33a9> */
	X86_SIM_X86_JMP(0x3398, 0x33a9, x86_l_33a9);
x86_l_339a:
	/* 0x339a: mov    QWORD PTR [rdx+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_33a2:
	/* 0x33a2: mov    QWORD PTR [rdx],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33a9:
	/* 0x33a9: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_33ac:
	/* 0x33ac: jns    3426 <trace_utimes_common+0x3426> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x33ac, 0x3426, x86_l_3426);
x86_l_33ae:
	/* 0x33ae: mov    rax,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33b2:
	/* 0x33b2: mov    rcx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33b7:
	/* 0x33b7: mov    QWORD PTR [rcx],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33ba:
	/* 0x33ba: mov    rax,QWORD PTR [rbp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33be:
	/* 0x33be: mov    QWORD PTR [rcx+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33c2:
	/* 0x33c2: mov    rax,QWORD PTR [rbp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33c6:
	/* 0x33c6: mov    QWORD PTR [rcx+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33ca:
	/* 0x33ca: mov    rax,QWORD PTR [rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33ce:
	/* 0x33ce: mov    QWORD PTR [rcx+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_33d2:
	/* 0x33d2: mov    rax,QWORD PTR [rbp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33d6:
	/* 0x33d6: mov    QWORD PTR [rcx+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_33da:
	/* 0x33da: mov    rax,QWORD PTR [rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_33de:
	/* 0x33de: mov    QWORD PTR [rcx+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_33e2:
	/* 0x33e2: mov    rax,QWORD PTR [rbp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33e6:
	/* 0x33e6: mov    QWORD PTR [rcx+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33ea:
	/* 0x33ea: mov    rax,QWORD PTR [rbp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_33ee:
	/* 0x33ee: mov    QWORD PTR [rcx+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_33f2:
	/* 0x33f2: mov    rax,QWORD PTR [rbp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_33f6:
	/* 0x33f6: mov    QWORD PTR [rcx+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_33fa:
	/* 0x33fa: mov    rax,QWORD PTR [rbp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_33fe:
	/* 0x33fe: mov    QWORD PTR [rcx+0x48],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_3402:
	/* 0x3402: mov    rax,QWORD PTR [rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_3406:
	/* 0x3406: mov    QWORD PTR [rcx+0x50],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_340a:
	/* 0x340a: mov    rax,QWORD PTR [rbp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_340e:
	/* 0x340e: mov    QWORD PTR [rcx+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_3412:
	/* 0x3412: mov    rax,QWORD PTR [rbp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_3416:
	/* 0x3416: mov    QWORD PTR [rcx+0x60],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_341a:
	/* 0x341a: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_341f:
	/* 0x341f: jne    3499 <trace_utimes_common+0x3499> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x341f, 0x3499, x86_l_3499);
x86_l_3421:
	/* 0x3421: jmp    34b5 <trace_utimes_common+0x34b5> */
	X86_SIM_X86_JMP(0x3421, 0x34b5, x86_l_34b5);
x86_l_3426:
	/* 0x3426: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_342b:
	/* 0x342b: mov    QWORD PTR [rax+0x60],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_3433:
	/* 0x3433: mov    QWORD PTR [rax+0x58],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_343b:
	/* 0x343b: mov    QWORD PTR [rax+0x50],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_3443:
	/* 0x3443: mov    QWORD PTR [rax+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_344b:
	/* 0x344b: mov    QWORD PTR [rax+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_3453:
	/* 0x3453: mov    QWORD PTR [rax+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_345b:
	/* 0x345b: mov    QWORD PTR [rax+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_3463:
	/* 0x3463: mov    QWORD PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_346b:
	/* 0x346b: mov    QWORD PTR [rax+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_3473:
	/* 0x3473: mov    QWORD PTR [rax+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_347b:
	/* 0x347b: mov    QWORD PTR [rax+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_3483:
	/* 0x3483: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_348b:
	/* 0x348b: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3492:
	/* 0x3492: test   BYTE PTR [r15+0x4],0x8 */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869192ULL);
x86_l_3497:
	/* 0x3497: je     34b5 <trace_utimes_common+0x34b5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3497, 0x34b5, x86_l_34b5);
x86_l_3499:
	/* 0x3499: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_addresses));
x86_l_34a0:
	/* 0x34a0: mov    edx,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_34a5:
	/* 0x34a5: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_34a8:
	/* 0x34a8: call   34ad <trace_utimes_common+0x34ad> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_stackid);
x86_l_34ad:
	/* 0x34ad: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_34af:
	/* 0x34af: js     34b5 <trace_utimes_common+0x34b5> */
	X86_SIM_X86_JCC(X86_CC_S, 0x34af, 0x34b5, x86_l_34b5);
x86_l_34b1:
	/* 0x34b1: mov    DWORD PTR [r14+0x78],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_34b5:
	/* 0x34b5: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_34bd:
	/* 0x34bd: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_34c2:
	/* 0x34c2: jb     34c9 <trace_utimes_common+0x34c9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x34c2, 0x34c9, x86_l_34c9);
x86_l_34c4:
	/* 0x34c4: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_34c9:
	/* 0x34c9: add    eax,0x89 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 137ULL);
x86_l_34ce:
	/* 0x34ce: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_34d2:
	/* 0x34d2: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_34d9:
	/* 0x34d9: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_34de:
	/* 0x34de: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_34e1:
	/* 0x34e1: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_34e4:
	/* 0x34e4: call   34e9 <trace_utimes_common+0x34e9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_34e9:
	/* 0x34e9: add    rsp,0xb8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 184ULL);
x86_l_34f0:
	/* 0x34f0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34f1:
	/* 0x34f1: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34f3:
	/* 0x34f3: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34f5:
	/* 0x34f5: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34f7:
	/* 0x34f7: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34f9:
	/* 0x34f9: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_34fa:
	/* 0x34fa: jmp    35b7 <trace_utimes_common+0x35b7> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_34ff:
	/* 0x34ff: cmp    r9,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R9, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3502:
	/* 0x3502: jne    35af <trace_utimes_common+0x35af> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3502, 0x35af, x86_l_35af);
x86_l_3508:
	/* 0x3508: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_350d:
	/* 0x350d: je     35af <trace_utimes_common+0x35af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x350d, 0x35af, x86_l_35af);
x86_l_3513:
	/* 0x3513: lea    rcx,[rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3517:
	/* 0x3517: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_351a:
	/* 0x351a: jns    355d <trace_utimes_common+0x355d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x351a, 0x355d, x86_l_355d);
x86_l_351c:
	/* 0x351c: mov    rdx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_351f:
	/* 0x351f: jmp    355f <trace_utimes_common+0x355f> */
	X86_SIM_X86_JMP(0x351f, 0x355f, x86_l_355f);
x86_l_3521:
	/* 0x3521: test   r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_3524:
	/* 0x3524: je     35af <trace_utimes_common+0x35af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3524, 0x35af, x86_l_35af);
x86_l_352a:
	/* 0x352a: and    edi,0x3fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3530:
	/* 0x3530: add    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3533:
	/* 0x3533: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3536:
	/* 0x3536: jns    357c <trace_utimes_common+0x357c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3536, 0x357c, x86_l_357c);
x86_l_3538:
	/* 0x3538: lea    ecx,[r8-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_353c:
	/* 0x353c: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_353e:
	/* 0x353e: cmp    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_3541:
	/* 0x3541: je     3586 <trace_utimes_common+0x3586> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3541, 0x3586, x86_l_3586);
x86_l_3543:
	/* 0x3543: lea    r10,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3547:
	/* 0x3547: movzx  r11d,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_354c:
	/* 0x354c: mov    BYTE PTR [rdi+rsi*1],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_3550:
	/* 0x3550: mov    rsi,r10 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R10, X86_WIDTH_64, 0, 0);
x86_l_3553:
	/* 0x3553: test   r11b,r11b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8, 0, 0);
x86_l_3556:
	/* 0x3556: jne    353e <trace_utimes_common+0x353e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3556, 0x353e, x86_l_353e);
x86_l_3558:
	/* 0x3558: mov    r8d,r10d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R10, X86_WIDTH_32, 0, 0);
x86_l_355b:
	/* 0x355b: jmp    358a <trace_utimes_common+0x358a> */
	X86_SIM_X86_JMP(0x355b, 0x358a, x86_l_358a);
x86_l_355d:
	/* 0x355d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_355f:
	/* 0x355f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3562:
	/* 0x3562: jns    3569 <trace_utimes_common+0x3569> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3562, 0x3569, x86_l_3569);
x86_l_3564:
	/* 0x3564: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3567:
	/* 0x3567: jmp    356b <trace_utimes_common+0x356b> */
	X86_SIM_X86_JMP(0x3567, 0x356b, x86_l_356b);
x86_l_3569:
	/* 0x3569: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_356b:
	/* 0x356b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_356e:
	/* 0x356e: jns    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x356e, 0x2b17, x86_l_2b17);
x86_l_3574:
	/* 0x3574: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3577:
	/* 0x3577: jmp    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JMP(0x3577, 0x2b17, x86_l_2b17);
x86_l_357c:
	/* 0x357c: mov    QWORD PTR [rsp+0x8],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3581:
	/* 0x3581: jmp    294d <trace_utimes_common+0x294d> */
	X86_SIM_X86_JMP(0x3581, 0x294d, x86_l_294d);
x86_l_3586:
	/* 0x3586: mov    BYTE PTR [rdi+rcx*1],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_358a:
	/* 0x358a: cmp    r8d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_358e:
	/* 0x358e: jl     35af <trace_utimes_common+0x35af> */
	X86_SIM_X86_JCC(X86_CC_L, 0x358e, 0x35af, x86_l_35af);
x86_l_3590:
	/* 0x3590: mov    r14,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3594:
	/* 0x3594: lea    eax,[r14-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3598:
	/* 0x3598: and    eax,0x7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_359d:
	/* 0x359d: mov    BYTE PTR [rbp+rax*1+0x0],0x2f */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_35a2:
	/* 0x35a2: sub    r14d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R8, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_35a5:
	/* 0x35a5: mov    r13,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35aa:
	/* 0x35aa: jmp    1178 <trace_utimes_common+0x1178> */
	X86_SIM_X86_JMP(0x35aa, 0x1178, x86_l_1178);
x86_l_35af:
	/* 0x35af: mov    rdx,r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R9, X86_WIDTH_64, 0, 0);
x86_l_35b2:
	/* 0x35b2: jmp    2b17 <trace_utimes_common+0x2b17> */
	X86_SIM_X86_JMP(0x35b2, 0x2b17, x86_l_2b17);
x86_l_35b7:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
