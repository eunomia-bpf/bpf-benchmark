#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 120U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(7)
#include "../x86_sim_local_bpf.h"

extern __u8 events[] __ksym;
extern __u8 ipv6_count[] __ksym;
extern __u8 sockets[] __ksym;
static const __u8 __x86_rodata_0[8] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\"section:SectionIndex(11):.rodata:table_110\",\"size\":8}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 7: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 7, 1);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 5: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 5, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 6: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 6, 2);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 1: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 1, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 2: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 2, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 3: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 3, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	case 4: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 4, 4);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		KPROG_C_COPY_BYTES(&value, __x86_rodata_0 + 0, 8);
		KPROG_C_VALUE_BARRIER_VAR(value);
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#define X86_SIM_L_NATIVE_DATA_LOAD_DECL(RESULT, BASE, OFF, WIDTH) \
   const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 RESULT; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       RESULT = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       RESULT = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width);
#define X86_SIM_L_NATIVE_DATA_LOAD_INTO(OUTPUT, BASE, OFF, WIDTH) \
   do { X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_into, BASE, OFF, WIDTH) \
        (OUTPUT) = __x86_ro_into; } while (0)
#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
   ({ X86_SIM_L_NATIVE_DATA_LOAD_DECL(__x86_ro_value, BASE, OFF, WIDTH) \
      __x86_ro_value; })

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MULX, X86_OP_MULX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kretprobe/tcp_v6_connect")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: sub    rsp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 80ULL);
x86_l_c:
	/* 0xc: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f:
	/* 0xf: mov    r15d,DWORD PTR [rdi+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13:
	/* 0x13: call   18 <tcp_v6_connect_ret+0x18> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_18:
	/* 0x18: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b:
	/* 0x1b: mov    DWORD PTR [rsp+0x4],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_20:
	/* 0x20: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sockets));
x86_l_27:
	/* 0x27: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c:
	/* 0x2c: call   31 <tcp_v6_connect_ret+0x31> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_31:
	/* 0x31: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_34:
	/* 0x34: je     4c <tcp_v6_connect_ret+0x4c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x34, 0x4c, x86_l_4c);
x86_l_36:
	/* 0x36: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_39:
	/* 0x39: je     5f <tcp_v6_connect_ret+0x5f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39, 0x5f, x86_l_5f);
x86_l_3b:
	/* 0x3b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)sockets));
x86_l_42:
	/* 0x42: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_47:
	/* 0x47: call   4c <tcp_v6_connect_ret+0x4c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_4c:
	/* 0x4c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4e:
	/* 0x4e: add    rsp,0x50 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_52:
	/* 0x52: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_55:
	/* 0x55: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_57:
	/* 0x57: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_59:
	/* 0x59: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5a:
	/* 0x5a: jmp    349 <tcp_v6_connect_ret+0x349> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_5f:
	/* 0x5f: mov    r15,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_62:
	/* 0x62: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&source_port));
x86_l_69:
	/* 0x69: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c:
	/* 0x6c: je     85 <tcp_v6_connect_ret+0x85> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6c, 0x85, x86_l_85);
x86_l_6e:
	/* 0x6e: lea    rax,[r15+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_72:
	/* 0x72: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_75:
	/* 0x75: jns    a2 <tcp_v6_connect_ret+0xa2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x75, 0xa2, x86_l_a2);
x86_l_77:
	/* 0x77: movzx  ebp,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_7a:
	/* 0x7a: lea    rax,[r15+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_7e:
	/* 0x7e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_81:
	/* 0x81: js     90 <tcp_v6_connect_ret+0x90> */
	X86_SIM_X86_JCC(X86_CC_S, 0x81, 0x90, x86_l_90);
x86_l_83:
	/* 0x83: jmp    ad <tcp_v6_connect_ret+0xad> */
	X86_SIM_X86_JMP(0x83, 0xad, x86_l_ad);
x86_l_85:
	/* 0x85: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_87:
	/* 0x87: lea    rax,[r15+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_8b:
	/* 0x8b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e:
	/* 0x8e: jns    ad <tcp_v6_connect_ret+0xad> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8e, 0xad, x86_l_ad);
x86_l_90:
	/* 0x90: movzx  r12d,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_94:
	/* 0x94: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_ports_len));
x86_l_9b:
	/* 0x9b: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9e:
	/* 0x9e: jne    bc <tcp_v6_connect_ret+0xbc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9e, 0xbc, x86_l_bc);
x86_l_a0:
	/* 0xa0: jmp    f3 <tcp_v6_connect_ret+0xf3> */
	X86_SIM_X86_JMP(0xa0, 0xf3, x86_l_f3);
x86_l_a2:
	/* 0xa2: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a4:
	/* 0xa4: lea    rax,[r15+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_a8:
	/* 0xa8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ab:
	/* 0xab: js     90 <tcp_v6_connect_ret+0x90> */
	X86_SIM_X86_JCC(X86_CC_S, 0xab, 0x90, x86_l_90);
x86_l_ad:
	/* 0xad: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b0:
	/* 0xb0: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_ports_len));
x86_l_b7:
	/* 0xb7: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ba:
	/* 0xba: je     f3 <tcp_v6_connect_ret+0xf3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xba, 0xf3, x86_l_f3);
x86_l_bc:
	/* 0xbc: cmp    DWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bf:
	/* 0xbf: jle    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xbf, 0x3b, x86_l_3b);
x86_l_c5:
	/* 0xc5: movzx  ecx,r12w */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RCX, X86_R12, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_c9:
	/* 0xc9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_cb:
	/* 0xcb: mov    rsi,QWORD PTR [rip+0xfffffffffffffffc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&filter_ports));
x86_l_d2:
	/* 0xd2: mov    edi,DWORD PTR [rsi+rdx*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 2), 0ULL);
x86_l_d5:
	/* 0xd5: cmp    edi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d7:
	/* 0xd7: je     f3 <tcp_v6_connect_ret+0xf3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd7, 0xf3, x86_l_f3);
x86_l_d9:
	/* 0xd9: movsxd rdi,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_dc:
	/* 0xdc: cmp    rdx,0x3e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 62ULL);
x86_l_e0:
	/* 0xe0: ja     3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe0, 0x3b, x86_l_3b);
x86_l_e6:
	/* 0xe6: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_e9:
	/* 0xe9: cmp    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_ec:
	/* 0xec: jl     d2 <tcp_v6_connect_ret+0xd2> */
	X86_SIM_X86_JCC(X86_CC_L, 0xec, 0xd2, x86_l_d2);
x86_l_ee:
	/* 0xee: jmp    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JMP(0xee, 0x3b, x86_l_3b);
x86_l_f3:
	/* 0xf3: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)&do_count));
x86_l_fa:
	/* 0xfa: cmp    BYTE PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fd:
	/* 0xfd: je     167 <tcp_v6_connect_ret+0x167> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfd, 0x167, x86_l_167);
x86_l_ff:
	/* 0xff: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_108:
	/* 0x108: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_111:
	/* 0x111: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_11a:
	/* 0x11a: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_123:
	/* 0x123: lea    rax,[r15+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_127:
	/* 0x127: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: jns    23a <tcp_v6_connect_ret+0x23a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12a, 0x23a, x86_l_23a);
x86_l_130:
	/* 0x130: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_133:
	/* 0x133: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_138:
	/* 0x138: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13c:
	/* 0x13c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_141:
	/* 0x141: add    r15,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_145:
	/* 0x145: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_148:
	/* 0x148: js     259 <tcp_v6_connect_ret+0x259> */
	X86_SIM_X86_JCC(X86_CC_S, 0x148, 0x259, x86_l_259);
x86_l_14e:
	/* 0x14e: lea    rax,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_153:
	/* 0x153: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_15b:
	/* 0x15b: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_162:
	/* 0x162: jmp    26a <tcp_v6_connect_ret+0x26a> */
	X86_SIM_X86_JMP(0x162, 0x26a, x86_l_26a);
x86_l_167:
	/* 0x167: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_16b:
	/* 0x16b: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_174:
	/* 0x174: mov    QWORD PTR [rsp+0x48],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_17d:
	/* 0x17d: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_186:
	/* 0x186: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_18f:
	/* 0x18f: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_198:
	/* 0x198: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_1a1:
	/* 0x1a1: mov    QWORD PTR [rsp+0x18],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1aa:
	/* 0x1aa: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1b3:
	/* 0x1b3: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_1bc:
	/* 0x1bc: mov    DWORD PTR [rsp+0x40],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906954ULL);
x86_l_1c4:
	/* 0x1c4: mov    DWORD PTR [rsp+0x44],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68ULL);
x86_l_1c9:
	/* 0x1c9: call   1ce <tcp_v6_connect_ret+0x1ce> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_1ce:
	/* 0x1ce: mov    DWORD PTR [rsp+0x48],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1d2:
	/* 0x1d2: call   1d7 <tcp_v6_connect_ret+0x1d7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_ns);
x86_l_1d7:
	/* 0x1d7: shr    rax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_1db:
	/* 0x1db: movabs rcx,0x20c49ba5e353f7cf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 2361183241434822607ULL);
x86_l_1e5:
	/* 0x1e5: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e8:
	/* 0x1e8: mulx   rax,rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MULX, X86_RAX, X86_RCX, X86_WIDTH_64, X86_RAX, 0);
x86_l_1ed:
	/* 0x1ed: shr    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 4ULL);
x86_l_1f1:
	/* 0x1f1: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1f6:
	/* 0x1f6: lea    rax,[r15+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1fa:
	/* 0x1fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fd:
	/* 0x1fd: jns    2db <tcp_v6_connect_ret+0x2db> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fd, 0x2db, x86_l_2db);
x86_l_203:
	/* 0x203: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_206:
	/* 0x206: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b:
	/* 0x20b: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20f:
	/* 0x20f: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_214:
	/* 0x214: add    r15,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_218:
	/* 0x218: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_21b:
	/* 0x21b: js     2fa <tcp_v6_connect_ret+0x2fa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x21b, 0x2fa, x86_l_2fa);
x86_l_221:
	/* 0x221: lea    rax,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_226:
	/* 0x226: mov    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_22e:
	/* 0x22e: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_235:
	/* 0x235: jmp    30b <tcp_v6_connect_ret+0x30b> */
	X86_SIM_X86_JMP(0x235, 0x30b, x86_l_30b);
x86_l_23a:
	/* 0x23a: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_243:
	/* 0x243: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_24c:
	/* 0x24c: add    r15,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_250:
	/* 0x250: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_253:
	/* 0x253: jns    14e <tcp_v6_connect_ret+0x14e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x253, 0x14e, x86_l_14e);
x86_l_259:
	/* 0x259: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25c:
	/* 0x25c: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_261:
	/* 0x261: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_265:
	/* 0x265: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_26a:
	/* 0x26a: mov    WORD PTR [rsp+0x28],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_26f:
	/* 0x26f: mov    WORD PTR [rsp+0x2a],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 42ULL);
x86_l_275:
	/* 0x275: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ipv6_count));
x86_l_27c:
	/* 0x27c: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_281:
	/* 0x281: call   286 <tcp_v6_connect_ret+0x286> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_286:
	/* 0x286: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_289:
	/* 0x289: je     294 <tcp_v6_connect_ret+0x294> */
	X86_SIM_X86_JCC(X86_CC_E, 0x289, 0x294, x86_l_294);
x86_l_28b:
	/* 0x28b: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_28f:
	/* 0x28f: jmp    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JMP(0x28f, 0x3b, x86_l_3b);
x86_l_294:
	/* 0x294: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ipv6_count));
x86_l_29b:
	/* 0x29b: lea    rdx,[rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_2a2:
	/* 0x2a2: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a7:
	/* 0x2a7: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2ac:
	/* 0x2ac: call   2b1 <tcp_v6_connect_ret+0x2b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_update_elem);
x86_l_2b1:
	/* 0x2b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b4:
	/* 0x2b4: je     2c0 <tcp_v6_connect_ret+0x2c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b4, 0x2c0, x86_l_2c0);
x86_l_2b6:
	/* 0x2b6: cmp    rax,0xffffffffffffffef */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551599ULL);
x86_l_2ba:
	/* 0x2ba: jne    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ba, 0x3b, x86_l_3b);
x86_l_2c0:
	/* 0x2c0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)ipv6_count));
x86_l_2c7:
	/* 0x2c7: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cc:
	/* 0x2cc: call   2d1 <tcp_v6_connect_ret+0x2d1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d1:
	/* 0x2d1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d4:
	/* 0x2d4: jne    28b <tcp_v6_connect_ret+0x28b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d4, 0x28b, x86_l_28b);
x86_l_2d6:
	/* 0x2d6: jmp    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JMP(0x2d6, 0x3b, x86_l_3b);
x86_l_2db:
	/* 0x2db: mov    QWORD PTR [rsp+0x10],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_2e4:
	/* 0x2e4: mov    QWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_2ed:
	/* 0x2ed: add    r15,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 56ULL);
x86_l_2f1:
	/* 0x2f1: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2f4:
	/* 0x2f4: jns    221 <tcp_v6_connect_ret+0x221> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f4, 0x221, x86_l_221);
x86_l_2fa:
	/* 0x2fa: mov    rax,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fd:
	/* 0x2fd: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_302:
	/* 0x302: mov    rax,QWORD PTR [r15+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_306:
	/* 0x306: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30b:
	/* 0x30b: mov    WORD PTR [rsp+0x4c],bp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_310:
	/* 0x310: mov    WORD PTR [rsp+0x4e],r12w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 78ULL);
x86_l_316:
	/* 0x316: lea    rdi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_31b:
	/* 0x31b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_320:
	/* 0x320: call   325 <tcp_v6_connect_ret+0x325> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_comm);
x86_l_325:
	/* 0x325: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)events));
x86_l_32c:
	/* 0x32c: lea    rcx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_331:
	/* 0x331: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_336:
	/* 0x336: mov    r8d,0x48 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 72ULL);
x86_l_33c:
	/* 0x33c: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_33f:
	/* 0x33f: call   344 <tcp_v6_connect_ret+0x344> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_344:
	/* 0x344: jmp    3b <tcp_v6_connect_ret+0x3b> */
	X86_SIM_X86_JMP(0x344, 0x3b, x86_l_3b);
x86_l_349:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
