#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 168U
#define X86_SIM_STACK_VALUE_WORDS(M) M(8) M(9) M(10) M(11) M(12) M(13) M(14)
#include "../x86_sim_local_bpf.h"

extern __u8 signal_data_map[] __ksym;
extern __u8 signals[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("raw_tracepoint/sched_process_fork")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 120ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x38b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signal_data_map));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_25:
	/* 0x25: call   38da <sched_process_fork_signal+0x38da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2a:
	/* 0x2a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: je     d36 <sched_process_fork_signal+0xd36> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d, 0xd36, x86_l_d36);
x86_l_33:
	/* 0x33: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: mov    DWORD PTR [rax],0x138a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 5002ULL);
x86_l_3c:
	/* 0x3c: mov    BYTE PTR [rax+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_40:
	/* 0x40: mov    WORD PTR [rax+0x7d06],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 137464723275776ULL);
x86_l_49:
	/* 0x49: mov    r15,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c:
	/* 0x4c: mov    rbp,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_50:
	/* 0x50: lea    rax,[rbp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_54:
	/* 0x54: mov    QWORD PTR [rsp+0x68],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_59:
	/* 0x59: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5c:
	/* 0x5c: jns    6f <sched_process_fork_signal+0x6f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x5c, 0x6f, x86_l_6f);
x86_l_5e:
	/* 0x5e: mov    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61:
	/* 0x61: lea    rax,[r12+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_66:
	/* 0x66: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_69:
	/* 0x69: js     7c <sched_process_fork_signal+0x7c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x69, 0x7c, x86_l_7c);
x86_l_6b:
	/* 0x6b: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6d:
	/* 0x6d: jmp    7f <sched_process_fork_signal+0x7f> */
	X86_SIM_X86_JMP(0x6d, 0x7f, x86_l_7f);
x86_l_6f:
	/* 0x6f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_72:
	/* 0x72: lea    rax,[r12+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_77:
	/* 0x77: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a:
	/* 0x7a: jns    6b <sched_process_fork_signal+0x6b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7a, 0x6b, x86_l_6b);
x86_l_7c:
	/* 0x7c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7f:
	/* 0x7f: add    rax,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_83:
	/* 0x83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86:
	/* 0x86: mov    QWORD PTR [rsp+0x70],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_8b:
	/* 0x8b: jns    92 <sched_process_fork_signal+0x92> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8b, 0x92, x86_l_92);
x86_l_8d:
	/* 0x8d: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_90:
	/* 0x90: jmp    95 <sched_process_fork_signal+0x95> */
	X86_SIM_X86_JMP(0x90, 0x95, x86_l_95);
x86_l_92:
	/* 0x92: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_95:
	/* 0x95: call   394a <sched_process_fork_signal+0x394a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_9a:
	/* 0x9a: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_9f:
	/* 0x9f: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_a7:
	/* 0xa7: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_ae:
	/* 0xae: ja     109 <sched_process_fork_signal+0x109> */
	X86_SIM_X86_JCC(X86_CC_A, 0xae, 0x109, x86_l_109);
x86_l_b0:
	/* 0xb0: mov    BYTE PTR [r14+rbx*1+0x5],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836480ULL);
x86_l_b6:
	/* 0xb6: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_bc:
	/* 0xbc: ja     109 <sched_process_fork_signal+0x109> */
	X86_SIM_X86_JCC(X86_CC_A, 0xbc, 0x109, x86_l_109);
x86_l_be:
	/* 0xbe: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_c2:
	/* 0xc2: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_c6:
	/* 0xc6: lea    rax,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_cb:
	/* 0xcb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ce:
	/* 0xce: jns    dd <sched_process_fork_signal+0xdd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xce, 0xdd, x86_l_dd);
x86_l_d0:
	/* 0xd0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d3:
	/* 0xd3: jns    102 <sched_process_fork_signal+0x102> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xd3, 0x102, x86_l_102);
x86_l_d5:
	/* 0xd5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d8:
	/* 0xd8: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_db:
	/* 0xdb: jmp    f1 <sched_process_fork_signal+0xf1> */
	X86_SIM_X86_JMP(0xdb, 0xf1, x86_l_f1);
x86_l_dd:
	/* 0xdd: lea    rdx,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e2:
	/* 0xe2: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_e7:
	/* 0xe7: call   399c <sched_process_fork_signal+0x399c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_ec:
	/* 0xec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ef:
	/* 0xef: js     109 <sched_process_fork_signal+0x109> */
	X86_SIM_X86_JCC(X86_CC_S, 0xef, 0x109, x86_l_109);
x86_l_f1:
	/* 0xf1: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_f4:
	/* 0xf4: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_fc:
	/* 0xfc: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_100:
	/* 0x100: jmp    109 <sched_process_fork_signal+0x109> */
	X86_SIM_X86_JMP(0x100, 0x109, x86_l_109);
x86_l_102:
	/* 0x102: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_109:
	/* 0x109: lea    rcx,[r15+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_10d:
	/* 0x10d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10f:
	/* 0x10f: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_112:
	/* 0x112: jns    119 <sched_process_fork_signal+0x119> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x112, 0x119, x86_l_119);
x86_l_114:
	/* 0x114: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_117:
	/* 0x117: jmp    11b <sched_process_fork_signal+0x11b> */
	X86_SIM_X86_JMP(0x117, 0x11b, x86_l_11b);
x86_l_119:
	/* 0x119: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b:
	/* 0x11b: mov    QWORD PTR [rsp+0x60],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_120:
	/* 0x120: lea    rcx,[r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_124:
	/* 0x124: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_127:
	/* 0x127: jns    12b <sched_process_fork_signal+0x12b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x127, 0x12b, x86_l_12b);
x86_l_129:
	/* 0x129: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_12b:
	/* 0x12b: mov    DWORD PTR [rsp+0x3c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_12f:
	/* 0x12f: lea    rcx,[r15+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_133:
	/* 0x133: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_135:
	/* 0x135: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_138:
	/* 0x138: jns    13c <sched_process_fork_signal+0x13c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x138, 0x13c, x86_l_13c);
x86_l_13a:
	/* 0x13a: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13c:
	/* 0x13c: mov    DWORD PTR [rsp+0x38],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_140:
	/* 0x140: lea    rax,[r15+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_144:
	/* 0x144: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_147:
	/* 0x147: jns    14e <sched_process_fork_signal+0x14e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x147, 0x14e, x86_l_14e);
x86_l_149:
	/* 0x149: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14c:
	/* 0x14c: jmp    150 <sched_process_fork_signal+0x150> */
	X86_SIM_X86_JMP(0x14c, 0x150, x86_l_150);
x86_l_14e:
	/* 0x14e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_150:
	/* 0x150: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_154:
	/* 0x154: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_156:
	/* 0x156: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_159:
	/* 0x159: jns    168 <sched_process_fork_signal+0x168> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x159, 0x168, x86_l_168);
x86_l_15b:
	/* 0x15b: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_15e:
	/* 0x15e: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_161:
	/* 0x161: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_164:
	/* 0x164: js     172 <sched_process_fork_signal+0x172> */
	X86_SIM_X86_JCC(X86_CC_S, 0x164, 0x172, x86_l_172);
x86_l_166:
	/* 0x166: jmp    174 <sched_process_fork_signal+0x174> */
	X86_SIM_X86_JMP(0x166, 0x174, x86_l_174);
x86_l_168:
	/* 0x168: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_16a:
	/* 0x16a: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_16d:
	/* 0x16d: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_170:
	/* 0x170: jns    174 <sched_process_fork_signal+0x174> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x170, 0x174, x86_l_174);
x86_l_172:
	/* 0x172: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_174:
	/* 0x174: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_176:
	/* 0x176: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_17a:
	/* 0x17a: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17d:
	/* 0x17d: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_181:
	/* 0x181: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_183:
	/* 0x183: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_186:
	/* 0x186: jns    18a <sched_process_fork_signal+0x18a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x186, 0x18a, x86_l_18a);
x86_l_188:
	/* 0x188: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18a:
	/* 0x18a: mov    DWORD PTR [rsp+0x34],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_18e:
	/* 0x18e: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_192:
	/* 0x192: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_194:
	/* 0x194: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_197:
	/* 0x197: jns    1a6 <sched_process_fork_signal+0x1a6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x197, 0x1a6, x86_l_1a6);
x86_l_199:
	/* 0x199: mov    rcx,QWORD PTR [r15] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19c:
	/* 0x19c: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_19f:
	/* 0x19f: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1a2:
	/* 0x1a2: js     1b0 <sched_process_fork_signal+0x1b0> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a2, 0x1b0, x86_l_1b0);
x86_l_1a4:
	/* 0x1a4: jmp    1b2 <sched_process_fork_signal+0x1b2> */
	X86_SIM_X86_JMP(0x1a4, 0x1b2, x86_l_1b2);
x86_l_1a6:
	/* 0x1a6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a8:
	/* 0x1a8: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ab:
	/* 0x1ab: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1ae:
	/* 0x1ae: jns    1b2 <sched_process_fork_signal+0x1b2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ae, 0x1b2, x86_l_1b2);
x86_l_1b0:
	/* 0x1b0: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b2:
	/* 0x1b2: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1b4:
	/* 0x1b4: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_1b8:
	/* 0x1b8: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1bb:
	/* 0x1bb: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1bf:
	/* 0x1bf: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c1:
	/* 0x1c1: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1c4:
	/* 0x1c4: jns    1c8 <sched_process_fork_signal+0x1c8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1c4, 0x1c8, x86_l_1c8);
x86_l_1c6:
	/* 0x1c6: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c8:
	/* 0x1c8: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1cc:
	/* 0x1cc: lea    rcx,[rbp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1d0:
	/* 0x1d0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d2:
	/* 0x1d2: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d5:
	/* 0x1d5: jns    1dc <sched_process_fork_signal+0x1dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1d5, 0x1dc, x86_l_1dc);
x86_l_1d7:
	/* 0x1d7: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1da:
	/* 0x1da: jmp    1de <sched_process_fork_signal+0x1de> */
	X86_SIM_X86_JMP(0x1da, 0x1de, x86_l_1de);
x86_l_1dc:
	/* 0x1dc: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1de:
	/* 0x1de: mov    QWORD PTR [rsp+0x58],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1e3:
	/* 0x1e3: lea    rcx,[rbp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e7:
	/* 0x1e7: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1ea:
	/* 0x1ea: jns    1ee <sched_process_fork_signal+0x1ee> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1ea, 0x1ee, x86_l_1ee);
x86_l_1ec:
	/* 0x1ec: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ee:
	/* 0x1ee: mov    DWORD PTR [rsp+0x2c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1f2:
	/* 0x1f2: lea    rcx,[rbp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1f6:
	/* 0x1f6: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1f8:
	/* 0x1f8: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fb:
	/* 0x1fb: jns    1ff <sched_process_fork_signal+0x1ff> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1fb, 0x1ff, x86_l_1ff);
x86_l_1fd:
	/* 0x1fd: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff:
	/* 0x1ff: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_203:
	/* 0x203: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_208:
	/* 0x208: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20b:
	/* 0x20b: jns    212 <sched_process_fork_signal+0x212> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x20b, 0x212, x86_l_212);
x86_l_20d:
	/* 0x20d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_210:
	/* 0x210: jmp    214 <sched_process_fork_signal+0x214> */
	X86_SIM_X86_JMP(0x210, 0x214, x86_l_214);
x86_l_212:
	/* 0x212: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_214:
	/* 0x214: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_218:
	/* 0x218: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21a:
	/* 0x21a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_21d:
	/* 0x21d: jns    22c <sched_process_fork_signal+0x22c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x21d, 0x22c, x86_l_22c);
x86_l_21f:
	/* 0x21f: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_222:
	/* 0x222: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_225:
	/* 0x225: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_228:
	/* 0x228: js     236 <sched_process_fork_signal+0x236> */
	X86_SIM_X86_JCC(X86_CC_S, 0x228, 0x236, x86_l_236);
x86_l_22a:
	/* 0x22a: jmp    238 <sched_process_fork_signal+0x238> */
	X86_SIM_X86_JMP(0x22a, 0x238, x86_l_238);
x86_l_22c:
	/* 0x22c: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_22e:
	/* 0x22e: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_231:
	/* 0x231: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_234:
	/* 0x234: jns    238 <sched_process_fork_signal+0x238> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x234, 0x238, x86_l_238);
x86_l_236:
	/* 0x236: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_238:
	/* 0x238: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_23a:
	/* 0x23a: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_23e:
	/* 0x23e: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_241:
	/* 0x241: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_245:
	/* 0x245: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_247:
	/* 0x247: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_24a:
	/* 0x24a: jns    24e <sched_process_fork_signal+0x24e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x24a, 0x24e, x86_l_24e);
x86_l_24c:
	/* 0x24c: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24e:
	/* 0x24e: mov    DWORD PTR [rsp+0x24],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_252:
	/* 0x252: add    rbp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_256:
	/* 0x256: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_258:
	/* 0x258: test   rbp,rbp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_25b:
	/* 0x25b: jns    26b <sched_process_fork_signal+0x26b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x25b, 0x26b, x86_l_26b);
x86_l_25d:
	/* 0x25d: mov    rcx,QWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_261:
	/* 0x261: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_264:
	/* 0x264: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_267:
	/* 0x267: js     275 <sched_process_fork_signal+0x275> */
	X86_SIM_X86_JCC(X86_CC_S, 0x267, 0x275, x86_l_275);
x86_l_269:
	/* 0x269: jmp    277 <sched_process_fork_signal+0x277> */
	X86_SIM_X86_JMP(0x269, 0x277, x86_l_277);
x86_l_26b:
	/* 0x26b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_26d:
	/* 0x26d: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_270:
	/* 0x270: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_273:
	/* 0x273: jns    277 <sched_process_fork_signal+0x277> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x273, 0x277, x86_l_277);
x86_l_275:
	/* 0x275: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_277:
	/* 0x277: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_279:
	/* 0x279: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_27d:
	/* 0x27d: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_280:
	/* 0x280: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_284:
	/* 0x284: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_286:
	/* 0x286: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_289:
	/* 0x289: jns    28d <sched_process_fork_signal+0x28d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x289, 0x28d, x86_l_28d);
x86_l_28b:
	/* 0x28b: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_28d:
	/* 0x28d: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_291:
	/* 0x291: lea    rcx,[r13+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_295:
	/* 0x295: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_297:
	/* 0x297: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: jns    2a1 <sched_process_fork_signal+0x2a1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x29a, 0x2a1, x86_l_2a1);
x86_l_29c:
	/* 0x29c: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29f:
	/* 0x29f: jmp    2a3 <sched_process_fork_signal+0x2a3> */
	X86_SIM_X86_JMP(0x29f, 0x2a3, x86_l_2a3);
x86_l_2a1:
	/* 0x2a1: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a3:
	/* 0x2a3: mov    QWORD PTR [rsp+0x50],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2a8:
	/* 0x2a8: lea    rcx,[r13+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2ac:
	/* 0x2ac: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2af:
	/* 0x2af: jns    2b3 <sched_process_fork_signal+0x2b3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2af, 0x2b3, x86_l_2b3);
x86_l_2b1:
	/* 0x2b1: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3:
	/* 0x2b3: mov    DWORD PTR [rsp+0x1c],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2b7:
	/* 0x2b7: lea    rcx,[r13+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2bb:
	/* 0x2bb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2bd:
	/* 0x2bd: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c0:
	/* 0x2c0: jns    2c4 <sched_process_fork_signal+0x2c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2c0, 0x2c4, x86_l_2c4);
x86_l_2c2:
	/* 0x2c2: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c4:
	/* 0x2c4: mov    DWORD PTR [rsp+0x18],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c8:
	/* 0x2c8: lea    rax,[r13+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2cc:
	/* 0x2cc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cf:
	/* 0x2cf: jns    2d6 <sched_process_fork_signal+0x2d6> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2cf, 0x2d6, x86_l_2d6);
x86_l_2d1:
	/* 0x2d1: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d4:
	/* 0x2d4: jmp    2d8 <sched_process_fork_signal+0x2d8> */
	X86_SIM_X86_JMP(0x2d4, 0x2d8, x86_l_2d8);
x86_l_2d6:
	/* 0x2d6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d8:
	/* 0x2d8: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2dc:
	/* 0x2dc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2de:
	/* 0x2de: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e1:
	/* 0x2e1: jns    2f0 <sched_process_fork_signal+0x2f0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2e1, 0x2f0, x86_l_2f0);
x86_l_2e3:
	/* 0x2e3: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e6:
	/* 0x2e6: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e9:
	/* 0x2e9: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ec:
	/* 0x2ec: js     2fa <sched_process_fork_signal+0x2fa> */
	X86_SIM_X86_JCC(X86_CC_S, 0x2ec, 0x2fa, x86_l_2fa);
x86_l_2ee:
	/* 0x2ee: jmp    2fc <sched_process_fork_signal+0x2fc> */
	X86_SIM_X86_JMP(0x2ee, 0x2fc, x86_l_2fc);
x86_l_2f0:
	/* 0x2f0: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2f2:
	/* 0x2f2: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f5:
	/* 0x2f5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2f8:
	/* 0x2f8: jns    2fc <sched_process_fork_signal+0x2fc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2f8, 0x2fc, x86_l_2fc);
x86_l_2fa:
	/* 0x2fa: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2fc:
	/* 0x2fc: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2fe:
	/* 0x2fe: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_302:
	/* 0x302: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_305:
	/* 0x305: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_309:
	/* 0x309: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_30b:
	/* 0x30b: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_30e:
	/* 0x30e: jns    312 <sched_process_fork_signal+0x312> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x30e, 0x312, x86_l_312);
x86_l_310:
	/* 0x310: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_312:
	/* 0x312: mov    DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_316:
	/* 0x316: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_31a:
	/* 0x31a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_31c:
	/* 0x31c: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_31f:
	/* 0x31f: jns    32f <sched_process_fork_signal+0x32f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x31f, 0x32f, x86_l_32f);
x86_l_321:
	/* 0x321: mov    rcx,QWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_325:
	/* 0x325: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_328:
	/* 0x328: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_32b:
	/* 0x32b: js     339 <sched_process_fork_signal+0x339> */
	X86_SIM_X86_JCC(X86_CC_S, 0x32b, 0x339, x86_l_339);
x86_l_32d:
	/* 0x32d: jmp    33b <sched_process_fork_signal+0x33b> */
	X86_SIM_X86_JMP(0x32d, 0x33b, x86_l_33b);
x86_l_32f:
	/* 0x32f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_331:
	/* 0x331: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_334:
	/* 0x334: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_337:
	/* 0x337: jns    33b <sched_process_fork_signal+0x33b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x337, 0x33b, x86_l_33b);
x86_l_339:
	/* 0x339: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_33b:
	/* 0x33b: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_33d:
	/* 0x33d: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_341:
	/* 0x341: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_344:
	/* 0x344: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_348:
	/* 0x348: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_34a:
	/* 0x34a: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_34d:
	/* 0x34d: jns    351 <sched_process_fork_signal+0x351> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x34d, 0x351, x86_l_351);
x86_l_34f:
	/* 0x34f: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_351:
	/* 0x351: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_355:
	/* 0x355: lea    rcx,[r12+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_35a:
	/* 0x35a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_35c:
	/* 0x35c: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_35f:
	/* 0x35f: jns    366 <sched_process_fork_signal+0x366> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x35f, 0x366, x86_l_366);
x86_l_361:
	/* 0x361: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_364:
	/* 0x364: jmp    368 <sched_process_fork_signal+0x368> */
	X86_SIM_X86_JMP(0x364, 0x368, x86_l_368);
x86_l_366:
	/* 0x366: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_368:
	/* 0x368: mov    QWORD PTR [rsp+0x48],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_36d:
	/* 0x36d: lea    rcx,[r12+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_372:
	/* 0x372: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_375:
	/* 0x375: jns    379 <sched_process_fork_signal+0x379> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x375, 0x379, x86_l_379);
x86_l_377:
	/* 0x377: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_379:
	/* 0x379: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_37d:
	/* 0x37d: lea    rcx,[r12+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_382:
	/* 0x382: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_384:
	/* 0x384: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_387:
	/* 0x387: jns    38b <sched_process_fork_signal+0x38b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x387, 0x38b, x86_l_38b);
x86_l_389:
	/* 0x389: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_38b:
	/* 0x38b: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_38f:
	/* 0x38f: lea    rax,[r12+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_394:
	/* 0x394: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_397:
	/* 0x397: jns    39e <sched_process_fork_signal+0x39e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x397, 0x39e, x86_l_39e);
x86_l_399:
	/* 0x399: mov    rcx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_39c:
	/* 0x39c: jmp    3a0 <sched_process_fork_signal+0x3a0> */
	X86_SIM_X86_JMP(0x39c, 0x3a0, x86_l_3a0);
x86_l_39e:
	/* 0x39e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a0:
	/* 0x3a0: add    rcx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3a4:
	/* 0x3a4: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3a6:
	/* 0x3a6: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3a9:
	/* 0x3a9: jns    3b8 <sched_process_fork_signal+0x3b8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3a9, 0x3b8, x86_l_3b8);
x86_l_3ab:
	/* 0x3ab: mov    rcx,QWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ae:
	/* 0x3ae: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3b1:
	/* 0x3b1: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3b4:
	/* 0x3b4: js     3c2 <sched_process_fork_signal+0x3c2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3b4, 0x3c2, x86_l_3c2);
x86_l_3b6:
	/* 0x3b6: jmp    3c4 <sched_process_fork_signal+0x3c4> */
	X86_SIM_X86_JMP(0x3b6, 0x3c4, x86_l_3c4);
x86_l_3b8:
	/* 0x3b8: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3ba:
	/* 0x3ba: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3bd:
	/* 0x3bd: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3c0:
	/* 0x3c0: jns    3c4 <sched_process_fork_signal+0x3c4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3c0, 0x3c4, x86_l_3c4);
x86_l_3c2:
	/* 0x3c2: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3c4:
	/* 0x3c4: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_3c6:
	/* 0x3c6: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_3ca:
	/* 0x3ca: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_3cd:
	/* 0x3cd: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3d1:
	/* 0x3d1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3d3:
	/* 0x3d3: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3d6:
	/* 0x3d6: jns    3da <sched_process_fork_signal+0x3da> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3d6, 0x3da, x86_l_3da);
x86_l_3d8:
	/* 0x3d8: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3da:
	/* 0x3da: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3de:
	/* 0x3de: add    r12,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3e2:
	/* 0x3e2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e4:
	/* 0x3e4: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3e7:
	/* 0x3e7: jns    3f7 <sched_process_fork_signal+0x3f7> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3e7, 0x3f7, x86_l_3f7);
x86_l_3e9:
	/* 0x3e9: mov    rcx,QWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3ed:
	/* 0x3ed: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3f0:
	/* 0x3f0: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3f3:
	/* 0x3f3: js     401 <sched_process_fork_signal+0x401> */
	X86_SIM_X86_JCC(X86_CC_S, 0x3f3, 0x401, x86_l_401);
x86_l_3f5:
	/* 0x3f5: jmp    403 <sched_process_fork_signal+0x403> */
	X86_SIM_X86_JMP(0x3f5, 0x403, x86_l_403);
x86_l_3f7:
	/* 0x3f7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3f9:
	/* 0x3f9: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_3fc:
	/* 0x3fc: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_3ff:
	/* 0x3ff: jns    403 <sched_process_fork_signal+0x403> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x3ff, 0x403, x86_l_403);
x86_l_401:
	/* 0x401: mov    eax,DWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_403:
	/* 0x403: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_405:
	/* 0x405: shl    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_409:
	/* 0x409: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_40c:
	/* 0x40c: add    rcx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_410:
	/* 0x410: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_412:
	/* 0x412: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_415:
	/* 0x415: jns    419 <sched_process_fork_signal+0x419> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x415, 0x419, x86_l_419);
x86_l_417:
	/* 0x417: mov    eax,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_419:
	/* 0x419: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_41c:
	/* 0x41c: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_424:
	/* 0x424: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_42b:
	/* 0x42b: ja     47f <sched_process_fork_signal+0x47f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x42b, 0x47f, x86_l_47f);
x86_l_42d:
	/* 0x42d: mov    BYTE PTR [r14+rbx*1+0x5],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836481ULL);
x86_l_433:
	/* 0x433: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_439:
	/* 0x439: ja     47f <sched_process_fork_signal+0x47f> */
	X86_SIM_X86_JCC(X86_CC_A, 0x439, 0x47f, x86_l_47f);
x86_l_43b:
	/* 0x43b: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_43f:
	/* 0x43f: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_443:
	/* 0x443: lea    rax,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_448:
	/* 0x448: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_44b:
	/* 0x44b: jns    45c <sched_process_fork_signal+0x45c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x44b, 0x45c, x86_l_45c);
x86_l_44d:
	/* 0x44d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_450:
	/* 0x450: jns    4e0 <sched_process_fork_signal+0x4e0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x450, 0x4e0, x86_l_4e0);
x86_l_456:
	/* 0x456: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_458:
	/* 0x458: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_45a:
	/* 0x45a: jmp    470 <sched_process_fork_signal+0x470> */
	X86_SIM_X86_JMP(0x45a, 0x470, x86_l_470);
x86_l_45c:
	/* 0x45c: lea    rdx,[rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_461:
	/* 0x461: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_466:
	/* 0x466: call   3d1b <sched_process_fork_signal+0x3d1b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_46b:
	/* 0x46b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_46e:
	/* 0x46e: js     47f <sched_process_fork_signal+0x47f> */
	X86_SIM_X86_JCC(X86_CC_S, 0x46e, 0x47f, x86_l_47f);
x86_l_470:
	/* 0x470: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_473:
	/* 0x473: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_47b:
	/* 0x47b: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_47f:
	/* 0x47f: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_487:
	/* 0x487: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_48e:
	/* 0x48e: ja     4ff <sched_process_fork_signal+0x4ff> */
	X86_SIM_X86_JCC(X86_CC_A, 0x48e, 0x4ff, x86_l_4ff);
x86_l_490:
	/* 0x490: mov    BYTE PTR [r14+rbx*1+0x5],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836482ULL);
x86_l_496:
	/* 0x496: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_49c:
	/* 0x49c: ja     4ff <sched_process_fork_signal+0x4ff> */
	X86_SIM_X86_JCC(X86_CC_A, 0x49c, 0x4ff, x86_l_4ff);
x86_l_49e:
	/* 0x49e: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_4a2:
	/* 0x4a2: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_4a6:
	/* 0x4a6: lea    rax,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4ab:
	/* 0x4ab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4ae:
	/* 0x4ae: jns    4bb <sched_process_fork_signal+0x4bb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4ae, 0x4bb, x86_l_4bb);
x86_l_4b0:
	/* 0x4b0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4b3:
	/* 0x4b3: jns    4f9 <sched_process_fork_signal+0x4f9> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x4b3, 0x4f9, x86_l_4f9);
x86_l_4b5:
	/* 0x4b5: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b7:
	/* 0x4b7: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b9:
	/* 0x4b9: jmp    4cf <sched_process_fork_signal+0x4cf> */
	X86_SIM_X86_JMP(0x4b9, 0x4cf, x86_l_4cf);
x86_l_4bb:
	/* 0x4bb: lea    rdx,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4c0:
	/* 0x4c0: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_4c5:
	/* 0x4c5: call   3d7a <sched_process_fork_signal+0x3d7a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_4ca:
	/* 0x4ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4cd:
	/* 0x4cd: js     4ff <sched_process_fork_signal+0x4ff> */
	X86_SIM_X86_JCC(X86_CC_S, 0x4cd, 0x4ff, x86_l_4ff);
x86_l_4cf:
	/* 0x4cf: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_4d2:
	/* 0x4d2: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_4da:
	/* 0x4da: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_4de:
	/* 0x4de: jmp    4ff <sched_process_fork_signal+0x4ff> */
	X86_SIM_X86_JMP(0x4de, 0x4ff, x86_l_4ff);
x86_l_4e0:
	/* 0x4e0: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e6:
	/* 0x4e6: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_4ee:
	/* 0x4ee: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_4f5:
	/* 0x4f5: jbe    490 <sched_process_fork_signal+0x490> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x4f5, 0x490, x86_l_490);
x86_l_4f7:
	/* 0x4f7: jmp    4ff <sched_process_fork_signal+0x4ff> */
	X86_SIM_X86_JMP(0x4f7, 0x4ff, x86_l_4ff);
x86_l_4f9:
	/* 0x4f9: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4ff:
	/* 0x4ff: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_507:
	/* 0x507: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_50e:
	/* 0x50e: ja     562 <sched_process_fork_signal+0x562> */
	X86_SIM_X86_JCC(X86_CC_A, 0x50e, 0x562, x86_l_562);
x86_l_510:
	/* 0x510: mov    BYTE PTR [r14+rbx*1+0x5],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836483ULL);
x86_l_516:
	/* 0x516: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_51c:
	/* 0x51c: ja     562 <sched_process_fork_signal+0x562> */
	X86_SIM_X86_JCC(X86_CC_A, 0x51c, 0x562, x86_l_562);
x86_l_51e:
	/* 0x51e: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_522:
	/* 0x522: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_526:
	/* 0x526: lea    rax,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_52b:
	/* 0x52b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_52e:
	/* 0x52e: jns    53f <sched_process_fork_signal+0x53f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x52e, 0x53f, x86_l_53f);
x86_l_530:
	/* 0x530: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_533:
	/* 0x533: jns    5c3 <sched_process_fork_signal+0x5c3> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x533, 0x5c3, x86_l_5c3);
x86_l_539:
	/* 0x539: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53b:
	/* 0x53b: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53d:
	/* 0x53d: jmp    553 <sched_process_fork_signal+0x553> */
	X86_SIM_X86_JMP(0x53d, 0x553, x86_l_553);
x86_l_53f:
	/* 0x53f: lea    rdx,[rsp+0x3c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_544:
	/* 0x544: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_549:
	/* 0x549: call   3dfe <sched_process_fork_signal+0x3dfe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_54e:
	/* 0x54e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_551:
	/* 0x551: js     562 <sched_process_fork_signal+0x562> */
	X86_SIM_X86_JCC(X86_CC_S, 0x551, 0x562, x86_l_562);
x86_l_553:
	/* 0x553: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_556:
	/* 0x556: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_55e:
	/* 0x55e: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_562:
	/* 0x562: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_56a:
	/* 0x56a: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_571:
	/* 0x571: ja     5e2 <sched_process_fork_signal+0x5e2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x571, 0x5e2, x86_l_5e2);
x86_l_573:
	/* 0x573: mov    BYTE PTR [r14+rbx*1+0x5],0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836484ULL);
x86_l_579:
	/* 0x579: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_57f:
	/* 0x57f: ja     5e2 <sched_process_fork_signal+0x5e2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x57f, 0x5e2, x86_l_5e2);
x86_l_581:
	/* 0x581: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_585:
	/* 0x585: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_589:
	/* 0x589: lea    rax,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_58e:
	/* 0x58e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_591:
	/* 0x591: jns    59e <sched_process_fork_signal+0x59e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x591, 0x59e, x86_l_59e);
x86_l_593:
	/* 0x593: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_596:
	/* 0x596: jns    5dc <sched_process_fork_signal+0x5dc> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x596, 0x5dc, x86_l_5dc);
x86_l_598:
	/* 0x598: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59a:
	/* 0x59a: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_59c:
	/* 0x59c: jmp    5b2 <sched_process_fork_signal+0x5b2> */
	X86_SIM_X86_JMP(0x59c, 0x5b2, x86_l_5b2);
x86_l_59e:
	/* 0x59e: lea    rdx,[rsp+0x34] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_5a3:
	/* 0x5a3: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_5a8:
	/* 0x5a8: call   3e5d <sched_process_fork_signal+0x3e5d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_5ad:
	/* 0x5ad: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b0:
	/* 0x5b0: js     5e2 <sched_process_fork_signal+0x5e2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x5b0, 0x5e2, x86_l_5e2);
x86_l_5b2:
	/* 0x5b2: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_5b5:
	/* 0x5b5: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_5bd:
	/* 0x5bd: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_5c1:
	/* 0x5c1: jmp    5e2 <sched_process_fork_signal+0x5e2> */
	X86_SIM_X86_JMP(0x5c1, 0x5e2, x86_l_5e2);
x86_l_5c3:
	/* 0x5c3: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c9:
	/* 0x5c9: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_5d1:
	/* 0x5d1: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_5d8:
	/* 0x5d8: jbe    573 <sched_process_fork_signal+0x573> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x5d8, 0x573, x86_l_573);
x86_l_5da:
	/* 0x5da: jmp    5e2 <sched_process_fork_signal+0x5e2> */
	X86_SIM_X86_JMP(0x5da, 0x5e2, x86_l_5e2);
x86_l_5dc:
	/* 0x5dc: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5e2:
	/* 0x5e2: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_5ea:
	/* 0x5ea: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_5f1:
	/* 0x5f1: ja     647 <sched_process_fork_signal+0x647> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5f1, 0x647, x86_l_647);
x86_l_5f3:
	/* 0x5f3: mov    BYTE PTR [r14+rbx*1+0x5],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836485ULL);
x86_l_5f9:
	/* 0x5f9: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_5ff:
	/* 0x5ff: ja     647 <sched_process_fork_signal+0x647> */
	X86_SIM_X86_JCC(X86_CC_A, 0x5ff, 0x647, x86_l_647);
x86_l_601:
	/* 0x601: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_605:
	/* 0x605: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_609:
	/* 0x609: lea    rax,[rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_60e:
	/* 0x60e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_611:
	/* 0x611: jns    624 <sched_process_fork_signal+0x624> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x611, 0x624, x86_l_624);
x86_l_613:
	/* 0x613: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_616:
	/* 0x616: jns    6a8 <sched_process_fork_signal+0x6a8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x616, 0x6a8, x86_l_6a8);
x86_l_61c:
	/* 0x61c: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61f:
	/* 0x61f: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_622:
	/* 0x622: jmp    638 <sched_process_fork_signal+0x638> */
	X86_SIM_X86_JMP(0x622, 0x638, x86_l_638);
x86_l_624:
	/* 0x624: lea    rdx,[rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_629:
	/* 0x629: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_62e:
	/* 0x62e: call   3ee3 <sched_process_fork_signal+0x3ee3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_633:
	/* 0x633: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_636:
	/* 0x636: js     647 <sched_process_fork_signal+0x647> */
	X86_SIM_X86_JCC(X86_CC_S, 0x636, 0x647, x86_l_647);
x86_l_638:
	/* 0x638: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_63b:
	/* 0x63b: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_643:
	/* 0x643: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_647:
	/* 0x647: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_64f:
	/* 0x64f: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_656:
	/* 0x656: ja     6c8 <sched_process_fork_signal+0x6c8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x656, 0x6c8, x86_l_6c8);
x86_l_658:
	/* 0x658: mov    BYTE PTR [r14+rbx*1+0x5],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836486ULL);
x86_l_65e:
	/* 0x65e: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_664:
	/* 0x664: ja     6c8 <sched_process_fork_signal+0x6c8> */
	X86_SIM_X86_JCC(X86_CC_A, 0x664, 0x6c8, x86_l_6c8);
x86_l_666:
	/* 0x666: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_66a:
	/* 0x66a: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_66e:
	/* 0x66e: lea    rax,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_673:
	/* 0x673: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_676:
	/* 0x676: jns    683 <sched_process_fork_signal+0x683> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x676, 0x683, x86_l_683);
x86_l_678:
	/* 0x678: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_67b:
	/* 0x67b: jns    6c2 <sched_process_fork_signal+0x6c2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x67b, 0x6c2, x86_l_6c2);
x86_l_67d:
	/* 0x67d: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_67f:
	/* 0x67f: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_681:
	/* 0x681: jmp    697 <sched_process_fork_signal+0x697> */
	X86_SIM_X86_JMP(0x681, 0x697, x86_l_697);
x86_l_683:
	/* 0x683: lea    rdx,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_688:
	/* 0x688: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_68d:
	/* 0x68d: call   3f42 <sched_process_fork_signal+0x3f42> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_692:
	/* 0x692: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_695:
	/* 0x695: js     6c8 <sched_process_fork_signal+0x6c8> */
	X86_SIM_X86_JCC(X86_CC_S, 0x695, 0x6c8, x86_l_6c8);
x86_l_697:
	/* 0x697: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_69a:
	/* 0x69a: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_6a2:
	/* 0x6a2: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_6a6:
	/* 0x6a6: jmp    6c8 <sched_process_fork_signal+0x6c8> */
	X86_SIM_X86_JMP(0x6a6, 0x6c8, x86_l_6c8);
x86_l_6a8:
	/* 0x6a8: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6af:
	/* 0x6af: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_6b7:
	/* 0x6b7: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_6be:
	/* 0x6be: jbe    658 <sched_process_fork_signal+0x658> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x6be, 0x658, x86_l_658);
x86_l_6c0:
	/* 0x6c0: jmp    6c8 <sched_process_fork_signal+0x6c8> */
	X86_SIM_X86_JMP(0x6c0, 0x6c8, x86_l_6c8);
x86_l_6c2:
	/* 0x6c2: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_6c8:
	/* 0x6c8: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_6d0:
	/* 0x6d0: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_6d7:
	/* 0x6d7: ja     72b <sched_process_fork_signal+0x72b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6d7, 0x72b, x86_l_72b);
x86_l_6d9:
	/* 0x6d9: mov    BYTE PTR [r14+rbx*1+0x5],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836487ULL);
x86_l_6df:
	/* 0x6df: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_6e5:
	/* 0x6e5: ja     72b <sched_process_fork_signal+0x72b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x6e5, 0x72b, x86_l_72b);
x86_l_6e7:
	/* 0x6e7: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_6eb:
	/* 0x6eb: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_6ef:
	/* 0x6ef: lea    rax,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6f4:
	/* 0x6f4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6f7:
	/* 0x6f7: jns    708 <sched_process_fork_signal+0x708> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6f7, 0x708, x86_l_708);
x86_l_6f9:
	/* 0x6f9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6fc:
	/* 0x6fc: jns    78c <sched_process_fork_signal+0x78c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x6fc, 0x78c, x86_l_78c);
x86_l_702:
	/* 0x702: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_704:
	/* 0x704: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_706:
	/* 0x706: jmp    71c <sched_process_fork_signal+0x71c> */
	X86_SIM_X86_JMP(0x706, 0x71c, x86_l_71c);
x86_l_708:
	/* 0x708: lea    rdx,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_70d:
	/* 0x70d: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_712:
	/* 0x712: call   3fc7 <sched_process_fork_signal+0x3fc7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_717:
	/* 0x717: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_71a:
	/* 0x71a: js     72b <sched_process_fork_signal+0x72b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x71a, 0x72b, x86_l_72b);
x86_l_71c:
	/* 0x71c: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_71f:
	/* 0x71f: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_727:
	/* 0x727: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_72b:
	/* 0x72b: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_733:
	/* 0x733: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_73a:
	/* 0x73a: ja     7ab <sched_process_fork_signal+0x7ab> */
	X86_SIM_X86_JCC(X86_CC_A, 0x73a, 0x7ab, x86_l_7ab);
x86_l_73c:
	/* 0x73c: mov    BYTE PTR [r14+rbx*1+0x5],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836488ULL);
x86_l_742:
	/* 0x742: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_748:
	/* 0x748: ja     7ab <sched_process_fork_signal+0x7ab> */
	X86_SIM_X86_JCC(X86_CC_A, 0x748, 0x7ab, x86_l_7ab);
x86_l_74a:
	/* 0x74a: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_74e:
	/* 0x74e: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_752:
	/* 0x752: lea    rax,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_757:
	/* 0x757: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_75a:
	/* 0x75a: jns    767 <sched_process_fork_signal+0x767> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x75a, 0x767, x86_l_767);
x86_l_75c:
	/* 0x75c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_75f:
	/* 0x75f: jns    7a5 <sched_process_fork_signal+0x7a5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x75f, 0x7a5, x86_l_7a5);
x86_l_761:
	/* 0x761: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_763:
	/* 0x763: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_765:
	/* 0x765: jmp    77b <sched_process_fork_signal+0x77b> */
	X86_SIM_X86_JMP(0x765, 0x77b, x86_l_77b);
x86_l_767:
	/* 0x767: lea    rdx,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_76c:
	/* 0x76c: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_771:
	/* 0x771: call   4026 <sched_process_fork_signal+0x4026> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_776:
	/* 0x776: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_779:
	/* 0x779: js     7ab <sched_process_fork_signal+0x7ab> */
	X86_SIM_X86_JCC(X86_CC_S, 0x779, 0x7ab, x86_l_7ab);
x86_l_77b:
	/* 0x77b: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_77e:
	/* 0x77e: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_786:
	/* 0x786: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_78a:
	/* 0x78a: jmp    7ab <sched_process_fork_signal+0x7ab> */
	X86_SIM_X86_JMP(0x78a, 0x7ab, x86_l_7ab);
x86_l_78c:
	/* 0x78c: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_792:
	/* 0x792: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_79a:
	/* 0x79a: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_7a1:
	/* 0x7a1: jbe    73c <sched_process_fork_signal+0x73c> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x7a1, 0x73c, x86_l_73c);
x86_l_7a3:
	/* 0x7a3: jmp    7ab <sched_process_fork_signal+0x7ab> */
	X86_SIM_X86_JMP(0x7a3, 0x7ab, x86_l_7ab);
x86_l_7a5:
	/* 0x7a5: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7ab:
	/* 0x7ab: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_7b3:
	/* 0x7b3: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_7ba:
	/* 0x7ba: ja     80e <sched_process_fork_signal+0x80e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7ba, 0x80e, x86_l_80e);
x86_l_7bc:
	/* 0x7bc: mov    BYTE PTR [r14+rbx*1+0x5],0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836489ULL);
x86_l_7c2:
	/* 0x7c2: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_7c8:
	/* 0x7c8: ja     80e <sched_process_fork_signal+0x80e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7c8, 0x80e, x86_l_80e);
x86_l_7ca:
	/* 0x7ca: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_7ce:
	/* 0x7ce: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_7d2:
	/* 0x7d2: lea    rax,[rsp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_7d7:
	/* 0x7d7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7da:
	/* 0x7da: jns    7eb <sched_process_fork_signal+0x7eb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7da, 0x7eb, x86_l_7eb);
x86_l_7dc:
	/* 0x7dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7df:
	/* 0x7df: jns    871 <sched_process_fork_signal+0x871> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x7df, 0x871, x86_l_871);
x86_l_7e5:
	/* 0x7e5: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e7:
	/* 0x7e7: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7e9:
	/* 0x7e9: jmp    7ff <sched_process_fork_signal+0x7ff> */
	X86_SIM_X86_JMP(0x7e9, 0x7ff, x86_l_7ff);
x86_l_7eb:
	/* 0x7eb: lea    rdx,[rsp+0x24] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_7f0:
	/* 0x7f0: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_7f5:
	/* 0x7f5: call   40aa <sched_process_fork_signal+0x40aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_7fa:
	/* 0x7fa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7fd:
	/* 0x7fd: js     80e <sched_process_fork_signal+0x80e> */
	X86_SIM_X86_JCC(X86_CC_S, 0x7fd, 0x80e, x86_l_80e);
x86_l_7ff:
	/* 0x7ff: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_802:
	/* 0x802: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_80a:
	/* 0x80a: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_80e:
	/* 0x80e: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_816:
	/* 0x816: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_81d:
	/* 0x81d: ja     891 <sched_process_fork_signal+0x891> */
	X86_SIM_X86_JCC(X86_CC_A, 0x81d, 0x891, x86_l_891);
x86_l_81f:
	/* 0x81f: mov    BYTE PTR [r14+rbx*1+0x5],0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836490ULL);
x86_l_825:
	/* 0x825: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_82b:
	/* 0x82b: ja     891 <sched_process_fork_signal+0x891> */
	X86_SIM_X86_JCC(X86_CC_A, 0x82b, 0x891, x86_l_891);
x86_l_82d:
	/* 0x82d: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_831:
	/* 0x831: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_835:
	/* 0x835: lea    rax,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_83a:
	/* 0x83a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_83d:
	/* 0x83d: jns    84c <sched_process_fork_signal+0x84c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x83d, 0x84c, x86_l_84c);
x86_l_83f:
	/* 0x83f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_842:
	/* 0x842: jns    88a <sched_process_fork_signal+0x88a> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x842, 0x88a, x86_l_88a);
x86_l_844:
	/* 0x844: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_847:
	/* 0x847: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_84a:
	/* 0x84a: jmp    860 <sched_process_fork_signal+0x860> */
	X86_SIM_X86_JMP(0x84a, 0x860, x86_l_860);
x86_l_84c:
	/* 0x84c: lea    rdx,[rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_851:
	/* 0x851: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_856:
	/* 0x856: call   410b <sched_process_fork_signal+0x410b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_85b:
	/* 0x85b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85e:
	/* 0x85e: js     891 <sched_process_fork_signal+0x891> */
	X86_SIM_X86_JCC(X86_CC_S, 0x85e, 0x891, x86_l_891);
x86_l_860:
	/* 0x860: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_863:
	/* 0x863: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_86b:
	/* 0x86b: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_86f:
	/* 0x86f: jmp    891 <sched_process_fork_signal+0x891> */
	X86_SIM_X86_JMP(0x86f, 0x891, x86_l_891);
x86_l_871:
	/* 0x871: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_877:
	/* 0x877: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_87f:
	/* 0x87f: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_886:
	/* 0x886: jbe    81f <sched_process_fork_signal+0x81f> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x886, 0x81f, x86_l_81f);
x86_l_888:
	/* 0x888: jmp    891 <sched_process_fork_signal+0x891> */
	X86_SIM_X86_JMP(0x888, 0x891, x86_l_891);
x86_l_88a:
	/* 0x88a: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_891:
	/* 0x891: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_899:
	/* 0x899: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_8a0:
	/* 0x8a0: ja     8f4 <sched_process_fork_signal+0x8f4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8a0, 0x8f4, x86_l_8f4);
x86_l_8a2:
	/* 0x8a2: mov    BYTE PTR [r14+rbx*1+0x5],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836491ULL);
x86_l_8a8:
	/* 0x8a8: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_8ae:
	/* 0x8ae: ja     8f4 <sched_process_fork_signal+0x8f4> */
	X86_SIM_X86_JCC(X86_CC_A, 0x8ae, 0x8f4, x86_l_8f4);
x86_l_8b0:
	/* 0x8b0: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_8b4:
	/* 0x8b4: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_8b8:
	/* 0x8b8: lea    rax,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8bd:
	/* 0x8bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c0:
	/* 0x8c0: jns    8d1 <sched_process_fork_signal+0x8d1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c0, 0x8d1, x86_l_8d1);
x86_l_8c2:
	/* 0x8c2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c5:
	/* 0x8c5: jns    955 <sched_process_fork_signal+0x955> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x8c5, 0x955, x86_l_955);
x86_l_8cb:
	/* 0x8cb: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8cd:
	/* 0x8cd: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8cf:
	/* 0x8cf: jmp    8e5 <sched_process_fork_signal+0x8e5> */
	X86_SIM_X86_JMP(0x8cf, 0x8e5, x86_l_8e5);
x86_l_8d1:
	/* 0x8d1: lea    rdx,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8d6:
	/* 0x8d6: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_8db:
	/* 0x8db: call   4190 <sched_process_fork_signal+0x4190> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_8e0:
	/* 0x8e0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e3:
	/* 0x8e3: js     8f4 <sched_process_fork_signal+0x8f4> */
	X86_SIM_X86_JCC(X86_CC_S, 0x8e3, 0x8f4, x86_l_8f4);
x86_l_8e5:
	/* 0x8e5: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_8e8:
	/* 0x8e8: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_8f0:
	/* 0x8f0: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_8f4:
	/* 0x8f4: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_8fc:
	/* 0x8fc: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_903:
	/* 0x903: ja     974 <sched_process_fork_signal+0x974> */
	X86_SIM_X86_JCC(X86_CC_A, 0x903, 0x974, x86_l_974);
x86_l_905:
	/* 0x905: mov    BYTE PTR [r14+rbx*1+0x5],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836492ULL);
x86_l_90b:
	/* 0x90b: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_911:
	/* 0x911: ja     974 <sched_process_fork_signal+0x974> */
	X86_SIM_X86_JCC(X86_CC_A, 0x911, 0x974, x86_l_974);
x86_l_913:
	/* 0x913: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_917:
	/* 0x917: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_91b:
	/* 0x91b: lea    rax,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_920:
	/* 0x920: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_923:
	/* 0x923: jns    930 <sched_process_fork_signal+0x930> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x923, 0x930, x86_l_930);
x86_l_925:
	/* 0x925: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_928:
	/* 0x928: jns    96e <sched_process_fork_signal+0x96e> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x928, 0x96e, x86_l_96e);
x86_l_92a:
	/* 0x92a: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_92c:
	/* 0x92c: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_92e:
	/* 0x92e: jmp    944 <sched_process_fork_signal+0x944> */
	X86_SIM_X86_JMP(0x92e, 0x944, x86_l_944);
x86_l_930:
	/* 0x930: lea    rdx,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_935:
	/* 0x935: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_93a:
	/* 0x93a: call   41ef <sched_process_fork_signal+0x41ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_93f:
	/* 0x93f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_942:
	/* 0x942: js     974 <sched_process_fork_signal+0x974> */
	X86_SIM_X86_JCC(X86_CC_S, 0x942, 0x974, x86_l_974);
x86_l_944:
	/* 0x944: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_947:
	/* 0x947: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_94f:
	/* 0x94f: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_953:
	/* 0x953: jmp    974 <sched_process_fork_signal+0x974> */
	X86_SIM_X86_JMP(0x953, 0x974, x86_l_974);
x86_l_955:
	/* 0x955: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_95b:
	/* 0x95b: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_963:
	/* 0x963: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_96a:
	/* 0x96a: jbe    905 <sched_process_fork_signal+0x905> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x96a, 0x905, x86_l_905);
x86_l_96c:
	/* 0x96c: jmp    974 <sched_process_fork_signal+0x974> */
	X86_SIM_X86_JMP(0x96c, 0x974, x86_l_974);
x86_l_96e:
	/* 0x96e: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_974:
	/* 0x974: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_97c:
	/* 0x97c: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_983:
	/* 0x983: ja     9d7 <sched_process_fork_signal+0x9d7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x983, 0x9d7, x86_l_9d7);
x86_l_985:
	/* 0x985: mov    BYTE PTR [r14+rbx*1+0x5],0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836493ULL);
x86_l_98b:
	/* 0x98b: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_991:
	/* 0x991: ja     9d7 <sched_process_fork_signal+0x9d7> */
	X86_SIM_X86_JCC(X86_CC_A, 0x991, 0x9d7, x86_l_9d7);
x86_l_993:
	/* 0x993: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_997:
	/* 0x997: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_99b:
	/* 0x99b: lea    rax,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_9a0:
	/* 0x9a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9a3:
	/* 0x9a3: jns    9b4 <sched_process_fork_signal+0x9b4> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9a3, 0x9b4, x86_l_9b4);
x86_l_9a5:
	/* 0x9a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9a8:
	/* 0x9a8: jns    a38 <sched_process_fork_signal+0xa38> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x9a8, 0xa38, x86_l_a38);
x86_l_9ae:
	/* 0x9ae: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9b0:
	/* 0x9b0: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9b2:
	/* 0x9b2: jmp    9c8 <sched_process_fork_signal+0x9c8> */
	X86_SIM_X86_JMP(0x9b2, 0x9c8, x86_l_9c8);
x86_l_9b4:
	/* 0x9b4: lea    rdx,[rsp+0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_9b9:
	/* 0x9b9: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_9be:
	/* 0x9be: call   4273 <sched_process_fork_signal+0x4273> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_9c3:
	/* 0x9c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9c6:
	/* 0x9c6: js     9d7 <sched_process_fork_signal+0x9d7> */
	X86_SIM_X86_JCC(X86_CC_S, 0x9c6, 0x9d7, x86_l_9d7);
x86_l_9c8:
	/* 0x9c8: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_9cb:
	/* 0x9cb: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_9d3:
	/* 0x9d3: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_9d7:
	/* 0x9d7: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_9df:
	/* 0x9df: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_9e6:
	/* 0x9e6: ja     a57 <sched_process_fork_signal+0xa57> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9e6, 0xa57, x86_l_a57);
x86_l_9e8:
	/* 0x9e8: mov    BYTE PTR [r14+rbx*1+0x5],0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836494ULL);
x86_l_9ee:
	/* 0x9ee: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_9f4:
	/* 0x9f4: ja     a57 <sched_process_fork_signal+0xa57> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9f4, 0xa57, x86_l_a57);
x86_l_9f6:
	/* 0x9f6: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_9fa:
	/* 0x9fa: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_9fe:
	/* 0x9fe: lea    rax,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_a03:
	/* 0xa03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a06:
	/* 0xa06: jns    a13 <sched_process_fork_signal+0xa13> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa06, 0xa13, x86_l_a13);
x86_l_a08:
	/* 0xa08: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a0b:
	/* 0xa0b: jns    a51 <sched_process_fork_signal+0xa51> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa0b, 0xa51, x86_l_a51);
x86_l_a0d:
	/* 0xa0d: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a0f:
	/* 0xa0f: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a11:
	/* 0xa11: jmp    a27 <sched_process_fork_signal+0xa27> */
	X86_SIM_X86_JMP(0xa11, 0xa27, x86_l_a27);
x86_l_a13:
	/* 0xa13: lea    rdx,[rsp+0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_a18:
	/* 0xa18: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_a1d:
	/* 0xa1d: call   42d2 <sched_process_fork_signal+0x42d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_a22:
	/* 0xa22: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a25:
	/* 0xa25: js     a57 <sched_process_fork_signal+0xa57> */
	X86_SIM_X86_JCC(X86_CC_S, 0xa25, 0xa57, x86_l_a57);
x86_l_a27:
	/* 0xa27: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_a2a:
	/* 0xa2a: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_a32:
	/* 0xa32: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_a36:
	/* 0xa36: jmp    a57 <sched_process_fork_signal+0xa57> */
	X86_SIM_X86_JMP(0xa36, 0xa57, x86_l_a57);
x86_l_a38:
	/* 0xa38: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a3e:
	/* 0xa3e: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_a46:
	/* 0xa46: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_a4d:
	/* 0xa4d: jbe    9e8 <sched_process_fork_signal+0x9e8> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa4d, 0x9e8, x86_l_9e8);
x86_l_a4f:
	/* 0xa4f: jmp    a57 <sched_process_fork_signal+0xa57> */
	X86_SIM_X86_JMP(0xa4f, 0xa57, x86_l_a57);
x86_l_a51:
	/* 0xa51: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a57:
	/* 0xa57: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_a5f:
	/* 0xa5f: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_a66:
	/* 0xa66: ja     abc <sched_process_fork_signal+0xabc> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa66, 0xabc, x86_l_abc);
x86_l_a68:
	/* 0xa68: mov    BYTE PTR [r14+rbx*1+0x5],0xf */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836495ULL);
x86_l_a6e:
	/* 0xa6e: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_a74:
	/* 0xa74: ja     abc <sched_process_fork_signal+0xabc> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa74, 0xabc, x86_l_abc);
x86_l_a76:
	/* 0xa76: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_a7a:
	/* 0xa7a: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_a7e:
	/* 0xa7e: lea    rax,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a83:
	/* 0xa83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a86:
	/* 0xa86: jns    a99 <sched_process_fork_signal+0xa99> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa86, 0xa99, x86_l_a99);
x86_l_a88:
	/* 0xa88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a8b:
	/* 0xa8b: jns    b1d <sched_process_fork_signal+0xb1d> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa8b, 0xb1d, x86_l_b1d);
x86_l_a91:
	/* 0xa91: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a94:
	/* 0xa94: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a97:
	/* 0xa97: jmp    aad <sched_process_fork_signal+0xaad> */
	X86_SIM_X86_JMP(0xa97, 0xaad, x86_l_aad);
x86_l_a99:
	/* 0xa99: lea    rdx,[rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a9e:
	/* 0xa9e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_aa3:
	/* 0xaa3: call   4358 <sched_process_fork_signal+0x4358> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_aa8:
	/* 0xaa8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aab:
	/* 0xaab: js     abc <sched_process_fork_signal+0xabc> */
	X86_SIM_X86_JCC(X86_CC_S, 0xaab, 0xabc, x86_l_abc);
x86_l_aad:
	/* 0xaad: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_ab0:
	/* 0xab0: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_ab8:
	/* 0xab8: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_abc:
	/* 0xabc: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_ac4:
	/* 0xac4: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_acb:
	/* 0xacb: ja     b3d <sched_process_fork_signal+0xb3d> */
	X86_SIM_X86_JCC(X86_CC_A, 0xacb, 0xb3d, x86_l_b3d);
x86_l_acd:
	/* 0xacd: mov    BYTE PTR [r14+rbx*1+0x5],0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836496ULL);
x86_l_ad3:
	/* 0xad3: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_ad9:
	/* 0xad9: ja     b3d <sched_process_fork_signal+0xb3d> */
	X86_SIM_X86_JCC(X86_CC_A, 0xad9, 0xb3d, x86_l_b3d);
x86_l_adb:
	/* 0xadb: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_adf:
	/* 0xadf: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_ae3:
	/* 0xae3: lea    rax,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ae8:
	/* 0xae8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aeb:
	/* 0xaeb: jns    af8 <sched_process_fork_signal+0xaf8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaeb, 0xaf8, x86_l_af8);
x86_l_aed:
	/* 0xaed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_af0:
	/* 0xaf0: jns    b37 <sched_process_fork_signal+0xb37> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xaf0, 0xb37, x86_l_b37);
x86_l_af2:
	/* 0xaf2: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af4:
	/* 0xaf4: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_af6:
	/* 0xaf6: jmp    b0c <sched_process_fork_signal+0xb0c> */
	X86_SIM_X86_JMP(0xaf6, 0xb0c, x86_l_b0c);
x86_l_af8:
	/* 0xaf8: lea    rdx,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_afd:
	/* 0xafd: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_b02:
	/* 0xb02: call   43b7 <sched_process_fork_signal+0x43b7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b07:
	/* 0xb07: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b0a:
	/* 0xb0a: js     b3d <sched_process_fork_signal+0xb3d> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb0a, 0xb3d, x86_l_b3d);
x86_l_b0c:
	/* 0xb0c: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_b0f:
	/* 0xb0f: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_b17:
	/* 0xb17: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_b1b:
	/* 0xb1b: jmp    b3d <sched_process_fork_signal+0xb3d> */
	X86_SIM_X86_JMP(0xb1b, 0xb3d, x86_l_b3d);
x86_l_b1d:
	/* 0xb1d: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b24:
	/* 0xb24: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_b2c:
	/* 0xb2c: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_b33:
	/* 0xb33: jbe    acd <sched_process_fork_signal+0xacd> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xb33, 0xacd, x86_l_acd);
x86_l_b35:
	/* 0xb35: jmp    b3d <sched_process_fork_signal+0xb3d> */
	X86_SIM_X86_JMP(0xb35, 0xb3d, x86_l_b3d);
x86_l_b37:
	/* 0xb37: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b3d:
	/* 0xb3d: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_b45:
	/* 0xb45: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_b4c:
	/* 0xb4c: ja     b9c <sched_process_fork_signal+0xb9c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb4c, 0xb9c, x86_l_b9c);
x86_l_b4e:
	/* 0xb4e: mov    BYTE PTR [r14+rbx*1+0x5],0x11 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836497ULL);
x86_l_b54:
	/* 0xb54: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_b5a:
	/* 0xb5a: ja     b9c <sched_process_fork_signal+0xb9c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb5a, 0xb9c, x86_l_b9c);
x86_l_b5c:
	/* 0xb5c: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_b60:
	/* 0xb60: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_b64:
	/* 0xb64: mov    rax,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b67:
	/* 0xb67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b6a:
	/* 0xb6a: jns    b7b <sched_process_fork_signal+0xb7b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb6a, 0xb7b, x86_l_b7b);
x86_l_b6c:
	/* 0xb6c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b6f:
	/* 0xb6f: jns    bfd <sched_process_fork_signal+0xbfd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xb6f, 0xbfd, x86_l_bfd);
x86_l_b75:
	/* 0xb75: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b77:
	/* 0xb77: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b79:
	/* 0xb79: jmp    b8d <sched_process_fork_signal+0xb8d> */
	X86_SIM_X86_JMP(0xb79, 0xb8d, x86_l_b8d);
x86_l_b7b:
	/* 0xb7b: mov    rdx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_b7e:
	/* 0xb7e: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_b83:
	/* 0xb83: call   4438 <sched_process_fork_signal+0x4438> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b88:
	/* 0xb88: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8b:
	/* 0xb8b: js     b9c <sched_process_fork_signal+0xb9c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xb8b, 0xb9c, x86_l_b9c);
x86_l_b8d:
	/* 0xb8d: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_b90:
	/* 0xb90: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_b98:
	/* 0xb98: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_b9c:
	/* 0xb9c: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_ba4:
	/* 0xba4: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_bab:
	/* 0xbab: ja     c1c <sched_process_fork_signal+0xc1c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xbab, 0xc1c, x86_l_c1c);
x86_l_bad:
	/* 0xbad: mov    BYTE PTR [r14+rbx*1+0x5],0x12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836498ULL);
x86_l_bb3:
	/* 0xbb3: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_bb9:
	/* 0xbb9: ja     c1c <sched_process_fork_signal+0xc1c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xbb9, 0xc1c, x86_l_c1c);
x86_l_bbb:
	/* 0xbbb: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_bbf:
	/* 0xbbf: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_bc3:
	/* 0xbc3: lea    rax,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_bc8:
	/* 0xbc8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bcb:
	/* 0xbcb: jns    bd8 <sched_process_fork_signal+0xbd8> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbcb, 0xbd8, x86_l_bd8);
x86_l_bcd:
	/* 0xbcd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bd0:
	/* 0xbd0: jns    c16 <sched_process_fork_signal+0xc16> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xbd0, 0xc16, x86_l_c16);
x86_l_bd2:
	/* 0xbd2: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd4:
	/* 0xbd4: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd6:
	/* 0xbd6: jmp    bec <sched_process_fork_signal+0xbec> */
	X86_SIM_X86_JMP(0xbd6, 0xbec, x86_l_bec);
x86_l_bd8:
	/* 0xbd8: lea    rdx,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_bdd:
	/* 0xbdd: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_be2:
	/* 0xbe2: call   4497 <sched_process_fork_signal+0x4497> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_be7:
	/* 0xbe7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bea:
	/* 0xbea: js     c1c <sched_process_fork_signal+0xc1c> */
	X86_SIM_X86_JCC(X86_CC_S, 0xbea, 0xc1c, x86_l_c1c);
x86_l_bec:
	/* 0xbec: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_bef:
	/* 0xbef: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_bf7:
	/* 0xbf7: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_bfb:
	/* 0xbfb: jmp    c1c <sched_process_fork_signal+0xc1c> */
	X86_SIM_X86_JMP(0xbfb, 0xc1c, x86_l_c1c);
x86_l_bfd:
	/* 0xbfd: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c03:
	/* 0xc03: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_c0b:
	/* 0xc0b: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_c12:
	/* 0xc12: jbe    bad <sched_process_fork_signal+0xbad> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xc12, 0xbad, x86_l_bad);
x86_l_c14:
	/* 0xc14: jmp    c1c <sched_process_fork_signal+0xc1c> */
	X86_SIM_X86_JMP(0xc14, 0xc1c, x86_l_c1c);
x86_l_c16:
	/* 0xc16: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c1c:
	/* 0xc1c: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_c24:
	/* 0xc24: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_c2b:
	/* 0xc2b: ja     c7f <sched_process_fork_signal+0xc7f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc2b, 0xc7f, x86_l_c7f);
x86_l_c2d:
	/* 0xc2d: mov    BYTE PTR [r14+rbx*1+0x5],0x13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836499ULL);
x86_l_c33:
	/* 0xc33: cmp    ebx,0x7cfb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31995ULL);
x86_l_c39:
	/* 0xc39: ja     c7f <sched_process_fork_signal+0xc7f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc39, 0xc7f, x86_l_c7f);
x86_l_c3b:
	/* 0xc3b: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_c3f:
	/* 0xc3f: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_c43:
	/* 0xc43: lea    rax,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_c48:
	/* 0xc48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c4b:
	/* 0xc4b: jns    c5c <sched_process_fork_signal+0xc5c> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc4b, 0xc5c, x86_l_c5c);
x86_l_c4d:
	/* 0xc4d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c50:
	/* 0xc50: jns    ce2 <sched_process_fork_signal+0xce2> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc50, 0xce2, x86_l_ce2);
x86_l_c56:
	/* 0xc56: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c58:
	/* 0xc58: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c5a:
	/* 0xc5a: jmp    c70 <sched_process_fork_signal+0xc70> */
	X86_SIM_X86_JMP(0xc5a, 0xc70, x86_l_c70);
x86_l_c5c:
	/* 0xc5c: lea    rdx,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_c61:
	/* 0xc61: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_c66:
	/* 0xc66: call   451b <sched_process_fork_signal+0x451b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_c6b:
	/* 0xc6b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c6e:
	/* 0xc6e: js     c7f <sched_process_fork_signal+0xc7f> */
	X86_SIM_X86_JCC(X86_CC_S, 0xc6e, 0xc7f, x86_l_c7f);
x86_l_c70:
	/* 0xc70: add    ebx,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_c73:
	/* 0xc73: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_c7b:
	/* 0xc7b: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_c7f:
	/* 0xc7f: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_c87:
	/* 0xc87: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_c8e:
	/* 0xc8e: ja     d02 <sched_process_fork_signal+0xd02> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc8e, 0xd02, x86_l_d02);
x86_l_c90:
	/* 0xc90: mov    BYTE PTR [r14+rbx*1+0x5],0x14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 21474836500ULL);
x86_l_c96:
	/* 0xc96: cmp    ebx,0x7cf7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 31991ULL);
x86_l_c9c:
	/* 0xc9c: ja     d02 <sched_process_fork_signal+0xd02> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc9c, 0xd02, x86_l_d02);
x86_l_c9e:
	/* 0xc9e: lea    rdi,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_ca2:
	/* 0xca2: add    rdi,0x6 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 6ULL);
x86_l_ca6:
	/* 0xca6: lea    rax,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_cab:
	/* 0xcab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cae:
	/* 0xcae: jns    cbd <sched_process_fork_signal+0xcbd> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcae, 0xcbd, x86_l_cbd);
x86_l_cb0:
	/* 0xcb0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cb3:
	/* 0xcb3: jns    cfb <sched_process_fork_signal+0xcfb> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcb3, 0xcfb, x86_l_cfb);
x86_l_cb5:
	/* 0xcb5: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cb8:
	/* 0xcb8: mov    QWORD PTR [rdi],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cbb:
	/* 0xcbb: jmp    cd1 <sched_process_fork_signal+0xcd1> */
	X86_SIM_X86_JMP(0xcbb, 0xcd1, x86_l_cd1);
x86_l_cbd:
	/* 0xcbd: lea    rdx,[rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_cc2:
	/* 0xcc2: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_cc7:
	/* 0xcc7: call   457c <sched_process_fork_signal+0x457c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_ccc:
	/* 0xccc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ccf:
	/* 0xccf: js     d02 <sched_process_fork_signal+0xd02> */
	X86_SIM_X86_JCC(X86_CC_S, 0xccf, 0xd02, x86_l_d02);
x86_l_cd1:
	/* 0xcd1: add    ebx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_cd4:
	/* 0xcd4: mov    WORD PTR [r14+0x7d06],bx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32006ULL);
x86_l_cdc:
	/* 0xcdc: inc    BYTE PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_R14, X86_REG_NONE, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 4ULL);
x86_l_ce0:
	/* 0xce0: jmp    d02 <sched_process_fork_signal+0xd02> */
	X86_SIM_X86_JMP(0xce0, 0xd02, x86_l_d02);
x86_l_ce2:
	/* 0xce2: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce8:
	/* 0xce8: movzx  ebx,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_cf0:
	/* 0xcf0: cmp    rbx,0x7cff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 31999ULL);
x86_l_cf7:
	/* 0xcf7: jbe    c90 <sched_process_fork_signal+0xc90> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xcf7, 0xc90, x86_l_c90);
x86_l_cf9:
	/* 0xcf9: jmp    d02 <sched_process_fork_signal+0xd02> */
	X86_SIM_X86_JMP(0xcf9, 0xd02, x86_l_d02);
x86_l_cfb:
	/* 0xcfb: mov    QWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d02:
	/* 0xd02: movzx  eax,WORD PTR [r14+0x7d06] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32006ULL);
x86_l_d0a:
	/* 0xd0a: cmp    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_d0f:
	/* 0xd0f: jb     d16 <sched_process_fork_signal+0xd16> */
	X86_SIM_X86_JCC(X86_CC_B, 0xd0f, 0xd16, x86_l_d16);
x86_l_d11:
	/* 0xd11: mov    eax,0x7d00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32000ULL);
x86_l_d16:
	/* 0xd16: add    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_d19:
	/* 0xd19: movzx  r8d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R8, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_d1d:
	/* 0xd1d: mov    rsi,QWORD PTR [rip+0x38b0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)signals));
x86_l_d24:
	/* 0xd24: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_d29:
	/* 0xd29: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_d2e:
	/* 0xd2e: mov    rcx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_d31:
	/* 0xd31: call   45e6 <sched_process_fork_signal+0x45e6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_d36:
	/* 0xd36: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d38:
	/* 0xd38: add    rsp,0x78 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 120ULL);
x86_l_d3c:
	/* 0xd3c: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d3d:
	/* 0xd3d: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d3f:
	/* 0xd3f: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d41:
	/* 0xd41: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d43:
	/* 0xd43: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d45:
	/* 0xd45: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_d46:
	/* 0xd46: jmp    d4b <sched_process_fork_signal+0xd4b> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_d4b:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
