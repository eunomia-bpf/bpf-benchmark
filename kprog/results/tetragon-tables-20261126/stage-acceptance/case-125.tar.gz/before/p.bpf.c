#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 56U
#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "../x86_sim_local_bpf.h"

extern __u8 execve_map[] __ksym;
extern __u8 execve_map_stats[] __ksym;
extern __u8 exit_heap_map[] __ksym;
extern __u8 tcpmon_map[] __ksym;
extern __u8 tg_conf_map[] __ksym;
extern __u8 tg_parents_bin[] __ksym;
extern __u8 tg_rb_events[] __ksym;
extern __u8 tg_stats_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/disassociate_ctty")
int p_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: cmp    DWORD PTR [rdi+0x70],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337152ULL);
x86_l_4:
	/* 0x4: je     2a2 <event_exit_disassociate_ctty+0x2a2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4, 0x2a2, x86_l_2a2);
x86_l_a:
	/* 0xa: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_c:
	/* 0xc: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_e:
	/* 0xe: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_10:
	/* 0x10: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_12:
	/* 0x12: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13:
	/* 0x13: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_17:
	/* 0x17: mov    r15,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1a:
	/* 0x1a: call   1f <event_exit_disassociate_ctty+0x1f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid);
x86_l_1f:
	/* 0x1f: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22:
	/* 0x22: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_26:
	/* 0x26: mov    DWORD PTR [rsp+0x4],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2b:
	/* 0x2b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_32:
	/* 0x32: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_37:
	/* 0x37: call   3c <event_exit_disassociate_ctty+0x3c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3c:
	/* 0x3c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: je     295 <event_exit_disassociate_ctty+0x295> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3f, 0x295, x86_l_295);
x86_l_45:
	/* 0x45: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_48:
	/* 0x48: cmp    QWORD PTR [rax+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_4d:
	/* 0x4d: je     228 <event_exit_disassociate_ctty+0x228> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4d, 0x228, x86_l_228);
x86_l_53:
	/* 0x53: call   58 <event_exit_disassociate_ctty+0x58> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_get_current_task);
x86_l_58:
	/* 0x58: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5b:
	/* 0x5b: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_63:
	/* 0x63: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exit_heap_map));
x86_l_6a:
	/* 0x6a: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_6f:
	/* 0x6f: call   74 <event_exit_disassociate_ctty+0x74> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_74:
	/* 0x74: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_77:
	/* 0x77: je     295 <event_exit_disassociate_ctty+0x295> */
	X86_SIM_X86_JCC(X86_CC_E, 0x77, 0x295, x86_l_295);
x86_l_7d:
	/* 0x7d: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_80:
	/* 0x80: movabs rax,0x2800000007 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 171798691847ULL);
x86_l_8a:
	/* 0x8a: mov    QWORD PTR [r12],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e:
	/* 0x8e: call   93 <event_exit_disassociate_ctty+0x93> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ktime_get_boot_ns);
x86_l_93:
	/* 0x93: mov    QWORD PTR [r12+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_98:
	/* 0x98: mov    DWORD PTR [r12+0x10],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9d:
	/* 0x9d: mov    DWORD PTR [r12+0x14],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_a6:
	/* 0xa6: mov    rax,QWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aa:
	/* 0xaa: mov    QWORD PTR [r12+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_af:
	/* 0xaf: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_b2:
	/* 0xb2: add    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_b6:
	/* 0xb6: mov    DWORD PTR [r12+0x24],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_bb:
	/* 0xbb: add    r13,0xa8c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2700ULL);
x86_l_c2:
	/* 0xc2: jns    d1 <event_exit_disassociate_ctty+0xd1> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc2, 0xd1, x86_l_d1);
x86_l_c4:
	/* 0xc4: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c7:
	/* 0xc7: jns    e0 <event_exit_disassociate_ctty+0xe0> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xc7, 0xe0, x86_l_e0);
x86_l_c9:
	/* 0xc9: mov    eax,DWORD PTR [r13+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cd:
	/* 0xcd: mov    DWORD PTR [rdi],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cf:
	/* 0xcf: jmp    e6 <event_exit_disassociate_ctty+0xe6> */
	X86_SIM_X86_JMP(0xcf, 0xe6, x86_l_e6);
x86_l_d1:
	/* 0xd1: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_d6:
	/* 0xd6: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_d9:
	/* 0xd9: call   de <event_exit_disassociate_ctty+0xde> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_de:
	/* 0xde: jmp    e6 <event_exit_disassociate_ctty+0xe6> */
	X86_SIM_X86_JMP(0xde, 0xe6, x86_l_e6);
x86_l_e0:
	/* 0xe0: mov    DWORD PTR [rdi],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e6:
	/* 0xe6: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_ee:
	/* 0xee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_conf_map));
x86_l_f5:
	/* 0xf5: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fa:
	/* 0xfa: call   ff <event_exit_disassociate_ctty+0xff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ff:
	/* 0xff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_102:
	/* 0x102: je     17a <event_exit_disassociate_ctty+0x17a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102, 0x17a, x86_l_17a);
x86_l_104:
	/* 0x104: cmp    BYTE PTR [rax+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_108:
	/* 0x108: je     17a <event_exit_disassociate_ctty+0x17a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x108, 0x17a, x86_l_17a);
x86_l_10a:
	/* 0x10a: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tcpmon_map));
x86_l_111:
	/* 0x111: mov    edx,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_116:
	/* 0x116: mov    r8d,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_11c:
	/* 0x11c: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_11f:
	/* 0x11f: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_122:
	/* 0x122: call   127 <event_exit_disassociate_ctty+0x127> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_perf_event_output);
x86_l_127:
	/* 0x127: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12a:
	/* 0x12a: jns    228 <event_exit_disassociate_ctty+0x228> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x12a, 0x228, x86_l_228);
x86_l_130:
	/* 0x130: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_133:
	/* 0x133: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_13b:
	/* 0x13b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_142:
	/* 0x142: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_147:
	/* 0x147: call   14c <event_exit_disassociate_ctty+0x14c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_14c:
	/* 0x14c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14f:
	/* 0x14f: je     228 <event_exit_disassociate_ctty+0x228> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f, 0x228, x86_l_228);
x86_l_155:
	/* 0x155: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_159:
	/* 0x159: jg     1f4 <event_exit_disassociate_ctty+0x1f4> */
	X86_SIM_X86_JCC(X86_CC_G, 0x159, 0x1f4, x86_l_1f4);
x86_l_15f:
	/* 0x15f: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_163:
	/* 0x163: je     20e <event_exit_disassociate_ctty+0x20e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x163, 0x20e, x86_l_20e);
x86_l_169:
	/* 0x169: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_16d:
	/* 0x16d: jne    1cc <event_exit_disassociate_ctty+0x1cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x16d, 0x1cc, x86_l_1cc);
x86_l_16f:
	/* 0x16f: add    rax,0x1a8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 424ULL);
x86_l_175:
	/* 0x175: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x175, 0x224, x86_l_224);
x86_l_17a:
	/* 0x17a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_rb_events));
x86_l_181:
	/* 0x181: mov    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_186:
	/* 0x186: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_189:
	/* 0x189: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b:
	/* 0x18b: call   190 <event_exit_disassociate_ctty+0x190> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_ringbuf_output);
x86_l_190:
	/* 0x190: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_193:
	/* 0x193: jns    228 <event_exit_disassociate_ctty+0x228> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x193, 0x228, x86_l_228);
x86_l_199:
	/* 0x199: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19c:
	/* 0x19c: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_1a4:
	/* 0x1a4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_stats_map));
x86_l_1ab:
	/* 0x1ab: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b0:
	/* 0x1b0: call   1b5 <event_exit_disassociate_ctty+0x1b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1b5:
	/* 0x1b5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b8:
	/* 0x1b8: je     228 <event_exit_disassociate_ctty+0x228> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b8, 0x228, x86_l_228);
x86_l_1ba:
	/* 0x1ba: cmp    r15,0xfffffffffffffff4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551604ULL);
x86_l_1be:
	/* 0x1be: jg     1da <event_exit_disassociate_ctty+0x1da> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1be, 0x1da, x86_l_1da);
x86_l_1c0:
	/* 0x1c0: cmp    r15,0xffffffffffffffe4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551588ULL);
x86_l_1c4:
	/* 0x1c4: je     20e <event_exit_disassociate_ctty+0x20e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c4, 0x20e, x86_l_20e);
x86_l_1c6:
	/* 0x1c6: cmp    r15,0xffffffffffffffea */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551594ULL);
x86_l_1ca:
	/* 0x1ca: je     16f <event_exit_disassociate_ctty+0x16f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ca, 0x16f, x86_l_16f);
x86_l_1cc:
	/* 0x1cc: cmp    r15,0xfffffffffffffff0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551600ULL);
x86_l_1d0:
	/* 0x1d0: jne    206 <event_exit_disassociate_ctty+0x206> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d0, 0x206, x86_l_206);
x86_l_1d2:
	/* 0x1d2: add    rax,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 416ULL);
x86_l_1d8:
	/* 0x1d8: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x1d8, 0x224, x86_l_224);
x86_l_1da:
	/* 0x1da: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_1de:
	/* 0x1de: je     216 <event_exit_disassociate_ctty+0x216> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1de, 0x216, x86_l_216);
x86_l_1e0:
	/* 0x1e0: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_1e4:
	/* 0x1e4: je     21e <event_exit_disassociate_ctty+0x21e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e4, 0x21e, x86_l_21e);
x86_l_1e6:
	/* 0x1e6: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_1ea:
	/* 0x1ea: jne    206 <event_exit_disassociate_ctty+0x206> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ea, 0x206, x86_l_206);
x86_l_1ec:
	/* 0x1ec: add    rax,0x190 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 400ULL);
x86_l_1f2:
	/* 0x1f2: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x1f2, 0x224, x86_l_224);
x86_l_1f4:
	/* 0x1f4: cmp    r15,0xfffffffffffffff5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551605ULL);
x86_l_1f8:
	/* 0x1f8: je     216 <event_exit_disassociate_ctty+0x216> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f8, 0x216, x86_l_216);
x86_l_1fa:
	/* 0x1fa: cmp    r15,0xfffffffffffffff9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551609ULL);
x86_l_1fe:
	/* 0x1fe: je     21e <event_exit_disassociate_ctty+0x21e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fe, 0x21e, x86_l_21e);
x86_l_200:
	/* 0x200: cmp    r15,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_204:
	/* 0x204: je     1ec <event_exit_disassociate_ctty+0x1ec> */
	X86_SIM_X86_JCC(X86_CC_E, 0x204, 0x1ec, x86_l_1ec);
x86_l_206:
	/* 0x206: add    rax,0x188 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 392ULL);
x86_l_20c:
	/* 0x20c: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x20c, 0x224, x86_l_224);
x86_l_20e:
	/* 0x20e: add    rax,0x1b0 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 432ULL);
x86_l_214:
	/* 0x214: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x214, 0x224, x86_l_224);
x86_l_216:
	/* 0x216: add    rax,0x1b8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 440ULL);
x86_l_21c:
	/* 0x21c: jmp    224 <event_exit_disassociate_ctty+0x224> */
	X86_SIM_X86_JMP(0x21c, 0x224, x86_l_224);
x86_l_21e:
	/* 0x21e: add    rax,0x198 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 408ULL);
x86_l_224:
	/* 0x224: lock inc QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, (X86_WIDTH_64 | X86_MEM_LOCK), (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_228:
	/* 0x228: mov    DWORD PTR [rsp+0x8],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d:
	/* 0x22d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map));
x86_l_234:
	/* 0x234: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_239:
	/* 0x239: call   23e <event_exit_disassociate_ctty+0x23e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_23e:
	/* 0x23e: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_240:
	/* 0x240: je     265 <event_exit_disassociate_ctty+0x265> */
	X86_SIM_X86_JCC(X86_CC_E, 0x240, 0x265, x86_l_265);
x86_l_242:
	/* 0x242: mov    DWORD PTR [rsp+0x4],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869186ULL);
x86_l_24a:
	/* 0x24a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map_stats));
x86_l_251:
	/* 0x251: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_256:
	/* 0x256: call   25b <event_exit_disassociate_ctty+0x25b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25b:
	/* 0x25b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25e:
	/* 0x25e: je     286 <event_exit_disassociate_ctty+0x286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25e, 0x286, x86_l_286);
x86_l_260:
	/* 0x260: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_263:
	/* 0x263: jmp    286 <event_exit_disassociate_ctty+0x286> */
	X86_SIM_X86_JMP(0x263, 0x286, x86_l_286);
x86_l_265:
	/* 0x265: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_26d:
	/* 0x26d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)execve_map_stats));
x86_l_274:
	/* 0x274: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_279:
	/* 0x279: call   27e <event_exit_disassociate_ctty+0x27e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27e:
	/* 0x27e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_281:
	/* 0x281: je     286 <event_exit_disassociate_ctty+0x286> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281, 0x286, x86_l_286);
x86_l_283:
	/* 0x283: dec    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_DEC)), 0ULL);
x86_l_286:
	/* 0x286: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)tg_parents_bin));
x86_l_28d:
	/* 0x28d: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_290:
	/* 0x290: call   295 <event_exit_disassociate_ctty+0x295> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_delete_elem);
x86_l_295:
	/* 0x295: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_299:
	/* 0x299: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29c:
	/* 0x29c: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_29e:
	/* 0x29e: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a0:
	/* 0x2a0: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2a2:
	/* 0x2a2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2a4:
	/* 0x2a4: jmp    2a9 <event_exit_disassociate_ctty+0x2a9> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2a9:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
