from pathlib import Path
import json,subprocess
S=Path('/var/tmp/kprog-tmp/S2');R=Path('/workspaces/repository');rows=[]
for p in sorted((S/'negative-src').glob('*.bpf.c')):
 text=p.read_text().replace('#include "../../test/include/native_helpers.h"','#include "/workspaces/repository/kprog/test/include/native_helpers.h"').replace('#include "../arm64_sim_local_bpf.h"','#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"');p.write_text(text)
 cmd=['clang','-O2','-g','-target','bpf','-mcpu=v4','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(p),'-o',str(S/'negative-build'/p.with_suffix('.o').name)]
 done=subprocess.run(cmd,capture_output=True,text=True);rows.append(dict(name=p.name,command=cmd,exit=done.returncode,stderr=done.stderr));print(p.name,done.returncode,flush=True)
(S/'negative-micro.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(len(rows)!=1 or any(x['exit'] for x in rows)))
