s2-generator:
	python3 /workspaces/repository/kprog/arm64/micro-prog/test_read_recovery.py > /var/tmp/kprog-tmp/S2/generator.json
