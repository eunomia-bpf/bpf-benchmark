ulimit -c 0
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S2/micro.mk s2-micro > /var/tmp/kprog-tmp/S2/micro.log 2>&1
echo $? > /var/tmp/kprog-tmp/S2/micro.exit
