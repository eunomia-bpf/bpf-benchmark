ulimit -c 0
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S2/micro.mk s2-negative-micro > /var/tmp/kprog-tmp/S2/negative-micro.log 2>&1
echo $? > /var/tmp/kprog-tmp/S2/negative-micro.exit
