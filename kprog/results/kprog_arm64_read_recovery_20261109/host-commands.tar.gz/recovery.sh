ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S2/recovery.mk s2-recovery > /var/tmp/kprog-tmp/S2/recovery.log 2>&1
echo $? > /var/tmp/kprog-tmp/S2/recovery.exit
