from pathlib import Path
import json,subprocess
S=Path('/var/tmp/kprog-tmp/S2');R=Path('/workspaces/repository');rows=[]
for p in sorted((S/'micro-src').glob('*.bpf.c')):
 text=p.read_text().replace('#include "../arm64_sim_local_bpf.h"','#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"');p.write_text(text)
 cmd=['clang','-O2','-g','-target','bpf','-mcpu=v4','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(p),'-o',str(S/'micro-build'/p.with_suffix('.o').name)]
 done=subprocess.run(cmd,capture_output=True,text=True);rows.append(dict(name=p.name,command=cmd,exit=done.returncode,stderr=done.stderr));print(p.name,done.returncode,flush=True)
(S/'micro.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(len(rows)!=29 or any(x['exit'] for x in rows)))
