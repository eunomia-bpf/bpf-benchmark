include /workspaces/repository/kprog/formal/Makefile
s2-recovery:
	$(CC) $(ARM64_HOST_ENV) -O2 -Wall -Wextra -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_read_recovery_host.c -o /var/tmp/kprog-tmp/S2/read-recovery
	/var/tmp/kprog-tmp/S2/read-recovery
