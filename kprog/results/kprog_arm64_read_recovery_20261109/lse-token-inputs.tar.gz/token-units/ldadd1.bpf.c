#define ARM64_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/arm64/arm64_sim_local_bpf.h"
SEC("xdp") int unit(struct xdp_md *ctx) { ARM64_SIM_ENTRY_RAW(ctx); ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDADD, ARM64_X1, ARM64_X0, ARM64_X0, ARM64_REG_NONE, 1, 3, 0); return ARM64_SIM_L_READ_REG_RAW(ARM64_X1); }
ARM64_SIM_LICENSE();
