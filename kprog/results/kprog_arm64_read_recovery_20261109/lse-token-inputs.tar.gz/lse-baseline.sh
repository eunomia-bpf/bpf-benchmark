ulimit -c 0
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S2/lse-baseline.mk s2-lse-baseline >/var/tmp/kprog-tmp/S2/lse-baseline.log 2>&1
echo $? >/var/tmp/kprog-tmp/S2/lse-baseline.exit
