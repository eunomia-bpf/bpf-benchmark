ulimit -c 0
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S2/lse.mk s2-lse-units >/var/tmp/kprog-tmp/S2/lse.log 2>&1
echo $? >/var/tmp/kprog-tmp/S2/lse.exit
