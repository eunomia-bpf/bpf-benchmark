s2-lse-baseline:
	unshare --mount --propagation private python3 /var/tmp/kprog-tmp/S2/lse-baseline-inside.py
