from pathlib import Path
import subprocess,json,os
R=Path('/workspaces/repository');S=Path('/var/tmp/kprog-tmp/S2')
for name in ['arm64_sim_local_bpf.h','arm64_sim_direct.h']:
 subprocess.run(['mount','--bind',str(S/'before/kprog/arm64'/name),str(R/'kprog/arm64'/name)],check=True)
rows=[]
for op in ['ldadd','ldset','ldclr']:
 p=S/'lse-units'/(op+'2.bpf.c');o=S/'lse-units'/(op+'2.before.bpf.o')
 cmd=['clang','-O2','-g','-target','bpf','-mcpu=v4','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(p),'-o',str(o)]
 d=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,TMPDIR=str(S/'lse-crash')));rows.append(dict(operation=op,width_bytes=2,compile_exit=d.returncode,stderr=d.stderr,command=cmd));print(op,d.returncode,flush=True)
(S/'lse-baseline.json').write_text(json.dumps(rows,indent=2)+'\n')
