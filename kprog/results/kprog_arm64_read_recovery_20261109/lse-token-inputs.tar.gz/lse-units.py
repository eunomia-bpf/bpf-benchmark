from pathlib import Path
import subprocess,json
R=Path('/workspaces/repository');S=Path('/var/tmp/kprog-tmp/S2/lse-units');rows=[]
for op in ['LDADD','LDSET','LDCLR']:
 for width in [1,2,4,8]:
  name=op.lower()+str(width);p=S/(name+'.bpf.c');o=S/(name+'.bpf.o')
  p.write_text('#define ARM64_SIM_ENABLE_STACK 1\n#include "'+str(R/'kprog/arm64/arm64_sim_local_bpf.h')+'"\nSEC("xdp") int unit(struct xdp_md *ctx) { ARM64_SIM_ENTRY_RAW(ctx); ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_'+op+', ARM64_X1, ARM64_X0, ARM64_X0, ARM64_REG_NONE, '+str(width)+', 3, 0); return ARM64_SIM_L_READ_REG_RAW(ARM64_X1); }\nARM64_SIM_LICENSE();\n')
  cmd=['clang','-O2','-g','-target','bpf','-mcpu=v4','-mllvm','-bpf-stack-size=4096','-D__TARGET_ARCH_arm64','-I'+str(R/'vendor/libbpf/include/uapi'),'-I'+str(R/'vendor/libbpf/src'),'-I/usr/include/x86_64-linux-gnu','-c',str(p),'-o',str(o)]
  d=subprocess.run(cmd,capture_output=True,text=True)
  rel=subprocess.run(['readelf','-rW',str(o)],capture_output=True,text=True) if d.returncode==0 else None
  rows.append(dict(operation=op,width_bytes=width,compile_exit=d.returncode,stderr=d.stderr,relocations=rel.stdout if rel else '',command=cmd));print(name,d.returncode,flush=True)
(S.parent/'lse-units.json').write_text(json.dumps(rows,indent=2)+'\n')
