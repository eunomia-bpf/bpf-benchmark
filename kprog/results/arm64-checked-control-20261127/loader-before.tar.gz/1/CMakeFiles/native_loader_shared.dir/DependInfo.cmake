
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/workspaces/repository/kprog/libnativeloader/src/native_loader.cpp" "native_loader/CMakeFiles/native_loader_shared.dir/src/native_loader.cpp.o" "gcc" "native_loader/CMakeFiles/native_loader_shared.dir/src/native_loader.cpp.o.d"
  "/workspaces/repository/kprog/libnativeloader/src/native_loader_trusted.cpp" "native_loader/CMakeFiles/native_loader_shared.dir/src/native_loader_trusted.cpp.o" "gcc" "native_loader/CMakeFiles/native_loader_shared.dir/src/native_loader_trusted.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
