# Empty compiler generated dependencies file for trusted-native-loader.
# This may be replaced when dependencies are built.
