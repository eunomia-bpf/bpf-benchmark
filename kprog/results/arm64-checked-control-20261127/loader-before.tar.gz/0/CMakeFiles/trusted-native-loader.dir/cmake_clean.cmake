file(REMOVE_RECURSE
  "CMakeFiles/trusted-native-loader.dir/workspaces/repository/kprog/trusted_loader.cpp.o"
  "CMakeFiles/trusted-native-loader.dir/workspaces/repository/kprog/trusted_loader.cpp.o.d"
  "trusted-native-loader"
  "trusted-native-loader.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/trusted-native-loader.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
