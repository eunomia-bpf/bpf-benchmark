file(REMOVE_RECURSE
  "libnative_loader.a"
)
