file(REMOVE_RECURSE
  "CMakeFiles/native_loader.dir/src/native_loader.cpp.o"
  "CMakeFiles/native_loader.dir/src/native_loader.cpp.o.d"
  "libnative_loader.a"
  "libnative_loader.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/native_loader.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
