# Empty dependencies file for native_loader.
# This may be replaced when dependencies are built.
