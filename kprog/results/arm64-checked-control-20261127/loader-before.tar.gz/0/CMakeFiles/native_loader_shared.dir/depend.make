# Empty dependencies file for native_loader_shared.
# This may be replaced when dependencies are built.
