file(REMOVE_RECURSE
  "CMakeFiles/native_loader_shared.dir/src/native_loader.cpp.o"
  "CMakeFiles/native_loader_shared.dir/src/native_loader.cpp.o.d"
  "libnative_loader.pdb"
  "libnative_loader.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/native_loader_shared.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
