file(REMOVE_RECURSE
  "CMakeFiles/trusted-service-client.dir/workspaces/repository/kprog/test/trusted_service_client.cpp.o"
  "CMakeFiles/trusted-service-client.dir/workspaces/repository/kprog/test/trusted_service_client.cpp.o.d"
  "trusted-service-client"
  "trusted-service-client.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/trusted-service-client.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
