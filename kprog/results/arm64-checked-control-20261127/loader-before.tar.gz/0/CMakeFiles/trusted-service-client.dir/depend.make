# Empty dependencies file for trusted-service-client.
# This may be replaced when dependencies are built.
