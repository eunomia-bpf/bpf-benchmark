#!/bin/sh
cd /workspaces/repository
D=/workspaces/.agent-state/kprog-lanes/T
sha256sum runner/src/native_lab_runner.cpp runner/build-llvmbpf/micro_exec kprog/x86/x86_sim_local_bpf.h kprog/libnativeloader/build/trusted-native-loader kprog/trusted_service.py > "$D/micro-native-before.sha256"
taskset -c 8-11 vng --run /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /workspaces/.agent-state/kprog-lanes/T --overlay-rwdir /tmp --disable-monitor --cpus 2 --memory 2G --append 'loglevel=4 panic=30 oops=panic' --exec 'mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug; insmod kprog/tv/build-x86/bpf_x86_native_lab.ko; python3 /workspaces/.agent-state/kprog-lanes/T/micro-native-guest.py' > "$D/micro-native-regression.log" 2>&1
rc=$?
sha256sum runner/src/native_lab_runner.cpp runner/build-llvmbpf/micro_exec kprog/x86/x86_sim_local_bpf.h kprog/libnativeloader/build/trusted-native-loader kprog/trusted_service.py > "$D/micro-native-after.sha256"
printf '%s\n' "$rc" > "$D/micro-native-regression.exit"
exit "$rc"
