import pathlib,subprocess,os,sys,threading,queue,json,signal,hashlib
R=pathlib.Path('/workspaces/repository');O=R/'kprog/results/kprog_tv_20261107/micro-native-only';O.mkdir(parents=True,exist_ok=False)
state=O/'requests';state.mkdir(mode=0o700)
(O/'guest-driver.py').write_bytes(pathlib.Path(__file__).read_bytes())
env=dict(os.environ,PATH='/usr/lib/llvm-18/bin:'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',BPFREJIT_MICRO_PROGRAM_DIR=str(R/'kprog/test/build-x86'),BPFREJIT_MICRO_RUNNER_BINARY=str(R/'runner/build-llvmbpf/micro_exec'),BPFREJIT_MICRO_PROOF_DIR=str(R/'kprog/test/build-x86/x86_sim_proofs'))
service=subprocess.Popen([sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(state),'--native-link',str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'--loader',str(R/'kprog/libnativeloader/build/trusted-native-loader')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,start_new_session=True,env=env)
q=queue.Queue()
def drain():
 with (O/'service.log').open('w') as f:
  for line in service.stdout:f.write(line);f.flush();q.put(line)
 q.put(None)
t=threading.Thread(target=drain);t.start()
try:
 line=q.get()
 if line is None or not json.loads(line).get('ready'):raise RuntimeError('common service did not register')
 cmd=[sys.executable,str(R/'micro/driver.py'),'--suite',str(R/'micro/config/micro_stage2.yaml'),'--runtime','native_kernel','--runtime','kernel','--runtime','native_proof','--samples','1','--warmups','0','--inner-repeat','1','--output',str(O/'driver.json')]
 (O/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (O/'driver.log').open('w') as f:rc=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 (O/'exit.json').write_text(json.dumps({'driver_exit':rc})+'\n')
finally:
 os.killpg(service.pid,signal.SIGTERM);service.wait();t.join()
raise SystemExit(rc)
