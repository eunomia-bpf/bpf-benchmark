#!/usr/bin/python3
import os,sys,json,hashlib
from pathlib import Path
root=Path('/workspaces/.agent-state/kprog-lanes/T')
header=root/'candidate-simulator.h'
args=sys.argv[1:]
inject=('-target' in args and args[args.index('-target')+1]=='bpf')
actual=['/usr/lib/llvm-18/bin/clang']
if inject:actual+=['-include',str(header),'-I','/workspaces/repository/kprog/x86']
actual+=args
if inject:
 live=Path(os.environ['BPFREJIT_NATIVE_LOADER_TV_DIR']).parent
 (live/'candidate-simulator.h').write_bytes(header.read_bytes())
 (live/'candidate-compiler.py').write_bytes(Path(__file__).read_bytes())
 with (live/'candidate-compiler-command.jsonl').open('a') as out:
  out.write(json.dumps(dict(command=actual,header_sha256=hashlib.sha256(header.read_bytes()).hexdigest()))+'\n')
os.execv(actual[0],actual)
