#!/bin/bash
cd /workspaces/.agent-state/kprog-lanes/T/abi-clean-source/kprog/x86/native_lab/native_link
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-x86-abi-final-validation.exit
{
 taskset -c 16-19 cargo test --target-dir /workspaces/.agent-state/kprog-lanes/T/native-link-abi-target &&
 taskset -c 16-19 cargo build --target-dir /workspaces/.agent-state/kprog-lanes/T/native-link-abi-target &&
 cd /workspaces/repository &&
 cp /workspaces/.agent-state/kprog-lanes/T/native-link-abi-target/debug/native-link kprog/tv/build/native-link-abi &&
 taskset -c 16-19 make -C kprog/tv x86-native-abi-check X86_ABI_NATIVE_LINK=/workspaces/repository/kprog/tv/build/native-link-abi &&
 taskset -c 16-19 make -C kprog/tv x86-native-abi-kernel-check
} > /workspaces/.agent-state/kprog-lanes/T/local-x86-abi-final-validation.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-x86-abi-final-validation.exit
exit "$rc"
