#!/bin/bash
cd /workspaces/repository/kprog/formal
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-return-final.exit
taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R ../tv -o ../tv/build/PacketCheckedBlocks.olean ../tv/PacketCheckedBlocks.lean > /workspaces/.agent-state/kprog-lanes/T/local-packet-return-final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-return-final.exit
exit "$rc"
