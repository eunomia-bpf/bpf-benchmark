import SimpleStoreCertificate
import PacketCompiled
set_option maxRecDepth 4096
set_option maxHeartbeats 2000000
namespace KProgTV.PacketStoreTransport
open KProgFormal.Reference KProgTV.PacketCompiled

/-- The two store bodies have different byte locations and final branch span.
Only PC is transported. All canonical memory/fault/register effects are kept. -/
def transferPC (s : AArch64.State) : AArch64.State :=
  { s with pc := if s.pc = (80#64) then (64#64) else s.pc - (12#64) }
def transferTransition (t : Transition AArch64.State) : Transition AArch64.State :=
  { t with state := transferPC t.state }
def sourceAt (s : AArch64.State) (offset : Nat) : AArch64.State :=
  { s with pc := BitVec.ofNat 64 (44 + offset) }

theorem packet_decode32 : AArch64.decode (native.extract 32 36) =
    .ok (.moveImmediate .w32 9 0x614e) := by rfl
theorem packet_decode36 : AArch64.decode (native.extract 36 40) =
    .ok (.moveImmediate .w32 0 2) := by rfl
theorem packet_decode40 : AArch64.decode (native.extract 40 44) =
    .ok (.memory ⟨.word, .store 31, 8, 3⟩) := by rfl
theorem packet_decode44 : AArch64.decode (native.extract 44 48) =
    .ok (.memory ⟨.byte, .store 31, 8, 7⟩) := by rfl
theorem packet_decode48 : AArch64.decode (native.extract 48 52) =
    .ok (.memory ⟨.half, .store 9, 8, 0⟩) := by rfl
theorem packet_decode52 : AArch64.decode (native.extract 52 56) =
    .ok (.moveImmediate .w32 9 0xbc) := by rfl
theorem packet_decode56 : AArch64.decode (native.extract 56 60) =
    .ok (.memory ⟨.byte, .store 9, 8, 2⟩) := by rfl
theorem packet_decode60 : AArch64.decode (native.extract 60 64) = .ok (.branch 4) := by rfl


def stepCommutes (s : AArch64.State) (offset : Nat) : Prop :=
  ARM64Path.step 0 native (transferPC (sourceAt s offset)) =
    (ARM64Path.step 0 SimpleCompiled.native (sourceAt s offset)).map transferTransition

theorem all_store_steps (s : AArch64.State) : ∀ position : Fin 8, stepCommutes s (position.val*4) := by
  simp only [Fin.forall_fin_succ]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  all_goals first | (intro impossible; exact Fin.elim0 impossible) | skip
  all_goals simp only [Fin.val_zero, Fin.val_succ, Fin.ofNat', Fin.instOfNat]
  all_goals simp +decide [stepCommutes, sourceAt, transferPC, transferTransition,
    ARM64Path.step, native_size, SimpleStoreCertificate.native_size,
    Fin.val_zero, Fin.val_succ, Fin.ofNat', Fin.instOfNat,
    packet_decode32, packet_decode36, packet_decode40, packet_decode44,
    packet_decode48, packet_decode52, packet_decode56, packet_decode60,
    SimpleStoreCertificate.decode44, SimpleStoreCertificate.decode48,
    SimpleStoreCertificate.decode52, SimpleStoreCertificate.decode56,
    SimpleStoreCertificate.decode60, SimpleStoreCertificate.decode64,
    SimpleStoreCertificate.decode68, SimpleStoreCertificate.decode72,
    AArch64.step, AArch64.memoryStep, AArch64.memoryBase, AArch64.readReg,
    AArch64.spAlignmentFault, AArch64.MemoryWidth.bytes, AArch64.branchStep,
    AArch64.writeReg, AArch64.narrow, AArch64.Width.bits, writeMemory,
    Except.bind, Except.map, Except.pure, Bind.bind, Pure.pure, Except.instMonad]
  all_goals repeat' first | rfl | (split <;> simp_all)

def allowed (position : Nat) : Prop := ∃ index : Fin 8, position = 44 + index.val*4

theorem native_evaluation_execution (positions : List Nat)
    (inside : ∀ position ∈ positions, allowed position)
    (s : AArch64.State) (result : Transition AArch64.State)
    (accepted : ARM64Path.evaluate 0 SimpleCompiled.native positions s = .ok result) :
    Execution (ARM64Path.instructionStep 0 native) (transferPC s) result.events (transferPC result.state) := by
  apply ARM64Path.evaluate_execution_transport 0 0 SimpleCompiled.native native transferPC allowed
    ?_ positions inside s result accepted
  intro before position valid pc effect executed
  obtain ⟨index, equal⟩ := valid
  have actualPosition : before.pc = BitVec.ofNat 64 (44 + index.val*4) := by
    simpa +decide [equal] using pc
  have fixed : sourceAt before (index.val*4) = before := by
    unfold sourceAt
    rw [← actualPosition]
  have same := all_store_steps before index
  unfold stepCommutes at same
  rw [fixed] at same
  refine ⟨transferTransition effect, ?_, rfl, rfl⟩
  simpa only [executed, Except.map] using same


def faultStays (s : AArch64.State) (offset : Nat) : Prop :=
  ∀ result, ARM64Path.step 0 SimpleCompiled.native (sourceAt s offset) = .ok result →
    ∀ reason, result.fault = some reason → result.state.pc = (sourceAt s offset).pc

theorem all_source_fault_steps (s : AArch64.State) :
    ∀ position : Fin 8, faultStays s (position.val*4) := by
  simp only [Fin.forall_fin_succ]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  all_goals first | (intro impossible; exact Fin.elim0 impossible) | skip
  all_goals simp only [Fin.val_zero, Fin.val_succ, Fin.ofNat', Fin.instOfNat]
  all_goals simp +decide [faultStays, sourceAt, ARM64Path.step, SimpleStoreCertificate.native_size,
    SimpleStoreCertificate.decode44, SimpleStoreCertificate.decode48,
    SimpleStoreCertificate.decode52, SimpleStoreCertificate.decode56,
    SimpleStoreCertificate.decode60, SimpleStoreCertificate.decode64,
    SimpleStoreCertificate.decode68, SimpleStoreCertificate.decode72,
    AArch64.step, AArch64.memoryStep, AArch64.memoryBase, AArch64.readReg,
    AArch64.spAlignmentFault, AArch64.MemoryWidth.bytes, AArch64.branchStep,
    AArch64.writeReg, AArch64.narrow, AArch64.Width.bits, writeMemory,
    Except.bind, Except.map, Except.pure, Bind.bind, Pure.pure, Except.instMonad]
  all_goals repeat' first | rfl | (split <;> simp_all)

theorem fault_step_pc (s : AArch64.State) (index : Fin 8)
    (pc : s.pc = BitVec.ofNat 64 (44+index.val*4)) (result : Transition AArch64.State)
    (executed : ARM64Path.step 0 SimpleCompiled.native s = .ok result)
    (reason : Fault) (fault : result.fault = some reason) : result.state.pc = s.pc := by
  have fixed : sourceAt s (index.val*4) = s := by unfold sourceAt; rw [← pc]
  have stays := all_source_fault_steps s index
  unfold faultStays at stays
  rw [fixed] at stays
  exact stays result executed reason fault

theorem evaluation_fault_position (positions : List Nat)
    (inside : ∀ position ∈ positions, allowed position)
    (s : AArch64.State) (result : Transition AArch64.State)
    (accepted : ARM64Path.evaluate 0 SimpleCompiled.native positions s = .ok result)
    (reason : Fault) (fault : result.fault = some reason) :
    ∃ index : Fin 8, result.state.pc = BitVec.ofNat 64 (44+index.val*4) := by
  induction positions generalizing s result with
  | nil => simp [ARM64Path.evaluate] at accepted; cases accepted; cases fault
  | cons position rest ih =>
    simp only [ARM64Path.evaluate] at accepted
    split at accepted
    · simp at accepted
    · rename_i matching
      obtain ⟨index, equal⟩ := inside position (by simp)
      have pc : s.pc = BitVec.ofNat 64 (44+index.val*4) := by simpa +decide [equal] using matching
      cases executed : ARM64Path.step 0 SimpleCompiled.native s with
      | error error => rw [executed] at accepted; cases accepted
      | ok first =>
        rw [executed] at accepted
        cases firstFault : first.fault with
        | some why =>
          have unchanged := fault_step_pc s index pc first executed why firstFault
          cases rest with
          | nil =>
            simp [executed, firstFault] at accepted
            cases accepted
            exact ⟨index, unchanged.trans pc⟩
          | cons next tail => simp [executed, firstFault] at accepted
        | none =>
          simp only [firstFault, Option.isSome, ↓reduceIte] at accepted
          cases continued : ARM64Path.evaluate 0 SimpleCompiled.native rest first.state with
          | error error => rw [continued] at accepted; simp [firstFault] at accepted
          | ok tail =>
            rw [continued] at accepted
            simp [firstFault] at accepted
            cases accepted
            exact ih (fun pos member => inside pos (List.mem_cons_of_mem _ member)) first.state tail continued fault

end KProgTV.PacketStoreTransport
#print axioms KProgTV.PacketStoreTransport.all_store_steps

#print axioms KProgTV.PacketStoreTransport.native_evaluation_execution

#print axioms KProgTV.PacketStoreTransport.evaluation_fault_position

#print axioms KProgTV.PacketStoreTransport.all_source_fault_steps
