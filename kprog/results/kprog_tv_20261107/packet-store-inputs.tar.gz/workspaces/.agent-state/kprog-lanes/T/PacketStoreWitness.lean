import PacketProofStoreTransport
set_option maxRecDepth 4096
set_option maxHeartbeats 2000000
namespace KProgTV.PacketStoreTransport
open KProgFormal.Reference KProgTV.PacketCompiled

def proofAllowed (position : Nat) : Prop := ∃ index : Fin 13, position = 14 + index.val

theorem proof_evaluation_execution (positions : List Nat)
    (inside : ∀ position ∈ positions, proofAllowed position)
    (s : BPF.State) (result : Transition BPF.State)
    (accepted : BPFPath.evaluate PacketCheckedPlatform.externals SimpleCompiled.proof positions s = .ok result) :
    Execution PacketCheckedPlatform.instructionStep (proofTransfer s) result.events (proofTransfer result.state) := by
  apply BPFPath.evaluate_execution_transport PacketCheckedPlatform.externals SimpleCompiled.proof
    proofTransfer PacketCheckedPlatform.instructionStep proofAllowed ?_ positions inside s result accepted
  intro before position valid pc effect executed
  obtain ⟨index, equal⟩ := valid
  have actualPosition : before.pc = Int.ofNat (14+index.val) := by simpa only [equal] using pc
  have fixed : proofSourceAt before index.val = before := by
    unfold proofSourceAt
    rw [← actualPosition]
  have same := all_proof_store_steps PacketCheckedPlatform.externals before index
  unfold proofStepCommutes at same
  rw [fixed] at same
  have physical : BPF.step PacketCheckedPlatform.externals PacketCheckedPlatform.physical (proofTransfer before) =
      .ok (proofTransferTransition effect) := by simpa only [executed, Except.map] using same
  exact ⟨proofTransferTransition effect, PacketCheckedPlatform.accepted_step _ _ physical, rfl, rfl⟩

theorem native_positions_inside (memory : Memory) (pointer : Word) :
    ∀ pc ∈ SimpleStoreCertificate.nativePositions memory pointer, allowed pc := by
  intro pc member
  have bounds : 44 ≤ pc ∧ pc ≤ 72 ∧ pc % 4 = 0 := by
    unfold SimpleStoreCertificate.nativePositions at member
    repeat' first | (split at member) | (simp at member; omega)
  refine ⟨⟨(pc-44)/4, by omega⟩, ?_⟩
  change pc = 44 + (pc-44)/4*4
  omega

theorem proof_positions_inside (memory : Memory) (pointer : Word) :
    ∀ pc ∈ SimpleStoreCertificate.proofPositions memory pointer, proofAllowed pc := by
  intro pc member
  have bounds : 14 ≤ pc ∧ pc ≤ 26 := by
    unfold SimpleStoreCertificate.proofPositions at member
    repeat' first | (split at member) | (simp at member; omega)
  refine ⟨⟨pc-14, by omega⟩, ?_⟩
  change pc = 14 + (pc-14)
  omega

/-- Exact compiled-PC correspondence; this is not an instruction semantics. -/
def proofNativePC (pc : Int) : Word :=
  let source := SimpleStoreCertificate.proofNativePC (pc+3)
  if source = (80#64) then (64#64) else source - (12#64)

/-- Both actual store executions retain complete mapped states, exact ordered
writes and first faults. No permission check is added to either artifact. -/
theorem store_execution_witnesses (related : Memory → Memory → Prop)
    (storeRelated : ∀ {first second}, related first second → ∀ address value count,
      related (storeMemory first address value count) (storeMemory second address value count))
    (n : AArch64.State) (p : BPF.State) (pointer : Word)
    (permissions : n.memory.writable = p.memory.writable) (initial : related n.memory p.memory) :
    ∃ (nr : Transition AArch64.State) (pr : Transition BPF.State),
      Execution (ARM64Path.instructionStep 0 native)
        (transferPC (SimpleStoreCertificate.nativeInitial n pointer)) nr.events (transferPC nr.state) ∧
      Execution PacketCheckedPlatform.instructionStep
        (proofTransfer (SimpleStoreCertificate.proofInitial { n with memory := p.memory } p pointer))
        pr.events (proofTransfer pr.state) ∧
      transferPC nr.state = transferPC (SimpleStoreCertificate.nativeStoreShape n pointer nr.state) ∧
      proofTransfer pr.state = proofTransfer (SimpleStoreCertificate.proofStoreShape p pointer pr.state) ∧
      related (transferPC nr.state).memory (proofTransfer pr.state).memory ∧
      nr.events = pr.events ∧ nr.fault = pr.fault ∧
      (transferPC nr.state).pc = proofNativePC (proofTransfer pr.state).pc ∧
      (∀ event ∈ nr.events, match event with
        | .memory .write _ bytes _ => bytes.length < 8 | .fault _ => True | _ => False) ∧
      (nr.fault = none ↔ (proofTransfer pr.state).pc = 24) ∧
      (∀ reason, nr.fault = some reason →
        ARM64Path.step 0 native (transferPC nr.state) =
          .ok ⟨transferPC nr.state, [.fault reason], some reason⟩ ∧ Event.fault reason ∈ nr.events) := by
  obtain ⟨nr, pr, nativeRun, proofRun, nativeShape, proofShape, memory, events, fault, pc, short, noFault, closed⟩ :=
    SimpleStoreCertificate.store_transition_relation related storeRelated n p pointer
      PacketCheckedPlatform.externals permissions initial
  have nativeExecution := native_evaluation_execution _ (native_positions_inside n.memory pointer) _ nr nativeRun
  have proofExecution := proof_evaluation_execution _ (proof_positions_inside p.memory pointer) _ pr proofRun
  have corresponding : (transferPC nr.state).pc = proofNativePC (proofTransfer pr.state).pc := by
    have cancel : pr.state.pc - 3 + 3 = pr.state.pc := by omega
    simp only [transferPC, proofTransfer, proofNativePC, cancel, pc]
  have returned : nr.fault = none ↔ (proofTransfer pr.state).pc = 24 := by
    rw [noFault]
    change pr.state.pc = 27 ↔ pr.state.pc - 3 = 24
    omega
  have faultClosed : ∀ reason, nr.fault = some reason →
      ARM64Path.step 0 native (transferPC nr.state) =
        .ok ⟨transferPC nr.state, [.fault reason], some reason⟩ ∧ Event.fault reason ∈ nr.events := by
    intro reason hasFault
    obtain ⟨index, position⟩ := evaluation_fault_position _ (native_positions_inside n.memory pointer)
      _ nr nativeRun reason hasFault
    have fixed : sourceAt nr.state (index.val*4) = nr.state := by
      unfold sourceAt
      rw [← position]
    have same := all_store_steps nr.state index
    unfold stepCommutes at same
    rw [fixed, (closed reason hasFault).1] at same
    exact ⟨by simpa only [Except.map, transferTransition] using same, (closed reason hasFault).2⟩
  exact ⟨nr, pr, nativeExecution, proofExecution, congrArg transferPC nativeShape,
    congrArg proofTransfer proofShape, memory, events, fault, corresponding, short, returned, faultClosed⟩
end KProgTV.PacketStoreTransport
#print axioms KProgTV.PacketStoreTransport.store_execution_witnesses
