import PacketStoreTransport
import PacketCheckedPlatform
set_option maxRecDepth 4096
set_option maxHeartbeats 2000000
namespace KProgTV.PacketStoreTransport
open KProgFormal.Reference KProgTV.PacketCompiled

def proofTransfer (s : BPF.State) : BPF.State := { s with pc := s.pc - 3 }
def proofTransferTransition (t : Transition BPF.State) : Transition BPF.State :=
  { t with state := proofTransfer t.state }
def proofSourceAt (s : BPF.State) (offset : Nat) : BPF.State :=
  { s with pc := Int.ofNat (14+offset) }

theorem packet_proofDecode11 : BPF.decode PacketCheckedPlatform.physical 11 = .ok ⟨191, 2, 1, 0, 0⟩ := rfl
theorem packet_proofDecode12 : BPF.decode PacketCheckedPlatform.physical 12 = .ok ⟨7, 2, 0, 0, 3⟩ := rfl
theorem packet_proofDecode13 : BPF.decode PacketCheckedPlatform.physical 13 = .ok ⟨183, 3, 0, 0, 0⟩ := rfl
theorem packet_proofDecode14 : BPF.decode PacketCheckedPlatform.physical 14 = .ok ⟨99, 2, 3, 0, 0⟩ := rfl
theorem packet_proofDecode15 : BPF.decode PacketCheckedPlatform.physical 15 = .ok ⟨191, 2, 1, 0, 0⟩ := rfl
theorem packet_proofDecode16 : BPF.decode PacketCheckedPlatform.physical 16 = .ok ⟨7, 2, 0, 0, 7⟩ := rfl
theorem packet_proofDecode17 : BPF.decode PacketCheckedPlatform.physical 17 = .ok ⟨115, 2, 3, 0, 0⟩ := rfl
theorem packet_proofDecode18 : BPF.decode PacketCheckedPlatform.physical 18 = .ok ⟨183, 2, 0, 0, 24910⟩ := rfl
theorem packet_proofDecode19 : BPF.decode PacketCheckedPlatform.physical 19 = .ok ⟨107, 1, 2, 0, 0⟩ := rfl
theorem packet_proofDecode20 : BPF.decode PacketCheckedPlatform.physical 20 = .ok ⟨7, 1, 0, 0, 2⟩ := rfl
theorem packet_proofDecode21 : BPF.decode PacketCheckedPlatform.physical 21 = .ok ⟨183, 2, 0, 0, 188⟩ := rfl
theorem packet_proofDecode22 : BPF.decode PacketCheckedPlatform.physical 22 = .ok ⟨115, 1, 2, 0, 0⟩ := rfl
theorem packet_proofDecode23 : BPF.decode PacketCheckedPlatform.physical 23 = .ok ⟨183, 0, 0, 0, 2⟩ := rfl



def proofStepCommutes (env : BPF.Environment) (s : BPF.State) (offset : Nat) : Prop :=
  BPF.step env PacketCheckedPlatform.physical (proofTransfer (proofSourceAt s offset)) =
    (BPF.step env SimpleCompiled.proof (proofSourceAt s offset)).map proofTransferTransition

theorem all_proof_store_steps (env : BPF.Environment) (s : BPF.State) :
    ∀ position : Fin 13, proofStepCommutes env s position.val := by
  simp only [Fin.forall_fin_succ]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  all_goals first | (intro impossible; exact Fin.elim0 impossible) | skip
  all_goals simp only [Fin.val_zero, Fin.val_succ, Fin.ofNat', Fin.instOfNat]
  all_goals simp +decide [proofStepCommutes, proofSourceAt, proofTransfer, proofTransferTransition,
    BPF.step, BPF.execute, BPF.source, BPF.alu, BPF.setReg, BPF.store, writeMemory,
    packet_proofDecode11, packet_proofDecode12, packet_proofDecode13,
    packet_proofDecode14, packet_proofDecode15, packet_proofDecode16,
    packet_proofDecode17, packet_proofDecode18, packet_proofDecode19,
    packet_proofDecode20, packet_proofDecode21, packet_proofDecode22, packet_proofDecode23,
    SimpleStoreCertificate.proofDecode14, SimpleStoreCertificate.proofDecode15,
    SimpleStoreCertificate.proofDecode16, SimpleStoreCertificate.proofDecode17,
    SimpleStoreCertificate.proofDecode18, SimpleStoreCertificate.proofDecode19,
    SimpleStoreCertificate.proofDecode20, SimpleStoreCertificate.proofDecode21,
    SimpleStoreCertificate.proofDecode22, SimpleStoreCertificate.proofDecode23,
    SimpleStoreCertificate.proofDecode24, SimpleStoreCertificate.proofDecode25,
    SimpleStoreCertificate.proofDecode26,
    Except.bind, Except.map, Except.pure, Bind.bind, Pure.pure, Except.instMonad]
  all_goals repeat' first | rfl | (split <;> simp_all)
end KProgTV.PacketStoreTransport
#print axioms KProgTV.PacketStoreTransport.all_proof_store_steps
