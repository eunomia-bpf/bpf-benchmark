#!/bin/bash
cd /workspaces/repository/kprog/tv
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-invocation-final.exit
{
 cd ../formal && taskset -c 16-19 env LEAN_PATH=../tv/build:../tv/build/simple-arm64:../tv/build/simple-checked lake env lean -R ../tv -o ../tv/build/SimpleInvocationABI.olean ../tv/SimpleInvocationABI.lean &&
 cd ../tv && python3 test_emitted_sites.py build/capture-loader-arm64-emitted &&
 python3 extract_simple_emitted.py build/capture-loader-arm64-emitted build/simple-emitted &&
 taskset -c 16-19 make simple-emitted-certificate &&
 taskset -c 16-19 make simple-emitted-negative-check
} > /workspaces/.agent-state/kprog-lanes/T/local-simple-invocation-final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-simple-invocation-final.exit
exit "$rc"
