#!/bin/bash
cd /workspaces/repository/kprog/tv
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-final.exit
{
 python3 extract_simple_packet.py build-arm64/simple-packet/checked-kernel.log build/simple-packet-arm64 build/capture-loader-arm64-simple-packet &&
 cd ../formal && taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-arm64 lake env lean -R ../tv/build/simple-packet-arm64 -o ../tv/build/simple-packet-arm64/PacketCompiled.olean ../tv/build/simple-packet-arm64/PacketCompiled.lean &&
 taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R ../tv -o ../tv/build/PacketGuardCertificate.olean ../tv/PacketGuardCertificate.lean &&
 cd ../tv && make simple-checked-kernel-check-arm64 CAPTURE_ARM64_OUTPUT=build-arm64/simple-recheck &&
 python3 test_emitted_sites.py build/capture-loader-arm64-simple-packet --native-bytes 68 --store-offset 40 &&
 python3 test_emitted_sites.py build/capture-loader-arm64-emitted
} > /workspaces/.agent-state/kprog-lanes/T/local-packet-final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-final.exit
exit "$rc"
