#!/bin/bash
cd /workspaces/repository/kprog/tv
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-inputs.exit
{
 python3 extract_simple_packet.py build-arm64/simple-packet/checked-kernel.log build/simple-packet-arm64 build/capture-loader-arm64-simple-packet &&
 python3 test_emitted_sites.py build/capture-loader-arm64-simple-packet --native-bytes 68 --store-offset 40 &&
 python3 test_emitted_sites.py build/capture-loader-arm64-emitted &&
 python3 extract_simple_arm64.py &&
 cd ../formal && taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-arm64 lake env lean -R ../tv/build/simple-packet-arm64 -o ../tv/build/simple-packet-arm64/PacketCompiled.olean ../tv/build/simple-packet-arm64/PacketCompiled.lean
} > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-inputs.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-inputs.exit
exit "$rc"
