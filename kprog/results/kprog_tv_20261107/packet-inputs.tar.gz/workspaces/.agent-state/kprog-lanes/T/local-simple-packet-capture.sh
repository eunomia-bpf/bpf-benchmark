#!/bin/bash
cd /workspaces/repository
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-capture.exit
{
 taskset -c 8-11 make -C kprog/tv simple-checked-kernel-check-arm64 CAPTURE_ARM64_PROGRAM=simple_packet CAPTURE_ARM64_ARTIFACTS=build/simple-packet-arm64 CAPTURE_ARM64_OUTPUT=build-arm64/simple-packet &&
 cd kprog/tv && python3 extract_checked.py build-arm64/simple-packet/checked-kernel.log build/simple-packet-checked --exports build/capture-loader-arm64-simple-packet &&
 python3 test_emitted_sites.py build/capture-loader-arm64-simple-packet
} > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-capture.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-capture.exit
exit "$rc"
