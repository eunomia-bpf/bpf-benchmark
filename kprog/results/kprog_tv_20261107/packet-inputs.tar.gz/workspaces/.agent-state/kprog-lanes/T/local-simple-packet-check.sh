#!/bin/bash
bash /workspaces/.agent-state/kprog-lanes/T/local-simple-packet-inputs-v2.sh && bash /workspaces/.agent-state/kprog-lanes/T/local-packet-guard.sh
