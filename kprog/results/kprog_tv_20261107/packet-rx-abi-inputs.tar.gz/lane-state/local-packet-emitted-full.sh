#!/bin/bash
cd /workspaces/repository
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-emitted-full.exit
git rev-parse HEAD > /workspaces/.agent-state/kprog-lanes/T/local-packet-emitted-full.source
{
 taskset -c 8-11 make -C kprog/tv simple-packet-emitted-check &&
 taskset -c 8-11 make -C kprog/tv simple-packet-emitted-negative-check simple-emitted-negative-check &&
 taskset -c 8-11 make -C kprog/tv simple-emitted-certificate
} > /workspaces/.agent-state/kprog-lanes/T/local-packet-emitted-full.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-emitted-full.exit
exit "$rc"
