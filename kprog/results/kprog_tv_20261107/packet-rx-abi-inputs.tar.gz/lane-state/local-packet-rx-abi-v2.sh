#!/bin/bash
cd /workspaces/repository/kprog/formal
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-v2.exit
cd kprog/formal
{
 taskset -c 8-11 env LEAN_PATH=../tv/build:/workspaces/.agent-state/kprog-lanes/T:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketPCRelocation.olean /workspaces/.agent-state/kprog-lanes/T/PacketPCRelocation.lean &&
 taskset -c 8-11 env LEAN_PATH=../tv/build:/workspaces/.agent-state/kprog-lanes/T:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketExecutionRelocation.olean /workspaces/.agent-state/kprog-lanes/T/PacketExecutionRelocation.lean &&
 taskset -c 8-11 env LEAN_PATH=../tv/build:/workspaces/.agent-state/kprog-lanes/T:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketInvocationABI.olean /workspaces/.agent-state/kprog-lanes/T/PacketInvocationABI.lean
} > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-v2.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-v2.exit
exit "$rc"
