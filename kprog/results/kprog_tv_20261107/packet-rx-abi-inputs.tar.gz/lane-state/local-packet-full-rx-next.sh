#!/bin/bash
cd /workspaces/repository
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-invocation-full.exit
git rev-parse HEAD > /workspaces/.agent-state/kprog-lanes/T/local-packet-invocation-full.source
taskset -c 8-11 make -C kprog/tv simple-packet-invocation-check > /workspaces/.agent-state/kprog-lanes/T/local-packet-invocation-full.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-invocation-full.exit
if [ "$rc" -ne 0 ]; then exit "$rc"; fi
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-next.exit
cd kprog/formal
{
 taskset -c 8-11 env LEAN_PATH=/workspaces/.agent-state/kprog-lanes/T:../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketPCRelocation.olean /workspaces/.agent-state/kprog-lanes/T/PacketPCRelocation.lean &&
 taskset -c 8-11 env LEAN_PATH=/workspaces/.agent-state/kprog-lanes/T:../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketExecutionRelocation.olean /workspaces/.agent-state/kprog-lanes/T/PacketExecutionRelocation.lean &&
 taskset -c 8-11 env LEAN_PATH=/workspaces/.agent-state/kprog-lanes/T:../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R /workspaces/.agent-state/kprog-lanes/T -o /workspaces/.agent-state/kprog-lanes/T/PacketInvocationABI.olean /workspaces/.agent-state/kprog-lanes/T/PacketInvocationABI.lean
} > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-next.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-rx-abi-next.exit
exit "$rc"
