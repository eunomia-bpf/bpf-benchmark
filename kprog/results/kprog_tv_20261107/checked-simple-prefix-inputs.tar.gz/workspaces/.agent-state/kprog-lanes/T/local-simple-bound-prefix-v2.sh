#!/bin/bash
printf 'waiting for store dependency\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-bound-prefix-v2.exit
while [ "$(cat /workspaces/.agent-state/kprog-lanes/T/local-prefix-composition-v2.exit)" = running ]; do sleep 5; done
if [ "$(cat /workspaces/.agent-state/kprog-lanes/T/local-prefix-composition-v2.exit)" != 0 ]; then
 printf 'dependency failed\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-bound-prefix-v2.exit
 exit 1
fi
cd /workspaces/repository/kprog/formal
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-bound-prefix-v2.exit
taskset -c 16-19 env LEAN_PATH=../tv/build:../tv/build/simple-arm64:../tv/build/simple-checked lake env lean -R ../tv ../tv/SimpleCheckedBlocks.lean > /workspaces/.agent-state/kprog-lanes/T/local-simple-bound-prefix-v2.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-simple-bound-prefix-v2.exit
exit "$rc"
