#!/bin/bash
cd /workspaces/repository/kprog/formal
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-packet-entry-final.exit
{
 taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R ../tv -o ../tv/build/PacketEntryCertificate.olean ../tv/PacketEntryCertificate.lean &&
 taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R ../tv -o ../tv/build/PacketCheckedPlatform.olean ../tv/PacketCheckedPlatform.lean &&
 taskset -c 8-11 env LEAN_PATH=../tv/build:../tv/build/simple-checked:../tv/build/simple-arm64:../tv/build/simple-packet-arm64 lake env lean -R ../tv -o ../tv/build/PacketCheckedBlocks.olean ../tv/PacketCheckedBlocks.lean &&
 cd ../tv && taskset -c 8-11 make simple-packet-entry-negative-check
} > /workspaces/.agent-state/kprog-lanes/T/local-packet-entry-final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-packet-entry-final.exit
exit "$rc"
