#!/bin/bash
cd /workspaces/repository
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-simple-actual-rx-check.exit
{
 taskset -c 16-19 make -C kprog/tv simple-execution-relocation-check -o simple-pc-relocation-check &&
 cd kprog/tv &&
 python3 extract_simple_emitted.py build/capture-loader-arm64-emitted build/simple-emitted &&
 taskset -c 16-19 make simple-emitted-certificate
} > /workspaces/.agent-state/kprog-lanes/T/local-simple-actual-rx-check.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-simple-actual-rx-check.exit
exit "$rc"
