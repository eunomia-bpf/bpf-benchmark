import KProgFormal.Reference.X86
set_option maxRecDepth 4096
set_option maxHeartbeats 4000000
open KProgFormal.Reference
namespace KProgTV.CompareOverflowReview
/-- C's proposed identity only for the actual width-truncated CMP
subtraction. No arbitrary result/SF premise, borrow, or added check. -/
theorem cmp_overflow_identity (width : X86.ScalarWidth) (left right old : Word) :
    (X86.arithmeticFlags width true false left right old).getLsbD 11 =
      Bool.xor ((X86.arithmeticFlags width true false left right old).getLsbD 7)
        (((left.setWidth width.bits).signExtend 64).slt ((right.setWidth width.bits).signExtend 64)) := by
  cases width <;>
    simp only [X86.arithmeticFlags,X86.ScalarWidth.bits,X86.ScalarWidth.bytes,
      X86.evenParity,X86.auxiliaryCarry]
  all_goals unfold Word at *
  all_goals bv_decide
end KProgTV.CompareOverflowReview
#print axioms KProgTV.CompareOverflowReview.cmp_overflow_identity
