#!/bin/sh
cd /workspaces/repository/kprog/formal
lake env lean /workspaces/.agent-state/kprog-lanes/T/cmp-overflow-review.lean > /workspaces/.agent-state/kprog-lanes/T/cmp-overflow-review.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/cmp-overflow-review.exit
exit "$rc"
