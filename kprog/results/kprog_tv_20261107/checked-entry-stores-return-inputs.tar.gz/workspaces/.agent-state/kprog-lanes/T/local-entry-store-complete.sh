#!/bin/bash
cd /workspaces/repository/kprog/formal
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-entry-store-complete.exit
taskset -c 16-19 env LEAN_PATH=../tv/build:../tv/build/simple-arm64:../tv/build/simple-checked lake env lean -R ../tv ../tv/SimpleCheckedBlocks.lean > /workspaces/.agent-state/kprog-lanes/T/local-entry-store-complete.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-entry-store-complete.exit
exit "$rc"
