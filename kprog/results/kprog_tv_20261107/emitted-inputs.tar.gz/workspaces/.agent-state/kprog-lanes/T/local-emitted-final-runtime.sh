#!/bin/bash
cd /workspaces/repository
printf 'running\n' > /workspaces/.agent-state/kprog-lanes/T/local-emitted-final-runtime.exit
{
 taskset -c 16-19 make -C kprog/libnativeloader BUILD_DIR=build-tv-context-v2-arm64 \
 LIBBPF_PREFIX=/workspaces/repository/runner/build-arm64-llvmbpf/vendor/libbpf/prefix \
 LIBBPF_LIBRARY=/workspaces/repository/runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a \
 KERNEL_OFFSETS_INCLUDE=/workspaces/repository/micro/programs/build-arm64 &&
 taskset -c 16-19 make -C kprog/tv simple-checked-kernel-check-arm64 &&
 taskset -c 16-19 make -C kprog/libnativeloader BUILD_DIR=build-tv-binding
} > /workspaces/.agent-state/kprog-lanes/T/local-emitted-final-runtime.log 2>&1
rc=$?
printf '%s\n' "$rc" > /workspaces/.agent-state/kprog-lanes/T/local-emitted-final-runtime.exit
exit "$rc"
