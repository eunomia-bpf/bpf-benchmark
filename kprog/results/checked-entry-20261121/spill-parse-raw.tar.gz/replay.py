from pathlib import Path
import json,sys,runpy,time,resource,hashlib,datetime
meta=json.loads(Path('/workspaces/kprog-raw/C/checked-entry-20261121/spill-parse-current.json').read_text())
raw=Path(meta['raw']);tmp=Path(meta['temporary'])
sys.argv=['kprog/x86/whole_word_spills.py',str(tmp/'input.mir'),str(tmp/'output.mir'),'--report',str(raw/'actual-lowering.json')]
start=time.perf_counter();cpu=time.process_time()
ns=runpy.run_path('kprog/x86/whole_word_spills.py',run_name='__main__')
wall=time.perf_counter()-start;cpu=time.process_time()-cpu
h=hashlib.sha256()
with (tmp/'output.mir').open('rb') as f:
 while chunk:=f.read(1024*1024):h.update(chunk)
expected=json.loads((raw/'expected-lowering.json').read_text())
actual=json.loads((raw/'actual-lowering.json').read_text())
expected.pop('source',None);actual.pop('source',None)
cache=ns['register_effects'].cache_info()
result=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=wall,cpu_seconds=cpu,max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,output_sha256=h.hexdigest(),output_bytes=(tmp/'output.mir').stat().st_size,output_byte_identical=h.hexdigest()==meta['expected_output']['sha256'],lowering_records_identical=actual==expected,cache=cache._asdict(),source_sha256=hashlib.sha256(Path('kprog/x86/whole_word_spills.py').read_bytes()).hexdigest(),kind='component regression replay; no application timing or isolated speedup claim')
(raw/'result.json').write_text(json.dumps(result,indent=2)+chr(10))
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['output_byte_identical'] and result['lowering_records_identical'] else 1)
