#!/bin/bash
cd /workspaces/repository
flock -s /workspaces/.agent-state/kprog-lanes/locks/timing taskset -c 20-23 python3 /workspaces/kprog-raw/C/checked-entry-20261121/spill-parse-20261122T022714Z/replay.py > /workspaces/kprog-raw/C/checked-entry-20261121/spill-parse-20261122T022714Z/replay.log 2>&1
code=$?
printf "%s" "$code" > /workspaces/kprog-raw/C/checked-entry-20261121/spill-parse-20261122T022714Z/exit-code
