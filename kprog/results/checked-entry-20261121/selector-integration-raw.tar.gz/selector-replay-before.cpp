#include <iostream>
struct Agreement { size_t length=0, leading=0, aligned=0; std::string difference; };
int main(int argc,char**argv) {
 std::ifstream f(argv[2],std::ios::binary);
 std::vector<char> bytes((std::istreambuf_iterator<char>(f)),{});
 std::vector<bpf_insn> insns(bytes.size()/sizeof(bpf_insn));
 std::memcpy(insns.data(),bytes.data(),bytes.size());
 if(argc>3) { bpf_insn call{};call.code=0x85;call.imm=174;insns.push_back(call); }
 bpf_prog_info info{}; info.type=BPF_PROG_TYPE_KPROBE;
 std::memcpy(info.name,"generic_kprobe_",15);
 auto result=resolve_native_manifest(argv[1],info,[](const auto&,const auto&){return Agreement{};},insns.size());
 std::cout<<result->native_object_path.filename().string()<<std::endl;
}
