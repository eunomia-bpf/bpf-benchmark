from pathlib import Path
import os,signal,sys,json,datetime,time
raw=Path(sys.argv[1]);fd=int(sys.argv[2])
m=json.loads((raw/'request.json').read_text())
gate=Path(m['gate'])
signal.pidfd_send_signal(fd,signal.SIGSTOP)
m['held_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
m['watcher_pid']=os.getpid()
m['state']='parent-loop-stopped; current child app continues; waiting for coordinator done file'
(raw/'held.json').write_text(json.dumps(m,indent=2)+chr(10))
print(json.dumps(m),flush=True)
while not gate.exists():
 time.sleep(10)
signal.pidfd_send_signal(fd,signal.SIGCONT)
m['resumed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
m['state']='parent-loop-resumed after coordinator done file exists'
(raw/'resumed.json').write_text(json.dumps(m,indent=2)+chr(10))
print(json.dumps(m),flush=True)
