#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(2) M(10) M(11) M(12) M(14) M(20) M(22) M(23) M(24)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 kprobe_calls[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ANDN_MEM, X86_OP_ANDN_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_MEMSET_REG, X86_OP_CALL_MEMSET_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_IMUL_IMM, X86_OP_IMUL_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_LOAD, X86_OP_MOVSX_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_RORX, X86_OP_RORX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_IMM, X86_OP_TEST_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_MEM_REG, X86_OP_TEST_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 40ULL);
x86_l_e:
	/* 0xe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_11:
	/* 0x11: mov    DWORD PTR [rsp+0xc],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607552ULL);
x86_l_19:
	/* 0x19: mov    rdi,QWORD PTR [rip+0x7d20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)process_call_heap));
x86_l_20:
	/* 0x20: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_25:
	/* 0x25: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2a:
	/* 0x2a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c:
	/* 0x2c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f:
	/* 0x2f: je     3e3 <generic_kprobe_filter_arg+0x3e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f, 0x3e3, x86_l_3e3);
x86_l_35:
	/* 0x35: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38:
	/* 0x38: mov    r12d,DWORD PTR [rax+0x5f00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_3f:
	/* 0x3f: lea    rsi,[rax+0x5ef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24312ULL);
x86_l_46:
	/* 0x46: mov    rdi,QWORD PTR [rip+0x7d20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)filter_map));
x86_l_4d:
	/* 0x4d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_52:
	/* 0x52: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_54:
	/* 0x54: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_57:
	/* 0x57: je     3c8 <generic_kprobe_filter_arg+0x3c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x57, 0x3c8, x86_l_3c8);
x86_l_5d:
	/* 0x5d: cmp    BYTE PTR [r14+0x5ee0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104316165685248ULL);
x86_l_65:
	/* 0x65: je     3c8 <generic_kprobe_filter_arg+0x3c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x65, 0x3c8, x86_l_3c8);
x86_l_6b:
	/* 0x6b: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6e:
	/* 0x6e: mov    eax,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_71:
	/* 0x71: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_74:
	/* 0x74: cmp    BYTE PTR [r14+rax*1+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 104183021699072ULL);
x86_l_7d:
	/* 0x7d: je     10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7d, 0x10c, x86_l_10c);
x86_l_83:
	/* 0x83: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_85:
	/* 0x85: mov    ecx,DWORD PTR [r15+rax*4+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 4ULL);
x86_l_8a:
	/* 0x8a: lea    rdx,[rcx+rax*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_8e:
	/* 0x8e: add    rdx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_92:
	/* 0x92: lea    rax,[rcx+rax*4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 2), 0ULL);
x86_l_96:
	/* 0x96: add    rax,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_9a:
	/* 0x9a: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_9f:
	/* 0x9f: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_a3:
	/* 0xa3: add    rax,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a6:
	/* 0xa6: add    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_aa:
	/* 0xaa: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_ac:
	/* 0xac: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_b2:
	/* 0xb2: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_b6:
	/* 0xb6: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_b9:
	/* 0xb9: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_bb:
	/* 0xbb: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_c0:
	/* 0xc0: mov    eax,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_c4:
	/* 0xc4: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_c7:
	/* 0xc7: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c9:
	/* 0xc9: and    ecx,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_cf:
	/* 0xcf: mov    ecx,DWORD PTR [rcx+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_d3:
	/* 0xd3: add    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_d6:
	/* 0xd6: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_d8:
	/* 0xd8: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_dd:
	/* 0xdd: mov    ebp,DWORD PTR [rax+r15*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R15, 0), 0ULL);
x86_l_e1:
	/* 0xe1: add    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_e4:
	/* 0xe4: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_e6:
	/* 0xe6: and    eax,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_eb:
	/* 0xeb: mov    QWORD PTR [rsp],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ef:
	/* 0xef: cmp    DWORD PTR [r15+rax*1],0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 25ULL);
x86_l_f4:
	/* 0xf4: jae    161 <generic_kprobe_filter_arg+0x161> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf4, 0x161, x86_l_161);
x86_l_f6:
	/* 0xf6: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fa:
	/* 0xfa: cmp    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_fe:
	/* 0xfe: je     3c8 <generic_kprobe_filter_arg+0x3c8> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfe, 0x3c8, x86_l_3c8);
x86_l_104:
	/* 0x104: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_106:
	/* 0x106: jne    3a2 <generic_kprobe_filter_arg+0x3a2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x106, 0x3a2, x86_l_3a2);
x86_l_10c:
	/* 0x10c: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_110:
	/* 0x110: jg     131 <generic_kprobe_filter_arg+0x131> */
	X86_SIM_X86_JCC(X86_CC_G, 0x110, 0x131, x86_l_131);
x86_l_112:
	/* 0x112: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_116:
	/* 0x116: je     3f8 <generic_kprobe_filter_arg+0x3f8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116, 0x3f8, x86_l_3f8);
x86_l_11c:
	/* 0x11c: test   r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_11f:
	/* 0x11f: je     405 <generic_kprobe_filter_arg+0x405> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11f, 0x405, x86_l_405);
x86_l_125:
	/* 0x125: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_129:
	/* 0x129: je     415 <generic_kprobe_filter_arg+0x415> */
	X86_SIM_X86_JCC(X86_CC_E, 0x129, 0x415, x86_l_415);
x86_l_12f:
	/* 0x12f: jmp    14f <generic_kprobe_filter_arg+0x14f> */
	X86_SIM_X86_JMP(0x12f, 0x14f, x86_l_14f);
x86_l_131:
	/* 0x131: cmp    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_135:
	/* 0x135: je     425 <generic_kprobe_filter_arg+0x425> */
	X86_SIM_X86_JCC(X86_CC_E, 0x135, 0x425, x86_l_425);
x86_l_13b:
	/* 0x13b: cmp    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_13f:
	/* 0x13f: je     435 <generic_kprobe_filter_arg+0x435> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13f, 0x435, x86_l_435);
x86_l_145:
	/* 0x145: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_149:
	/* 0x149: je     445 <generic_kprobe_filter_arg+0x445> */
	X86_SIM_X86_JCC(X86_CC_E, 0x149, 0x445, x86_l_445);
x86_l_14f:
	/* 0x14f: cmp    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_153:
	/* 0x153: jg     477 <generic_kprobe_filter_arg+0x477> */
	X86_SIM_X86_JCC(X86_CC_G, 0x153, 0x477, x86_l_477);
x86_l_159:
	/* 0x159: inc    r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_15c:
	/* 0x15c: jmp    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JMP(0x15c, 0x455, x86_l_455);
x86_l_161:
	/* 0x161: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_165:
	/* 0x165: add    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_168:
	/* 0x168: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16d:
	/* 0x16d: mov    r13d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_173:
	/* 0x173: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_178:
	/* 0x178: mov    edi,DWORD PTR [rax+r13*4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 2), 0ULL);
x86_l_17c:
	/* 0x17c: test   edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 1023ULL);
x86_l_182:
	/* 0x182: je     f6 <generic_kprobe_filter_arg+0xf6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x182, 0xf6, x86_l_f6);
x86_l_188:
	/* 0x188: add    edi,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RBP, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_18a:
	/* 0x18a: and    edi,0x3ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 1023ULL);
x86_l_190:
	/* 0x190: mov    ecx,DWORD PTR [r15+rdi*1+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RDI, 0), 4ULL);
x86_l_195:
	/* 0x195: cmp    ecx,0x23 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 35ULL);
x86_l_198:
	/* 0x198: je     10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x198, 0x10c, x86_l_10c);
x86_l_19e:
	/* 0x19e: add    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_R15, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1a1:
	/* 0x1a1: mov    eax,DWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a3:
	/* 0x1a3: cmp    rax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4ULL);
x86_l_1a7:
	/* 0x1a7: ja     10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1a7, 0x10c, x86_l_10c);
x86_l_1ad:
	/* 0x1ad: cmp    DWORD PTR [r14+rax*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 104041287778304ULL);
x86_l_1b6:
	/* 0x1b6: jne    10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b6, 0x10c, x86_l_10c);
x86_l_1bc:
	/* 0x1bc: mov    rax,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_1c4:
	/* 0x1c4: and    eax,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_1c9:
	/* 0x1c9: lea    rsi,[r14+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1cd:
	/* 0x1cd: add    rsi,0x90 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 144ULL);
x86_l_1d4:
	/* 0x1d4: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d7:
	/* 0x1d7: cmp    eax,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_1da:
	/* 0x1da: jle    1fb <generic_kprobe_filter_arg+0x1fb> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1da, 0x1fb, x86_l_1fb);
x86_l_1dc:
	/* 0x1dc: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1df:
	/* 0x1df: jg     22b <generic_kprobe_filter_arg+0x22b> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1df, 0x22b, x86_l_22b);
x86_l_1e1:
	/* 0x1e1: lea    edx,[rax-0x1c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551588ULL);
x86_l_1e4:
	/* 0x1e4: cmp    edx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1e7:
	/* 0x1e7: jb     271 <generic_kprobe_filter_arg+0x271> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e7, 0x271, x86_l_271);
x86_l_1ed:
	/* 0x1ed: cmp    eax,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1f0:
	/* 0x1f0: je     354 <generic_kprobe_filter_arg+0x354> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f0, 0x354, x86_l_354);
x86_l_1f6:
	/* 0x1f6: jmp    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JMP(0x1f6, 0x390, x86_l_390);
x86_l_1fb:
	/* 0x1fb: cmp    eax,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1fe:
	/* 0x1fe: jle    251 <generic_kprobe_filter_arg+0x251> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1fe, 0x251, x86_l_251);
x86_l_200:
	/* 0x200: lea    edx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_203:
	/* 0x203: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_206:
	/* 0x206: jb     271 <generic_kprobe_filter_arg+0x271> */
	X86_SIM_X86_JCC(X86_CC_B, 0x206, 0x271, x86_l_271);
x86_l_208:
	/* 0x208: lea    ecx,[rax-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_20b:
	/* 0x20b: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_20e:
	/* 0x20e: jb     354 <generic_kprobe_filter_arg+0x354> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20e, 0x354, x86_l_354);
x86_l_214:
	/* 0x214: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_217:
	/* 0x217: jne    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x217, 0x390, x86_l_390);
x86_l_21d:
	/* 0x21d: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_221:
	/* 0x221: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4c0, 0x226ULL);
x86_l_226:
	/* 0x226: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x226, 0x387, x86_l_387);
x86_l_22b:
	/* 0x22b: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_22e:
	/* 0x22e: jg     343 <generic_kprobe_filter_arg+0x343> */
	X86_SIM_X86_JCC(X86_CC_G, 0x22e, 0x343, x86_l_343);
x86_l_234:
	/* 0x234: lea    ecx,[rax-0x26] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551578ULL);
x86_l_237:
	/* 0x237: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_23a:
	/* 0x23a: jb     2fe <generic_kprobe_filter_arg+0x2fe> */
	X86_SIM_X86_JCC(X86_CC_B, 0x23a, 0x2fe, x86_l_2fe);
x86_l_240:
	/* 0x240: add    eax,0xffffffd8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967256ULL);
x86_l_243:
	/* 0x243: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_246:
	/* 0x246: jb     2f4 <generic_kprobe_filter_arg+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x246, 0x2f4, x86_l_2f4);
x86_l_24c:
	/* 0x24c: jmp    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JMP(0x24c, 0x390, x86_l_390);
x86_l_251:
	/* 0x251: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_254:
	/* 0x254: jg     2e1 <generic_kprobe_filter_arg+0x2e1> */
	X86_SIM_X86_JCC(X86_CC_G, 0x254, 0x2e1, x86_l_2e1);
x86_l_25a:
	/* 0x25a: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_25d:
	/* 0x25d: je     271 <generic_kprobe_filter_arg+0x271> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25d, 0x271, x86_l_271);
x86_l_25f:
	/* 0x25f: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_262:
	/* 0x262: je     371 <generic_kprobe_filter_arg+0x371> */
	X86_SIM_X86_JCC(X86_CC_E, 0x262, 0x371, x86_l_371);
x86_l_268:
	/* 0x268: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_26b:
	/* 0x26b: jne    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26b, 0x390, x86_l_390);
x86_l_271:
	/* 0x271: cmp    eax,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_274:
	/* 0x274: jle    2be <generic_kprobe_filter_arg+0x2be> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x274, 0x2be, x86_l_2be);
x86_l_276:
	/* 0x276: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_279:
	/* 0x279: ja     35b <generic_kprobe_filter_arg+0x35b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x279, 0x35b, x86_l_35b);
x86_l_27f:
	/* 0x27f: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_281:
	/* 0x281: movabs r8,0x1e00000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_64, 0, 128849018880ULL);
x86_l_28b:
	/* 0x28b: bt     r8,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_28f:
	/* 0x28f: jb     305 <generic_kprobe_filter_arg+0x305> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28f, 0x305, x86_l_305);
x86_l_291:
	/* 0x291: mov    ecx,0x60000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1610612736ULL);
x86_l_296:
	/* 0x296: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_29a:
	/* 0x29a: jb     36a <generic_kprobe_filter_arg+0x36a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x29a, 0x36a, x86_l_36a);
x86_l_2a0:
	/* 0x2a0: movabs rcx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_2aa:
	/* 0x2aa: bt     rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2ae:
	/* 0x2ae: jae    35b <generic_kprobe_filter_arg+0x35b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2ae, 0x35b, x86_l_35b);
x86_l_2b4:
	/* 0x2b4: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_583, 0x2b9ULL);
x86_l_2b9:
	/* 0x2b9: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x2b9, 0x387, x86_l_387);
x86_l_2be:
	/* 0x2be: lea    ecx,[rax-0xa] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551606ULL);
x86_l_2c1:
	/* 0x2c1: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2c4:
	/* 0x2c4: jb     382 <generic_kprobe_filter_arg+0x382> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c4, 0x382, x86_l_382);
x86_l_2ca:
	/* 0x2ca: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2cd:
	/* 0x2cd: je     363 <generic_kprobe_filter_arg+0x363> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cd, 0x363, x86_l_363);
x86_l_2d3:
	/* 0x2d3: cmp    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2d6:
	/* 0x2d6: je     363 <generic_kprobe_filter_arg+0x363> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d6, 0x363, x86_l_363);
x86_l_2dc:
	/* 0x2dc: jmp    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JMP(0x2dc, 0x390, x86_l_390);
x86_l_2e1:
	/* 0x2e1: cmp    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2e4:
	/* 0x2e4: je     2f4 <generic_kprobe_filter_arg+0x2f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e4, 0x2f4, x86_l_2f4);
x86_l_2e6:
	/* 0x2e6: cmp    eax,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_2e9:
	/* 0x2e9: je     2fe <generic_kprobe_filter_arg+0x2fe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e9, 0x2fe, x86_l_2fe);
x86_l_2eb:
	/* 0x2eb: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_2ee:
	/* 0x2ee: jne    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ee, 0x390, x86_l_390);
x86_l_2f4:
	/* 0x2f4: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_5ca, 0x2f9ULL);
x86_l_2f9:
	/* 0x2f9: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x2f9, 0x387, x86_l_387);
x86_l_2fe:
	/* 0x2fe: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_303:
	/* 0x303: jmp    376 <generic_kprobe_filter_arg+0x376> */
	X86_SIM_X86_JMP(0x303, 0x376, x86_l_376);
x86_l_305:
	/* 0x305: cmp    ecx,0x1e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 30ULL);
x86_l_308:
	/* 0x308: jne    382 <generic_kprobe_filter_arg+0x382> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x308, 0x382, x86_l_382);
x86_l_30a:
	/* 0x30a: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30d:
	/* 0x30d: and    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_310:
	/* 0x310: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_312:
	/* 0x312: cmp    DWORD PTR [r14+rcx*4+0x5ea0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 2), 104041287778304ULL);
x86_l_31b:
	/* 0x31b: jne    10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x31b, 0x10c, x86_l_10c);
x86_l_321:
	/* 0x321: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_324:
	/* 0x324: mov    rdx,QWORD PTR [r14+rax*8+0x5e78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 24184ULL);
x86_l_32c:
	/* 0x32c: and    edx,0x7ff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 2047ULL);
x86_l_332:
	/* 0x332: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_334:
	/* 0x334: andn   rcx,rcx,QWORD PTR [r14+rdx*1+0x90] */
	X86_SIM_RUN_OP(X86_OP_ANDN_MEM, X86_RCX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_R14)), 618475290624ULL);
x86_l_33e:
	/* 0x33e: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_341:
	/* 0x341: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x341, 0x387, x86_l_387);
x86_l_343:
	/* 0x343: cmp    eax,0x2a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 42ULL);
x86_l_346:
	/* 0x346: je     354 <generic_kprobe_filter_arg+0x354> */
	X86_SIM_X86_JCC(X86_CC_E, 0x346, 0x354, x86_l_354);
x86_l_348:
	/* 0x348: cmp    eax,0x2c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 44ULL);
x86_l_34b:
	/* 0x34b: jne    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x34b, 0x390, x86_l_390);
x86_l_34d:
	/* 0x34d: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_908, 0x352ULL);
x86_l_352:
	/* 0x352: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x352, 0x387, x86_l_387);
x86_l_354:
	/* 0x354: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_4c0, 0x359ULL);
x86_l_359:
	/* 0x359: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x359, 0x387, x86_l_387);
x86_l_35b:
	/* 0x35b: lea    ecx,[rax-0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551604ULL);
x86_l_35e:
	/* 0x35e: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_361:
	/* 0x361: jae    37d <generic_kprobe_filter_arg+0x37d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x361, 0x37d, x86_l_37d);
x86_l_363:
	/* 0x363: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_9b3, 0x368ULL);
x86_l_368:
	/* 0x368: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x368, 0x387, x86_l_387);
x86_l_36a:
	/* 0x36a: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_9fa, 0x36fULL);
x86_l_36f:
	/* 0x36f: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x36f, 0x387, x86_l_387);
x86_l_371:
	/* 0x371: mov    edx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_376:
	/* 0x376: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_a41, 0x37bULL);
x86_l_37b:
	/* 0x37b: jmp    387 <generic_kprobe_filter_arg+0x387> */
	X86_SIM_X86_JMP(0x37b, 0x387, x86_l_387);
x86_l_37d:
	/* 0x37d: cmp    eax,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_380:
	/* 0x380: jne    390 <generic_kprobe_filter_arg+0x390> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x380, 0x390, x86_l_390);
x86_l_382:
	/* 0x382: call   0 <generic_kprobe_filter_arg> */
	X86_SIM_X86_CALL(x86_l_ae4, 0x387ULL);
x86_l_387:
	/* 0x387: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_38a:
	/* 0x38a: je     10c <generic_kprobe_filter_arg+0x10c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x38a, 0x10c, x86_l_10c);
x86_l_390:
	/* 0x390: inc    r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_393:
	/* 0x393: cmp    r13,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 6ULL);
x86_l_397:
	/* 0x397: jne    173 <generic_kprobe_filter_arg+0x173> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x397, 0x173, x86_l_173);
x86_l_39d:
	/* 0x39d: jmp    f6 <generic_kprobe_filter_arg+0xf6> */
	X86_SIM_X86_JMP(0x39d, 0xf6, x86_l_f6);
x86_l_3a2:
	/* 0x3a2: mov    rax,QWORD PTR [rsp] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3a6:
	/* 0x3a6: mov    DWORD PTR [r14+0x5f04],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24324ULL);
x86_l_3ad:
	/* 0x3ad: mov    rsi,QWORD PTR [rip+0x7d39] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)kprobe_calls));
x86_l_3b4:
	/* 0x3b4: mov    eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3b9:
	/* 0x3b9: mov    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_3be:
	/* 0x3be: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3c1:
	/* 0x3c1: mov    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_3c6:
	/* 0x3c6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3c8:
	/* 0x3c8: mov    rsi,QWORD PTR [rip+0x7d39] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)kprobe_calls));
x86_l_3cf:
	/* 0x3cf: mov    eax,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3d4:
	/* 0x3d4: mov    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_3d9:
	/* 0x3d9: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3dc:
	/* 0x3dc: mov    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_3e1:
	/* 0x3e1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3e3:
	/* 0x3e3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3e5:
	/* 0x3e5: add    rsp,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_3e9:
	/* 0x3e9: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3ea:
	/* 0x3ea: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3ec:
	/* 0x3ec: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3ee:
	/* 0x3ee: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3f0:
	/* 0x3f0: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3f2:
	/* 0x3f2: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_3f3:
	/* 0x3f3: jmp    2779 <filter_file_type+0xc5> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_3f8:
	/* 0x3f8: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3fb:
	/* 0x3fb: cmp    BYTE PTR [r14+0x5ec1],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104183021699072ULL);
x86_l_403:
	/* 0x403: jne    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x403, 0x455, x86_l_455);
x86_l_405:
	/* 0x405: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_40b:
	/* 0x40b: cmp    BYTE PTR [r14+0x5ec2],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104187316666368ULL);
x86_l_413:
	/* 0x413: jne    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x413, 0x455, x86_l_455);
x86_l_415:
	/* 0x415: mov    r12d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_41b:
	/* 0x41b: cmp    BYTE PTR [r14+0x5ec3],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104191611633664ULL);
x86_l_423:
	/* 0x423: jne    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x423, 0x455, x86_l_455);
x86_l_425:
	/* 0x425: mov    r12d,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_42b:
	/* 0x42b: cmp    BYTE PTR [r14+0x5ec4],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104195906600960ULL);
x86_l_433:
	/* 0x433: jne    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x433, 0x455, x86_l_455);
x86_l_435:
	/* 0x435: mov    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_43b:
	/* 0x43b: cmp    BYTE PTR [r14+0x5ec5],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104200201568256ULL);
x86_l_443:
	/* 0x443: jne    455 <generic_kprobe_filter_arg+0x455> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x443, 0x455, x86_l_455);
x86_l_445:
	/* 0x445: mov    r12d,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_44b:
	/* 0x44b: cmp    BYTE PTR [r14+0x5ec6],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 104204496535552ULL);
x86_l_453:
	/* 0x453: je     477 <generic_kprobe_filter_arg+0x477> */
	X86_SIM_X86_JCC(X86_CC_E, 0x453, 0x477, x86_l_477);
x86_l_455:
	/* 0x455: mov    DWORD PTR [r14+0x5f00],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24320ULL);
x86_l_45c:
	/* 0x45c: mov    rsi,QWORD PTR [rip+0x7d35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)kprobe_calls));
x86_l_463:
	/* 0x463: mov    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_468:
	/* 0x468: mov    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_46d:
	/* 0x46d: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_470:
	/* 0x470: mov    edx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_475:
	/* 0x475: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_tail_call); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_477:
	/* 0x477: mov    rbx,QWORD PTR [r14+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_47b:
	/* 0x47b: mov    eax,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_480:
	/* 0x480: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_get_current_pid_tgid); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_482:
	/* 0x482: mov    QWORD PTR [rsp+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_487:
	/* 0x487: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_48c:
	/* 0x48c: mov    rdi,QWORD PTR [rip+0x7d35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_493:
	/* 0x493: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_498:
	/* 0x498: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_49d:
	/* 0x49d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_49f:
	/* 0x49f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a2:
	/* 0x4a2: je     3e3 <generic_kprobe_filter_arg+0x3e3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a2, 0x3e3, x86_l_3e3);
x86_l_4a8:
	/* 0x4a8: mov    rdi,QWORD PTR [rip+0x7d35] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)retprobe_map));
x86_l_4af:
	/* 0x4af: lea    rsi,[rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4b4:
	/* 0x4b4: mov    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_4b9:
	/* 0x4b9: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_delete_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x3ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_delete_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4bb:
	/* 0x4bb: jmp    3e3 <generic_kprobe_filter_arg+0x3e3> */
	X86_SIM_X86_JMP(0x4bb, 0x3e3, x86_l_3e3);
x86_l_2779:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_4c0 */
x86_l_4c0:
	/* 0x4c0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_4c1:
	/* 0x4c1: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_4c4:
	/* 0x4c4: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4c6:
	/* 0x4c6: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4c9:
	/* 0x4c9: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_4cb:
	/* 0x4cb: jne    4db <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x4cb, 0x4db, x86_l_4db);
x86_l_4cd:
	/* 0x4cd: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4cf:
	/* 0x4cf: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_4d2:
	/* 0x4d2: cmp    eax,0x24 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 36ULL);
x86_l_4d5:
	/* 0x4d5: je     4db <filter_file_buf+0x1b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x4d5, 0x4db, x86_l_4db);
x86_l_4d7:
	/* 0x4d7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_4d9:
	/* 0x4d9: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4da:
	/* 0x4da: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4da);
x86_l_4db:
	/* 0x4db: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_4de:
	/* 0x4de: ja     51a <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x4de, 0x51a, x86_l_51a);
x86_l_4e0:
	/* 0x4e0: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_4e2:
	/* 0x4e2: mov    edi,0x4000100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 67109120ULL);
x86_l_4e7:
	/* 0x4e7: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4eb:
	/* 0x4eb: jb     54e <filter_file_buf+0x8e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4eb, 0x54e, x86_l_54e);
x86_l_4ed:
	/* 0x4ed: mov    edi,0x8000200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 134218240ULL);
x86_l_4f2:
	/* 0x4f2: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4f6:
	/* 0x4f6: jb     538 <filter_file_buf+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x4f6, 0x538, x86_l_538);
x86_l_4f8:
	/* 0x4f8: movabs rdi,0x3000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, 206158430208ULL);
x86_l_502:
	/* 0x502: bt     rdi,rax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_506:
	/* 0x506: jae    51a <filter_file_buf+0x5a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x506, 0x51a, x86_l_51a);
x86_l_508:
	/* 0x508: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_50b:
	/* 0x50b: call   26b4 <filter_file_type> */
	X86_SIM_X86_CALL(x86_l_26b4, 0x510ULL);
x86_l_510:
	/* 0x510: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_513:
	/* 0x513: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_516:
	/* 0x516: jbe    56b <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x516, 0x56b, x86_l_56b);
x86_l_518:
	/* 0x518: jmp    581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x518, 0x581, x86_l_581);
x86_l_51a:
	/* 0x51a: lea    eax,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_51d:
	/* 0x51d: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_520:
	/* 0x520: jae    564 <filter_file_buf+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x520, 0x564, x86_l_564);
x86_l_522:
	/* 0x522: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_526:
	/* 0x526: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_529:
	/* 0x529: call   1221 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1221, 0x52eULL);
x86_l_52e:
	/* 0x52e: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_531:
	/* 0x531: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_534:
	/* 0x534: jbe    56b <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x534, 0x56b, x86_l_56b);
x86_l_536:
	/* 0x536: jmp    581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x536, 0x581, x86_l_581);
x86_l_538:
	/* 0x538: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_53c:
	/* 0x53c: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_53f:
	/* 0x53f: call   fb0 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_fb0, 0x544ULL);
x86_l_544:
	/* 0x544: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_547:
	/* 0x547: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_54a:
	/* 0x54a: jbe    56b <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x54a, 0x56b, x86_l_56b);
x86_l_54c:
	/* 0x54c: jmp    581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x54c, 0x581, x86_l_581);
x86_l_54e:
	/* 0x54e: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_552:
	/* 0x552: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_555:
	/* 0x555: call   10f8 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10f8, 0x55aULL);
x86_l_55a:
	/* 0x55a: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_55d:
	/* 0x55d: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_560:
	/* 0x560: jbe    56b <filter_file_buf+0xab> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x560, 0x56b, x86_l_56b);
x86_l_562:
	/* 0x562: jmp    581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JMP(0x562, 0x581, x86_l_581);
x86_l_564:
	/* 0x564: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_566:
	/* 0x566: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_569:
	/* 0x569: ja     581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x569, 0x581, x86_l_581);
x86_l_56b:
	/* 0x56b: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_56d:
	/* 0x56d: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_577:
	/* 0x577: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_57b:
	/* 0x57b: jae    581 <filter_file_buf+0xc1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x57b, 0x581, x86_l_581);
x86_l_57d:
	/* 0x57d: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_581:
	/* 0x581: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_582:
	/* 0x582: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_4da);

	/* native subroutine native_link_sub_583 */
x86_l_583:
	/* 0x583: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_584:
	/* 0x584: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_587:
	/* 0x587: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_589:
	/* 0x589: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_58d:
	/* 0x58d: ja     5c8 <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x58d, 0x5c8, x86_l_5c8);
x86_l_58f:
	/* 0x58f: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_594:
	/* 0x594: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_598:
	/* 0x598: jae    5a1 <filter_8ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x598, 0x5a1, x86_l_5a1);
x86_l_59a:
	/* 0x59a: call   225c <filter_8ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_225c, 0x59fULL);
x86_l_59f:
	/* 0x59f: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5a0:
	/* 0x5a0: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_5a0);
x86_l_5a1:
	/* 0x5a1: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_5a6:
	/* 0x5a6: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5aa:
	/* 0x5aa: jb     5c3 <filter_8ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x5aa, 0x5c3, x86_l_5c3);
x86_l_5ac:
	/* 0x5ac: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_5b6:
	/* 0x5b6: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_5ba:
	/* 0x5ba: jae    5c8 <filter_8ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x5ba, 0x5c8, x86_l_5c8);
x86_l_5bc:
	/* 0x5bc: call   2476 <filter_8ty_range> */
	X86_SIM_X86_CALL(x86_l_2476, 0x5c1ULL);
x86_l_5c1:
	/* 0x5c1: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5c2:
	/* 0x5c2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_5a0);
x86_l_5c3:
	/* 0x5c3: call   262e <filter_8ty_map> */
	X86_SIM_X86_CALL(x86_l_262e, 0x5c8ULL);
x86_l_5c8:
	/* 0x5c8: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_5c9:
	/* 0x5c9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_5a0);

	/* native subroutine native_link_sub_5ca */
x86_l_5ca:
	/* 0x5ca: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_5cc:
	/* 0x5cc: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5ce:
	/* 0x5ce: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_5d0:
	/* 0x5d0: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5d1:
	/* 0x5d1: sub    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 72ULL);
x86_l_5d5:
	/* 0x5d5: mov    QWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_5de:
	/* 0x5de: mov    QWORD PTR [rsp+0x38],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_5e7:
	/* 0x5e7: mov    QWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_5f0:
	/* 0x5f0: mov    QWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_5f9:
	/* 0x5f9: mov    QWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_602:
	/* 0x602: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_609:
	/* 0x609: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_611:
	/* 0x611: mov    edx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_614:
	/* 0x614: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_616:
	/* 0x616: cmp    edx,0x27 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 39ULL);
x86_l_619:
	/* 0x619: jg     631 <filter_inet+0x67> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x619, 0x631, x86_l_631);
x86_l_61b:
	/* 0x61b: cmp    edx,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_61e:
	/* 0x61e: je     6b6 <filter_inet+0xec> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x61e, 0x6b6, x86_l_6b6);
x86_l_624:
	/* 0x624: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_627:
	/* 0x627: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_62a:
	/* 0x62a: je     642 <filter_inet+0x78> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x62a, 0x642, x86_l_642);
x86_l_62c:
	/* 0x62c: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x62c, 0x8c4, x86_l_8c4);
x86_l_631:
	/* 0x631: cmp    edx,0x28 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 40ULL);
x86_l_634:
	/* 0x634: je     68e <filter_inet+0xc4> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x634, 0x68e, x86_l_68e);
x86_l_636:
	/* 0x636: mov    r8,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_639:
	/* 0x639: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_63c:
	/* 0x63c: jne    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x63c, 0x8c4, x86_l_8c4);
x86_l_642:
	/* 0x642: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_645:
	/* 0x645: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_647:
	/* 0x647: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_64a:
	/* 0x64a: jle    6c3 <filter_inet+0xf9> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x64a, 0x6c3, x86_l_6c3);
x86_l_64c:
	/* 0x64c: cmp    ecx,0x17 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 23ULL);
x86_l_64f:
	/* 0x64f: jg     66e <filter_inet+0xa4> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x64f, 0x66e, x86_l_66e);
x86_l_651:
	/* 0x651: lea    edx,[rcx-0x14] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551596ULL);
x86_l_654:
	/* 0x654: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_657:
	/* 0x657: jb     714 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x657, 0x714, x86_l_714);
x86_l_65d:
	/* 0x65d: lea    edx,[rcx-0x16] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551594ULL);
x86_l_660:
	/* 0x660: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_663:
	/* 0x663: jb     70e <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x663, 0x70e, x86_l_70e);
x86_l_669:
	/* 0x669: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x669, 0x8c4, x86_l_8c4);
x86_l_66e:
	/* 0x66e: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_671:
	/* 0x671: jg     751 <filter_inet+0x187> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x671, 0x751, x86_l_751);
x86_l_677:
	/* 0x677: cmp    ecx,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_67a:
	/* 0x67a: je     784 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x67a, 0x784, x86_l_784);
x86_l_680:
	/* 0x680: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_683:
	/* 0x683: je     77a <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x683, 0x77a, x86_l_77a);
x86_l_689:
	/* 0x689: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x689, 0x8c4, x86_l_8c4);
x86_l_68e:
	/* 0x68e: movzx  eax,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_691:
	/* 0x691: mov    WORD PTR [rsp+0x46],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_696:
	/* 0x696: movzx  eax,WORD PTR [rsi+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_69a:
	/* 0x69a: mov    WORD PTR [rsp+0x40],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_69f:
	/* 0x69f: mov    rax,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6a3:
	/* 0x6a3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6a8:
	/* 0x6a8: mov    rax,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6ac:
	/* 0x6ac: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6b1:
	/* 0x6b1: lea    rsi,[rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6b6:
	/* 0x6b6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6b9:
	/* 0x6b9: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_6bc:
	/* 0x6bc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_6be:
	/* 0x6be: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_6c1:
	/* 0x6c1: jg     64c <filter_inet+0x82> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6c1, 0x64c, x86_l_64c);
x86_l_6c3:
	/* 0x6c3: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_6c6:
	/* 0x6c6: jle    6e4 <filter_inet+0x11a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x6c6, 0x6e4, x86_l_6e4);
x86_l_6c8:
	/* 0x6c8: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6cb:
	/* 0x6cb: jg     700 <filter_inet+0x136> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x6cb, 0x700, x86_l_700);
x86_l_6cd:
	/* 0x6cd: cmp    ecx,0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_6d0:
	/* 0x6d0: je     70e <filter_inet+0x144> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6d0, 0x70e, x86_l_70e);
x86_l_6d2:
	/* 0x6d2: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_6d5:
	/* 0x6d5: jne    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x6d5, 0x8c4, x86_l_8c4);
x86_l_6db:
	/* 0x6db: movzx  eax,WORD PTR [rsi+0x24] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 36ULL);
x86_l_6df:
	/* 0x6df: jmp    8b9 <filter_inet+0x2ef> */
	X86_SIM_X86_SUB_JMP(0x6df, 0x8b9, x86_l_8b9);
x86_l_6e4:
	/* 0x6e4: cmp    ecx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_6e7:
	/* 0x6e7: je     784 <filter_inet+0x1ba> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6e7, 0x784, x86_l_784);
x86_l_6ed:
	/* 0x6ed: cmp    ecx,0xe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_6f0:
	/* 0x6f0: je     77a <filter_inet+0x1b0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6f0, 0x77a, x86_l_77a);
x86_l_6f6:
	/* 0x6f6: cmp    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_6f9:
	/* 0x6f9: je     714 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x6f9, 0x714, x86_l_714);
x86_l_6fb:
	/* 0x6fb: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x6fb, 0x8c4, x86_l_8c4);
x86_l_700:
	/* 0x700: cmp    ecx,0x12 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 18ULL);
x86_l_703:
	/* 0x703: je     714 <filter_inet+0x14a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x703, 0x714, x86_l_714);
x86_l_705:
	/* 0x705: cmp    ecx,0x13 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 19ULL);
x86_l_708:
	/* 0x708: jne    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x708, 0x8c4, x86_l_8c4);
x86_l_70e:
	/* 0x70e: movzx  edx,WORD PTR [rsi+0x22] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_712:
	/* 0x712: jmp    718 <filter_inet+0x14e> */
	X86_SIM_X86_SUB_JMP(0x712, 0x718, x86_l_718);
x86_l_714:
	/* 0x714: movzx  edx,WORD PTR [rsi+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_718:
	/* 0x718: mov    DWORD PTR [rsp+0x4],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_71c:
	/* 0x71c: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_71e:
	/* 0x71e: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_721:
	/* 0x721: xor    r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R14, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_724:
	/* 0x724: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_726:
	/* 0x726: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_729:
	/* 0x729: jg     79b <filter_inet+0x1d1> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x729, 0x79b, x86_l_79b);
x86_l_72b:
	/* 0x72b: lea    edx,[rcx-0xd] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551603ULL);
x86_l_72e:
	/* 0x72e: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_731:
	/* 0x731: jb     7c2 <filter_inet+0x1f8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x731, 0x7c2, x86_l_7c2);
x86_l_737:
	/* 0x737: lea    edx,[rcx-0xf] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551601ULL);
x86_l_73a:
	/* 0x73a: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_73d:
	/* 0x73d: jb     814 <filter_inet+0x24a> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x73d, 0x814, x86_l_814);
x86_l_743:
	/* 0x743: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_746:
	/* 0x746: je     8bc <filter_inet+0x2f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x746, 0x8bc, x86_l_8bc);
x86_l_74c:
	/* 0x74c: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x74c, 0x8c4, x86_l_8c4);
x86_l_751:
	/* 0x751: cmp    ecx,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_754:
	/* 0x754: je     8b5 <filter_inet+0x2eb> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x754, 0x8b5, x86_l_8b5);
x86_l_75a:
	/* 0x75a: cmp    ecx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_75d:
	/* 0x75d: jne    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x75d, 0x8c4, x86_l_8c4);
x86_l_763:
	/* 0x763: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_766:
	/* 0x766: jne    8e8 <filter_inet+0x31e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x766, 0x8e8, x86_l_8e8);
x86_l_76c:
	/* 0x76c: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_76f:
	/* 0x76f: jne    8f2 <filter_inet+0x328> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x76f, 0x8f2, x86_l_8f2);
x86_l_775:
	/* 0x775: jmp    8bc <filter_inet+0x2f2> */
	X86_SIM_X86_SUB_JMP(0x775, 0x8bc, x86_l_8bc);
x86_l_77a:
	/* 0x77a: mov    rbx,QWORD PTR [rsi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_77e:
	/* 0x77e: mov    r14,QWORD PTR [rsi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_782:
	/* 0x782: jmp    78b <filter_inet+0x1c1> */
	X86_SIM_X86_SUB_JMP(0x782, 0x78b, x86_l_78b);
x86_l_784:
	/* 0x784: mov    rbx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_787:
	/* 0x787: mov    r14,QWORD PTR [rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_78b:
	/* 0x78b: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_78e:
	/* 0x78e: shr    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_792:
	/* 0x792: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_794:
	/* 0x794: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_796:
	/* 0x796: cmp    ecx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_799:
	/* 0x799: jle    72b <filter_inet+0x161> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x799, 0x72b, x86_l_72b);
x86_l_79b:
	/* 0x79b: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_79e:
	/* 0x79e: ja     808 <filter_inet+0x23e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x79e, 0x808, x86_l_808);
x86_l_7a0:
	/* 0x7a0: mov    r8d,0x500000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 5242880ULL);
x86_l_7a6:
	/* 0x7a6: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7aa:
	/* 0x7aa: jb     81e <filter_inet+0x254> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x7aa, 0x81e, x86_l_81e);
x86_l_7ac:
	/* 0x7ac: mov    r8d,0xa00000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 10485760ULL);
x86_l_7b2:
	/* 0x7b2: bt     r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7b6:
	/* 0x7b6: jb     82e <filter_inet+0x264> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x7b6, 0x82e, x86_l_82e);
x86_l_7b8:
	/* 0x7b8: mov    edx,0x3000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 50331648ULL);
x86_l_7bd:
	/* 0x7bd: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7c0:
	/* 0x7c0: jae    808 <filter_inet+0x23e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x7c0, 0x808, x86_l_808);
x86_l_7c2:
	/* 0x7c2: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_7c6:
	/* 0x7c6: cmp    eax,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_7c9:
	/* 0x7c9: je     83e <filter_inet+0x274> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7c9, 0x83e, x86_l_83e);
x86_l_7cb:
	/* 0x7cb: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7ce:
	/* 0x7ce: jne    8ae <filter_inet+0x2e4> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x7ce, 0x8ae, x86_l_8ae);
x86_l_7d4:
	/* 0x7d4: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_7d7:
	/* 0x7d7: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_7da:
	/* 0x7da: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7de:
	/* 0x7de: mov    rdi,QWORD PTR [rip+0x1e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr4lpm_maps));
x86_l_7e5:
	/* 0x7e5: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7ea:
	/* 0x7ea: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_7ef:
	/* 0x7ef: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7f1:
	/* 0x7f1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f4:
	/* 0x7f4: je     8d0 <filter_inet+0x306> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x7f4, 0x8d0, x86_l_8d0);
x86_l_7fa:
	/* 0x7fa: mov    DWORD PTR [rsp+0xc],0x20 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607584ULL);
x86_l_802:
	/* 0x802: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_806:
	/* 0x806: jmp    87f <filter_inet+0x2b5> */
	X86_SIM_X86_SUB_JMP(0x806, 0x87f, x86_l_87f);
x86_l_808:
	/* 0x808: add    ecx,0xffffffee */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967278ULL);
x86_l_80b:
	/* 0x80b: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_80e:
	/* 0x80e: jae    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x80e, 0x8c4, x86_l_8c4);
x86_l_814:
	/* 0x814: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_819:
	/* 0x819: jmp    8bf <filter_inet+0x2f5> */
	X86_SIM_X86_SUB_JMP(0x819, 0x8bf, x86_l_8bf);
x86_l_81e:
	/* 0x81e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_820:
	/* 0x820: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_826:
	/* 0x826: setb   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_B, 0);
x86_l_829:
	/* 0x829: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x829, 0x8c4, x86_l_8c4);
x86_l_82e:
	/* 0x82e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_830:
	/* 0x830: cmp    edx,0x400 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_836:
	/* 0x836: setae  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_839:
	/* 0x839: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x839, 0x8c4, x86_l_8c4);
x86_l_83e:
	/* 0x83e: mov    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_841:
	/* 0x841: mov    eax,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_844:
	/* 0x844: mov    DWORD PTR [rsp+0x8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_848:
	/* 0x848: mov    rdi,QWORD PTR [rip+0x1e80] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)addr6lpm_maps));
x86_l_84f:
	/* 0x84f: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_854:
	/* 0x854: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_859:
	/* 0x859: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_85b:
	/* 0x85b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_85e:
	/* 0x85e: je     8d0 <filter_inet+0x306> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x85e, 0x8d0, x86_l_8d0);
x86_l_860:
	/* 0x860: mov    DWORD PTR [rsp+0xc],0x80 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 51539607680ULL);
x86_l_868:
	/* 0x868: mov    DWORD PTR [rsp+0x10],ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_86c:
	/* 0x86c: mov    DWORD PTR [rsp+0x14],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_871:
	/* 0x871: mov    DWORD PTR [rsp+0x18],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_876:
	/* 0x876: shr    r14,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_87a:
	/* 0x87a: mov    DWORD PTR [rsp+0x1c],r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_87f:
	/* 0x87f: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_884:
	/* 0x884: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_889:
	/* 0x889: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_88c:
	/* 0x88c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_88e:
	/* 0x88e: mov    ecx,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_893:
	/* 0x893: lea    edx,[rcx-0x18] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551592ULL);
x86_l_896:
	/* 0x896: cmp    edx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_899:
	/* 0x899: jb     8dd <filter_inet+0x313> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x899, 0x8dd, x86_l_8dd);
x86_l_89b:
	/* 0x89b: add    ecx,0xfffffff3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967283ULL);
x86_l_89e:
	/* 0x89e: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_8a1:
	/* 0x8a1: ja     8ae <filter_inet+0x2e4> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x8a1, 0x8ae, x86_l_8ae);
x86_l_8a3:
	/* 0x8a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8a6:
	/* 0x8a6: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_8a9:
	/* 0x8a9: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_8ac:
	/* 0x8ac: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x8ac, 0x8c4, x86_l_8c4);
x86_l_8ae:
	/* 0x8ae: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_8b0:
	/* 0x8b0: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_8b3:
	/* 0x8b3: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x8b3, 0x8c4, x86_l_8c4);
x86_l_8b5:
	/* 0x8b5: movzx  eax,WORD PTR [rsi+0x26] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 38ULL);
x86_l_8b9:
	/* 0x8b9: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8bc:
	/* 0x8bc: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_8bf:
	/* 0x8bf: call   21d7 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_21d7, 0x8c4ULL);
x86_l_8c4:
	/* 0x8c4: add    rsp,0x48 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 72ULL);
x86_l_8c8:
	/* 0x8c8: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8c9:
	/* 0x8c9: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8cb:
	/* 0x8cb: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8cd:
	/* 0x8cd: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_8cf:
	/* 0x8cf: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_8cf);
x86_l_8d0:
	/* 0x8d0: mov    eax,DWORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_8d5:
	/* 0x8d5: and    eax,0xfffffffe */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967294ULL);
x86_l_8d8:
	/* 0x8d8: cmp    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_8db:
	/* 0x8db: jmp    8e0 <filter_inet+0x316> */
	X86_SIM_X86_SUB_JMP(0x8db, 0x8e0, x86_l_8e0);
x86_l_8dd:
	/* 0x8dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8e0:
	/* 0x8e0: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_8e3:
	/* 0x8e3: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_8e6:
	/* 0x8e6: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x8e6, 0x8c4, x86_l_8c4);
x86_l_8e8:
	/* 0x8e8: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_8eb:
	/* 0x8eb: jne    8fa <filter_inet+0x330> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x8eb, 0x8fa, x86_l_8fa);
x86_l_8ed:
	/* 0x8ed: test   r8,r8 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R8, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_8f0:
	/* 0x8f0: je     8fa <filter_inet+0x330> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8f0, 0x8fa, x86_l_8fa);
x86_l_8f2:
	/* 0x8f2: movzx  eax,BYTE PTR [r8+0x3a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R8, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 58ULL);
x86_l_8f7:
	/* 0x8f7: mov    DWORD PTR [rsp],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8fa:
	/* 0x8fa: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_8fd:
	/* 0x8fd: je     8bc <filter_inet+0x2f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x8fd, 0x8bc, x86_l_8bc);
x86_l_8ff:
	/* 0x8ff: cmp    edx,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_902:
	/* 0x902: je     8bc <filter_inet+0x2f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x902, 0x8bc, x86_l_8bc);
x86_l_904:
	/* 0x904: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_906:
	/* 0x906: jmp    8c4 <filter_inet+0x2fa> */
	X86_SIM_X86_SUB_JMP(0x906, 0x8c4, x86_l_8c4);

	/* native subroutine native_link_sub_908 */
x86_l_908:
	/* 0x908: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_909:
	/* 0x909: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_90d:
	/* 0x90d: mov    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_910:
	/* 0x910: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_914:
	/* 0x914: movzx  edx,BYTE PTR [rcx+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_918:
	/* 0x918: mov    r8d,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_91c:
	/* 0x91c: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_91e:
	/* 0x91e: cmp    r8d,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_922:
	/* 0x922: jg     958 <filter_sockaddr_un+0x50> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x922, 0x958, x86_l_958);
x86_l_924:
	/* 0x924: lea    ecx,[r8-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_928:
	/* 0x928: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_92b:
	/* 0x92b: jae    966 <filter_sockaddr_un+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x92b, 0x966, x86_l_966);
x86_l_92d:
	/* 0x92d: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_930:
	/* 0x930: call   1221 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1221, 0x935ULL);
x86_l_935:
	/* 0x935: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_938:
	/* 0x938: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_93c:
	/* 0x93c: ja     952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x93c, 0x952, x86_l_952);
x86_l_93e:
	/* 0x93e: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_948:
	/* 0x948: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_94c:
	/* 0x94c: jae    952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x94c, 0x952, x86_l_952);
x86_l_94e:
	/* 0x94e: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_952:
	/* 0x952: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_956:
	/* 0x956: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_957:
	/* 0x957: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_957);
x86_l_958:
	/* 0x958: cmp    r8d,0x1c */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 28ULL);
x86_l_95c:
	/* 0x95c: je     99c <filter_sockaddr_un+0x94> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x95c, 0x99c, x86_l_99c);
x86_l_95e:
	/* 0x95e: cmp    r8d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_962:
	/* 0x962: je     96c <filter_sockaddr_un+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x962, 0x96c, x86_l_96c);
x86_l_964:
	/* 0x964: jmp    952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JMP(0x964, 0x952, x86_l_952);
x86_l_966:
	/* 0x966: cmp    r8d,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_96a:
	/* 0x96a: jne    952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x96a, 0x952, x86_l_952);
x86_l_96c:
	/* 0x96c: mov    eax,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_96f:
	/* 0x96f: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_972:
	/* 0x972: mov    edi,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_974:
	/* 0x974: call   10f8 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10f8, 0x979ULL);
x86_l_979:
	/* 0x979: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_97c:
	/* 0x97c: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_980:
	/* 0x980: ja     952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x980, 0x952, x86_l_952);
x86_l_982:
	/* 0x982: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_98c:
	/* 0x98c: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_990:
	/* 0x990: jae    952 <filter_sockaddr_un+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x990, 0x952, x86_l_952);
x86_l_992:
	/* 0x992: xor    rax,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_996:
	/* 0x996: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_99a:
	/* 0x99a: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_99b:
	/* 0x99b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_957);
x86_l_99c:
	/* 0x99c: movzx  eax,WORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_99f:
	/* 0x99f: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9a3:
	/* 0x9a3: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_9a8:
	/* 0x9a8: call   21d7 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_21d7, 0x9adULL);
x86_l_9ad:
	/* 0x9ad: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_9b1:
	/* 0x9b1: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9b2:
	/* 0x9b2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_957);

	/* native subroutine native_link_sub_9b3 */
x86_l_9b3:
	/* 0x9b3: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9b4:
	/* 0x9b4: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9b7:
	/* 0x9b7: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9b9:
	/* 0x9b9: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_9bd:
	/* 0x9bd: ja     9f8 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x9bd, 0x9f8, x86_l_9f8);
x86_l_9bf:
	/* 0x9bf: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_9c4:
	/* 0x9c4: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9c8:
	/* 0x9c8: jae    9d1 <filter_32ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9c8, 0x9d1, x86_l_9d1);
x86_l_9ca:
	/* 0x9ca: call   1e0d <filter_32ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_1e0d, 0x9cfULL);
x86_l_9cf:
	/* 0x9cf: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9d0:
	/* 0x9d0: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9d0);
x86_l_9d1:
	/* 0x9d1: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_9d6:
	/* 0x9d6: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9da:
	/* 0x9da: jb     9f3 <filter_32ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x9da, 0x9f3, x86_l_9f3);
x86_l_9dc:
	/* 0x9dc: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_9e6:
	/* 0x9e6: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_9ea:
	/* 0x9ea: jae    9f8 <filter_32ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x9ea, 0x9f8, x86_l_9f8);
x86_l_9ec:
	/* 0x9ec: call   2021 <filter_32ty_range> */
	X86_SIM_X86_CALL(x86_l_2021, 0x9f1ULL);
x86_l_9f1:
	/* 0x9f1: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9f2:
	/* 0x9f2: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9d0);
x86_l_9f3:
	/* 0x9f3: call   21d7 <filter_32ty_map> */
	X86_SIM_X86_CALL(x86_l_21d7, 0x9f8ULL);
x86_l_9f8:
	/* 0x9f8: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_9f9:
	/* 0x9f9: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_9d0);

	/* native subroutine native_link_sub_9fa */
x86_l_9fa:
	/* 0x9fa: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9fb:
	/* 0x9fb: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_9fe:
	/* 0x9fe: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a00:
	/* 0xa00: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_a04:
	/* 0xa04: ja     a3f <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xa04, 0xa3f, x86_l_a3f);
x86_l_a06:
	/* 0xa06: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_a0b:
	/* 0xa0b: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a0f:
	/* 0xa0f: jae    a18 <filter_16ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa0f, 0xa18, x86_l_a18);
x86_l_a11:
	/* 0xa11: call   19b5 <filter_16ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_19b5, 0xa16ULL);
x86_l_a16:
	/* 0xa16: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a17:
	/* 0xa17: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a17);
x86_l_a18:
	/* 0xa18: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_a1d:
	/* 0xa1d: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a21:
	/* 0xa21: jb     a3a <filter_16ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa21, 0xa3a, x86_l_a3a);
x86_l_a23:
	/* 0xa23: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_a2d:
	/* 0xa2d: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a31:
	/* 0xa31: jae    a3f <filter_16ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xa31, 0xa3f, x86_l_a3f);
x86_l_a33:
	/* 0xa33: call   1bcf <filter_16ty_range> */
	X86_SIM_X86_CALL(x86_l_1bcf, 0xa38ULL);
x86_l_a38:
	/* 0xa38: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a39:
	/* 0xa39: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a17);
x86_l_a3a:
	/* 0xa3a: call   1d87 <filter_16ty_map> */
	X86_SIM_X86_CALL(x86_l_1d87, 0xa3fULL);
x86_l_a3f:
	/* 0xa3f: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_a40:
	/* 0xa40: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_a17);

	/* native subroutine native_link_sub_a41 */
x86_l_a41:
	/* 0xa41: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a42:
	/* 0xa42: mov    rax,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_a45:
	/* 0xa45: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_a48:
	/* 0xa48: movsxd rcx,edx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_a4b:
	/* 0xa4b: mov    edx,DWORD PTR [rsi+rcx*1-0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 18446744073709551612ULL);
x86_l_a4f:
	/* 0xa4f: mov    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_a51:
	/* 0xa51: add    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a54:
	/* 0xa54: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_a57:
	/* 0xa57: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a59:
	/* 0xa59: cmp    ecx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_a5c:
	/* 0xa5c: jg     a72 <filter_char_buf+0x31> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xa5c, 0xa72, x86_l_a72);
x86_l_a5e:
	/* 0xa5e: lea    edi,[rcx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_a61:
	/* 0xa61: cmp    edi,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_a64:
	/* 0xa64: jb     aa9 <filter_char_buf+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xa64, 0xaa9, x86_l_aa9);
x86_l_a66:
	/* 0xa66: cmp    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_a69:
	/* 0xa69: je     a9f <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa69, 0xa9f, x86_l_a9f);
x86_l_a6b:
	/* 0xa6b: cmp    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_a6e:
	/* 0xa6e: je     a81 <filter_char_buf+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa6e, 0xa81, x86_l_a81);
x86_l_a70:
	/* 0xa70: jmp    ac0 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JMP(0xa70, 0xac0, x86_l_ac0);
x86_l_a72:
	/* 0xa72: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_a75:
	/* 0xa75: jg     a8b <filter_char_buf+0x4a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xa75, 0xa8b, x86_l_a8b);
x86_l_a77:
	/* 0xa77: cmp    ecx,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_a7a:
	/* 0xa7a: je     a9f <filter_char_buf+0x5e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa7a, 0xa9f, x86_l_a9f);
x86_l_a7c:
	/* 0xa7c: cmp    ecx,0x1b */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 27ULL);
x86_l_a7f:
	/* 0xa7f: jne    ac0 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xa7f, 0xac0, x86_l_ac0);
x86_l_a81:
	/* 0xa81: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_a84:
	/* 0xa84: call   fb0 <filter_char_buf_postfix> */
	X86_SIM_X86_CALL(x86_l_fb0, 0xa89ULL);
x86_l_a89:
	/* 0xa89: jmp    abd <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xa89, 0xabd, x86_l_abd);
x86_l_a8b:
	/* 0xa8b: cmp    ecx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_a8e:
	/* 0xa8e: je     ab3 <filter_char_buf+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xa8e, 0xab3, x86_l_ab3);
x86_l_a90:
	/* 0xa90: cmp    ecx,0x22 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 34ULL);
x86_l_a93:
	/* 0xa93: jne    ac0 <filter_char_buf+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xa93, 0xac0, x86_l_ac0);
x86_l_a95:
	/* 0xa95: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a98:
	/* 0xa98: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_a9d:
	/* 0xa9d: jmp    ab8 <filter_char_buf+0x77> */
	X86_SIM_X86_SUB_JMP(0xa9d, 0xab8, x86_l_ab8);
x86_l_a9f:
	/* 0xa9f: mov    edi,DWORD PTR [rbx+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_aa2:
	/* 0xaa2: call   10f8 <filter_char_buf_prefix> */
	X86_SIM_X86_CALL(x86_l_10f8, 0xaa7ULL);
x86_l_aa7:
	/* 0xaa7: jmp    abd <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xaa7, 0xabd, x86_l_abd);
x86_l_aa9:
	/* 0xaa9: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_aac:
	/* 0xaac: call   1221 <filter_char_buf_equal> */
	X86_SIM_X86_CALL(x86_l_1221, 0xab1ULL);
x86_l_ab1:
	/* 0xab1: jmp    abd <filter_char_buf+0x7c> */
	X86_SIM_X86_SUB_JMP(0xab1, 0xabd, x86_l_abd);
x86_l_ab3:
	/* 0xab3: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_ab6:
	/* 0xab6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ab8:
	/* 0xab8: call   179f <filter_char_substring> */
	X86_SIM_X86_CALL(x86_l_179f, 0xabdULL);
x86_l_abd:
	/* 0xabd: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ac0:
	/* 0xac0: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_ac3:
	/* 0xac3: ja     ae2 <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xac3, 0xae2, x86_l_ae2);
x86_l_ac5:
	/* 0xac5: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_ac7:
	/* 0xac7: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_ad1:
	/* 0xad1: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ad5:
	/* 0xad5: jae    ae2 <filter_char_buf+0xa1> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xad5, 0xae2, x86_l_ae2);
x86_l_ad7:
	/* 0xad7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ad9:
	/* 0xad9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_adc:
	/* 0xadc: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_adf:
	/* 0xadf: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ae2:
	/* 0xae2: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_ae3:
	/* 0xae3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_ae3);

	/* native subroutine native_link_sub_ae4 */
x86_l_ae4:
	/* 0xae4: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ae5:
	/* 0xae5: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ae8:
	/* 0xae8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_aea:
	/* 0xaea: cmp    rcx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 32ULL);
x86_l_aee:
	/* 0xaee: ja     b29 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xaee, 0xb29, x86_l_b29);
x86_l_af0:
	/* 0xaf0: mov    edx,0x101e */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4126ULL);
x86_l_af5:
	/* 0xaf5: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_af9:
	/* 0xaf9: jae    b02 <filter_64ty+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xaf9, 0xb02, x86_l_b02);
x86_l_afb:
	/* 0xafb: call   b2b <filter_64ty_selector_val> */
	X86_SIM_X86_CALL(x86_l_b2b, 0xb00ULL);
x86_l_b00:
	/* 0xb00: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b01:
	/* 0xb01: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b01);
x86_l_b02:
	/* 0xb02: mov    edx,0xc00 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 3072ULL);
x86_l_b07:
	/* 0xb07: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b0b:
	/* 0xb0b: jb     b24 <filter_64ty+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb0b, 0xb24, x86_l_b24);
x86_l_b0d:
	/* 0xb0d: movabs rdx,0x180000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 6442450944ULL);
x86_l_b17:
	/* 0xb17: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b1b:
	/* 0xb1b: jae    b29 <filter_64ty+0x45> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb1b, 0xb29, x86_l_b29);
x86_l_b1d:
	/* 0xb1d: call   d5d <filter_64ty_range> */
	X86_SIM_X86_CALL(x86_l_d5d, 0xb22ULL);
x86_l_b22:
	/* 0xb22: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b23:
	/* 0xb23: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b01);
x86_l_b24:
	/* 0xb24: call   f38 <filter_64ty_map> */
	X86_SIM_X86_CALL(x86_l_f38, 0xb29ULL);
x86_l_b29:
	/* 0xb29: pop    rcx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_b2a:
	/* 0xb2a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b01);

	/* native subroutine native_link_sub_b2b */
x86_l_b2b:
	/* 0xb2b: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_b2e:
	/* 0xb2e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_b33:
	/* 0xb33: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_b37:
	/* 0xb37: ja     baf <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xb37, 0xbaf, x86_l_baf);
x86_l_b39:
	/* 0xb39: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_b43:
	/* 0xb43: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b47:
	/* 0xb47: jae    b4a <filter_64ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb47, 0xb4a, x86_l_b4a);
x86_l_b49:
	/* 0xb49: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b49);
x86_l_b4a:
	/* 0xb4a: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_b4f:
	/* 0xb4f: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_b53:
	/* 0xb53: jae    b6b <filter_64ty_selector_val+0x40> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xb53, 0xb6b, x86_l_b6b);
x86_l_b55:
	/* 0xb55: mov    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b58:
	/* 0xb58: cmp    rdx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_b5c:
	/* 0xb5c: jne    c8d <filter_64ty_selector_val+0x162> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb5c, 0xc8d, x86_l_c8d);
x86_l_b62:
	/* 0xb62: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b64:
	/* 0xb64: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_b67:
	/* 0xb67: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_b6a:
	/* 0xb6a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b49);
x86_l_b6b:
	/* 0xb6b: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_b6f:
	/* 0xb6f: jne    baf <filter_64ty_selector_val+0x84> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb6f, 0xbaf, x86_l_baf);
x86_l_b71:
	/* 0xb71: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b74:
	/* 0xb74: test   QWORD PTR [rdi+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_b78:
	/* 0xb78: jne    b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb78, 0xb49, x86_l_b49);
x86_l_b7a:
	/* 0xb7a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b7d:
	/* 0xb7d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_b80:
	/* 0xb80: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb80, 0xd5a, x86_l_d5a);
x86_l_b86:
	/* 0xb86: test   QWORD PTR [rdi+0x18],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_b8a:
	/* 0xb8a: jne    b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb8a, 0xb49, x86_l_b49);
x86_l_b8c:
	/* 0xb8c: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_b8f:
	/* 0xb8f: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb8f, 0xd5a, x86_l_d5a);
x86_l_b95:
	/* 0xb95: test   QWORD PTR [rdi+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_b99:
	/* 0xb99: jne    b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xb99, 0xb49, x86_l_b49);
x86_l_b9b:
	/* 0xb9b: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_b9e:
	/* 0xb9e: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xb9e, 0xd5a, x86_l_d5a);
x86_l_ba4:
	/* 0xba4: test   QWORD PTR [rdi+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_ba8:
	/* 0xba8: jne    b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xba8, 0xb49, x86_l_b49);
x86_l_baa:
	/* 0xbaa: jmp    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xbaa, 0xd5a, x86_l_d5a);
x86_l_baf:
	/* 0xbaf: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_bb2:
	/* 0xbb2: je     c25 <filter_64ty_selector_val+0xfa> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xbb2, 0xc25, x86_l_c25);
x86_l_bb4:
	/* 0xbb4: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_bb7:
	/* 0xbb7: jne    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xbb7, 0xd5a, x86_l_d5a);
x86_l_bbd:
	/* 0xbbd: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_bc0:
	/* 0xbc0: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_bc3:
	/* 0xbc3: ja     d1d <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xbc3, 0xd1d, x86_l_d1d);
x86_l_bc9:
	/* 0xbc9: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_bce:
	/* 0xbce: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_bd1:
	/* 0xbd1: jae    d1d <filter_64ty_selector_val+0x1f2> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xbd1, 0xd1d, x86_l_d1d);
x86_l_bd7:
	/* 0xbd7: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bda:
	/* 0xbda: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_bde:
	/* 0xbde: jl     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbde, 0xb49, x86_l_b49);
x86_l_be4:
	/* 0xbe4: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_be7:
	/* 0xbe7: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_bea:
	/* 0xbea: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbea, 0xd5a, x86_l_d5a);
x86_l_bf0:
	/* 0xbf0: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_bf4:
	/* 0xbf4: jl     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xbf4, 0xb49, x86_l_b49);
x86_l_bfa:
	/* 0xbfa: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_bfd:
	/* 0xbfd: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xbfd, 0xd5a, x86_l_d5a);
x86_l_c03:
	/* 0xc03: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c07:
	/* 0xc07: jl     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc07, 0xb49, x86_l_b49);
x86_l_c0d:
	/* 0xc0d: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c10:
	/* 0xc10: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc10, 0xd5a, x86_l_d5a);
x86_l_c16:
	/* 0xc16: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c1a:
	/* 0xc1a: jl     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0xc1a, 0xb49, x86_l_b49);
x86_l_c20:
	/* 0xc20: jmp    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc20, 0xd5a, x86_l_d5a);
x86_l_c25:
	/* 0xc25: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_c28:
	/* 0xc28: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_c2b:
	/* 0xc2b: ja     cde <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xc2b, 0xcde, x86_l_cde);
x86_l_c31:
	/* 0xc31: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_c36:
	/* 0xc36: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c39:
	/* 0xc39: jae    cde <filter_64ty_selector_val+0x1b3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xc39, 0xcde, x86_l_cde);
x86_l_c3f:
	/* 0xc3f: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c42:
	/* 0xc42: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_c46:
	/* 0xc46: jg     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc46, 0xb49, x86_l_b49);
x86_l_c4c:
	/* 0xc4c: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c4f:
	/* 0xc4f: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c52:
	/* 0xc52: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc52, 0xd5a, x86_l_d5a);
x86_l_c58:
	/* 0xc58: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c5c:
	/* 0xc5c: jg     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc5c, 0xb49, x86_l_b49);
x86_l_c62:
	/* 0xc62: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_c65:
	/* 0xc65: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc65, 0xd5a, x86_l_d5a);
x86_l_c6b:
	/* 0xc6b: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_c6f:
	/* 0xc6f: jg     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc6f, 0xb49, x86_l_b49);
x86_l_c75:
	/* 0xc75: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_c78:
	/* 0xc78: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc78, 0xd5a, x86_l_d5a);
x86_l_c7e:
	/* 0xc7e: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_c82:
	/* 0xc82: jg     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xc82, 0xb49, x86_l_b49);
x86_l_c88:
	/* 0xc88: jmp    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xc88, 0xd5a, x86_l_d5a);
x86_l_c8d:
	/* 0xc8d: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c90:
	/* 0xc90: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_c93:
	/* 0xc93: jb     cbd <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xc93, 0xcbd, x86_l_cbd);
x86_l_c95:
	/* 0xc95: cmp    rdx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_c99:
	/* 0xc99: je     b62 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xc99, 0xb62, x86_l_b62);
x86_l_c9f:
	/* 0xc9f: cmp    esi,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_ca2:
	/* 0xca2: jb     cbd <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xca2, 0xcbd, x86_l_cbd);
x86_l_ca4:
	/* 0xca4: cmp    rdx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_ca8:
	/* 0xca8: je     b62 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xca8, 0xb62, x86_l_b62);
x86_l_cae:
	/* 0xcae: cmp    esi,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_cb1:
	/* 0xcb1: jb     cbd <filter_64ty_selector_val+0x192> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcb1, 0xcbd, x86_l_cbd);
x86_l_cb3:
	/* 0xcb3: cmp    rdx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_cb7:
	/* 0xcb7: je     b62 <filter_64ty_selector_val+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xcb7, 0xb62, x86_l_b62);
x86_l_cbd:
	/* 0xcbd: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_cc0:
	/* 0xcc0: ja     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcc0, 0xd5a, x86_l_d5a);
x86_l_cc6:
	/* 0xcc6: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_cc8:
	/* 0xcc8: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_cd2:
	/* 0xcd2: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_cd6:
	/* 0xcd6: jb     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcd6, 0xb49, x86_l_b49);
x86_l_cdc:
	/* 0xcdc: jmp    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xcdc, 0xd5a, x86_l_d5a);
x86_l_cde:
	/* 0xcde: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ce1:
	/* 0xce1: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_ce5:
	/* 0xce5: ja     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xce5, 0xb49, x86_l_b49);
x86_l_ceb:
	/* 0xceb: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cee:
	/* 0xcee: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_cf1:
	/* 0xcf1: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xcf1, 0xd5a, x86_l_d5a);
x86_l_cf3:
	/* 0xcf3: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_cf7:
	/* 0xcf7: ja     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xcf7, 0xb49, x86_l_b49);
x86_l_cfd:
	/* 0xcfd: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d00:
	/* 0xd00: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd00, 0xd5a, x86_l_d5a);
x86_l_d02:
	/* 0xd02: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d06:
	/* 0xd06: ja     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd06, 0xb49, x86_l_b49);
x86_l_d0c:
	/* 0xd0c: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_d0f:
	/* 0xd0f: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd0f, 0xd5a, x86_l_d5a);
x86_l_d11:
	/* 0xd11: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d15:
	/* 0xd15: ja     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd15, 0xb49, x86_l_b49);
x86_l_d1b:
	/* 0xd1b: jmp    d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JMP(0xd1b, 0xd5a, x86_l_d5a);
x86_l_d1d:
	/* 0xd1d: mov    rcx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d20:
	/* 0xd20: cmp    rcx,QWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 16ULL);
x86_l_d24:
	/* 0xd24: jb     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd24, 0xb49, x86_l_b49);
x86_l_d2a:
	/* 0xd2a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d2d:
	/* 0xd2d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_d30:
	/* 0xd30: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd30, 0xd5a, x86_l_d5a);
x86_l_d32:
	/* 0xd32: cmp    rcx,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d36:
	/* 0xd36: jb     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd36, 0xb49, x86_l_b49);
x86_l_d3c:
	/* 0xd3c: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d3f:
	/* 0xd3f: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd3f, 0xd5a, x86_l_d5a);
x86_l_d41:
	/* 0xd41: cmp    rcx,QWORD PTR [rdi+0x20] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 32ULL);
x86_l_d45:
	/* 0xd45: jb     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd45, 0xb49, x86_l_b49);
x86_l_d4b:
	/* 0xd4b: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_d4e:
	/* 0xd4e: jb     d5a <filter_64ty_selector_val+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd4e, 0xd5a, x86_l_d5a);
x86_l_d50:
	/* 0xd50: cmp    rcx,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_d54:
	/* 0xd54: jb     b49 <filter_64ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd54, 0xb49, x86_l_b49);
x86_l_d5a:
	/* 0xd5a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d5c:
	/* 0xd5c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_b49);

	/* native subroutine native_link_sub_d5d */
x86_l_d5d:
	/* 0xd5d: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_d60:
	/* 0xd60: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_d63:
	/* 0xd63: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_d66:
	/* 0xd66: ja     e60 <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xd66, 0xe60, x86_l_e60);
x86_l_d6c:
	/* 0xd6c: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_d71:
	/* 0xd71: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_d74:
	/* 0xd74: jae    e60 <filter_64ty_range+0x103> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0xd74, 0xe60, x86_l_e60);
x86_l_d7a:
	/* 0xd7a: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_d7d:
	/* 0xd7d: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_d80:
	/* 0xd80: jne    df0 <filter_64ty_range+0x93> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xd80, 0xdf0, x86_l_df0);
x86_l_d82:
	/* 0xd82: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_d87:
	/* 0xd87: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d8b:
	/* 0xd8b: jg     d97 <filter_64ty_range+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xd8b, 0xd97, x86_l_d97);
x86_l_d8d:
	/* 0xd8d: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_d91:
	/* 0xd91: jle    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xd91, 0xe79, x86_l_e79);
x86_l_d97:
	/* 0xd97: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_d9a:
	/* 0xd9a: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_d9d:
	/* 0xd9d: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xd9d, 0xf27, x86_l_f27);
x86_l_da3:
	/* 0xda3: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_da7:
	/* 0xda7: jg     db3 <filter_64ty_range+0x56> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xda7, 0xdb3, x86_l_db3);
x86_l_da9:
	/* 0xda9: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_dad:
	/* 0xdad: jle    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xdad, 0xe79, x86_l_e79);
x86_l_db3:
	/* 0xdb3: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_db6:
	/* 0xdb6: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdb6, 0xf27, x86_l_f27);
x86_l_dbc:
	/* 0xdbc: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_dc0:
	/* 0xdc0: jg     dcc <filter_64ty_range+0x6f> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xdc0, 0xdcc, x86_l_dcc);
x86_l_dc2:
	/* 0xdc2: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_dc6:
	/* 0xdc6: jle    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xdc6, 0xe79, x86_l_e79);
x86_l_dcc:
	/* 0xdcc: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_dcf:
	/* 0xdcf: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xdcf, 0xf27, x86_l_f27);
x86_l_dd5:
	/* 0xdd5: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_dd7:
	/* 0xdd7: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ddb:
	/* 0xddb: jg     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0xddb, 0xf29, x86_l_f29);
x86_l_de1:
	/* 0xde1: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_de5:
	/* 0xde5: jle    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0xde5, 0xe79, x86_l_e79);
x86_l_deb:
	/* 0xdeb: jmp    f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xdeb, 0xf29, x86_l_f29);
x86_l_df0:
	/* 0xdf0: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_df3:
	/* 0xdf3: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_df7:
	/* 0xdf7: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_dfb:
	/* 0xdfb: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_dff:
	/* 0xdff: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e02:
	/* 0xe02: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e05:
	/* 0xe05: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_e08:
	/* 0xe08: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe08, 0xf29, x86_l_f29);
x86_l_e0e:
	/* 0xe0e: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e12:
	/* 0xe12: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e16:
	/* 0xe16: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_e1a:
	/* 0xe1a: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e1e:
	/* 0xe1e: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e21:
	/* 0xe21: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e24:
	/* 0xe24: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_e27:
	/* 0xe27: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe27, 0xf29, x86_l_f29);
x86_l_e2d:
	/* 0xe2d: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e31:
	/* 0xe31: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e35:
	/* 0xe35: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_e39:
	/* 0xe39: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e3d:
	/* 0xe3d: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e40:
	/* 0xe40: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_e43:
	/* 0xe43: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_e46:
	/* 0xe46: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe46, 0xf29, x86_l_f29);
x86_l_e4c:
	/* 0xe4c: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e50:
	/* 0xe50: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e53:
	/* 0xe53: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_e57:
	/* 0xe57: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_e5b:
	/* 0xe5b: jmp    edd <filter_64ty_range+0x180> */
	X86_SIM_X86_SUB_JMP(0xe5b, 0xedd, x86_l_edd);
x86_l_e60:
	/* 0xe60: mov    rsi,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e63:
	/* 0xe63: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_e66:
	/* 0xe66: jne    e7a <filter_64ty_range+0x11d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xe66, 0xe7a, x86_l_e7a);
x86_l_e68:
	/* 0xe68: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_e6d:
	/* 0xe6d: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e71:
	/* 0xe71: ja     ee5 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe71, 0xee5, x86_l_ee5);
x86_l_e73:
	/* 0xe73: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e77:
	/* 0xe77: ja     ee5 <filter_64ty_range+0x188> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xe77, 0xee5, x86_l_ee5);
x86_l_e79:
	/* 0xe79: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_e79);
x86_l_e7a:
	/* 0xe7a: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e7d:
	/* 0xe7d: cmp    QWORD PTR [rdi+0x10],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e81:
	/* 0xe81: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e85:
	/* 0xe85: cmp    rsi,QWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_e89:
	/* 0xe89: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_e8c:
	/* 0xe8c: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_e8f:
	/* 0xe8f: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_e92:
	/* 0xe92: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xe92, 0xf29, x86_l_f29);
x86_l_e98:
	/* 0xe98: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e9c:
	/* 0xe9c: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_ea0:
	/* 0xea0: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_ea4:
	/* 0xea4: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_ea8:
	/* 0xea8: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_eab:
	/* 0xeab: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_eae:
	/* 0xeae: cmp    eax,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_eb1:
	/* 0xeb1: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xeb1, 0xf29, x86_l_f29);
x86_l_eb3:
	/* 0xeb3: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_eb7:
	/* 0xeb7: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_ebb:
	/* 0xebb: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_ebf:
	/* 0xebf: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_ec3:
	/* 0xec3: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_ec6:
	/* 0xec6: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_ec9:
	/* 0xec9: cmp    eax,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_ecc:
	/* 0xecc: jb     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xecc, 0xf29, x86_l_f29);
x86_l_ece:
	/* 0xece: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_ed2:
	/* 0xed2: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_ed5:
	/* 0xed5: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_ed9:
	/* 0xed9: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_edd:
	/* 0xedd: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_ee0:
	/* 0xee0: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_ee3:
	/* 0xee3: jmp    f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xee3, 0xf29, x86_l_f29);
x86_l_ee5:
	/* 0xee5: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee8:
	/* 0xee8: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_eeb:
	/* 0xeeb: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xeeb, 0xf27, x86_l_f27);
x86_l_eed:
	/* 0xeed: cmp    QWORD PTR [rdi+0x20],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_ef1:
	/* 0xef1: ja     ef9 <filter_64ty_range+0x19c> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xef1, 0xef9, x86_l_ef9);
x86_l_ef3:
	/* 0xef3: cmp    rsi,QWORD PTR [rdi+0x28] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 40ULL);
x86_l_ef7:
	/* 0xef7: jbe    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xef7, 0xe79, x86_l_e79);
x86_l_ef9:
	/* 0xef9: cmp    edx,0x29 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 41ULL);
x86_l_efc:
	/* 0xefc: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xefc, 0xf27, x86_l_f27);
x86_l_efe:
	/* 0xefe: cmp    QWORD PTR [rdi+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f02:
	/* 0xf02: ja     f0e <filter_64ty_range+0x1b1> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf02, 0xf0e, x86_l_f0e);
x86_l_f04:
	/* 0xf04: cmp    rsi,QWORD PTR [rdi+0x38] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 56ULL);
x86_l_f08:
	/* 0xf08: jbe    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xf08, 0xe79, x86_l_e79);
x86_l_f0e:
	/* 0xf0e: cmp    edx,0x39 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 57ULL);
x86_l_f11:
	/* 0xf11: jb     f27 <filter_64ty_range+0x1ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0xf11, 0xf27, x86_l_f27);
x86_l_f13:
	/* 0xf13: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f15:
	/* 0xf15: cmp    QWORD PTR [rdi+0x40],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f19:
	/* 0xf19: ja     f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0xf19, 0xf29, x86_l_f29);
x86_l_f1b:
	/* 0xf1b: cmp    rsi,QWORD PTR [rdi+0x48] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_f1f:
	/* 0xf1f: jbe    e79 <filter_64ty_range+0x11c> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0xf1f, 0xe79, x86_l_e79);
x86_l_f25:
	/* 0xf25: jmp    f29 <filter_64ty_range+0x1cc> */
	X86_SIM_X86_SUB_JMP(0xf25, 0xf29, x86_l_f29);
x86_l_f27:
	/* 0xf27: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f29:
	/* 0xf29: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_f2c:
	/* 0xf2c: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_f2f:
	/* 0xf2f: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_f32:
	/* 0xf32: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_f34:
	/* 0xf34: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_f37:
	/* 0xf37: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_e79);

	/* native subroutine native_link_sub_f38 */
x86_l_f38:
	/* 0xf38: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_f3a:
	/* 0xf3a: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_f3b:
	/* 0xf3b: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_f3f:
	/* 0xf3f: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_f42:
	/* 0xf42: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_f45:
	/* 0xf45: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_f49:
	/* 0xf49: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f4d:
	/* 0xf4d: mov    rdi,QWORD PTR [rip+0xd50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_f54:
	/* 0xf54: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_f59:
	/* 0xf59: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f5e:
	/* 0xf5e: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f60:
	/* 0xf60: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f63:
	/* 0xf63: je     f91 <filter_64ty_map+0x59> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf63, 0xf91, x86_l_f91);
x86_l_f65:
	/* 0xf65: mov    rcx,QWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f68:
	/* 0xf68: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f6d:
	/* 0xf6d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f72:
	/* 0xf72: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f77:
	/* 0xf77: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f7a:
	/* 0xf7a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f7c:
	/* 0xf7c: mov    ecx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f7f:
	/* 0xf7f: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_f82:
	/* 0xf82: je     f9b <filter_64ty_map+0x63> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xf82, 0xf9b, x86_l_f9b);
x86_l_f84:
	/* 0xf84: cmp    ecx,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_f87:
	/* 0xf87: jne    fa3 <filter_64ty_map+0x6b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0xf87, 0xfa3, x86_l_fa3);
x86_l_f89:
	/* 0xf89: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f8c:
	/* 0xf8c: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_f8f:
	/* 0xf8f: jmp    fa5 <filter_64ty_map+0x6d> */
	X86_SIM_X86_SUB_JMP(0xf8f, 0xfa5, x86_l_fa5);
x86_l_f91:
	/* 0xf91: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_f93:
	/* 0xf93: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_f97:
	/* 0xf97: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f98:
	/* 0xf98: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_f9a:
	/* 0xf9a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f9a);
x86_l_f9b:
	/* 0xf9b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f9e:
	/* 0xf9e: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_fa1:
	/* 0xfa1: jmp    fa5 <filter_64ty_map+0x6d> */
	X86_SIM_X86_SUB_JMP(0xfa1, 0xfa5, x86_l_fa5);
x86_l_fa3:
	/* 0xfa3: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fa5:
	/* 0xfa5: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_fa8:
	/* 0xfa8: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_fac:
	/* 0xfac: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_fad:
	/* 0xfad: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_faf:
	/* 0xfaf: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_f9a);

	/* native subroutine native_link_sub_fb0 */
x86_l_fb0:
	/* 0xfb0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fb2:
	/* 0xfb2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_fb4:
	/* 0xfb4: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_fb5:
	/* 0xfb5: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_fb9:
	/* 0xfb9: mov    ebx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_fbb:
	/* 0xfbb: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_fbe:
	/* 0xfbe: mov    DWORD PTR [rsp+0xc],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_fc2:
	/* 0xfc2: mov    DWORD PTR [rsp+0x8],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_fca:
	/* 0xfca: mov    rdi,QWORD PTR [rip+0x2930] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps));
x86_l_fd1:
	/* 0xfd1: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_fd6:
	/* 0xfd6: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_fdb:
	/* 0xfdb: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fdd:
	/* 0xfdd: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fe0:
	/* 0xfe0: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_fe2:
	/* 0xfe2: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_fe4:
	/* 0xfe4: je     10ee <filter_char_buf_postfix+0x13e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfe4, 0x10ee, x86_l_10ee);
x86_l_fea:
	/* 0xfea: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_fed:
	/* 0xfed: je     10ee <filter_char_buf_postfix+0x13e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0xfed, 0x10ee, x86_l_10ee);
x86_l_ff3:
	/* 0xff3: mov    rdi,QWORD PTR [rip+0x2930] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_postfix_maps_heap));
x86_l_ffa:
	/* 0xffa: lea    rsi,[rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fff:
	/* 0xfff: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1004:
	/* 0x1004: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1006:
	/* 0x1006: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1009:
	/* 0x1009: je     10ec <filter_char_buf_postfix+0x13c> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1009, 0x10ec, x86_l_10ec);
x86_l_100f:
	/* 0x100f: cmp    ebx,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_1012:
	/* 0x1012: mov    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 127ULL);
x86_l_1017:
	/* 0x1017: cmovb  ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RBX, X86_WIDTH_32, X86_CC_B, 0);
x86_l_101a:
	/* 0x101a: shl    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_101d:
	/* 0x101d: mov    DWORD PTR [rax],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_101f:
	/* 0x101f: mov    ecx,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1021:
	/* 0x1021: lea    edx,[rbx-0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551612ULL);
x86_l_1024:
	/* 0x1024: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1027:
	/* 0x1027: add    rsi,0x7 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 7ULL);
x86_l_102b:
	/* 0x102b: lea    edi,[rbx-0x3] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_102e:
	/* 0x102e: lea    r8d,[rbx-0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1032:
	/* 0x1032: dec    ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1034:
	/* 0x1034: mov    r9,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_103b:
	/* 0x103b: lea    r10d,[rbx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_103f:
	/* 0x103f: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1043:
	/* 0x1043: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_104a:
	/* 0x104a: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_104f:
	/* 0x104f: mov    BYTE PTR [rsi-0x3],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551613ULL);
x86_l_1053:
	/* 0x1053: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1057:
	/* 0x1057: cmp    r10,0xfffffffffffffffe */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551614ULL);
x86_l_105b:
	/* 0x105b: je     10d2 <filter_char_buf_postfix+0x122> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x105b, 0x10d2, x86_l_10d2);
x86_l_105d:
	/* 0x105d: lea    r11d,[r8+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R11, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_1061:
	/* 0x1061: add    r11d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1065:
	/* 0x1065: and    r11d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R11, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_106c:
	/* 0x106c: movzx  r11d,BYTE PTR [r14+r11*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R11, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R11, 0, X86_WIDTH_8), 0ULL);
x86_l_1071:
	/* 0x1071: mov    BYTE PTR [rsi-0x2],r11b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R11, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551614ULL);
x86_l_1075:
	/* 0x1075: cmp    r10,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_1079:
	/* 0x1079: je     10d2 <filter_char_buf_postfix+0x122> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1079, 0x10d2, x86_l_10d2);
x86_l_107b:
	/* 0x107b: lea    r10d,[rdi+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_107f:
	/* 0x107f: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1083:
	/* 0x1083: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_108a:
	/* 0x108a: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_108f:
	/* 0x108f: mov    BYTE PTR [rsi-0x1],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1093:
	/* 0x1093: mov    r10,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R10, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1096:
	/* 0x1096: add    r10,r9 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1099:
	/* 0x1099: je     10d2 <filter_char_buf_postfix+0x122> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1099, 0x10d2, x86_l_10d2);
x86_l_109b:
	/* 0x109b: cmp    r9,0xffffffffffffff81 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551489ULL);
x86_l_109f:
	/* 0x109f: je     10d2 <filter_char_buf_postfix+0x122> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x109f, 0x10d2, x86_l_10d2);
x86_l_10a1:
	/* 0x10a1: lea    r10d,[rdx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_10a5:
	/* 0x10a5: add    r10d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_10a9:
	/* 0x10a9: and    r10d,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_10b0:
	/* 0x10b0: movzx  r10d,BYTE PTR [r14+r10*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R10, 0, X86_WIDTH_8), 0ULL);
x86_l_10b5:
	/* 0x10b5: mov    BYTE PTR [rsi],r10b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSI, X86_R10, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b8:
	/* 0x10b8: add    rsi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_10bc:
	/* 0x10bc: lea    r10,[rcx+r9*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_R9, 0), 0ULL);
x86_l_10c0:
	/* 0x10c0: add    r10,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_10c4:
	/* 0x10c4: add    r9,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_10c8:
	/* 0x10c8: cmp    r10,0xfffffffffffffffd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551613ULL);
x86_l_10cc:
	/* 0x10cc: jne    103b <filter_char_buf_postfix+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x10cc, 0x103b, x86_l_103b);
x86_l_10d2:
	/* 0x10d2: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_10d7:
	/* 0x10d7: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10da:
	/* 0x10da: mov    rsi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10dd:
	/* 0x10dd: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10df:
	/* 0x10df: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e2:
	/* 0x10e2: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10e4:
	/* 0x10e4: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_10e7:
	/* 0x10e7: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_10ea:
	/* 0x10ea: jmp    10ee <filter_char_buf_postfix+0x13e> */
	X86_SIM_X86_SUB_JMP(0x10ea, 0x10ee, x86_l_10ee);
x86_l_10ec:
	/* 0x10ec: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10ee:
	/* 0x10ee: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_10f2:
	/* 0x10f2: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10f3:
	/* 0x10f3: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10f5:
	/* 0x10f5: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_10f7:
	/* 0x10f7: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_10f7);

	/* native subroutine native_link_sub_10f8 */
x86_l_10f8:
	/* 0x10f8: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_10f9:
	/* 0x10f9: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_10fb:
	/* 0x10fb: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_10fd:
	/* 0x10fd: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_10fe:
	/* 0x10fe: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10ff:
	/* 0x10ff: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1101:
	/* 0x1101: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1104:
	/* 0x1104: mov    DWORD PTR [rsp+0x4],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1108:
	/* 0x1108: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_110f:
	/* 0x110f: mov    rdi,QWORD PTR [rip+0x2800] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps));
x86_l_1116:
	/* 0x1116: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_111b:
	/* 0x111b: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1120:
	/* 0x1120: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1122:
	/* 0x1122: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1125:
	/* 0x1125: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1127:
	/* 0x1127: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_1129:
	/* 0x1129: je     1216 <filter_char_buf_prefix+0x11e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1129, 0x1216, x86_l_1216);
x86_l_112f:
	/* 0x112f: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1132:
	/* 0x1132: je     1216 <filter_char_buf_prefix+0x11e> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1132, 0x1216, x86_l_1216);
x86_l_1138:
	/* 0x1138: mov    rdi,QWORD PTR [rip+0x2800] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_prefix_maps_heap));
x86_l_113f:
	/* 0x113f: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1142:
	/* 0x1142: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1147:
	/* 0x1147: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1149:
	/* 0x1149: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_114c:
	/* 0x114c: je     11b1 <filter_char_buf_prefix+0xb9> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x114c, 0x11b1, x86_l_11b1);
x86_l_114e:
	/* 0x114e: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1151:
	/* 0x1151: cmp    ebp,0xff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_1157:
	/* 0x1157: mov    esi,0xff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 255ULL);
x86_l_115c:
	/* 0x115c: cmovb  esi,ebp */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RBP, X86_WIDTH_32, X86_CC_B, 0);
x86_l_115f:
	/* 0x115f: lea    eax,[rsi*8+0x0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 3), 0ULL);
x86_l_1166:
	/* 0x1166: mov    DWORD PTR [r15],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1169:
	/* 0x1169: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_116c:
	/* 0x116c: add    rdi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1170:
	/* 0x1170: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1173:
	/* 0x1173: jns    11b5 <filter_char_buf_prefix+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1173, 0x11b5, x86_l_11b5);
x86_l_1175:
	/* 0x1175: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1178:
	/* 0x1178: jns    11c3 <filter_char_buf_prefix+0xcb> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1178, 0x11c3, x86_l_11c3);
x86_l_117a:
	/* 0x117a: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_117c:
	/* 0x117c: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_117f:
	/* 0x117f: jb     119d <filter_char_buf_prefix+0xa5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x117f, 0x119d, x86_l_119d);
x86_l_1181:
	/* 0x1181: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1183:
	/* 0x1183: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1185:
	/* 0x1185: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1188:
	/* 0x1188: mov    rax,QWORD PTR [r14+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_118c:
	/* 0x118c: mov    QWORD PTR [rdi+rdx*1],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1190:
	/* 0x1190: lea    rax,[rdx+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1194:
	/* 0x1194: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1198:
	/* 0x1198: cmp    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_119b:
	/* 0x119b: jbe    1185 <filter_char_buf_prefix+0x8d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x119b, 0x1185, x86_l_1185);
x86_l_119d:
	/* 0x119d: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_11a1:
	/* 0x11a1: jne    11ce <filter_char_buf_prefix+0xd6> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x11a1, 0x11ce, x86_l_11ce);
x86_l_11a3:
	/* 0x11a3: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11a7:
	/* 0x11a7: jne    11e0 <filter_char_buf_prefix+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x11a7, 0x11e0, x86_l_11e0);
x86_l_11a9:
	/* 0x11a9: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_11ad:
	/* 0x11ad: jne    11f4 <filter_char_buf_prefix+0xfc> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x11ad, 0x11f4, x86_l_11f4);
x86_l_11af:
	/* 0x11af: jmp    11fe <filter_char_buf_prefix+0x106> */
	X86_SIM_X86_SUB_JMP(0x11af, 0x11fe, x86_l_11fe);
x86_l_11b1:
	/* 0x11b1: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11b3:
	/* 0x11b3: jmp    1216 <filter_char_buf_prefix+0x11e> */
	X86_SIM_X86_SUB_JMP(0x11b3, 0x1216, x86_l_1216);
x86_l_11b5:
	/* 0x11b5: mov    eax,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_11b7:
	/* 0x11b7: mov    ecx,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_11bc:
	/* 0x11bc: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_11bf:
	/* 0x11bf: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11c1:
	/* 0x11c1: jmp    11fe <filter_char_buf_prefix+0x106> */
	X86_SIM_X86_SUB_JMP(0x11c1, 0x11fe, x86_l_11fe);
x86_l_11c3:
	/* 0x11c3: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_11c5:
	/* 0x11c5: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_11c7:
	/* 0x11c7: call   39cf <filter_file_type+0x131b> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_11cc:
	/* 0x11cc: jmp    11fe <filter_char_buf_prefix+0x106> */
	X86_SIM_X86_SUB_JMP(0x11cc, 0x11fe, x86_l_11fe);
x86_l_11ce:
	/* 0x11ce: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11d0:
	/* 0x11d0: mov    edx,DWORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11d4:
	/* 0x11d4: mov    DWORD PTR [rdi+rcx*1],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11d7:
	/* 0x11d7: or     eax,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_11da:
	/* 0x11da: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11de:
	/* 0x11de: je     11a9 <filter_char_buf_prefix+0xb1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11de, 0x11a9, x86_l_11a9);
x86_l_11e0:
	/* 0x11e0: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11e2:
	/* 0x11e2: movzx  edx,WORD PTR [r14+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_16), 0ULL);
x86_l_11e7:
	/* 0x11e7: mov    WORD PTR [rdi+rcx*1],dx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_11eb:
	/* 0x11eb: add    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_11ee:
	/* 0x11ee: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_11f2:
	/* 0x11f2: je     11fe <filter_char_buf_prefix+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x11f2, 0x11fe, x86_l_11fe);
x86_l_11f4:
	/* 0x11f4: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_11f6:
	/* 0x11f6: movzx  ecx,BYTE PTR [r14+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_8), 0ULL);
x86_l_11fb:
	/* 0x11fb: mov    BYTE PTR [rdi+rax*1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_11fe:
	/* 0x11fe: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1203:
	/* 0x1203: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1206:
	/* 0x1206: mov    rsi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1209:
	/* 0x1209: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_120b:
	/* 0x120b: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_120e:
	/* 0x120e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1210:
	/* 0x1210: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1213:
	/* 0x1213: setne  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1216:
	/* 0x1216: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_121a:
	/* 0x121a: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_121b:
	/* 0x121b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_121d:
	/* 0x121d: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_121f:
	/* 0x121f: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1220:
	/* 0x1220: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1220);

	/* native subroutine native_link_sub_1221 */
x86_l_1221:
	/* 0x1221: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1222:
	/* 0x1222: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1224:
	/* 0x1224: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1226:
	/* 0x1226: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1228:
	/* 0x1228: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_122a:
	/* 0x122a: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_122b:
	/* 0x122b: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_122c:
	/* 0x122c: mov    DWORD PTR [rsp+0x4],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869184ULL);
x86_l_1234:
	/* 0x1234: cmp    edx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4096ULL);
x86_l_123a:
	/* 0x123a: ja     1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x123a, 0x1697, x86_l_1697);
x86_l_1240:
	/* 0x1240: movzx  eax,dx */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1243:
	/* 0x1243: cmp    eax,0x90 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1248:
	/* 0x1248: ja     1298 <filter_char_buf_equal+0x77> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1248, 0x1298, x86_l_1298);
x86_l_124a:
	/* 0x124a: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_124d:
	/* 0x124d: imul   ecx,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_1253:
	/* 0x1253: shr    ecx,0x9 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 9ULL);
x86_l_1256:
	/* 0x1256: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1259:
	/* 0x1259: lea    ecx,[rcx+rcx*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_RCX, 1), 0ULL);
x86_l_125c:
	/* 0x125c: sub    al,cl */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_ALU_SUB, 0);
x86_l_125e:
	/* 0x125e: test   dx,dx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_16, 0, 0);
x86_l_1261:
	/* 0x1261: je     126c <filter_char_buf_equal+0x4b> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1261, 0x126c, x86_l_126c);
x86_l_1263:
	/* 0x1263: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1265:
	/* 0x1265: mov    r15d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1268:
	/* 0x1268: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_126a:
	/* 0x126a: je     1285 <filter_char_buf_equal+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x126a, 0x1285, x86_l_1285);
x86_l_126c:
	/* 0x126c: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_126f:
	/* 0x126f: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1271:
	/* 0x1271: sub    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1273:
	/* 0x1273: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1275:
	/* 0x1275: add    eax,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 24ULL);
x86_l_1278:
	/* 0x1278: movzx  r15d,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_R15, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_127c:
	/* 0x127c: cmp    cx,0x78 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_16, 0, 120ULL);
x86_l_1280:
	/* 0x1280: ja     12d6 <filter_char_buf_equal+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1280, 0x12d6, x86_l_12d6);
x86_l_1282:
	/* 0x1282: mov    ecx,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1285:
	/* 0x1285: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1288:
	/* 0x1288: imul   ebp,eax,0xab */
	X86_SIM_RUN_OP(X86_OP_IMUL_IMM, X86_RBP, X86_RAX, X86_WIDTH_32, 0, 171ULL);
x86_l_128e:
	/* 0x128e: shr    ebp,0xc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 12ULL);
x86_l_1291:
	/* 0x1291: dec    ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1293:
	/* 0x1293: jmp    131c <filter_char_buf_equal+0xfb> */
	X86_SIM_X86_SUB_JMP(0x1293, 0x131c, x86_l_131c);
x86_l_1298:
	/* 0x1298: mov    r15d,0x100 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 256ULL);
x86_l_129e:
	/* 0x129e: cmp    eax,0x101 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 257ULL);
x86_l_12a3:
	/* 0x12a3: jb     12d6 <filter_char_buf_equal+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12a3, 0x12d6, x86_l_12d6);
x86_l_12a5:
	/* 0x12a5: mov    r15d,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_12ab:
	/* 0x12ab: cmp    eax,0x201 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 513ULL);
x86_l_12b0:
	/* 0x12b0: jb     12d6 <filter_char_buf_equal+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12b0, 0x12d6, x86_l_12d6);
x86_l_12b2:
	/* 0x12b2: mov    r15d,0x400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 1024ULL);
x86_l_12b8:
	/* 0x12b8: cmp    eax,0x401 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1025ULL);
x86_l_12bd:
	/* 0x12bd: jb     12d6 <filter_char_buf_equal+0xb5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x12bd, 0x12d6, x86_l_12d6);
x86_l_12bf:
	/* 0x12bf: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_12c2:
	/* 0x12c2: cmp    eax,0x801 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2049ULL);
x86_l_12c7:
	/* 0x12c7: setae  r15b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_12cb:
	/* 0x12cb: shl    r15d,0xb */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 11ULL);
x86_l_12cf:
	/* 0x12cf: add    r15d,0x800 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2048ULL);
x86_l_12d6:
	/* 0x12d6: lea    eax,[r15-0x100] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551360ULL);
x86_l_12dd:
	/* 0x12dd: rorx   eax,eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 8ULL);
x86_l_12e3:
	/* 0x12e3: cmp    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_12e6:
	/* 0x12e6: jg     12f8 <filter_char_buf_equal+0xd7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x12e6, 0x12f8, x86_l_12f8);
x86_l_12e8:
	/* 0x12e8: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_12ea:
	/* 0x12ea: je     1310 <filter_char_buf_equal+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12ea, 0x1310, x86_l_1310);
x86_l_12ec:
	/* 0x12ec: cmp    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12ef:
	/* 0x12ef: jne    1309 <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x12ef, 0x1309, x86_l_1309);
x86_l_12f1:
	/* 0x12f1: mov    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_12f6:
	/* 0x12f6: jmp    131c <filter_char_buf_equal+0xfb> */
	X86_SIM_X86_SUB_JMP(0x12f6, 0x131c, x86_l_131c);
x86_l_12f8:
	/* 0x12f8: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_12fb:
	/* 0x12fb: je     1317 <filter_char_buf_equal+0xf6> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x12fb, 0x1317, x86_l_1317);
x86_l_12fd:
	/* 0x12fd: cmp    eax,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1300:
	/* 0x1300: jne    1309 <filter_char_buf_equal+0xe8> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1300, 0x1309, x86_l_1309);
x86_l_1302:
	/* 0x1302: mov    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_1307:
	/* 0x1307: jmp    131c <filter_char_buf_equal+0xfb> */
	X86_SIM_X86_SUB_JMP(0x1307, 0x131c, x86_l_131c);
x86_l_1309:
	/* 0x1309: mov    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_130e:
	/* 0x130e: jmp    131c <filter_char_buf_equal+0xfb> */
	X86_SIM_X86_SUB_JMP(0x130e, 0x131c, x86_l_131c);
x86_l_1310:
	/* 0x1310: mov    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1315:
	/* 0x1315: jmp    131c <filter_char_buf_equal+0xfb> */
	X86_SIM_X86_SUB_JMP(0x1315, 0x131c, x86_l_131c);
x86_l_1317:
	/* 0x1317: mov    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_131c:
	/* 0x131c: mov    eax,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_131e:
	/* 0x131e: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1321:
	/* 0x1321: mov    r12d,DWORD PTR [rdi+rax*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 2), 16ULL);
x86_l_1326:
	/* 0x1326: cmp    r12d,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_132a:
	/* 0x132a: je     1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x132a, 0x1697, x86_l_1697);
x86_l_1330:
	/* 0x1330: mov    rbx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1333:
	/* 0x1333: mov    r13d,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1336:
	/* 0x1336: mov    rdi,QWORD PTR [rip+0x2270] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_heap));
x86_l_133d:
	/* 0x133d: lea    r14,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1342:
	/* 0x1342: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1347:
	/* 0x1347: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_134a:
	/* 0x134a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_134c:
	/* 0x134c: mov    rdi,QWORD PTR [rip+0x2270] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)heap_ro_zero));
x86_l_1353:
	/* 0x1353: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1358:
	/* 0x1358: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_135b:
	/* 0x135b: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_135e:
	/* 0x135e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1360:
	/* 0x1360: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1362:
	/* 0x1362: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1365:
	/* 0x1365: je     1699 <filter_char_buf_equal+0x478> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1365, 0x1699, x86_l_1699);
x86_l_136b:
	/* 0x136b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_136e:
	/* 0x136e: je     1699 <filter_char_buf_equal+0x478> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x136e, 0x1699, x86_l_1699);
x86_l_1374:
	/* 0x1374: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_1377:
	/* 0x1377: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_137a:
	/* 0x137a: jg     13dd <filter_char_buf_equal+0x1bc> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x137a, 0x13dd, x86_l_13dd);
x86_l_137c:
	/* 0x137c: mov    BYTE PTR [r14],sil */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_137f:
	/* 0x137f: lea    rdi,[r14+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1383:
	/* 0x1383: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1386:
	/* 0x1386: jns    1433 <filter_char_buf_equal+0x212> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1386, 0x1433, x86_l_1433);
x86_l_138c:
	/* 0x138c: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_138f:
	/* 0x138f: jns    1450 <filter_char_buf_equal+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x138f, 0x1450, x86_l_1450);
x86_l_1395:
	/* 0x1395: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1397:
	/* 0x1397: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_139a:
	/* 0x139a: jb     13ba <filter_char_buf_equal+0x199> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x139a, 0x13ba, x86_l_13ba);
x86_l_139c:
	/* 0x139c: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_139f:
	/* 0x139f: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_13a2:
	/* 0x13a2: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_13a6:
	/* 0x13a6: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_13aa:
	/* 0x13aa: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_13ae:
	/* 0x13ae: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_13b2:
	/* 0x13b2: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_13b5:
	/* 0x13b5: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_13b8:
	/* 0x13b8: jbe    139f <filter_char_buf_equal+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x13b8, 0x139f, x86_l_139f);
x86_l_13ba:
	/* 0x13ba: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_13be:
	/* 0x13be: jne    16ab <filter_char_buf_equal+0x48a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x13be, 0x16ab, x86_l_16ab);
x86_l_13c4:
	/* 0x13c4: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_13c8:
	/* 0x13c8: jne    16c3 <filter_char_buf_equal+0x4a2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x13c8, 0x16c3, x86_l_16c3);
x86_l_13ce:
	/* 0x13ce: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_13d2:
	/* 0x13d2: je     1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x13d2, 0x1462, x86_l_1462);
x86_l_13d8:
	/* 0x13d8: jmp    16dd <filter_char_buf_equal+0x4bc> */
	X86_SIM_X86_SUB_JMP(0x13d8, 0x16dd, x86_l_16dd);
x86_l_13dd:
	/* 0x13dd: mov    WORD PTR [r14],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13e1:
	/* 0x13e1: lea    rdi,[r14+0x2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_13e5:
	/* 0x13e5: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13e8:
	/* 0x13e8: jns    143d <filter_char_buf_equal+0x21c> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13e8, 0x143d, x86_l_143d);
x86_l_13ea:
	/* 0x13ea: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_13ed:
	/* 0x13ed: jns    1450 <filter_char_buf_equal+0x22f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x13ed, 0x1450, x86_l_1450);
x86_l_13ef:
	/* 0x13ef: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13f1:
	/* 0x13f1: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_13f4:
	/* 0x13f4: jb     1414 <filter_char_buf_equal+0x1f3> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x13f4, 0x1414, x86_l_1414);
x86_l_13f6:
	/* 0x13f6: xor    r8d,r8d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13f9:
	/* 0x13f9: mov    ecx,r8d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R8, X86_WIDTH_32, 0, 0);
x86_l_13fc:
	/* 0x13fc: mov    r9,QWORD PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1400:
	/* 0x1400: mov    QWORD PTR [rdi+rcx*1],r9 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1404:
	/* 0x1404: lea    ecx,[r8+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1408:
	/* 0x1408: add    r8d,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 16ULL);
x86_l_140c:
	/* 0x140c: cmp    r8d,esi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_140f:
	/* 0x140f: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1412:
	/* 0x1412: jbe    13f9 <filter_char_buf_equal+0x1d8> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1412, 0x13f9, x86_l_13f9);
x86_l_1414:
	/* 0x1414: test   sil,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_1418:
	/* 0x1418: jne    16eb <filter_char_buf_equal+0x4ca> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1418, 0x16eb, x86_l_16eb);
x86_l_141e:
	/* 0x141e: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1422:
	/* 0x1422: jne    1703 <filter_char_buf_equal+0x4e2> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1422, 0x1703, x86_l_1703);
x86_l_1428:
	/* 0x1428: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_142c:
	/* 0x142c: je     1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x142c, 0x1462, x86_l_1462);
x86_l_142e:
	/* 0x142e: jmp    171d <filter_char_buf_equal+0x4fc> */
	X86_SIM_X86_SUB_JMP(0x142e, 0x171d, x86_l_171d);
x86_l_1433:
	/* 0x1433: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1435:
	/* 0x1435: mov    r8d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_143b:
	/* 0x143b: jmp    1445 <filter_char_buf_equal+0x224> */
	X86_SIM_X86_SUB_JMP(0x143b, 0x1445, x86_l_1445);
x86_l_143d:
	/* 0x143d: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_143f:
	/* 0x143f: mov    r8d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_1445:
	/* 0x1445: mov    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1448:
	/* 0x1448: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_144b:
	/* 0x144b: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_144e:
	/* 0x144e: jmp    145c <filter_char_buf_equal+0x23b> */
	X86_SIM_X86_SUB_JMP(0x144e, 0x145c, x86_l_145c);
x86_l_1450:
	/* 0x1450: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1452:
	/* 0x1452: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1454:
	/* 0x1454: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1457:
	/* 0x1457: call   36d4 <filter_file_type+0x1020> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_145c:
	/* 0x145c: mov    esi,r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_32, 0, 0);
x86_l_145f:
	/* 0x145f: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1462:
	/* 0x1462: sub    r15d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RSI, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1465:
	/* 0x1465: jle    154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1465, 0x154b, x86_l_154b);
x86_l_146b:
	/* 0x146b: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_146d:
	/* 0x146d: mov    rdi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1470:
	/* 0x1470: add    rdi,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1473:
	/* 0x1473: mov    esi,r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R15, X86_WIDTH_32, 0, 0);
x86_l_1476:
	/* 0x1476: and    esi,0xfff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_147c:
	/* 0x147c: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_147f:
	/* 0x147f: jg     14d8 <filter_char_buf_equal+0x2b7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x147f, 0x14d8, x86_l_14d8);
x86_l_1481:
	/* 0x1481: inc    rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1484:
	/* 0x1484: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1487:
	/* 0x1487: jns    1528 <filter_char_buf_equal+0x307> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1487, 0x1528, x86_l_1528);
x86_l_148d:
	/* 0x148d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1490:
	/* 0x1490: jns    1542 <filter_char_buf_equal+0x321> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1490, 0x1542, x86_l_1542);
x86_l_1496:
	/* 0x1496: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1498:
	/* 0x1498: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_149b:
	/* 0x149b: jb     14b9 <filter_char_buf_equal+0x298> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x149b, 0x14b9, x86_l_14b9);
x86_l_149d:
	/* 0x149d: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_149f:
	/* 0x149f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14a1:
	/* 0x14a1: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14a4:
	/* 0x14a4: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_14a8:
	/* 0x14a8: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_14ac:
	/* 0x14ac: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14b0:
	/* 0x14b0: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14b4:
	/* 0x14b4: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_14b7:
	/* 0x14b7: jbe    14a1 <filter_char_buf_equal+0x280> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x14b7, 0x14a1, x86_l_14a1);
x86_l_14b9:
	/* 0x14b9: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_14bd:
	/* 0x14bd: jne    172b <filter_char_buf_equal+0x50a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14bd, 0x172b, x86_l_172b);
x86_l_14c3:
	/* 0x14c3: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_14c7:
	/* 0x14c7: jne    1740 <filter_char_buf_equal+0x51f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x14c7, 0x1740, x86_l_1740);
x86_l_14cd:
	/* 0x14cd: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_14d1:
	/* 0x14d1: je     154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x14d1, 0x154b, x86_l_154b);
x86_l_14d3:
	/* 0x14d3: jmp    1757 <filter_char_buf_equal+0x536> */
	X86_SIM_X86_SUB_JMP(0x14d3, 0x1757, x86_l_1757);
x86_l_14d8:
	/* 0x14d8: add    rdi,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_14dc:
	/* 0x14dc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14df:
	/* 0x14df: jns    1532 <filter_char_buf_equal+0x311> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x14df, 0x1532, x86_l_1532);
x86_l_14e1:
	/* 0x14e1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14e4:
	/* 0x14e4: jns    1542 <filter_char_buf_equal+0x321> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x14e4, 0x1542, x86_l_1542);
x86_l_14e6:
	/* 0x14e6: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e8:
	/* 0x14e8: cmp    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_14eb:
	/* 0x14eb: jb     1509 <filter_char_buf_equal+0x2e8> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x14eb, 0x1509, x86_l_1509);
x86_l_14ed:
	/* 0x14ed: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_14ef:
	/* 0x14ef: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14f1:
	/* 0x14f1: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14f4:
	/* 0x14f4: mov    rcx,QWORD PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_14f8:
	/* 0x14f8: mov    QWORD PTR [rdi+rsi*1],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_14fc:
	/* 0x14fc: lea    rcx,[rsi+0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1500:
	/* 0x1500: add    rsi,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1504:
	/* 0x1504: cmp    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_1507:
	/* 0x1507: jbe    14f1 <filter_char_buf_equal+0x2d0> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1507, 0x14f1, x86_l_14f1);
x86_l_1509:
	/* 0x1509: test   r15b,0x4 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 4ULL);
x86_l_150d:
	/* 0x150d: jne    1765 <filter_char_buf_equal+0x544> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x150d, 0x1765, x86_l_1765);
x86_l_1513:
	/* 0x1513: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1517:
	/* 0x1517: jne    177a <filter_char_buf_equal+0x559> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1517, 0x177a, x86_l_177a);
x86_l_151d:
	/* 0x151d: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1521:
	/* 0x1521: je     154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1521, 0x154b, x86_l_154b);
x86_l_1523:
	/* 0x1523: jmp    1791 <filter_char_buf_equal+0x570> */
	X86_SIM_X86_SUB_JMP(0x1523, 0x1791, x86_l_1791);
x86_l_1528:
	/* 0x1528: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_152a:
	/* 0x152a: mov    r8d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_1530:
	/* 0x1530: jmp    153a <filter_char_buf_equal+0x319> */
	X86_SIM_X86_SUB_JMP(0x1530, 0x153a, x86_l_153a);
x86_l_1532:
	/* 0x1532: mov    ecx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1534:
	/* 0x1534: mov    r8d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_153a:
	/* 0x153a: mov    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153d:
	/* 0x153d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1540:
	/* 0x1540: jmp    154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JMP(0x1540, 0x154b, x86_l_154b);
x86_l_1542:
	/* 0x1542: mov    edx,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_1544:
	/* 0x1544: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1546:
	/* 0x1546: call   37c3 <filter_file_type+0x110f> */
	X86_SIM_RUN_OP(X86_OP_CALL_MEMSET_REG, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0ULL);
x86_l_154b:
	/* 0x154b: mov    DWORD PTR [rsp],r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_154f:
	/* 0x154f: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1552:
	/* 0x1552: jle    1588 <filter_char_buf_equal+0x367> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1552, 0x1588, x86_l_1588);
x86_l_1554:
	/* 0x1554: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_1557:
	/* 0x1557: jg     15b8 <filter_char_buf_equal+0x397> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1557, 0x15b8, x86_l_15b8);
x86_l_1559:
	/* 0x1559: cmp    ebp,0x5 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_155c:
	/* 0x155c: je     1656 <filter_char_buf_equal+0x435> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x155c, 0x1656, x86_l_1656);
x86_l_1562:
	/* 0x1562: cmp    ebp,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1565:
	/* 0x1565: je     1623 <filter_char_buf_equal+0x402> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1565, 0x1623, x86_l_1623);
x86_l_156b:
	/* 0x156b: cmp    ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 7ULL);
x86_l_156e:
	/* 0x156e: jne    1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x156e, 0x1697, x86_l_1697);
x86_l_1574:
	/* 0x1574: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_7));
x86_l_157b:
	/* 0x157b: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_157e:
	/* 0x157e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1583:
	/* 0x1583: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1583, 0x1676, x86_l_1676);
x86_l_1588:
	/* 0x1588: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_158b:
	/* 0x158b: jle    15e3 <filter_char_buf_equal+0x3c2> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x158b, 0x15e3, x86_l_15e3);
x86_l_158d:
	/* 0x158d: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1590:
	/* 0x1590: je     1645 <filter_char_buf_equal+0x424> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1590, 0x1645, x86_l_1645);
x86_l_1596:
	/* 0x1596: cmp    ebp,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1599:
	/* 0x1599: je     1612 <filter_char_buf_equal+0x3f1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1599, 0x1612, x86_l_1612);
x86_l_159b:
	/* 0x159b: cmp    ebp,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_159e:
	/* 0x159e: jne    1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x159e, 0x1697, x86_l_1697);
x86_l_15a4:
	/* 0x15a4: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_4));
x86_l_15ab:
	/* 0x15ab: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_15ae:
	/* 0x15ae: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_15b3:
	/* 0x15b3: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x15b3, 0x1676, x86_l_1676);
x86_l_15b8:
	/* 0x15b8: cmp    ebp,0x8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_15bb:
	/* 0x15bb: je     1667 <filter_char_buf_equal+0x446> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15bb, 0x1667, x86_l_1667);
x86_l_15c1:
	/* 0x15c1: cmp    ebp,0x9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_15c4:
	/* 0x15c4: je     1634 <filter_char_buf_equal+0x413> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15c4, 0x1634, x86_l_1634);
x86_l_15c6:
	/* 0x15c6: cmp    ebp,0xa */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_15c9:
	/* 0x15c9: jne    1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x15c9, 0x1697, x86_l_1697);
x86_l_15cf:
	/* 0x15cf: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_10));
x86_l_15d6:
	/* 0x15d6: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_15d9:
	/* 0x15d9: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_15de:
	/* 0x15de: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x15de, 0x1676, x86_l_1676);
x86_l_15e3:
	/* 0x15e3: test   ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_15e5:
	/* 0x15e5: je     1601 <filter_char_buf_equal+0x3e0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x15e5, 0x1601, x86_l_1601);
x86_l_15e7:
	/* 0x15e7: cmp    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_15ea:
	/* 0x15ea: jne    1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x15ea, 0x1697, x86_l_1697);
x86_l_15f0:
	/* 0x15f0: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_1));
x86_l_15f7:
	/* 0x15f7: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_15fa:
	/* 0x15fa: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_15ff:
	/* 0x15ff: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x15ff, 0x1676, x86_l_1676);
x86_l_1601:
	/* 0x1601: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_0));
x86_l_1608:
	/* 0x1608: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_160b:
	/* 0x160b: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1610:
	/* 0x1610: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1610, 0x1676, x86_l_1676);
x86_l_1612:
	/* 0x1612: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_3));
x86_l_1619:
	/* 0x1619: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_161c:
	/* 0x161c: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1621:
	/* 0x1621: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1621, 0x1676, x86_l_1676);
x86_l_1623:
	/* 0x1623: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_6));
x86_l_162a:
	/* 0x162a: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_162d:
	/* 0x162d: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1632:
	/* 0x1632: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1632, 0x1676, x86_l_1676);
x86_l_1634:
	/* 0x1634: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_9));
x86_l_163b:
	/* 0x163b: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_163e:
	/* 0x163e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1643:
	/* 0x1643: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1643, 0x1676, x86_l_1676);
x86_l_1645:
	/* 0x1645: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_2));
x86_l_164c:
	/* 0x164c: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_164f:
	/* 0x164f: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1654:
	/* 0x1654: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1654, 0x1676, x86_l_1676);
x86_l_1656:
	/* 0x1656: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_5));
x86_l_165d:
	/* 0x165d: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1660:
	/* 0x1660: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1665:
	/* 0x1665: jmp    1676 <filter_char_buf_equal+0x455> */
	X86_SIM_X86_SUB_JMP(0x1665, 0x1676, x86_l_1676);
x86_l_1667:
	/* 0x1667: mov    rdi,QWORD PTR [rip+0x2278] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)string_maps_8));
x86_l_166e:
	/* 0x166e: mov    rcx,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1671:
	/* 0x1671: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1676:
	/* 0x1676: mov    rsi,rsp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSP, X86_WIDTH_64, 0, 0);
x86_l_1679:
	/* 0x1679: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_167b:
	/* 0x167b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_167e:
	/* 0x167e: je     1697 <filter_char_buf_equal+0x476> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x167e, 0x1697, x86_l_1697);
x86_l_1680:
	/* 0x1680: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1685:
	/* 0x1685: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1688:
	/* 0x1688: mov    rsi,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_168b:
	/* 0x168b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_168d:
	/* 0x168d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_168f:
	/* 0x168f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1692:
	/* 0x1692: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1695:
	/* 0x1695: jmp    1699 <filter_char_buf_equal+0x478> */
	X86_SIM_X86_SUB_JMP(0x1695, 0x1699, x86_l_1699);
x86_l_1697:
	/* 0x1697: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1699:
	/* 0x1699: mov    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_169c:
	/* 0x169c: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16a0:
	/* 0x16a0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16a1:
	/* 0x16a1: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16a3:
	/* 0x16a3: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16a5:
	/* 0x16a5: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16a7:
	/* 0x16a7: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16a9:
	/* 0x16a9: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_16aa:
	/* 0x16aa: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_16aa);
x86_l_16ab:
	/* 0x16ab: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16ae:
	/* 0x16ae: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_16b2:
	/* 0x16b2: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_16b6:
	/* 0x16b6: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_16b9:
	/* 0x16b9: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_16bd:
	/* 0x16bd: je     13ce <filter_char_buf_equal+0x1ad> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16bd, 0x13ce, x86_l_13ce);
x86_l_16c3:
	/* 0x16c3: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16c6:
	/* 0x16c6: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_16cb:
	/* 0x16cb: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_16d0:
	/* 0x16d0: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_16d3:
	/* 0x16d3: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_16d7:
	/* 0x16d7: je     1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16d7, 0x1462, x86_l_1462);
x86_l_16dd:
	/* 0x16dd: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16df:
	/* 0x16df: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_16e3:
	/* 0x16e3: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_16e6:
	/* 0x16e6: jmp    1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JMP(0x16e6, 0x1462, x86_l_1462);
x86_l_16eb:
	/* 0x16eb: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16ee:
	/* 0x16ee: mov    r9d,DWORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_16f2:
	/* 0x16f2: mov    DWORD PTR [rdi+r8*1],r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_16f6:
	/* 0x16f6: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_16f9:
	/* 0x16f9: test   sil,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_16fd:
	/* 0x16fd: je     1428 <filter_char_buf_equal+0x207> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x16fd, 0x1428, x86_l_1428);
x86_l_1703:
	/* 0x1703: mov    r8d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1706:
	/* 0x1706: movzx  r9d,WORD PTR [rbx+r8*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_R8, 0, X86_WIDTH_16), 0ULL);
x86_l_170b:
	/* 0x170b: mov    WORD PTR [rdi+r8*1],r9w */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_R9, X86_WIDTH_16, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_1710:
	/* 0x1710: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1713:
	/* 0x1713: test   sil,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1717:
	/* 0x1717: je     1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1717, 0x1462, x86_l_1462);
x86_l_171d:
	/* 0x171d: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_171f:
	/* 0x171f: movzx  edx,BYTE PTR [rbx+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1723:
	/* 0x1723: mov    BYTE PTR [rdi+rcx*1],dl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RDX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1726:
	/* 0x1726: jmp    1462 <filter_char_buf_equal+0x241> */
	X86_SIM_X86_SUB_JMP(0x1726, 0x1462, x86_l_1462);
x86_l_172b:
	/* 0x172b: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_172d:
	/* 0x172d: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1730:
	/* 0x1730: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1733:
	/* 0x1733: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1736:
	/* 0x1736: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_173a:
	/* 0x173a: je     14cd <filter_char_buf_equal+0x2ac> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x173a, 0x14cd, x86_l_14cd);
x86_l_1740:
	/* 0x1740: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1742:
	/* 0x1742: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_1746:
	/* 0x1746: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_174a:
	/* 0x174a: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_174d:
	/* 0x174d: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1751:
	/* 0x1751: je     154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1751, 0x154b, x86_l_154b);
x86_l_1757:
	/* 0x1757: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1759:
	/* 0x1759: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_175d:
	/* 0x175d: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1760:
	/* 0x1760: jmp    154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JMP(0x1760, 0x154b, x86_l_154b);
x86_l_1765:
	/* 0x1765: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1767:
	/* 0x1767: mov    esi,DWORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_176a:
	/* 0x176a: mov    DWORD PTR [rdi+rdx*1],esi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_176d:
	/* 0x176d: or     ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 4ULL);
x86_l_1770:
	/* 0x1770: test   r15b,0x2 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1774:
	/* 0x1774: je     151d <filter_char_buf_equal+0x2fc> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1774, 0x151d, x86_l_151d);
x86_l_177a:
	/* 0x177a: mov    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_177c:
	/* 0x177c: movzx  esi,WORD PTR [rax+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RDX, 0, X86_WIDTH_16), 0ULL);
x86_l_1780:
	/* 0x1780: mov    WORD PTR [rdi+rdx*1],si */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1784:
	/* 0x1784: add    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 2ULL);
x86_l_1787:
	/* 0x1787: test   r15b,0x1 */
	X86_SIM_RUN_OP(X86_OP_TEST_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_178b:
	/* 0x178b: je     154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x178b, 0x154b, x86_l_154b);
x86_l_1791:
	/* 0x1791: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1793:
	/* 0x1793: movzx  eax,BYTE PTR [rax+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RCX, 0, X86_WIDTH_8), 0ULL);
x86_l_1797:
	/* 0x1797: mov    BYTE PTR [rdi+rcx*1],al */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_179a:
	/* 0x179a: jmp    154b <filter_char_buf_equal+0x32a> */
	X86_SIM_X86_SUB_JMP(0x179a, 0x154b, x86_l_154b);

	/* native subroutine native_link_sub_179f */
x86_l_179f:
	/* 0x179f: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_17a0:
	/* 0x17a0: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_17a2:
	/* 0x17a2: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_17a4:
	/* 0x17a4: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17a6:
	/* 0x17a6: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17a8:
	/* 0x17a8: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17a9:
	/* 0x17a9: push   rax */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17aa:
	/* 0x17aa: mov    r15,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_17ad:
	/* 0x17ad: mov    r14,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_17b0:
	/* 0x17b0: mov    ebp,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17b2:
	/* 0x17b2: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_17b4:
	/* 0x17b4: je     187c <filter_char_substring+0xdd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17b4, 0x187c, x86_l_187c);
x86_l_17ba:
	/* 0x17ba: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_17bc:
	/* 0x17bc: je     1919 <filter_char_substring+0x17a> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17bc, 0x1919, x86_l_1919);
x86_l_17c2:
	/* 0x17c2: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17c7:
	/* 0x17c7: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17c9:
	/* 0x17c9: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17cc:
	/* 0x17cc: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_17d1:
	/* 0x17d1: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17d5:
	/* 0x17d5: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_17da:
	/* 0x17da: mov    rdi,QWORD PTR [rip+0x2b53] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_17e1:
	/* 0x17e1: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_17e4:
	/* 0x17e4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_17e6:
	/* 0x17e6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17e9:
	/* 0x17e9: je     199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17e9, 0x199d, x86_l_199d);
x86_l_17ef:
	/* 0x17ef: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_17f2:
	/* 0x17f2: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_17f4:
	/* 0x17f4: jmp    1801 <filter_char_substring+0x62> */
	X86_SIM_X86_SUB_JMP(0x17f4, 0x1801, x86_l_1801);
x86_l_17f6:
	/* 0x17f6: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17f9:
	/* 0x17f9: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_17fc:
	/* 0x17fc: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_17ff:
	/* 0x17ff: je     1857 <filter_char_substring+0xb8> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x17ff, 0x1857, x86_l_1857);
x86_l_1801:
	/* 0x1801: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1803:
	/* 0x1803: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_1807:
	/* 0x1807: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_180a:
	/* 0x180a: jae    17f6 <filter_char_substring+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x180a, 0x17f6, x86_l_17f6);
x86_l_180c:
	/* 0x180c: movsx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1810:
	/* 0x1810: test   edi,edi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1812:
	/* 0x1812: je     184f <filter_char_substring+0xb0> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1812, 0x184f, x86_l_184f);
x86_l_1814:
	/* 0x1814: movsx  r9d,BYTE PTR [rdx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_1819:
	/* 0x1819: lea    r10d,[r9-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_181d:
	/* 0x181d: mov    r8d,r9d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_1820:
	/* 0x1820: or     r8d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_1824:
	/* 0x1824: cmp    r10d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_1828:
	/* 0x1828: cmovae r8d,r9d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R8, X86_R9, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_182c:
	/* 0x182c: lea    r10d,[rdi-0x41] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R10, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551551ULL);
x86_l_1830:
	/* 0x1830: mov    r9d,edi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R9, X86_RDI, X86_WIDTH_32, 0, 0);
x86_l_1833:
	/* 0x1833: or     r9d,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_32, X86_ALU_OR, 32ULL);
x86_l_1837:
	/* 0x1837: cmp    r10d,0x1a */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R10, X86_REG_NONE, X86_WIDTH_32, 0, 26ULL);
x86_l_183b:
	/* 0x183b: cmovae r9d,edi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R9, X86_RDI, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_183f:
	/* 0x183f: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_1843:
	/* 0x1843: ja     17f6 <filter_char_substring+0x57> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1843, 0x17f6, x86_l_17f6);
x86_l_1845:
	/* 0x1845: inc    rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_1848:
	/* 0x1848: cmp    r8d,r9d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R8, X86_R9, X86_WIDTH_32, 0, 0);
x86_l_184b:
	/* 0x184b: je     1803 <filter_char_substring+0x64> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x184b, 0x1803, x86_l_1803);
x86_l_184d:
	/* 0x184d: jmp    17f6 <filter_char_substring+0x57> */
	X86_SIM_X86_SUB_JMP(0x184d, 0x17f6, x86_l_17f6);
x86_l_184f:
	/* 0x184f: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1851:
	/* 0x1851: jns    19ae <filter_char_substring+0x20f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x1851, 0x19ae, x86_l_19ae);
x86_l_1857:
	/* 0x1857: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_185c:
	/* 0x185c: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1860:
	/* 0x1860: jae    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1860, 0x199d, x86_l_199d);
x86_l_1866:
	/* 0x1866: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_186a:
	/* 0x186a: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_186d:
	/* 0x186d: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_1871:
	/* 0x1871: jne    17cc <filter_char_substring+0x2d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1871, 0x17cc, x86_l_17cc);
x86_l_1877:
	/* 0x1877: jmp    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JMP(0x1877, 0x199d, x86_l_199d);
x86_l_187c:
	/* 0x187c: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_187e:
	/* 0x187e: je     195c <filter_char_substring+0x1bd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x187e, 0x195c, x86_l_195c);
x86_l_1884:
	/* 0x1884: lea    r13,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1889:
	/* 0x1889: xor    ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_188b:
	/* 0x188b: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_188e:
	/* 0x188e: mov    eax,DWORD PTR [r14+rbx*4+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 2), 16ULL);
x86_l_1893:
	/* 0x1893: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1897:
	/* 0x1897: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_189c:
	/* 0x189c: mov    rdi,QWORD PTR [rip+0x2b61] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_18a3:
	/* 0x18a3: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_18a6:
	/* 0x18a6: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18a8:
	/* 0x18a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18ab:
	/* 0x18ab: je     199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18ab, 0x199d, x86_l_199d);
x86_l_18b1:
	/* 0x18b1: mov    rdx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_18b4:
	/* 0x18b4: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18b6:
	/* 0x18b6: jmp    18c3 <filter_char_substring+0x124> */
	X86_SIM_X86_SUB_JMP(0x18b6, 0x18c3, x86_l_18c3);
x86_l_18b8:
	/* 0x18b8: inc    rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_18bb:
	/* 0x18bb: inc    rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_18be:
	/* 0x18be: cmp    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_18c1:
	/* 0x18c1: je     18f4 <filter_char_substring+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18c1, 0x18f4, x86_l_18f4);
x86_l_18c3:
	/* 0x18c3: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_18c5:
	/* 0x18c5: lea    rdi,[rcx+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_18c9:
	/* 0x18c9: cmp    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_18cc:
	/* 0x18cc: jae    18b8 <filter_char_substring+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18cc, 0x18b8, x86_l_18b8);
x86_l_18ce:
	/* 0x18ce: movzx  edi,BYTE PTR [rax+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RSI, 0, X86_WIDTH_8), 0ULL);
x86_l_18d2:
	/* 0x18d2: test   dil,dil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDI, X86_RDI, X86_WIDTH_8, 0, 0);
x86_l_18d5:
	/* 0x18d5: je     18ec <filter_char_substring+0x14d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18d5, 0x18ec, x86_l_18ec);
x86_l_18d7:
	/* 0x18d7: cmp    rsi,0x62 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 98ULL);
x86_l_18db:
	/* 0x18db: ja     18b8 <filter_char_substring+0x119> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x18db, 0x18b8, x86_l_18b8);
x86_l_18dd:
	/* 0x18dd: lea    r8,[rsi+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R8, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_18e1:
	/* 0x18e1: cmp    BYTE PTR [rdx+rsi*1],dil */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_18e5:
	/* 0x18e5: mov    rsi,r8 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R8, X86_WIDTH_64, 0, 0);
x86_l_18e8:
	/* 0x18e8: je     18c5 <filter_char_substring+0x126> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x18e8, 0x18c5, x86_l_18c5);
x86_l_18ea:
	/* 0x18ea: jmp    18b8 <filter_char_substring+0x119> */
	X86_SIM_X86_SUB_JMP(0x18ea, 0x18b8, x86_l_18b8);
x86_l_18ec:
	/* 0x18ec: test   ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_18ee:
	/* 0x18ee: jns    19ae <filter_char_substring+0x20f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x18ee, 0x19ae, x86_l_19ae);
x86_l_18f4:
	/* 0x18f4: lea    eax,[r12+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_18f9:
	/* 0x18f9: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_18fd:
	/* 0x18fd: jae    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x18fd, 0x199d, x86_l_199d);
x86_l_1903:
	/* 0x1903: add    r12d,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4ULL);
x86_l_1907:
	/* 0x1907: inc    rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_190a:
	/* 0x190a: cmp    rbx,0x64 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 100ULL);
x86_l_190e:
	/* 0x190e: jne    188e <filter_char_substring+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x190e, 0x188e, x86_l_188e);
x86_l_1914:
	/* 0x1914: jmp    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JMP(0x1914, 0x199d, x86_l_199d);
x86_l_1919:
	/* 0x1919: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_191e:
	/* 0x191e: mov    r15,QWORD PTR [rip+0x2b73] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_1925:
	/* 0x1925: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_192a:
	/* 0x192a: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_192e:
	/* 0x192e: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1932:
	/* 0x1932: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1937:
	/* 0x1937: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_193a:
	/* 0x193a: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_193d:
	/* 0x193d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_193f:
	/* 0x193f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1942:
	/* 0x1942: je     199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1942, 0x199d, x86_l_199d);
x86_l_1944:
	/* 0x1944: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_1948:
	/* 0x1948: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_194b:
	/* 0x194b: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_194f:
	/* 0x194f: jae    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x194f, 0x199d, x86_l_199d);
x86_l_1951:
	/* 0x1951: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_1958:
	/* 0x1958: jne    192a <filter_char_substring+0x18b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1958, 0x192a, x86_l_192a);
x86_l_195a:
	/* 0x195a: jmp    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JMP(0x195a, 0x199d, x86_l_199d);
x86_l_195c:
	/* 0x195c: mov    ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1961:
	/* 0x1961: mov    r15,QWORD PTR [rip+0x2b75] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)substring_map));
x86_l_1968:
	/* 0x1968: lea    r12,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_196d:
	/* 0x196d: mov    eax,DWORD PTR [r14+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1971:
	/* 0x1971: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1975:
	/* 0x1975: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_197a:
	/* 0x197a: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_197d:
	/* 0x197d: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1980:
	/* 0x1980: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1982:
	/* 0x1982: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1985:
	/* 0x1985: je     199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1985, 0x199d, x86_l_199d);
x86_l_1987:
	/* 0x1987: add    rbx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4ULL);
x86_l_198b:
	/* 0x198b: lea    eax,[rbx-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_198e:
	/* 0x198e: cmp    eax,DWORD PTR [r14+0x8] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 8ULL);
x86_l_1992:
	/* 0x1992: jae    199d <filter_char_substring+0x1fe> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1992, 0x199d, x86_l_199d);
x86_l_1994:
	/* 0x1994: cmp    rbx,0x1a0 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 416ULL);
x86_l_199b:
	/* 0x199b: jne    196d <filter_char_substring+0x1ce> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x199b, 0x196d, x86_l_196d);
x86_l_199d:
	/* 0x199d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_199f:
	/* 0x199f: add    rsp,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_19a3:
	/* 0x19a3: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19a4:
	/* 0x19a4: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19a6:
	/* 0x19a6: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19a8:
	/* 0x19a8: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19aa:
	/* 0x19aa: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19ac:
	/* 0x19ac: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_19ad:
	/* 0x19ad: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_19ad);
x86_l_19ae:
	/* 0x19ae: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_19b3:
	/* 0x19b3: jmp    199f <filter_char_substring+0x200> */
	X86_SIM_X86_SUB_JMP(0x19b3, 0x199f, x86_l_199f);

	/* native subroutine native_link_sub_19b5 */
x86_l_19b5:
	/* 0x19b5: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19b8:
	/* 0x19b8: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_19bd:
	/* 0x19bd: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_19c1:
	/* 0x19c1: ja     1a34 <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x19c1, 0x1a34, x86_l_1a34);
x86_l_19c3:
	/* 0x19c3: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_19cd:
	/* 0x19cd: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_19d1:
	/* 0x19d1: jae    19d4 <filter_16ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x19d1, 0x19d4, x86_l_19d4);
x86_l_19d3:
	/* 0x19d3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_19d3);
x86_l_19d4:
	/* 0x19d4: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_19d9:
	/* 0x19d9: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_19dd:
	/* 0x19dd: jae    19f4 <filter_16ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x19dd, 0x19f4, x86_l_19f4);
x86_l_19df:
	/* 0x19df: movzx  edx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_19e2:
	/* 0x19e2: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19e5:
	/* 0x19e5: jne    1b0a <filter_16ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x19e5, 0x1b0a, x86_l_1b0a);
x86_l_19eb:
	/* 0x19eb: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_19ed:
	/* 0x19ed: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_19f0:
	/* 0x19f0: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_19f3:
	/* 0x19f3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_19d3);
x86_l_19f4:
	/* 0x19f4: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_19f8:
	/* 0x19f8: jne    1a34 <filter_16ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x19f8, 0x1a34, x86_l_1a34);
x86_l_19fa:
	/* 0x19fa: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_19fd:
	/* 0x19fd: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1a00:
	/* 0x1a00: jne    19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a00, 0x19d3, x86_l_19d3);
x86_l_1a02:
	/* 0x1a02: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a05:
	/* 0x1a05: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a08:
	/* 0x1a08: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a08, 0x1bcc, x86_l_1bcc);
x86_l_1a0e:
	/* 0x1a0e: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1a11:
	/* 0x1a11: jne    19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a11, 0x19d3, x86_l_19d3);
x86_l_1a13:
	/* 0x1a13: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a16:
	/* 0x1a16: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a16, 0x1bcc, x86_l_1bcc);
x86_l_1a1c:
	/* 0x1a1c: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1a1f:
	/* 0x1a1f: jne    19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a1f, 0x19d3, x86_l_19d3);
x86_l_1a21:
	/* 0x1a21: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a24:
	/* 0x1a24: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a24, 0x1bcc, x86_l_1bcc);
x86_l_1a2a:
	/* 0x1a2a: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1a2d:
	/* 0x1a2d: jne    19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a2d, 0x19d3, x86_l_19d3);
x86_l_1a2f:
	/* 0x1a2f: jmp    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1a2f, 0x1bcc, x86_l_1bcc);
x86_l_1a34:
	/* 0x1a34: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1a37:
	/* 0x1a37: je     1aa6 <filter_16ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1a37, 0x1aa6, x86_l_1aa6);
x86_l_1a39:
	/* 0x1a39: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1a3c:
	/* 0x1a3c: jne    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1a3c, 0x1bcc, x86_l_1bcc);
x86_l_1a42:
	/* 0x1a42: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1a45:
	/* 0x1a45: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1a48:
	/* 0x1a48: ja     1b93 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1a48, 0x1b93, x86_l_1b93);
x86_l_1a4e:
	/* 0x1a4e: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1a53:
	/* 0x1a53: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1a56:
	/* 0x1a56: jae    1b93 <filter_16ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1a56, 0x1b93, x86_l_1b93);
x86_l_1a5c:
	/* 0x1a5c: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1a5f:
	/* 0x1a5f: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a62:
	/* 0x1a62: jg     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a62, 0x19d3, x86_l_19d3);
x86_l_1a68:
	/* 0x1a68: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a6b:
	/* 0x1a6b: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1a6e:
	/* 0x1a6e: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a6e, 0x1bcc, x86_l_1bcc);
x86_l_1a74:
	/* 0x1a74: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1a77:
	/* 0x1a77: jg     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a77, 0x19d3, x86_l_19d3);
x86_l_1a7d:
	/* 0x1a7d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1a80:
	/* 0x1a80: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a80, 0x1bcc, x86_l_1bcc);
x86_l_1a86:
	/* 0x1a86: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1a89:
	/* 0x1a89: jg     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a89, 0x19d3, x86_l_19d3);
x86_l_1a8f:
	/* 0x1a8f: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1a92:
	/* 0x1a92: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1a92, 0x1bcc, x86_l_1bcc);
x86_l_1a98:
	/* 0x1a98: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1a9b:
	/* 0x1a9b: jg     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1a9b, 0x19d3, x86_l_19d3);
x86_l_1aa1:
	/* 0x1aa1: jmp    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1aa1, 0x1bcc, x86_l_1bcc);
x86_l_1aa6:
	/* 0x1aa6: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1aa9:
	/* 0x1aa9: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1aac:
	/* 0x1aac: ja     1b58 <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1aac, 0x1b58, x86_l_1b58);
x86_l_1ab2:
	/* 0x1ab2: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1ab7:
	/* 0x1ab7: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1aba:
	/* 0x1aba: jae    1b58 <filter_16ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1aba, 0x1b58, x86_l_1b58);
x86_l_1ac0:
	/* 0x1ac0: movsx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1ac3:
	/* 0x1ac3: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ac6:
	/* 0x1ac6: jl     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1ac6, 0x19d3, x86_l_19d3);
x86_l_1acc:
	/* 0x1acc: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1acf:
	/* 0x1acf: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ad2:
	/* 0x1ad2: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ad2, 0x1bcc, x86_l_1bcc);
x86_l_1ad8:
	/* 0x1ad8: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1adb:
	/* 0x1adb: jl     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1adb, 0x19d3, x86_l_19d3);
x86_l_1ae1:
	/* 0x1ae1: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ae4:
	/* 0x1ae4: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ae4, 0x1bcc, x86_l_1bcc);
x86_l_1aea:
	/* 0x1aea: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1aed:
	/* 0x1aed: jl     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1aed, 0x19d3, x86_l_19d3);
x86_l_1af3:
	/* 0x1af3: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1af6:
	/* 0x1af6: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1af6, 0x1bcc, x86_l_1bcc);
x86_l_1afc:
	/* 0x1afc: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1aff:
	/* 0x1aff: jl     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1aff, 0x19d3, x86_l_19d3);
x86_l_1b05:
	/* 0x1b05: jmp    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1b05, 0x1bcc, x86_l_1bcc);
x86_l_1b0a:
	/* 0x1b0a: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b0d:
	/* 0x1b0d: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1b10:
	/* 0x1b10: jb     1b37 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b10, 0x1b37, x86_l_1b37);
x86_l_1b12:
	/* 0x1b12: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b15:
	/* 0x1b15: je     19eb <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1b15, 0x19eb, x86_l_19eb);
x86_l_1b1b:
	/* 0x1b1b: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1b1e:
	/* 0x1b1e: jb     1b37 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b1e, 0x1b37, x86_l_1b37);
x86_l_1b20:
	/* 0x1b20: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b23:
	/* 0x1b23: je     19eb <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1b23, 0x19eb, x86_l_19eb);
x86_l_1b29:
	/* 0x1b29: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1b2c:
	/* 0x1b2c: jb     1b37 <filter_16ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b2c, 0x1b37, x86_l_1b37);
x86_l_1b2e:
	/* 0x1b2e: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b31:
	/* 0x1b31: je     19eb <filter_16ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1b31, 0x19eb, x86_l_19eb);
x86_l_1b37:
	/* 0x1b37: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1b3a:
	/* 0x1b3a: ja     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1b3a, 0x1bcc, x86_l_1bcc);
x86_l_1b40:
	/* 0x1b40: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1b42:
	/* 0x1b42: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1b4c:
	/* 0x1b4c: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b50:
	/* 0x1b50: jb     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b50, 0x19d3, x86_l_19d3);
x86_l_1b56:
	/* 0x1b56: jmp    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1b56, 0x1bcc, x86_l_1bcc);
x86_l_1b58:
	/* 0x1b58: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b5b:
	/* 0x1b5b: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b5e:
	/* 0x1b5e: jb     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b5e, 0x19d3, x86_l_19d3);
x86_l_1b64:
	/* 0x1b64: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b67:
	/* 0x1b67: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1b6a:
	/* 0x1b6a: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b6a, 0x1bcc, x86_l_1bcc);
x86_l_1b6c:
	/* 0x1b6c: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1b6f:
	/* 0x1b6f: jb     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b6f, 0x19d3, x86_l_19d3);
x86_l_1b75:
	/* 0x1b75: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1b78:
	/* 0x1b78: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b78, 0x1bcc, x86_l_1bcc);
x86_l_1b7a:
	/* 0x1b7a: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1b7d:
	/* 0x1b7d: jb     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b7d, 0x19d3, x86_l_19d3);
x86_l_1b83:
	/* 0x1b83: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1b86:
	/* 0x1b86: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b86, 0x1bcc, x86_l_1bcc);
x86_l_1b88:
	/* 0x1b88: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1b8b:
	/* 0x1b8b: jb     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1b8b, 0x19d3, x86_l_19d3);
x86_l_1b91:
	/* 0x1b91: jmp    1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x1b91, 0x1bcc, x86_l_1bcc);
x86_l_1b93:
	/* 0x1b93: movzx  ecx,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1b96:
	/* 0x1b96: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b99:
	/* 0x1b99: ja     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1b99, 0x19d3, x86_l_19d3);
x86_l_1b9f:
	/* 0x1b9f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ba2:
	/* 0x1ba2: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ba5:
	/* 0x1ba5: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ba5, 0x1bcc, x86_l_1bcc);
x86_l_1ba7:
	/* 0x1ba7: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1baa:
	/* 0x1baa: ja     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1baa, 0x19d3, x86_l_19d3);
x86_l_1bb0:
	/* 0x1bb0: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1bb3:
	/* 0x1bb3: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bb3, 0x1bcc, x86_l_1bcc);
x86_l_1bb5:
	/* 0x1bb5: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1bb8:
	/* 0x1bb8: ja     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bb8, 0x19d3, x86_l_19d3);
x86_l_1bbe:
	/* 0x1bbe: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1bc1:
	/* 0x1bc1: jb     1bcc <filter_16ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1bc1, 0x1bcc, x86_l_1bcc);
x86_l_1bc3:
	/* 0x1bc3: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1bc6:
	/* 0x1bc6: ja     19d3 <filter_16ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bc6, 0x19d3, x86_l_19d3);
x86_l_1bcc:
	/* 0x1bcc: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1bce:
	/* 0x1bce: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_19d3);

	/* native subroutine native_link_sub_1bcf */
x86_l_1bcf:
	/* 0x1bcf: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bd2:
	/* 0x1bd2: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1bd5:
	/* 0x1bd5: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1bd8:
	/* 0x1bd8: ja     1cbf <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1bd8, 0x1cbf, x86_l_1cbf);
x86_l_1bde:
	/* 0x1bde: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1be3:
	/* 0x1be3: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1be6:
	/* 0x1be6: jae    1cbf <filter_16ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1be6, 0x1cbf, x86_l_1cbf);
x86_l_1bec:
	/* 0x1bec: movsx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1bef:
	/* 0x1bef: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1bf2:
	/* 0x1bf2: jne    1c5a <filter_16ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1bf2, 0x1c5a, x86_l_1c5a);
x86_l_1bf4:
	/* 0x1bf4: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1bf9:
	/* 0x1bf9: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bfc:
	/* 0x1bfc: jg     1c07 <filter_16ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1bfc, 0x1c07, x86_l_1c07);
x86_l_1bfe:
	/* 0x1bfe: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1c01:
	/* 0x1c01: jge    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1c01, 0x1cd6, x86_l_1cd6);
x86_l_1c07:
	/* 0x1c07: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0a:
	/* 0x1c0a: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1c0d:
	/* 0x1c0d: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c0d, 0x1d76, x86_l_1d76);
x86_l_1c13:
	/* 0x1c13: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c16:
	/* 0x1c16: jg     1c21 <filter_16ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1c16, 0x1c21, x86_l_1c21);
x86_l_1c18:
	/* 0x1c18: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c1b:
	/* 0x1c1b: jge    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1c1b, 0x1cd6, x86_l_1cd6);
x86_l_1c21:
	/* 0x1c21: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1c24:
	/* 0x1c24: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c24, 0x1d76, x86_l_1d76);
x86_l_1c2a:
	/* 0x1c2a: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c2d:
	/* 0x1c2d: jg     1c38 <filter_16ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1c2d, 0x1c38, x86_l_1c38);
x86_l_1c2f:
	/* 0x1c2f: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c32:
	/* 0x1c32: jge    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1c32, 0x1cd6, x86_l_1cd6);
x86_l_1c38:
	/* 0x1c38: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1c3b:
	/* 0x1c3b: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c3b, 0x1d76, x86_l_1d76);
x86_l_1c41:
	/* 0x1c41: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c43:
	/* 0x1c43: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1c46:
	/* 0x1c46: jg     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1c46, 0x1d78, x86_l_1d78);
x86_l_1c4c:
	/* 0x1c4c: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1c4f:
	/* 0x1c4f: jge    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x1c4f, 0x1cd6, x86_l_1cd6);
x86_l_1c55:
	/* 0x1c55: jmp    1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1c55, 0x1d78, x86_l_1d78);
x86_l_1c5a:
	/* 0x1c5a: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c5d:
	/* 0x1c5d: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c60:
	/* 0x1c60: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1c64:
	/* 0x1c64: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1c67:
	/* 0x1c67: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1c6a:
	/* 0x1c6a: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c6d:
	/* 0x1c6d: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1c70:
	/* 0x1c70: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c70, 0x1d78, x86_l_1d78);
x86_l_1c76:
	/* 0x1c76: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c79:
	/* 0x1c79: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1c7d:
	/* 0x1c7d: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1c80:
	/* 0x1c80: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1c84:
	/* 0x1c84: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1c87:
	/* 0x1c87: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1c8a:
	/* 0x1c8a: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1c8d:
	/* 0x1c8d: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1c8d, 0x1d78, x86_l_1d78);
x86_l_1c93:
	/* 0x1c93: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c96:
	/* 0x1c96: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1c9a:
	/* 0x1c9a: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1c9d:
	/* 0x1c9d: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1ca1:
	/* 0x1ca1: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1ca4:
	/* 0x1ca4: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1ca7:
	/* 0x1ca7: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1caa:
	/* 0x1caa: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1caa, 0x1d78, x86_l_1d78);
x86_l_1cb0:
	/* 0x1cb0: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1cb3:
	/* 0x1cb3: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_1cb6:
	/* 0x1cb6: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1cb9:
	/* 0x1cb9: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_1cbd:
	/* 0x1cbd: jmp    1d32 <filter_16ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x1cbd, 0x1d32, x86_l_1d32);
x86_l_1cbf:
	/* 0x1cbf: movzx  esi,WORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1cc2:
	/* 0x1cc2: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_1cc5:
	/* 0x1cc5: jne    1cd7 <filter_16ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1cc5, 0x1cd7, x86_l_1cd7);
x86_l_1cc7:
	/* 0x1cc7: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ccc:
	/* 0x1ccc: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ccf:
	/* 0x1ccf: ja     1d3a <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ccf, 0x1d3a, x86_l_1d3a);
x86_l_1cd1:
	/* 0x1cd1: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1cd4:
	/* 0x1cd4: jb     1d3a <filter_16ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cd4, 0x1d3a, x86_l_1d3a);
x86_l_1cd6:
	/* 0x1cd6: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cd6);
x86_l_1cd7:
	/* 0x1cd7: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cda:
	/* 0x1cda: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cdd:
	/* 0x1cdd: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1ce1:
	/* 0x1ce1: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_1ce4:
	/* 0x1ce4: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1ce7:
	/* 0x1ce7: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1cea:
	/* 0x1cea: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ced:
	/* 0x1ced: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ced, 0x1d78, x86_l_1d78);
x86_l_1cf3:
	/* 0x1cf3: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1cf6:
	/* 0x1cf6: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1cfa:
	/* 0x1cfa: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1cfd:
	/* 0x1cfd: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1d01:
	/* 0x1d01: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1d04:
	/* 0x1d04: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1d07:
	/* 0x1d07: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1d0a:
	/* 0x1d0a: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d0a, 0x1d78, x86_l_1d78);
x86_l_1d0c:
	/* 0x1d0c: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d0f:
	/* 0x1d0f: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1d13:
	/* 0x1d13: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d16:
	/* 0x1d16: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1d1a:
	/* 0x1d1a: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1d1d:
	/* 0x1d1d: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1d20:
	/* 0x1d20: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1d23:
	/* 0x1d23: jb     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d23, 0x1d78, x86_l_1d78);
x86_l_1d25:
	/* 0x1d25: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d28:
	/* 0x1d28: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_1d2b:
	/* 0x1d2b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1d2e:
	/* 0x1d2e: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1d32:
	/* 0x1d32: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1d35:
	/* 0x1d35: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_1d38:
	/* 0x1d38: jmp    1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1d38, 0x1d78, x86_l_1d78);
x86_l_1d3a:
	/* 0x1d3a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d3d:
	/* 0x1d3d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1d40:
	/* 0x1d40: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d40, 0x1d76, x86_l_1d76);
x86_l_1d42:
	/* 0x1d42: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1d45:
	/* 0x1d45: ja     1d4c <filter_16ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d45, 0x1d4c, x86_l_1d4c);
x86_l_1d47:
	/* 0x1d47: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_1d4a:
	/* 0x1d4a: jae    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d4a, 0x1cd6, x86_l_1cd6);
x86_l_1d4c:
	/* 0x1d4c: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_1d4f:
	/* 0x1d4f: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d4f, 0x1d76, x86_l_1d76);
x86_l_1d51:
	/* 0x1d51: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d54:
	/* 0x1d54: ja     1d5f <filter_16ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d54, 0x1d5f, x86_l_1d5f);
x86_l_1d56:
	/* 0x1d56: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_1d59:
	/* 0x1d59: jae    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d59, 0x1cd6, x86_l_1cd6);
x86_l_1d5f:
	/* 0x1d5f: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_1d62:
	/* 0x1d62: jb     1d76 <filter_16ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d62, 0x1d76, x86_l_1d76);
x86_l_1d64:
	/* 0x1d64: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d66:
	/* 0x1d66: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d69:
	/* 0x1d69: ja     1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d69, 0x1d78, x86_l_1d78);
x86_l_1d6b:
	/* 0x1d6b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1d6e:
	/* 0x1d6e: jae    1cd6 <filter_16ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1d6e, 0x1cd6, x86_l_1cd6);
x86_l_1d74:
	/* 0x1d74: jmp    1d78 <filter_16ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x1d74, 0x1d78, x86_l_1d78);
x86_l_1d76:
	/* 0x1d76: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d78:
	/* 0x1d78: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_1d7b:
	/* 0x1d7b: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1d7e:
	/* 0x1d7e: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1d81:
	/* 0x1d81: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_1d83:
	/* 0x1d83: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1d86:
	/* 0x1d86: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1cd6);

	/* native subroutine native_link_sub_1d87 */
x86_l_1d87:
	/* 0x1d87: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1d89:
	/* 0x1d89: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1d8a:
	/* 0x1d8a: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1d8e:
	/* 0x1d8e: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_1d91:
	/* 0x1d91: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_1d94:
	/* 0x1d94: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1d98:
	/* 0x1d98: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1d9c:
	/* 0x1d9c: mov    rdi,QWORD PTR [rip+0x1640] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_1da3:
	/* 0x1da3: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1da8:
	/* 0x1da8: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1dad:
	/* 0x1dad: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1daf:
	/* 0x1daf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1db2:
	/* 0x1db2: je     1de8 <filter_16ty_map+0x61> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1db2, 0x1de8, x86_l_1de8);
x86_l_1db4:
	/* 0x1db4: movzx  ecx,WORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1db8:
	/* 0x1db8: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dbd:
	/* 0x1dbd: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dc2:
	/* 0x1dc2: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1dc7:
	/* 0x1dc7: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dca:
	/* 0x1dca: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1dcc:
	/* 0x1dcc: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1dcf:
	/* 0x1dcf: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dd1:
	/* 0x1dd1: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_1dd4:
	/* 0x1dd4: ja     1e02 <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1dd4, 0x1e02, x86_l_1e02);
x86_l_1dd6:
	/* 0x1dd6: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_1ddb:
	/* 0x1ddb: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1dde:
	/* 0x1dde: jae    1df2 <filter_16ty_map+0x6b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1dde, 0x1df2, x86_l_1df2);
x86_l_1de0:
	/* 0x1de0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1de3:
	/* 0x1de3: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_1de6:
	/* 0x1de6: jmp    1e02 <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_JMP(0x1de6, 0x1e02, x86_l_1e02);
x86_l_1de8:
	/* 0x1de8: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dea:
	/* 0x1dea: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1dee:
	/* 0x1dee: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1def:
	/* 0x1def: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1df1:
	/* 0x1df1: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1df1);
x86_l_1df2:
	/* 0x1df2: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_1df7:
	/* 0x1df7: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1dfa:
	/* 0x1dfa: jae    1e02 <filter_16ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1dfa, 0x1e02, x86_l_1e02);
x86_l_1dfc:
	/* 0x1dfc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dff:
	/* 0x1dff: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1e02:
	/* 0x1e02: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1e05:
	/* 0x1e05: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1e09:
	/* 0x1e09: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e0a:
	/* 0x1e0a: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1e0c:
	/* 0x1e0c: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1df1);

	/* native subroutine native_link_sub_1e0d */
x86_l_1e0d:
	/* 0x1e0d: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1e10:
	/* 0x1e10: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1e15:
	/* 0x1e15: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_1e19:
	/* 0x1e19: ja     1e8a <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e19, 0x1e8a, x86_l_1e8a);
x86_l_1e1b:
	/* 0x1e1b: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_1e25:
	/* 0x1e25: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e29:
	/* 0x1e29: jae    1e2c <filter_32ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1e29, 0x1e2c, x86_l_1e2c);
x86_l_1e2b:
	/* 0x1e2b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1e2b);
x86_l_1e2c:
	/* 0x1e2c: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_1e31:
	/* 0x1e31: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1e35:
	/* 0x1e35: jae    1e4b <filter_32ty_selector_val+0x3e> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1e35, 0x1e4b, x86_l_1e4b);
x86_l_1e37:
	/* 0x1e37: mov    edx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e39:
	/* 0x1e39: cmp    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1e3c:
	/* 0x1e3c: jne    1f5e <filter_32ty_selector_val+0x151> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e3c, 0x1f5e, x86_l_1f5e);
x86_l_1e42:
	/* 0x1e42: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e44:
	/* 0x1e44: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1e47:
	/* 0x1e47: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_1e4a:
	/* 0x1e4a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1e2b);
x86_l_1e4b:
	/* 0x1e4b: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_1e4f:
	/* 0x1e4f: jne    1e8a <filter_32ty_selector_val+0x7d> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e4f, 0x1e8a, x86_l_1e8a);
x86_l_1e51:
	/* 0x1e51: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e53:
	/* 0x1e53: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_1e56:
	/* 0x1e56: jne    1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e56, 0x1e2b, x86_l_1e2b);
x86_l_1e58:
	/* 0x1e58: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e5b:
	/* 0x1e5b: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e5e:
	/* 0x1e5e: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e5e, 0x201e, x86_l_201e);
x86_l_1e64:
	/* 0x1e64: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_1e67:
	/* 0x1e67: jne    1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e67, 0x1e2b, x86_l_1e2b);
x86_l_1e69:
	/* 0x1e69: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1e6c:
	/* 0x1e6c: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e6c, 0x201e, x86_l_201e);
x86_l_1e72:
	/* 0x1e72: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_1e75:
	/* 0x1e75: jne    1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e75, 0x1e2b, x86_l_1e2b);
x86_l_1e77:
	/* 0x1e77: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1e7a:
	/* 0x1e7a: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e7a, 0x201e, x86_l_201e);
x86_l_1e80:
	/* 0x1e80: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_1e83:
	/* 0x1e83: jne    1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e83, 0x1e2b, x86_l_1e2b);
x86_l_1e85:
	/* 0x1e85: jmp    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1e85, 0x201e, x86_l_201e);
x86_l_1e8a:
	/* 0x1e8a: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1e8d:
	/* 0x1e8d: je     1efb <filter_32ty_selector_val+0xee> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1e8d, 0x1efb, x86_l_1efb);
x86_l_1e8f:
	/* 0x1e8f: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_1e92:
	/* 0x1e92: jne    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e92, 0x201e, x86_l_201e);
x86_l_1e98:
	/* 0x1e98: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1e9b:
	/* 0x1e9b: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1e9e:
	/* 0x1e9e: ja     1fe6 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1e9e, 0x1fe6, x86_l_1fe6);
x86_l_1ea4:
	/* 0x1ea4: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1ea9:
	/* 0x1ea9: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1eac:
	/* 0x1eac: jae    1fe6 <filter_32ty_selector_val+0x1d9> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1eac, 0x1fe6, x86_l_1fe6);
x86_l_1eb2:
	/* 0x1eb2: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb4:
	/* 0x1eb4: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1eb7:
	/* 0x1eb7: jl     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1eb7, 0x1e2b, x86_l_1e2b);
x86_l_1ebd:
	/* 0x1ebd: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ec0:
	/* 0x1ec0: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ec3:
	/* 0x1ec3: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ec3, 0x201e, x86_l_201e);
x86_l_1ec9:
	/* 0x1ec9: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ecc:
	/* 0x1ecc: jl     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1ecc, 0x1e2b, x86_l_1e2b);
x86_l_1ed2:
	/* 0x1ed2: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1ed5:
	/* 0x1ed5: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ed5, 0x201e, x86_l_201e);
x86_l_1edb:
	/* 0x1edb: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1ede:
	/* 0x1ede: jl     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1ede, 0x1e2b, x86_l_1e2b);
x86_l_1ee4:
	/* 0x1ee4: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1ee7:
	/* 0x1ee7: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ee7, 0x201e, x86_l_201e);
x86_l_1eed:
	/* 0x1eed: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1ef0:
	/* 0x1ef0: jl     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x1ef0, 0x1e2b, x86_l_1e2b);
x86_l_1ef6:
	/* 0x1ef6: jmp    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1ef6, 0x201e, x86_l_201e);
x86_l_1efb:
	/* 0x1efb: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1efe:
	/* 0x1efe: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_1f01:
	/* 0x1f01: ja     1fac <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f01, 0x1fac, x86_l_1fac);
x86_l_1f07:
	/* 0x1f07: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_1f0c:
	/* 0x1f0c: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1f0f:
	/* 0x1f0f: jae    1fac <filter_32ty_selector_val+0x19f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1f0f, 0x1fac, x86_l_1fac);
x86_l_1f15:
	/* 0x1f15: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f17:
	/* 0x1f17: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1f1a:
	/* 0x1f1a: jg     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f1a, 0x1e2b, x86_l_1e2b);
x86_l_1f20:
	/* 0x1f20: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f23:
	/* 0x1f23: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1f26:
	/* 0x1f26: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f26, 0x201e, x86_l_201e);
x86_l_1f2c:
	/* 0x1f2c: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f2f:
	/* 0x1f2f: jg     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f2f, 0x1e2b, x86_l_1e2b);
x86_l_1f35:
	/* 0x1f35: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f38:
	/* 0x1f38: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f38, 0x201e, x86_l_201e);
x86_l_1f3e:
	/* 0x1f3e: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1f41:
	/* 0x1f41: jg     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f41, 0x1e2b, x86_l_1e2b);
x86_l_1f47:
	/* 0x1f47: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1f4a:
	/* 0x1f4a: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f4a, 0x201e, x86_l_201e);
x86_l_1f50:
	/* 0x1f50: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f53:
	/* 0x1f53: jg     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1f53, 0x1e2b, x86_l_1e2b);
x86_l_1f59:
	/* 0x1f59: jmp    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1f59, 0x201e, x86_l_201e);
x86_l_1f5e:
	/* 0x1f5e: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f61:
	/* 0x1f61: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1f64:
	/* 0x1f64: jb     1f8b <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f64, 0x1f8b, x86_l_1f8b);
x86_l_1f66:
	/* 0x1f66: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1f69:
	/* 0x1f69: je     1e42 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f69, 0x1e42, x86_l_1e42);
x86_l_1f6f:
	/* 0x1f6f: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1f72:
	/* 0x1f72: jb     1f8b <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f72, 0x1f8b, x86_l_1f8b);
x86_l_1f74:
	/* 0x1f74: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1f77:
	/* 0x1f77: je     1e42 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f77, 0x1e42, x86_l_1e42);
x86_l_1f7d:
	/* 0x1f7d: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1f80:
	/* 0x1f80: jb     1f8b <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f80, 0x1f8b, x86_l_1f8b);
x86_l_1f82:
	/* 0x1f82: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f85:
	/* 0x1f85: je     1e42 <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f85, 0x1e42, x86_l_1e42);
x86_l_1f8b:
	/* 0x1f8b: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_1f8e:
	/* 0x1f8e: ja     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f8e, 0x201e, x86_l_201e);
x86_l_1f94:
	/* 0x1f94: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1f96:
	/* 0x1f96: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_1fa0:
	/* 0x1fa0: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1fa4:
	/* 0x1fa4: jb     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fa4, 0x1e2b, x86_l_1e2b);
x86_l_1faa:
	/* 0x1faa: jmp    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1faa, 0x201e, x86_l_201e);
x86_l_1fac:
	/* 0x1fac: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fae:
	/* 0x1fae: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1fb1:
	/* 0x1fb1: ja     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fb1, 0x1e2b, x86_l_1e2b);
x86_l_1fb7:
	/* 0x1fb7: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1fba:
	/* 0x1fba: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1fbd:
	/* 0x1fbd: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fbd, 0x201e, x86_l_201e);
x86_l_1fbf:
	/* 0x1fbf: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1fc2:
	/* 0x1fc2: ja     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fc2, 0x1e2b, x86_l_1e2b);
x86_l_1fc8:
	/* 0x1fc8: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_1fcb:
	/* 0x1fcb: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fcb, 0x201e, x86_l_201e);
x86_l_1fcd:
	/* 0x1fcd: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1fd0:
	/* 0x1fd0: ja     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fd0, 0x1e2b, x86_l_1e2b);
x86_l_1fd6:
	/* 0x1fd6: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_1fd9:
	/* 0x1fd9: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1fd9, 0x201e, x86_l_201e);
x86_l_1fdb:
	/* 0x1fdb: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1fde:
	/* 0x1fde: ja     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fde, 0x1e2b, x86_l_1e2b);
x86_l_1fe4:
	/* 0x1fe4: jmp    201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1fe4, 0x201e, x86_l_201e);
x86_l_1fe6:
	/* 0x1fe6: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe8:
	/* 0x1fe8: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1feb:
	/* 0x1feb: jb     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1feb, 0x1e2b, x86_l_1e2b);
x86_l_1ff1:
	/* 0x1ff1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ff4:
	/* 0x1ff4: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1ff7:
	/* 0x1ff7: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ff7, 0x201e, x86_l_201e);
x86_l_1ff9:
	/* 0x1ff9: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ffc:
	/* 0x1ffc: jb     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ffc, 0x1e2b, x86_l_1e2b);
x86_l_2002:
	/* 0x2002: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2005:
	/* 0x2005: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2005, 0x201e, x86_l_201e);
x86_l_2007:
	/* 0x2007: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_200a:
	/* 0x200a: jb     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x200a, 0x1e2b, x86_l_1e2b);
x86_l_2010:
	/* 0x2010: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2013:
	/* 0x2013: jb     201e <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2013, 0x201e, x86_l_201e);
x86_l_2015:
	/* 0x2015: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_2018:
	/* 0x2018: jb     1e2b <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2018, 0x1e2b, x86_l_1e2b);
x86_l_201e:
	/* 0x201e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2020:
	/* 0x2020: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_1e2b);

	/* native subroutine native_link_sub_2021 */
x86_l_2021:
	/* 0x2021: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2024:
	/* 0x2024: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2027:
	/* 0x2027: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_202a:
	/* 0x202a: ja     2110 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x202a, 0x2110, x86_l_2110);
x86_l_2030:
	/* 0x2030: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_2035:
	/* 0x2035: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2038:
	/* 0x2038: jae    2110 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2038, 0x2110, x86_l_2110);
x86_l_203e:
	/* 0x203e: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2040:
	/* 0x2040: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2043:
	/* 0x2043: jne    20ab <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2043, 0x20ab, x86_l_20ab);
x86_l_2045:
	/* 0x2045: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_204a:
	/* 0x204a: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_204d:
	/* 0x204d: jg     2058 <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x204d, 0x2058, x86_l_2058);
x86_l_204f:
	/* 0x204f: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2052:
	/* 0x2052: jle    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x2052, 0x2126, x86_l_2126);
x86_l_2058:
	/* 0x2058: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_205b:
	/* 0x205b: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_205e:
	/* 0x205e: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x205e, 0x21c6, x86_l_21c6);
x86_l_2064:
	/* 0x2064: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2067:
	/* 0x2067: jg     2072 <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2067, 0x2072, x86_l_2072);
x86_l_2069:
	/* 0x2069: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_206c:
	/* 0x206c: jle    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x206c, 0x2126, x86_l_2126);
x86_l_2072:
	/* 0x2072: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2075:
	/* 0x2075: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2075, 0x21c6, x86_l_21c6);
x86_l_207b:
	/* 0x207b: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_207e:
	/* 0x207e: jg     2089 <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x207e, 0x2089, x86_l_2089);
x86_l_2080:
	/* 0x2080: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2083:
	/* 0x2083: jle    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x2083, 0x2126, x86_l_2126);
x86_l_2089:
	/* 0x2089: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_208c:
	/* 0x208c: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x208c, 0x21c6, x86_l_21c6);
x86_l_2092:
	/* 0x2092: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2094:
	/* 0x2094: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2097:
	/* 0x2097: jg     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2097, 0x21c8, x86_l_21c8);
x86_l_209d:
	/* 0x209d: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_20a0:
	/* 0x20a0: jle    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x20a0, 0x2126, x86_l_2126);
x86_l_20a6:
	/* 0x20a6: jmp    21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x20a6, 0x21c8, x86_l_21c8);
x86_l_20ab:
	/* 0x20ab: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20ae:
	/* 0x20ae: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20b1:
	/* 0x20b1: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20b5:
	/* 0x20b5: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_20b8:
	/* 0x20b8: setle  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20bb:
	/* 0x20bb: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_20be:
	/* 0x20be: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_20c1:
	/* 0x20c1: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20c1, 0x21c8, x86_l_21c8);
x86_l_20c7:
	/* 0x20c7: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20ca:
	/* 0x20ca: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20ce:
	/* 0x20ce: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_20d1:
	/* 0x20d1: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20d5:
	/* 0x20d5: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_20d8:
	/* 0x20d8: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_20db:
	/* 0x20db: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_20de:
	/* 0x20de: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20de, 0x21c8, x86_l_21c8);
x86_l_20e4:
	/* 0x20e4: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20e7:
	/* 0x20e7: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20eb:
	/* 0x20eb: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_20ee:
	/* 0x20ee: setle  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_20f2:
	/* 0x20f2: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_20f5:
	/* 0x20f5: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_20f8:
	/* 0x20f8: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_20fb:
	/* 0x20fb: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20fb, 0x21c8, x86_l_21c8);
x86_l_2101:
	/* 0x2101: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2104:
	/* 0x2104: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2107:
	/* 0x2107: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_210a:
	/* 0x210a: setle  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_210e:
	/* 0x210e: jmp    2182 <filter_32ty_range+0x161> */
	X86_SIM_X86_SUB_JMP(0x210e, 0x2182, x86_l_2182);
x86_l_2110:
	/* 0x2110: mov    esi,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2112:
	/* 0x2112: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2115:
	/* 0x2115: jne    2127 <filter_32ty_range+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2115, 0x2127, x86_l_2127);
x86_l_2117:
	/* 0x2117: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_211c:
	/* 0x211c: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_211f:
	/* 0x211f: ja     218a <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x211f, 0x218a, x86_l_218a);
x86_l_2121:
	/* 0x2121: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2124:
	/* 0x2124: ja     218a <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2124, 0x218a, x86_l_218a);
x86_l_2126:
	/* 0x2126: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2126);
x86_l_2127:
	/* 0x2127: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_212a:
	/* 0x212a: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_212d:
	/* 0x212d: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2131:
	/* 0x2131: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2134:
	/* 0x2134: setbe  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2137:
	/* 0x2137: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_213a:
	/* 0x213a: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_213d:
	/* 0x213d: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x213d, 0x21c8, x86_l_21c8);
x86_l_2143:
	/* 0x2143: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2146:
	/* 0x2146: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_214a:
	/* 0x214a: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_214d:
	/* 0x214d: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2151:
	/* 0x2151: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2154:
	/* 0x2154: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2157:
	/* 0x2157: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_215a:
	/* 0x215a: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x215a, 0x21c8, x86_l_21c8);
x86_l_215c:
	/* 0x215c: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_215f:
	/* 0x215f: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2163:
	/* 0x2163: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_2166:
	/* 0x2166: setbe  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_216a:
	/* 0x216a: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_216d:
	/* 0x216d: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2170:
	/* 0x2170: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2173:
	/* 0x2173: jb     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2173, 0x21c8, x86_l_21c8);
x86_l_2175:
	/* 0x2175: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2178:
	/* 0x2178: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_217b:
	/* 0x217b: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_217e:
	/* 0x217e: setbe  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2182:
	/* 0x2182: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2185:
	/* 0x2185: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2188:
	/* 0x2188: jmp    21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x2188, 0x21c8, x86_l_21c8);
x86_l_218a:
	/* 0x218a: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_218d:
	/* 0x218d: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2190:
	/* 0x2190: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2190, 0x21c6, x86_l_21c6);
x86_l_2192:
	/* 0x2192: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2195:
	/* 0x2195: ja     219c <filter_32ty_range+0x17b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2195, 0x219c, x86_l_219c);
x86_l_2197:
	/* 0x2197: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_219a:
	/* 0x219a: jbe    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x219a, 0x2126, x86_l_2126);
x86_l_219c:
	/* 0x219c: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_219f:
	/* 0x219f: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x219f, 0x21c6, x86_l_21c6);
x86_l_21a1:
	/* 0x21a1: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21a4:
	/* 0x21a4: ja     21af <filter_32ty_range+0x18e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21a4, 0x21af, x86_l_21af);
x86_l_21a6:
	/* 0x21a6: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_21a9:
	/* 0x21a9: jbe    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x21a9, 0x2126, x86_l_2126);
x86_l_21af:
	/* 0x21af: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_21b2:
	/* 0x21b2: jb     21c6 <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21b2, 0x21c6, x86_l_21c6);
x86_l_21b4:
	/* 0x21b4: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21b6:
	/* 0x21b6: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21b9:
	/* 0x21b9: ja     21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21b9, 0x21c8, x86_l_21c8);
x86_l_21bb:
	/* 0x21bb: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_21be:
	/* 0x21be: jbe    2126 <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x21be, 0x2126, x86_l_2126);
x86_l_21c4:
	/* 0x21c4: jmp    21c8 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x21c4, 0x21c8, x86_l_21c8);
x86_l_21c6:
	/* 0x21c6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_21c8:
	/* 0x21c8: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_21cb:
	/* 0x21cb: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_21ce:
	/* 0x21ce: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_21d1:
	/* 0x21d1: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_21d3:
	/* 0x21d3: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_21d6:
	/* 0x21d6: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2126);

	/* native subroutine native_link_sub_21d7 */
x86_l_21d7:
	/* 0x21d7: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_21d9:
	/* 0x21d9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_21da:
	/* 0x21da: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_21de:
	/* 0x21de: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_21e1:
	/* 0x21e1: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_21e4:
	/* 0x21e4: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_21e8:
	/* 0x21e8: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_21ec:
	/* 0x21ec: mov    rdi,QWORD PTR [rip+0x11d0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_21f3:
	/* 0x21f3: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_21f8:
	/* 0x21f8: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_21fd:
	/* 0x21fd: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21ff:
	/* 0x21ff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2202:
	/* 0x2202: je     2237 <filter_32ty_map+0x60> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2202, 0x2237, x86_l_2237);
x86_l_2204:
	/* 0x2204: mov    ecx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2207:
	/* 0x2207: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_220c:
	/* 0x220c: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2211:
	/* 0x2211: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2216:
	/* 0x2216: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2219:
	/* 0x2219: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_221b:
	/* 0x221b: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_221e:
	/* 0x221e: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2220:
	/* 0x2220: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_2223:
	/* 0x2223: ja     2251 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2223, 0x2251, x86_l_2251);
x86_l_2225:
	/* 0x2225: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_222a:
	/* 0x222a: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_222d:
	/* 0x222d: jae    2241 <filter_32ty_map+0x6a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x222d, 0x2241, x86_l_2241);
x86_l_222f:
	/* 0x222f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2232:
	/* 0x2232: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_2235:
	/* 0x2235: jmp    2251 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JMP(0x2235, 0x2251, x86_l_2251);
x86_l_2237:
	/* 0x2237: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2239:
	/* 0x2239: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_223d:
	/* 0x223d: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_223e:
	/* 0x223e: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2240:
	/* 0x2240: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2240);
x86_l_2241:
	/* 0x2241: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_2246:
	/* 0x2246: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2249:
	/* 0x2249: jae    2251 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2249, 0x2251, x86_l_2251);
x86_l_224b:
	/* 0x224b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_224e:
	/* 0x224e: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2251:
	/* 0x2251: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2254:
	/* 0x2254: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2258:
	/* 0x2258: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2259:
	/* 0x2259: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_225b:
	/* 0x225b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2240);

	/* native subroutine native_link_sub_225c */
x86_l_225c:
	/* 0x225c: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_225f:
	/* 0x225f: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2264:
	/* 0x2264: cmp    rcx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 37ULL);
x86_l_2268:
	/* 0x2268: ja     22db <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2268, 0x22db, x86_l_22db);
x86_l_226a:
	/* 0x226a: movabs rdx,0x200c000040 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280128ULL);
x86_l_2274:
	/* 0x2274: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2278:
	/* 0x2278: jae    227b <filter_8ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2278, 0x227b, x86_l_227b);
x86_l_227a:
	/* 0x227a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_227a);
x86_l_227b:
	/* 0x227b: mov    edx,0x18 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 24ULL);
x86_l_2280:
	/* 0x2280: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2284:
	/* 0x2284: jae    229b <filter_8ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2284, 0x229b, x86_l_229b);
x86_l_2286:
	/* 0x2286: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2289:
	/* 0x2289: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_228c:
	/* 0x228c: jne    23b1 <filter_8ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x228c, 0x23b1, x86_l_23b1);
x86_l_2292:
	/* 0x2292: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2294:
	/* 0x2294: cmp    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_2297:
	/* 0x2297: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_229a:
	/* 0x229a: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_227a);
x86_l_229b:
	/* 0x229b: cmp    rcx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 12ULL);
x86_l_229f:
	/* 0x229f: jne    22db <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x229f, 0x22db, x86_l_22db);
x86_l_22a1:
	/* 0x22a1: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_22a4:
	/* 0x22a4: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_22a7:
	/* 0x22a7: jne    227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22a7, 0x227a, x86_l_227a);
x86_l_22a9:
	/* 0x22a9: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22ac:
	/* 0x22ac: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_22af:
	/* 0x22af: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22af, 0x2473, x86_l_2473);
x86_l_22b5:
	/* 0x22b5: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_22b8:
	/* 0x22b8: jne    227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22b8, 0x227a, x86_l_227a);
x86_l_22ba:
	/* 0x22ba: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_22bd:
	/* 0x22bd: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22bd, 0x2473, x86_l_2473);
x86_l_22c3:
	/* 0x22c3: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_22c6:
	/* 0x22c6: jne    227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22c6, 0x227a, x86_l_227a);
x86_l_22c8:
	/* 0x22c8: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_22cb:
	/* 0x22cb: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22cb, 0x2473, x86_l_2473);
x86_l_22d1:
	/* 0x22d1: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_22d4:
	/* 0x22d4: jne    227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22d4, 0x227a, x86_l_227a);
x86_l_22d6:
	/* 0x22d6: jmp    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x22d6, 0x2473, x86_l_2473);
x86_l_22db:
	/* 0x22db: cmp    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_22de:
	/* 0x22de: je     234d <filter_8ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x22de, 0x234d, x86_l_234d);
x86_l_22e0:
	/* 0x22e0: cmp    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_22e3:
	/* 0x22e3: jne    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22e3, 0x2473, x86_l_2473);
x86_l_22e9:
	/* 0x22e9: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_22ec:
	/* 0x22ec: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_22ef:
	/* 0x22ef: ja     243a <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x22ef, 0x243a, x86_l_243a);
x86_l_22f5:
	/* 0x22f5: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_22fa:
	/* 0x22fa: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_22fd:
	/* 0x22fd: jae    243a <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x22fd, 0x243a, x86_l_243a);
x86_l_2303:
	/* 0x2303: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2306:
	/* 0x2306: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2309:
	/* 0x2309: jg     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2309, 0x227a, x86_l_227a);
x86_l_230f:
	/* 0x230f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2312:
	/* 0x2312: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2315:
	/* 0x2315: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2315, 0x2473, x86_l_2473);
x86_l_231b:
	/* 0x231b: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_231e:
	/* 0x231e: jg     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x231e, 0x227a, x86_l_227a);
x86_l_2324:
	/* 0x2324: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2327:
	/* 0x2327: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2327, 0x2473, x86_l_2473);
x86_l_232d:
	/* 0x232d: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2330:
	/* 0x2330: jg     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2330, 0x227a, x86_l_227a);
x86_l_2336:
	/* 0x2336: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2339:
	/* 0x2339: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2339, 0x2473, x86_l_2473);
x86_l_233f:
	/* 0x233f: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2342:
	/* 0x2342: jg     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2342, 0x227a, x86_l_227a);
x86_l_2348:
	/* 0x2348: jmp    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2348, 0x2473, x86_l_2473);
x86_l_234d:
	/* 0x234d: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2350:
	/* 0x2350: cmp    ecx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_2353:
	/* 0x2353: ja     23ff <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2353, 0x23ff, x86_l_23ff);
x86_l_2359:
	/* 0x2359: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_235e:
	/* 0x235e: bt     edx,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2361:
	/* 0x2361: jae    23ff <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2361, 0x23ff, x86_l_23ff);
x86_l_2367:
	/* 0x2367: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_236a:
	/* 0x236a: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_236d:
	/* 0x236d: jl     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x236d, 0x227a, x86_l_227a);
x86_l_2373:
	/* 0x2373: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2376:
	/* 0x2376: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2379:
	/* 0x2379: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2379, 0x2473, x86_l_2473);
x86_l_237f:
	/* 0x237f: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2382:
	/* 0x2382: jl     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2382, 0x227a, x86_l_227a);
x86_l_2388:
	/* 0x2388: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_238b:
	/* 0x238b: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x238b, 0x2473, x86_l_2473);
x86_l_2391:
	/* 0x2391: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2394:
	/* 0x2394: jl     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x2394, 0x227a, x86_l_227a);
x86_l_239a:
	/* 0x239a: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_239d:
	/* 0x239d: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x239d, 0x2473, x86_l_2473);
x86_l_23a3:
	/* 0x23a3: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23a6:
	/* 0x23a6: jl     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x23a6, 0x227a, x86_l_227a);
x86_l_23ac:
	/* 0x23ac: jmp    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x23ac, 0x2473, x86_l_2473);
x86_l_23b1:
	/* 0x23b1: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23b4:
	/* 0x23b4: cmp    esi,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_23b7:
	/* 0x23b7: jb     23de <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23b7, 0x23de, x86_l_23de);
x86_l_23b9:
	/* 0x23b9: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_23bc:
	/* 0x23bc: je     2292 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23bc, 0x2292, x86_l_2292);
x86_l_23c2:
	/* 0x23c2: cmp    esi,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_23c5:
	/* 0x23c5: jb     23de <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23c5, 0x23de, x86_l_23de);
x86_l_23c7:
	/* 0x23c7: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_23ca:
	/* 0x23ca: je     2292 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23ca, 0x2292, x86_l_2292);
x86_l_23d0:
	/* 0x23d0: cmp    esi,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_23d3:
	/* 0x23d3: jb     23de <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23d3, 0x23de, x86_l_23de);
x86_l_23d5:
	/* 0x23d5: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_23d8:
	/* 0x23d8: je     2292 <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23d8, 0x2292, x86_l_2292);
x86_l_23de:
	/* 0x23de: cmp    ecx,0x25 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 37ULL);
x86_l_23e1:
	/* 0x23e1: ja     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x23e1, 0x2473, x86_l_2473);
x86_l_23e7:
	/* 0x23e7: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_23e9:
	/* 0x23e9: movabs rdx,0x200c000050 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 137640280144ULL);
x86_l_23f3:
	/* 0x23f3: bt     rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_23f7:
	/* 0x23f7: jb     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x23f7, 0x227a, x86_l_227a);
x86_l_23fd:
	/* 0x23fd: jmp    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x23fd, 0x2473, x86_l_2473);
x86_l_23ff:
	/* 0x23ff: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2402:
	/* 0x2402: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2405:
	/* 0x2405: jb     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2405, 0x227a, x86_l_227a);
x86_l_240b:
	/* 0x240b: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_240e:
	/* 0x240e: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_2411:
	/* 0x2411: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2411, 0x2473, x86_l_2473);
x86_l_2413:
	/* 0x2413: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2416:
	/* 0x2416: jb     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2416, 0x227a, x86_l_227a);
x86_l_241c:
	/* 0x241c: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_241f:
	/* 0x241f: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x241f, 0x2473, x86_l_2473);
x86_l_2421:
	/* 0x2421: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2424:
	/* 0x2424: jb     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2424, 0x227a, x86_l_227a);
x86_l_242a:
	/* 0x242a: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_242d:
	/* 0x242d: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x242d, 0x2473, x86_l_2473);
x86_l_242f:
	/* 0x242f: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2432:
	/* 0x2432: jb     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2432, 0x227a, x86_l_227a);
x86_l_2438:
	/* 0x2438: jmp    2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2438, 0x2473, x86_l_2473);
x86_l_243a:
	/* 0x243a: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_243d:
	/* 0x243d: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2440:
	/* 0x2440: ja     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2440, 0x227a, x86_l_227a);
x86_l_2446:
	/* 0x2446: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2449:
	/* 0x2449: cmp    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_244c:
	/* 0x244c: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x244c, 0x2473, x86_l_2473);
x86_l_244e:
	/* 0x244e: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2451:
	/* 0x2451: ja     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2451, 0x227a, x86_l_227a);
x86_l_2457:
	/* 0x2457: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_245a:
	/* 0x245a: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x245a, 0x2473, x86_l_2473);
x86_l_245c:
	/* 0x245c: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_245f:
	/* 0x245f: ja     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x245f, 0x227a, x86_l_227a);
x86_l_2465:
	/* 0x2465: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_2468:
	/* 0x2468: jb     2473 <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2468, 0x2473, x86_l_2473);
x86_l_246a:
	/* 0x246a: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_246d:
	/* 0x246d: ja     227a <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x246d, 0x227a, x86_l_227a);
x86_l_2473:
	/* 0x2473: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2475:
	/* 0x2475: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_227a);

	/* native subroutine native_link_sub_2476 */
x86_l_2476:
	/* 0x2476: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2479:
	/* 0x2479: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_247c:
	/* 0x247c: cmp    eax,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_247f:
	/* 0x247f: ja     2566 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x247f, 0x2566, x86_l_2566);
x86_l_2485:
	/* 0x2485: mov    edx,0x1402 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 5122ULL);
x86_l_248a:
	/* 0x248a: bt     edx,eax */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_248d:
	/* 0x248d: jae    2566 <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x248d, 0x2566, x86_l_2566);
x86_l_2493:
	/* 0x2493: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2496:
	/* 0x2496: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_2499:
	/* 0x2499: jne    2501 <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2499, 0x2501, x86_l_2501);
x86_l_249b:
	/* 0x249b: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_24a0:
	/* 0x24a0: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a3:
	/* 0x24a3: jg     24ae <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x24a3, 0x24ae, x86_l_24ae);
x86_l_24a5:
	/* 0x24a5: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24a8:
	/* 0x24a8: jge    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x24a8, 0x257d, x86_l_257d);
x86_l_24ae:
	/* 0x24ae: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24b1:
	/* 0x24b1: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_24b4:
	/* 0x24b4: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24b4, 0x261d, x86_l_261d);
x86_l_24ba:
	/* 0x24ba: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24bd:
	/* 0x24bd: jg     24c8 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x24bd, 0x24c8, x86_l_24c8);
x86_l_24bf:
	/* 0x24bf: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24c2:
	/* 0x24c2: jge    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x24c2, 0x257d, x86_l_257d);
x86_l_24c8:
	/* 0x24c8: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_24cb:
	/* 0x24cb: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24cb, 0x261d, x86_l_261d);
x86_l_24d1:
	/* 0x24d1: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_24d4:
	/* 0x24d4: jg     24df <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x24d4, 0x24df, x86_l_24df);
x86_l_24d6:
	/* 0x24d6: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_24d9:
	/* 0x24d9: jge    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x24d9, 0x257d, x86_l_257d);
x86_l_24df:
	/* 0x24df: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_24e2:
	/* 0x24e2: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24e2, 0x261d, x86_l_261d);
x86_l_24e8:
	/* 0x24e8: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_24ea:
	/* 0x24ea: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_24ed:
	/* 0x24ed: jg     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x24ed, 0x261f, x86_l_261f);
x86_l_24f3:
	/* 0x24f3: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_24f6:
	/* 0x24f6: jge    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x24f6, 0x257d, x86_l_257d);
x86_l_24fc:
	/* 0x24fc: jmp    261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x24fc, 0x261f, x86_l_261f);
x86_l_2501:
	/* 0x2501: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2504:
	/* 0x2504: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2507:
	/* 0x2507: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_250b:
	/* 0x250b: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_250e:
	/* 0x250e: setge  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2511:
	/* 0x2511: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2514:
	/* 0x2514: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2517:
	/* 0x2517: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2517, 0x261f, x86_l_261f);
x86_l_251d:
	/* 0x251d: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2520:
	/* 0x2520: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2524:
	/* 0x2524: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2527:
	/* 0x2527: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_252b:
	/* 0x252b: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_252e:
	/* 0x252e: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_2531:
	/* 0x2531: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_2534:
	/* 0x2534: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2534, 0x261f, x86_l_261f);
x86_l_253a:
	/* 0x253a: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_253d:
	/* 0x253d: setle  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_2541:
	/* 0x2541: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2544:
	/* 0x2544: setge  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2548:
	/* 0x2548: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_254b:
	/* 0x254b: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_254e:
	/* 0x254e: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2551:
	/* 0x2551: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2551, 0x261f, x86_l_261f);
x86_l_2557:
	/* 0x2557: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_255a:
	/* 0x255a: setle  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_LE, 0);
x86_l_255d:
	/* 0x255d: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2560:
	/* 0x2560: setge  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_GE, 0);
x86_l_2564:
	/* 0x2564: jmp    25d9 <filter_8ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x2564, 0x25d9, x86_l_25d9);
x86_l_2566:
	/* 0x2566: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2569:
	/* 0x2569: cmp    ecx,0x1f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 31ULL);
x86_l_256c:
	/* 0x256c: jne    257e <filter_8ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x256c, 0x257e, x86_l_257e);
x86_l_256e:
	/* 0x256e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2573:
	/* 0x2573: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2576:
	/* 0x2576: ja     25e1 <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2576, 0x25e1, x86_l_25e1);
x86_l_2578:
	/* 0x2578: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_257b:
	/* 0x257b: jb     25e1 <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x257b, 0x25e1, x86_l_25e1);
x86_l_257d:
	/* 0x257d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_257d);
x86_l_257e:
	/* 0x257e: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2581:
	/* 0x2581: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2584:
	/* 0x2584: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_2588:
	/* 0x2588: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_258b:
	/* 0x258b: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_258e:
	/* 0x258e: and    dl,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_2591:
	/* 0x2591: cmp    eax,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_2594:
	/* 0x2594: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2594, 0x261f, x86_l_261f);
x86_l_259a:
	/* 0x259a: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_259d:
	/* 0x259d: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_25a1:
	/* 0x25a1: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_25a4:
	/* 0x25a4: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_25a8:
	/* 0x25a8: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_25ab:
	/* 0x25ab: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_25ae:
	/* 0x25ae: cmp    eax,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_25b1:
	/* 0x25b1: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x25b1, 0x261f, x86_l_261f);
x86_l_25b3:
	/* 0x25b3: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25b6:
	/* 0x25b6: setbe  r8b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R8, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_25ba:
	/* 0x25ba: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_25bd:
	/* 0x25bd: setae  r9b */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_25c1:
	/* 0x25c1: and    r9b,r8b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_25c4:
	/* 0x25c4: or     dl,r9b */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_25c7:
	/* 0x25c7: cmp    eax,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_25ca:
	/* 0x25ca: jb     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x25ca, 0x261f, x86_l_261f);
x86_l_25cc:
	/* 0x25cc: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_25cf:
	/* 0x25cf: setbe  al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_BE, 0);
x86_l_25d2:
	/* 0x25d2: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_25d5:
	/* 0x25d5: setae  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_25d9:
	/* 0x25d9: and    sil,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_25dc:
	/* 0x25dc: or     dl,sil */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR, 0);
x86_l_25df:
	/* 0x25df: jmp    261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x25df, 0x261f, x86_l_261f);
x86_l_25e1:
	/* 0x25e1: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25e4:
	/* 0x25e4: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_25e7:
	/* 0x25e7: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x25e7, 0x261d, x86_l_261d);
x86_l_25e9:
	/* 0x25e9: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_25ec:
	/* 0x25ec: ja     25f3 <filter_8ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25ec, 0x25f3, x86_l_25f3);
x86_l_25ee:
	/* 0x25ee: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_25f1:
	/* 0x25f1: jae    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x25f1, 0x257d, x86_l_257d);
x86_l_25f3:
	/* 0x25f3: cmp    edx,0x19 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 25ULL);
x86_l_25f6:
	/* 0x25f6: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x25f6, 0x261d, x86_l_261d);
x86_l_25f8:
	/* 0x25f8: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25fb:
	/* 0x25fb: ja     2606 <filter_8ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x25fb, 0x2606, x86_l_2606);
x86_l_25fd:
	/* 0x25fd: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2600:
	/* 0x2600: jae    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2600, 0x257d, x86_l_257d);
x86_l_2606:
	/* 0x2606: cmp    edx,0x21 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 33ULL);
x86_l_2609:
	/* 0x2609: jb     261d <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2609, 0x261d, x86_l_261d);
x86_l_260b:
	/* 0x260b: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_260d:
	/* 0x260d: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2610:
	/* 0x2610: ja     261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2610, 0x261f, x86_l_261f);
x86_l_2612:
	/* 0x2612: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2615:
	/* 0x2615: jae    257d <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2615, 0x257d, x86_l_257d);
x86_l_261b:
	/* 0x261b: jmp    261f <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x261b, 0x261f, x86_l_261f);
x86_l_261d:
	/* 0x261d: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_261f:
	/* 0x261f: cmp    ecx,0x20 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 32ULL);
x86_l_2622:
	/* 0x2622: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_2625:
	/* 0x2625: xor    dl,0x1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_2628:
	/* 0x2628: and    dl,al */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND, 0);
x86_l_262a:
	/* 0x262a: movzx  eax,dl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_262d:
	/* 0x262d: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_257d);

	/* native subroutine native_link_sub_262e */
x86_l_262e:
	/* 0x262e: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2630:
	/* 0x2630: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2631:
	/* 0x2631: sub    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_2635:
	/* 0x2635: mov    r14,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_2638:
	/* 0x2638: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_263b:
	/* 0x263b: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_263f:
	/* 0x263f: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2643:
	/* 0x2643: mov    rdi,QWORD PTR [rip+0x1ab0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)argfilter_maps));
x86_l_264a:
	/* 0x264a: lea    rsi,[rsp+0xc] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_264f:
	/* 0x264f: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2654:
	/* 0x2654: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2656:
	/* 0x2656: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2659:
	/* 0x2659: je     268f <filter_8ty_map+0x61> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2659, 0x268f, x86_l_268f);
x86_l_265b:
	/* 0x265b: movzx  ecx,BYTE PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_265f:
	/* 0x265f: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2664:
	/* 0x2664: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2669:
	/* 0x2669: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_266e:
	/* 0x266e: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2671:
	/* 0x2671: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_map_lookup_elem); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2673:
	/* 0x2673: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2676:
	/* 0x2676: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2678:
	/* 0x2678: cmp    edx,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 29ULL);
x86_l_267b:
	/* 0x267b: ja     26a9 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x267b, 0x26a9, x86_l_26a9);
x86_l_267d:
	/* 0x267d: mov    esi,0x30038400 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 805536768ULL);
x86_l_2682:
	/* 0x2682: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2685:
	/* 0x2685: jae    2699 <filter_8ty_map+0x6b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2685, 0x2699, x86_l_2699);
x86_l_2687:
	/* 0x2687: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_268a:
	/* 0x268a: setne  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NE, 0);
x86_l_268d:
	/* 0x268d: jmp    26a9 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JMP(0x268d, 0x26a9, x86_l_26a9);
x86_l_268f:
	/* 0x268f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2691:
	/* 0x2691: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2695:
	/* 0x2695: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2696:
	/* 0x2696: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2698:
	/* 0x2698: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2698);
x86_l_2699:
	/* 0x2699: mov    esi,0xc0800 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 788480ULL);
x86_l_269e:
	/* 0x269e: bt     esi,edx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_26a1:
	/* 0x26a1: jae    26a9 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x26a1, 0x26a9, x86_l_26a9);
x86_l_26a3:
	/* 0x26a3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26a6:
	/* 0x26a6: sete   cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_26a9:
	/* 0x26a9: movzx  eax,cl */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_26ac:
	/* 0x26ac: add    rsp,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_26b0:
	/* 0x26b0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_26b1:
	/* 0x26b1: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_26b3:
	/* 0x26b3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2698);

	/* native subroutine native_link_sub_26b4 */
x86_l_26b4:
	/* 0x26b4: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_26b5:
	/* 0x26b5: sub    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_26b9:
	/* 0x26b9: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_26c0:
	/* 0x26c0: mov    eax,DWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c2:
	/* 0x26c2: cmp    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_26c8:
	/* 0x26c8: ja     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x26c8, 0x2771, x86_l_2771);
x86_l_26ce:
	/* 0x26ce: mov    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_26d1:
	/* 0x26d1: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_26d4:
	/* 0x26d4: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_26d8:
	/* 0x26d8: jns    26ee <filter_file_type+0x3a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x26d8, 0x26ee, x86_l_26ee);
x86_l_26da:
	/* 0x26da: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_26dd:
	/* 0x26dd: jns    271d <filter_file_type+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_NS, 0x26dd, 0x271d, x86_l_271d);
x86_l_26df:
	/* 0x26df: movzx  ecx,WORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_26e2:
	/* 0x26e2: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26e5:
	/* 0x26e5: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_26e7:
	/* 0x26e7: jne    2726 <filter_file_type+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x26e7, 0x2726, x86_l_2726);
x86_l_26e9:
	/* 0x26e9: jmp    2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JMP(0x26e9, 0x2771, x86_l_2771);
x86_l_26ee:
	/* 0x26ee: lea    rax,[rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_26f3:
	/* 0x26f3: mov    ecx,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_26f8:
	/* 0x26f8: mov    r8d,0x70 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_32, 0, 112ULL);
x86_l_26fe:
	/* 0x26fe: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_2701:
	/* 0x2701: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2704:
	/* 0x2704: mov    esi,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2709:
	/* 0x2709: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x70ULL: X86_SIM_RUN_OP(X86_OP_CALL_HELPER, 0, 0, 0, 0, X86_SIM_HELPER_bpf_probe_read_user); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_270c:
	/* 0x270c: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_270f:
	/* 0x270f: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_2714:
	/* 0x2714: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2717:
	/* 0x2717: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2719:
	/* 0x2719: jne    2726 <filter_file_type+0x72> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2719, 0x2726, x86_l_2726);
x86_l_271b:
	/* 0x271b: jmp    2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JMP(0x271b, 0x2771, x86_l_2771);
x86_l_271d:
	/* 0x271d: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_271f:
	/* 0x271f: mov    edx,DWORD PTR [rdi+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2722:
	/* 0x2722: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2724:
	/* 0x2724: je     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2724, 0x2771, x86_l_2771);
x86_l_2726:
	/* 0x2726: and    ecx,0xf000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_272c:
	/* 0x272c: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2731:
	/* 0x2731: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2733:
	/* 0x2733: je     2773 <filter_file_type+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2733, 0x2773, x86_l_2773);
x86_l_2735:
	/* 0x2735: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2738:
	/* 0x2738: cmp    edx,0xc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 12ULL);
x86_l_273b:
	/* 0x273b: jbe    2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x273b, 0x2771, x86_l_2771);
x86_l_273d:
	/* 0x273d: mov    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2740:
	/* 0x2740: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2742:
	/* 0x2742: je     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2742, 0x2771, x86_l_2771);
x86_l_2744:
	/* 0x2744: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2746:
	/* 0x2746: je     2773 <filter_file_type+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2746, 0x2773, x86_l_2773);
x86_l_2748:
	/* 0x2748: cmp    edx,0x11 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 17ULL);
x86_l_274b:
	/* 0x274b: jb     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x274b, 0x2771, x86_l_2771);
x86_l_274d:
	/* 0x274d: mov    esi,DWORD PTR [rdi+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2750:
	/* 0x2750: test   esi,esi */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_2752:
	/* 0x2752: je     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2752, 0x2771, x86_l_2771);
x86_l_2754:
	/* 0x2754: cmp    esi,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2756:
	/* 0x2756: je     2773 <filter_file_type+0xbf> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2756, 0x2773, x86_l_2773);
x86_l_2758:
	/* 0x2758: cmp    edx,0x15 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 21ULL);
x86_l_275b:
	/* 0x275b: jb     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x275b, 0x2771, x86_l_2771);
x86_l_275d:
	/* 0x275d: mov    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2760:
	/* 0x2760: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2762:
	/* 0x2762: je     2771 <filter_file_type+0xbd> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2762, 0x2771, x86_l_2771);
x86_l_2764:
	/* 0x2764: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2766:
	/* 0x2766: cmp    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2768:
	/* 0x2768: sete   al */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_CC_E, 0);
x86_l_276b:
	/* 0x276b: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_276f:
	/* 0x276f: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2770:
	/* 0x2770: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2770);
x86_l_2771:
	/* 0x2771: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2773:
	/* 0x2773: add    rsp,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2777:
	/* 0x2777: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_2778:
	/* 0x2778: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch_2770);

x86_sim_ret_dispatch_4da:
	switch (__x86_sim_ret_addr) {
	case 0x226ULL: goto x86_l_226;
	case 0x359ULL: goto x86_l_359;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_5a0:
	switch (__x86_sim_ret_addr) {
	case 0x2b9ULL: goto x86_l_2b9;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_8cf:
	switch (__x86_sim_ret_addr) {
	case 0x2f9ULL: goto x86_l_2f9;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_957:
	switch (__x86_sim_ret_addr) {
	case 0x352ULL: goto x86_l_352;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_9d0:
	switch (__x86_sim_ret_addr) {
	case 0x368ULL: goto x86_l_368;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_a17:
	switch (__x86_sim_ret_addr) {
	case 0x36fULL: goto x86_l_36f;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_ae3:
	switch (__x86_sim_ret_addr) {
	case 0x37bULL: goto x86_l_37b;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_b01:
	switch (__x86_sim_ret_addr) {
	case 0x387ULL: goto x86_l_387;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_b49:
	switch (__x86_sim_ret_addr) {
	case 0xb00ULL: goto x86_l_b00;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_e79:
	switch (__x86_sim_ret_addr) {
	case 0xb22ULL: goto x86_l_b22;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_f9a:
	switch (__x86_sim_ret_addr) {
	case 0xb29ULL: goto x86_l_b29;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_10f7:
	switch (__x86_sim_ret_addr) {
	case 0x544ULL: goto x86_l_544;
	case 0xa89ULL: goto x86_l_a89;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1220:
	switch (__x86_sim_ret_addr) {
	case 0x55aULL: goto x86_l_55a;
	case 0x979ULL: goto x86_l_979;
	case 0xaa7ULL: goto x86_l_aa7;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_16aa:
	switch (__x86_sim_ret_addr) {
	case 0x52eULL: goto x86_l_52e;
	case 0x935ULL: goto x86_l_935;
	case 0xab1ULL: goto x86_l_ab1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_19ad:
	switch (__x86_sim_ret_addr) {
	case 0xabdULL: goto x86_l_abd;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_19d3:
	switch (__x86_sim_ret_addr) {
	case 0xa16ULL: goto x86_l_a16;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1cd6:
	switch (__x86_sim_ret_addr) {
	case 0xa38ULL: goto x86_l_a38;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1df1:
	switch (__x86_sim_ret_addr) {
	case 0xa3fULL: goto x86_l_a3f;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_1e2b:
	switch (__x86_sim_ret_addr) {
	case 0x9cfULL: goto x86_l_9cf;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2126:
	switch (__x86_sim_ret_addr) {
	case 0x9f1ULL: goto x86_l_9f1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2240:
	switch (__x86_sim_ret_addr) {
	case 0x8c4ULL: goto x86_l_8c4;
	case 0x9adULL: goto x86_l_9ad;
	case 0x9f8ULL: goto x86_l_9f8;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_227a:
	switch (__x86_sim_ret_addr) {
	case 0x59fULL: goto x86_l_59f;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_257d:
	switch (__x86_sim_ret_addr) {
	case 0x5c1ULL: goto x86_l_5c1;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2698:
	switch (__x86_sim_ret_addr) {
	case 0x5c8ULL: goto x86_l_5c8;
	default: __x86_sim_unresolved_indirect_target();
	}

x86_sim_ret_dispatch_2770:
	switch (__x86_sim_ret_addr) {
	case 0x510ULL: goto x86_l_510;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
