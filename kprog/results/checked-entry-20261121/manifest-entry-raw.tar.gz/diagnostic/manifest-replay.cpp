#include "kprog/libnativeloader/src/native_loader_trusted_manifest.hpp"
#include <iostream>
struct Agreement { size_t length=0, leading=0, aligned=0; std::string difference; };
int main(int argc,char **argv) {
 auto path=std::filesystem::path(argv[1]);
 auto entries=json_array_objects(read_text_file_required(path),"objects");
 unsigned ok=0,failed=0,source_calls=0;
 for(auto &entry:entries) {
  bpf_prog_info info{};
  auto name=json_required_string(entry,"program");
  std::memcpy(info.name,name.data(),std::min(name.size(),sizeof(info.name)-1));
  try {
   auto result=resolve_native_manifest(path,info,[&](const auto &,const auto &) { ++source_calls; return Agreement{}; },0);
   if(result) ++ok; else ++failed;
  } catch(const std::exception &e) { ++failed; if(failed==1) std::cout<<"first_error="<<e.what()<<std::endl; }
 }
 std::cout<<"entries="<<entries.size()<<" resolved="<<ok<<" failed="<<failed<<" source_calls="<<source_calls<<std::endl;
 return 0;
}
