#!/bin/bash
set -u
ROOT=/workspaces/kprog-raw/C/checked-entry-20261121
date -u +%FT%TZ > "$ROOT/resume-queued"
tail --pid=2151863 -f /dev/null
date -u +%FT%TZ > "$ROOT/resume-started"
cd /workspaces/repository
make -C kprog/libnativeloader checked-corpus-all CHECKED_OUTPUT="$ROOT/whole-apps-after-otel-retest" > "$ROOT/verification-after-otel-retest.log" 2>&1
rc=$?
printf '%s
' "$rc" > "$ROOT/verification-after-otel-retest.exit"
date -u +%FT%TZ > "$ROOT/resume-complete"
exit "$rc"
