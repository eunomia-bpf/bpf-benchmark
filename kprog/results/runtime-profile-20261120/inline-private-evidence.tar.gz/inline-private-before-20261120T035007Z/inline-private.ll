; ModuleID = '/workspaces/repository/kprog/results/sparse-stack-cache-20261119/oracle.c'
source_filename = "/workspaces/repository/kprog/results/sparse-stack-cache-20261119/oracle.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.x86_sim_state = type { %union.anon, i64, i8, i8, i8, i8, i8, i8, i64, i64, i64, i32, %union.x86_sim_stack_mem, %struct.x86_sim_xdp_abi, %struct.x86_sim_skb_abi, ptr, ptr, i8, ptr, i8 }
%union.anon = type { %struct.anon }
%struct.anon = type { %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8, %union.x86_sim_gpr, i8 }
%union.x86_sim_gpr = type { ptr }
%union.x86_sim_stack_mem = type { [8 x i64] }
%struct.x86_sim_xdp_abi = type { ptr, ptr, [5 x i32] }
%struct.x86_sim_skb_abi = type { [48 x i8], [5 x i32], [12 x i8], ptr, [120 x i8], ptr }
%struct.x86_sim_inline_bindings = type { ptr, ptr, [8 x %struct.x86_sim_inline_value], ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i8, i8 }
%struct.x86_sim_inline_value = type { ptr, ptr }
%struct.x86_sim_gpr_cell = type { %union.x86_sim_gpr, i8 }
%struct.__sk_buff = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, [5 x i32], i32, i32, i32, i32, i32, i32, i32, i32, [4 x i32], [4 x i32], i32, i32, i32, %union.anon.0, i64, i32, i32, %union.anon.1, i32, i8, [3 x i8], i64 }
%union.anon.0 = type { ptr }
%union.anon.1 = type { ptr }
%struct.xdp_md = type { i32, i32, i32, i32, i32, i32 }

@.str = private unnamed_addr constant [37 x i8] c"kind == NATIVE_LAB_INPUT_UNSPECIFIED\00", align 1
@.str.1 = private unnamed_addr constant [74 x i8] c"/workspaces/repository/kprog/results/sparse-stack-cache-20261119/oracle.c\00", align 1
@__PRETTY_FUNCTION__.native_lab_entry_input = private unnamed_addr constant [51 x i8] c"unsigned long native_lab_entry_input(unsigned int)\00", align 1
@.str.2 = private unnamed_addr constant [16 x i8] c"cached.tag==tag\00", align 1
@__PRETTY_FUNCTION__.main = private unnamed_addr constant [15 x i8] c"int main(void)\00", align 1
@.str.3 = private unnamed_addr constant [30 x i8] c"cached.pointer==state.rbx.ptr\00", align 1
@stderr = external local_unnamed_addr global ptr, align 8
@.str.4 = private unnamed_addr constant [75 x i8] c"reload tag=%u word=%u alias=%u replant=%u observed_tag=%u same_pointer=%d\0A\00", align 1
@.str.5 = private unnamed_addr constant [51 x i8] c"state.rax_tag==tag && state.rax.ptr==state.rbx.ptr\00", align 1
@.str.6 = private unnamed_addr constant [31 x i8] c"cached.tag==X86_SIM_TAG_SCALAR\00", align 1
@.str.7 = private unnamed_addr constant [84 x i8] c"state.rax_tag==X86_SIM_TAG_SCALAR && (uintptr_t)state.rax.ptr==0x1020304050607080UL\00", align 1
@.str.8 = private unnamed_addr constant [40 x i8] c"{\22tag_alias_partial_release_cases\22:%u}\0A\00", align 1

; Function Attrs: nounwind uwtable
define dso_local noundef i64 @native_lab_entry_input(i32 noundef %0) local_unnamed_addr #0 {
  %2 = icmp eq i32 %0, 6
  br i1 %2, label %4, label %3

3:                                                ; preds = %1
  tail call void @__assert_fail(ptr noundef nonnull @.str, ptr noundef nonnull @.str.1, i32 noundef 12, ptr noundef nonnull @__PRETTY_FUNCTION__.native_lab_entry_input) #6
  unreachable

4:                                                ; preds = %1
  ret i64 1161981756646125696
}

; Function Attrs: noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #1

; Function Attrs: nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca %struct.x86_sim_state, align 8
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x ptr], align 16
  %4 = alloca %struct.x86_sim_inline_bindings, align 8
  %5 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 1
  %6 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12
  %7 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2
  %8 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 3
  %9 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 1
  %10 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 4
  %11 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 2
  %12 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 5
  %13 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 3
  %14 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 6
  %15 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 4
  %16 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 7
  %17 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 5
  %18 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 8
  %19 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 6
  %20 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 9
  %21 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 7
  %22 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 10
  %23 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 8
  %24 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 11
  %25 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 9
  %26 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 12
  %27 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 10
  %28 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 13
  %29 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 16
  %30 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 14
  %31 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 18
  %32 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 15
  %33 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 15
  %34 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 16
  %35 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 17
  %36 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 17
  %37 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 19
  %38 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 8
  %39 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 14
  %40 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 15
  %41 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 1
  %42 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 6
  %43 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 7
  %44 = getelementptr inbounds %struct.anon, ptr %1, i64 0, i32 1
  %45 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %46 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %47 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %48 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %49 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %50 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %51 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %52 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %53 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %54 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %55 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %56 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %57 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %58 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %59 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %60 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %61 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %62 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %63 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %64 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %65 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %66 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %67 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %68 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %69 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %70 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %71 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %72 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %73 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %74 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %75 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %76 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %77 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %78 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %79 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %80 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %81 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %82 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %83 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %84 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %85 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %86 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %87 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %88 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %89 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %90 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %91 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %92 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %93 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %94 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %95 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %96 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %97 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %98 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %99 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %100 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %101 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %102 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %103 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %104 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %105 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %106 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %107 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %108 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %109 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %110 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %111 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %112 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %113 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %114 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %115 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %116 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %117 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %118 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %119 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %120 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %121 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %122 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %123 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %124 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %125 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %126 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %127 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %128 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %129 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %130 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %131 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %132 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %133 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %134 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %135 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %136 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %137 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %138 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %139 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 1
  %140 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 1
  %141 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 5
  %142 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 5
  %143 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %144 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %145 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %146 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %147 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %148 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %149 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %150 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %151 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %152 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %153 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %154 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %155 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %156 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %157 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %158 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %159 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %160 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %161 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %162 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %163 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %164 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %165 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %166 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %167 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %168 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %169 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %170 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %171 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %172 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %173 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %174 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %175 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 1
  %176 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 5
  %177 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 1
  %178 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 2
  %179 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 3
  %180 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 4
  %181 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 5
  %182 = getelementptr inbounds %struct.x86_sim_state, ptr %1, i64 0, i32 12, i32 0, i64 6
  %183 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 1
  %184 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 1
  %185 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 2
  %186 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 2
  %187 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 3
  %188 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 3
  %189 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 4
  %190 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 4
  %191 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 5
  %192 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 5
  %193 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 6
  %194 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 6
  %195 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %196 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %197 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %198 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %199 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %200 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %201 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %202 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %203 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %204 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %205 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %206 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %207 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %208 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %209 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %210 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  %211 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0
  %212 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 0, i32 1
  %213 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1
  %214 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 1, i32 1
  %215 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2
  %216 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 2, i32 1
  %217 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3
  %218 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 3, i32 1
  %219 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4
  %220 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 4, i32 1
  %221 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5
  %222 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 5, i32 1
  %223 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6
  %224 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 6, i32 1
  %225 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7
  %226 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 7, i32 1
  br label %227

227:                                              ; preds = %0, %250
  %228 = phi i32 [ 0, %0 ], [ %251, %250 ]
  %229 = trunc i32 %228 to i8
  %230 = icmp ne i32 %228, 4
  br label %233

231:                                              ; preds = %250
  %232 = call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str.8, i32 noundef 72)
  ret i32 0

233:                                              ; preds = %227, %253
  %234 = phi i64 [ 1, %227 ], [ %254, %253 ]
  %235 = shl nuw nsw i64 %234, 3
  %236 = or disjoint i64 %235, -64
  %237 = getelementptr inbounds [64 x i8], ptr %6, i64 0, i64 %235
  %238 = add nuw nsw i64 %235, -56
  %239 = icmp eq i64 %234, 1
  %240 = icmp eq i64 %234, 5
  %241 = trunc i64 %234 to i32
  %242 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 %234
  %243 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 %234
  %244 = icmp eq i64 %234, 1
  %245 = icmp eq i64 %234, 5
  %246 = icmp ult i64 %234, 2
  %247 = icmp ult i64 %234, 3
  %248 = icmp ult i64 %234, 4
  %249 = icmp ult i64 %234, 5
  br label %256

250:                                              ; preds = %253
  %251 = add nuw nsw i32 %228, 1
  %252 = icmp eq i32 %251, 9
  br i1 %252, label %231, label %227, !llvm.loop !5

253:                                              ; preds = %276
  %254 = add nuw nsw i64 %234, 4
  %255 = icmp ult i64 %234, 2
  br i1 %255, label %233, label %250, !llvm.loop !8

256:                                              ; preds = %233, %276
  %257 = phi i32 [ 0, %233 ], [ %277, %276 ]
  call void @llvm.lifetime.start.p0(i64 664, ptr nonnull %1) #7
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(664) %1, i8 0, i64 664, i1 false)
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %2) #7
  store i64 0, ptr %2, align 8
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %3) #7
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(64) %3, i8 0, i64 64, i1 false)
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %4) #7
  store ptr %1, ptr %4, align 8, !tbaa !9
  store ptr %6, ptr %5, align 8, !tbaa !14
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(128) %7, i8 0, i64 128, i1 false)
  store ptr %9, ptr %8, align 8, !tbaa !15
  store ptr %11, ptr %10, align 8, !tbaa !16
  store ptr %13, ptr %12, align 8, !tbaa !17
  store ptr %15, ptr %14, align 8, !tbaa !18
  store ptr %17, ptr %16, align 8, !tbaa !19
  store ptr %19, ptr %18, align 8, !tbaa !20
  store ptr %21, ptr %20, align 8, !tbaa !21
  store ptr %23, ptr %22, align 8, !tbaa !22
  store ptr %25, ptr %24, align 8, !tbaa !23
  store ptr %27, ptr %26, align 8, !tbaa !24
  %258 = load ptr, ptr %29, align 8, !tbaa !25
  store ptr %258, ptr %28, align 8, !tbaa !31
  %259 = load ptr, ptr %31, align 8, !tbaa !32
  store ptr %259, ptr %30, align 8, !tbaa !33
  %260 = load ptr, ptr %33, align 8, !tbaa !34
  store ptr %260, ptr %32, align 8, !tbaa !35
  %261 = load i8, ptr %35, align 8, !tbaa !36
  store i8 %261, ptr %34, align 8, !tbaa !37
  %262 = load i8, ptr %37, align 8, !tbaa !38
  store i8 %262, ptr %36, align 1, !tbaa !39
  br label %268

263:                                              ; preds = %268
  store i8 2, ptr %37, align 8, !tbaa !38
  store ptr inttoptr (i64 -64 to ptr), ptr %38, align 8, !tbaa !40
  store i64 305397760, ptr %9, align 8, !tbaa !41
  store ptr %237, ptr %39, align 8, !tbaa !40
  store i8 4, ptr %40, align 8, !tbaa !40
  store ptr %41, ptr %42, align 8, !tbaa !40
  store i8 %229, ptr %43, align 8, !tbaa !40
  %264 = icmp eq i32 %257, 0
  %265 = select i1 %264, i64 %235, i64 0
  %266 = select i1 %264, i64 4, i64 7
  %267 = select i1 %264, i64 %238, i64 0
  br label %279

268:                                              ; preds = %256, %268
  %269 = phi i64 [ 0, %256 ], [ %274, %268 ]
  %270 = getelementptr inbounds [8 x i8], ptr %2, i64 0, i64 %269
  %271 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 %269
  store ptr %270, ptr %271, align 8, !tbaa !42
  %272 = getelementptr inbounds [8 x ptr], ptr %3, i64 0, i64 %269
  %273 = getelementptr inbounds %struct.x86_sim_inline_bindings, ptr %4, i64 0, i32 2, i64 %269, i32 1
  store ptr %272, ptr %273, align 8, !tbaa !44
  %274 = add nuw nsw i64 %269, 1
  %275 = icmp eq i64 %274, 8
  br i1 %275, label %263, label %268, !llvm.loop !45

276:                                              ; preds = %1921
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %4) #7
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %3) #7
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %2) #7
  call void @llvm.lifetime.end.p0(i64 664, ptr nonnull %1) #7
  %277 = add nuw nsw i32 %257, 1
  %278 = icmp eq i32 %257, 0
  br i1 %278, label %256, label %253, !llvm.loop !46

279:                                              ; preds = %263, %1921
  %280 = phi i32 [ 0, %263 ], [ %1922, %1921 ]
  store ptr inttoptr (i64 -64 to ptr), ptr %38, align 8, !tbaa !40
  %281 = load ptr, ptr %4, align 8, !tbaa !9
  %282 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %281, i64 3
  %283 = load ptr, ptr %282, align 8, !tbaa !40
  %284 = ptrtoint ptr %283 to i64
  %285 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %281, i64 3, i32 1
  %286 = load i8, ptr %285, align 8, !tbaa !47
  %287 = icmp eq i8 %286, 4
  br i1 %287, label %288, label %297

288:                                              ; preds = %279
  %289 = load ptr, ptr %5, align 8, !tbaa !14
  %290 = ptrtoint ptr %289 to i64
  %291 = add i64 %284, -64
  %292 = sub i64 %291, %290
  %293 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %292) #7, !srcloc !49
  %294 = load ptr, ptr %8, align 8, !tbaa !15
  %295 = load i64, ptr %294, align 8, !tbaa !50
  %296 = add i64 %295, %293
  br label %297

297:                                              ; preds = %288, %279
  %298 = phi i64 [ %296, %288 ], [ %284, %279 ]
  %299 = load ptr, ptr %4, align 8, !tbaa !9
  %300 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %299, i64 %266, i32 1
  %301 = load i8, ptr %300, align 8, !tbaa !47
  %302 = icmp eq i8 %301, 1
  br i1 %302, label %305, label %303

303:                                              ; preds = %297
  %304 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %265) #7, !srcloc !51
  br label %305

305:                                              ; preds = %303, %297
  %306 = phi i64 [ %304, %303 ], [ %265, %297 ]
  %307 = load ptr, ptr %4, align 8, !tbaa !9
  %308 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %307, i64 %266
  %309 = load ptr, ptr %308, align 8, !tbaa !40
  %310 = load i8, ptr %36, align 1, !tbaa !39
  %311 = icmp eq i8 %310, 1
  br i1 %311, label %312, label %370

312:                                              ; preds = %305
  %313 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %307, i64 %266, i32 1
  %314 = load i8, ptr %313, align 8, !tbaa !47
  %315 = icmp eq i8 %314, 1
  br i1 %315, label %316, label %370

316:                                              ; preds = %312
  %317 = ptrtoint ptr %309 to i64
  %318 = load ptr, ptr %30, align 8, !tbaa !33
  %319 = ptrtoint ptr %318 to i64
  %320 = sub i64 %317, %319
  %321 = add i64 %320, %306
  %322 = add i64 %321, -48
  %323 = icmp ult i64 %322, 13
  br i1 %323, label %324, label %349

324:                                              ; preds = %316
  %325 = load ptr, ptr %28, align 8, !tbaa !31
  %326 = getelementptr inbounds i8, ptr %325, i64 %321
  %327 = trunc i64 %298 to i8
  store volatile i8 %327, ptr %326, align 1, !tbaa !40
  %328 = lshr i64 %298, 8
  %329 = trunc i64 %328 to i8
  %330 = getelementptr inbounds i8, ptr %326, i64 1
  store volatile i8 %329, ptr %330, align 1, !tbaa !40
  %331 = lshr i64 %298, 16
  %332 = trunc i64 %331 to i8
  %333 = getelementptr inbounds i8, ptr %326, i64 2
  store volatile i8 %332, ptr %333, align 1, !tbaa !40
  %334 = lshr i64 %298, 24
  %335 = trunc i64 %334 to i8
  %336 = getelementptr inbounds i8, ptr %326, i64 3
  store volatile i8 %335, ptr %336, align 1, !tbaa !40
  %337 = lshr i64 %298, 32
  %338 = trunc i64 %337 to i8
  %339 = getelementptr inbounds i8, ptr %326, i64 4
  store volatile i8 %338, ptr %339, align 1, !tbaa !40
  %340 = lshr i64 %298, 40
  %341 = trunc i64 %340 to i8
  %342 = getelementptr inbounds i8, ptr %326, i64 5
  store volatile i8 %341, ptr %342, align 1, !tbaa !40
  %343 = lshr i64 %298, 48
  %344 = trunc i64 %343 to i8
  %345 = getelementptr inbounds i8, ptr %326, i64 6
  store volatile i8 %344, ptr %345, align 1, !tbaa !40
  %346 = lshr i64 %298, 56
  %347 = trunc i64 %346 to i8
  %348 = getelementptr inbounds i8, ptr %326, i64 7
  store volatile i8 %347, ptr %348, align 1, !tbaa !40
  br label %879

349:                                              ; preds = %316
  %350 = load ptr, ptr %123, align 8, !tbaa !42
  store i8 0, ptr %350, align 1, !tbaa !40
  %351 = load ptr, ptr %124, align 8, !tbaa !44
  store ptr null, ptr %351, align 8, !tbaa !52
  %352 = load ptr, ptr %125, align 8, !tbaa !42
  store i8 0, ptr %352, align 1, !tbaa !40
  %353 = load ptr, ptr %126, align 8, !tbaa !44
  store ptr null, ptr %353, align 8, !tbaa !52
  %354 = load ptr, ptr %127, align 8, !tbaa !42
  store i8 0, ptr %354, align 1, !tbaa !40
  %355 = load ptr, ptr %128, align 8, !tbaa !44
  store ptr null, ptr %355, align 8, !tbaa !52
  %356 = load ptr, ptr %129, align 8, !tbaa !42
  store i8 0, ptr %356, align 1, !tbaa !40
  %357 = load ptr, ptr %130, align 8, !tbaa !44
  store ptr null, ptr %357, align 8, !tbaa !52
  %358 = load ptr, ptr %131, align 8, !tbaa !42
  store i8 0, ptr %358, align 1, !tbaa !40
  %359 = load ptr, ptr %132, align 8, !tbaa !44
  store ptr null, ptr %359, align 8, !tbaa !52
  %360 = load ptr, ptr %133, align 8, !tbaa !42
  store i8 0, ptr %360, align 1, !tbaa !40
  %361 = load ptr, ptr %134, align 8, !tbaa !44
  store ptr null, ptr %361, align 8, !tbaa !52
  %362 = load ptr, ptr %135, align 8, !tbaa !42
  store i8 0, ptr %362, align 1, !tbaa !40
  %363 = load ptr, ptr %136, align 8, !tbaa !44
  store ptr null, ptr %363, align 8, !tbaa !52
  %364 = load ptr, ptr %137, align 8, !tbaa !42
  store i8 0, ptr %364, align 1, !tbaa !40
  %365 = load ptr, ptr %138, align 8, !tbaa !44
  store ptr null, ptr %365, align 8, !tbaa !52
  %366 = load ptr, ptr %4, align 8, !tbaa !9
  %367 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %366, i64 %266
  %368 = load ptr, ptr %367, align 8, !tbaa !40
  %369 = getelementptr inbounds i8, ptr %368, i64 %306
  store volatile i64 %298, ptr %369, align 1, !tbaa !40
  br label %879

370:                                              ; preds = %312, %305
  %371 = ptrtoint ptr %309 to i64
  br i1 %264, label %372, label %629

372:                                              ; preds = %370
  %373 = add nsw i64 %265, %371
  %374 = add i64 %373, 64
  %375 = add i64 %373, 71
  %376 = icmp ult i64 %375, 15
  br i1 %376, label %377, label %380

377:                                              ; preds = %372
  %378 = load ptr, ptr %91, align 8, !tbaa !42
  store i8 0, ptr %378, align 1, !tbaa !40
  %379 = load ptr, ptr %92, align 8, !tbaa !44
  store ptr null, ptr %379, align 8, !tbaa !52
  br label %380

380:                                              ; preds = %377, %372
  %381 = and i64 %373, -8
  %382 = icmp eq i64 %381, -56
  %383 = add i64 %373, 63
  %384 = icmp ult i64 %383, 8
  %385 = or i1 %382, %384
  br i1 %385, label %386, label %389

386:                                              ; preds = %380
  %387 = load ptr, ptr %93, align 8, !tbaa !42
  store i8 0, ptr %387, align 1, !tbaa !40
  %388 = load ptr, ptr %94, align 8, !tbaa !44
  store ptr null, ptr %388, align 8, !tbaa !52
  br label %389

389:                                              ; preds = %386, %380
  %390 = and i64 %373, -8
  %391 = icmp eq i64 %390, -48
  %392 = add i64 %373, 55
  %393 = icmp ult i64 %392, 8
  %394 = or i1 %391, %393
  br i1 %394, label %395, label %398

395:                                              ; preds = %389
  %396 = load ptr, ptr %95, align 8, !tbaa !42
  store i8 0, ptr %396, align 1, !tbaa !40
  %397 = load ptr, ptr %96, align 8, !tbaa !44
  store ptr null, ptr %397, align 8, !tbaa !52
  br label %398

398:                                              ; preds = %395, %389
  %399 = and i64 %373, -8
  %400 = icmp eq i64 %399, -40
  %401 = add i64 %373, 47
  %402 = icmp ult i64 %401, 8
  %403 = or i1 %400, %402
  br i1 %403, label %404, label %407

404:                                              ; preds = %398
  %405 = load ptr, ptr %97, align 8, !tbaa !42
  store i8 0, ptr %405, align 1, !tbaa !40
  %406 = load ptr, ptr %98, align 8, !tbaa !44
  store ptr null, ptr %406, align 8, !tbaa !52
  br label %407

407:                                              ; preds = %404, %398
  %408 = and i64 %373, -8
  %409 = icmp eq i64 %408, -32
  %410 = add i64 %373, 39
  %411 = icmp ult i64 %410, 8
  %412 = or i1 %409, %411
  br i1 %412, label %413, label %416

413:                                              ; preds = %407
  %414 = load ptr, ptr %99, align 8, !tbaa !42
  store i8 0, ptr %414, align 1, !tbaa !40
  %415 = load ptr, ptr %100, align 8, !tbaa !44
  store ptr null, ptr %415, align 8, !tbaa !52
  br label %416

416:                                              ; preds = %413, %407
  %417 = and i64 %373, -8
  %418 = icmp eq i64 %417, -24
  %419 = add i64 %373, 31
  %420 = icmp ult i64 %419, 8
  %421 = or i1 %418, %420
  br i1 %421, label %422, label %425

422:                                              ; preds = %416
  %423 = load ptr, ptr %101, align 8, !tbaa !42
  store i8 0, ptr %423, align 1, !tbaa !40
  %424 = load ptr, ptr %102, align 8, !tbaa !44
  store ptr null, ptr %424, align 8, !tbaa !52
  br label %425

425:                                              ; preds = %422, %416
  %426 = and i64 %373, -8
  %427 = icmp eq i64 %426, -16
  %428 = add i64 %373, 23
  %429 = icmp ult i64 %428, 8
  %430 = or i1 %427, %429
  br i1 %430, label %431, label %434

431:                                              ; preds = %425
  %432 = load ptr, ptr %103, align 8, !tbaa !42
  store i8 0, ptr %432, align 1, !tbaa !40
  %433 = load ptr, ptr %104, align 8, !tbaa !44
  store ptr null, ptr %433, align 8, !tbaa !52
  br label %434

434:                                              ; preds = %431, %425
  %435 = icmp ugt i64 %373, -16
  br i1 %435, label %436, label %439

436:                                              ; preds = %434
  %437 = load ptr, ptr %105, align 8, !tbaa !42
  store i8 0, ptr %437, align 1, !tbaa !40
  %438 = load ptr, ptr %106, align 8, !tbaa !44
  store ptr null, ptr %438, align 8, !tbaa !52
  br label %439

439:                                              ; preds = %436, %434
  %440 = add nsw i64 %306, %371
  %441 = add i64 %440, 64
  %442 = and i64 %440, 7
  %443 = icmp eq i64 %442, 0
  %444 = load ptr, ptr %5, align 8, !tbaa !14
  br i1 %443, label %445, label %448

445:                                              ; preds = %439
  %446 = lshr exact i64 %441, 3
  %447 = getelementptr inbounds [8 x i64], ptr %444, i64 0, i64 %446
  store volatile i64 %298, ptr %447, align 8, !tbaa !40
  br label %472

448:                                              ; preds = %439
  %449 = getelementptr inbounds [64 x i8], ptr %444, i64 0, i64 %441
  %450 = trunc i64 %298 to i8
  store i8 %450, ptr %449, align 1, !tbaa !40
  %451 = lshr i64 %298, 8
  %452 = trunc i64 %451 to i8
  %453 = getelementptr inbounds i8, ptr %449, i64 1
  store i8 %452, ptr %453, align 1, !tbaa !40
  %454 = lshr i64 %298, 16
  %455 = trunc i64 %454 to i8
  %456 = getelementptr inbounds i8, ptr %449, i64 2
  store i8 %455, ptr %456, align 1, !tbaa !40
  %457 = lshr i64 %298, 24
  %458 = trunc i64 %457 to i8
  %459 = getelementptr inbounds i8, ptr %449, i64 3
  store i8 %458, ptr %459, align 1, !tbaa !40
  %460 = lshr i64 %298, 32
  %461 = trunc i64 %460 to i8
  %462 = getelementptr inbounds i8, ptr %449, i64 4
  store i8 %461, ptr %462, align 1, !tbaa !40
  %463 = lshr i64 %298, 40
  %464 = trunc i64 %463 to i8
  %465 = getelementptr inbounds i8, ptr %449, i64 5
  store i8 %464, ptr %465, align 1, !tbaa !40
  %466 = lshr i64 %298, 48
  %467 = trunc i64 %466 to i8
  %468 = getelementptr inbounds i8, ptr %449, i64 6
  store i8 %467, ptr %468, align 1, !tbaa !40
  %469 = lshr i64 %298, 56
  %470 = trunc i64 %469 to i8
  %471 = getelementptr inbounds i8, ptr %449, i64 7
  store i8 %470, ptr %471, align 1, !tbaa !40
  br label %472

472:                                              ; preds = %448, %445
  %473 = load ptr, ptr %4, align 8, !tbaa !9
  %474 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %473, i64 4
  %475 = load ptr, ptr %474, align 8, !tbaa !40
  %476 = ptrtoint ptr %475 to i64
  %477 = icmp slt i64 %440, %476
  br i1 %477, label %478, label %565

478:                                              ; preds = %472
  %479 = load ptr, ptr %4, align 8, !tbaa !9
  %480 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %479, i64 4
  %481 = load ptr, ptr %480, align 8, !tbaa !40
  %482 = ptrtoint ptr %481 to i64
  %483 = icmp slt i64 %440, %482
  br i1 %483, label %484, label %488

484:                                              ; preds = %478
  %485 = add i64 %440, 64
  %486 = load ptr, ptr %5, align 8, !tbaa !14
  %487 = getelementptr inbounds [64 x i8], ptr %486, i64 0, i64 %485
  store i8 -128, ptr %487, align 1, !tbaa !40
  br label %488

488:                                              ; preds = %484, %478
  %489 = add nsw i64 %440, 1
  %490 = load ptr, ptr %4, align 8, !tbaa !9
  %491 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %490, i64 4
  %492 = load ptr, ptr %491, align 8, !tbaa !40
  %493 = ptrtoint ptr %492 to i64
  %494 = icmp slt i64 %489, %493
  br i1 %494, label %495, label %499

495:                                              ; preds = %488
  %496 = add i64 %440, 65
  %497 = load ptr, ptr %5, align 8, !tbaa !14
  %498 = getelementptr inbounds [64 x i8], ptr %497, i64 0, i64 %496
  store i8 -128, ptr %498, align 1, !tbaa !40
  br label %499

499:                                              ; preds = %495, %488
  %500 = add nsw i64 %440, 2
  %501 = load ptr, ptr %4, align 8, !tbaa !9
  %502 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %501, i64 4
  %503 = load ptr, ptr %502, align 8, !tbaa !40
  %504 = ptrtoint ptr %503 to i64
  %505 = icmp slt i64 %500, %504
  br i1 %505, label %506, label %510

506:                                              ; preds = %499
  %507 = add i64 %440, 66
  %508 = load ptr, ptr %5, align 8, !tbaa !14
  %509 = getelementptr inbounds [64 x i8], ptr %508, i64 0, i64 %507
  store i8 -128, ptr %509, align 1, !tbaa !40
  br label %510

510:                                              ; preds = %506, %499
  %511 = add nsw i64 %440, 3
  %512 = load ptr, ptr %4, align 8, !tbaa !9
  %513 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %512, i64 4
  %514 = load ptr, ptr %513, align 8, !tbaa !40
  %515 = ptrtoint ptr %514 to i64
  %516 = icmp slt i64 %511, %515
  br i1 %516, label %517, label %521

517:                                              ; preds = %510
  %518 = add i64 %440, 67
  %519 = load ptr, ptr %5, align 8, !tbaa !14
  %520 = getelementptr inbounds [64 x i8], ptr %519, i64 0, i64 %518
  store i8 -128, ptr %520, align 1, !tbaa !40
  br label %521

521:                                              ; preds = %517, %510
  %522 = add nsw i64 %440, 4
  %523 = load ptr, ptr %4, align 8, !tbaa !9
  %524 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %523, i64 4
  %525 = load ptr, ptr %524, align 8, !tbaa !40
  %526 = ptrtoint ptr %525 to i64
  %527 = icmp slt i64 %522, %526
  br i1 %527, label %528, label %532

528:                                              ; preds = %521
  %529 = add i64 %440, 68
  %530 = load ptr, ptr %5, align 8, !tbaa !14
  %531 = getelementptr inbounds [64 x i8], ptr %530, i64 0, i64 %529
  store i8 -128, ptr %531, align 1, !tbaa !40
  br label %532

532:                                              ; preds = %528, %521
  %533 = add nsw i64 %440, 5
  %534 = load ptr, ptr %4, align 8, !tbaa !9
  %535 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %534, i64 4
  %536 = load ptr, ptr %535, align 8, !tbaa !40
  %537 = ptrtoint ptr %536 to i64
  %538 = icmp slt i64 %533, %537
  br i1 %538, label %539, label %543

539:                                              ; preds = %532
  %540 = add i64 %440, 69
  %541 = load ptr, ptr %5, align 8, !tbaa !14
  %542 = getelementptr inbounds [64 x i8], ptr %541, i64 0, i64 %540
  store i8 -128, ptr %542, align 1, !tbaa !40
  br label %543

543:                                              ; preds = %539, %532
  %544 = add nsw i64 %440, 6
  %545 = load ptr, ptr %4, align 8, !tbaa !9
  %546 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %545, i64 4
  %547 = load ptr, ptr %546, align 8, !tbaa !40
  %548 = ptrtoint ptr %547 to i64
  %549 = icmp slt i64 %544, %548
  br i1 %549, label %550, label %554

550:                                              ; preds = %543
  %551 = add i64 %440, 70
  %552 = load ptr, ptr %5, align 8, !tbaa !14
  %553 = getelementptr inbounds [64 x i8], ptr %552, i64 0, i64 %551
  store i8 -128, ptr %553, align 1, !tbaa !40
  br label %554

554:                                              ; preds = %550, %543
  %555 = add nsw i64 %440, 7
  %556 = load ptr, ptr %4, align 8, !tbaa !9
  %557 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %556, i64 4
  %558 = load ptr, ptr %557, align 8, !tbaa !40
  %559 = ptrtoint ptr %558 to i64
  %560 = icmp slt i64 %555, %559
  br i1 %560, label %561, label %565

561:                                              ; preds = %554
  %562 = add i64 %440, 71
  %563 = load ptr, ptr %5, align 8, !tbaa !14
  %564 = getelementptr inbounds [64 x i8], ptr %563, i64 0, i64 %562
  store i8 -128, ptr %564, align 1, !tbaa !40
  br label %565

565:                                              ; preds = %554, %561, %472
  %566 = load ptr, ptr %4, align 8, !tbaa !9
  %567 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %566, i64 3, i32 1
  %568 = load i8, ptr %567, align 8, !tbaa !47
  %569 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %566, i64 4
  %570 = load ptr, ptr %569, align 8, !tbaa !40
  %571 = ptrtoint ptr %570 to i64
  %572 = icmp slt i64 %373, %571
  %573 = icmp eq i8 %568, 0
  %574 = select i1 %572, i1 true, i1 %573
  br i1 %574, label %879, label %575

575:                                              ; preds = %565
  %576 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %566, i64 3
  %577 = load ptr, ptr %576, align 8, !tbaa !40
  %578 = icmp eq i8 %568, 4
  %579 = call i64 @llvm.fshl.i64(i64 %374, i64 %374, i64 61)
  switch i64 %579, label %879 [
    i64 0, label %580
    i64 1, label %587
    i64 2, label %594
    i64 3, label %601
    i64 4, label %608
    i64 5, label %613
    i64 6, label %618
    i64 7, label %624
  ]

580:                                              ; preds = %575
  br i1 %578, label %581, label %583

581:                                              ; preds = %580
  %582 = load ptr, ptr %107, align 8, !tbaa !44
  store ptr %577, ptr %582, align 8, !tbaa !52
  br label %583

583:                                              ; preds = %581, %580
  %584 = load ptr, ptr %108, align 8, !tbaa !42
  store i8 %568, ptr %584, align 1, !tbaa !40
  %585 = add i64 %373, 56
  %586 = call i64 @llvm.fshl.i64(i64 %585, i64 %585, i64 61)
  switch i64 %586, label %879 [
    i64 0, label %587
    i64 1, label %594
    i64 2, label %601
    i64 3, label %608
    i64 4, label %613
    i64 5, label %618
    i64 6, label %624
  ]

587:                                              ; preds = %575, %583
  br i1 %578, label %588, label %590

588:                                              ; preds = %587
  %589 = load ptr, ptr %109, align 8, !tbaa !44
  store ptr %577, ptr %589, align 8, !tbaa !52
  br label %590

590:                                              ; preds = %588, %587
  %591 = load ptr, ptr %110, align 8, !tbaa !42
  store i8 %568, ptr %591, align 1, !tbaa !40
  %592 = add i64 %373, 48
  %593 = call i64 @llvm.fshl.i64(i64 %592, i64 %592, i64 61)
  switch i64 %593, label %879 [
    i64 0, label %594
    i64 1, label %601
    i64 2, label %608
    i64 3, label %613
    i64 4, label %618
    i64 5, label %624
  ]

594:                                              ; preds = %575, %583, %590
  br i1 %578, label %595, label %597

595:                                              ; preds = %594
  %596 = load ptr, ptr %111, align 8, !tbaa !44
  store ptr %577, ptr %596, align 8, !tbaa !52
  br label %597

597:                                              ; preds = %595, %594
  %598 = load ptr, ptr %112, align 8, !tbaa !42
  store i8 %568, ptr %598, align 1, !tbaa !40
  %599 = add i64 %373, 40
  %600 = call i64 @llvm.fshl.i64(i64 %599, i64 %599, i64 61)
  switch i64 %600, label %879 [
    i64 0, label %601
    i64 1, label %608
    i64 2, label %613
    i64 3, label %618
    i64 4, label %624
  ]

601:                                              ; preds = %575, %583, %590, %597
  br i1 %578, label %602, label %604

602:                                              ; preds = %601
  %603 = load ptr, ptr %113, align 8, !tbaa !44
  store ptr %577, ptr %603, align 8, !tbaa !52
  br label %604

604:                                              ; preds = %602, %601
  %605 = load ptr, ptr %114, align 8, !tbaa !42
  store i8 %568, ptr %605, align 1, !tbaa !40
  %606 = add i64 %373, 32
  %607 = call i64 @llvm.fshl.i64(i64 %606, i64 %606, i64 61)
  switch i64 %607, label %879 [
    i64 0, label %608
    i64 1, label %613
    i64 2, label %618
    i64 3, label %624
  ]

608:                                              ; preds = %575, %583, %590, %597, %604
  br i1 %578, label %609, label %611

609:                                              ; preds = %608
  %610 = load ptr, ptr %115, align 8, !tbaa !44
  store ptr %577, ptr %610, align 8, !tbaa !52
  br label %611

611:                                              ; preds = %609, %608
  %612 = load ptr, ptr %116, align 8, !tbaa !42
  store i8 %568, ptr %612, align 1, !tbaa !40
  switch i64 %373, label %879 [
    i64 -24, label %613
    i64 -16, label %618
    i64 -8, label %624
  ]

613:                                              ; preds = %575, %583, %590, %597, %604, %611
  br i1 %578, label %614, label %616

614:                                              ; preds = %613
  %615 = load ptr, ptr %117, align 8, !tbaa !44
  store ptr %577, ptr %615, align 8, !tbaa !52
  br label %616

616:                                              ; preds = %614, %613
  %617 = load ptr, ptr %118, align 8, !tbaa !42
  store i8 %568, ptr %617, align 1, !tbaa !40
  switch i64 %373, label %879 [
    i64 -16, label %618
    i64 -8, label %624
  ]

618:                                              ; preds = %575, %583, %590, %597, %604, %611, %616
  br i1 %578, label %619, label %621

619:                                              ; preds = %618
  %620 = load ptr, ptr %119, align 8, !tbaa !44
  store ptr %577, ptr %620, align 8, !tbaa !52
  br label %621

621:                                              ; preds = %619, %618
  %622 = load ptr, ptr %120, align 8, !tbaa !42
  store i8 %568, ptr %622, align 1, !tbaa !40
  %623 = icmp eq i64 %374, 56
  br i1 %623, label %624, label %879

624:                                              ; preds = %575, %583, %590, %597, %604, %611, %616, %621
  br i1 %578, label %625, label %627

625:                                              ; preds = %624
  %626 = load ptr, ptr %121, align 8, !tbaa !44
  store ptr %577, ptr %626, align 8, !tbaa !52
  br label %627

627:                                              ; preds = %625, %624
  %628 = load ptr, ptr %122, align 8, !tbaa !42
  store i8 %568, ptr %628, align 1, !tbaa !40
  br label %879

629:                                              ; preds = %370
  %630 = add i64 %306, %371
  %631 = inttoptr i64 %630 to ptr
  %632 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %307, i64 %266, i32 1
  %633 = load i8, ptr %632, align 8, !tbaa !47
  %634 = icmp eq i8 %633, 4
  br i1 %634, label %635, label %704

635:                                              ; preds = %629
  %636 = load ptr, ptr %5, align 8, !tbaa !14
  %637 = ptrtoint ptr %636 to i64
  %638 = sub i64 %630, %637
  %639 = add i64 %638, 7
  %640 = icmp ult i64 %639, 15
  br i1 %640, label %641, label %644

641:                                              ; preds = %635
  %642 = load ptr, ptr %59, align 8, !tbaa !42
  store i8 0, ptr %642, align 1, !tbaa !40
  %643 = load ptr, ptr %60, align 8, !tbaa !44
  store ptr null, ptr %643, align 8, !tbaa !52
  br label %644

644:                                              ; preds = %641, %635
  %645 = and i64 %638, -8
  %646 = icmp eq i64 %645, 8
  %647 = add i64 %638, -1
  %648 = icmp ult i64 %647, 8
  %649 = or i1 %646, %648
  br i1 %649, label %650, label %653

650:                                              ; preds = %644
  %651 = load ptr, ptr %61, align 8, !tbaa !42
  store i8 0, ptr %651, align 1, !tbaa !40
  %652 = load ptr, ptr %62, align 8, !tbaa !44
  store ptr null, ptr %652, align 8, !tbaa !52
  br label %653

653:                                              ; preds = %650, %644
  %654 = and i64 %638, -8
  %655 = icmp eq i64 %654, 16
  %656 = add i64 %638, -9
  %657 = icmp ult i64 %656, 8
  %658 = or i1 %655, %657
  br i1 %658, label %659, label %662

659:                                              ; preds = %653
  %660 = load ptr, ptr %63, align 8, !tbaa !42
  store i8 0, ptr %660, align 1, !tbaa !40
  %661 = load ptr, ptr %64, align 8, !tbaa !44
  store ptr null, ptr %661, align 8, !tbaa !52
  br label %662

662:                                              ; preds = %659, %653
  %663 = and i64 %638, -8
  %664 = icmp eq i64 %663, 24
  %665 = add i64 %638, -17
  %666 = icmp ult i64 %665, 8
  %667 = or i1 %664, %666
  br i1 %667, label %668, label %671

668:                                              ; preds = %662
  %669 = load ptr, ptr %65, align 8, !tbaa !42
  store i8 0, ptr %669, align 1, !tbaa !40
  %670 = load ptr, ptr %66, align 8, !tbaa !44
  store ptr null, ptr %670, align 8, !tbaa !52
  br label %671

671:                                              ; preds = %668, %662
  %672 = and i64 %638, -8
  %673 = icmp eq i64 %672, 32
  %674 = add i64 %638, -25
  %675 = icmp ult i64 %674, 8
  %676 = or i1 %673, %675
  br i1 %676, label %677, label %680

677:                                              ; preds = %671
  %678 = load ptr, ptr %67, align 8, !tbaa !42
  store i8 0, ptr %678, align 1, !tbaa !40
  %679 = load ptr, ptr %68, align 8, !tbaa !44
  store ptr null, ptr %679, align 8, !tbaa !52
  br label %680

680:                                              ; preds = %677, %671
  %681 = and i64 %638, -8
  %682 = icmp eq i64 %681, 40
  %683 = add i64 %638, -33
  %684 = icmp ult i64 %683, 8
  %685 = or i1 %682, %684
  br i1 %685, label %686, label %689

686:                                              ; preds = %680
  %687 = load ptr, ptr %69, align 8, !tbaa !42
  store i8 0, ptr %687, align 1, !tbaa !40
  %688 = load ptr, ptr %70, align 8, !tbaa !44
  store ptr null, ptr %688, align 8, !tbaa !52
  br label %689

689:                                              ; preds = %686, %680
  %690 = and i64 %638, -8
  %691 = icmp eq i64 %690, 48
  %692 = add i64 %638, -41
  %693 = icmp ult i64 %692, 8
  %694 = or i1 %691, %693
  br i1 %694, label %695, label %698

695:                                              ; preds = %689
  %696 = load ptr, ptr %71, align 8, !tbaa !42
  store i8 0, ptr %696, align 1, !tbaa !40
  %697 = load ptr, ptr %72, align 8, !tbaa !44
  store ptr null, ptr %697, align 8, !tbaa !52
  br label %698

698:                                              ; preds = %695, %689
  %699 = and i64 %638, -8
  %700 = icmp eq i64 %699, 56
  %701 = add i64 %638, -49
  %702 = icmp ult i64 %701, 8
  %703 = or i1 %700, %702
  br i1 %703, label %721, label %724

704:                                              ; preds = %629
  %705 = icmp eq i8 %633, 0
  br i1 %705, label %706, label %724

706:                                              ; preds = %704
  %707 = load ptr, ptr %45, align 8, !tbaa !42
  store i8 0, ptr %707, align 1, !tbaa !40
  %708 = load ptr, ptr %46, align 8, !tbaa !44
  store ptr null, ptr %708, align 8, !tbaa !52
  %709 = load ptr, ptr %47, align 8, !tbaa !42
  store i8 0, ptr %709, align 1, !tbaa !40
  %710 = load ptr, ptr %48, align 8, !tbaa !44
  store ptr null, ptr %710, align 8, !tbaa !52
  %711 = load ptr, ptr %49, align 8, !tbaa !42
  store i8 0, ptr %711, align 1, !tbaa !40
  %712 = load ptr, ptr %50, align 8, !tbaa !44
  store ptr null, ptr %712, align 8, !tbaa !52
  %713 = load ptr, ptr %51, align 8, !tbaa !42
  store i8 0, ptr %713, align 1, !tbaa !40
  %714 = load ptr, ptr %52, align 8, !tbaa !44
  store ptr null, ptr %714, align 8, !tbaa !52
  %715 = load ptr, ptr %53, align 8, !tbaa !42
  store i8 0, ptr %715, align 1, !tbaa !40
  %716 = load ptr, ptr %54, align 8, !tbaa !44
  store ptr null, ptr %716, align 8, !tbaa !52
  %717 = load ptr, ptr %55, align 8, !tbaa !42
  store i8 0, ptr %717, align 1, !tbaa !40
  %718 = load ptr, ptr %56, align 8, !tbaa !44
  store ptr null, ptr %718, align 8, !tbaa !52
  %719 = load ptr, ptr %57, align 8, !tbaa !42
  store i8 0, ptr %719, align 1, !tbaa !40
  %720 = load ptr, ptr %58, align 8, !tbaa !44
  store ptr null, ptr %720, align 8, !tbaa !52
  br label %721

721:                                              ; preds = %698, %706
  %722 = load ptr, ptr %73, align 8, !tbaa !42
  store i8 0, ptr %722, align 1, !tbaa !40
  %723 = load ptr, ptr %74, align 8, !tbaa !44
  store ptr null, ptr %723, align 8, !tbaa !52
  br label %724

724:                                              ; preds = %721, %698, %704
  store volatile i64 %298, ptr %631, align 1, !tbaa !40
  br i1 %634, label %725, label %806

725:                                              ; preds = %724
  %726 = load ptr, ptr %5, align 8, !tbaa !14
  %727 = ptrtoint ptr %726 to i64
  %728 = add i64 %630, -64
  %729 = sub i64 %728, %727
  %730 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %729) #7, !srcloc !53
  %731 = load ptr, ptr %4, align 8, !tbaa !9
  %732 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %731, i64 4
  %733 = load ptr, ptr %732, align 8, !tbaa !40
  %734 = ptrtoint ptr %733 to i64
  %735 = icmp slt i64 %730, %734
  br i1 %735, label %736, label %806

736:                                              ; preds = %725
  %737 = load ptr, ptr %4, align 8, !tbaa !9
  %738 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %737, i64 4
  %739 = load ptr, ptr %738, align 8, !tbaa !40
  %740 = ptrtoint ptr %739 to i64
  %741 = icmp slt i64 %730, %740
  br i1 %741, label %742, label %743

742:                                              ; preds = %736
  store i8 -128, ptr %631, align 1, !tbaa !40
  br label %743

743:                                              ; preds = %742, %736
  %744 = add nsw i64 %730, 1
  %745 = load ptr, ptr %4, align 8, !tbaa !9
  %746 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %745, i64 4
  %747 = load ptr, ptr %746, align 8, !tbaa !40
  %748 = ptrtoint ptr %747 to i64
  %749 = icmp slt i64 %744, %748
  br i1 %749, label %750, label %752

750:                                              ; preds = %743
  %751 = getelementptr inbounds i8, ptr %631, i64 1
  store i8 -128, ptr %751, align 1, !tbaa !40
  br label %752

752:                                              ; preds = %750, %743
  %753 = add nsw i64 %730, 2
  %754 = load ptr, ptr %4, align 8, !tbaa !9
  %755 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %754, i64 4
  %756 = load ptr, ptr %755, align 8, !tbaa !40
  %757 = ptrtoint ptr %756 to i64
  %758 = icmp slt i64 %753, %757
  br i1 %758, label %759, label %761

759:                                              ; preds = %752
  %760 = getelementptr inbounds i8, ptr %631, i64 2
  store i8 -128, ptr %760, align 1, !tbaa !40
  br label %761

761:                                              ; preds = %759, %752
  %762 = add nsw i64 %730, 3
  %763 = load ptr, ptr %4, align 8, !tbaa !9
  %764 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %763, i64 4
  %765 = load ptr, ptr %764, align 8, !tbaa !40
  %766 = ptrtoint ptr %765 to i64
  %767 = icmp slt i64 %762, %766
  br i1 %767, label %768, label %770

768:                                              ; preds = %761
  %769 = getelementptr inbounds i8, ptr %631, i64 3
  store i8 -128, ptr %769, align 1, !tbaa !40
  br label %770

770:                                              ; preds = %768, %761
  %771 = add nsw i64 %730, 4
  %772 = load ptr, ptr %4, align 8, !tbaa !9
  %773 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %772, i64 4
  %774 = load ptr, ptr %773, align 8, !tbaa !40
  %775 = ptrtoint ptr %774 to i64
  %776 = icmp slt i64 %771, %775
  br i1 %776, label %777, label %779

777:                                              ; preds = %770
  %778 = getelementptr inbounds i8, ptr %631, i64 4
  store i8 -128, ptr %778, align 1, !tbaa !40
  br label %779

779:                                              ; preds = %777, %770
  %780 = add nsw i64 %730, 5
  %781 = load ptr, ptr %4, align 8, !tbaa !9
  %782 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %781, i64 4
  %783 = load ptr, ptr %782, align 8, !tbaa !40
  %784 = ptrtoint ptr %783 to i64
  %785 = icmp slt i64 %780, %784
  br i1 %785, label %786, label %788

786:                                              ; preds = %779
  %787 = getelementptr inbounds i8, ptr %631, i64 5
  store i8 -128, ptr %787, align 1, !tbaa !40
  br label %788

788:                                              ; preds = %786, %779
  %789 = add nsw i64 %730, 6
  %790 = load ptr, ptr %4, align 8, !tbaa !9
  %791 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %790, i64 4
  %792 = load ptr, ptr %791, align 8, !tbaa !40
  %793 = ptrtoint ptr %792 to i64
  %794 = icmp slt i64 %789, %793
  br i1 %794, label %795, label %797

795:                                              ; preds = %788
  %796 = getelementptr inbounds i8, ptr %631, i64 6
  store i8 -128, ptr %796, align 1, !tbaa !40
  br label %797

797:                                              ; preds = %795, %788
  %798 = add nsw i64 %730, 7
  %799 = load ptr, ptr %4, align 8, !tbaa !9
  %800 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %799, i64 4
  %801 = load ptr, ptr %800, align 8, !tbaa !40
  %802 = ptrtoint ptr %801 to i64
  %803 = icmp slt i64 %798, %802
  br i1 %803, label %804, label %806

804:                                              ; preds = %797
  %805 = getelementptr inbounds i8, ptr %631, i64 7
  store i8 -128, ptr %805, align 1, !tbaa !40
  br label %806

806:                                              ; preds = %797, %804, %725, %724
  %807 = load ptr, ptr %4, align 8, !tbaa !9
  %808 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %807, i64 %266, i32 1
  %809 = load i8, ptr %808, align 8, !tbaa !47
  %810 = icmp eq i8 %809, 4
  br i1 %810, label %811, label %879

811:                                              ; preds = %806
  %812 = load ptr, ptr %5, align 8, !tbaa !14
  %813 = ptrtoint ptr %812 to i64
  %814 = sub i64 %630, %813
  %815 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %807, i64 3, i32 1
  %816 = load i8, ptr %815, align 8, !tbaa !47
  %817 = add nsw i64 %814, -64
  %818 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %807, i64 4
  %819 = load ptr, ptr %818, align 8, !tbaa !40
  %820 = ptrtoint ptr %819 to i64
  %821 = icmp slt i64 %817, %820
  %822 = icmp eq i8 %816, 0
  %823 = select i1 %821, i1 true, i1 %822
  br i1 %823, label %879, label %824

824:                                              ; preds = %811
  %825 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %807, i64 3
  %826 = load ptr, ptr %825, align 8, !tbaa !40
  %827 = icmp eq i8 %816, 4
  %828 = icmp eq i64 %630, %813
  br i1 %828, label %829, label %834

829:                                              ; preds = %824
  br i1 %827, label %830, label %832

830:                                              ; preds = %829
  %831 = load ptr, ptr %75, align 8, !tbaa !44
  store ptr %826, ptr %831, align 8, !tbaa !52
  br label %832

832:                                              ; preds = %830, %829
  %833 = load ptr, ptr %76, align 8, !tbaa !42
  store i8 %816, ptr %833, align 1, !tbaa !40
  br label %834

834:                                              ; preds = %832, %824
  %835 = add i64 %814, -8
  %836 = call i64 @llvm.fshl.i64(i64 %835, i64 %835, i64 61)
  switch i64 %836, label %879 [
    i64 0, label %837
    i64 1, label %844
    i64 2, label %851
    i64 3, label %858
    i64 4, label %863
    i64 5, label %868
    i64 6, label %874
  ]

837:                                              ; preds = %834
  br i1 %827, label %838, label %840

838:                                              ; preds = %837
  %839 = load ptr, ptr %77, align 8, !tbaa !44
  store ptr %826, ptr %839, align 8, !tbaa !52
  br label %840

840:                                              ; preds = %838, %837
  %841 = load ptr, ptr %78, align 8, !tbaa !42
  store i8 %816, ptr %841, align 1, !tbaa !40
  %842 = add i64 %814, -16
  %843 = call i64 @llvm.fshl.i64(i64 %842, i64 %842, i64 61)
  switch i64 %843, label %879 [
    i64 0, label %844
    i64 1, label %851
    i64 2, label %858
    i64 3, label %863
    i64 4, label %868
    i64 5, label %874
  ]

844:                                              ; preds = %834, %840
  br i1 %827, label %845, label %847

845:                                              ; preds = %844
  %846 = load ptr, ptr %79, align 8, !tbaa !44
  store ptr %826, ptr %846, align 8, !tbaa !52
  br label %847

847:                                              ; preds = %845, %844
  %848 = load ptr, ptr %80, align 8, !tbaa !42
  store i8 %816, ptr %848, align 1, !tbaa !40
  %849 = add i64 %814, -24
  %850 = call i64 @llvm.fshl.i64(i64 %849, i64 %849, i64 61)
  switch i64 %850, label %879 [
    i64 0, label %851
    i64 1, label %858
    i64 2, label %863
    i64 3, label %868
    i64 4, label %874
  ]

851:                                              ; preds = %834, %840, %847
  br i1 %827, label %852, label %854

852:                                              ; preds = %851
  %853 = load ptr, ptr %81, align 8, !tbaa !44
  store ptr %826, ptr %853, align 8, !tbaa !52
  br label %854

854:                                              ; preds = %852, %851
  %855 = load ptr, ptr %82, align 8, !tbaa !42
  store i8 %816, ptr %855, align 1, !tbaa !40
  %856 = add i64 %814, -32
  %857 = call i64 @llvm.fshl.i64(i64 %856, i64 %856, i64 61)
  switch i64 %857, label %879 [
    i64 0, label %858
    i64 1, label %863
    i64 2, label %868
    i64 3, label %874
  ]

858:                                              ; preds = %834, %840, %847, %854
  br i1 %827, label %859, label %861

859:                                              ; preds = %858
  %860 = load ptr, ptr %83, align 8, !tbaa !44
  store ptr %826, ptr %860, align 8, !tbaa !52
  br label %861

861:                                              ; preds = %859, %858
  %862 = load ptr, ptr %84, align 8, !tbaa !42
  store i8 %816, ptr %862, align 1, !tbaa !40
  switch i64 %814, label %879 [
    i64 40, label %863
    i64 48, label %868
    i64 56, label %874
  ]

863:                                              ; preds = %834, %840, %847, %854, %861
  br i1 %827, label %864, label %866

864:                                              ; preds = %863
  %865 = load ptr, ptr %85, align 8, !tbaa !44
  store ptr %826, ptr %865, align 8, !tbaa !52
  br label %866

866:                                              ; preds = %864, %863
  %867 = load ptr, ptr %86, align 8, !tbaa !42
  store i8 %816, ptr %867, align 1, !tbaa !40
  switch i64 %814, label %879 [
    i64 48, label %868
    i64 56, label %874
  ]

868:                                              ; preds = %834, %840, %847, %854, %861, %866
  br i1 %827, label %869, label %871

869:                                              ; preds = %868
  %870 = load ptr, ptr %87, align 8, !tbaa !44
  store ptr %826, ptr %870, align 8, !tbaa !52
  br label %871

871:                                              ; preds = %869, %868
  %872 = load ptr, ptr %88, align 8, !tbaa !42
  store i8 %816, ptr %872, align 1, !tbaa !40
  %873 = icmp eq i64 %814, 56
  br i1 %873, label %874, label %879

874:                                              ; preds = %834, %840, %847, %854, %861, %866, %871
  br i1 %827, label %875, label %877

875:                                              ; preds = %874
  %876 = load ptr, ptr %89, align 8, !tbaa !44
  store ptr %826, ptr %876, align 8, !tbaa !52
  br label %877

877:                                              ; preds = %875, %874
  %878 = load ptr, ptr %90, align 8, !tbaa !42
  store i8 %816, ptr %878, align 1, !tbaa !40
  br label %879

879:                                              ; preds = %871, %877, %866, %861, %854, %847, %840, %834, %621, %627, %616, %611, %604, %597, %590, %583, %575, %324, %349, %565, %806, %811
  %880 = load ptr, ptr %38, align 8
  %881 = ptrtoint ptr %880 to i64
  %882 = icmp slt i64 %236, %881
  br i1 %882, label %895, label %883

883:                                              ; preds = %879
  %884 = load i8, ptr %139, align 1
  %885 = icmp eq i8 %884, 4
  %886 = load ptr, ptr %140, align 8
  %887 = select i1 %885, ptr %886, ptr null
  %888 = select i1 %239, i8 %884, i8 0
  %889 = select i1 %239, ptr %887, ptr null
  br i1 %240, label %890, label %895

890:                                              ; preds = %883
  %891 = load i8, ptr %141, align 1, !tbaa !40
  switch i8 %891, label %894 [
    i8 0, label %895
    i8 4, label %892
  ]

892:                                              ; preds = %890
  %893 = load ptr, ptr %142, align 8, !tbaa !52
  br label %895

894:                                              ; preds = %890
  br label %895

895:                                              ; preds = %883, %890, %892, %894, %879
  %896 = phi i8 [ 0, %879 ], [ %891, %892 ], [ %888, %890 ], [ %888, %883 ], [ %891, %894 ]
  %897 = phi ptr [ null, %879 ], [ %893, %892 ], [ %889, %890 ], [ %889, %883 ], [ %889, %894 ]
  %898 = zext i8 %896 to i32
  %899 = icmp eq i32 %228, %898
  br i1 %899, label %901, label %900

900:                                              ; preds = %895
  call void @__assert_fail(ptr noundef nonnull @.str.2, ptr noundef nonnull @.str.1, i32 noundef 38, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #6
  unreachable

901:                                              ; preds = %895
  %902 = load ptr, ptr %42, align 8
  %903 = icmp eq ptr %897, %902
  %904 = select i1 %230, i1 true, i1 %903
  br i1 %904, label %906, label %905

905:                                              ; preds = %901
  call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.1, i32 noundef 39, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #6
  unreachable

906:                                              ; preds = %901
  %907 = sub nsw i64 %236, %881
  %908 = select i1 %264, i64 %907, i64 0
  br i1 %264, label %928, label %909

909:                                              ; preds = %906
  %910 = load ptr, ptr %4, align 8, !tbaa !9
  %911 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %910, i64 %266, i32 1
  %912 = load i8, ptr %911, align 8, !tbaa !47
  %913 = icmp eq i8 %912, 0
  br i1 %913, label %914, label %922

914:                                              ; preds = %909
  %915 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %910, i64 %266
  %916 = load ptr, ptr %915, align 8, !tbaa !40
  %917 = ptrtoint ptr %916 to i64
  %918 = add i64 %908, %917
  %919 = icmp ult i64 %918, 4096
  br i1 %919, label %920, label %922

920:                                              ; preds = %914
  %921 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr null, ptr %921, align 8, !tbaa !40
  br label %1383

922:                                              ; preds = %914, %909
  br i1 %264, label %928, label %923

923:                                              ; preds = %922
  %924 = load ptr, ptr %4, align 8, !tbaa !9
  %925 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %924, i64 %266, i32 1
  %926 = load i8, ptr %925, align 8, !tbaa !47
  %927 = icmp eq i8 %926, 1
  br label %928

928:                                              ; preds = %906, %923, %922
  %929 = phi i1 [ false, %922 ], [ %927, %923 ], [ false, %906 ]
  %930 = load ptr, ptr %4, align 8, !tbaa !9
  %931 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %930, i64 %266
  %932 = load ptr, ptr %931, align 8, !tbaa !40
  %933 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %930, i64 %266, i32 1
  %934 = load i8, ptr %933, align 8, !tbaa !47
  %935 = icmp eq i8 %934, 1
  br i1 %935, label %938, label %936

936:                                              ; preds = %928
  %937 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %908) #7, !srcloc !54
  br label %938

938:                                              ; preds = %936, %928
  %939 = phi i64 [ %937, %936 ], [ %908, %928 ]
  %940 = ptrtoint ptr %932 to i64
  %941 = add i64 %939, %940
  %942 = load i8, ptr %36, align 1, !tbaa !39
  %943 = icmp eq i8 %942, 1
  br i1 %943, label %944, label %1018

944:                                              ; preds = %938
  %945 = load ptr, ptr %4, align 8, !tbaa !9
  %946 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %945, i64 %266, i32 1
  %947 = load i8, ptr %946, align 8, !tbaa !47
  %948 = icmp eq i8 %947, 1
  br i1 %948, label %949, label %1018

949:                                              ; preds = %944
  %950 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %945, i64 %266
  %951 = load ptr, ptr %950, align 8, !tbaa !40
  %952 = ptrtoint ptr %951 to i64
  %953 = load ptr, ptr %30, align 8, !tbaa !33
  %954 = ptrtoint ptr %953 to i64
  %955 = sub i64 %952, %954
  %956 = add i64 %955, %939
  %957 = load ptr, ptr %28, align 8, !tbaa !31
  %958 = icmp eq i64 %956, 208
  switch i64 %956, label %966 [
    i64 208, label %959
    i64 80, label %959
  ]

959:                                              ; preds = %949, %949
  %960 = icmp sgt i64 %956, 207
  %961 = getelementptr inbounds %struct.__sk_buff, ptr %957, i64 0, i32 15
  %962 = getelementptr inbounds %struct.__sk_buff, ptr %957, i64 0, i32 16
  %963 = select i1 %960, ptr %961, ptr %962
  %964 = load i32, ptr %963, align 4, !tbaa !55
  %965 = zext i32 %964 to i64
  br label %1011

966:                                              ; preds = %949
  %967 = add i64 %956, -48
  %968 = icmp ult i64 %967, 13
  br i1 %968, label %969, label %1008

969:                                              ; preds = %966
  %970 = getelementptr inbounds i8, ptr %957, i64 %956
  %971 = load volatile i8, ptr %970, align 1, !tbaa !40
  %972 = zext i8 %971 to i64
  %973 = getelementptr inbounds i8, ptr %970, i64 1
  %974 = load volatile i8, ptr %973, align 1, !tbaa !40
  %975 = zext i8 %974 to i64
  %976 = shl nuw nsw i64 %975, 8
  %977 = or disjoint i64 %976, %972
  %978 = getelementptr inbounds i8, ptr %970, i64 2
  %979 = load volatile i8, ptr %978, align 1, !tbaa !40
  %980 = zext i8 %979 to i64
  %981 = shl nuw nsw i64 %980, 16
  %982 = or disjoint i64 %977, %981
  %983 = getelementptr inbounds i8, ptr %970, i64 3
  %984 = load volatile i8, ptr %983, align 1, !tbaa !40
  %985 = zext i8 %984 to i64
  %986 = shl nuw nsw i64 %985, 24
  %987 = or disjoint i64 %982, %986
  %988 = getelementptr inbounds i8, ptr %970, i64 4
  %989 = load volatile i8, ptr %988, align 1, !tbaa !40
  %990 = zext i8 %989 to i64
  %991 = shl nuw nsw i64 %990, 32
  %992 = or disjoint i64 %987, %991
  %993 = getelementptr inbounds i8, ptr %970, i64 5
  %994 = load volatile i8, ptr %993, align 1, !tbaa !40
  %995 = zext i8 %994 to i64
  %996 = shl nuw nsw i64 %995, 40
  %997 = or i64 %992, %996
  %998 = getelementptr inbounds i8, ptr %970, i64 6
  %999 = load volatile i8, ptr %998, align 1, !tbaa !40
  %1000 = zext i8 %999 to i64
  %1001 = shl nuw nsw i64 %1000, 48
  %1002 = or i64 %997, %1001
  %1003 = getelementptr inbounds i8, ptr %970, i64 7
  %1004 = load volatile i8, ptr %1003, align 1, !tbaa !40
  %1005 = zext i8 %1004 to i64
  %1006 = shl nuw i64 %1005, 56
  %1007 = or i64 %1002, %1006
  br label %1011

1008:                                             ; preds = %966
  %1009 = getelementptr inbounds i8, ptr %951, i64 %939
  %1010 = load volatile i64, ptr %1009, align 1, !tbaa !40
  br label %1011

1011:                                             ; preds = %1008, %969, %959
  %1012 = phi i64 [ %965, %959 ], [ %1007, %969 ], [ %1010, %1008 ]
  br i1 %929, label %1013, label %1373

1013:                                             ; preds = %1011
  %1014 = icmp eq i64 %956, 80
  %1015 = select i1 %1014, i8 3, i8 0
  %1016 = select i1 %958, i8 2, i8 %1015
  %1017 = inttoptr i64 %1012 to ptr
  br label %1373

1018:                                             ; preds = %944, %938
  %1019 = load i8, ptr %34, align 8, !tbaa !37
  %1020 = icmp eq i8 %1019, 0
  br i1 %1020, label %1058, label %1021

1021:                                             ; preds = %1018
  %1022 = load ptr, ptr %4, align 8, !tbaa !9
  %1023 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1022, i64 %266, i32 1
  %1024 = load i8, ptr %1023, align 8, !tbaa !47
  %1025 = icmp eq i8 %1024, 1
  br i1 %1025, label %1026, label %1058

1026:                                             ; preds = %1021
  %1027 = load ptr, ptr %30, align 8, !tbaa !33
  %1028 = ptrtoint ptr %1027 to i64
  %1029 = add i64 %939, %940
  %1030 = sub i64 %1029, %1028
  %1031 = load ptr, ptr %28, align 8, !tbaa !31
  switch i64 %1030, label %1043 [
    i64 0, label %1032
    i64 8, label %1035
    i64 16, label %1039
  ]

1032:                                             ; preds = %1026
  %1033 = load volatile i32, ptr %1031, align 4, !tbaa !56
  %1034 = zext i32 %1033 to i64
  br label %1046

1035:                                             ; preds = %1026
  %1036 = getelementptr inbounds %struct.xdp_md, ptr %1031, i64 0, i32 1
  %1037 = load volatile i32, ptr %1036, align 4, !tbaa !58
  %1038 = zext i32 %1037 to i64
  br label %1046

1039:                                             ; preds = %1026
  %1040 = getelementptr inbounds %struct.xdp_md, ptr %1031, i64 0, i32 2
  %1041 = load volatile i32, ptr %1040, align 4, !tbaa !59
  %1042 = zext i32 %1041 to i64
  br label %1046

1043:                                             ; preds = %1026
  %1044 = getelementptr inbounds i8, ptr %932, i64 %939
  %1045 = load volatile i64, ptr %1044, align 1, !tbaa !40
  br label %1046

1046:                                             ; preds = %1043, %1039, %1035, %1032
  %1047 = phi i64 [ %1034, %1032 ], [ %1038, %1035 ], [ %1042, %1039 ], [ %1045, %1043 ]
  %1048 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %1047) #7, !srcloc !60
  %1049 = load ptr, ptr %30, align 8, !tbaa !33
  %1050 = ptrtoint ptr %1049 to i64
  %1051 = sub i64 %940, %1050
  %1052 = add i64 %1051, %939
  %1053 = icmp eq i64 %1052, 8
  %1054 = select i1 %1053, i8 3, i8 0
  %1055 = icmp eq i64 %1052, 0
  %1056 = select i1 %1055, i8 2, i8 %1054
  %1057 = inttoptr i64 %1048 to ptr
  br label %1373

1058:                                             ; preds = %1021, %1018
  br i1 %264, label %1065, label %1059

1059:                                             ; preds = %1058
  %1060 = load ptr, ptr %4, align 8, !tbaa !9
  %1061 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1060, i64 %266, i32 1
  %1062 = load i8, ptr %1061, align 8, !tbaa !47
  %1063 = icmp eq i8 %1062, 1
  %1064 = select i1 %1063, i32 1, i32 2
  br label %1065

1065:                                             ; preds = %1059, %1058
  %1066 = phi i32 [ 0, %1058 ], [ %1064, %1059 ]
  switch i32 %1066, label %1243 [
    i32 0, label %1067
    i32 1, label %1218
  ]

1067:                                             ; preds = %1065
  %1068 = add i64 %941, 64
  %1069 = and i64 %941, 7
  %1070 = icmp eq i64 %1069, 0
  %1071 = load ptr, ptr %5, align 8, !tbaa !14
  br i1 %1070, label %1072, label %1076

1072:                                             ; preds = %1067
  %1073 = lshr exact i64 %1068, 3
  %1074 = getelementptr inbounds [8 x i64], ptr %1071, i64 0, i64 %1073
  %1075 = load volatile i64, ptr %1074, align 8, !tbaa !40
  br label %1116

1076:                                             ; preds = %1067
  %1077 = getelementptr inbounds i8, ptr %1071, i64 %1068
  %1078 = load i8, ptr %1077, align 1, !tbaa !40
  %1079 = zext i8 %1078 to i64
  %1080 = getelementptr i8, ptr %1071, i64 %941
  %1081 = getelementptr i8, ptr %1080, i64 65
  %1082 = load i8, ptr %1081, align 1, !tbaa !40
  %1083 = zext i8 %1082 to i64
  %1084 = shl nuw nsw i64 %1083, 8
  %1085 = or disjoint i64 %1084, %1079
  %1086 = getelementptr i8, ptr %1080, i64 66
  %1087 = load i8, ptr %1086, align 1, !tbaa !40
  %1088 = zext i8 %1087 to i64
  %1089 = shl nuw nsw i64 %1088, 16
  %1090 = or disjoint i64 %1085, %1089
  %1091 = getelementptr i8, ptr %1080, i64 67
  %1092 = load i8, ptr %1091, align 1, !tbaa !40
  %1093 = zext i8 %1092 to i64
  %1094 = shl nuw nsw i64 %1093, 24
  %1095 = or disjoint i64 %1090, %1094
  %1096 = getelementptr i8, ptr %1080, i64 68
  %1097 = load i8, ptr %1096, align 1, !tbaa !40
  %1098 = zext i8 %1097 to i64
  %1099 = shl nuw nsw i64 %1098, 32
  %1100 = or disjoint i64 %1095, %1099
  %1101 = getelementptr i8, ptr %1080, i64 69
  %1102 = load i8, ptr %1101, align 1, !tbaa !40
  %1103 = zext i8 %1102 to i64
  %1104 = shl nuw nsw i64 %1103, 40
  %1105 = or i64 %1100, %1104
  %1106 = getelementptr i8, ptr %1080, i64 70
  %1107 = load i8, ptr %1106, align 1, !tbaa !40
  %1108 = zext i8 %1107 to i64
  %1109 = shl nuw nsw i64 %1108, 48
  %1110 = or i64 %1105, %1109
  %1111 = getelementptr i8, ptr %1080, i64 71
  %1112 = load i8, ptr %1111, align 1, !tbaa !40
  %1113 = zext i8 %1112 to i64
  %1114 = shl nuw i64 %1113, 56
  %1115 = or i64 %1110, %1114
  br label %1116

1116:                                             ; preds = %1076, %1072
  %1117 = phi i64 [ %1075, %1072 ], [ %1115, %1076 ]
  %1118 = load ptr, ptr %4, align 8, !tbaa !9
  %1119 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1118, i64 4
  %1120 = load ptr, ptr %1119, align 8, !tbaa !40
  %1121 = ptrtoint ptr %1120 to i64
  %1122 = icmp slt i64 %941, %1121
  %1123 = select i1 %1122, i64 1161981756646125696, i64 %1117
  %1124 = add nsw i64 %908, %940
  %1125 = add i64 %1124, 64
  %1126 = icmp slt i64 %1124, %1121
  br i1 %1126, label %1213, label %1127

1127:                                             ; preds = %1116
  %1128 = icmp eq i64 %1125, 0
  br i1 %1128, label %1129, label %1136

1129:                                             ; preds = %1127
  %1130 = load ptr, ptr %143, align 8, !tbaa !42
  %1131 = load i8, ptr %1130, align 1, !tbaa !40
  %1132 = icmp eq i8 %1131, 4
  br i1 %1132, label %1133, label %1136

1133:                                             ; preds = %1129
  %1134 = load ptr, ptr %144, align 8, !tbaa !44
  %1135 = load ptr, ptr %1134, align 8, !tbaa !52
  br label %1136

1136:                                             ; preds = %1129, %1133, %1127
  %1137 = phi i8 [ %1131, %1133 ], [ 0, %1127 ], [ %1131, %1129 ]
  %1138 = phi ptr [ %1135, %1133 ], [ null, %1127 ], [ null, %1129 ]
  %1139 = icmp eq i64 %1125, 8
  br i1 %1139, label %1140, label %1147

1140:                                             ; preds = %1136
  %1141 = load ptr, ptr %145, align 8, !tbaa !42
  %1142 = load i8, ptr %1141, align 1, !tbaa !40
  switch i8 %1142, label %1146 [
    i8 0, label %1147
    i8 4, label %1143
  ]

1143:                                             ; preds = %1140
  %1144 = load ptr, ptr %146, align 8, !tbaa !44
  %1145 = load ptr, ptr %1144, align 8, !tbaa !52
  br label %1147

1146:                                             ; preds = %1140
  br label %1147

1147:                                             ; preds = %1146, %1143, %1140, %1136
  %1148 = phi i8 [ %1142, %1143 ], [ %1137, %1140 ], [ %1137, %1136 ], [ %1142, %1146 ]
  %1149 = phi ptr [ %1145, %1143 ], [ %1138, %1140 ], [ %1138, %1136 ], [ %1138, %1146 ]
  %1150 = icmp eq i64 %1125, 16
  br i1 %1150, label %1151, label %1158

1151:                                             ; preds = %1147
  %1152 = load ptr, ptr %147, align 8, !tbaa !42
  %1153 = load i8, ptr %1152, align 1, !tbaa !40
  switch i8 %1153, label %1157 [
    i8 0, label %1158
    i8 4, label %1154
  ]

1154:                                             ; preds = %1151
  %1155 = load ptr, ptr %148, align 8, !tbaa !44
  %1156 = load ptr, ptr %1155, align 8, !tbaa !52
  br label %1158

1157:                                             ; preds = %1151
  br label %1158

1158:                                             ; preds = %1157, %1154, %1151, %1147
  %1159 = phi i8 [ %1153, %1154 ], [ %1148, %1151 ], [ %1148, %1147 ], [ %1153, %1157 ]
  %1160 = phi ptr [ %1156, %1154 ], [ %1149, %1151 ], [ %1149, %1147 ], [ %1149, %1157 ]
  %1161 = icmp eq i64 %1125, 24
  br i1 %1161, label %1162, label %1169

1162:                                             ; preds = %1158
  %1163 = load ptr, ptr %149, align 8, !tbaa !42
  %1164 = load i8, ptr %1163, align 1, !tbaa !40
  switch i8 %1164, label %1168 [
    i8 0, label %1169
    i8 4, label %1165
  ]

1165:                                             ; preds = %1162
  %1166 = load ptr, ptr %150, align 8, !tbaa !44
  %1167 = load ptr, ptr %1166, align 8, !tbaa !52
  br label %1169

1168:                                             ; preds = %1162
  br label %1169

1169:                                             ; preds = %1168, %1165, %1162, %1158
  %1170 = phi i8 [ %1164, %1165 ], [ %1159, %1162 ], [ %1159, %1158 ], [ %1164, %1168 ]
  %1171 = phi ptr [ %1167, %1165 ], [ %1160, %1162 ], [ %1160, %1158 ], [ %1160, %1168 ]
  %1172 = icmp eq i64 %1125, 32
  br i1 %1172, label %1173, label %1180

1173:                                             ; preds = %1169
  %1174 = load ptr, ptr %151, align 8, !tbaa !42
  %1175 = load i8, ptr %1174, align 1, !tbaa !40
  switch i8 %1175, label %1179 [
    i8 0, label %1180
    i8 4, label %1176
  ]

1176:                                             ; preds = %1173
  %1177 = load ptr, ptr %152, align 8, !tbaa !44
  %1178 = load ptr, ptr %1177, align 8, !tbaa !52
  br label %1180

1179:                                             ; preds = %1173
  br label %1180

1180:                                             ; preds = %1179, %1176, %1173, %1169
  %1181 = phi i8 [ %1175, %1176 ], [ %1170, %1173 ], [ %1170, %1169 ], [ %1175, %1179 ]
  %1182 = phi ptr [ %1178, %1176 ], [ %1171, %1173 ], [ %1171, %1169 ], [ %1171, %1179 ]
  %1183 = icmp eq i64 %1125, 40
  br i1 %1183, label %1184, label %1191

1184:                                             ; preds = %1180
  %1185 = load ptr, ptr %153, align 8, !tbaa !42
  %1186 = load i8, ptr %1185, align 1, !tbaa !40
  switch i8 %1186, label %1190 [
    i8 0, label %1191
    i8 4, label %1187
  ]

1187:                                             ; preds = %1184
  %1188 = load ptr, ptr %154, align 8, !tbaa !44
  %1189 = load ptr, ptr %1188, align 8, !tbaa !52
  br label %1191

1190:                                             ; preds = %1184
  br label %1191

1191:                                             ; preds = %1190, %1187, %1184, %1180
  %1192 = phi i8 [ %1186, %1187 ], [ %1181, %1184 ], [ %1181, %1180 ], [ %1186, %1190 ]
  %1193 = phi ptr [ %1189, %1187 ], [ %1182, %1184 ], [ %1182, %1180 ], [ %1182, %1190 ]
  %1194 = icmp eq i64 %1125, 48
  br i1 %1194, label %1195, label %1202

1195:                                             ; preds = %1191
  %1196 = load ptr, ptr %155, align 8, !tbaa !42
  %1197 = load i8, ptr %1196, align 1, !tbaa !40
  switch i8 %1197, label %1201 [
    i8 0, label %1202
    i8 4, label %1198
  ]

1198:                                             ; preds = %1195
  %1199 = load ptr, ptr %156, align 8, !tbaa !44
  %1200 = load ptr, ptr %1199, align 8, !tbaa !52
  br label %1202

1201:                                             ; preds = %1195
  br label %1202

1202:                                             ; preds = %1201, %1198, %1195, %1191
  %1203 = phi i8 [ %1197, %1198 ], [ %1192, %1195 ], [ %1192, %1191 ], [ %1197, %1201 ]
  %1204 = phi ptr [ %1200, %1198 ], [ %1193, %1195 ], [ %1193, %1191 ], [ %1193, %1201 ]
  %1205 = icmp eq i64 %1125, 56
  br i1 %1205, label %1206, label %1213

1206:                                             ; preds = %1202
  %1207 = load ptr, ptr %157, align 8, !tbaa !42
  %1208 = load i8, ptr %1207, align 1, !tbaa !40
  switch i8 %1208, label %1212 [
    i8 0, label %1213
    i8 4, label %1209
  ]

1209:                                             ; preds = %1206
  %1210 = load ptr, ptr %158, align 8, !tbaa !44
  %1211 = load ptr, ptr %1210, align 8, !tbaa !52
  br label %1213

1212:                                             ; preds = %1206
  br label %1213

1213:                                             ; preds = %1202, %1206, %1209, %1212, %1116
  %1214 = phi i8 [ 0, %1116 ], [ %1208, %1209 ], [ %1203, %1206 ], [ %1203, %1202 ], [ %1208, %1212 ]
  %1215 = phi ptr [ null, %1116 ], [ %1211, %1209 ], [ %1204, %1206 ], [ %1204, %1202 ], [ %1204, %1212 ]
  switch i8 %1214, label %1216 [
    i8 0, label %1373
    i8 4, label %1372
  ]

1216:                                             ; preds = %1213
  %1217 = inttoptr i64 %1123 to ptr
  br label %1373

1218:                                             ; preds = %1065
  br i1 %929, label %1223, label %1219

1219:                                             ; preds = %1218
  %1220 = add i64 %908, %940
  %1221 = inttoptr i64 %1220 to ptr
  %1222 = load volatile i64, ptr %1221, align 1, !tbaa !40
  br label %1373

1223:                                             ; preds = %1218
  %1224 = icmp eq i8 %942, 0
  %1225 = icmp eq i64 %939, 0
  %1226 = select i1 %1224, i1 %1225, i1 false
  %1227 = icmp eq i64 %939, 208
  %1228 = select i1 %943, i1 %1227, i1 false
  %1229 = select i1 %1226, i1 true, i1 %1228
  br i1 %1229, label %1237, label %1230

1230:                                             ; preds = %1223
  %1231 = icmp eq i64 %939, 8
  %1232 = select i1 %1224, i1 %1231, i1 false
  %1233 = icmp eq i64 %939, 80
  %1234 = select i1 %943, i1 %1233, i1 false
  %1235 = select i1 %1232, i1 true, i1 %1234
  %1236 = select i1 %1235, i8 3, i8 0
  br label %1237

1237:                                             ; preds = %1230, %1223
  %1238 = phi i8 [ 2, %1223 ], [ %1236, %1230 ]
  %1239 = add i64 %908, %940
  %1240 = inttoptr i64 %1239 to ptr
  %1241 = load volatile i64, ptr %1240, align 1, !tbaa !40
  %1242 = inttoptr i64 %1241 to ptr
  br label %1373

1243:                                             ; preds = %1065
  %1244 = add i64 %908, %940
  %1245 = inttoptr i64 %1244 to ptr
  %1246 = load volatile i64, ptr %1245, align 1, !tbaa !40
  %1247 = load ptr, ptr %4, align 8, !tbaa !9
  %1248 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1247, i64 %266, i32 1
  %1249 = load i8, ptr %1248, align 8, !tbaa !47
  %1250 = icmp eq i8 %1249, 4
  br i1 %1250, label %1251, label %1263

1251:                                             ; preds = %1243
  %1252 = load ptr, ptr %5, align 8, !tbaa !14
  %1253 = ptrtoint ptr %1252 to i64
  %1254 = add i64 %1244, -64
  %1255 = sub i64 %1254, %1253
  %1256 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %1255) #7, !srcloc !61
  %1257 = load ptr, ptr %4, align 8, !tbaa !9
  %1258 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1257, i64 4
  %1259 = load ptr, ptr %1258, align 8, !tbaa !40
  %1260 = ptrtoint ptr %1259 to i64
  %1261 = icmp slt i64 %1256, %1260
  %1262 = select i1 %1261, i64 1161981756646125696, i64 %1246
  br label %1263

1263:                                             ; preds = %1251, %1243
  %1264 = phi i64 [ %1246, %1243 ], [ %1262, %1251 ]
  %1265 = load ptr, ptr %4, align 8, !tbaa !9
  %1266 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1265, i64 %266, i32 1
  %1267 = load i8, ptr %1266, align 8, !tbaa !47
  %1268 = icmp eq i8 %1267, 4
  br i1 %1268, label %1269, label %1364

1269:                                             ; preds = %1263
  %1270 = load ptr, ptr %5, align 8, !tbaa !14
  %1271 = ptrtoint ptr %1270 to i64
  %1272 = sub i64 %941, %1271
  %1273 = add nsw i64 %1272, -64
  %1274 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1265, i64 4
  %1275 = load ptr, ptr %1274, align 8, !tbaa !40
  %1276 = ptrtoint ptr %1275 to i64
  %1277 = icmp slt i64 %1273, %1276
  br i1 %1277, label %1364, label %1278

1278:                                             ; preds = %1269
  %1279 = icmp eq i64 %941, %1271
  br i1 %1279, label %1280, label %1287

1280:                                             ; preds = %1278
  %1281 = load ptr, ptr %159, align 8, !tbaa !42
  %1282 = load i8, ptr %1281, align 1, !tbaa !40
  %1283 = icmp eq i8 %1282, 4
  br i1 %1283, label %1284, label %1287

1284:                                             ; preds = %1280
  %1285 = load ptr, ptr %160, align 8, !tbaa !44
  %1286 = load ptr, ptr %1285, align 8, !tbaa !52
  br label %1287

1287:                                             ; preds = %1280, %1284, %1278
  %1288 = phi ptr [ %1286, %1284 ], [ null, %1278 ], [ null, %1280 ]
  %1289 = phi i8 [ %1282, %1284 ], [ 0, %1278 ], [ %1282, %1280 ]
  %1290 = icmp eq i64 %1272, 8
  br i1 %1290, label %1291, label %1298

1291:                                             ; preds = %1287
  %1292 = load ptr, ptr %161, align 8, !tbaa !42
  %1293 = load i8, ptr %1292, align 1, !tbaa !40
  switch i8 %1293, label %1297 [
    i8 0, label %1298
    i8 4, label %1294
  ]

1294:                                             ; preds = %1291
  %1295 = load ptr, ptr %162, align 8, !tbaa !44
  %1296 = load ptr, ptr %1295, align 8, !tbaa !52
  br label %1298

1297:                                             ; preds = %1291
  br label %1298

1298:                                             ; preds = %1297, %1294, %1291, %1287
  %1299 = phi ptr [ %1296, %1294 ], [ %1288, %1291 ], [ %1288, %1287 ], [ %1288, %1297 ]
  %1300 = phi i8 [ %1293, %1294 ], [ %1289, %1291 ], [ %1289, %1287 ], [ %1293, %1297 ]
  %1301 = icmp eq i64 %1272, 16
  br i1 %1301, label %1302, label %1309

1302:                                             ; preds = %1298
  %1303 = load ptr, ptr %163, align 8, !tbaa !42
  %1304 = load i8, ptr %1303, align 1, !tbaa !40
  switch i8 %1304, label %1308 [
    i8 0, label %1309
    i8 4, label %1305
  ]

1305:                                             ; preds = %1302
  %1306 = load ptr, ptr %164, align 8, !tbaa !44
  %1307 = load ptr, ptr %1306, align 8, !tbaa !52
  br label %1309

1308:                                             ; preds = %1302
  br label %1309

1309:                                             ; preds = %1308, %1305, %1302, %1298
  %1310 = phi ptr [ %1307, %1305 ], [ %1299, %1302 ], [ %1299, %1298 ], [ %1299, %1308 ]
  %1311 = phi i8 [ %1304, %1305 ], [ %1300, %1302 ], [ %1300, %1298 ], [ %1304, %1308 ]
  %1312 = icmp eq i64 %1272, 24
  br i1 %1312, label %1313, label %1320

1313:                                             ; preds = %1309
  %1314 = load ptr, ptr %165, align 8, !tbaa !42
  %1315 = load i8, ptr %1314, align 1, !tbaa !40
  switch i8 %1315, label %1319 [
    i8 0, label %1320
    i8 4, label %1316
  ]

1316:                                             ; preds = %1313
  %1317 = load ptr, ptr %166, align 8, !tbaa !44
  %1318 = load ptr, ptr %1317, align 8, !tbaa !52
  br label %1320

1319:                                             ; preds = %1313
  br label %1320

1320:                                             ; preds = %1319, %1316, %1313, %1309
  %1321 = phi ptr [ %1318, %1316 ], [ %1310, %1313 ], [ %1310, %1309 ], [ %1310, %1319 ]
  %1322 = phi i8 [ %1315, %1316 ], [ %1311, %1313 ], [ %1311, %1309 ], [ %1315, %1319 ]
  %1323 = icmp eq i64 %1272, 32
  br i1 %1323, label %1324, label %1331

1324:                                             ; preds = %1320
  %1325 = load ptr, ptr %167, align 8, !tbaa !42
  %1326 = load i8, ptr %1325, align 1, !tbaa !40
  switch i8 %1326, label %1330 [
    i8 0, label %1331
    i8 4, label %1327
  ]

1327:                                             ; preds = %1324
  %1328 = load ptr, ptr %168, align 8, !tbaa !44
  %1329 = load ptr, ptr %1328, align 8, !tbaa !52
  br label %1331

1330:                                             ; preds = %1324
  br label %1331

1331:                                             ; preds = %1330, %1327, %1324, %1320
  %1332 = phi ptr [ %1329, %1327 ], [ %1321, %1324 ], [ %1321, %1320 ], [ %1321, %1330 ]
  %1333 = phi i8 [ %1326, %1327 ], [ %1322, %1324 ], [ %1322, %1320 ], [ %1326, %1330 ]
  %1334 = icmp eq i64 %1272, 40
  br i1 %1334, label %1335, label %1342

1335:                                             ; preds = %1331
  %1336 = load ptr, ptr %169, align 8, !tbaa !42
  %1337 = load i8, ptr %1336, align 1, !tbaa !40
  switch i8 %1337, label %1341 [
    i8 0, label %1342
    i8 4, label %1338
  ]

1338:                                             ; preds = %1335
  %1339 = load ptr, ptr %170, align 8, !tbaa !44
  %1340 = load ptr, ptr %1339, align 8, !tbaa !52
  br label %1342

1341:                                             ; preds = %1335
  br label %1342

1342:                                             ; preds = %1341, %1338, %1335, %1331
  %1343 = phi ptr [ %1340, %1338 ], [ %1332, %1335 ], [ %1332, %1331 ], [ %1332, %1341 ]
  %1344 = phi i8 [ %1337, %1338 ], [ %1333, %1335 ], [ %1333, %1331 ], [ %1337, %1341 ]
  %1345 = icmp eq i64 %1272, 48
  br i1 %1345, label %1346, label %1353

1346:                                             ; preds = %1342
  %1347 = load ptr, ptr %171, align 8, !tbaa !42
  %1348 = load i8, ptr %1347, align 1, !tbaa !40
  switch i8 %1348, label %1352 [
    i8 0, label %1353
    i8 4, label %1349
  ]

1349:                                             ; preds = %1346
  %1350 = load ptr, ptr %172, align 8, !tbaa !44
  %1351 = load ptr, ptr %1350, align 8, !tbaa !52
  br label %1353

1352:                                             ; preds = %1346
  br label %1353

1353:                                             ; preds = %1352, %1349, %1346, %1342
  %1354 = phi ptr [ %1351, %1349 ], [ %1343, %1346 ], [ %1343, %1342 ], [ %1343, %1352 ]
  %1355 = phi i8 [ %1348, %1349 ], [ %1344, %1346 ], [ %1344, %1342 ], [ %1348, %1352 ]
  %1356 = icmp eq i64 %1272, 56
  br i1 %1356, label %1357, label %1364

1357:                                             ; preds = %1353
  %1358 = load ptr, ptr %173, align 8, !tbaa !42
  %1359 = load i8, ptr %1358, align 1, !tbaa !40
  switch i8 %1359, label %1363 [
    i8 0, label %1364
    i8 4, label %1360
  ]

1360:                                             ; preds = %1357
  %1361 = load ptr, ptr %174, align 8, !tbaa !44
  %1362 = load ptr, ptr %1361, align 8, !tbaa !52
  br label %1364

1363:                                             ; preds = %1357
  br label %1364

1364:                                             ; preds = %1353, %1357, %1360, %1363, %1269, %1263
  %1365 = phi ptr [ null, %1263 ], [ null, %1269 ], [ %1362, %1360 ], [ %1354, %1357 ], [ %1354, %1353 ], [ %1354, %1363 ]
  %1366 = phi i8 [ 0, %1263 ], [ 0, %1269 ], [ %1359, %1360 ], [ %1355, %1357 ], [ %1355, %1353 ], [ %1359, %1363 ]
  %1367 = icmp eq i8 %1366, 0
  br i1 %1367, label %1373, label %1368

1368:                                             ; preds = %1364
  %1369 = icmp eq i8 %1366, 4
  %1370 = inttoptr i64 %1264 to ptr
  %1371 = select i1 %1369, ptr %1365, ptr %1370
  br label %1373

1372:                                             ; preds = %1213
  br label %1373

1373:                                             ; preds = %1372, %1368, %1364, %1237, %1219, %1216, %1213, %1046, %1013, %1011
  %1374 = phi i1 [ false, %1013 ], [ false, %1046 ], [ true, %1219 ], [ false, %1237 ], [ false, %1216 ], [ true, %1213 ], [ true, %1011 ], [ false, %1372 ], [ false, %1368 ], [ %1367, %1364 ]
  %1375 = phi i8 [ %1016, %1013 ], [ %1056, %1046 ], [ 0, %1219 ], [ %1238, %1237 ], [ %1214, %1216 ], [ %1214, %1213 ], [ 0, %1011 ], [ %1214, %1372 ], [ %1366, %1368 ], [ 0, %1364 ]
  %1376 = phi ptr [ %1017, %1013 ], [ %1057, %1046 ], [ null, %1219 ], [ %1242, %1237 ], [ %1217, %1216 ], [ null, %1213 ], [ null, %1011 ], [ %1215, %1372 ], [ %1371, %1368 ], [ null, %1364 ]
  %1377 = phi i64 [ %1012, %1013 ], [ %1048, %1046 ], [ %1222, %1219 ], [ %1241, %1237 ], [ %1123, %1216 ], [ %1123, %1213 ], [ %1012, %1011 ], [ %1123, %1372 ], [ %1264, %1368 ], [ %1264, %1364 ]
  br i1 %1374, label %1380, label %1378

1378:                                             ; preds = %1373
  %1379 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr %1376, ptr %1379, align 8, !tbaa !40
  br label %1383

1380:                                             ; preds = %1373
  %1381 = inttoptr i64 %1377 to ptr
  %1382 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr %1381, ptr %1382, align 8, !tbaa !40
  br label %1383

1383:                                             ; preds = %920, %1378, %1380
  %1384 = phi i8 [ 0, %920 ], [ %1375, %1378 ], [ 0, %1380 ]
  %1385 = load ptr, ptr %4, align 8, !tbaa !9
  %1386 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1385, i64 0, i32 1
  store i8 %1384, ptr %1386, align 8, !tbaa !47
  %1387 = load i8, ptr %44, align 8, !tbaa !40
  %1388 = zext i8 %1387 to i32
  %1389 = icmp eq i32 %228, %1388
  br i1 %1389, label %1390, label %1394

1390:                                             ; preds = %1383
  %1391 = load ptr, ptr %1, align 8, !tbaa !40
  %1392 = load ptr, ptr %42, align 8, !tbaa !40
  %1393 = icmp eq ptr %1391, %1392
  br i1 %1393, label %1401, label %1394

1394:                                             ; preds = %1390, %1383
  %1395 = load ptr, ptr @stderr, align 8, !tbaa !52
  %1396 = load ptr, ptr %1, align 8, !tbaa !40
  %1397 = load ptr, ptr %42, align 8, !tbaa !40
  %1398 = icmp eq ptr %1396, %1397
  %1399 = zext i1 %1398 to i32
  %1400 = call i32 (ptr, ptr, ...) @fprintf(ptr noundef %1395, ptr noundef nonnull @.str.4, i32 noundef %228, i32 noundef %241, i32 noundef %257, i32 noundef %280, i32 noundef %1388, i32 noundef %1399) #8
  br label %1401

1401:                                             ; preds = %1394, %1390
  %1402 = load i8, ptr %44, align 8, !tbaa !40
  %1403 = zext i8 %1402 to i32
  %1404 = icmp eq i32 %228, %1403
  br i1 %1404, label %1405, label %1409

1405:                                             ; preds = %1401
  %1406 = load ptr, ptr %1, align 8, !tbaa !40
  %1407 = load ptr, ptr %42, align 8, !tbaa !40
  %1408 = icmp eq ptr %1406, %1407
  br i1 %1408, label %1410, label %1409

1409:                                             ; preds = %1405, %1401
  call void @__assert_fail(ptr noundef nonnull @.str.5, ptr noundef nonnull @.str.1, i32 noundef 45, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #6
  unreachable

1410:                                             ; preds = %1405
  switch i64 %234, label %1412 [
    i64 1, label %1411
    i64 5, label %1411
  ]

1411:                                             ; preds = %1410, %1410
  store i8 0, ptr %242, align 1, !tbaa !40
  store ptr null, ptr %243, align 8, !tbaa !52
  br label %1412

1412:                                             ; preds = %1411, %1410
  store i8 90, ptr %237, align 8, !tbaa !40
  %1413 = load ptr, ptr %38, align 8
  %1414 = ptrtoint ptr %1413 to i64
  %1415 = icmp slt i64 %236, %1414
  br i1 %1415, label %1416, label %1417

1416:                                             ; preds = %1412
  store i8 -128, ptr %237, align 8, !tbaa !40
  br label %1424

1417:                                             ; preds = %1412
  %1418 = load i8, ptr %175, align 1
  %1419 = select i1 %244, i8 %1418, i8 0
  br i1 %245, label %1420, label %1424

1420:                                             ; preds = %1417
  %1421 = load i8, ptr %176, align 1, !tbaa !40
  switch i8 %1421, label %1423 [
    i8 0, label %1424
    i8 4, label %1422
  ]

1422:                                             ; preds = %1420
  br label %1424

1423:                                             ; preds = %1420
  br label %1424

1424:                                             ; preds = %1416, %1417, %1420, %1422, %1423
  %1425 = phi i8 [ 0, %1416 ], [ %1421, %1422 ], [ %1419, %1420 ], [ %1419, %1417 ], [ %1421, %1423 ]
  %1426 = icmp eq i8 %1425, 0
  br i1 %1426, label %1428, label %1427

1427:                                             ; preds = %1424
  call void @__assert_fail(ptr noundef nonnull @.str.6, ptr noundef nonnull @.str.1, i32 noundef 49, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #6
  unreachable

1428:                                             ; preds = %1424
  store ptr inttoptr (i64 -8 to ptr), ptr %38, align 8, !tbaa !40
  br i1 %246, label %1429, label %1430

1429:                                             ; preds = %1428
  store i64 1161981756646125696, ptr %177, align 8, !tbaa !40
  br label %1430

1430:                                             ; preds = %1428, %1429
  br i1 %247, label %1431, label %1432

1431:                                             ; preds = %1430
  store i64 1161981756646125696, ptr %178, align 8, !tbaa !40
  br label %1432

1432:                                             ; preds = %1430, %1431
  br i1 %248, label %1433, label %1434

1433:                                             ; preds = %1432
  store i64 1161981756646125696, ptr %179, align 8, !tbaa !40
  br label %1434

1434:                                             ; preds = %1432, %1433
  br i1 %249, label %1435, label %1436

1435:                                             ; preds = %1434
  store i64 1161981756646125696, ptr %180, align 8, !tbaa !40
  br label %1436

1436:                                             ; preds = %1435, %1434
  store i64 1161981756646125696, ptr %181, align 8, !tbaa !40
  store i64 1161981756646125696, ptr %182, align 8, !tbaa !40
  store i8 0, ptr %2, align 8, !tbaa !40
  store ptr null, ptr %3, align 16, !tbaa !52
  store i8 0, ptr %183, align 1, !tbaa !40
  store ptr null, ptr %184, align 8, !tbaa !52
  store i8 0, ptr %185, align 2, !tbaa !40
  store ptr null, ptr %186, align 16, !tbaa !52
  store i8 0, ptr %187, align 1, !tbaa !40
  store ptr null, ptr %188, align 8, !tbaa !52
  store i8 0, ptr %189, align 4, !tbaa !40
  store ptr null, ptr %190, align 16, !tbaa !52
  store i8 0, ptr %191, align 1, !tbaa !40
  store ptr null, ptr %192, align 8, !tbaa !52
  store i8 0, ptr %193, align 2, !tbaa !40
  store ptr null, ptr %194, align 16, !tbaa !52
  br i1 %264, label %1456, label %1437

1437:                                             ; preds = %1436
  %1438 = load ptr, ptr %4, align 8, !tbaa !9
  %1439 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1438, i64 %266, i32 1
  %1440 = load i8, ptr %1439, align 8, !tbaa !47
  %1441 = icmp eq i8 %1440, 0
  br i1 %1441, label %1442, label %1450

1442:                                             ; preds = %1437
  %1443 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1438, i64 %266
  %1444 = load ptr, ptr %1443, align 8, !tbaa !40
  %1445 = ptrtoint ptr %1444 to i64
  %1446 = add i64 %267, %1445
  %1447 = icmp ult i64 %1446, 4096
  br i1 %1447, label %1448, label %1450

1448:                                             ; preds = %1442
  %1449 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr null, ptr %1449, align 8, !tbaa !40
  br label %1911

1450:                                             ; preds = %1442, %1437
  br i1 %264, label %1456, label %1451

1451:                                             ; preds = %1450
  %1452 = load ptr, ptr %4, align 8, !tbaa !9
  %1453 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1452, i64 %266, i32 1
  %1454 = load i8, ptr %1453, align 8, !tbaa !47
  %1455 = icmp eq i8 %1454, 1
  br label %1456

1456:                                             ; preds = %1436, %1451, %1450
  %1457 = phi i1 [ false, %1450 ], [ %1455, %1451 ], [ false, %1436 ]
  %1458 = load ptr, ptr %4, align 8, !tbaa !9
  %1459 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1458, i64 %266
  %1460 = load ptr, ptr %1459, align 8, !tbaa !40
  %1461 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1458, i64 %266, i32 1
  %1462 = load i8, ptr %1461, align 8, !tbaa !47
  %1463 = icmp eq i8 %1462, 1
  br i1 %1463, label %1466, label %1464

1464:                                             ; preds = %1456
  %1465 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %267) #7, !srcloc !54
  br label %1466

1466:                                             ; preds = %1464, %1456
  %1467 = phi i64 [ %1465, %1464 ], [ %267, %1456 ]
  %1468 = ptrtoint ptr %1460 to i64
  %1469 = add i64 %1467, %1468
  %1470 = load i8, ptr %36, align 1, !tbaa !39
  %1471 = icmp eq i8 %1470, 1
  br i1 %1471, label %1472, label %1546

1472:                                             ; preds = %1466
  %1473 = load ptr, ptr %4, align 8, !tbaa !9
  %1474 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1473, i64 %266, i32 1
  %1475 = load i8, ptr %1474, align 8, !tbaa !47
  %1476 = icmp eq i8 %1475, 1
  br i1 %1476, label %1477, label %1546

1477:                                             ; preds = %1472
  %1478 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1473, i64 %266
  %1479 = load ptr, ptr %1478, align 8, !tbaa !40
  %1480 = ptrtoint ptr %1479 to i64
  %1481 = load ptr, ptr %30, align 8, !tbaa !33
  %1482 = ptrtoint ptr %1481 to i64
  %1483 = sub i64 %1480, %1482
  %1484 = add i64 %1483, %1467
  %1485 = load ptr, ptr %28, align 8, !tbaa !31
  %1486 = icmp eq i64 %1484, 208
  switch i64 %1484, label %1494 [
    i64 208, label %1487
    i64 80, label %1487
  ]

1487:                                             ; preds = %1477, %1477
  %1488 = icmp sgt i64 %1484, 207
  %1489 = getelementptr inbounds %struct.__sk_buff, ptr %1485, i64 0, i32 15
  %1490 = getelementptr inbounds %struct.__sk_buff, ptr %1485, i64 0, i32 16
  %1491 = select i1 %1488, ptr %1489, ptr %1490
  %1492 = load i32, ptr %1491, align 4, !tbaa !55
  %1493 = zext i32 %1492 to i64
  br label %1539

1494:                                             ; preds = %1477
  %1495 = add i64 %1484, -48
  %1496 = icmp ult i64 %1495, 13
  br i1 %1496, label %1497, label %1536

1497:                                             ; preds = %1494
  %1498 = getelementptr inbounds i8, ptr %1485, i64 %1484
  %1499 = load volatile i8, ptr %1498, align 1, !tbaa !40
  %1500 = zext i8 %1499 to i64
  %1501 = getelementptr inbounds i8, ptr %1498, i64 1
  %1502 = load volatile i8, ptr %1501, align 1, !tbaa !40
  %1503 = zext i8 %1502 to i64
  %1504 = shl nuw nsw i64 %1503, 8
  %1505 = or disjoint i64 %1504, %1500
  %1506 = getelementptr inbounds i8, ptr %1498, i64 2
  %1507 = load volatile i8, ptr %1506, align 1, !tbaa !40
  %1508 = zext i8 %1507 to i64
  %1509 = shl nuw nsw i64 %1508, 16
  %1510 = or disjoint i64 %1505, %1509
  %1511 = getelementptr inbounds i8, ptr %1498, i64 3
  %1512 = load volatile i8, ptr %1511, align 1, !tbaa !40
  %1513 = zext i8 %1512 to i64
  %1514 = shl nuw nsw i64 %1513, 24
  %1515 = or disjoint i64 %1510, %1514
  %1516 = getelementptr inbounds i8, ptr %1498, i64 4
  %1517 = load volatile i8, ptr %1516, align 1, !tbaa !40
  %1518 = zext i8 %1517 to i64
  %1519 = shl nuw nsw i64 %1518, 32
  %1520 = or disjoint i64 %1515, %1519
  %1521 = getelementptr inbounds i8, ptr %1498, i64 5
  %1522 = load volatile i8, ptr %1521, align 1, !tbaa !40
  %1523 = zext i8 %1522 to i64
  %1524 = shl nuw nsw i64 %1523, 40
  %1525 = or i64 %1520, %1524
  %1526 = getelementptr inbounds i8, ptr %1498, i64 6
  %1527 = load volatile i8, ptr %1526, align 1, !tbaa !40
  %1528 = zext i8 %1527 to i64
  %1529 = shl nuw nsw i64 %1528, 48
  %1530 = or i64 %1525, %1529
  %1531 = getelementptr inbounds i8, ptr %1498, i64 7
  %1532 = load volatile i8, ptr %1531, align 1, !tbaa !40
  %1533 = zext i8 %1532 to i64
  %1534 = shl nuw i64 %1533, 56
  %1535 = or i64 %1530, %1534
  br label %1539

1536:                                             ; preds = %1494
  %1537 = getelementptr inbounds i8, ptr %1479, i64 %1467
  %1538 = load volatile i64, ptr %1537, align 1, !tbaa !40
  br label %1539

1539:                                             ; preds = %1536, %1497, %1487
  %1540 = phi i64 [ %1493, %1487 ], [ %1535, %1497 ], [ %1538, %1536 ]
  br i1 %1457, label %1541, label %1901

1541:                                             ; preds = %1539
  %1542 = icmp eq i64 %1484, 80
  %1543 = select i1 %1542, i8 3, i8 0
  %1544 = select i1 %1486, i8 2, i8 %1543
  %1545 = inttoptr i64 %1540 to ptr
  br label %1901

1546:                                             ; preds = %1472, %1466
  %1547 = load i8, ptr %34, align 8, !tbaa !37
  %1548 = icmp eq i8 %1547, 0
  br i1 %1548, label %1586, label %1549

1549:                                             ; preds = %1546
  %1550 = load ptr, ptr %4, align 8, !tbaa !9
  %1551 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1550, i64 %266, i32 1
  %1552 = load i8, ptr %1551, align 8, !tbaa !47
  %1553 = icmp eq i8 %1552, 1
  br i1 %1553, label %1554, label %1586

1554:                                             ; preds = %1549
  %1555 = load ptr, ptr %30, align 8, !tbaa !33
  %1556 = ptrtoint ptr %1555 to i64
  %1557 = add i64 %1467, %1468
  %1558 = sub i64 %1557, %1556
  %1559 = load ptr, ptr %28, align 8, !tbaa !31
  switch i64 %1558, label %1571 [
    i64 0, label %1560
    i64 8, label %1563
    i64 16, label %1567
  ]

1560:                                             ; preds = %1554
  %1561 = load volatile i32, ptr %1559, align 4, !tbaa !56
  %1562 = zext i32 %1561 to i64
  br label %1574

1563:                                             ; preds = %1554
  %1564 = getelementptr inbounds %struct.xdp_md, ptr %1559, i64 0, i32 1
  %1565 = load volatile i32, ptr %1564, align 4, !tbaa !58
  %1566 = zext i32 %1565 to i64
  br label %1574

1567:                                             ; preds = %1554
  %1568 = getelementptr inbounds %struct.xdp_md, ptr %1559, i64 0, i32 2
  %1569 = load volatile i32, ptr %1568, align 4, !tbaa !59
  %1570 = zext i32 %1569 to i64
  br label %1574

1571:                                             ; preds = %1554
  %1572 = getelementptr inbounds i8, ptr %1460, i64 %1467
  %1573 = load volatile i64, ptr %1572, align 1, !tbaa !40
  br label %1574

1574:                                             ; preds = %1571, %1567, %1563, %1560
  %1575 = phi i64 [ %1562, %1560 ], [ %1566, %1563 ], [ %1570, %1567 ], [ %1573, %1571 ]
  %1576 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %1575) #7, !srcloc !60
  %1577 = load ptr, ptr %30, align 8, !tbaa !33
  %1578 = ptrtoint ptr %1577 to i64
  %1579 = sub i64 %1468, %1578
  %1580 = add i64 %1579, %1467
  %1581 = icmp eq i64 %1580, 8
  %1582 = select i1 %1581, i8 3, i8 0
  %1583 = icmp eq i64 %1580, 0
  %1584 = select i1 %1583, i8 2, i8 %1582
  %1585 = inttoptr i64 %1576 to ptr
  br label %1901

1586:                                             ; preds = %1549, %1546
  br i1 %264, label %1593, label %1587

1587:                                             ; preds = %1586
  %1588 = load ptr, ptr %4, align 8, !tbaa !9
  %1589 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1588, i64 %266, i32 1
  %1590 = load i8, ptr %1589, align 8, !tbaa !47
  %1591 = icmp eq i8 %1590, 1
  %1592 = select i1 %1591, i32 1, i32 2
  br label %1593

1593:                                             ; preds = %1587, %1586
  %1594 = phi i32 [ 0, %1586 ], [ %1592, %1587 ]
  switch i32 %1594, label %1771 [
    i32 0, label %1595
    i32 1, label %1746
  ]

1595:                                             ; preds = %1593
  %1596 = add i64 %1469, 64
  %1597 = and i64 %1469, 7
  %1598 = icmp eq i64 %1597, 0
  %1599 = load ptr, ptr %5, align 8, !tbaa !14
  br i1 %1598, label %1600, label %1604

1600:                                             ; preds = %1595
  %1601 = lshr exact i64 %1596, 3
  %1602 = getelementptr inbounds [8 x i64], ptr %1599, i64 0, i64 %1601
  %1603 = load volatile i64, ptr %1602, align 8, !tbaa !40
  br label %1644

1604:                                             ; preds = %1595
  %1605 = getelementptr inbounds i8, ptr %1599, i64 %1596
  %1606 = load i8, ptr %1605, align 1, !tbaa !40
  %1607 = zext i8 %1606 to i64
  %1608 = getelementptr i8, ptr %1599, i64 %1469
  %1609 = getelementptr i8, ptr %1608, i64 65
  %1610 = load i8, ptr %1609, align 1, !tbaa !40
  %1611 = zext i8 %1610 to i64
  %1612 = shl nuw nsw i64 %1611, 8
  %1613 = or disjoint i64 %1612, %1607
  %1614 = getelementptr i8, ptr %1608, i64 66
  %1615 = load i8, ptr %1614, align 1, !tbaa !40
  %1616 = zext i8 %1615 to i64
  %1617 = shl nuw nsw i64 %1616, 16
  %1618 = or disjoint i64 %1613, %1617
  %1619 = getelementptr i8, ptr %1608, i64 67
  %1620 = load i8, ptr %1619, align 1, !tbaa !40
  %1621 = zext i8 %1620 to i64
  %1622 = shl nuw nsw i64 %1621, 24
  %1623 = or disjoint i64 %1618, %1622
  %1624 = getelementptr i8, ptr %1608, i64 68
  %1625 = load i8, ptr %1624, align 1, !tbaa !40
  %1626 = zext i8 %1625 to i64
  %1627 = shl nuw nsw i64 %1626, 32
  %1628 = or disjoint i64 %1623, %1627
  %1629 = getelementptr i8, ptr %1608, i64 69
  %1630 = load i8, ptr %1629, align 1, !tbaa !40
  %1631 = zext i8 %1630 to i64
  %1632 = shl nuw nsw i64 %1631, 40
  %1633 = or i64 %1628, %1632
  %1634 = getelementptr i8, ptr %1608, i64 70
  %1635 = load i8, ptr %1634, align 1, !tbaa !40
  %1636 = zext i8 %1635 to i64
  %1637 = shl nuw nsw i64 %1636, 48
  %1638 = or i64 %1633, %1637
  %1639 = getelementptr i8, ptr %1608, i64 71
  %1640 = load i8, ptr %1639, align 1, !tbaa !40
  %1641 = zext i8 %1640 to i64
  %1642 = shl nuw i64 %1641, 56
  %1643 = or i64 %1638, %1642
  br label %1644

1644:                                             ; preds = %1604, %1600
  %1645 = phi i64 [ %1603, %1600 ], [ %1643, %1604 ]
  %1646 = load ptr, ptr %4, align 8, !tbaa !9
  %1647 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1646, i64 4
  %1648 = load ptr, ptr %1647, align 8, !tbaa !40
  %1649 = ptrtoint ptr %1648 to i64
  %1650 = icmp slt i64 %1469, %1649
  %1651 = select i1 %1650, i64 1161981756646125696, i64 %1645
  %1652 = add nsw i64 %267, %1468
  %1653 = add i64 %1652, 64
  %1654 = icmp slt i64 %1652, %1649
  br i1 %1654, label %1741, label %1655

1655:                                             ; preds = %1644
  %1656 = icmp eq i64 %1653, 0
  br i1 %1656, label %1657, label %1664

1657:                                             ; preds = %1655
  %1658 = load ptr, ptr %195, align 8, !tbaa !42
  %1659 = load i8, ptr %1658, align 1, !tbaa !40
  %1660 = icmp eq i8 %1659, 4
  br i1 %1660, label %1661, label %1664

1661:                                             ; preds = %1657
  %1662 = load ptr, ptr %196, align 8, !tbaa !44
  %1663 = load ptr, ptr %1662, align 8, !tbaa !52
  br label %1664

1664:                                             ; preds = %1657, %1661, %1655
  %1665 = phi i8 [ %1659, %1661 ], [ 0, %1655 ], [ %1659, %1657 ]
  %1666 = phi ptr [ %1663, %1661 ], [ null, %1655 ], [ null, %1657 ]
  %1667 = icmp eq i64 %1653, 8
  br i1 %1667, label %1668, label %1675

1668:                                             ; preds = %1664
  %1669 = load ptr, ptr %197, align 8, !tbaa !42
  %1670 = load i8, ptr %1669, align 1, !tbaa !40
  switch i8 %1670, label %1674 [
    i8 0, label %1675
    i8 4, label %1671
  ]

1671:                                             ; preds = %1668
  %1672 = load ptr, ptr %198, align 8, !tbaa !44
  %1673 = load ptr, ptr %1672, align 8, !tbaa !52
  br label %1675

1674:                                             ; preds = %1668
  br label %1675

1675:                                             ; preds = %1674, %1671, %1668, %1664
  %1676 = phi i8 [ %1670, %1671 ], [ %1665, %1668 ], [ %1665, %1664 ], [ %1670, %1674 ]
  %1677 = phi ptr [ %1673, %1671 ], [ %1666, %1668 ], [ %1666, %1664 ], [ %1666, %1674 ]
  %1678 = icmp eq i64 %1653, 16
  br i1 %1678, label %1679, label %1686

1679:                                             ; preds = %1675
  %1680 = load ptr, ptr %199, align 8, !tbaa !42
  %1681 = load i8, ptr %1680, align 1, !tbaa !40
  switch i8 %1681, label %1685 [
    i8 0, label %1686
    i8 4, label %1682
  ]

1682:                                             ; preds = %1679
  %1683 = load ptr, ptr %200, align 8, !tbaa !44
  %1684 = load ptr, ptr %1683, align 8, !tbaa !52
  br label %1686

1685:                                             ; preds = %1679
  br label %1686

1686:                                             ; preds = %1685, %1682, %1679, %1675
  %1687 = phi i8 [ %1681, %1682 ], [ %1676, %1679 ], [ %1676, %1675 ], [ %1681, %1685 ]
  %1688 = phi ptr [ %1684, %1682 ], [ %1677, %1679 ], [ %1677, %1675 ], [ %1677, %1685 ]
  %1689 = icmp eq i64 %1653, 24
  br i1 %1689, label %1690, label %1697

1690:                                             ; preds = %1686
  %1691 = load ptr, ptr %201, align 8, !tbaa !42
  %1692 = load i8, ptr %1691, align 1, !tbaa !40
  switch i8 %1692, label %1696 [
    i8 0, label %1697
    i8 4, label %1693
  ]

1693:                                             ; preds = %1690
  %1694 = load ptr, ptr %202, align 8, !tbaa !44
  %1695 = load ptr, ptr %1694, align 8, !tbaa !52
  br label %1697

1696:                                             ; preds = %1690
  br label %1697

1697:                                             ; preds = %1696, %1693, %1690, %1686
  %1698 = phi i8 [ %1692, %1693 ], [ %1687, %1690 ], [ %1687, %1686 ], [ %1692, %1696 ]
  %1699 = phi ptr [ %1695, %1693 ], [ %1688, %1690 ], [ %1688, %1686 ], [ %1688, %1696 ]
  %1700 = icmp eq i64 %1653, 32
  br i1 %1700, label %1701, label %1708

1701:                                             ; preds = %1697
  %1702 = load ptr, ptr %203, align 8, !tbaa !42
  %1703 = load i8, ptr %1702, align 1, !tbaa !40
  switch i8 %1703, label %1707 [
    i8 0, label %1708
    i8 4, label %1704
  ]

1704:                                             ; preds = %1701
  %1705 = load ptr, ptr %204, align 8, !tbaa !44
  %1706 = load ptr, ptr %1705, align 8, !tbaa !52
  br label %1708

1707:                                             ; preds = %1701
  br label %1708

1708:                                             ; preds = %1707, %1704, %1701, %1697
  %1709 = phi i8 [ %1703, %1704 ], [ %1698, %1701 ], [ %1698, %1697 ], [ %1703, %1707 ]
  %1710 = phi ptr [ %1706, %1704 ], [ %1699, %1701 ], [ %1699, %1697 ], [ %1699, %1707 ]
  %1711 = icmp eq i64 %1653, 40
  br i1 %1711, label %1712, label %1719

1712:                                             ; preds = %1708
  %1713 = load ptr, ptr %205, align 8, !tbaa !42
  %1714 = load i8, ptr %1713, align 1, !tbaa !40
  switch i8 %1714, label %1718 [
    i8 0, label %1719
    i8 4, label %1715
  ]

1715:                                             ; preds = %1712
  %1716 = load ptr, ptr %206, align 8, !tbaa !44
  %1717 = load ptr, ptr %1716, align 8, !tbaa !52
  br label %1719

1718:                                             ; preds = %1712
  br label %1719

1719:                                             ; preds = %1718, %1715, %1712, %1708
  %1720 = phi i8 [ %1714, %1715 ], [ %1709, %1712 ], [ %1709, %1708 ], [ %1714, %1718 ]
  %1721 = phi ptr [ %1717, %1715 ], [ %1710, %1712 ], [ %1710, %1708 ], [ %1710, %1718 ]
  %1722 = icmp eq i64 %1653, 48
  br i1 %1722, label %1723, label %1730

1723:                                             ; preds = %1719
  %1724 = load ptr, ptr %207, align 8, !tbaa !42
  %1725 = load i8, ptr %1724, align 1, !tbaa !40
  switch i8 %1725, label %1729 [
    i8 0, label %1730
    i8 4, label %1726
  ]

1726:                                             ; preds = %1723
  %1727 = load ptr, ptr %208, align 8, !tbaa !44
  %1728 = load ptr, ptr %1727, align 8, !tbaa !52
  br label %1730

1729:                                             ; preds = %1723
  br label %1730

1730:                                             ; preds = %1729, %1726, %1723, %1719
  %1731 = phi i8 [ %1725, %1726 ], [ %1720, %1723 ], [ %1720, %1719 ], [ %1725, %1729 ]
  %1732 = phi ptr [ %1728, %1726 ], [ %1721, %1723 ], [ %1721, %1719 ], [ %1721, %1729 ]
  %1733 = icmp eq i64 %1653, 56
  br i1 %1733, label %1734, label %1741

1734:                                             ; preds = %1730
  %1735 = load ptr, ptr %209, align 8, !tbaa !42
  %1736 = load i8, ptr %1735, align 1, !tbaa !40
  switch i8 %1736, label %1740 [
    i8 0, label %1741
    i8 4, label %1737
  ]

1737:                                             ; preds = %1734
  %1738 = load ptr, ptr %210, align 8, !tbaa !44
  %1739 = load ptr, ptr %1738, align 8, !tbaa !52
  br label %1741

1740:                                             ; preds = %1734
  br label %1741

1741:                                             ; preds = %1730, %1734, %1737, %1740, %1644
  %1742 = phi i8 [ 0, %1644 ], [ %1736, %1737 ], [ %1731, %1734 ], [ %1731, %1730 ], [ %1736, %1740 ]
  %1743 = phi ptr [ null, %1644 ], [ %1739, %1737 ], [ %1732, %1734 ], [ %1732, %1730 ], [ %1732, %1740 ]
  switch i8 %1742, label %1744 [
    i8 0, label %1901
    i8 4, label %1900
  ]

1744:                                             ; preds = %1741
  %1745 = inttoptr i64 %1651 to ptr
  br label %1901

1746:                                             ; preds = %1593
  br i1 %1457, label %1751, label %1747

1747:                                             ; preds = %1746
  %1748 = add i64 %267, %1468
  %1749 = inttoptr i64 %1748 to ptr
  %1750 = load volatile i64, ptr %1749, align 1, !tbaa !40
  br label %1901

1751:                                             ; preds = %1746
  %1752 = icmp eq i8 %1470, 0
  %1753 = icmp eq i64 %1467, 0
  %1754 = select i1 %1752, i1 %1753, i1 false
  %1755 = icmp eq i64 %1467, 208
  %1756 = select i1 %1471, i1 %1755, i1 false
  %1757 = select i1 %1754, i1 true, i1 %1756
  br i1 %1757, label %1765, label %1758

1758:                                             ; preds = %1751
  %1759 = icmp eq i64 %1467, 8
  %1760 = select i1 %1752, i1 %1759, i1 false
  %1761 = icmp eq i64 %1467, 80
  %1762 = select i1 %1471, i1 %1761, i1 false
  %1763 = select i1 %1760, i1 true, i1 %1762
  %1764 = select i1 %1763, i8 3, i8 0
  br label %1765

1765:                                             ; preds = %1758, %1751
  %1766 = phi i8 [ 2, %1751 ], [ %1764, %1758 ]
  %1767 = add i64 %267, %1468
  %1768 = inttoptr i64 %1767 to ptr
  %1769 = load volatile i64, ptr %1768, align 1, !tbaa !40
  %1770 = inttoptr i64 %1769 to ptr
  br label %1901

1771:                                             ; preds = %1593
  %1772 = add i64 %267, %1468
  %1773 = inttoptr i64 %1772 to ptr
  %1774 = load volatile i64, ptr %1773, align 1, !tbaa !40
  %1775 = load ptr, ptr %4, align 8, !tbaa !9
  %1776 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1775, i64 %266, i32 1
  %1777 = load i8, ptr %1776, align 8, !tbaa !47
  %1778 = icmp eq i8 %1777, 4
  br i1 %1778, label %1779, label %1791

1779:                                             ; preds = %1771
  %1780 = load ptr, ptr %5, align 8, !tbaa !14
  %1781 = ptrtoint ptr %1780 to i64
  %1782 = add i64 %1772, -64
  %1783 = sub i64 %1782, %1781
  %1784 = call i64 asm sideeffect "", "=r,0,~{dirflag},~{fpsr},~{flags}"(i64 %1783) #7, !srcloc !61
  %1785 = load ptr, ptr %4, align 8, !tbaa !9
  %1786 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1785, i64 4
  %1787 = load ptr, ptr %1786, align 8, !tbaa !40
  %1788 = ptrtoint ptr %1787 to i64
  %1789 = icmp slt i64 %1784, %1788
  %1790 = select i1 %1789, i64 1161981756646125696, i64 %1774
  br label %1791

1791:                                             ; preds = %1779, %1771
  %1792 = phi i64 [ %1774, %1771 ], [ %1790, %1779 ]
  %1793 = load ptr, ptr %4, align 8, !tbaa !9
  %1794 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1793, i64 %266, i32 1
  %1795 = load i8, ptr %1794, align 8, !tbaa !47
  %1796 = icmp eq i8 %1795, 4
  br i1 %1796, label %1797, label %1892

1797:                                             ; preds = %1791
  %1798 = load ptr, ptr %5, align 8, !tbaa !14
  %1799 = ptrtoint ptr %1798 to i64
  %1800 = sub i64 %1469, %1799
  %1801 = add nsw i64 %1800, -64
  %1802 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1793, i64 4
  %1803 = load ptr, ptr %1802, align 8, !tbaa !40
  %1804 = ptrtoint ptr %1803 to i64
  %1805 = icmp slt i64 %1801, %1804
  br i1 %1805, label %1892, label %1806

1806:                                             ; preds = %1797
  %1807 = icmp eq i64 %1469, %1799
  br i1 %1807, label %1808, label %1815

1808:                                             ; preds = %1806
  %1809 = load ptr, ptr %211, align 8, !tbaa !42
  %1810 = load i8, ptr %1809, align 1, !tbaa !40
  %1811 = icmp eq i8 %1810, 4
  br i1 %1811, label %1812, label %1815

1812:                                             ; preds = %1808
  %1813 = load ptr, ptr %212, align 8, !tbaa !44
  %1814 = load ptr, ptr %1813, align 8, !tbaa !52
  br label %1815

1815:                                             ; preds = %1808, %1812, %1806
  %1816 = phi ptr [ %1814, %1812 ], [ null, %1806 ], [ null, %1808 ]
  %1817 = phi i8 [ %1810, %1812 ], [ 0, %1806 ], [ %1810, %1808 ]
  %1818 = icmp eq i64 %1800, 8
  br i1 %1818, label %1819, label %1826

1819:                                             ; preds = %1815
  %1820 = load ptr, ptr %213, align 8, !tbaa !42
  %1821 = load i8, ptr %1820, align 1, !tbaa !40
  switch i8 %1821, label %1825 [
    i8 0, label %1826
    i8 4, label %1822
  ]

1822:                                             ; preds = %1819
  %1823 = load ptr, ptr %214, align 8, !tbaa !44
  %1824 = load ptr, ptr %1823, align 8, !tbaa !52
  br label %1826

1825:                                             ; preds = %1819
  br label %1826

1826:                                             ; preds = %1825, %1822, %1819, %1815
  %1827 = phi ptr [ %1824, %1822 ], [ %1816, %1819 ], [ %1816, %1815 ], [ %1816, %1825 ]
  %1828 = phi i8 [ %1821, %1822 ], [ %1817, %1819 ], [ %1817, %1815 ], [ %1821, %1825 ]
  %1829 = icmp eq i64 %1800, 16
  br i1 %1829, label %1830, label %1837

1830:                                             ; preds = %1826
  %1831 = load ptr, ptr %215, align 8, !tbaa !42
  %1832 = load i8, ptr %1831, align 1, !tbaa !40
  switch i8 %1832, label %1836 [
    i8 0, label %1837
    i8 4, label %1833
  ]

1833:                                             ; preds = %1830
  %1834 = load ptr, ptr %216, align 8, !tbaa !44
  %1835 = load ptr, ptr %1834, align 8, !tbaa !52
  br label %1837

1836:                                             ; preds = %1830
  br label %1837

1837:                                             ; preds = %1836, %1833, %1830, %1826
  %1838 = phi ptr [ %1835, %1833 ], [ %1827, %1830 ], [ %1827, %1826 ], [ %1827, %1836 ]
  %1839 = phi i8 [ %1832, %1833 ], [ %1828, %1830 ], [ %1828, %1826 ], [ %1832, %1836 ]
  %1840 = icmp eq i64 %1800, 24
  br i1 %1840, label %1841, label %1848

1841:                                             ; preds = %1837
  %1842 = load ptr, ptr %217, align 8, !tbaa !42
  %1843 = load i8, ptr %1842, align 1, !tbaa !40
  switch i8 %1843, label %1847 [
    i8 0, label %1848
    i8 4, label %1844
  ]

1844:                                             ; preds = %1841
  %1845 = load ptr, ptr %218, align 8, !tbaa !44
  %1846 = load ptr, ptr %1845, align 8, !tbaa !52
  br label %1848

1847:                                             ; preds = %1841
  br label %1848

1848:                                             ; preds = %1847, %1844, %1841, %1837
  %1849 = phi ptr [ %1846, %1844 ], [ %1838, %1841 ], [ %1838, %1837 ], [ %1838, %1847 ]
  %1850 = phi i8 [ %1843, %1844 ], [ %1839, %1841 ], [ %1839, %1837 ], [ %1843, %1847 ]
  %1851 = icmp eq i64 %1800, 32
  br i1 %1851, label %1852, label %1859

1852:                                             ; preds = %1848
  %1853 = load ptr, ptr %219, align 8, !tbaa !42
  %1854 = load i8, ptr %1853, align 1, !tbaa !40
  switch i8 %1854, label %1858 [
    i8 0, label %1859
    i8 4, label %1855
  ]

1855:                                             ; preds = %1852
  %1856 = load ptr, ptr %220, align 8, !tbaa !44
  %1857 = load ptr, ptr %1856, align 8, !tbaa !52
  br label %1859

1858:                                             ; preds = %1852
  br label %1859

1859:                                             ; preds = %1858, %1855, %1852, %1848
  %1860 = phi ptr [ %1857, %1855 ], [ %1849, %1852 ], [ %1849, %1848 ], [ %1849, %1858 ]
  %1861 = phi i8 [ %1854, %1855 ], [ %1850, %1852 ], [ %1850, %1848 ], [ %1854, %1858 ]
  %1862 = icmp eq i64 %1800, 40
  br i1 %1862, label %1863, label %1870

1863:                                             ; preds = %1859
  %1864 = load ptr, ptr %221, align 8, !tbaa !42
  %1865 = load i8, ptr %1864, align 1, !tbaa !40
  switch i8 %1865, label %1869 [
    i8 0, label %1870
    i8 4, label %1866
  ]

1866:                                             ; preds = %1863
  %1867 = load ptr, ptr %222, align 8, !tbaa !44
  %1868 = load ptr, ptr %1867, align 8, !tbaa !52
  br label %1870

1869:                                             ; preds = %1863
  br label %1870

1870:                                             ; preds = %1869, %1866, %1863, %1859
  %1871 = phi ptr [ %1868, %1866 ], [ %1860, %1863 ], [ %1860, %1859 ], [ %1860, %1869 ]
  %1872 = phi i8 [ %1865, %1866 ], [ %1861, %1863 ], [ %1861, %1859 ], [ %1865, %1869 ]
  %1873 = icmp eq i64 %1800, 48
  br i1 %1873, label %1874, label %1881

1874:                                             ; preds = %1870
  %1875 = load ptr, ptr %223, align 8, !tbaa !42
  %1876 = load i8, ptr %1875, align 1, !tbaa !40
  switch i8 %1876, label %1880 [
    i8 0, label %1881
    i8 4, label %1877
  ]

1877:                                             ; preds = %1874
  %1878 = load ptr, ptr %224, align 8, !tbaa !44
  %1879 = load ptr, ptr %1878, align 8, !tbaa !52
  br label %1881

1880:                                             ; preds = %1874
  br label %1881

1881:                                             ; preds = %1880, %1877, %1874, %1870
  %1882 = phi ptr [ %1879, %1877 ], [ %1871, %1874 ], [ %1871, %1870 ], [ %1871, %1880 ]
  %1883 = phi i8 [ %1876, %1877 ], [ %1872, %1874 ], [ %1872, %1870 ], [ %1876, %1880 ]
  %1884 = icmp eq i64 %1800, 56
  br i1 %1884, label %1885, label %1892

1885:                                             ; preds = %1881
  %1886 = load ptr, ptr %225, align 8, !tbaa !42
  %1887 = load i8, ptr %1886, align 1, !tbaa !40
  switch i8 %1887, label %1891 [
    i8 0, label %1892
    i8 4, label %1888
  ]

1888:                                             ; preds = %1885
  %1889 = load ptr, ptr %226, align 8, !tbaa !44
  %1890 = load ptr, ptr %1889, align 8, !tbaa !52
  br label %1892

1891:                                             ; preds = %1885
  br label %1892

1892:                                             ; preds = %1881, %1885, %1888, %1891, %1797, %1791
  %1893 = phi ptr [ null, %1791 ], [ null, %1797 ], [ %1890, %1888 ], [ %1882, %1885 ], [ %1882, %1881 ], [ %1882, %1891 ]
  %1894 = phi i8 [ 0, %1791 ], [ 0, %1797 ], [ %1887, %1888 ], [ %1883, %1885 ], [ %1883, %1881 ], [ %1887, %1891 ]
  %1895 = icmp eq i8 %1894, 0
  br i1 %1895, label %1901, label %1896

1896:                                             ; preds = %1892
  %1897 = icmp eq i8 %1894, 4
  %1898 = inttoptr i64 %1792 to ptr
  %1899 = select i1 %1897, ptr %1893, ptr %1898
  br label %1901

1900:                                             ; preds = %1741
  br label %1901

1901:                                             ; preds = %1900, %1896, %1892, %1765, %1747, %1744, %1741, %1574, %1541, %1539
  %1902 = phi i1 [ false, %1541 ], [ false, %1574 ], [ true, %1747 ], [ false, %1765 ], [ false, %1744 ], [ true, %1741 ], [ true, %1539 ], [ false, %1900 ], [ false, %1896 ], [ %1895, %1892 ]
  %1903 = phi i8 [ %1544, %1541 ], [ %1584, %1574 ], [ 0, %1747 ], [ %1766, %1765 ], [ %1742, %1744 ], [ %1742, %1741 ], [ 0, %1539 ], [ %1742, %1900 ], [ %1894, %1896 ], [ 0, %1892 ]
  %1904 = phi ptr [ %1545, %1541 ], [ %1585, %1574 ], [ null, %1747 ], [ %1770, %1765 ], [ %1745, %1744 ], [ null, %1741 ], [ null, %1539 ], [ %1743, %1900 ], [ %1899, %1896 ], [ null, %1892 ]
  %1905 = phi i64 [ %1540, %1541 ], [ %1576, %1574 ], [ %1750, %1747 ], [ %1769, %1765 ], [ %1651, %1744 ], [ %1651, %1741 ], [ %1540, %1539 ], [ %1651, %1900 ], [ %1792, %1896 ], [ %1792, %1892 ]
  br i1 %1902, label %1908, label %1906

1906:                                             ; preds = %1901
  %1907 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr %1904, ptr %1907, align 8, !tbaa !40
  br label %1911

1908:                                             ; preds = %1901
  %1909 = inttoptr i64 %1905 to ptr
  %1910 = load ptr, ptr %4, align 8, !tbaa !9
  store ptr %1909, ptr %1910, align 8, !tbaa !40
  br label %1911

1911:                                             ; preds = %1448, %1906, %1908
  %1912 = phi i8 [ 0, %1448 ], [ %1903, %1906 ], [ 0, %1908 ]
  %1913 = load ptr, ptr %4, align 8, !tbaa !9
  %1914 = getelementptr inbounds %struct.x86_sim_gpr_cell, ptr %1913, i64 0, i32 1
  store i8 %1912, ptr %1914, align 8, !tbaa !47
  %1915 = load i8, ptr %44, align 8, !tbaa !40
  %1916 = icmp eq i8 %1915, 0
  %1917 = load ptr, ptr %1, align 8
  %1918 = icmp eq ptr %1917, inttoptr (i64 1161981756646125696 to ptr)
  %1919 = select i1 %1916, i1 %1918, i1 false
  br i1 %1919, label %1921, label %1920

1920:                                             ; preds = %1911
  call void @__assert_fail(ptr noundef nonnull @.str.7, ptr noundef nonnull @.str.1, i32 noundef 58, ptr noundef nonnull @__PRETTY_FUNCTION__.main) #6
  unreachable

1921:                                             ; preds = %1911
  %1922 = add nuw nsw i32 %280, 1
  %1923 = icmp eq i32 %280, 0
  br i1 %1923, label %279, label %276, !llvm.loop !62
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nofree nounwind
declare noundef i32 @fprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #4

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.fshl.i64(i64, i64, i64) #5

attributes #0 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { noreturn nounwind }
attributes #7 = { nounwind }
attributes #8 = { cold }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!5 = distinct !{!5, !6, !7}
!6 = !{!"llvm.loop.mustprogress"}
!7 = !{!"llvm.loop.unroll.disable"}
!8 = distinct !{!8, !6, !7}
!9 = !{!10, !11, i64 0}
!10 = !{!"x86_sim_inline_bindings", !11, i64 0, !11, i64 8, !12, i64 16, !11, i64 144, !11, i64 152, !11, i64 160, !11, i64 168, !11, i64 176, !11, i64 184, !11, i64 192, !11, i64 200, !11, i64 208, !11, i64 216, !11, i64 224, !11, i64 232, !11, i64 240, !12, i64 248, !12, i64 249}
!11 = !{!"any pointer", !12, i64 0}
!12 = !{!"omnipotent char", !13, i64 0}
!13 = !{!"Simple C/C++ TBAA"}
!14 = !{!10, !11, i64 8}
!15 = !{!10, !11, i64 144}
!16 = !{!10, !11, i64 152}
!17 = !{!10, !11, i64 160}
!18 = !{!10, !11, i64 168}
!19 = !{!10, !11, i64 176}
!20 = !{!10, !11, i64 184}
!21 = !{!10, !11, i64 192}
!22 = !{!10, !11, i64 200}
!23 = !{!10, !11, i64 208}
!24 = !{!10, !11, i64 216}
!25 = !{!26, !11, i64 632}
!26 = !{!"x86_sim_state", !12, i64 0, !27, i64 256, !12, i64 264, !12, i64 265, !12, i64 266, !12, i64 267, !12, i64 268, !12, i64 269, !27, i64 272, !27, i64 280, !27, i64 288, !28, i64 296, !12, i64 304, !29, i64 368, !30, i64 408, !11, i64 624, !11, i64 632, !12, i64 640, !11, i64 648, !12, i64 656}
!27 = !{!"long long", !12, i64 0}
!28 = !{!"int", !12, i64 0}
!29 = !{!"x86_sim_xdp_abi", !11, i64 0, !11, i64 8, !12, i64 16}
!30 = !{!"x86_sim_skb_abi", !12, i64 0, !12, i64 48, !12, i64 68, !11, i64 80, !12, i64 88, !11, i64 208}
!31 = !{!10, !11, i64 224}
!32 = !{!26, !11, i64 648}
!33 = !{!10, !11, i64 232}
!34 = !{!26, !11, i64 624}
!35 = !{!10, !11, i64 240}
!36 = !{!26, !12, i64 640}
!37 = !{!10, !12, i64 248}
!38 = !{!26, !12, i64 656}
!39 = !{!10, !12, i64 249}
!40 = !{!12, !12, i64 0}
!41 = !{!26, !27, i64 256}
!42 = !{!43, !11, i64 0}
!43 = !{!"x86_sim_inline_value", !11, i64 0, !11, i64 8}
!44 = !{!43, !11, i64 8}
!45 = distinct !{!45, !6, !7}
!46 = distinct !{!46, !6, !7}
!47 = !{!48, !12, i64 8}
!48 = !{!"x86_sim_gpr_cell", !12, i64 0, !12, i64 8}
!49 = !{i64 2153180196}
!50 = !{!27, !27, i64 0}
!51 = !{i64 2153193093}
!52 = !{!11, !11, i64 0}
!53 = !{i64 2153225496}
!54 = !{i64 2153024472}
!55 = !{!28, !28, i64 0}
!56 = !{!57, !28, i64 0}
!57 = !{!"xdp_md", !28, i64 0, !28, i64 4, !28, i64 8, !28, i64 12, !28, i64 16, !28, i64 20}
!58 = !{!57, !28, i64 4}
!59 = !{!57, !28, i64 8}
!60 = !{i64 2153036458}
!61 = !{i64 2153057873}
!62 = distinct !{!62, !6, !7}
