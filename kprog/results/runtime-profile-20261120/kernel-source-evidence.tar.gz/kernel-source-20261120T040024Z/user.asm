
/var/tmp/kprog-tmp/perf/runtime-profile-user/user.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_probe_read_user>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 53                           	pushq	%rbx
       5: 49 89 fe                     	movq	%rdi, %r14
       8: 89 f3                        	movl	%esi, %ebx
       a: 48 89 d6                     	movq	%rdx, %rsi
       d: 48 89 da                     	movq	%rbx, %rdx
      10: e8 00 00 00 00               	callq	0x15 <__kprog_probe_read_user+0x15>
		0000000000000011:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      15: 49 89 c7                     	movq	%rax, %r15
      18: 45 85 ff                     	testl	%r15d, %r15d
      1b: 79 0d                        	jns	0x2a <__kprog_probe_read_user+0x2a>
      1d: 4c 89 f7                     	movq	%r14, %rdi
      20: 31 f6                        	xorl	%esi, %esi
      22: 48 89 da                     	movq	%rbx, %rdx
      25: e8 00 00 00 00               	callq	0x2a <__kprog_probe_read_user+0x2a>
		0000000000000026:  R_X86_64_PLT32	memset-0x4
      2a: 49 63 c7                     	movslq	%r15d, %rax
      2d: 5b                           	popq	%rbx
      2e: 41 5e                        	popq	%r14
      30: 41 5f                        	popq	%r15
      32: c3                           	retq
      33: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000040 <__kprog_probe_read_kernel>:
      40: 41 57                        	pushq	%r15
      42: 41 56                        	pushq	%r14
      44: 53                           	pushq	%rbx
      45: 49 89 fe                     	movq	%rdi, %r14
      48: 89 f3                        	movl	%esi, %ebx
      4a: 48 89 d6                     	movq	%rdx, %rsi
      4d: 48 89 da                     	movq	%rbx, %rdx
      50: e8 00 00 00 00               	callq	0x55 <__kprog_probe_read_kernel+0x15>
		0000000000000051:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
      55: 49 89 c7                     	movq	%rax, %r15
      58: 45 85 ff                     	testl	%r15d, %r15d
      5b: 79 0d                        	jns	0x6a <__kprog_probe_read_kernel+0x2a>
      5d: 4c 89 f7                     	movq	%r14, %rdi
      60: 31 f6                        	xorl	%esi, %esi
      62: 48 89 da                     	movq	%rbx, %rdx
      65: e8 00 00 00 00               	callq	0x6a <__kprog_probe_read_kernel+0x2a>
		0000000000000066:  R_X86_64_PLT32	memset-0x4
      6a: 49 63 c7                     	movslq	%r15d, %rax
      6d: 5b                           	popq	%rbx
      6e: 41 5e                        	popq	%r14
      70: 41 5f                        	popq	%r15
      72: c3                           	retq
      73: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000080 <user8>:
      80: 48 89 f2                     	movq	%rsi, %rdx
      83: be 08 00 00 00               	movl	$0x8, %esi
      88: e9 00 00 00 00               	jmp	0x8d <user8+0xd>
		0000000000000089:  R_X86_64_PLT32	bpf_probe_read_user-0x4
      8d: 0f 1f 00                     	nopl	(%rax)

0000000000000090 <user_dynamic>:
      90: e9 00 00 00 00               	jmp	0x95 <user_dynamic+0x5>
		0000000000000091:  R_X86_64_PLT32	bpf_probe_read_user-0x4
      95: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

00000000000000a0 <kernel8>:
      a0: 48 89 f2                     	movq	%rsi, %rdx
      a3: be 08 00 00 00               	movl	$0x8, %esi
      a8: e9 00 00 00 00               	jmp	0xad <kernel8+0xd>
		00000000000000a9:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
      ad: 0f 1f 00                     	nopl	(%rax)

00000000000000b0 <kernel_dynamic>:
      b0: e9 00 00 00 00               	jmp	0xb5 <kernel_dynamic+0x5>
		00000000000000b1:  R_X86_64_PLT32	bpf_probe_read_kernel-0x4
      b5: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

00000000000000c0 <kernel_str8>:
      c0: 48 89 f2                     	movq	%rsi, %rdx
      c3: be 08 00 00 00               	movl	$0x8, %esi
      c8: e9 00 00 00 00               	jmp	0xcd <kernel_str8+0xd>
		00000000000000c9:  R_X86_64_PLT32	bpf_probe_read_kernel_str-0x4
      cd: 0f 1f 00                     	nopl	(%rax)

00000000000000d0 <kernel_str_dynamic>:
      d0: e9 00 00 00 00               	jmp	0xd5 <kernel_str_dynamic+0x5>
		00000000000000d1:  R_X86_64_PLT32	bpf_probe_read_kernel_str-0x4
      d5: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

00000000000000e0 <compat>:
      e0: e9 00 00 00 00               	jmp	0xe5 <compat+0x5>
		00000000000000e1:  R_X86_64_PLT32	bpf_probe_read-0x4
