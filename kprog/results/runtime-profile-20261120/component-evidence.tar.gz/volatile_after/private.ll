; ModuleID = '/workspaces/repository/kprog/results/runtime-profile-20261120/private.c'
source_filename = "/workspaces/repository/kprog/results/runtime-profile-20261120/private.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%union.x86_sim_stack_mem = type { [8 x i64] }

@.str = private unnamed_addr constant [51 x i8] c"%u private arena byte/width/neighbor cases passed\0A\00", align 1
@.str.1 = private unnamed_addr constant [34 x i8] c"__x86_stack_mem.b[i]==expected[i]\00", align 1
@.str.2 = private unnamed_addr constant [72 x i8] c"/workspaces/repository/kprog/results/runtime-profile-20261120/private.c\00", align 1
@__PRETTY_FUNCTION__.check = private unnamed_addr constant [44 x i8] c"uint64_t check(uint64_t, int, unsigned int)\00", align 1
@.str.3 = private unnamed_addr constant [18 x i8] c"result==reference\00", align 1

; Function Attrs: nounwind uwtable
define dso_local noundef i32 @main() local_unnamed_addr #0 {
  %1 = alloca %union.x86_sim_stack_mem, align 8
  %2 = alloca [64 x i8], align 16
  %3 = alloca i64, align 8
  %4 = alloca i64, align 8
  %5 = alloca [6 x i64], align 16
  call void @llvm.lifetime.start.p0(i64 48, ptr nonnull %5) #6
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(48) %5, i8 0, i64 48, i1 false)
  %6 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 1
  store i64 1, ptr %6, align 8
  %7 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 2
  store i64 4294967295, ptr %7, align 16
  %8 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 3
  store i64 4294967296, ptr %8, align 8
  %9 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 4
  store i64 -9223372036854775808, ptr %9, align 16
  %10 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 5
  store i64 -1, ptr %10, align 8
  %11 = getelementptr inbounds i8, ptr %2, i64 64
  %12 = getelementptr i8, ptr %1, i64 65
  %13 = getelementptr i8, ptr %1, i64 66
  %14 = getelementptr i8, ptr %1, i64 67
  %15 = getelementptr i8, ptr %1, i64 68
  %16 = getelementptr i8, ptr %1, i64 69
  %17 = getelementptr i8, ptr %1, i64 70
  %18 = getelementptr i8, ptr %1, i64 71
  br label %19

19:                                               ; preds = %0, %77
  %20 = phi i64 [ 0, %0 ], [ %78, %77 ]
  %21 = phi i32 [ 0, %0 ], [ %28, %77 ]
  %22 = getelementptr inbounds [6 x i64], ptr %5, i64 0, i64 %20
  %23 = load i64, ptr %22, align 8, !tbaa !5
  %24 = xor i64 %23, -1
  %25 = trunc i64 %24 to i32
  %26 = trunc i64 %24 to i8
  %27 = trunc i64 %24 to i16
  %28 = add nuw nsw i32 %21, 228
  br label %31

29:                                               ; preds = %77
  %30 = tail call i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i32 noundef 1368)
  call void @llvm.lifetime.end.p0(i64 48, ptr nonnull %5) #6
  ret i32 0

31:                                               ; preds = %19, %80
  %32 = phi i64 [ -64, %19 ], [ %81, %80 ]
  %33 = phi i32 [ %21, %19 ], [ %35, %80 ]
  %34 = phi i32 [ %21, %19 ], [ %76, %80 ]
  %35 = add i32 %33, 4
  %36 = add nsw i64 %32, 64
  %37 = and i64 %32, 7
  %38 = icmp eq i64 %37, 0
  %39 = getelementptr inbounds i8, ptr %11, i64 %32
  %40 = and i64 %32, 3
  %41 = icmp ne i64 %40, 0
  %42 = lshr exact i64 %36, 2
  %43 = getelementptr inbounds [16 x i32], ptr %1, i64 0, i64 %42
  %44 = and i64 %32, 1
  %45 = icmp eq i64 %44, 0
  %46 = getelementptr inbounds [64 x i8], ptr %1, i64 0, i64 %36
  %47 = getelementptr inbounds i8, ptr %46, i64 1
  %48 = getelementptr inbounds i8, ptr %46, i64 2
  %49 = getelementptr inbounds i8, ptr %46, i64 3
  %50 = getelementptr inbounds i8, ptr %46, i64 4
  %51 = getelementptr inbounds i8, ptr %46, i64 5
  %52 = getelementptr inbounds i8, ptr %46, i64 6
  %53 = getelementptr inbounds i8, ptr %46, i64 7
  %54 = lshr exact i64 %36, 1
  %55 = getelementptr inbounds [32 x i16], ptr %1, i64 0, i64 %54
  %56 = lshr i64 %36, 3
  %57 = getelementptr inbounds [8 x i64], ptr %1, i64 0, i64 %56
  %58 = and i64 %32, 3
  %59 = icmp eq i64 %58, 0
  %60 = and i64 %32, 1
  %61 = icmp eq i64 %60, 0
  %62 = getelementptr inbounds i8, ptr %1, i64 %36
  %63 = getelementptr i8, ptr %12, i64 %32
  %64 = getelementptr i8, ptr %13, i64 %32
  %65 = getelementptr i8, ptr %14, i64 %32
  %66 = getelementptr i8, ptr %15, i64 %32
  %67 = getelementptr i8, ptr %16, i64 %32
  %68 = getelementptr i8, ptr %17, i64 %32
  %69 = getelementptr i8, ptr %18, i64 %32
  %70 = lshr exact i64 %36, 1
  %71 = getelementptr inbounds [32 x i16], ptr %1, i64 0, i64 %70
  %72 = lshr exact i64 %36, 2
  %73 = getelementptr inbounds [16 x i32], ptr %1, i64 0, i64 %72
  %74 = lshr i64 %36, 3
  %75 = getelementptr inbounds [8 x i64], ptr %1, i64 0, i64 %74
  %76 = add i32 %34, 4
  br label %83

77:                                               ; preds = %80
  %78 = add nuw nsw i64 %20, 1
  %79 = icmp eq i64 %78, 6
  br i1 %79, label %29, label %19, !llvm.loop !9

80:                                               ; preds = %235
  %81 = add nuw nsw i64 %32, 1
  %82 = icmp eq i64 %81, -7
  br i1 %82, label %77, label %31, !llvm.loop !12

83:                                               ; preds = %31, %235
  %84 = phi i32 [ 1, %31 ], [ %237, %235 ]
  %85 = phi i32 [ %34, %31 ], [ %236, %235 ]
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %1) #6
  call void @llvm.lifetime.start.p0(i64 64, ptr nonnull %2) #6
  br label %90

86:                                               ; preds = %90
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %3)
  store i64 %24, ptr %3, align 8, !tbaa !5
  %87 = trunc i32 %84 to i8
  %88 = icmp eq i8 %87, 8
  %89 = and i1 %38, %88
  br i1 %89, label %97, label %98

90:                                               ; preds = %90, %83
  %91 = phi i64 [ 0, %83 ], [ %95, %90 ]
  %92 = getelementptr inbounds [8 x i64], ptr %1, i64 0, i64 %91
  store i64 %23, ptr %92, align 8, !tbaa !13
  %93 = shl nuw nsw i64 %91, 3
  %94 = getelementptr inbounds i8, ptr %2, i64 %93
  store i64 %23, ptr %94, align 8
  %95 = add nuw nsw i64 %91, 1
  %96 = icmp eq i64 %95, 8
  br i1 %96, label %86, label %90, !llvm.loop !14

97:                                               ; preds = %86
  store i64 %24, ptr %57, align 8, !tbaa !13
  br label %145

98:                                               ; preds = %86
  %99 = icmp ne i8 %87, 4
  %100 = or i1 %41, %99
  br i1 %100, label %102, label %101

101:                                              ; preds = %98
  store i32 %25, ptr %43, align 4, !tbaa !13
  br label %145

102:                                              ; preds = %98
  %103 = icmp eq i8 %87, 2
  %104 = and i1 %45, %103
  br i1 %104, label %105, label %106

105:                                              ; preds = %102
  store i16 %27, ptr %55, align 2, !tbaa !13
  br label %145

106:                                              ; preds = %102
  switch i8 %87, label %107 [
    i8 1, label %111
    i8 2, label %110
  ]

107:                                              ; preds = %106
  %108 = icmp eq i8 %87, 4
  %109 = select i1 %108, i64 4294967295, i64 -1
  br label %111

110:                                              ; preds = %106
  br label %111

111:                                              ; preds = %110, %107, %106
  %112 = phi i64 [ 255, %106 ], [ %109, %107 ], [ 65535, %110 ]
  %113 = and i64 %112, %24
  store i8 %26, ptr %46, align 1, !tbaa !13
  %114 = icmp ne i8 %87, 1
  br i1 %114, label %115, label %126

115:                                              ; preds = %111
  %116 = lshr i64 %113, 8
  %117 = trunc i64 %116 to i8
  store i8 %117, ptr %47, align 1, !tbaa !13
  br i1 %103, label %123, label %118

118:                                              ; preds = %115
  %119 = lshr i64 %113, 16
  %120 = trunc i64 %119 to i8
  store i8 %120, ptr %48, align 1, !tbaa !13
  %121 = lshr i64 %113, 24
  %122 = trunc i64 %121 to i8
  store i8 %122, ptr %49, align 1, !tbaa !13
  br label %123

123:                                              ; preds = %118, %115
  %124 = select i1 %99, i8 15, i8 0
  %125 = select i1 %103, i8 0, i8 %124
  br label %126

126:                                              ; preds = %123, %111
  %127 = phi i8 [ %125, %123 ], [ 0, %111 ]
  %128 = and i8 %127, 1
  %129 = icmp eq i8 %128, 0
  br i1 %129, label %133, label %130

130:                                              ; preds = %126
  %131 = lshr i64 %113, 32
  %132 = trunc i64 %131 to i8
  store i8 %132, ptr %50, align 1, !tbaa !13
  br label %133

133:                                              ; preds = %130, %126
  switch i8 %87, label %134 [
    i8 4, label %139
    i8 2, label %139
    i8 1, label %139
  ]

134:                                              ; preds = %133
  %135 = lshr i64 %113, 40
  %136 = trunc i64 %135 to i8
  store i8 %136, ptr %51, align 1, !tbaa !13
  %137 = lshr i64 %113, 48
  %138 = trunc i64 %137 to i8
  store i8 %138, ptr %52, align 1, !tbaa !13
  br label %139

139:                                              ; preds = %134, %133, %133, %133
  %140 = xor i1 %103, %99
  %141 = and i1 %114, %140
  br i1 %141, label %142, label %145

142:                                              ; preds = %139
  %143 = lshr i64 %113, 56
  %144 = trunc i64 %143 to i8
  store i8 %144, ptr %53, align 1, !tbaa !13
  br label %145

145:                                              ; preds = %142, %139, %105, %101, %97
  %146 = zext nneg i32 %84 to i64
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(1) %39, ptr noundef nonnull align 8 dereferenceable(1) %3, i64 %146, i1 false)
  br label %151

147:                                              ; preds = %151
  %148 = add nuw nsw i64 %152, 1
  %149 = icmp eq i64 %148, 64
  br i1 %149, label %150, label %151, !llvm.loop !15

150:                                              ; preds = %147
  br i1 %89, label %159, label %161

151:                                              ; preds = %147, %145
  %152 = phi i64 [ 0, %145 ], [ %148, %147 ]
  %153 = getelementptr inbounds [64 x i8], ptr %1, i64 0, i64 %152
  %154 = load i8, ptr %153, align 1, !tbaa !13
  %155 = getelementptr inbounds [64 x i8], ptr %2, i64 0, i64 %152
  %156 = load i8, ptr %155, align 1, !tbaa !13
  %157 = icmp eq i8 %154, %156
  br i1 %157, label %147, label %158

158:                                              ; preds = %151
  tail call void @__assert_fail(ptr noundef nonnull @.str.1, ptr noundef nonnull @.str.2, i32 noundef 20, ptr noundef nonnull @__PRETTY_FUNCTION__.check) #7
  unreachable

159:                                              ; preds = %150
  %160 = load i64, ptr %75, align 8, !tbaa !13
  br label %230

161:                                              ; preds = %150
  %162 = icmp eq i8 %87, 4
  %163 = and i1 %59, %162
  br i1 %163, label %164, label %167

164:                                              ; preds = %161
  %165 = load i32, ptr %73, align 4, !tbaa !13
  %166 = zext i32 %165 to i64
  br label %230

167:                                              ; preds = %161
  %168 = icmp eq i8 %87, 2
  %169 = and i1 %61, %168
  br i1 %169, label %170, label %173

170:                                              ; preds = %167
  %171 = load i16, ptr %71, align 2, !tbaa !13
  %172 = zext i16 %171 to i64
  br label %230

173:                                              ; preds = %167
  %174 = load i8, ptr %62, align 1, !tbaa !13
  %175 = zext i8 %174 to i64
  %176 = icmp eq i8 %87, 1
  br i1 %176, label %182, label %177

177:                                              ; preds = %173
  %178 = load i8, ptr %63, align 1, !tbaa !13
  %179 = zext i8 %178 to i64
  %180 = shl nuw nsw i64 %179, 8
  %181 = or disjoint i64 %180, %175
  br label %182

182:                                              ; preds = %177, %173
  %183 = phi i64 [ %181, %177 ], [ %175, %173 ]
  %184 = add nsw i8 %87, -1
  %185 = icmp ult i8 %184, 2
  br i1 %185, label %191, label %186

186:                                              ; preds = %182
  %187 = load i8, ptr %64, align 1, !tbaa !13
  %188 = zext i8 %187 to i64
  %189 = shl nuw nsw i64 %188, 16
  %190 = or i64 %189, %183
  br label %191

191:                                              ; preds = %186, %182
  %192 = phi i64 [ %190, %186 ], [ %183, %182 ]
  br i1 %185, label %198, label %193

193:                                              ; preds = %191
  %194 = load i8, ptr %65, align 1, !tbaa !13
  %195 = zext i8 %194 to i64
  %196 = shl nuw nsw i64 %195, 24
  %197 = or i64 %196, %192
  br label %198

198:                                              ; preds = %193, %191
  %199 = phi i64 [ %197, %193 ], [ %192, %191 ]
  br i1 %176, label %206, label %200

200:                                              ; preds = %198
  switch i8 %87, label %201 [
    i8 4, label %206
    i8 2, label %206
  ]

201:                                              ; preds = %200
  %202 = load i8, ptr %66, align 1, !tbaa !13
  %203 = zext i8 %202 to i64
  %204 = shl nuw nsw i64 %203, 32
  %205 = or i64 %204, %199
  br label %206

206:                                              ; preds = %201, %200, %200, %198
  %207 = phi i64 [ %205, %201 ], [ %199, %200 ], [ %199, %198 ], [ %199, %200 ]
  br i1 %176, label %214, label %208

208:                                              ; preds = %206
  switch i8 %87, label %209 [
    i8 4, label %214
    i8 2, label %214
  ]

209:                                              ; preds = %208
  %210 = load i8, ptr %67, align 1, !tbaa !13
  %211 = zext i8 %210 to i64
  %212 = shl nuw nsw i64 %211, 40
  %213 = or i64 %212, %207
  br label %214

214:                                              ; preds = %209, %208, %208, %206
  %215 = phi i64 [ %213, %209 ], [ %207, %208 ], [ %207, %206 ], [ %207, %208 ]
  br i1 %176, label %222, label %216

216:                                              ; preds = %214
  switch i8 %87, label %217 [
    i8 4, label %222
    i8 2, label %222
  ]

217:                                              ; preds = %216
  %218 = load i8, ptr %68, align 1, !tbaa !13
  %219 = zext i8 %218 to i64
  %220 = shl nuw nsw i64 %219, 48
  %221 = or i64 %220, %215
  br label %222

222:                                              ; preds = %217, %216, %216, %214
  %223 = phi i64 [ %221, %217 ], [ %215, %216 ], [ %215, %214 ], [ %215, %216 ]
  br i1 %176, label %230, label %224

224:                                              ; preds = %222
  switch i8 %87, label %225 [
    i8 4, label %230
    i8 2, label %230
  ]

225:                                              ; preds = %224
  %226 = load i8, ptr %69, align 1, !tbaa !13
  %227 = zext i8 %226 to i64
  %228 = shl nuw i64 %227, 56
  %229 = or i64 %228, %223
  br label %230

230:                                              ; preds = %225, %224, %224, %222, %170, %164, %159
  %231 = phi i64 [ %160, %159 ], [ %166, %164 ], [ %172, %170 ], [ %229, %225 ], [ %223, %224 ], [ %223, %222 ], [ %223, %224 ]
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %4)
  store i64 0, ptr %4, align 8, !tbaa !5
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(1) %4, ptr noundef nonnull align 8 dereferenceable(1) %3, i64 %146, i1 false)
  %232 = load i64, ptr %4, align 8, !tbaa !5
  %233 = icmp eq i64 %231, %232
  br i1 %233, label %235, label %234

234:                                              ; preds = %230
  tail call void @__assert_fail(ptr noundef nonnull @.str.3, ptr noundef nonnull @.str.2, i32 noundef 24, ptr noundef nonnull @__PRETTY_FUNCTION__.check) #7
  unreachable

235:                                              ; preds = %230
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %4)
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %3)
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %2) #6
  call void @llvm.lifetime.end.p0(i64 64, ptr nonnull %1) #6
  %236 = add i32 %85, 1
  %237 = shl nuw nsw i32 %84, 1
  %238 = icmp eq i32 %236, %35
  br i1 %238, label %80, label %83, !llvm.loop !16
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree nounwind
declare noundef i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #3

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: noreturn nounwind
declare void @__assert_fail(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #5

attributes #0 = { nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #3 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { noreturn nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nounwind }
attributes #7 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!5 = !{!6, !6, i64 0}
!6 = !{!"long", !7, i64 0}
!7 = !{!"omnipotent char", !8, i64 0}
!8 = !{!"Simple C/C++ TBAA"}
!9 = distinct !{!9, !10, !11}
!10 = !{!"llvm.loop.mustprogress"}
!11 = !{!"llvm.loop.unroll.disable"}
!12 = distinct !{!12, !10, !11}
!13 = !{!7, !7, i64 0}
!14 = distinct !{!14, !10, !11}
!15 = distinct !{!15, !10, !11}
!16 = distinct !{!16, !10, !11}
