
/var/tmp/kprog-tmp/perf/runtime-profile-user/user.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_probe_read_user>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 53                           	pushq	%rbx
       5: 49 89 fe                     	movq	%rdi, %r14
       8: 89 f3                        	movl	%esi, %ebx
       a: 48 89 d6                     	movq	%rdx, %rsi
       d: 48 89 da                     	movq	%rbx, %rdx
      10: e8 00 00 00 00               	callq	0x15 <__kprog_probe_read_user+0x15>
		0000000000000011:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      15: 49 89 c7                     	movq	%rax, %r15
      18: 45 85 ff                     	testl	%r15d, %r15d
      1b: 79 0d                        	jns	0x2a <__kprog_probe_read_user+0x2a>
      1d: 4c 89 f7                     	movq	%r14, %rdi
      20: 31 f6                        	xorl	%esi, %esi
      22: 48 89 da                     	movq	%rbx, %rdx
      25: e8 00 00 00 00               	callq	0x2a <__kprog_probe_read_user+0x2a>
		0000000000000026:  R_X86_64_PLT32	memset-0x4
      2a: 49 63 c7                     	movslq	%r15d, %rax
      2d: 5b                           	popq	%rbx
      2e: 41 5e                        	popq	%r14
      30: 41 5f                        	popq	%r15
      32: c3                           	retq
      33: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000040 <__kprog_probe_read_kernel>:
      40: 41 57                        	pushq	%r15
      42: 41 56                        	pushq	%r14
      44: 53                           	pushq	%rbx
      45: 49 89 fe                     	movq	%rdi, %r14
      48: 89 f3                        	movl	%esi, %ebx
      4a: 48 89 d6                     	movq	%rdx, %rsi
      4d: 48 89 da                     	movq	%rbx, %rdx
      50: e8 00 00 00 00               	callq	0x55 <__kprog_probe_read_kernel+0x15>
		0000000000000051:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
      55: 49 89 c7                     	movq	%rax, %r15
      58: 45 85 ff                     	testl	%r15d, %r15d
      5b: 79 0d                        	jns	0x6a <__kprog_probe_read_kernel+0x2a>
      5d: 4c 89 f7                     	movq	%r14, %rdi
      60: 31 f6                        	xorl	%esi, %esi
      62: 48 89 da                     	movq	%rbx, %rdx
      65: e8 00 00 00 00               	callq	0x6a <__kprog_probe_read_kernel+0x2a>
		0000000000000066:  R_X86_64_PLT32	memset-0x4
      6a: 49 63 c7                     	movslq	%r15d, %rax
      6d: 5b                           	popq	%rbx
      6e: 41 5e                        	popq	%r14
      70: 41 5f                        	popq	%r15
      72: c3                           	retq
      73: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000080 <user8>:
      80: 53                           	pushq	%rbx
      81: 48 89 fb                     	movq	%rdi, %rbx
      84: ba 08 00 00 00               	movl	$0x8, %edx
      89: e8 00 00 00 00               	callq	0x8e <user8+0xe>
		000000000000008a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      8e: 85 c0                        	testl	%eax, %eax
      90: 79 07                        	jns	0x99 <user8+0x19>
      92: 48 c7 03 00 00 00 00         	movq	$0x0, (%rbx)
      99: 48 98                        	cltq
      9b: 5b                           	popq	%rbx
      9c: c3                           	retq
      9d: 0f 1f 00                     	nopl	(%rax)

00000000000000a0 <user_dynamic>:
      a0: 41 57                        	pushq	%r15
      a2: 41 56                        	pushq	%r14
      a4: 53                           	pushq	%rbx
      a5: 49 89 fe                     	movq	%rdi, %r14
      a8: 89 f3                        	movl	%esi, %ebx
      aa: 48 89 d6                     	movq	%rdx, %rsi
      ad: 48 89 da                     	movq	%rbx, %rdx
      b0: e8 00 00 00 00               	callq	0xb5 <user_dynamic+0x15>
		00000000000000b1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      b5: 49 89 c7                     	movq	%rax, %r15
      b8: 45 85 ff                     	testl	%r15d, %r15d
      bb: 79 0d                        	jns	0xca <user_dynamic+0x2a>
      bd: 4c 89 f7                     	movq	%r14, %rdi
      c0: 31 f6                        	xorl	%esi, %esi
      c2: 48 89 da                     	movq	%rbx, %rdx
      c5: e8 00 00 00 00               	callq	0xca <user_dynamic+0x2a>
		00000000000000c6:  R_X86_64_PLT32	memset-0x4
      ca: 49 63 c7                     	movslq	%r15d, %rax
      cd: 5b                           	popq	%rbx
      ce: 41 5e                        	popq	%r14
      d0: 41 5f                        	popq	%r15
      d2: c3                           	retq
      d3: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

00000000000000e0 <kernel8>:
      e0: 53                           	pushq	%rbx
      e1: 48 89 fb                     	movq	%rdi, %rbx
      e4: ba 08 00 00 00               	movl	$0x8, %edx
      e9: e8 00 00 00 00               	callq	0xee <kernel8+0xe>
		00000000000000ea:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
      ee: 85 c0                        	testl	%eax, %eax
      f0: 79 07                        	jns	0xf9 <kernel8+0x19>
      f2: 48 c7 03 00 00 00 00         	movq	$0x0, (%rbx)
      f9: 48 98                        	cltq
      fb: 5b                           	popq	%rbx
      fc: c3                           	retq
      fd: 0f 1f 00                     	nopl	(%rax)

0000000000000100 <kernel_dynamic>:
     100: 41 57                        	pushq	%r15
     102: 41 56                        	pushq	%r14
     104: 53                           	pushq	%rbx
     105: 49 89 fe                     	movq	%rdi, %r14
     108: 89 f3                        	movl	%esi, %ebx
     10a: 48 89 d6                     	movq	%rdx, %rsi
     10d: 48 89 da                     	movq	%rbx, %rdx
     110: e8 00 00 00 00               	callq	0x115 <kernel_dynamic+0x15>
		0000000000000111:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
     115: 49 89 c7                     	movq	%rax, %r15
     118: 45 85 ff                     	testl	%r15d, %r15d
     11b: 79 0d                        	jns	0x12a <kernel_dynamic+0x2a>
     11d: 4c 89 f7                     	movq	%r14, %rdi
     120: 31 f6                        	xorl	%esi, %esi
     122: 48 89 da                     	movq	%rbx, %rdx
     125: e8 00 00 00 00               	callq	0x12a <kernel_dynamic+0x2a>
		0000000000000126:  R_X86_64_PLT32	memset-0x4
     12a: 49 63 c7                     	movslq	%r15d, %rax
     12d: 5b                           	popq	%rbx
     12e: 41 5e                        	popq	%r14
     130: 41 5f                        	popq	%r15
     132: c3                           	retq
     133: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000140 <compat>:
     140: e9 00 00 00 00               	jmp	0x145 <compat+0x5>
		0000000000000141:  R_X86_64_PLT32	bpf_probe_read-0x4
