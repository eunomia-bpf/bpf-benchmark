
/workspaces/repository/kprog/fidelity/build-lea-published-validation/abi-observation/callee_saved_clobber.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 bb f0 de bc 9a 78 56 34 12                   	movabs rbx,0x123456789abcdef0
   a:	b8 02 00 00 00                                  	mov    eax,0x2
   f:	c3                                              	ret
