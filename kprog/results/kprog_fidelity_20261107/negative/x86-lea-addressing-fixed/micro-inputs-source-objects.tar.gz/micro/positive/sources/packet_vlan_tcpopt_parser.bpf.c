#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 32U
#include "/workspaces/repository/kprog/fidelity/build-lea-addressing-validation/micro/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int packet_vlan_tcpopt_parser_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rdx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    r10,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_9:
	/* 0x9: cmp    rdx,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R10, X86_WIDTH_64);
x86_l_c:
	/* 0xc: ja     2d2 <packet_vlan_tcpopt_parser_xdp+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc, 0x2d2, x86_l_2d2);
x86_l_12:
	/* 0x12: lea    rcx,[rdx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16:
	/* 0x16: cmp    rcx,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_R10, X86_WIDTH_64);
x86_l_19:
	/* 0x19: ja     2d2 <packet_vlan_tcpopt_parser_xdp+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x19, 0x2d2, x86_l_2d2);
x86_l_1f:
	/* 0x1f: lea    r9,[rdx+0x16] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_23:
	/* 0x23: cmp    r9,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R9, X86_R10, X86_WIDTH_64);
x86_l_26:
	/* 0x26: ja     2d2 <packet_vlan_tcpopt_parser_xdp+0x2d2> */
	X86_SIM_X86_JCC(X86_CC_A, 0x26, 0x2d2, x86_l_2d2);
x86_l_2c:
	/* 0x2c: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d:
	/* 0x2d: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2f:
	/* 0x2f: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_31:
	/* 0x31: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_32:
	/* 0x32: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_37:
	/* 0x37: movbe  ax,WORD PTR [rdx+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_3d:
	/* 0x3d: movzx  ecx,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_40:
	/* 0x40: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_42:
	/* 0x42: cmp    ecx,0x800 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2048ULL);
x86_l_48:
	/* 0x48: je     f6 <packet_vlan_tcpopt_parser_xdp+0xf6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x48, 0xf6, x86_l_f6);
x86_l_4e:
	/* 0x4e: cmp    ecx,0x88a8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 34984ULL);
x86_l_54:
	/* 0x54: je     62 <packet_vlan_tcpopt_parser_xdp+0x62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x54, 0x62, x86_l_62);
x86_l_56:
	/* 0x56: cmp    ecx,0x8100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 33024ULL);
x86_l_5c:
	/* 0x5c: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c, 0x2cc, x86_l_2cc);
x86_l_62:
	/* 0x62: lea    r9,[rdx+0x1a] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 26ULL);
x86_l_66:
	/* 0x66: cmp    r9,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R9, X86_R10, X86_WIDTH_64);
x86_l_69:
	/* 0x69: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x69, 0x2cc, x86_l_2cc);
x86_l_6f:
	/* 0x6f: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_74:
	/* 0x74: movbe  si,WORD PTR [rdx+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RSI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 22ULL);
x86_l_7a:
	/* 0x7a: mov    ecx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 0ULL);
x86_l_7f:
	/* 0x7f: movbe  cx,WORD PTR [rdx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_85:
	/* 0x85: movzx  ecx,cx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_88:
	/* 0x88: cmp    ecx,0x800 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2048ULL);
x86_l_8e:
	/* 0x8e: je     2ba <packet_vlan_tcpopt_parser_xdp+0x2ba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e, 0x2ba, x86_l_2ba);
x86_l_94:
	/* 0x94: cmp    ecx,0x88a8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 34984ULL);
x86_l_9a:
	/* 0x9a: je     a8 <packet_vlan_tcpopt_parser_xdp+0xa8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9a, 0xa8, x86_l_a8);
x86_l_9c:
	/* 0x9c: cmp    ecx,0x8100 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 33024ULL);
x86_l_a2:
	/* 0xa2: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa2, 0x2cc, x86_l_2cc);
x86_l_a8:
	/* 0xa8: lea    rcx,[rdx+0x1e] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_ac:
	/* 0xac: cmp    rcx,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_R10, X86_WIDTH_64);
x86_l_af:
	/* 0xaf: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0xaf, 0x2cc, x86_l_2cc);
x86_l_b5:
	/* 0xb5: mov    ecx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 0ULL);
x86_l_ba:
	/* 0xba: movbe  cx,WORD PTR [rdx+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 28ULL);
x86_l_c0:
	/* 0xc0: movzx  ecx,cx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_c3:
	/* 0xc3: cmp    ecx,0x800 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2048ULL);
x86_l_c9:
	/* 0xc9: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc9, 0x2cc, x86_l_2cc);
x86_l_cf:
	/* 0xcf: lea    rcx,[rdx+0x32] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_d3:
	/* 0xd3: cmp    rcx,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_R10, X86_WIDTH_64);
x86_l_d6:
	/* 0xd6: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd6, 0x2cc, x86_l_2cc);
x86_l_dc:
	/* 0xdc: lea    r9,[rdx+0x1e] */
	X86_SIM_L_EXEC_LEA(X86_R9, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_e0:
	/* 0xe0: mov    ecx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 0ULL);
x86_l_e5:
	/* 0xe5: movbe  cx,WORD PTR [rdx+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RCX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 26ULL);
x86_l_eb:
	/* 0xeb: movzx  r8d,cx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_RCX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_ef:
	/* 0xef: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_f4:
	/* 0xf4: jmp    10a <packet_vlan_tcpopt_parser_xdp+0x10a> */
	X86_SIM_X86_JMP(0xf4, 0x10a, x86_l_10a);
x86_l_f6:
	/* 0xf6: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f8:
	/* 0xf8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_fa:
	/* 0xfa: lea    rdi,[r9+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_fe:
	/* 0xfe: cmp    rdi,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_R10, X86_WIDTH_64);
x86_l_101:
	/* 0x101: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x101, 0x2cc, x86_l_2cc);
x86_l_107:
	/* 0x107: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10a:
	/* 0x10a: movzx  edi,BYTE PTR [r9] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_10e:
	/* 0x10e: mov    r11d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RDI, X86_WIDTH_32);
x86_l_111:
	/* 0x111: and    r11b,0xf0 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_8, X86_ALU_AND, 240ULL);
x86_l_115:
	/* 0x115: cmp    r11b,0x40 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_8, 64ULL);
x86_l_119:
	/* 0x119: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x119, 0x2cc, x86_l_2cc);
x86_l_11f:
	/* 0x11f: and    edi,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_122:
	/* 0x122: cmp    dil,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_8, 5ULL);
x86_l_126:
	/* 0x126: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x126, 0x2cc, x86_l_2cc);
x86_l_12c:
	/* 0x12c: lea    rbx,[r9+rdi*4] */
	X86_SIM_L_EXEC_LEA(X86_RBX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_RDI, 2), 0ULL);
x86_l_130:
	/* 0x130: cmp    rbx,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RBX, X86_R10, X86_WIDTH_64);
x86_l_133:
	/* 0x133: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x133, 0x2cc, x86_l_2cc);
x86_l_139:
	/* 0x139: cmp    BYTE PTR [r9+0x9],0x6 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R9, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 38654705670ULL);
x86_l_13e:
	/* 0x13e: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13e, 0x2cc, x86_l_2cc);
x86_l_144:
	/* 0x144: lea    r14,[rbx+0x14] */
	X86_SIM_L_EXEC_LEA(X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_148:
	/* 0x148: cmp    r14,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R14, X86_R10, X86_WIDTH_64);
x86_l_14b:
	/* 0x14b: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14b, 0x2cc, x86_l_2cc);
x86_l_151:
	/* 0x151: movzx  r11d,BYTE PTR [rbx+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 12ULL);
x86_l_156:
	/* 0x156: cmp    r11,0x50 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_64, 80ULL);
x86_l_15a:
	/* 0x15a: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15a, 0x2cc, x86_l_2cc);
x86_l_160:
	/* 0x160: shr    r11d,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_SHR, 2ULL);
x86_l_164:
	/* 0x164: and    r11d,0xfffffffc */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_AND, 4294967292ULL);
x86_l_168:
	/* 0x168: lea    r15,[rbx+r11*1] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_16c:
	/* 0x16c: cmp    r15,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_R10, X86_WIDTH_64);
x86_l_16f:
	/* 0x16f: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x16f, 0x2cc, x86_l_2cc);
x86_l_175:
	/* 0x175: lea    r15,[rbx+0x20] */
	X86_SIM_L_EXEC_LEA(X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_179:
	/* 0x179: cmp    r15,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R15, X86_R10, X86_WIDTH_64);
x86_l_17c:
	/* 0x17c: ja     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17c, 0x2cc, x86_l_2cc);
x86_l_182:
	/* 0x182: cmp    r11b,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_8, 32ULL);
x86_l_186:
	/* 0x186: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x186, 0x2cc, x86_l_2cc);
x86_l_18c:
	/* 0x18c: cmp    BYTE PTR [r14],0x2 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 2ULL);
x86_l_190:
	/* 0x190: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x190, 0x2cc, x86_l_2cc);
x86_l_196:
	/* 0x196: cmp    BYTE PTR [rbx+0x15],0x4 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 90194313220ULL);
x86_l_19a:
	/* 0x19a: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x19a, 0x2cc, x86_l_2cc);
x86_l_1a0:
	/* 0x1a0: cmp    BYTE PTR [rbx+0x18],0x1 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 103079215105ULL);
x86_l_1a4:
	/* 0x1a4: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a4, 0x2cc, x86_l_2cc);
x86_l_1aa:
	/* 0x1aa: cmp    BYTE PTR [rbx+0x19],0x3 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 107374182403ULL);
x86_l_1ae:
	/* 0x1ae: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ae, 0x2cc, x86_l_2cc);
x86_l_1b4:
	/* 0x1b4: cmp    BYTE PTR [rbx+0x1a],0x3 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 111669149699ULL);
x86_l_1b8:
	/* 0x1b8: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1b8, 0x2cc, x86_l_2cc);
x86_l_1be:
	/* 0x1be: cmp    BYTE PTR [rbx+0x1c],0x4 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 120259084292ULL);
x86_l_1c2:
	/* 0x1c2: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c2, 0x2cc, x86_l_2cc);
x86_l_1c8:
	/* 0x1c8: cmp    BYTE PTR [rbx+0x1d],0x2 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 124554051586ULL);
x86_l_1cc:
	/* 0x1cc: jb     2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cc, 0x2cc, x86_l_2cc);
x86_l_1d2:
	/* 0x1d2: cmp    BYTE PTR [rbx+0x1e],0x1 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 128849018881ULL);
x86_l_1d6:
	/* 0x1d6: jne    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d6, 0x2cc, x86_l_2cc);
x86_l_1dc:
	/* 0x1dc: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_1e1:
	/* 0x1e1: movbe  ax,WORD PTR [r9+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RAX, X86_R9, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_1e8:
	/* 0x1e8: shl    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 2ULL);
x86_l_1ec:
	/* 0x1ec: movbe  r10d,DWORD PTR [r9+0xc] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R10, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 12ULL);
x86_l_1f2:
	/* 0x1f2: mov    ebp,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 0ULL);
x86_l_1f7:
	/* 0x1f7: movbe  bp,WORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RBP, X86_RBX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1fc:
	/* 0x1fc: movzx  eax,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1ff:
	/* 0x1ff: movzx  r14d,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R14, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_203:
	/* 0x203: add    r14,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_206:
	/* 0x206: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_20b:
	/* 0x20b: movbe  ax,WORD PTR [rbx+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RAX, X86_RBX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_211:
	/* 0x211: movbe  r9d,DWORD PTR [r9+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_R9, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_217:
	/* 0x217: movzx  eax,ax */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16);
x86_l_21a:
	/* 0x21a: add    rax,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_21d:
	/* 0x21d: xor    rax,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_220:
	/* 0x220: add    rax,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_223:
	/* 0x223: movzx  r9d,BYTE PTR [rbx+0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_228:
	/* 0x228: mov    r10d,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R9, X86_WIDTH_32);
x86_l_22b:
	/* 0x22b: shl    r10d,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_22f:
	/* 0x22f: movzx  r14d,BYTE PTR [rbx+0x17] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_234:
	/* 0x234: or     r10d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R14, X86_WIDTH_32, X86_ALU_OR);
x86_l_237:
	/* 0x237: add    r10,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_23b:
	/* 0x23b: shl    r9d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_23f:
	/* 0x23f: xor    r9,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_242:
	/* 0x242: shl    r14d,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_32, X86_ALU_SHL, 24ULL);
x86_l_246:
	/* 0x246: add    r9,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_249:
	/* 0x249: add    r9,0x30100 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_ADD, 196864ULL);
x86_l_250:
	/* 0x250: movzx  r10d,BYTE PTR [rbx+0x1b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 27ULL);
x86_l_255:
	/* 0x255: mov    r14,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R10, X86_WIDTH_64);
x86_l_258:
	/* 0x258: shl    r14,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_25c:
	/* 0x25c: shl    r10d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_260:
	/* 0x260: xor    r10,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R14, X86_WIDTH_64, X86_ALU_XOR);
x86_l_263:
	/* 0x263: xor    r10,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_XOR);
x86_l_266:
	/* 0x266: movzx  ebx,BYTE PTR [rbx+0x1f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 31ULL);
x86_l_26a:
	/* 0x26a: shl    rbx,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_26e:
	/* 0x26e: or     rbx,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_64, X86_ALU_OR);
x86_l_271:
	/* 0x271: movabs r9,0x144000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_64, 5435817984ULL);
x86_l_27b:
	/* 0x27b: add    r9,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_27e:
	/* 0x27e: shl    esi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_281:
	/* 0x281: or     rsi,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R8, X86_WIDTH_64, X86_ALU_OR);
x86_l_284:
	/* 0x284: xor    rsi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_287:
	/* 0x287: mov    rax,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RCX, X86_WIDTH_64);
x86_l_28a:
	/* 0x28a: shl    rax,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_28e:
	/* 0x28e: shl    edi,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 8ULL);
x86_l_291:
	/* 0x291: or     rdi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_294:
	/* 0x294: or     rdi,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R11, X86_WIDTH_64, X86_ALU_OR);
x86_l_297:
	/* 0x297: movabs rax,0x600000000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 25769803776ULL);
x86_l_2a1:
	/* 0x2a1: add    rax,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2a4:
	/* 0x2a4: add    rax,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_2a7:
	/* 0x2a7: add    ecx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_2aa:
	/* 0x2aa: rol    r9,cl */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RCX, X86_WIDTH_64, X86_ALU_ROL);
x86_l_2ad:
	/* 0x2ad: xor    r9,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RAX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_2b0:
	/* 0x2b0: mov    QWORD PTR [rdx],r9 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RDX, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b3:
	/* 0x2b3: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2b8:
	/* 0x2b8: jmp    2cc <packet_vlan_tcpopt_parser_xdp+0x2cc> */
	X86_SIM_X86_JMP(0x2b8, 0x2cc, x86_l_2cc);
x86_l_2ba:
	/* 0x2ba: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_2bf:
	/* 0x2bf: lea    rdi,[r9+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2c3:
	/* 0x2c3: cmp    rdi,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_R10, X86_WIDTH_64);
x86_l_2c6:
	/* 0x2c6: jbe    107 <packet_vlan_tcpopt_parser_xdp+0x107> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x2c6, 0x107, x86_l_107);
x86_l_2cc:
	/* 0x2cc: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2cd:
	/* 0x2cd: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2cf:
	/* 0x2cf: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2d1:
	/* 0x2d1: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2d2:
	/* 0x2d2: jmp    2d7 <packet_vlan_tcpopt_parser_xdp+0x2d7> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2d7:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
