#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/fidelity/build-lea-addressing-validation/micro/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int packet_toeplitz_rss_hash_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rcx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rsi,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: mov    rdx,rcx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_a:
	/* 0xa: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c:
	/* 0xc: cmp    rdx,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_f:
	/* 0xf: jbe    16 <packet_toeplitz_rss_hash_xdp+0x16> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xf, 0x16, x86_l_16);
x86_l_11:
	/* 0x11: jmp    2ff <packet_toeplitz_rss_hash_xdp+0x2ff> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_16:
	/* 0x16: lea    rdi,[rdx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a:
	/* 0x1a: cmp    rdi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_1d:
	/* 0x1d: ja     11 <packet_toeplitz_rss_hash_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d, 0x11, x86_l_11);
x86_l_1f:
	/* 0x1f: lea    rdi,[rdx+0x3e] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_23:
	/* 0x23: cmp    rdi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_26:
	/* 0x26: ja     11 <packet_toeplitz_rss_hash_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_A, 0x26, 0x11, x86_l_11);
x86_l_28:
	/* 0x28: mov    esi,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 0ULL);
x86_l_2d:
	/* 0x2d: movbe  si,WORD PTR [rdx+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RSI, X86_RDX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_33:
	/* 0x33: movzx  esi,si */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_WIDTH_16);
x86_l_36:
	/* 0x36: cmp    esi,0x800 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 2048ULL);
x86_l_3c:
	/* 0x3c: jne    11 <packet_toeplitz_rss_hash_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3c, 0x11, x86_l_11);
x86_l_3e:
	/* 0x3e: movzx  esi,BYTE PTR [rdx+0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_42:
	/* 0x42: and    sil,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_8, X86_ALU_AND, 15ULL);
x86_l_46:
	/* 0x46: cmp    sil,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_8, 5ULL);
x86_l_4a:
	/* 0x4a: jne    11 <packet_toeplitz_rss_hash_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4a, 0x11, x86_l_11);
x86_l_4c:
	/* 0x4c: cmp    BYTE PTR [rdx+0x1f],0x6 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986182ULL);
x86_l_50:
	/* 0x50: jne    11 <packet_toeplitz_rss_hash_xdp+0x11> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x50, 0x11, x86_l_11);
x86_l_52:
	/* 0x52: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_53:
	/* 0x53: lea    rsi,[rdx+0x1f] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 31ULL);
x86_l_57:
	/* 0x57: mov    rdi,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RDX, X86_WIDTH_64);
x86_l_5a:
	/* 0x5a: add    rdi,0x22 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 34ULL);
x86_l_5e:
	/* 0x5e: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_60:
	/* 0x60: xor    r8d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_63:
	/* 0x63: jmp    90 <packet_toeplitz_rss_hash_xdp+0x90> */
	X86_SIM_X86_JMP(0x63, 0x90, x86_l_90);
x86_l_65:
	/* 0x65: mov    ebx,0xc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 194ULL);
x86_l_6a:
	/* 0x6a: shlx   r10d,r11d,r9d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R10, X86_R11, X86_WIDTH_32, X86_R9, X86_ALU_SHL);
x86_l_6f:
	/* 0x6f: mov    r11d,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 8ULL);
x86_l_75:
	/* 0x75: sub    r11b,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R9, X86_WIDTH_8, X86_ALU_SUB);
x86_l_78:
	/* 0x78: shrx   r11d,ebx,r11d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R11, X86_RBX, X86_WIDTH_32, X86_R11, X86_ALU_SHR);
x86_l_7d:
	/* 0x7d: or     r11d,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R10, X86_WIDTH_32, X86_ALU_OR);
x86_l_80:
	/* 0x80: xor    eax,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_83:
	/* 0x83: inc    r8d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_86:
	/* 0x86: cmp    r8d,0x68 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 104ULL);
x86_l_8a:
	/* 0x8a: je     294 <packet_toeplitz_rss_hash_xdp+0x294> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8a, 0x294, x86_l_294);
x86_l_90:
	/* 0x90: mov    r10d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R8, X86_WIDTH_32);
x86_l_93:
	/* 0x93: shr    r10d,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHR, 3ULL);
x86_l_97:
	/* 0x97: cmp    r8d,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 31ULL);
x86_l_9b:
	/* 0x9b: jbe    b2 <packet_toeplitz_rss_hash_xdp+0xb2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x9b, 0xb2, x86_l_b2);
x86_l_9d:
	/* 0x9d: cmp    r8d,0x3f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 63ULL);
x86_l_a1:
	/* 0xa1: jbe    b2 <packet_toeplitz_rss_hash_xdp+0xb2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa1, 0xb2, x86_l_b2);
x86_l_a3:
	/* 0xa3: cmp    r8d,0x4f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 79ULL);
x86_l_a7:
	/* 0xa7: jbe    b2 <packet_toeplitz_rss_hash_xdp+0xb2> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xa7, 0xb2, x86_l_b2);
x86_l_a9:
	/* 0xa9: mov    r9,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RSI, X86_WIDTH_64);
x86_l_ac:
	/* 0xac: cmp    r8d,0x5f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_32, 95ULL);
x86_l_b0:
	/* 0xb0: ja     b8 <packet_toeplitz_rss_hash_xdp+0xb8> */
	X86_SIM_X86_JCC(X86_CC_A, 0xb0, 0xb8, x86_l_b8);
x86_l_b2:
	/* 0xb2: mov    r9d,r10d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R10, X86_WIDTH_32);
x86_l_b5:
	/* 0xb5: add    r9,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_b8:
	/* 0xb8: movzx  r11d,BYTE PTR [r9] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_R9, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_bc:
	/* 0xbc: mov    r9d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R8, X86_WIDTH_32);
x86_l_bf:
	/* 0xbf: and    r9d,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_c3:
	/* 0xc3: shlx   r11d,r11d,r9d */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_R11, X86_R11, X86_WIDTH_32, X86_R9, X86_ALU_SHL);
x86_l_c8:
	/* 0xc8: test   r11b,r11b */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R11, X86_R11, X86_WIDTH_8);
x86_l_cb:
	/* 0xcb: jns    83 <packet_toeplitz_rss_hash_xdp+0x83> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xcb, 0x83, x86_l_83);
x86_l_cd:
	/* 0xcd: cmp    r10d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 5ULL);
x86_l_d1:
	/* 0xd1: jle    f9 <packet_toeplitz_rss_hash_xdp+0xf9> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xd1, 0xf9, x86_l_f9);
x86_l_d3:
	/* 0xd3: cmp    r10d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 8ULL);
x86_l_d7:
	/* 0xd7: jle    11e <packet_toeplitz_rss_hash_xdp+0x11e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0xd7, 0x11e, x86_l_11e);
x86_l_d9:
	/* 0xd9: cmp    r10d,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 10ULL);
x86_l_dd:
	/* 0xdd: jg     153 <packet_toeplitz_rss_hash_xdp+0x153> */
	X86_SIM_X86_JCC(X86_CC_G, 0xdd, 0x153, x86_l_153);
x86_l_df:
	/* 0xdf: cmp    r10d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 9ULL);
x86_l_e3:
	/* 0xe3: jne    19a <packet_toeplitz_rss_hash_xdp+0x19a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe3, 0x19a, x86_l_19a);
x86_l_e9:
	/* 0xe9: mov    ebx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 67ULL);
x86_l_ee:
	/* 0xee: mov    r11d,0x67253d00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1730493696ULL);
x86_l_f4:
	/* 0xf4: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0xf4, 0x1cc, x86_l_1cc);
x86_l_f9:
	/* 0xf9: cmp    r10d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 2ULL);
x86_l_fd:
	/* 0xfd: jg     13a <packet_toeplitz_rss_hash_xdp+0x13a> */
	X86_SIM_X86_JCC(X86_CC_G, 0xfd, 0x13a, x86_l_13a);
x86_l_ff:
	/* 0xff: test   r10d,r10d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_32);
x86_l_102:
	/* 0x102: je     173 <packet_toeplitz_rss_hash_xdp+0x173> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102, 0x173, x86_l_173);
x86_l_104:
	/* 0x104: cmp    r10d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 1ULL);
x86_l_108:
	/* 0x108: jne    1b4 <packet_toeplitz_rss_hash_xdp+0x1b4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x108, 0x1b4, x86_l_1b4);
x86_l_10e:
	/* 0x10e: mov    ebx,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 37ULL);
x86_l_113:
	/* 0x113: mov    r11d,0x5a56da00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1515641344ULL);
x86_l_119:
	/* 0x119: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x119, 0x1cc, x86_l_1cc);
x86_l_11e:
	/* 0x11e: cmp    r10d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 6ULL);
x86_l_122:
	/* 0x122: je     166 <packet_toeplitz_rss_hash_xdp+0x166> */
	X86_SIM_X86_JCC(X86_CC_E, 0x122, 0x166, x86_l_166);
x86_l_124:
	/* 0x124: cmp    r10d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 7ULL);
x86_l_128:
	/* 0x128: jne    18d <packet_toeplitz_rss_hash_xdp+0x18d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x128, 0x18d, x86_l_18d);
x86_l_12a:
	/* 0x12a: mov    ebx,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 37ULL);
x86_l_12f:
	/* 0x12f: mov    r11d,0xc2416700 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 3259066112ULL);
x86_l_135:
	/* 0x135: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x135, 0x1cc, x86_l_1cc);
x86_l_13a:
	/* 0x13a: cmp    r10d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 3ULL);
x86_l_13e:
	/* 0x13e: je     180 <packet_toeplitz_rss_hash_xdp+0x180> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13e, 0x180, x86_l_180);
x86_l_140:
	/* 0x140: cmp    r10d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 4ULL);
x86_l_144:
	/* 0x144: jne    1c1 <packet_toeplitz_rss_hash_xdp+0x1c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x144, 0x1c1, x86_l_1c1);
x86_l_146:
	/* 0x146: mov    ebx,0xc2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 194ULL);
x86_l_14b:
	/* 0x14b: mov    r11d,0x255b0e00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 626724352ULL);
x86_l_151:
	/* 0x151: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x151, 0x1cc, x86_l_1cc);
x86_l_153:
	/* 0x153: cmp    r10d,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 11ULL);
x86_l_157:
	/* 0x157: jne    1a7 <packet_toeplitz_rss_hash_xdp+0x1a7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x157, 0x1a7, x86_l_1a7);
x86_l_159:
	/* 0x159: mov    ebx,0x8f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 143ULL);
x86_l_15e:
	/* 0x15e: mov    r11d,0x3d43a300 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1027842816ULL);
x86_l_164:
	/* 0x164: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x164, 0x1cc, x86_l_1cc);
x86_l_166:
	/* 0x166: mov    ebx,0x67 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 103ULL);
x86_l_16b:
	/* 0x16b: mov    r11d,0xec24100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 247611648ULL);
x86_l_171:
	/* 0x171: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x171, 0x1cc, x86_l_1cc);
x86_l_173:
	/* 0x173: mov    ebx,0xda */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 218ULL);
x86_l_178:
	/* 0x178: mov    r11d,0x6d5a5600 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1834636800ULL);
x86_l_17e:
	/* 0x17e: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x17e, 0x1cc, x86_l_1cc);
x86_l_180:
	/* 0x180: mov    ebx,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 14ULL);
x86_l_185:
	/* 0x185: mov    r11d,0xda255b00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 3659881216ULL);
x86_l_18b:
	/* 0x18b: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x18b, 0x1cc, x86_l_1cc);
x86_l_18d:
	/* 0x18d: mov    ebx,0x3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 61ULL);
x86_l_192:
	/* 0x192: mov    r11d,0x41672500 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1097278720ULL);
x86_l_198:
	/* 0x198: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x198, 0x1cc, x86_l_1cc);
x86_l_19a:
	/* 0x19a: mov    ebx,0xa3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 163ULL);
x86_l_19f:
	/* 0x19f: mov    r11d,0x253d4300 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 624771840ULL);
x86_l_1a5:
	/* 0x1a5: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x1a5, 0x1cc, x86_l_1cc);
x86_l_1a7:
	/* 0x1a7: mov    ebx,0xb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 176ULL);
x86_l_1ac:
	/* 0x1ac: mov    r11d,0x43a38f00 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1134792448ULL);
x86_l_1b2:
	/* 0x1b2: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x1b2, 0x1cc, x86_l_1cc);
x86_l_1b4:
	/* 0x1b4: mov    ebx,0x5b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 91ULL);
x86_l_1b9:
	/* 0x1b9: mov    r11d,0x56da2500 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1457136896ULL);
x86_l_1bf:
	/* 0x1bf: jmp    1cc <packet_toeplitz_rss_hash_xdp+0x1cc> */
	X86_SIM_X86_JMP(0x1bf, 0x1cc, x86_l_1cc);
x86_l_1c1:
	/* 0x1c1: mov    ebx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 65ULL);
x86_l_1c6:
	/* 0x1c6: mov    r11d,0x5b0ec200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 1527693824ULL);
x86_l_1cc:
	/* 0x1cc: or     r11d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_32, X86_ALU_OR);
x86_l_1cf:
	/* 0x1cf: test   r9d,r9d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R9, X86_R9, X86_WIDTH_32);
x86_l_1d2:
	/* 0x1d2: je     80 <packet_toeplitz_rss_hash_xdp+0x80> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d2, 0x80, x86_l_80);
x86_l_1d8:
	/* 0x1d8: mov    ebx,0x25 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 37ULL);
x86_l_1dd:
	/* 0x1dd: cmp    r10d,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 5ULL);
x86_l_1e1:
	/* 0x1e1: jle    1ff <packet_toeplitz_rss_hash_xdp+0x1ff> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1e1, 0x1ff, x86_l_1ff);
x86_l_1e3:
	/* 0x1e3: cmp    r10d,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 8ULL);
x86_l_1e7:
	/* 0x1e7: jle    21e <packet_toeplitz_rss_hash_xdp+0x21e> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1e7, 0x21e, x86_l_21e);
x86_l_1e9:
	/* 0x1e9: cmp    r10d,0xa */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 10ULL);
x86_l_1ed:
	/* 0x1ed: jg     252 <packet_toeplitz_rss_hash_xdp+0x252> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1ed, 0x252, x86_l_252);
x86_l_1ef:
	/* 0x1ef: cmp    r10d,0x9 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 9ULL);
x86_l_1f3:
	/* 0x1f3: jne    26c <packet_toeplitz_rss_hash_xdp+0x26c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f3, 0x26c, x86_l_26c);
x86_l_1f5:
	/* 0x1f5: mov    ebx,0xa3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 163ULL);
x86_l_1fa:
	/* 0x1fa: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x1fa, 0x6a, x86_l_6a);
x86_l_1ff:
	/* 0x1ff: cmp    r10d,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 2ULL);
x86_l_203:
	/* 0x203: jg     238 <packet_toeplitz_rss_hash_xdp+0x238> */
	X86_SIM_X86_JCC(X86_CC_G, 0x203, 0x238, x86_l_238);
x86_l_205:
	/* 0x205: test   r10d,r10d */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R10, X86_R10, X86_WIDTH_32);
x86_l_208:
	/* 0x208: je     6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x208, 0x6a, x86_l_6a);
x86_l_20e:
	/* 0x20e: cmp    r10d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 1ULL);
x86_l_212:
	/* 0x212: jne    280 <packet_toeplitz_rss_hash_xdp+0x280> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x212, 0x280, x86_l_280);
x86_l_214:
	/* 0x214: mov    ebx,0x5b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 91ULL);
x86_l_219:
	/* 0x219: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x219, 0x6a, x86_l_6a);
x86_l_21e:
	/* 0x21e: cmp    r10d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 6ULL);
x86_l_222:
	/* 0x222: je     6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x222, 0x6a, x86_l_6a);
x86_l_228:
	/* 0x228: cmp    r10d,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 7ULL);
x86_l_22c:
	/* 0x22c: jne    262 <packet_toeplitz_rss_hash_xdp+0x262> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x22c, 0x262, x86_l_262);
x86_l_22e:
	/* 0x22e: mov    ebx,0x3d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 61ULL);
x86_l_233:
	/* 0x233: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x233, 0x6a, x86_l_6a);
x86_l_238:
	/* 0x238: cmp    r10d,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 3ULL);
x86_l_23c:
	/* 0x23c: je     65 <packet_toeplitz_rss_hash_xdp+0x65> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23c, 0x65, x86_l_65);
x86_l_242:
	/* 0x242: cmp    r10d,0x4 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 4ULL);
x86_l_246:
	/* 0x246: jne    28a <packet_toeplitz_rss_hash_xdp+0x28a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x246, 0x28a, x86_l_28a);
x86_l_248:
	/* 0x248: mov    ebx,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 65ULL);
x86_l_24d:
	/* 0x24d: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x24d, 0x6a, x86_l_6a);
x86_l_252:
	/* 0x252: cmp    r10d,0xb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_32, 11ULL);
x86_l_256:
	/* 0x256: jne    276 <packet_toeplitz_rss_hash_xdp+0x276> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x256, 0x276, x86_l_276);
x86_l_258:
	/* 0x258: mov    ebx,0xb0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 176ULL);
x86_l_25d:
	/* 0x25d: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x25d, 0x6a, x86_l_6a);
x86_l_262:
	/* 0x262: mov    ebx,0x43 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 67ULL);
x86_l_267:
	/* 0x267: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x267, 0x6a, x86_l_6a);
x86_l_26c:
	/* 0x26c: mov    ebx,0x8f */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 143ULL);
x86_l_271:
	/* 0x271: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x271, 0x6a, x86_l_6a);
x86_l_276:
	/* 0x276: mov    ebx,0xd0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 208ULL);
x86_l_27b:
	/* 0x27b: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x27b, 0x6a, x86_l_6a);
x86_l_280:
	/* 0x280: mov    ebx,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 14ULL);
x86_l_285:
	/* 0x285: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x285, 0x6a, x86_l_6a);
x86_l_28a:
	/* 0x28a: mov    ebx,0x67 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 103ULL);
x86_l_28f:
	/* 0x28f: jmp    6a <packet_toeplitz_rss_hash_xdp+0x6a> */
	X86_SIM_X86_JMP(0x28f, 0x6a, x86_l_6a);
x86_l_294:
	/* 0x294: mov    esi,DWORD PTR [rdx+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_297:
	/* 0x297: movzx  edi,BYTE PTR [rdx+0x2a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 42ULL);
x86_l_29b:
	/* 0x29b: movzx  r8d,BYTE PTR [rdx+0x2b] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 43ULL);
x86_l_2a0:
	/* 0x2a0: movzx  r9d,BYTE PTR [rdx+0x2c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 44ULL);
x86_l_2a5:
	/* 0x2a5: movzx  r10d,BYTE PTR [rdx+0x2d] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 45ULL);
x86_l_2aa:
	/* 0x2aa: mov    r11,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RAX, X86_WIDTH_64);
x86_l_2ad:
	/* 0x2ad: shl    r11,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_2b1:
	/* 0x2b1: xor    esi,DWORD PTR [rdx+0x22] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RSI, X86_RDX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 34ULL);
x86_l_2b4:
	/* 0x2b4: bswap  esi */
	X86_SIM_RUN_OP(X86_OP_BSWAP, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 0);
x86_l_2b6:
	/* 0x2b6: mov    edx,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSI, X86_WIDTH_32);
x86_l_2b8:
	/* 0x2b8: xor    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2ba:
	/* 0x2ba: or     rdx,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R11, X86_WIDTH_64, X86_ALU_OR);
x86_l_2bd:
	/* 0x2bd: shl    rdi,0x38 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 56ULL);
x86_l_2c1:
	/* 0x2c1: shl    r8,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_SHL, 48ULL);
x86_l_2c5:
	/* 0x2c5: or     r8,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_2c8:
	/* 0x2c8: shl    r9,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_SHL, 40ULL);
x86_l_2cc:
	/* 0x2cc: or     r9,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_64, X86_ALU_OR);
x86_l_2cf:
	/* 0x2cf: shl    r10,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_2d3:
	/* 0x2d3: or     rsi,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R9, X86_WIDTH_64, X86_ALU_OR);
x86_l_2d6:
	/* 0x2d6: or     rsi,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R10, X86_WIDTH_64, X86_ALU_OR);
x86_l_2d9:
	/* 0x2d9: and    eax,0x7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 7ULL);
x86_l_2dc:
	/* 0x2dc: lea    edi,[rax+0x1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2df:
	/* 0x2df: shlx   rdi,rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RDI, X86_RSI, X86_WIDTH_64, X86_RDI, X86_ALU_SHL);
x86_l_2e4:
	/* 0x2e4: not    al */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_8, X86_ALU_NOT, 0);
x86_l_2e6:
	/* 0x2e6: shrx   rax,rsi,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_RSI, X86_WIDTH_64, X86_RAX, X86_ALU_SHR);
x86_l_2eb:
	/* 0x2eb: or     rax,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDI, X86_WIDTH_64, X86_ALU_OR);
x86_l_2ee:
	/* 0x2ee: xor    rax,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RDX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_2f1:
	/* 0x2f1: mov    QWORD PTR [rcx],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f4:
	/* 0x2f4: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2f9:
	/* 0x2f9: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2fa:
	/* 0x2fa: jmp    2ff <packet_toeplitz_rss_hash_xdp+0x2ff> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2ff:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
