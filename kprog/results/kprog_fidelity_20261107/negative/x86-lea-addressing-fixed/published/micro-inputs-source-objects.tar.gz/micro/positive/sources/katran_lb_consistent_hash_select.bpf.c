#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 24U
#include "/workspaces/repository/kprog/fidelity/build-lea-published-validation/micro/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int katran_lb_consistent_hash_select_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: mov    rcx,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_7:
	/* 0x7: mov    rbx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b:
	/* 0xb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_d:
	/* 0xd: cmp    rcx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RCX, X86_RBX, X86_WIDTH_64);
x86_l_10:
	/* 0x10: ja     511 <katran_lb_consistent_hash_select_xdp+0x511> */
	X86_SIM_X86_JCC(X86_CC_A, 0x10, 0x511, x86_l_511);
x86_l_16:
	/* 0x16: lea    rsi,[rcx+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a:
	/* 0x1a: cmp    rsi,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_1d:
	/* 0x1d: ja     511 <katran_lb_consistent_hash_select_xdp+0x511> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1d, 0x511, x86_l_511);
x86_l_23:
	/* 0x23: lea    rdx,[rcx+0x16] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 22ULL);
x86_l_27:
	/* 0x27: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2a:
	/* 0x2a: ja     511 <katran_lb_consistent_hash_select_xdp+0x511> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2a, 0x511, x86_l_511);
x86_l_30:
	/* 0x30: movabs rax,0x9e3779b97f4a7c15 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 11400714819323198485ULL);
x86_l_3a:
	/* 0x3a: mov    r10,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RBX, X86_WIDTH_64);
x86_l_3d:
	/* 0x3d: sub    r10,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RSI, X86_WIDTH_64, X86_ALU_SUB);
x86_l_40:
	/* 0x40: movzx  esi,WORD PTR [rcx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_44:
	/* 0x44: cmp    esi,0xdd86 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 56710ULL);
x86_l_4a:
	/* 0x4a: je     e6 <katran_lb_consistent_hash_select_xdp+0xe6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a, 0xe6, x86_l_e6);
x86_l_50:
	/* 0x50: cmp    esi,0x8 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_53:
	/* 0x53: jne    115 <katran_lb_consistent_hash_select_xdp+0x115> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x53, 0x115, x86_l_115);
x86_l_59:
	/* 0x59: lea    rsi,[rcx+0x2a] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 42ULL);
x86_l_5d:
	/* 0x5d: mov    r9d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 1ULL);
x86_l_63:
	/* 0x63: cmp    rsi,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RBX, X86_WIDTH_64);
x86_l_66:
	/* 0x66: ja     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0x66, 0x4ea, x86_l_4ea);
x86_l_6c:
	/* 0x6c: movzx  edx,BYTE PTR [rdx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_6f:
	/* 0x6f: and    dl,0xf */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_AND, 15ULL);
x86_l_72:
	/* 0x72: cmp    dl,0x5 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_8, 5ULL);
x86_l_75:
	/* 0x75: jne    4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x75, 0x4ea, x86_l_4ea);
x86_l_7b:
	/* 0x7b: movzx  edx,BYTE PTR [rcx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_7f:
	/* 0x7f: movzx  esi,BYTE PTR [rcx+0x1d] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 29ULL);
x86_l_83:
	/* 0x83: and    edx,0x3f */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 63ULL);
x86_l_86:
	/* 0x86: or     dx,si */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_16, X86_ALU_OR);
x86_l_89:
	/* 0x89: jne    4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x89, 0x4ea, x86_l_4ea);
x86_l_8f:
	/* 0x8f: movzx  r14d,BYTE PTR [rcx+0x1f] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 31ULL);
x86_l_94:
	/* 0x94: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_99:
	/* 0x99: cmp    r14d,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 1ULL);
x86_l_9d:
	/* 0x9d: je     133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9d, 0x133, x86_l_133);
x86_l_a3:
	/* 0xa3: mov    ebp,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 0ULL);
x86_l_a8:
	/* 0xa8: movbe  bp,WORD PTR [rcx+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RBP, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 24ULL);
x86_l_ae:
	/* 0xae: movzx  edi,BYTE PTR [rcx+0x17] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_b2:
	/* 0xb2: movzx  r11d,WORD PTR [rcx+0x22] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R11, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 34ULL);
x86_l_b7:
	/* 0xb7: movzx  r8d,BYTE PTR [rcx+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 36ULL);
x86_l_bc:
	/* 0xbc: movzx  edx,BYTE PTR [rcx+0x25] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 37ULL);
x86_l_c0:
	/* 0xc0: mov    r15d,DWORD PTR [rcx+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_c4:
	/* 0xc4: cmp    r14d,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 17ULL);
x86_l_c8:
	/* 0xc8: je     4e1 <katran_lb_consistent_hash_select_xdp+0x4e1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc8, 0x4e1, x86_l_4e1);
x86_l_ce:
	/* 0xce: cmp    r14d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_32, 6ULL);
x86_l_d2:
	/* 0xd2: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xd2, 0x133, x86_l_133);
x86_l_d4:
	/* 0xd4: lea    r12,[rcx+0x3e] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_d8:
	/* 0xd8: cmp    r12,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBX, X86_WIDTH_64);
x86_l_db:
	/* 0xdb: ja     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdb, 0x4ea, x86_l_4ea);
x86_l_e1:
	/* 0xe1: jmp    51d <katran_lb_consistent_hash_select_xdp+0x51d> */
	X86_SIM_X86_JMP(0xe1, 0x51d, x86_l_51d);
x86_l_e6:
	/* 0xe6: lea    rdx,[rcx+0x3e] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 62ULL);
x86_l_ea:
	/* 0xea: mov    r9d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 1ULL);
x86_l_f0:
	/* 0xf0: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_f3:
	/* 0xf3: ja     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf3, 0x4ea, x86_l_4ea);
x86_l_f9:
	/* 0xf9: movzx  r12d,BYTE PTR [rcx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_fe:
	/* 0xfe: cmp    r12d,0x2c */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 44ULL);
x86_l_102:
	/* 0x102: je     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102, 0x4ea, x86_l_4ea);
x86_l_108:
	/* 0x108: cmp    r12d,0x3a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 58ULL);
x86_l_10c:
	/* 0x10c: jne    13e <katran_lb_consistent_hash_select_xdp+0x13e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10c, 0x13e, x86_l_13e);
x86_l_10e:
	/* 0x10e: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_113:
	/* 0x113: jmp    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JMP(0x113, 0x133, x86_l_133);
x86_l_115:
	/* 0x115: add    r10,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_118:
	/* 0x118: mov    rdx,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R10, X86_WIDTH_64);
x86_l_11b:
	/* 0x11b: shl    rdx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_11f:
	/* 0x11f: add    rdx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_122:
	/* 0x122: mov    rsi,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R10, X86_WIDTH_64);
x86_l_125:
	/* 0x125: shr    rsi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_129:
	/* 0x129: add    rsi,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_12c:
	/* 0x12c: add    rsi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_130:
	/* 0x130: xor    rsi,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_133:
	/* 0x133: mov    r9d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 2ULL);
x86_l_139:
	/* 0x139: jmp    4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JMP(0x139, 0x4ef, x86_l_4ef);
x86_l_13e:
	/* 0x13e: movzx  edx,BYTE PTR [rcx+0x16] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_142:
	/* 0x142: movzx  r15d,BYTE PTR [rcx+0x17] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_147:
	/* 0x147: mov    ebp,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 0ULL);
x86_l_14c:
	/* 0x14c: movbe  bp,WORD PTR [rcx+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOVBE_LOAD, X86_RBP, X86_RCX, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 26ULL);
x86_l_152:
	/* 0x152: mov    edi,DWORD PTR [rcx+0x1e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 30ULL);
x86_l_155:
	/* 0x155: mov    r14d,DWORD PTR [rcx+0x26] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R14, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 38ULL);
x86_l_159:
	/* 0x159: mov    r8d,DWORD PTR [rcx+0x2a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 42ULL);
x86_l_15d:
	/* 0x15d: mov    r13d,DWORD PTR [rcx+0x2e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 46ULL);
x86_l_161:
	/* 0x161: mov    r11d,0xdeadc0ff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 3735929087ULL);
x86_l_167:
	/* 0x167: add    r11d,DWORD PTR [rcx+0x22] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R11, X86_RCX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 34ULL);
x86_l_16b:
	/* 0x16b: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_170:
	/* 0x170: cmp    r12d,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 17ULL);
x86_l_174:
	/* 0x174: je     18f <katran_lb_consistent_hash_select_xdp+0x18f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x174, 0x18f, x86_l_18f);
x86_l_176:
	/* 0x176: cmp    r12d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 6ULL);
x86_l_17a:
	/* 0x17a: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17a, 0x133, x86_l_133);
x86_l_17c:
	/* 0x17c: mov    QWORD PTR [rsp],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_180:
	/* 0x180: lea    rdi,[rcx+0x52] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 82ULL);
x86_l_184:
	/* 0x184: cmp    rdi,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_187:
	/* 0x187: ja     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0x187, 0x4ea, x86_l_4ea);
x86_l_18d:
	/* 0x18d: jmp    1a0 <katran_lb_consistent_hash_select_xdp+0x1a0> */
	X86_SIM_X86_JMP(0x18d, 0x1a0, x86_l_1a0);
x86_l_18f:
	/* 0x18f: mov    QWORD PTR [rsp],rdi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_193:
	/* 0x193: lea    rdi,[rcx+0x46] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 70ULL);
x86_l_197:
	/* 0x197: cmp    rdi,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_19a:
	/* 0x19a: ja     4ea <katran_lb_consistent_hash_select_xdp+0x4ea> */
	X86_SIM_X86_JCC(X86_CC_A, 0x19a, 0x4ea, x86_l_4ea);
x86_l_1a0:
	/* 0x1a0: cmp    r12d,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R12, X86_WIDTH_32, 6ULL);
x86_l_1a4:
	/* 0x1a4: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a4, 0x133, x86_l_133);
x86_l_1a6:
	/* 0x1a6: cmp    r13d,0x101640a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_32, 16868362ULL);
x86_l_1ad:
	/* 0x1ad: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ad, 0x133, x86_l_133);
x86_l_1af:
	/* 0x1af: movzx  edi,WORD PTR [rcx+0x40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 64ULL);
x86_l_1b3:
	/* 0x1b3: mov    r9d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 2ULL);
x86_l_1b9:
	/* 0x1b9: cmp    edi,0x901f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_32, 36895ULL);
x86_l_1bf:
	/* 0x1bf: jne    4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bf, 0x4ef, x86_l_4ef);
x86_l_1c5:
	/* 0x1c5: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_1ca:
	/* 0x1ca: mov    r9d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 1ULL);
x86_l_1d0:
	/* 0x1d0: cmp    r10,0x5ea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 1514ULL);
x86_l_1d7:
	/* 0x1d7: jg     4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1d7, 0x4ef, x86_l_4ef);
x86_l_1dd:
	/* 0x1dd: shr    r15b,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_8, X86_ALU_SHR, 4ULL);
x86_l_1e1:
	/* 0x1e1: mov    r12d,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RDX, X86_WIDTH_32);
x86_l_1e4:
	/* 0x1e4: shl    r12b,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_8, X86_ALU_SHL, 4ULL);
x86_l_1e8:
	/* 0x1e8: or     r12b,r15b */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_8, X86_ALU_OR);
x86_l_1eb:
	/* 0x1eb: movzx  esi,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_1ee:
	/* 0x1ee: mov    edi,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R8, X86_WIDTH_32);
x86_l_1f1:
	/* 0x1f1: and    edi,0xff000000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 4278190080ULL);
x86_l_1f7:
	/* 0x1f7: lea    r10d,[r14-0x21523f01] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073150513407ULL);
x86_l_1fe:
	/* 0x1fe: mov    r9d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R8, X86_WIDTH_32);
x86_l_201:
	/* 0x201: and    r9d,0xff0000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_AND, 16711680ULL);
x86_l_208:
	/* 0x208: add    r9d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_20b:
	/* 0x20b: mov    edi,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R8, X86_WIDTH_32);
x86_l_20e:
	/* 0x20e: and    edi,0xff00 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 65280ULL);
x86_l_214:
	/* 0x214: add    edi,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_ADD);
x86_l_217:
	/* 0x217: movzx  r9d,r8b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_WIDTH_8);
x86_l_21b:
	/* 0x21b: add    r9d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_21e:
	/* 0x21e: movzx  r8d,WORD PTR [rcx+0x3e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R8, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 62ULL);
x86_l_223:
	/* 0x223: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_227:
	/* 0x227: mov    edi,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RDX, X86_WIDTH_32);
x86_l_229:
	/* 0x229: sub    edi,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R14, X86_WIDTH_32, X86_ALU_SUB);
x86_l_22c:
	/* 0x22c: rorx   ebx,r10d,0x1c */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RBX, X86_R10, X86_WIDTH_32, 0, 28ULL);
x86_l_232:
	/* 0x232: xor    ebx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_234:
	/* 0x234: add    r10d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_32, X86_ALU_ADD);
x86_l_237:
	/* 0x237: sub    r11d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_23a:
	/* 0x23a: rorx   edi,ebx,0x1a */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 26ULL);
x86_l_240:
	/* 0x240: xor    edi,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_243:
	/* 0x243: add    ebx,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_32, X86_ALU_ADD);
x86_l_246:
	/* 0x246: lea    ebp,[rdi+rbx*1] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_249:
	/* 0x249: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_24c:
	/* 0x24c: rorx   edi,edi,0x18 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_RDI, X86_WIDTH_32, 0, 24ULL);
x86_l_252:
	/* 0x252: xor    edi,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_255:
	/* 0x255: sub    ebx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_257:
	/* 0x257: rorx   r11d,edi,0x10 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_R11, X86_RDI, X86_WIDTH_32, 0, 16ULL);
x86_l_25d:
	/* 0x25d: xor    r11d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_260:
	/* 0x260: add    edi,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_32, X86_ALU_ADD);
x86_l_262:
	/* 0x262: sub    ebp,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R11, X86_WIDTH_32, X86_ALU_SUB);
x86_l_265:
	/* 0x265: rorx   ebx,r11d,0xd */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RBX, X86_R11, X86_WIDTH_32, 0, 13ULL);
x86_l_26b:
	/* 0x26b: xor    ebx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_26d:
	/* 0x26d: add    r11d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_32, X86_ALU_ADD);
x86_l_270:
	/* 0x270: lea    r10d,[rbx+r11*1] */
	X86_SIM_L_EXEC_LEA(X86_R10, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R11, 0), 0ULL);
x86_l_274:
	/* 0x274: sub    edi,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_276:
	/* 0x276: rorx   ebx,ebx,0x1c */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 28ULL);
x86_l_27c:
	/* 0x27c: xor    ebx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_27e:
	/* 0x27e: add    r11d,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R9, X86_WIDTH_32, X86_ALU_ADD);
x86_l_281:
	/* 0x281: xor    ebx,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_284:
	/* 0x284: rorx   edi,r10d,0x12 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R10, X86_WIDTH_32, 0, 18ULL);
x86_l_28a:
	/* 0x28a: sub    ebx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_28c:
	/* 0x28c: xor    r11d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_28f:
	/* 0x28f: rorx   edi,ebx,0x15 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 21ULL);
x86_l_295:
	/* 0x295: sub    r11d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_298:
	/* 0x298: xor    r10d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29b:
	/* 0x29b: rorx   edi,r11d,0x7 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R11, X86_WIDTH_32, 0, 7ULL);
x86_l_2a1:
	/* 0x2a1: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2a4:
	/* 0x2a4: xor    ebx,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2a7:
	/* 0x2a7: rorx   edi,r10d,0x10 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R10, X86_WIDTH_32, 0, 16ULL);
x86_l_2ad:
	/* 0x2ad: sub    ebx,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2af:
	/* 0x2af: xor    r11d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2b2:
	/* 0x2b2: rorx   edi,ebx,0x1c */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_RBX, X86_WIDTH_32, 0, 28ULL);
x86_l_2b8:
	/* 0x2b8: sub    r11d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2bb:
	/* 0x2bb: xor    r10d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2be:
	/* 0x2be: rorx   edi,r11d,0x12 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R11, X86_WIDTH_32, 0, 18ULL);
x86_l_2c4:
	/* 0x2c4: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2c7:
	/* 0x2c7: rorx   edi,r10d,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R10, X86_WIDTH_32, 0, 8ULL);
x86_l_2cd:
	/* 0x2cd: xor    r10d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d0:
	/* 0x2d0: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2d3:
	/* 0x2d3: add    r10d,0xe0adc0f7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_ADD, 3769483511ULL);
x86_l_2da:
	/* 0x2da: mov    r11d,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R8, X86_WIDTH_32);
x86_l_2dd:
	/* 0x2dd: add    r11d,0x70ccc0f7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_ADD, 1892466935ULL);
x86_l_2e4:
	/* 0x2e4: mov    r9d,r11d */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R11, X86_WIDTH_32);
x86_l_2e7:
	/* 0x2e7: xor    r9d,0xe0adc0f7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_XOR, 3769483511ULL);
x86_l_2ee:
	/* 0x2ee: mov    edi,0x70cc0000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 1892417536ULL);
x86_l_2f3:
	/* 0x2f3: shrd   edi,r11d,0x12 */
	X86_SIM_RUN_OP(X86_OP_SHRD_IMM, X86_RDI, X86_R11, X86_WIDTH_32, 0, 18ULL);
x86_l_2f8:
	/* 0x2f8: sub    r9d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2fb:
	/* 0x2fb: xor    r10d,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2fe:
	/* 0x2fe: rorx   edi,r9d,0x15 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R9, X86_WIDTH_32, 0, 21ULL);
x86_l_304:
	/* 0x304: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_307:
	/* 0x307: xor    r11d,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_30a:
	/* 0x30a: rorx   edi,r10d,0x7 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R10, X86_WIDTH_32, 0, 7ULL);
x86_l_310:
	/* 0x310: sub    r11d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_313:
	/* 0x313: xor    r9d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_316:
	/* 0x316: rorx   edi,r11d,0x10 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R11, X86_WIDTH_32, 0, 16ULL);
x86_l_31c:
	/* 0x31c: sub    r9d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_31f:
	/* 0x31f: xor    r10d,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_32, X86_ALU_XOR);
x86_l_322:
	/* 0x322: rorx   edi,r9d,0x1c */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R9, X86_WIDTH_32, 0, 28ULL);
x86_l_328:
	/* 0x328: sub    r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_32b:
	/* 0x32b: xor    r11d,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_32e:
	/* 0x32e: rorx   edi,r10d,0x12 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R10, X86_WIDTH_32, 0, 18ULL);
x86_l_334:
	/* 0x334: sub    r11d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_337:
	/* 0x337: xor    r9d,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R11, X86_WIDTH_32, X86_ALU_XOR);
x86_l_33a:
	/* 0x33a: rorx   edi,r11d,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RDI, X86_R11, X86_WIDTH_32, 0, 8ULL);
x86_l_340:
	/* 0x340: sub    r9d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_343:
	/* 0x343: mov    edi,0xffff0001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDI, X86_WIDTH_32, 4294901761ULL);
x86_l_348:
	/* 0x348: imul   rdi,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R9, X86_WIDTH_64, X86_ALU_IMUL);
x86_l_34c:
	/* 0x34c: shr    rdi,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 48ULL);
x86_l_350:
	/* 0x350: mov    r10d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RDI, X86_WIDTH_32);
x86_l_353:
	/* 0x353: shl    r10d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_357:
	/* 0x357: or     r10d,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_32, X86_ALU_OR);
x86_l_35a:
	/* 0x35a: sub    r9d,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R10, X86_WIDTH_32, X86_ALU_SUB);
x86_l_35d:
	/* 0x35d: mov    rdi,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RDX, X86_WIDTH_64);
x86_l_360:
	/* 0x360: add    rdi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_363:
	/* 0x363: mov    r10,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RDI, X86_WIDTH_64);
x86_l_366:
	/* 0x366: shl    r10,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_36a:
	/* 0x36a: add    r10,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_36d:
	/* 0x36d: mov    r11,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RDI, X86_WIDTH_64);
x86_l_370:
	/* 0x370: shr    r11,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_374:
	/* 0x374: add    r10,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_64, X86_ALU_ADD);
x86_l_377:
	/* 0x377: add    r10,0x101640a */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_ADD, 16868362ULL);
x86_l_37e:
	/* 0x37e: xor    r10,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_381:
	/* 0x381: mov    r11,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R10, X86_WIDTH_64);
x86_l_384:
	/* 0x384: shl    r11,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_388:
	/* 0x388: add    r11,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R8, X86_WIDTH_64, X86_ALU_ADD);
x86_l_38b:
	/* 0x38b: add    r11,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_38e:
	/* 0x38e: mov    rdi,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R10, X86_WIDTH_64);
x86_l_391:
	/* 0x391: shr    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_395:
	/* 0x395: mov    ebx,0x901f0000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 2417950720ULL);
x86_l_39a:
	/* 0x39a: add    rbx,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_39d:
	/* 0x39d: add    rbx,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R11, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3a0:
	/* 0x3a0: xor    rbx,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_3a3:
	/* 0x3a3: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_3a6:
	/* 0x3a6: shl    rdi,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_3aa:
	/* 0x3aa: mov    r10,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RBX, X86_WIDTH_64);
x86_l_3ad:
	/* 0x3ad: shr    r10,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_3b1:
	/* 0x3b1: add    rdi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3b4:
	/* 0x3b4: add    rdi,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R10, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3b7:
	/* 0x3b7: add    rdi,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3ba:
	/* 0x3ba: xor    rdi,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_3bd:
	/* 0x3bd: mov    r9,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDI, X86_WIDTH_64);
x86_l_3c0:
	/* 0x3c0: shl    r9,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_3c4:
	/* 0x3c4: add    r9,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3c7:
	/* 0x3c7: mov    r10,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RDI, X86_WIDTH_64);
x86_l_3ca:
	/* 0x3ca: shr    r10,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_3ce:
	/* 0x3ce: add    r9,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R10, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3d1:
	/* 0x3d1: inc    r9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_3d4:
	/* 0x3d4: xor    r9,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_3d7:
	/* 0x3d7: mov    rdi,r9 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R9, X86_WIDTH_64);
x86_l_3da:
	/* 0x3da: shl    rdi,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_3de:
	/* 0x3de: add    rdi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3e1:
	/* 0x3e1: mov    r10,r9 */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R9, X86_WIDTH_64);
x86_l_3e4:
	/* 0x3e4: shr    r10,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_3e8:
	/* 0x3e8: add    r10,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3eb:
	/* 0x3eb: xor    r10,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R9, X86_WIDTH_64, X86_ALU_XOR);
x86_l_3ee:
	/* 0x3ee: mov    r11,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R10, X86_WIDTH_64);
x86_l_3f1:
	/* 0x3f1: shl    r11,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_3f5:
	/* 0x3f5: add    r11,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3f8:
	/* 0x3f8: add    r11,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_3fb:
	/* 0x3fb: mov    r9,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_R10, X86_WIDTH_64);
x86_l_3fe:
	/* 0x3fe: shr    r9,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_402:
	/* 0x402: add    r9,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R11, X86_WIDTH_64, X86_ALU_ADD);
x86_l_405:
	/* 0x405: rol    r8w,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_16, X86_ALU_ROL, 8ULL);
x86_l_40a:
	/* 0x40a: shl    r8d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_40e:
	/* 0x40e: and    edx,0xffff0000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_AND, 4294901760ULL);
x86_l_414:
	/* 0x414: xor    edx,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_32, X86_ALU_XOR);
x86_l_417:
	/* 0x417: mov    edi,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_32);
x86_l_419:
	/* 0x419: add    edi,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_ADD, 20ULL);
x86_l_41c:
	/* 0x41c: rol    di,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_16, X86_ALU_ROL, 8ULL);
x86_l_420:
	/* 0x420: movzx  r8d,r12b */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_R12, X86_WIDTH_32, X86_WIDTH_8);
x86_l_424:
	/* 0x424: movzx  edi,di */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RDI, X86_RDI, X86_WIDTH_32, X86_WIDTH_16);
x86_l_427:
	/* 0x427: mov    r11d,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RDX, X86_WIDTH_32);
x86_l_42a:
	/* 0x42a: shr    r11d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_42e:
	/* 0x42e: add    rdi,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R8, X86_WIDTH_64, X86_ALU_ADD);
x86_l_431:
	/* 0x431: add    rdi,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R11, X86_WIDTH_64, X86_ALU_ADD);
x86_l_434:
	/* 0x434: add    rdi,0xdf3b */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 57147ULL);
x86_l_43b:
	/* 0x43b: mov    r8d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RDI, X86_WIDTH_32);
x86_l_43e:
	/* 0x43e: shr    r8d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_442:
	/* 0x442: movzx  r11d,di */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R11, X86_RDI, X86_WIDTH_32, X86_WIDTH_16);
x86_l_446:
	/* 0x446: add    r11,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R8, X86_WIDTH_64, X86_ALU_ADD);
x86_l_449:
	/* 0x449: cmp    rdi,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_64, 65536ULL);
x86_l_450:
	/* 0x450: cmovb  r11,rdi */
	X86_SIM_L_EXEC_CMOV(X86_R11, X86_RDI, X86_WIDTH_64, X86_CC_B);
x86_l_454:
	/* 0x454: mov    edi,r11d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R11, X86_WIDTH_32);
x86_l_457:
	/* 0x457: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_45a:
	/* 0x45a: movzx  r8d,r11w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_R11, X86_WIDTH_32, X86_WIDTH_16);
x86_l_45e:
	/* 0x45e: add    r8,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_461:
	/* 0x461: cmp    r11,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_64, 65536ULL);
x86_l_468:
	/* 0x468: cmovb  r8,r11 */
	X86_SIM_L_EXEC_CMOV(X86_R8, X86_R11, X86_WIDTH_64, X86_CC_B);
x86_l_46c:
	/* 0x46c: mov    edi,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R8, X86_WIDTH_32);
x86_l_46f:
	/* 0x46f: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_472:
	/* 0x472: movzx  r11d,r8w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R11, X86_R8, X86_WIDTH_32, X86_WIDTH_16);
x86_l_476:
	/* 0x476: add    r11,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_479:
	/* 0x479: cmp    r8,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_64, 65536ULL);
x86_l_480:
	/* 0x480: cmovb  r11,r8 */
	X86_SIM_L_EXEC_CMOV(X86_R11, X86_R8, X86_WIDTH_64, X86_CC_B);
x86_l_484:
	/* 0x484: mov    edi,r11d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R11, X86_WIDTH_32);
x86_l_487:
	/* 0x487: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_48a:
	/* 0x48a: add    edi,r11d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R11, X86_WIDTH_32, X86_ALU_ADD);
x86_l_48d:
	/* 0x48d: xor    r9,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_490:
	/* 0x490: or     edx,0x10ac */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_OR, 4268ULL);
x86_l_496:
	/* 0x496: shl    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_49a:
	/* 0x49a: or     rdx,0x200c80a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_OR, 33605642ULL);
x86_l_4a1:
	/* 0x4a1: cmp    r11,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R11, X86_WIDTH_64, 65536ULL);
x86_l_4a8:
	/* 0x4a8: cmovb  edi,r11d */
	X86_SIM_L_EXEC_CMOV(X86_RDI, X86_R11, X86_WIDTH_32, X86_CC_B);
x86_l_4ac:
	/* 0x4ac: shl    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_4af:
	/* 0x4af: xor    rdx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_4b2:
	/* 0x4b2: movabs rsi,0x200ffff000b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 2203318157323ULL);
x86_l_4bc:
	/* 0x4bc: xor    rsi,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_4bf:
	/* 0x4bf: xor    rsi,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_4c2:
	/* 0x4c2: mov    rdx,r9 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R9, X86_WIDTH_64);
x86_l_4c5:
	/* 0x4c5: shl    rdx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_4c9:
	/* 0x4c9: mov    rdi,r9 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R9, X86_WIDTH_64);
x86_l_4cc:
	/* 0x4cc: shr    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_4d0:
	/* 0x4d0: add    rdi,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4d3:
	/* 0x4d3: add    rdx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4d6:
	/* 0x4d6: add    rdx,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_4d9:
	/* 0x4d9: xor    rdx,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_64, X86_ALU_XOR);
x86_l_4dc:
	/* 0x4dc: jmp    771 <katran_lb_consistent_hash_select_xdp+0x771> */
	X86_SIM_X86_JMP(0x4dc, 0x771, x86_l_771);
x86_l_4e1:
	/* 0x4e1: lea    r12,[rcx+0x32] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 50ULL);
x86_l_4e5:
	/* 0x4e5: cmp    r12,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_R12, X86_RBX, X86_WIDTH_64);
x86_l_4e8:
	/* 0x4e8: jbe    51d <katran_lb_consistent_hash_select_xdp+0x51d> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x4e8, 0x51d, x86_l_51d);
x86_l_4ea:
	/* 0x4ea: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_4ef:
	/* 0x4ef: mov    rdx,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSI, X86_WIDTH_64);
x86_l_4f2:
	/* 0x4f2: shl    rdx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_4f6:
	/* 0x4f6: mov    rdi,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_64);
x86_l_4f9:
	/* 0x4f9: shr    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_4fd:
	/* 0x4fd: add    rdi,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_500:
	/* 0x500: add    rdx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_503:
	/* 0x503: add    rdx,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_506:
	/* 0x506: xor    rdx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_509:
	/* 0x509: mov    QWORD PTR [rcx],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_50c:
	/* 0x50c: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_511:
	/* 0x511: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_515:
	/* 0x515: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_517:
	/* 0x517: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_518:
	/* 0x518: jmp    797 <katran_lb_consistent_hash_select_xdp+0x797> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_51d:
	/* 0x51d: cmp    r15d,0x101640a */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 16868362ULL);
x86_l_524:
	/* 0x524: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x524, 0x133, x86_l_133);
x86_l_52a:
	/* 0x52a: movzx  r9d,WORD PTR [rcx+0x2c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 44ULL);
x86_l_52f:
	/* 0x52f: cmp    r9d,0x901f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_32, 36895ULL);
x86_l_536:
	/* 0x536: jne    133 <katran_lb_consistent_hash_select_xdp+0x133> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x536, 0x133, x86_l_133);
x86_l_53c:
	/* 0x53c: mov    r9d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 2ULL);
x86_l_542:
	/* 0x542: cmp    r14b,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R14, X86_WIDTH_8, 6ULL);
x86_l_546:
	/* 0x546: jne    4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x546, 0x4ef, x86_l_4ef);
x86_l_548:
	/* 0x548: mov    esi,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 1ULL);
x86_l_54d:
	/* 0x54d: mov    r9d,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 1ULL);
x86_l_553:
	/* 0x553: cmp    r10,0x5ea */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R10, X86_WIDTH_64, 1514ULL);
x86_l_55a:
	/* 0x55a: jg     4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JCC(X86_CC_G, 0x55a, 0x4ef, x86_l_4ef);
x86_l_55c:
	/* 0x55c: movzx  esi,bp */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RSI, X86_RBP, X86_WIDTH_32, X86_WIDTH_16);
x86_l_55f:
	/* 0x55f: shl    r8d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_563:
	/* 0x563: shl    edx,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_SHL, 24ULL);
x86_l_566:
	/* 0x566: or     r11d,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R8, X86_WIDTH_32, X86_ALU_OR);
x86_l_569:
	/* 0x569: or     r11d,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RDX, X86_WIDTH_32, X86_ALU_OR);
x86_l_56c:
	/* 0x56c: movzx  r9d,WORD PTR [rcx+0x2a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RCX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 42ULL);
x86_l_571:
	/* 0x571: mov    ebx,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R9, X86_WIDTH_32);
x86_l_574:
	/* 0x574: add    ebx,0x70ccc0f7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 1892466935ULL);
x86_l_57a:
	/* 0x57a: mov    r10d,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_RBX, X86_WIDTH_32);
x86_l_57d:
	/* 0x57d: xor    r10d,0xe0adc0f7 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_32, X86_ALU_XOR, 3769483511ULL);
x86_l_584:
	/* 0x584: mov    ebp,0x70cc0000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_32, 1892417536ULL);
x86_l_589:
	/* 0x589: shrd   ebp,ebx,0x12 */
	X86_SIM_RUN_OP(X86_OP_SHRD_IMM, X86_RBP, X86_RBX, X86_WIDTH_32, 0, 18ULL);
x86_l_58d:
	/* 0x58d: sub    r10d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_590:
	/* 0x590: lea    ebp,[r11-0x1f523f09] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_R11, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073184067831ULL);
x86_l_597:
	/* 0x597: xor    ebp,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_59a:
	/* 0x59a: rorx   r14d,r10d,0x15 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_R14, X86_R10, X86_WIDTH_32, 0, 21ULL);
x86_l_5a0:
	/* 0x5a0: sub    ebp,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R14, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5a3:
	/* 0x5a3: xor    ebx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5a5:
	/* 0x5a5: rorx   r14d,ebp,0x7 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_R14, X86_RBP, X86_WIDTH_32, 0, 7ULL);
x86_l_5ab:
	/* 0x5ab: sub    ebx,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R14, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5ae:
	/* 0x5ae: xor    r10d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5b1:
	/* 0x5b1: rorx   r14d,ebx,0x10 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_R14, X86_RBX, X86_WIDTH_32, 0, 16ULL);
x86_l_5b7:
	/* 0x5b7: sub    r10d,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R14, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5ba:
	/* 0x5ba: xor    ebp,r10d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R10, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5bd:
	/* 0x5bd: rorx   r14d,r10d,0x1c */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_R14, X86_R10, X86_WIDTH_32, 0, 28ULL);
x86_l_5c3:
	/* 0x5c3: sub    ebp,r14d */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R14, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5c6:
	/* 0x5c6: xor    ebx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5c8:
	/* 0x5c8: rorx   ebp,ebp,0x12 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RBP, X86_RBP, X86_WIDTH_32, 0, 18ULL);
x86_l_5ce:
	/* 0x5ce: sub    ebx,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5d0:
	/* 0x5d0: xor    r10d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_5d3:
	/* 0x5d3: rorx   ebx,ebx,0x8 */
	X86_SIM_RUN_OP(X86_OP_RORX, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 8ULL);
x86_l_5d9:
	/* 0x5d9: sub    r10d,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5dc:
	/* 0x5dc: mov    ebx,0xffff0001 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 4294901761ULL);
x86_l_5e1:
	/* 0x5e1: imul   rbx,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R10, X86_WIDTH_64, X86_ALU_IMUL);
x86_l_5e5:
	/* 0x5e5: shr    rbx,0x30 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHR, 48ULL);
x86_l_5e9:
	/* 0x5e9: mov    ebp,ebx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RBX, X86_WIDTH_32);
x86_l_5eb:
	/* 0x5eb: shl    ebp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_5ee:
	/* 0x5ee: or     ebp,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RBX, X86_WIDTH_32, X86_ALU_OR);
x86_l_5f0:
	/* 0x5f0: sub    r10d,ebp */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBP, X86_WIDTH_32, X86_ALU_SUB);
x86_l_5f3:
	/* 0x5f3: mov    r11d,r11d */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R11, X86_WIDTH_32);
x86_l_5f6:
	/* 0x5f6: add    r11,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_5f9:
	/* 0x5f9: mov    rbx,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R11, X86_WIDTH_64);
x86_l_5fc:
	/* 0x5fc: shl    rbx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_600:
	/* 0x600: mov    r14,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_R11, X86_WIDTH_64);
x86_l_603:
	/* 0x603: shr    r14,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_607:
	/* 0x607: add    rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_60a:
	/* 0x60a: add    rbx,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_60d:
	/* 0x60d: add    rbx,0x101640a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 16868362ULL);
x86_l_614:
	/* 0x614: xor    rbx,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R11, X86_WIDTH_64, X86_ALU_XOR);
x86_l_617:
	/* 0x617: mov    r11,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_RBX, X86_WIDTH_64);
x86_l_61a:
	/* 0x61a: shl    r11,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_61e:
	/* 0x61e: mov    r14,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RBX, X86_WIDTH_64);
x86_l_621:
	/* 0x621: shr    r14,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R14, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_625:
	/* 0x625: add    r14,r9 */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R9, X86_WIDTH_64, X86_ALU_ADD);
x86_l_628:
	/* 0x628: add    r11,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_62b:
	/* 0x62b: add    r11,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_62e:
	/* 0x62e: mov    r14d,0x901f0000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R14, X86_WIDTH_32, 2417950720ULL);
x86_l_634:
	/* 0x634: add    r14,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_R11, X86_WIDTH_64, X86_ALU_ADD);
x86_l_637:
	/* 0x637: xor    r14,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R14, X86_RBX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_63a:
	/* 0x63a: mov    r11,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R14, X86_WIDTH_64);
x86_l_63d:
	/* 0x63d: shl    r11,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_641:
	/* 0x641: mov    rbx,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R14, X86_WIDTH_64);
x86_l_644:
	/* 0x644: shr    rbx,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_648:
	/* 0x648: add    r11,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_64b:
	/* 0x64b: add    r11,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_64e:
	/* 0x64e: add    r11,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R10, X86_WIDTH_64, X86_ALU_ADD);
x86_l_651:
	/* 0x651: xor    r11,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R14, X86_WIDTH_64, X86_ALU_XOR);
x86_l_654:
	/* 0x654: mov    r10,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R11, X86_WIDTH_64);
x86_l_657:
	/* 0x657: shl    r10,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_65b:
	/* 0x65b: add    r10,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_65e:
	/* 0x65e: mov    rbx,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R11, X86_WIDTH_64);
x86_l_661:
	/* 0x661: shr    rbx,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_665:
	/* 0x665: add    r10,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_668:
	/* 0x668: inc    r10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_INC, 1);
x86_l_66b:
	/* 0x66b: xor    r10,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_64, X86_ALU_XOR);
x86_l_66e:
	/* 0x66e: mov    rbx,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R10, X86_WIDTH_64);
x86_l_671:
	/* 0x671: shl    rbx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_675:
	/* 0x675: add    rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_678:
	/* 0x678: mov    r11,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R10, X86_WIDTH_64);
x86_l_67b:
	/* 0x67b: shr    r11,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R11, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_67f:
	/* 0x67f: add    r11,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_682:
	/* 0x682: xor    r11,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_R11, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_685:
	/* 0x685: mov    rbx,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_R11, X86_WIDTH_64);
x86_l_688:
	/* 0x688: shl    rbx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_68c:
	/* 0x68c: add    rbx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_68f:
	/* 0x68f: add    rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_692:
	/* 0x692: mov    r10,r11 */
	X86_SIM_L_EXEC_MOV_REG(X86_R10, X86_R11, X86_WIDTH_64);
x86_l_695:
	/* 0x695: shr    r10,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R10, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_699:
	/* 0x699: add    r10,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_69c:
	/* 0x69c: rol    r9w,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_16, X86_ALU_ROL, 8ULL);
x86_l_6a1:
	/* 0x6a1: shl    r9d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_6a5:
	/* 0x6a5: or     edx,r8d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_32, X86_ALU_OR);
x86_l_6a8:
	/* 0x6a8: xor    edx,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6ab:
	/* 0x6ab: mov    r8d,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RSI, X86_WIDTH_32);
x86_l_6ae:
	/* 0x6ae: add    r8d,0x14 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_ADD, 20ULL);
x86_l_6b2:
	/* 0x6b2: rol    r8w,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_16, X86_ALU_ROL, 8ULL);
x86_l_6b7:
	/* 0x6b7: movzx  r8d,r8w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_R8, X86_WIDTH_32, X86_WIDTH_16);
x86_l_6bb:
	/* 0x6bb: mov    r9d,edx */
	X86_SIM_L_EXEC_MOV_REG(X86_R9, X86_RDX, X86_WIDTH_32);
x86_l_6be:
	/* 0x6be: shr    r9d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R9, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_6c2:
	/* 0x6c2: add    r8,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_6c5:
	/* 0x6c5: lea    rdi,[r9+r8*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R9, X86_WIDTH_64, X86_MEM_AUX(X86_R8, 0), 0ULL);
x86_l_6c9:
	/* 0x6c9: add    rdi,0xdf3b */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 57147ULL);
x86_l_6d0:
	/* 0x6d0: mov    r8d,edi */
	X86_SIM_L_EXEC_MOV_REG(X86_R8, X86_RDI, X86_WIDTH_32);
x86_l_6d3:
	/* 0x6d3: shr    r8d,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_6d7:
	/* 0x6d7: movzx  r9d,di */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R9, X86_RDI, X86_WIDTH_32, X86_WIDTH_16);
x86_l_6db:
	/* 0x6db: add    r9,r8 */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_64, X86_ALU_ADD);
x86_l_6de:
	/* 0x6de: cmp    rdi,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDI, X86_WIDTH_64, 65536ULL);
x86_l_6e5:
	/* 0x6e5: cmovb  r9,rdi */
	X86_SIM_L_EXEC_CMOV(X86_R9, X86_RDI, X86_WIDTH_64, X86_CC_B);
x86_l_6e9:
	/* 0x6e9: mov    edi,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R9, X86_WIDTH_32);
x86_l_6ec:
	/* 0x6ec: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_6ef:
	/* 0x6ef: movzx  r8d,r9w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R8, X86_R9, X86_WIDTH_32, X86_WIDTH_16);
x86_l_6f3:
	/* 0x6f3: add    r8,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_6f6:
	/* 0x6f6: cmp    r9,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_64, 65536ULL);
x86_l_6fd:
	/* 0x6fd: cmovb  r8,r9 */
	X86_SIM_L_EXEC_CMOV(X86_R8, X86_R9, X86_WIDTH_64, X86_CC_B);
x86_l_701:
	/* 0x701: mov    edi,r8d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R8, X86_WIDTH_32);
x86_l_704:
	/* 0x704: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_707:
	/* 0x707: movzx  r9d,r8w */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_R9, X86_R8, X86_WIDTH_32, X86_WIDTH_16);
x86_l_70b:
	/* 0x70b: add    r9,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_70e:
	/* 0x70e: cmp    r8,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_64, 65536ULL);
x86_l_715:
	/* 0x715: cmovb  r9,r8 */
	X86_SIM_L_EXEC_CMOV(X86_R9, X86_R8, X86_WIDTH_64, X86_CC_B);
x86_l_719:
	/* 0x719: mov    edi,r9d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R9, X86_WIDTH_32);
x86_l_71c:
	/* 0x71c: shr    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHR, 16ULL);
x86_l_71f:
	/* 0x71f: add    edi,r9d */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_R9, X86_WIDTH_32, X86_ALU_ADD);
x86_l_722:
	/* 0x722: xor    r10,r11 */
	X86_SIM_L_EXEC_ALU_REG(X86_R10, X86_R11, X86_WIDTH_64, X86_ALU_XOR);
x86_l_725:
	/* 0x725: or     edx,0x10ac */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_32, X86_ALU_OR, 4268ULL);
x86_l_72b:
	/* 0x72b: shl    rdx,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_72f:
	/* 0x72f: or     rdx,0x200c80a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_OR, 33605642ULL);
x86_l_736:
	/* 0x736: cmp    r9,0x10000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R9, X86_WIDTH_64, 65536ULL);
x86_l_73d:
	/* 0x73d: cmovb  edi,r9d */
	X86_SIM_L_EXEC_CMOV(X86_RDI, X86_R9, X86_WIDTH_32, X86_CC_B);
x86_l_741:
	/* 0x741: shl    edi,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_SHL, 16ULL);
x86_l_744:
	/* 0x744: xor    rdx,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_747:
	/* 0x747: movabs rsi,0x200ffff000b */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_64, 2203318157323ULL);
x86_l_751:
	/* 0x751: xor    rsi,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_754:
	/* 0x754: xor    rsi,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_XOR);
x86_l_757:
	/* 0x757: mov    rdx,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R10, X86_WIDTH_64);
x86_l_75a:
	/* 0x75a: shl    rdx,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_75e:
	/* 0x75e: mov    rdi,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R10, X86_WIDTH_64);
x86_l_761:
	/* 0x761: shr    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_765:
	/* 0x765: add    rdi,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_768:
	/* 0x768: add    rdx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_76b:
	/* 0x76b: add    rdx,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_76e:
	/* 0x76e: xor    rdx,r10 */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R10, X86_WIDTH_64, X86_ALU_XOR);
x86_l_771:
	/* 0x771: mov    rsi,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RDX, X86_WIDTH_64);
x86_l_774:
	/* 0x774: shl    rsi,0x6 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_SHL, 6ULL);
x86_l_778:
	/* 0x778: add    rsi,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_77b:
	/* 0x77b: mov    rdi,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RDX, X86_WIDTH_64);
x86_l_77e:
	/* 0x77e: shr    rdi,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_SHR, 2ULL);
x86_l_782:
	/* 0x782: add    rsi,rdi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_785:
	/* 0x785: add    rsi,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 3ULL);
x86_l_789:
	/* 0x789: xor    rsi,rdx */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_XOR);
x86_l_78c:
	/* 0x78c: mov    r9d,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_32, 3ULL);
x86_l_792:
	/* 0x792: jmp    4ef <katran_lb_consistent_hash_select_xdp+0x4ef> */
	X86_SIM_X86_JMP(0x792, 0x4ef, x86_l_4ef);
x86_l_797:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
