#include "/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int absolute_ax_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: movabs rax,0x1122334455667788 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1234605616436508552ULL);
x86_l_a:
	/* 0xa: movabs r8,0x1122334455667788 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 1234605616436508552ULL);
x86_l_14:
	/* 0x14: lea    ax,ds:0x12345678 */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 305419896ULL);
x86_l_1c:
	/* 0x1c: movabs r10,0x1122334455665678 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R10, X86_WIDTH_64, 1234605616436500088ULL);
x86_l_26:
	/* 0x26: cmp    rax,r10 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_R10, X86_WIDTH_64);
x86_l_29:
	/* 0x29: jne    31 <entry+0x31> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29, 0x31, x86_l_31);
x86_l_2b:
	/* 0x2b: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_30:
	/* 0x30: ret */
	X86_SIM_X86_RET();
x86_l_31:
	/* 0x31: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_36:
	/* 0x36: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
