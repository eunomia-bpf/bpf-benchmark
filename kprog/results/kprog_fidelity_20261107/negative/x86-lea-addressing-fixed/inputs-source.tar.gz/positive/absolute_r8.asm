
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/absolute_r8.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 88 77 66 55 44 33 22 11                   	movabs rax,0x1122334455667788
   a:	49 b8 88 77 66 55 44 33 22 11                   	movabs r8,0x1122334455667788
  14:	4c 8d 04 25 78 56 34 12                         	lea    r8,ds:0x12345678
  1c:	49 c7 c2 78 56 34 12                            	mov    r10,0x12345678
  23:	4d 39 d0                                        	cmp    r8,r10
  26:	75 06                                           	jne    2e <entry+0x2e>
  28:	b8 02 00 00 00                                  	mov    eax,0x2
  2d:	c3                                              	ret
  2e:	b8 00 00 00 00                                  	mov    eax,0x0
  33:	c3                                              	ret
