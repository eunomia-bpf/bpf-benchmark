#include "/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int addr32_r8_extended_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: movabs rax,0x12345678fffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 1311768469162688510ULL);
x86_l_a:
	/* 0xa: mov    ecx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_f:
	/* 0xf: movabs r8,0x12345678fffffffe */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 1311768469162688510ULL);
x86_l_19:
	/* 0x19: movabs r9,0xabcdef0100000003 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R9, X86_WIDTH_64, 12379813738285367299ULL);
x86_l_23:
	/* 0x23: lea    r8,[r8d+r9d*8+0x7f] */
	X86_SIM_L_EXEC_LEA(X86_R8, X86_R8, X86_WIDTH_32, X86_MEM_AUX(X86_R9, 3), 127ULL);
x86_l_29:
	/* 0x29: cmp    r8,0x95 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R8, X86_WIDTH_64, 149ULL);
x86_l_30:
	/* 0x30: jne    38 <entry+0x38> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30, 0x38, x86_l_38);
x86_l_32:
	/* 0x32: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_37:
	/* 0x37: ret */
	X86_SIM_X86_RET();
x86_l_38:
	/* 0x38: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_3d:
	/* 0x3d: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
