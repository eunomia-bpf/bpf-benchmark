
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/addr32_r8_legacy.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 fe ff ff ff 78 56 34 12                   	movabs rax,0x12345678fffffffe
   a:	b9 03 00 00 00                                  	mov    ecx,0x3
   f:	49 b8 fe ff ff ff 78 56 34 12                   	movabs r8,0x12345678fffffffe
  19:	49 b9 03 00 00 00 01 ef cd ab                   	movabs r9,0xabcdef0100000003
  23:	67 4c 8d 44 88 f9                               	lea    r8,[eax+ecx*4-0x7]
  29:	49 83 f8 03                                     	cmp    r8,0x3
  2d:	75 06                                           	jne    35 <entry+0x35>
  2f:	b8 02 00 00 00                                  	mov    eax,0x2
  34:	c3                                              	ret
  35:	b8 00 00 00 00                                  	mov    eax,0x0
  3a:	c3                                              	ret
