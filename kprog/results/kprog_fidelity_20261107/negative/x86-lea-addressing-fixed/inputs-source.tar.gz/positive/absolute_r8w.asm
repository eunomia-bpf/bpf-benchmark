
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/absolute_r8w.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 88 77 66 55 44 33 22 11                   	movabs rax,0x1122334455667788
   a:	49 b8 88 77 66 55 44 33 22 11                   	movabs r8,0x1122334455667788
  14:	66 44 8d 04 25 78 56 34 12                      	lea    r8w,ds:0x12345678
  1d:	49 ba 78 56 66 55 44 33 22 11                   	movabs r10,0x1122334455665678
  27:	4d 39 d0                                        	cmp    r8,r10
  2a:	75 06                                           	jne    32 <entry+0x32>
  2c:	b8 02 00 00 00                                  	mov    eax,0x2
  31:	c3                                              	ret
  32:	b8 00 00 00 00                                  	mov    eax,0x0
  37:	c3                                              	ret
