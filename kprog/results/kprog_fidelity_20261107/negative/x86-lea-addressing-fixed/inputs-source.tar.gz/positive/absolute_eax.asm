
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/absolute_eax.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 88 77 66 55 44 33 22 11                   	movabs rax,0x1122334455667788
   a:	49 b8 88 77 66 55 44 33 22 11                   	movabs r8,0x1122334455667788
  14:	8d 04 25 78 56 34 12                            	lea    eax,ds:0x12345678
  1b:	49 c7 c2 78 56 34 12                            	mov    r10,0x12345678
  22:	4c 39 d0                                        	cmp    rax,r10
  25:	75 06                                           	jne    2d <entry+0x2d>
  27:	b8 02 00 00 00                                  	mov    eax,0x2
  2c:	c3                                              	ret
  2d:	b8 00 00 00 00                                  	mov    eax,0x0
  32:	c3                                              	ret
