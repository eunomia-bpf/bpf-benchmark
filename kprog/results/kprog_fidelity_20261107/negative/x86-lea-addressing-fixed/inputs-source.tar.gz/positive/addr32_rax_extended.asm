
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/addr32_rax_extended.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 fe ff ff ff 78 56 34 12                   	movabs rax,0x12345678fffffffe
   a:	b9 03 00 00 00                                  	mov    ecx,0x3
   f:	49 b8 fe ff ff ff 78 56 34 12                   	movabs r8,0x12345678fffffffe
  19:	49 b9 03 00 00 00 01 ef cd ab                   	movabs r9,0xabcdef0100000003
  23:	67 4b 8d 44 c8 7f                               	lea    rax,[r8d+r9d*8+0x7f]
  29:	48 3d 95 00 00 00                               	cmp    rax,0x95
  2f:	75 06                                           	jne    37 <entry+0x37>
  31:	b8 02 00 00 00                                  	mov    eax,0x2
  36:	c3                                              	ret
  37:	b8 00 00 00 00                                  	mov    eax,0x0
  3c:	c3                                              	ret
