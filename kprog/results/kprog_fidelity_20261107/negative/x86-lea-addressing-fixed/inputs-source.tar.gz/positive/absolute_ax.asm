
/workspaces/repository/kprog/fidelity/build-lea-published-validation/positive/absolute_ax.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 b8 88 77 66 55 44 33 22 11                   	movabs rax,0x1122334455667788
   a:	49 b8 88 77 66 55 44 33 22 11                   	movabs r8,0x1122334455667788
  14:	66 8d 04 25 78 56 34 12                         	lea    ax,ds:0x12345678
  1c:	49 ba 78 56 66 55 44 33 22 11                   	movabs r10,0x1122334455665678
  26:	4c 39 d0                                        	cmp    rax,r10
  29:	75 06                                           	jne    31 <entry+0x31>
  2b:	b8 02 00 00 00                                  	mov    eax,0x2
  30:	c3                                              	ret
  31:	b8 00 00 00 00                                  	mov    eax,0x0
  36:	c3                                              	ret
