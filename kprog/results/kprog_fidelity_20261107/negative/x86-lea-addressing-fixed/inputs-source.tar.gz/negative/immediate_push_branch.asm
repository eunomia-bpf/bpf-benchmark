
/workspaces/repository/kprog/fidelity/build-lea-published-validation/negative/immediate_push_branch.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b8 02 00 00 00                                  	mov    eax,0x2
   5:	6a 01                                           	push   0x1
   7:	59                                              	pop    rcx
   8:	48 85 c9                                        	test   rcx,rcx
   b:	74 04                                           	je     11 <entry+0x11>
   d:	31 d2                                           	xor    edx,edx
   f:	8b 02                                           	mov    eax,DWORD PTR [rdx]
  11:	c3                                              	ret
