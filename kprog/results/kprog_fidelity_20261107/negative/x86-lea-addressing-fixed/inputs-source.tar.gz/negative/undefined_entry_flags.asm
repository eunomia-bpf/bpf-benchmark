
/workspaces/repository/kprog/fidelity/build-lea-published-validation/negative/undefined_entry_flags.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	73 08                                           	jae    a <entry+0xa>
   2:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
   6:	0f b6 00                                        	movzx  eax,BYTE PTR [rax]
   9:	c3                                              	ret
   a:	b8 02 00 00 00                                  	mov    eax,0x2
   f:	c3                                              	ret
