
/workspaces/repository/kprog/fidelity/build-lea-published-validation/negative/stack_base_flags.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b8 02 00 00 00                                  	mov    eax,0x2
   5:	48 83 ec 08                                     	sub    rsp,0x8
   9:	48 83 c4 08                                     	add    rsp,0x8
   d:	74 04                                           	je     13 <entry+0x13>
   f:	31 c9                                           	xor    ecx,ecx
  11:	8b 01                                           	mov    eax,DWORD PTR [rcx]
  13:	c3                                              	ret
