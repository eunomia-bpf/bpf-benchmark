
/workspaces/repository/kprog/fidelity/build-lea-published-validation/negative/div16_overflow.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	31 c0                                           	xor    eax,eax
   2:	ba 01 00 00 00                                  	mov    edx,0x1
   7:	b9 01 00 00 00                                  	mov    ecx,0x1
   c:	66 f7 f1                                        	div    cx
   f:	b8 02 00 00 00                                  	mov    eax,0x2
  14:	c3                                              	ret
