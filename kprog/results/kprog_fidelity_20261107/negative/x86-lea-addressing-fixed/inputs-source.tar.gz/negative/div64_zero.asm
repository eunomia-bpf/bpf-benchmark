
/workspaces/repository/kprog/fidelity/build-lea-published-validation/negative/div64_zero.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b8 01 00 00 00                                  	mov    eax,0x1
   5:	31 d2                                           	xor    edx,edx
   7:	31 c9                                           	xor    ecx,ecx
   9:	48 f7 f1                                        	div    rcx
   c:	b8 02 00 00 00                                  	mov    eax,0x2
  11:	c3                                              	ret
