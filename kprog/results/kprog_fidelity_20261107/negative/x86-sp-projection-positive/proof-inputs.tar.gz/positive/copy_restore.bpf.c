#include "/workspaces/repository/kprog/fidelity/build-sp-projection-positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int copy_restore_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSP, X86_WIDTH_64);
x86_l_3:
	/* 0x3: mov    rsp,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RSP, X86_RAX, X86_WIDTH_64);
x86_l_6:
	/* 0x6: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_b:
	/* 0xb: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
