
/workspaces/repository/kprog/fidelity/build-sp-projection-positive/copy_restore.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 89 e0                                        	mov    rax,rsp
   3:	48 89 c4                                        	mov    rsp,rax
   6:	b8 02 00 00 00                                  	mov    eax,0x2
   b:	c3                                              	ret
