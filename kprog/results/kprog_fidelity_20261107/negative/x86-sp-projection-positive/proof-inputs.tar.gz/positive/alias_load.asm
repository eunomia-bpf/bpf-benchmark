
/workspaces/repository/kprog/fidelity/build-sp-projection-positive/alias_load.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 83 ec 10                                     	sub    rsp,0x10
   4:	48 c7 04 24 25 00 00 00                         	mov    QWORD PTR [rsp],0x25
   c:	48 89 e0                                        	mov    rax,rsp
   f:	8b 08                                           	mov    ecx,DWORD PTR [rax]
  11:	48 83 c4 10                                     	add    rsp,0x10
  15:	83 f9 25                                        	cmp    ecx,0x25
  18:	75 06                                           	jne    20 <entry+0x20>
  1a:	b8 02 00 00 00                                  	mov    eax,0x2
  1f:	c3                                              	ret
  20:	b8 00 00 00 00                                  	mov    eax,0x0
  25:	c3                                              	ret
