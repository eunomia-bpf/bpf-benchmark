#include "/workspaces/repository/kprog/fidelity/build-sp-projection-positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int partial_alias_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSP, X86_WIDTH_64);
x86_l_3:
	/* 0x3: mov    al,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_8, 1ULL);
x86_l_5:
	/* 0x5: cmp    al,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_8, 1ULL);
x86_l_7:
	/* 0x7: jne    f <entry+0xf> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7, 0xf, x86_l_f);
x86_l_9:
	/* 0x9: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_e:
	/* 0xe: ret */
	X86_SIM_X86_RET();
x86_l_f:
	/* 0xf: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_14:
	/* 0x14: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
