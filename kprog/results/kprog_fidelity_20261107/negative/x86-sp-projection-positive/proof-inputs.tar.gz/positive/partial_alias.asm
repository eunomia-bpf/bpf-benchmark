
/workspaces/repository/kprog/fidelity/build-sp-projection-positive/partial_alias.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 89 e0                                        	mov    rax,rsp
   3:	b0 01                                           	mov    al,0x1
   5:	3c 01                                           	cmp    al,0x1
   7:	75 06                                           	jne    f <entry+0xf>
   9:	b8 02 00 00 00                                  	mov    eax,0x2
   e:	c3                                              	ret
   f:	b8 00 00 00 00                                  	mov    eax,0x0
  14:	c3                                              	ret
