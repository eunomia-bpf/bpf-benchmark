
/workspaces/repository/kprog/fidelity/build-sp-projection-positive/spill_restore.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 83 ec 20                                     	sub    rsp,0x20
   4:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
   9:	48 89 04 24                                     	mov    QWORD PTR [rsp],rax
   d:	48 8b 04 24                                     	mov    rax,QWORD PTR [rsp]
  11:	48 89 c4                                        	mov    rsp,rax
  14:	48 83 c4 10                                     	add    rsp,0x10
  18:	b8 02 00 00 00                                  	mov    eax,0x2
  1d:	c3                                              	ret
