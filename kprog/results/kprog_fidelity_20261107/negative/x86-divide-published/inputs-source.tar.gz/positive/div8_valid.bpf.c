#include "/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int div8_valid_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,0x200 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 512ULL);
x86_l_7:
	/* 0x7: mov    edx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 0ULL);
x86_l_c:
	/* 0xc: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: div    cl */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_13:
	/* 0x13: cmp    ax,0x149 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_16, 329ULL);
x86_l_17:
	/* 0x17: jne    1f <entry+0x1f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17, 0x1f, x86_l_1f);
x86_l_19:
	/* 0x19: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1e:
	/* 0x1e: ret */
	X86_SIM_X86_RET();
x86_l_1f:
	/* 0x1f: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_24:
	/* 0x24: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
