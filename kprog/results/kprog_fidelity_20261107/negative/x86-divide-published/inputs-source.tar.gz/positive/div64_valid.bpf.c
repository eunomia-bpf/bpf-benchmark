#include "/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int div64_valid_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6ULL);
x86_l_7:
	/* 0x7: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_c:
	/* 0xc: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: div    rcx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: movabs r8,0x2492492492492493 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 2635249153387078803ULL);
x86_l_1e:
	/* 0x1e: cmp    rax,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_R8, X86_WIDTH_64);
x86_l_21:
	/* 0x21: jne    2f <entry+0x2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21, 0x2f, x86_l_2f);
x86_l_23:
	/* 0x23: cmp    rdx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 1ULL);
x86_l_27:
	/* 0x27: jne    2f <entry+0x2f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27, 0x2f, x86_l_2f);
x86_l_29:
	/* 0x29: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e:
	/* 0x2e: ret */
	X86_SIM_X86_RET();
x86_l_2f:
	/* 0x2f: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_34:
	/* 0x34: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
