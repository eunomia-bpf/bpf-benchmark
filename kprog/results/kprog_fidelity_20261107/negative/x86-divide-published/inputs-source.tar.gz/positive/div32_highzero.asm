
/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/div32_highzero.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 06 00 00 00                            	mov    rax,0x6
   7:	ba 00 00 00 00                                  	mov    edx,0x0
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	f7 f1                                           	div    ecx
  13:	83 f8 00                                        	cmp    eax,0x0
  16:	75 0b                                           	jne    23 <entry+0x23>
  18:	83 fa 06                                        	cmp    edx,0x6
  1b:	75 06                                           	jne    23 <entry+0x23>
  1d:	b8 02 00 00 00                                  	mov    eax,0x2
  22:	c3                                              	ret
  23:	b8 00 00 00 00                                  	mov    eax,0x0
  28:	c3                                              	ret
