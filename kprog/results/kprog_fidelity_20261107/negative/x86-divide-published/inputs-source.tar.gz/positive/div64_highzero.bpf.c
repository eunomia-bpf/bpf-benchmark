#include "/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int div64_highzero_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6ULL);
x86_l_7:
	/* 0x7: mov    edx,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 0ULL);
x86_l_c:
	/* 0xc: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: div    rcx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    r8,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_64, 0ULL);
x86_l_1b:
	/* 0x1b: cmp    rax,r8 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_R8, X86_WIDTH_64);
x86_l_1e:
	/* 0x1e: jne    2c <entry+0x2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e, 0x2c, x86_l_2c);
x86_l_20:
	/* 0x20: cmp    rdx,0x6 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 6ULL);
x86_l_24:
	/* 0x24: jne    2c <entry+0x2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24, 0x2c, x86_l_2c);
x86_l_26:
	/* 0x26: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2b:
	/* 0x2b: ret */
	X86_SIM_X86_RET();
x86_l_2c:
	/* 0x2c: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_31:
	/* 0x31: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
