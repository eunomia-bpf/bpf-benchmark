#include "/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int div32_valid_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6ULL);
x86_l_7:
	/* 0x7: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_c:
	/* 0xc: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: div    ecx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_13:
	/* 0x13: cmp    eax,0x24924925 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 613566757ULL);
x86_l_18:
	/* 0x18: jne    25 <entry+0x25> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18, 0x25, x86_l_25);
x86_l_1a:
	/* 0x1a: cmp    edx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_1d:
	/* 0x1d: jne    25 <entry+0x25> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d, 0x25, x86_l_25);
x86_l_1f:
	/* 0x1f: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_24:
	/* 0x24: ret */
	X86_SIM_X86_RET();
x86_l_25:
	/* 0x25: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_2a:
	/* 0x2a: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
