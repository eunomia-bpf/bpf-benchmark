
/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/div16_valid.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 06 00 00 00                            	mov    rax,0x6
   7:	ba 01 00 00 00                                  	mov    edx,0x1
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	66 f7 f1                                        	div    cx
  14:	66 3d 93 24                                     	cmp    ax,0x2493
  18:	75 0c                                           	jne    26 <entry+0x26>
  1a:	66 83 fa 01                                     	cmp    dx,0x1
  1e:	75 06                                           	jne    26 <entry+0x26>
  20:	b8 02 00 00 00                                  	mov    eax,0x2
  25:	c3                                              	ret
  26:	b8 00 00 00 00                                  	mov    eax,0x0
  2b:	c3                                              	ret
