#include "/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int div16_valid_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rax,0x6 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_64, 6ULL);
x86_l_7:
	/* 0x7: mov    edx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 1ULL);
x86_l_c:
	/* 0xc: mov    ecx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: div    cx */
	X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_RCX, X86_WIDTH_16, 0, 0);
x86_l_14:
	/* 0x14: cmp    ax,0x2493 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_16, 9363ULL);
x86_l_18:
	/* 0x18: jne    26 <entry+0x26> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18, 0x26, x86_l_26);
x86_l_1a:
	/* 0x1a: cmp    dx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_16, 1ULL);
x86_l_1e:
	/* 0x1e: jne    26 <entry+0x26> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e, 0x26, x86_l_26);
x86_l_20:
	/* 0x20: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_25:
	/* 0x25: ret */
	X86_SIM_X86_RET();
x86_l_26:
	/* 0x26: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_2b:
	/* 0x2b: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
