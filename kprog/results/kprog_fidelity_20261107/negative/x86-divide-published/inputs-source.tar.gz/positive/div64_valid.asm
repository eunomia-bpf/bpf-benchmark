
/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/div64_valid.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 06 00 00 00                            	mov    rax,0x6
   7:	ba 01 00 00 00                                  	mov    edx,0x1
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	48 f7 f1                                        	div    rcx
  14:	49 b8 93 24 49 92 24 49 92 24                   	movabs r8,0x2492492492492493
  1e:	4c 39 c0                                        	cmp    rax,r8
  21:	75 0c                                           	jne    2f <entry+0x2f>
  23:	48 83 fa 01                                     	cmp    rdx,0x1
  27:	75 06                                           	jne    2f <entry+0x2f>
  29:	b8 02 00 00 00                                  	mov    eax,0x2
  2e:	c3                                              	ret
  2f:	b8 00 00 00 00                                  	mov    eax,0x0
  34:	c3                                              	ret
