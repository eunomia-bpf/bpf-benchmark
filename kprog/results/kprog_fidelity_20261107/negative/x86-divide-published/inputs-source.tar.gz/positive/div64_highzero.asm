
/workspaces/repository/kprog/fidelity/build-div-published-negative/positive/div64_highzero.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 06 00 00 00                            	mov    rax,0x6
   7:	ba 00 00 00 00                                  	mov    edx,0x0
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	48 f7 f1                                        	div    rcx
  14:	49 c7 c0 00 00 00 00                            	mov    r8,0x0
  1b:	4c 39 c0                                        	cmp    rax,r8
  1e:	75 0c                                           	jne    2c <entry+0x2c>
  20:	48 83 fa 06                                     	cmp    rdx,0x6
  24:	75 06                                           	jne    2c <entry+0x2c>
  26:	b8 02 00 00 00                                  	mov    eax,0x2
  2b:	c3                                              	ret
  2c:	b8 00 00 00 00                                  	mov    eax,0x0
  31:	c3                                              	ret
