#include "/workspaces/repository/kprog/fidelity/build-lea-published-validation/abi-observation/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int callee_saved_clobber_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: movabs rbx,0x123456789abcdef0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 1311768467463790320ULL);
x86_l_a:
	/* 0xa: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_f:
	/* 0xf: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
