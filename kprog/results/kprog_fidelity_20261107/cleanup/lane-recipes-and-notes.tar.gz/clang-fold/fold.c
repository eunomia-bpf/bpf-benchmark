int plain(int z) { const int w=1; if(w) return z+2; return z+3; }
int statement(int z) { const int w=({const int r=1;r;});if(w) return z+2;return z+3;}
int builtin(int z) { const int w=__builtin_choose_expr(__builtin_constant_p(1),1,({const int r=1;r;}));if(w) return z+2;return z+3;}
