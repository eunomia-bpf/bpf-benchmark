.PHONY: build wire
build:
	lake build reference
wire:
	python3 tools/check_reference_arm64.py

.PHONY: model
model:
	lake build KProgFormal.Refinement.Arm64Exclusive reference
exclusive-wire:
	python3 tools/check_reference_exclusive.py

axioms:
	lake env lean PrintExclusive.lean
