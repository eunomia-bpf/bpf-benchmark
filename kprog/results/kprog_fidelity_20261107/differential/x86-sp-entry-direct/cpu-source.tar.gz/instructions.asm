
/workspaces/repository/kprog/fidelity/build-sp-entry-replay/source/kprog/fidelity/build-cpu/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	48 89 e0                                        	mov    rax,rsp
   3:	89 e0                                           	mov    eax,esp
   5:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
   a:	48 83 fc 00                                     	cmp    rsp,0x0
   e:	48 89 c4                                        	mov    rsp,rax
  11:	89 c4                                           	mov    esp,eax
  13:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
  18:	48 83 c4 10                                     	add    rsp,0x10
  1c:	54                                              	push   rsp
  1d:	5c                                              	pop    rsp
  1e:	66 54                                           	push   sp
  20:	66 5c                                           	pop    sp
