
/workspaces/repository/kprog/fidelity/build-x86-dshift-cl16/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	66 0f a5 d8                                     	shld   ax,bx,cl
   4:	66 0f a5 c0                                     	shld   ax,ax,cl
   8:	66 0f a5 c1                                     	shld   cx,ax,cl
   c:	66 0f a5 c8                                     	shld   ax,cx,cl
  10:	66 0f a5 c9                                     	shld   cx,cx,cl
  14:	66 0f a5 c4                                     	shld   sp,ax,cl
  18:	66 0f a5 e0                                     	shld   ax,sp,cl
  1c:	66 0f a5 e4                                     	shld   sp,sp,cl
  20:	66 0f ad d8                                     	shrd   ax,bx,cl
  24:	66 0f ad c0                                     	shrd   ax,ax,cl
  28:	66 0f ad c1                                     	shrd   cx,ax,cl
  2c:	66 0f ad c8                                     	shrd   ax,cx,cl
  30:	66 0f ad c9                                     	shrd   cx,cx,cl
  34:	66 0f ad c4                                     	shrd   sp,ax,cl
  38:	66 0f ad e0                                     	shrd   ax,sp,cl
  3c:	66 0f ad e4                                     	shrd   sp,sp,cl
