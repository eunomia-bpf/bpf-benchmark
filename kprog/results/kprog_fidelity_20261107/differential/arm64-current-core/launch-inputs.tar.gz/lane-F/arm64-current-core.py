from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
B=R/'kprog/fidelity/build-arm64';O=R/'kprog/results/kprog_fidelity_20261107/differential/arm64-current-core'
stem=F/'arm64-current-core'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def state(s):stem.with_suffix('.state').write_text(s+'\n')
def run(cmd,name):
 with (O/name).open('w') as f:rc=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 return dict(command=cmd,exit=rc)
try:
 O.mkdir()
 paths=[R/'kprog/fidelity'/n for n in ['generate.py','driver.c','driver.h','Makefile','reference_check.py']]
 paths += list((R/'kprog/arm64').glob('*.h'))+list((R/'kprog/arm64/micro-prog').glob('*.py'))+list((R/'kprog/formal/generated').glob('*.h'))
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 emit('launch.json',dict(started=datetime.now(timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),header_commit='b89015df9528fd5d3dcd4d2f451ba2a8e8b2dad9',pins=pins,reference_sha256=sha(F/'reference-control-frozen')))
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
  t.add(__file__,arcname='lane-F/arm64-current-core.py',recursive=False)
 (O/'README.md').write_text('# Current ARM core807 static handoff refresh\n\nThis detached run consumes the published b89015df9528fd5d3dcd4d2f451ba2a8e8b2dad9 ARM simulator snapshot. The old807 handoff captured c82c0832 at14:22 and predates the later b2b6/9004/b890 source changes. Its prior results remain historical in ../arm64-form-completion. Reuse the same incremental build-arm64 cache and unchanged807 form matrix; no production/reference source, mask, kernel/module/image or workload changes.\n\nAll executions here use QEMU user mode on the x86 host, NOT real ARM CPU evidence. The existing c110 canonical executable is frozen and reused without a root Lake build. Actual compiled inputs and the static ARM executable are captured after build; terminal results require independent review before publication.\n\n~~~sh\ntaskset -c 16-19 make -C kprog/fidelity build ARCH=arm64\ntaskset -c 16-19 make -f kprog/results/kprog_fidelity_20261107/differential/arm64-current-logical/Makefile reference OUT=/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/arm64-current-core\n~~~\n\nAfter the static artifact is reviewed and published, the coordinator can use the EXISTING hardware-only run script without changing its code:\n\n~~~sh\nARM64_HANDOFF=/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/arm64-current-core/cpu-differential-arm64.gz OUT=/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/arm64-current-hardware sh kprog/fidelity/run-arm64.sh\n~~~\n\nThe existing script refuses non-AArch64 hosts and preserves per-form case counts and every mismatch input. Hardware results remain pending. Default handoff still points to the earlier validated artifact until this refresh completes.\n')
 state('incremental_build_running')
 built=run(['taskset','-c','16-19','make','-C','kprog/fidelity','build','ARCH=arm64'],'build.log')
 emit('build-status.json',built)
 if built['exit']:raise RuntimeError('ARM cross-compiled harness build failed; evidence retained')
 files=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
 files += [B/n for n in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json']]
 files += [R/'kprog/fidelity'/n for n in ['driver.c','driver.h','Makefile']]
 actual={str(p.relative_to(R)):sha(p) for p in files}
 emit('actual-compiled-inputs.json',actual)
 with tarfile.open(O/'actual-compiled-inputs.tar.gz','w:gz') as t:
  for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 (O/'static-elf.txt').write_text(subprocess.check_output(['file',str(B/'cpu-differential')],text=True)+subprocess.check_output(['aarch64-linux-gnu-readelf','-h',str(B/'cpu-differential')],text=True))
 (O/'cpu-differential-arm64.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
 header=B/'snapshot/kprog/arm64/arm64_sim_local_bpf.h'
 published=subprocess.check_output(['git','show','b89015df9528fd5d3dcd4d2f451ba2a8e8b2dad9:kprog/arm64/arm64_sim_local_bpf.h'],cwd=R)
 assert header.read_bytes()==published,'actual header differs from intended published ARM snapshot'
 forms=json.loads((B/'coverage.json').read_text());assert len(forms)==807
 emit('executable-pins.json',dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(F/'reference-control-frozen'),compiled_header_sha256=sha(header)))
 state('qemu_user_and_frozen_canonical_replay_running')
 replay=run(['taskset','-c','16-19','make','-f','kprog/results/kprog_fidelity_20261107/differential/arm64-current-logical/Makefile','reference','OUT='+str(O)],'reference.log')
 replay['finished']=datetime.now(timezone.utc).isoformat();emit('replay-status.json',replay)
 emit('source-drift-after.json',{p:dict(before=h,after=sha(R/p)) for p,h in pins.items() if (R/p).exists() and sha(R/p)!=h})
 for n in ['build.log','reference.log','mismatches.jsonl','reference-mismatches.jsonl','reference-unavailable.jsonl']:
  p=O/n
  if p.exists():(O/(n+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 state('closed_'+str(replay['exit'])+'_needs_independent_review_and_publication')
 stem.with_suffix('.exit').write_text(str(replay['exit'])+'\n')
except BaseException:
 stem.with_suffix('.error').write_text(traceback.format_exc());state('failed_evidence_retained')
 stem.with_suffix('.exit').write_text('1\n');raise
