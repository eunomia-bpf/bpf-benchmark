
build-arm64/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	d503201f 	nop
   4:	0b020020 	add	w0, w1, w2
   8:	0b020c20 	add	w0, w1, w2, lsl #3
   c:	1101fc20 	add	w0, w1, #0x7f
  10:	4b020020 	sub	w0, w1, w2
  14:	4b020c20 	sub	w0, w1, w2, lsl #3
  18:	5101fc20 	sub	w0, w1, #0x7f
  1c:	0a020020 	and	w0, w1, w2
  20:	0a020c20 	and	w0, w1, w2, lsl #3
  24:	0a220020 	bic	w0, w1, w2
  28:	0a220c20 	bic	w0, w1, w2, lsl #3
  2c:	4a020020 	eor	w0, w1, w2
  30:	4a020c20 	eor	w0, w1, w2, lsl #3
  34:	2a020020 	orr	w0, w1, w2
  38:	2a020c20 	orr	w0, w1, w2, lsl #3
  3c:	2a220020 	orn	w0, w1, w2
  40:	2a220c20 	orn	w0, w1, w2, lsl #3
  44:	2b020020 	adds	w0, w1, w2
  48:	2b020c20 	adds	w0, w1, w2, lsl #3
  4c:	3101fc20 	adds	w0, w1, #0x7f
  50:	6b020020 	subs	w0, w1, w2
  54:	6b020c20 	subs	w0, w1, w2, lsl #3
  58:	7101fc20 	subs	w0, w1, #0x7f
  5c:	6a020020 	ands	w0, w1, w2
  60:	6a020c20 	ands	w0, w1, w2, lsl #3
  64:	6a220020 	bics	w0, w1, w2
  68:	6a220c20 	bics	w0, w1, w2, lsl #3
  6c:	6b02003f 	cmp	w1, w2
  70:	6b020c3f 	cmp	w1, w2, lsl #3
  74:	2b02003f 	cmn	w1, w2
  78:	2b020c3f 	cmn	w1, w2, lsl #3
  7c:	6a02003f 	tst	w1, w2
  80:	6a020c3f 	tst	w1, w2, lsl #3
  84:	7100003f 	cmp	w1, #0x0
  88:	7101fc3f 	cmp	w1, #0x7f
  8c:	713ffc3f 	cmp	w1, #0xfff
  90:	7140043f 	cmp	w1, #0x1, lsl #12
  94:	3100003f 	cmn	w1, #0x0
  98:	3101fc3f 	cmn	w1, #0x7f
  9c:	313ffc3f 	cmn	w1, #0xfff
  a0:	3140043f 	cmn	w1, #0x1, lsl #12
  a4:	6a22003f 	bics	wzr, w1, w2
  a8:	6a621c3f 	bics	wzr, w1, w2, lsr #7
  ac:	6aa27c3f 	bics	wzr, w1, w2, asr #31
  b0:	6ae21c3f 	bics	wzr, w1, w2, ror #7
  b4:	12000020 	and	w0, w1, #0x1
  b8:	12000000 	and	w0, w0, #0x1
  bc:	120003e0 	and	w0, wzr, #0x1
  c0:	1200003f 	and	wsp, w1, #0x1
  c4:	32000020 	orr	w0, w1, #0x1
  c8:	32000000 	orr	w0, w0, #0x1
  cc:	320003e0 	orr	w0, wzr, #0x1
  d0:	3200003f 	orr	wsp, w1, #0x1
  d4:	52000020 	eor	w0, w1, #0x1
  d8:	52000000 	eor	w0, w0, #0x1
  dc:	520003e0 	eor	w0, wzr, #0x1
  e0:	5200003f 	eor	wsp, w1, #0x1
  e4:	72000020 	ands	w0, w1, #0x1
  e8:	72000000 	ands	w0, w0, #0x1
  ec:	720003e0 	ands	w0, wzr, #0x1
  f0:	7200003f 	tst	w1, #0x1
  f4:	720003ff 	tst	wzr, #0x1
  f8:	12001c20 	and	w0, w1, #0xff
  fc:	12001c00 	and	w0, w0, #0xff
 100:	12001fe0 	and	w0, wzr, #0xff
 104:	12001c3f 	and	wsp, w1, #0xff
 108:	32001c20 	orr	w0, w1, #0xff
 10c:	32001c00 	orr	w0, w0, #0xff
 110:	32001fe0 	orr	w0, wzr, #0xff
 114:	32001c3f 	orr	wsp, w1, #0xff
 118:	52001c20 	eor	w0, w1, #0xff
 11c:	52001c00 	eor	w0, w0, #0xff
 120:	52001fe0 	eor	w0, wzr, #0xff
 124:	52001c3f 	eor	wsp, w1, #0xff
 128:	72001c20 	ands	w0, w1, #0xff
 12c:	72001c00 	ands	w0, w0, #0xff
 130:	72001fe0 	ands	w0, wzr, #0xff
 134:	72001c3f 	tst	w1, #0xff
 138:	72001fff 	tst	wzr, #0xff
 13c:	12010020 	and	w0, w1, #0x80000000
 140:	12010000 	and	w0, w0, #0x80000000
 144:	120103e0 	and	w0, wzr, #0x80000000
 148:	1201003f 	and	wsp, w1, #0x80000000
 14c:	32010020 	orr	w0, w1, #0x80000000
 150:	32010000 	orr	w0, w0, #0x80000000
 154:	320103e0 	orr	w0, wzr, #0x80000000
 158:	3201003f 	orr	wsp, w1, #0x80000000
 15c:	52010020 	eor	w0, w1, #0x80000000
 160:	52010000 	eor	w0, w0, #0x80000000
 164:	520103e0 	eor	w0, wzr, #0x80000000
 168:	5201003f 	eor	wsp, w1, #0x80000000
 16c:	72010020 	ands	w0, w1, #0x80000000
 170:	72010000 	ands	w0, w0, #0x80000000
 174:	720103e0 	ands	w0, wzr, #0x80000000
 178:	7201003f 	tst	w1, #0x80000000
 17c:	720103ff 	tst	wzr, #0x80000000
 180:	12003c20 	and	w0, w1, #0xffff
 184:	12003c00 	and	w0, w0, #0xffff
 188:	12003fe0 	and	w0, wzr, #0xffff
 18c:	12003c3f 	and	wsp, w1, #0xffff
 190:	32003c20 	orr	w0, w1, #0xffff
 194:	32003c00 	orr	w0, w0, #0xffff
 198:	32003fe0 	orr	w0, wzr, #0xffff
 19c:	32003c3f 	orr	wsp, w1, #0xffff
 1a0:	52003c20 	eor	w0, w1, #0xffff
 1a4:	52003c00 	eor	w0, w0, #0xffff
 1a8:	52003fe0 	eor	w0, wzr, #0xffff
 1ac:	52003c3f 	eor	wsp, w1, #0xffff
 1b0:	72003c20 	ands	w0, w1, #0xffff
 1b4:	72003c00 	ands	w0, w0, #0xffff
 1b8:	72003fe0 	ands	w0, wzr, #0xffff
 1bc:	72003c3f 	tst	w1, #0xffff
 1c0:	72003fff 	tst	wzr, #0xffff
 1c4:	12009c20 	and	w0, w1, #0xff00ff
 1c8:	12009c00 	and	w0, w0, #0xff00ff
 1cc:	12009fe0 	and	w0, wzr, #0xff00ff
 1d0:	12009c3f 	and	wsp, w1, #0xff00ff
 1d4:	32009c20 	orr	w0, w1, #0xff00ff
 1d8:	32009c00 	orr	w0, w0, #0xff00ff
 1dc:	32009fe0 	mov	w0, #0xff00ff              	// #16711935
 1e0:	32009c3f 	orr	wsp, w1, #0xff00ff
 1e4:	52009c20 	eor	w0, w1, #0xff00ff
 1e8:	52009c00 	eor	w0, w0, #0xff00ff
 1ec:	52009fe0 	eor	w0, wzr, #0xff00ff
 1f0:	52009c3f 	eor	wsp, w1, #0xff00ff
 1f4:	72009c20 	ands	w0, w1, #0xff00ff
 1f8:	72009c00 	ands	w0, w0, #0xff00ff
 1fc:	72009fe0 	ands	w0, wzr, #0xff00ff
 200:	72009c3f 	tst	w1, #0xff00ff
 204:	72009fff 	tst	wzr, #0xff00ff
 208:	1201f020 	and	w0, w1, #0xaaaaaaaa
 20c:	1201f000 	and	w0, w0, #0xaaaaaaaa
 210:	1201f3e0 	and	w0, wzr, #0xaaaaaaaa
 214:	1201f03f 	and	wsp, w1, #0xaaaaaaaa
 218:	3201f020 	orr	w0, w1, #0xaaaaaaaa
 21c:	3201f000 	orr	w0, w0, #0xaaaaaaaa
 220:	3201f3e0 	mov	w0, #0xaaaaaaaa            	// #-1431655766
 224:	3201f03f 	orr	wsp, w1, #0xaaaaaaaa
 228:	5201f020 	eor	w0, w1, #0xaaaaaaaa
 22c:	5201f000 	eor	w0, w0, #0xaaaaaaaa
 230:	5201f3e0 	eor	w0, wzr, #0xaaaaaaaa
 234:	5201f03f 	eor	wsp, w1, #0xaaaaaaaa
 238:	7201f020 	ands	w0, w1, #0xaaaaaaaa
 23c:	7201f000 	ands	w0, w0, #0xaaaaaaaa
 240:	7201f3e0 	ands	w0, wzr, #0xaaaaaaaa
 244:	7201f03f 	tst	w1, #0xaaaaaaaa
 248:	7201f3ff 	tst	wzr, #0xaaaaaaaa
 24c:	2a0103e0 	mov	w0, w1
 250:	52800fe0 	mov	w0, #0x7f                  	// #127
 254:	72bbd5a0 	movk	w0, #0xdead, lsl #16
 258:	110003e0 	mov	w0, wsp
 25c:	1100001f 	mov	wsp, w0
 260:	2a2103e0 	mvn	w0, w1
 264:	4b0103e0 	neg	w0, w1
 268:	5ac00820 	rev	w0, w1
 26c:	5ac00420 	rev16	w0, w1
 270:	13001c20 	sxtb	w0, w1
 274:	13003c20 	sxth	w0, w1
 278:	2a2103e0 	mvn	w0, w1
 27c:	2a2107e0 	mvn	w0, w1, lsl #1
 280:	2a217fe0 	mvn	w0, w1, lsl #31
 284:	2a6103e0 	mvn	w0, w1, lsr #0
 288:	2a6107e0 	mvn	w0, w1, lsr #1
 28c:	2a617fe0 	mvn	w0, w1, lsr #31
 290:	2aa103e0 	mvn	w0, w1, asr #0
 294:	2aa107e0 	mvn	w0, w1, asr #1
 298:	2aa17fe0 	mvn	w0, w1, asr #31
 29c:	2ae103e0 	mvn	w0, w1, ror #0
 2a0:	2ae107e0 	mvn	w0, w1, ror #1
 2a4:	2ae17fe0 	mvn	w0, w1, ror #31
 2a8:	4b0103e0 	neg	w0, w1
 2ac:	4b0107e0 	neg	w0, w1, lsl #1
 2b0:	4b017fe0 	neg	w0, w1, lsl #31
 2b4:	4b4103e0 	neg	w0, w1, lsr #0
 2b8:	4b4107e0 	neg	w0, w1, lsr #1
 2bc:	4b417fe0 	neg	w0, w1, lsr #31
 2c0:	4b8103e0 	neg	w0, w1, asr #0
 2c4:	4b8107e0 	neg	w0, w1, asr #1
 2c8:	4b817fe0 	neg	w0, w1, asr #31
 2cc:	1b027c20 	mul	w0, w1, w2
 2d0:	1ac20820 	udiv	w0, w1, w2
 2d4:	1b020c20 	madd	w0, w1, w2, w3
 2d8:	1b028c20 	msub	w0, w1, w2, w3
 2dc:	1ac22020 	lsl	w0, w1, w2
 2e0:	53007c20 	lsr	w0, w1, #0
 2e4:	531f7820 	lsl	w0, w1, #1
 2e8:	53196020 	lsl	w0, w1, #7
 2ec:	53010020 	lsl	w0, w1, #31
 2f0:	1ac22420 	lsr	w0, w1, w2
 2f4:	53007c20 	lsr	w0, w1, #0
 2f8:	53017c20 	lsr	w0, w1, #1
 2fc:	53077c20 	lsr	w0, w1, #7
 300:	531f7c20 	lsr	w0, w1, #31
 304:	1ac22820 	asr	w0, w1, w2
 308:	13007c20 	asr	w0, w1, #0
 30c:	13017c20 	asr	w0, w1, #1
 310:	13077c20 	asr	w0, w1, #7
 314:	131f7c20 	asr	w0, w1, #31
 318:	1ac22c20 	ror	w0, w1, w2
 31c:	13810020 	ror	w0, w1, #0
 320:	13810420 	ror	w0, w1, #1
 324:	13811c20 	ror	w0, w1, #7
 328:	13817c20 	ror	w0, w1, #31
 32c:	13821c20 	extr	w0, w1, w2, #7
 330:	53074c20 	ubfx	w0, w1, #7, #13
 334:	13074c20 	sbfx	w0, w1, #7, #13
 338:	53193020 	ubfiz	w0, w1, #7, #13
 33c:	33074c20 	bfxil	w0, w1, #7, #13
 340:	33193020 	bfi	w0, w1, #7, #13
 344:	1a820020 	csel	w0, w1, w2, eq	// eq = none
 348:	1a820420 	csinc	w0, w1, w2, eq	// eq = none
 34c:	5a820020 	csinv	w0, w1, w2, eq	// eq = none
 350:	5a820420 	csneg	w0, w1, w2, eq	// eq = none
 354:	1a811420 	cinc	w0, w1, eq	// eq = none
 358:	5a811020 	cinv	w0, w1, eq	// eq = none
 35c:	5a811420 	cneg	w0, w1, eq	// eq = none
 360:	1a9f17e0 	cset	w0, eq	// eq = none
 364:	5a9f13e0 	csetm	w0, eq	// eq = none
 368:	7a420025 	ccmp	w1, w2, #0x5, eq	// eq = none
 36c:	7a47082a 	ccmp	w1, #0x7, #0xa, eq	// eq = none
 370:	1a821020 	csel	w0, w1, w2, ne	// ne = any
 374:	1a821420 	csinc	w0, w1, w2, ne	// ne = any
 378:	5a821020 	csinv	w0, w1, w2, ne	// ne = any
 37c:	5a821420 	csneg	w0, w1, w2, ne	// ne = any
 380:	1a810420 	cinc	w0, w1, ne	// ne = any
 384:	5a810020 	cinv	w0, w1, ne	// ne = any
 388:	5a810420 	cneg	w0, w1, ne	// ne = any
 38c:	1a9f07e0 	cset	w0, ne	// ne = any
 390:	5a9f03e0 	csetm	w0, ne	// ne = any
 394:	7a421025 	ccmp	w1, w2, #0x5, ne	// ne = any
 398:	7a47182a 	ccmp	w1, #0x7, #0xa, ne	// ne = any
 39c:	1a822020 	csel	w0, w1, w2, cs	// cs = hs, nlast
 3a0:	1a822420 	csinc	w0, w1, w2, cs	// cs = hs, nlast
 3a4:	5a822020 	csinv	w0, w1, w2, cs	// cs = hs, nlast
 3a8:	5a822420 	csneg	w0, w1, w2, cs	// cs = hs, nlast
 3ac:	1a813420 	cinc	w0, w1, cs	// cs = hs, nlast
 3b0:	5a813020 	cinv	w0, w1, cs	// cs = hs, nlast
 3b4:	5a813420 	cneg	w0, w1, cs	// cs = hs, nlast
 3b8:	1a9f37e0 	cset	w0, cs	// cs = hs, nlast
 3bc:	5a9f33e0 	csetm	w0, cs	// cs = hs, nlast
 3c0:	7a422025 	ccmp	w1, w2, #0x5, cs	// cs = hs, nlast
 3c4:	7a47282a 	ccmp	w1, #0x7, #0xa, cs	// cs = hs, nlast
 3c8:	1a823020 	csel	w0, w1, w2, cc	// cc = lo, ul, last
 3cc:	1a823420 	csinc	w0, w1, w2, cc	// cc = lo, ul, last
 3d0:	5a823020 	csinv	w0, w1, w2, cc	// cc = lo, ul, last
 3d4:	5a823420 	csneg	w0, w1, w2, cc	// cc = lo, ul, last
 3d8:	1a812420 	cinc	w0, w1, cc	// cc = lo, ul, last
 3dc:	5a812020 	cinv	w0, w1, cc	// cc = lo, ul, last
 3e0:	5a812420 	cneg	w0, w1, cc	// cc = lo, ul, last
 3e4:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
 3e8:	5a9f23e0 	csetm	w0, cc	// cc = lo, ul, last
 3ec:	7a423025 	ccmp	w1, w2, #0x5, cc	// cc = lo, ul, last
 3f0:	7a47382a 	ccmp	w1, #0x7, #0xa, cc	// cc = lo, ul, last
 3f4:	1a824020 	csel	w0, w1, w2, mi	// mi = first
 3f8:	1a824420 	csinc	w0, w1, w2, mi	// mi = first
 3fc:	5a824020 	csinv	w0, w1, w2, mi	// mi = first
 400:	5a824420 	csneg	w0, w1, w2, mi	// mi = first
 404:	1a815420 	cinc	w0, w1, mi	// mi = first
 408:	5a815020 	cinv	w0, w1, mi	// mi = first
 40c:	5a815420 	cneg	w0, w1, mi	// mi = first
 410:	1a9f57e0 	cset	w0, mi	// mi = first
 414:	5a9f53e0 	csetm	w0, mi	// mi = first
 418:	7a424025 	ccmp	w1, w2, #0x5, mi	// mi = first
 41c:	7a47482a 	ccmp	w1, #0x7, #0xa, mi	// mi = first
 420:	1a825020 	csel	w0, w1, w2, pl	// pl = nfrst
 424:	1a825420 	csinc	w0, w1, w2, pl	// pl = nfrst
 428:	5a825020 	csinv	w0, w1, w2, pl	// pl = nfrst
 42c:	5a825420 	csneg	w0, w1, w2, pl	// pl = nfrst
 430:	1a814420 	cinc	w0, w1, pl	// pl = nfrst
 434:	5a814020 	cinv	w0, w1, pl	// pl = nfrst
 438:	5a814420 	cneg	w0, w1, pl	// pl = nfrst
 43c:	1a9f47e0 	cset	w0, pl	// pl = nfrst
 440:	5a9f43e0 	csetm	w0, pl	// pl = nfrst
 444:	7a425025 	ccmp	w1, w2, #0x5, pl	// pl = nfrst
 448:	7a47582a 	ccmp	w1, #0x7, #0xa, pl	// pl = nfrst
 44c:	1a826020 	csel	w0, w1, w2, vs
 450:	1a826420 	csinc	w0, w1, w2, vs
 454:	5a826020 	csinv	w0, w1, w2, vs
 458:	5a826420 	csneg	w0, w1, w2, vs
 45c:	1a817420 	cinc	w0, w1, vs
 460:	5a817020 	cinv	w0, w1, vs
 464:	5a817420 	cneg	w0, w1, vs
 468:	1a9f77e0 	cset	w0, vs
 46c:	5a9f73e0 	csetm	w0, vs
 470:	7a426025 	ccmp	w1, w2, #0x5, vs
 474:	7a47682a 	ccmp	w1, #0x7, #0xa, vs
 478:	1a827020 	csel	w0, w1, w2, vc
 47c:	1a827420 	csinc	w0, w1, w2, vc
 480:	5a827020 	csinv	w0, w1, w2, vc
 484:	5a827420 	csneg	w0, w1, w2, vc
 488:	1a816420 	cinc	w0, w1, vc
 48c:	5a816020 	cinv	w0, w1, vc
 490:	5a816420 	cneg	w0, w1, vc
 494:	1a9f67e0 	cset	w0, vc
 498:	5a9f63e0 	csetm	w0, vc
 49c:	7a427025 	ccmp	w1, w2, #0x5, vc
 4a0:	7a47782a 	ccmp	w1, #0x7, #0xa, vc
 4a4:	1a828020 	csel	w0, w1, w2, hi	// hi = pmore
 4a8:	1a828420 	csinc	w0, w1, w2, hi	// hi = pmore
 4ac:	5a828020 	csinv	w0, w1, w2, hi	// hi = pmore
 4b0:	5a828420 	csneg	w0, w1, w2, hi	// hi = pmore
 4b4:	1a819420 	cinc	w0, w1, hi	// hi = pmore
 4b8:	5a819020 	cinv	w0, w1, hi	// hi = pmore
 4bc:	5a819420 	cneg	w0, w1, hi	// hi = pmore
 4c0:	1a9f97e0 	cset	w0, hi	// hi = pmore
 4c4:	5a9f93e0 	csetm	w0, hi	// hi = pmore
 4c8:	7a428025 	ccmp	w1, w2, #0x5, hi	// hi = pmore
 4cc:	7a47882a 	ccmp	w1, #0x7, #0xa, hi	// hi = pmore
 4d0:	1a829020 	csel	w0, w1, w2, ls	// ls = plast
 4d4:	1a829420 	csinc	w0, w1, w2, ls	// ls = plast
 4d8:	5a829020 	csinv	w0, w1, w2, ls	// ls = plast
 4dc:	5a829420 	csneg	w0, w1, w2, ls	// ls = plast
 4e0:	1a818420 	cinc	w0, w1, ls	// ls = plast
 4e4:	5a818020 	cinv	w0, w1, ls	// ls = plast
 4e8:	5a818420 	cneg	w0, w1, ls	// ls = plast
 4ec:	1a9f87e0 	cset	w0, ls	// ls = plast
 4f0:	5a9f83e0 	csetm	w0, ls	// ls = plast
 4f4:	7a429025 	ccmp	w1, w2, #0x5, ls	// ls = plast
 4f8:	7a47982a 	ccmp	w1, #0x7, #0xa, ls	// ls = plast
 4fc:	1a82a020 	csel	w0, w1, w2, ge	// ge = tcont
 500:	1a82a420 	csinc	w0, w1, w2, ge	// ge = tcont
 504:	5a82a020 	csinv	w0, w1, w2, ge	// ge = tcont
 508:	5a82a420 	csneg	w0, w1, w2, ge	// ge = tcont
 50c:	1a81b420 	cinc	w0, w1, ge	// ge = tcont
 510:	5a81b020 	cinv	w0, w1, ge	// ge = tcont
 514:	5a81b420 	cneg	w0, w1, ge	// ge = tcont
 518:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 51c:	5a9fb3e0 	csetm	w0, ge	// ge = tcont
 520:	7a42a025 	ccmp	w1, w2, #0x5, ge	// ge = tcont
 524:	7a47a82a 	ccmp	w1, #0x7, #0xa, ge	// ge = tcont
 528:	1a82b020 	csel	w0, w1, w2, lt	// lt = tstop
 52c:	1a82b420 	csinc	w0, w1, w2, lt	// lt = tstop
 530:	5a82b020 	csinv	w0, w1, w2, lt	// lt = tstop
 534:	5a82b420 	csneg	w0, w1, w2, lt	// lt = tstop
 538:	1a81a420 	cinc	w0, w1, lt	// lt = tstop
 53c:	5a81a020 	cinv	w0, w1, lt	// lt = tstop
 540:	5a81a420 	cneg	w0, w1, lt	// lt = tstop
 544:	1a9fa7e0 	cset	w0, lt	// lt = tstop
 548:	5a9fa3e0 	csetm	w0, lt	// lt = tstop
 54c:	7a42b025 	ccmp	w1, w2, #0x5, lt	// lt = tstop
 550:	7a47b82a 	ccmp	w1, #0x7, #0xa, lt	// lt = tstop
 554:	1a82c020 	csel	w0, w1, w2, gt
 558:	1a82c420 	csinc	w0, w1, w2, gt
 55c:	5a82c020 	csinv	w0, w1, w2, gt
 560:	5a82c420 	csneg	w0, w1, w2, gt
 564:	1a81d420 	cinc	w0, w1, gt
 568:	5a81d020 	cinv	w0, w1, gt
 56c:	5a81d420 	cneg	w0, w1, gt
 570:	1a9fd7e0 	cset	w0, gt
 574:	5a9fd3e0 	csetm	w0, gt
 578:	7a42c025 	ccmp	w1, w2, #0x5, gt
 57c:	7a47c82a 	ccmp	w1, #0x7, #0xa, gt
 580:	1a82d020 	csel	w0, w1, w2, le
 584:	1a82d420 	csinc	w0, w1, w2, le
 588:	5a82d020 	csinv	w0, w1, w2, le
 58c:	5a82d420 	csneg	w0, w1, w2, le
 590:	1a81c420 	cinc	w0, w1, le
 594:	5a81c020 	cinv	w0, w1, le
 598:	5a81c420 	cneg	w0, w1, le
 59c:	1a9fc7e0 	cset	w0, le
 5a0:	5a9fc3e0 	csetm	w0, le
 5a4:	7a42d025 	ccmp	w1, w2, #0x5, le
 5a8:	7a47d82a 	ccmp	w1, #0x7, #0xa, le
 5ac:	1a82e020 	csel	w0, w1, w2, al
 5b0:	1a82e420 	csinc	w0, w1, w2, al
 5b4:	5a82e020 	csinv	w0, w1, w2, al
 5b8:	5a82e420 	csneg	w0, w1, w2, al
 5bc:	7a42e025 	ccmp	w1, w2, #0x5, al
 5c0:	7a47e82a 	ccmp	w1, #0x7, #0xa, al
 5c4:	1a82f020 	csel	w0, w1, w2, nv
 5c8:	1a82f420 	csinc	w0, w1, w2, nv
 5cc:	5a82f020 	csinv	w0, w1, w2, nv
 5d0:	5a82f420 	csneg	w0, w1, w2, nv
 5d4:	7a42f025 	ccmp	w1, w2, #0x5, nv
 5d8:	7a47f82a 	ccmp	w1, #0x7, #0xa, nv
 5dc:	b9400880 	ldr	w0, [x4, #8]
 5e0:	b9000880 	str	w0, [x4, #8]
 5e4:	b8408080 	ldur	w0, [x4, #8]
 5e8:	b8008080 	stur	w0, [x4, #8]
 5ec:	b8408c80 	ldr	w0, [x4, #8]!
 5f0:	b8408480 	ldr	w0, [x4], #8
 5f4:	b8657880 	ldr	w0, [x4, x5, lsl #2]
 5f8:	b8008c80 	str	w0, [x4, #8]!
 5fc:	b8008480 	str	w0, [x4], #8
 600:	b8257880 	str	w0, [x4, x5, lsl #2]
 604:	39402080 	ldrb	w0, [x4, #8]
 608:	79401080 	ldrh	w0, [x4, #8]
 60c:	39002080 	strb	w0, [x4, #8]
 610:	79001080 	strh	w0, [x4, #8]
 614:	39c02080 	ldrsb	w0, [x4, #8]
 618:	79c01080 	ldrsh	w0, [x4, #8]
 61c:	8b020020 	add	x0, x1, x2
 620:	8b020c20 	add	x0, x1, x2, lsl #3
 624:	9101fc20 	add	x0, x1, #0x7f
 628:	cb020020 	sub	x0, x1, x2
 62c:	cb020c20 	sub	x0, x1, x2, lsl #3
 630:	d101fc20 	sub	x0, x1, #0x7f
 634:	8a020020 	and	x0, x1, x2
 638:	8a020c20 	and	x0, x1, x2, lsl #3
 63c:	8a220020 	bic	x0, x1, x2
 640:	8a220c20 	bic	x0, x1, x2, lsl #3
 644:	ca020020 	eor	x0, x1, x2
 648:	ca020c20 	eor	x0, x1, x2, lsl #3
 64c:	aa020020 	orr	x0, x1, x2
 650:	aa020c20 	orr	x0, x1, x2, lsl #3
 654:	aa220020 	orn	x0, x1, x2
 658:	aa220c20 	orn	x0, x1, x2, lsl #3
 65c:	ab020020 	adds	x0, x1, x2
 660:	ab020c20 	adds	x0, x1, x2, lsl #3
 664:	b101fc20 	adds	x0, x1, #0x7f
 668:	eb020020 	subs	x0, x1, x2
 66c:	eb020c20 	subs	x0, x1, x2, lsl #3
 670:	f101fc20 	subs	x0, x1, #0x7f
 674:	ea020020 	ands	x0, x1, x2
 678:	ea020c20 	ands	x0, x1, x2, lsl #3
 67c:	ea220020 	bics	x0, x1, x2
 680:	ea220c20 	bics	x0, x1, x2, lsl #3
 684:	eb02003f 	cmp	x1, x2
 688:	eb020c3f 	cmp	x1, x2, lsl #3
 68c:	ab02003f 	cmn	x1, x2
 690:	ab020c3f 	cmn	x1, x2, lsl #3
 694:	ea02003f 	tst	x1, x2
 698:	ea020c3f 	tst	x1, x2, lsl #3
 69c:	f100003f 	cmp	x1, #0x0
 6a0:	f101fc3f 	cmp	x1, #0x7f
 6a4:	f13ffc3f 	cmp	x1, #0xfff
 6a8:	f140043f 	cmp	x1, #0x1, lsl #12
 6ac:	b100003f 	cmn	x1, #0x0
 6b0:	b101fc3f 	cmn	x1, #0x7f
 6b4:	b13ffc3f 	cmn	x1, #0xfff
 6b8:	b140043f 	cmn	x1, #0x1, lsl #12
 6bc:	ea22003f 	bics	xzr, x1, x2
 6c0:	ea621c3f 	bics	xzr, x1, x2, lsr #7
 6c4:	eaa27c3f 	bics	xzr, x1, x2, asr #31
 6c8:	eae21c3f 	bics	xzr, x1, x2, ror #7
 6cc:	92400020 	and	x0, x1, #0x1
 6d0:	92400000 	and	x0, x0, #0x1
 6d4:	924003e0 	and	x0, xzr, #0x1
 6d8:	9240003f 	and	sp, x1, #0x1
 6dc:	b2400020 	orr	x0, x1, #0x1
 6e0:	b2400000 	orr	x0, x0, #0x1
 6e4:	b24003e0 	orr	x0, xzr, #0x1
 6e8:	b240003f 	orr	sp, x1, #0x1
 6ec:	d2400020 	eor	x0, x1, #0x1
 6f0:	d2400000 	eor	x0, x0, #0x1
 6f4:	d24003e0 	eor	x0, xzr, #0x1
 6f8:	d240003f 	eor	sp, x1, #0x1
 6fc:	f2400020 	ands	x0, x1, #0x1
 700:	f2400000 	ands	x0, x0, #0x1
 704:	f24003e0 	ands	x0, xzr, #0x1
 708:	f240003f 	tst	x1, #0x1
 70c:	f24003ff 	tst	xzr, #0x1
 710:	92401c20 	and	x0, x1, #0xff
 714:	92401c00 	and	x0, x0, #0xff
 718:	92401fe0 	and	x0, xzr, #0xff
 71c:	92401c3f 	and	sp, x1, #0xff
 720:	b2401c20 	orr	x0, x1, #0xff
 724:	b2401c00 	orr	x0, x0, #0xff
 728:	b2401fe0 	orr	x0, xzr, #0xff
 72c:	b2401c3f 	orr	sp, x1, #0xff
 730:	d2401c20 	eor	x0, x1, #0xff
 734:	d2401c00 	eor	x0, x0, #0xff
 738:	d2401fe0 	eor	x0, xzr, #0xff
 73c:	d2401c3f 	eor	sp, x1, #0xff
 740:	f2401c20 	ands	x0, x1, #0xff
 744:	f2401c00 	ands	x0, x0, #0xff
 748:	f2401fe0 	ands	x0, xzr, #0xff
 74c:	f2401c3f 	tst	x1, #0xff
 750:	f2401fff 	tst	xzr, #0xff
 754:	92410020 	and	x0, x1, #0x8000000000000000
 758:	92410000 	and	x0, x0, #0x8000000000000000
 75c:	924103e0 	and	x0, xzr, #0x8000000000000000
 760:	9241003f 	and	sp, x1, #0x8000000000000000
 764:	b2410020 	orr	x0, x1, #0x8000000000000000
 768:	b2410000 	orr	x0, x0, #0x8000000000000000
 76c:	b24103e0 	orr	x0, xzr, #0x8000000000000000
 770:	b241003f 	orr	sp, x1, #0x8000000000000000
 774:	d2410020 	eor	x0, x1, #0x8000000000000000
 778:	d2410000 	eor	x0, x0, #0x8000000000000000
 77c:	d24103e0 	eor	x0, xzr, #0x8000000000000000
 780:	d241003f 	eor	sp, x1, #0x8000000000000000
 784:	f2410020 	ands	x0, x1, #0x8000000000000000
 788:	f2410000 	ands	x0, x0, #0x8000000000000000
 78c:	f24103e0 	ands	x0, xzr, #0x8000000000000000
 790:	f241003f 	tst	x1, #0x8000000000000000
 794:	f24103ff 	tst	xzr, #0x8000000000000000
 798:	92407c20 	and	x0, x1, #0xffffffff
 79c:	92407c00 	and	x0, x0, #0xffffffff
 7a0:	92407fe0 	and	x0, xzr, #0xffffffff
 7a4:	92407c3f 	and	sp, x1, #0xffffffff
 7a8:	b2407c20 	orr	x0, x1, #0xffffffff
 7ac:	b2407c00 	orr	x0, x0, #0xffffffff
 7b0:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
 7b4:	b2407c3f 	orr	sp, x1, #0xffffffff
 7b8:	d2407c20 	eor	x0, x1, #0xffffffff
 7bc:	d2407c00 	eor	x0, x0, #0xffffffff
 7c0:	d2407fe0 	eor	x0, xzr, #0xffffffff
 7c4:	d2407c3f 	eor	sp, x1, #0xffffffff
 7c8:	f2407c20 	ands	x0, x1, #0xffffffff
 7cc:	f2407c00 	ands	x0, x0, #0xffffffff
 7d0:	f2407fe0 	ands	x0, xzr, #0xffffffff
 7d4:	f2407c3f 	tst	x1, #0xffffffff
 7d8:	f2407fff 	tst	xzr, #0xffffffff
 7dc:	92009c20 	and	x0, x1, #0xff00ff00ff00ff
 7e0:	92009c00 	and	x0, x0, #0xff00ff00ff00ff
 7e4:	92009fe0 	and	x0, xzr, #0xff00ff00ff00ff
 7e8:	92009c3f 	and	sp, x1, #0xff00ff00ff00ff
 7ec:	b2009c20 	orr	x0, x1, #0xff00ff00ff00ff
 7f0:	b2009c00 	orr	x0, x0, #0xff00ff00ff00ff
 7f4:	b2009fe0 	mov	x0, #0xff00ff00ff00ff      	// #71777214294589695
 7f8:	b2009c3f 	orr	sp, x1, #0xff00ff00ff00ff
 7fc:	d2009c20 	eor	x0, x1, #0xff00ff00ff00ff
 800:	d2009c00 	eor	x0, x0, #0xff00ff00ff00ff
 804:	d2009fe0 	eor	x0, xzr, #0xff00ff00ff00ff
 808:	d2009c3f 	eor	sp, x1, #0xff00ff00ff00ff
 80c:	f2009c20 	ands	x0, x1, #0xff00ff00ff00ff
 810:	f2009c00 	ands	x0, x0, #0xff00ff00ff00ff
 814:	f2009fe0 	ands	x0, xzr, #0xff00ff00ff00ff
 818:	f2009c3f 	tst	x1, #0xff00ff00ff00ff
 81c:	f2009fff 	tst	xzr, #0xff00ff00ff00ff
 820:	9201f020 	and	x0, x1, #0xaaaaaaaaaaaaaaaa
 824:	9201f000 	and	x0, x0, #0xaaaaaaaaaaaaaaaa
 828:	9201f3e0 	and	x0, xzr, #0xaaaaaaaaaaaaaaaa
 82c:	9201f03f 	and	sp, x1, #0xaaaaaaaaaaaaaaaa
 830:	b201f020 	orr	x0, x1, #0xaaaaaaaaaaaaaaaa
 834:	b201f000 	orr	x0, x0, #0xaaaaaaaaaaaaaaaa
 838:	b201f3e0 	mov	x0, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
 83c:	b201f03f 	orr	sp, x1, #0xaaaaaaaaaaaaaaaa
 840:	d201f020 	eor	x0, x1, #0xaaaaaaaaaaaaaaaa
 844:	d201f000 	eor	x0, x0, #0xaaaaaaaaaaaaaaaa
 848:	d201f3e0 	eor	x0, xzr, #0xaaaaaaaaaaaaaaaa
 84c:	d201f03f 	eor	sp, x1, #0xaaaaaaaaaaaaaaaa
 850:	f201f020 	ands	x0, x1, #0xaaaaaaaaaaaaaaaa
 854:	f201f000 	ands	x0, x0, #0xaaaaaaaaaaaaaaaa
 858:	f201f3e0 	ands	x0, xzr, #0xaaaaaaaaaaaaaaaa
 85c:	f201f03f 	tst	x1, #0xaaaaaaaaaaaaaaaa
 860:	f201f3ff 	tst	xzr, #0xaaaaaaaaaaaaaaaa
 864:	aa0103e0 	mov	x0, x1
 868:	d2800fe0 	mov	x0, #0x7f                  	// #127
 86c:	f2bbd5a0 	movk	x0, #0xdead, lsl #16
 870:	910003e0 	mov	x0, sp
 874:	9100001f 	mov	sp, x0
 878:	aa2103e0 	mvn	x0, x1
 87c:	cb0103e0 	neg	x0, x1
 880:	dac00c20 	rev	x0, x1
 884:	dac00420 	rev16	x0, x1
 888:	93401c20 	sxtb	x0, w1
 88c:	93403c20 	sxth	x0, w1
 890:	aa2103e0 	mvn	x0, x1
 894:	aa2107e0 	mvn	x0, x1, lsl #1
 898:	aa21ffe0 	mvn	x0, x1, lsl #63
 89c:	aa6103e0 	mvn	x0, x1, lsr #0
 8a0:	aa6107e0 	mvn	x0, x1, lsr #1
 8a4:	aa61ffe0 	mvn	x0, x1, lsr #63
 8a8:	aaa103e0 	mvn	x0, x1, asr #0
 8ac:	aaa107e0 	mvn	x0, x1, asr #1
 8b0:	aaa1ffe0 	mvn	x0, x1, asr #63
 8b4:	aae103e0 	mvn	x0, x1, ror #0
 8b8:	aae107e0 	mvn	x0, x1, ror #1
 8bc:	aae1ffe0 	mvn	x0, x1, ror #63
 8c0:	cb0103e0 	neg	x0, x1
 8c4:	cb0107e0 	neg	x0, x1, lsl #1
 8c8:	cb01ffe0 	neg	x0, x1, lsl #63
 8cc:	cb4103e0 	neg	x0, x1, lsr #0
 8d0:	cb4107e0 	neg	x0, x1, lsr #1
 8d4:	cb41ffe0 	neg	x0, x1, lsr #63
 8d8:	cb8103e0 	neg	x0, x1, asr #0
 8dc:	cb8107e0 	neg	x0, x1, asr #1
 8e0:	cb81ffe0 	neg	x0, x1, asr #63
 8e4:	9b027c20 	mul	x0, x1, x2
 8e8:	9ac20820 	udiv	x0, x1, x2
 8ec:	9b020c20 	madd	x0, x1, x2, x3
 8f0:	9b028c20 	msub	x0, x1, x2, x3
 8f4:	9ac22020 	lsl	x0, x1, x2
 8f8:	d340fc20 	lsr	x0, x1, #0
 8fc:	d37ff820 	lsl	x0, x1, #1
 900:	d379e020 	lsl	x0, x1, #7
 904:	d3618020 	lsl	x0, x1, #31
 908:	9ac22420 	lsr	x0, x1, x2
 90c:	d340fc20 	lsr	x0, x1, #0
 910:	d341fc20 	lsr	x0, x1, #1
 914:	d347fc20 	lsr	x0, x1, #7
 918:	d35ffc20 	lsr	x0, x1, #31
 91c:	9ac22820 	asr	x0, x1, x2
 920:	9340fc20 	asr	x0, x1, #0
 924:	9341fc20 	asr	x0, x1, #1
 928:	9347fc20 	asr	x0, x1, #7
 92c:	935ffc20 	asr	x0, x1, #31
 930:	9ac22c20 	ror	x0, x1, x2
 934:	93c10020 	ror	x0, x1, #0
 938:	93c10420 	ror	x0, x1, #1
 93c:	93c11c20 	ror	x0, x1, #7
 940:	93c17c20 	ror	x0, x1, #31
 944:	93c21c20 	extr	x0, x1, x2, #7
 948:	d3474c20 	ubfx	x0, x1, #7, #13
 94c:	93474c20 	sbfx	x0, x1, #7, #13
 950:	d3793020 	ubfiz	x0, x1, #7, #13
 954:	b3474c20 	bfxil	x0, x1, #7, #13
 958:	b3793020 	bfi	x0, x1, #7, #13
 95c:	9a820020 	csel	x0, x1, x2, eq	// eq = none
 960:	9a820420 	csinc	x0, x1, x2, eq	// eq = none
 964:	da820020 	csinv	x0, x1, x2, eq	// eq = none
 968:	da820420 	csneg	x0, x1, x2, eq	// eq = none
 96c:	9a811420 	cinc	x0, x1, eq	// eq = none
 970:	da811020 	cinv	x0, x1, eq	// eq = none
 974:	da811420 	cneg	x0, x1, eq	// eq = none
 978:	9a9f17e0 	cset	x0, eq	// eq = none
 97c:	da9f13e0 	csetm	x0, eq	// eq = none
 980:	fa420025 	ccmp	x1, x2, #0x5, eq	// eq = none
 984:	fa47082a 	ccmp	x1, #0x7, #0xa, eq	// eq = none
 988:	9a821020 	csel	x0, x1, x2, ne	// ne = any
 98c:	9a821420 	csinc	x0, x1, x2, ne	// ne = any
 990:	da821020 	csinv	x0, x1, x2, ne	// ne = any
 994:	da821420 	csneg	x0, x1, x2, ne	// ne = any
 998:	9a810420 	cinc	x0, x1, ne	// ne = any
 99c:	da810020 	cinv	x0, x1, ne	// ne = any
 9a0:	da810420 	cneg	x0, x1, ne	// ne = any
 9a4:	9a9f07e0 	cset	x0, ne	// ne = any
 9a8:	da9f03e0 	csetm	x0, ne	// ne = any
 9ac:	fa421025 	ccmp	x1, x2, #0x5, ne	// ne = any
 9b0:	fa47182a 	ccmp	x1, #0x7, #0xa, ne	// ne = any
 9b4:	9a822020 	csel	x0, x1, x2, cs	// cs = hs, nlast
 9b8:	9a822420 	csinc	x0, x1, x2, cs	// cs = hs, nlast
 9bc:	da822020 	csinv	x0, x1, x2, cs	// cs = hs, nlast
 9c0:	da822420 	csneg	x0, x1, x2, cs	// cs = hs, nlast
 9c4:	9a813420 	cinc	x0, x1, cs	// cs = hs, nlast
 9c8:	da813020 	cinv	x0, x1, cs	// cs = hs, nlast
 9cc:	da813420 	cneg	x0, x1, cs	// cs = hs, nlast
 9d0:	9a9f37e0 	cset	x0, cs	// cs = hs, nlast
 9d4:	da9f33e0 	csetm	x0, cs	// cs = hs, nlast
 9d8:	fa422025 	ccmp	x1, x2, #0x5, cs	// cs = hs, nlast
 9dc:	fa47282a 	ccmp	x1, #0x7, #0xa, cs	// cs = hs, nlast
 9e0:	9a823020 	csel	x0, x1, x2, cc	// cc = lo, ul, last
 9e4:	9a823420 	csinc	x0, x1, x2, cc	// cc = lo, ul, last
 9e8:	da823020 	csinv	x0, x1, x2, cc	// cc = lo, ul, last
 9ec:	da823420 	csneg	x0, x1, x2, cc	// cc = lo, ul, last
 9f0:	9a812420 	cinc	x0, x1, cc	// cc = lo, ul, last
 9f4:	da812020 	cinv	x0, x1, cc	// cc = lo, ul, last
 9f8:	da812420 	cneg	x0, x1, cc	// cc = lo, ul, last
 9fc:	9a9f27e0 	cset	x0, cc	// cc = lo, ul, last
 a00:	da9f23e0 	csetm	x0, cc	// cc = lo, ul, last
 a04:	fa423025 	ccmp	x1, x2, #0x5, cc	// cc = lo, ul, last
 a08:	fa47382a 	ccmp	x1, #0x7, #0xa, cc	// cc = lo, ul, last
 a0c:	9a824020 	csel	x0, x1, x2, mi	// mi = first
 a10:	9a824420 	csinc	x0, x1, x2, mi	// mi = first
 a14:	da824020 	csinv	x0, x1, x2, mi	// mi = first
 a18:	da824420 	csneg	x0, x1, x2, mi	// mi = first
 a1c:	9a815420 	cinc	x0, x1, mi	// mi = first
 a20:	da815020 	cinv	x0, x1, mi	// mi = first
 a24:	da815420 	cneg	x0, x1, mi	// mi = first
 a28:	9a9f57e0 	cset	x0, mi	// mi = first
 a2c:	da9f53e0 	csetm	x0, mi	// mi = first
 a30:	fa424025 	ccmp	x1, x2, #0x5, mi	// mi = first
 a34:	fa47482a 	ccmp	x1, #0x7, #0xa, mi	// mi = first
 a38:	9a825020 	csel	x0, x1, x2, pl	// pl = nfrst
 a3c:	9a825420 	csinc	x0, x1, x2, pl	// pl = nfrst
 a40:	da825020 	csinv	x0, x1, x2, pl	// pl = nfrst
 a44:	da825420 	csneg	x0, x1, x2, pl	// pl = nfrst
 a48:	9a814420 	cinc	x0, x1, pl	// pl = nfrst
 a4c:	da814020 	cinv	x0, x1, pl	// pl = nfrst
 a50:	da814420 	cneg	x0, x1, pl	// pl = nfrst
 a54:	9a9f47e0 	cset	x0, pl	// pl = nfrst
 a58:	da9f43e0 	csetm	x0, pl	// pl = nfrst
 a5c:	fa425025 	ccmp	x1, x2, #0x5, pl	// pl = nfrst
 a60:	fa47582a 	ccmp	x1, #0x7, #0xa, pl	// pl = nfrst
 a64:	9a826020 	csel	x0, x1, x2, vs
 a68:	9a826420 	csinc	x0, x1, x2, vs
 a6c:	da826020 	csinv	x0, x1, x2, vs
 a70:	da826420 	csneg	x0, x1, x2, vs
 a74:	9a817420 	cinc	x0, x1, vs
 a78:	da817020 	cinv	x0, x1, vs
 a7c:	da817420 	cneg	x0, x1, vs
 a80:	9a9f77e0 	cset	x0, vs
 a84:	da9f73e0 	csetm	x0, vs
 a88:	fa426025 	ccmp	x1, x2, #0x5, vs
 a8c:	fa47682a 	ccmp	x1, #0x7, #0xa, vs
 a90:	9a827020 	csel	x0, x1, x2, vc
 a94:	9a827420 	csinc	x0, x1, x2, vc
 a98:	da827020 	csinv	x0, x1, x2, vc
 a9c:	da827420 	csneg	x0, x1, x2, vc
 aa0:	9a816420 	cinc	x0, x1, vc
 aa4:	da816020 	cinv	x0, x1, vc
 aa8:	da816420 	cneg	x0, x1, vc
 aac:	9a9f67e0 	cset	x0, vc
 ab0:	da9f63e0 	csetm	x0, vc
 ab4:	fa427025 	ccmp	x1, x2, #0x5, vc
 ab8:	fa47782a 	ccmp	x1, #0x7, #0xa, vc
 abc:	9a828020 	csel	x0, x1, x2, hi	// hi = pmore
 ac0:	9a828420 	csinc	x0, x1, x2, hi	// hi = pmore
 ac4:	da828020 	csinv	x0, x1, x2, hi	// hi = pmore
 ac8:	da828420 	csneg	x0, x1, x2, hi	// hi = pmore
 acc:	9a819420 	cinc	x0, x1, hi	// hi = pmore
 ad0:	da819020 	cinv	x0, x1, hi	// hi = pmore
 ad4:	da819420 	cneg	x0, x1, hi	// hi = pmore
 ad8:	9a9f97e0 	cset	x0, hi	// hi = pmore
 adc:	da9f93e0 	csetm	x0, hi	// hi = pmore
 ae0:	fa428025 	ccmp	x1, x2, #0x5, hi	// hi = pmore
 ae4:	fa47882a 	ccmp	x1, #0x7, #0xa, hi	// hi = pmore
 ae8:	9a829020 	csel	x0, x1, x2, ls	// ls = plast
 aec:	9a829420 	csinc	x0, x1, x2, ls	// ls = plast
 af0:	da829020 	csinv	x0, x1, x2, ls	// ls = plast
 af4:	da829420 	csneg	x0, x1, x2, ls	// ls = plast
 af8:	9a818420 	cinc	x0, x1, ls	// ls = plast
 afc:	da818020 	cinv	x0, x1, ls	// ls = plast
 b00:	da818420 	cneg	x0, x1, ls	// ls = plast
 b04:	9a9f87e0 	cset	x0, ls	// ls = plast
 b08:	da9f83e0 	csetm	x0, ls	// ls = plast
 b0c:	fa429025 	ccmp	x1, x2, #0x5, ls	// ls = plast
 b10:	fa47982a 	ccmp	x1, #0x7, #0xa, ls	// ls = plast
 b14:	9a82a020 	csel	x0, x1, x2, ge	// ge = tcont
 b18:	9a82a420 	csinc	x0, x1, x2, ge	// ge = tcont
 b1c:	da82a020 	csinv	x0, x1, x2, ge	// ge = tcont
 b20:	da82a420 	csneg	x0, x1, x2, ge	// ge = tcont
 b24:	9a81b420 	cinc	x0, x1, ge	// ge = tcont
 b28:	da81b020 	cinv	x0, x1, ge	// ge = tcont
 b2c:	da81b420 	cneg	x0, x1, ge	// ge = tcont
 b30:	9a9fb7e0 	cset	x0, ge	// ge = tcont
 b34:	da9fb3e0 	csetm	x0, ge	// ge = tcont
 b38:	fa42a025 	ccmp	x1, x2, #0x5, ge	// ge = tcont
 b3c:	fa47a82a 	ccmp	x1, #0x7, #0xa, ge	// ge = tcont
 b40:	9a82b020 	csel	x0, x1, x2, lt	// lt = tstop
 b44:	9a82b420 	csinc	x0, x1, x2, lt	// lt = tstop
 b48:	da82b020 	csinv	x0, x1, x2, lt	// lt = tstop
 b4c:	da82b420 	csneg	x0, x1, x2, lt	// lt = tstop
 b50:	9a81a420 	cinc	x0, x1, lt	// lt = tstop
 b54:	da81a020 	cinv	x0, x1, lt	// lt = tstop
 b58:	da81a420 	cneg	x0, x1, lt	// lt = tstop
 b5c:	9a9fa7e0 	cset	x0, lt	// lt = tstop
 b60:	da9fa3e0 	csetm	x0, lt	// lt = tstop
 b64:	fa42b025 	ccmp	x1, x2, #0x5, lt	// lt = tstop
 b68:	fa47b82a 	ccmp	x1, #0x7, #0xa, lt	// lt = tstop
 b6c:	9a82c020 	csel	x0, x1, x2, gt
 b70:	9a82c420 	csinc	x0, x1, x2, gt
 b74:	da82c020 	csinv	x0, x1, x2, gt
 b78:	da82c420 	csneg	x0, x1, x2, gt
 b7c:	9a81d420 	cinc	x0, x1, gt
 b80:	da81d020 	cinv	x0, x1, gt
 b84:	da81d420 	cneg	x0, x1, gt
 b88:	9a9fd7e0 	cset	x0, gt
 b8c:	da9fd3e0 	csetm	x0, gt
 b90:	fa42c025 	ccmp	x1, x2, #0x5, gt
 b94:	fa47c82a 	ccmp	x1, #0x7, #0xa, gt
 b98:	9a82d020 	csel	x0, x1, x2, le
 b9c:	9a82d420 	csinc	x0, x1, x2, le
 ba0:	da82d020 	csinv	x0, x1, x2, le
 ba4:	da82d420 	csneg	x0, x1, x2, le
 ba8:	9a81c420 	cinc	x0, x1, le
 bac:	da81c020 	cinv	x0, x1, le
 bb0:	da81c420 	cneg	x0, x1, le
 bb4:	9a9fc7e0 	cset	x0, le
 bb8:	da9fc3e0 	csetm	x0, le
 bbc:	fa42d025 	ccmp	x1, x2, #0x5, le
 bc0:	fa47d82a 	ccmp	x1, #0x7, #0xa, le
 bc4:	9a82e020 	csel	x0, x1, x2, al
 bc8:	9a82e420 	csinc	x0, x1, x2, al
 bcc:	da82e020 	csinv	x0, x1, x2, al
 bd0:	da82e420 	csneg	x0, x1, x2, al
 bd4:	fa42e025 	ccmp	x1, x2, #0x5, al
 bd8:	fa47e82a 	ccmp	x1, #0x7, #0xa, al
 bdc:	9a82f020 	csel	x0, x1, x2, nv
 be0:	9a82f420 	csinc	x0, x1, x2, nv
 be4:	da82f020 	csinv	x0, x1, x2, nv
 be8:	da82f420 	csneg	x0, x1, x2, nv
 bec:	fa42f025 	ccmp	x1, x2, #0x5, nv
 bf0:	fa47f82a 	ccmp	x1, #0x7, #0xa, nv
 bf4:	f9400480 	ldr	x0, [x4, #8]
 bf8:	f9000480 	str	x0, [x4, #8]
 bfc:	f8408080 	ldur	x0, [x4, #8]
 c00:	f8008080 	stur	x0, [x4, #8]
 c04:	f8408c80 	ldr	x0, [x4, #8]!
 c08:	f8408480 	ldr	x0, [x4], #8
 c0c:	f8657880 	ldr	x0, [x4, x5, lsl #3]
 c10:	f8008c80 	str	x0, [x4, #8]!
 c14:	f8008480 	str	x0, [x4], #8
 c18:	f8257880 	str	x0, [x4, x5, lsl #3]
 c1c:	39802080 	ldrsb	x0, [x4, #8]
 c20:	79801080 	ldrsh	x0, [x4, #8]
 c24:	93407c20 	sxtw	x0, w1
 c28:	9bc27c20 	umulh	x0, x1, x2
 c2c:	9ba27c20 	umull	x0, w1, w2
 c30:	9ba20c20 	umaddl	x0, w1, w2, x3
 c34:	9b220c20 	smaddl	x0, w1, w2, x3
 c38:	b9800880 	ldrsw	x0, [x4, #8]
 c3c:	a9408480 	ldp	x0, x1, [x4, #8]
 c40:	a9008480 	stp	x0, x1, [x4, #8]
 c44:	9e670000 	fmov	d0, x0
 c48:	9e660000 	fmov	x0, d0
 c4c:	1e270000 	fmov	s0, w0
 c50:	1e260000 	fmov	w0, s0
 c54:	0e205800 	cnt	v0.8b, v0.8b
 c58:	4e205800 	cnt	v0.16b, v0.16b
 c5c:	2e303800 	uaddlv	h0, v0.8b
 c60:	6e303800 	uaddlv	h0, v0.16b
 c64:	3dc00480 	ldr	q0, [x4, #16]
 c68:	3d800480 	str	q0, [x4, #16]
 c6c:	fd400480 	ldr	d0, [x4, #8]
 c70:	fd000480 	str	d0, [x4, #8]
 c74:	fc408080 	ldur	d0, [x4, #8]
 c78:	fc008080 	stur	d0, [x4, #8]
 c7c:	fc408c80 	ldr	d0, [x4, #8]!
 c80:	fc408480 	ldr	d0, [x4], #8
 c84:	fc657880 	ldr	d0, [x4, x5, lsl #3]
 c88:	fc008c80 	str	d0, [x4, #8]!
 c8c:	fc008480 	str	d0, [x4], #8
 c90:	fc257880 	str	d0, [x4, x5, lsl #3]
 c94:	3cc10080 	ldur	q0, [x4, #16]
 c98:	3c810080 	stur	q0, [x4, #16]
