from pathlib import Path
import subprocess,hashlib,tarfile,json,datetime,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-load-width'
S=F/'x86-load-width'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
try:
 S.with_suffix('.state').write_text('running\n')
 pin='c0b8e9cfaf9298c565c5f35a9ae8f8f25ceec307'
 header='kprog/formal/generated/x86_mem_access.h'
 assert git('show',pin+':'+header)==(R/header).read_bytes()
 pins={header:sha(R/header)}
 for variant,rev in [('before',pin+'^'),('current',pin)]:
  d=O/variant;d.mkdir();(d/'x86_mem_access.h').write_bytes(git('show',rev+':'+header))
 src=[p for p in (R/'vendor/llvmbpf').rglob('*') if p.is_file() and p.suffix in ['.h','.hpp','.cpp']]
 objs=list((R/'runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src').glob('*.o'))
 assert len(objs)==4
 inputs=list(O.glob('*.c'))+list(O.glob('*.cpp'))+list(O.glob('*.h'))+list(O.glob('*.py'))+[O/'Makefile']+list(O.glob('*/x86_mem_access.h'))+src+objs
 manifest={str(p.relative_to(R)):sha(p) for p in inputs}
 (O/'launch.json').write_text(json.dumps(dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),production_commit=pin,head=git('rev-parse','HEAD').decode().strip(),pins=pins,inputs=manifest),indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as t:
  for p in inputs:
   if p not in objs:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
  t.add(__file__,arcname='lane-F/x86-load-width.py')
 with (O/'run.log').open('w') as f:
  rc=subprocess.run(['taskset','-c','16-19','make','-f',str(O/'Makefile'),'check'],cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 drift={p:dict(before=h,after=sha(R/p)) for p,h in manifest.items() if sha(R/p)!=h}
 (O/'status.json').write_text(json.dumps(dict(exit=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_drift=drift),indent=2)+'\n')
 S.with_suffix('.exit').write_text(str(rc)+'\n');S.with_suffix('.state').write_text('closed_needs_review\n')
except BaseException:
 S.with_suffix('.error').write_text(traceback.format_exc());S.with_suffix('.exit').write_text('1\n');S.with_suffix('.state').write_text('failed_preserved\n');raise
