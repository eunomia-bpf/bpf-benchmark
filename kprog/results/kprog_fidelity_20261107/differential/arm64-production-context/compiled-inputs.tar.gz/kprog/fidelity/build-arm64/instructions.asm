
build-arm64/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	d503201f 	nop
   4:	0b020020 	add	w0, w1, w2
   8:	0b020c20 	add	w0, w1, w2, lsl #3
   c:	1101fc20 	add	w0, w1, #0x7f
  10:	4b020020 	sub	w0, w1, w2
  14:	4b020c20 	sub	w0, w1, w2, lsl #3
  18:	5101fc20 	sub	w0, w1, #0x7f
  1c:	0a020020 	and	w0, w1, w2
  20:	0a020c20 	and	w0, w1, w2, lsl #3
  24:	0a220020 	bic	w0, w1, w2
  28:	0a220c20 	bic	w0, w1, w2, lsl #3
  2c:	4a020020 	eor	w0, w1, w2
  30:	4a020c20 	eor	w0, w1, w2, lsl #3
  34:	2a020020 	orr	w0, w1, w2
  38:	2a020c20 	orr	w0, w1, w2, lsl #3
  3c:	2a220020 	orn	w0, w1, w2
  40:	2a220c20 	orn	w0, w1, w2, lsl #3
  44:	2b020020 	adds	w0, w1, w2
  48:	2b020c20 	adds	w0, w1, w2, lsl #3
  4c:	3101fc20 	adds	w0, w1, #0x7f
  50:	6b020020 	subs	w0, w1, w2
  54:	6b020c20 	subs	w0, w1, w2, lsl #3
  58:	7101fc20 	subs	w0, w1, #0x7f
  5c:	6a020020 	ands	w0, w1, w2
  60:	6a020c20 	ands	w0, w1, w2, lsl #3
  64:	6a220020 	bics	w0, w1, w2
  68:	6a220c20 	bics	w0, w1, w2, lsl #3
  6c:	6b02003f 	cmp	w1, w2
  70:	6b020c3f 	cmp	w1, w2, lsl #3
  74:	2b02003f 	cmn	w1, w2
  78:	2b020c3f 	cmn	w1, w2, lsl #3
  7c:	6a02003f 	tst	w1, w2
  80:	6a020c3f 	tst	w1, w2, lsl #3
  84:	12000020 	and	w0, w1, #0x1
  88:	12000000 	and	w0, w0, #0x1
  8c:	120003e0 	and	w0, wzr, #0x1
  90:	1200003f 	and	wsp, w1, #0x1
  94:	32000020 	orr	w0, w1, #0x1
  98:	32000000 	orr	w0, w0, #0x1
  9c:	320003e0 	orr	w0, wzr, #0x1
  a0:	3200003f 	orr	wsp, w1, #0x1
  a4:	52000020 	eor	w0, w1, #0x1
  a8:	52000000 	eor	w0, w0, #0x1
  ac:	520003e0 	eor	w0, wzr, #0x1
  b0:	5200003f 	eor	wsp, w1, #0x1
  b4:	72000020 	ands	w0, w1, #0x1
  b8:	72000000 	ands	w0, w0, #0x1
  bc:	720003e0 	ands	w0, wzr, #0x1
  c0:	7200003f 	tst	w1, #0x1
  c4:	720003ff 	tst	wzr, #0x1
  c8:	12001c20 	and	w0, w1, #0xff
  cc:	12001c00 	and	w0, w0, #0xff
  d0:	12001fe0 	and	w0, wzr, #0xff
  d4:	12001c3f 	and	wsp, w1, #0xff
  d8:	32001c20 	orr	w0, w1, #0xff
  dc:	32001c00 	orr	w0, w0, #0xff
  e0:	32001fe0 	orr	w0, wzr, #0xff
  e4:	32001c3f 	orr	wsp, w1, #0xff
  e8:	52001c20 	eor	w0, w1, #0xff
  ec:	52001c00 	eor	w0, w0, #0xff
  f0:	52001fe0 	eor	w0, wzr, #0xff
  f4:	52001c3f 	eor	wsp, w1, #0xff
  f8:	72001c20 	ands	w0, w1, #0xff
  fc:	72001c00 	ands	w0, w0, #0xff
 100:	72001fe0 	ands	w0, wzr, #0xff
 104:	72001c3f 	tst	w1, #0xff
 108:	72001fff 	tst	wzr, #0xff
 10c:	12010020 	and	w0, w1, #0x80000000
 110:	12010000 	and	w0, w0, #0x80000000
 114:	120103e0 	and	w0, wzr, #0x80000000
 118:	1201003f 	and	wsp, w1, #0x80000000
 11c:	32010020 	orr	w0, w1, #0x80000000
 120:	32010000 	orr	w0, w0, #0x80000000
 124:	320103e0 	orr	w0, wzr, #0x80000000
 128:	3201003f 	orr	wsp, w1, #0x80000000
 12c:	52010020 	eor	w0, w1, #0x80000000
 130:	52010000 	eor	w0, w0, #0x80000000
 134:	520103e0 	eor	w0, wzr, #0x80000000
 138:	5201003f 	eor	wsp, w1, #0x80000000
 13c:	72010020 	ands	w0, w1, #0x80000000
 140:	72010000 	ands	w0, w0, #0x80000000
 144:	720103e0 	ands	w0, wzr, #0x80000000
 148:	7201003f 	tst	w1, #0x80000000
 14c:	720103ff 	tst	wzr, #0x80000000
 150:	12003c20 	and	w0, w1, #0xffff
 154:	12003c00 	and	w0, w0, #0xffff
 158:	12003fe0 	and	w0, wzr, #0xffff
 15c:	12003c3f 	and	wsp, w1, #0xffff
 160:	32003c20 	orr	w0, w1, #0xffff
 164:	32003c00 	orr	w0, w0, #0xffff
 168:	32003fe0 	orr	w0, wzr, #0xffff
 16c:	32003c3f 	orr	wsp, w1, #0xffff
 170:	52003c20 	eor	w0, w1, #0xffff
 174:	52003c00 	eor	w0, w0, #0xffff
 178:	52003fe0 	eor	w0, wzr, #0xffff
 17c:	52003c3f 	eor	wsp, w1, #0xffff
 180:	72003c20 	ands	w0, w1, #0xffff
 184:	72003c00 	ands	w0, w0, #0xffff
 188:	72003fe0 	ands	w0, wzr, #0xffff
 18c:	72003c3f 	tst	w1, #0xffff
 190:	72003fff 	tst	wzr, #0xffff
 194:	12009c20 	and	w0, w1, #0xff00ff
 198:	12009c00 	and	w0, w0, #0xff00ff
 19c:	12009fe0 	and	w0, wzr, #0xff00ff
 1a0:	12009c3f 	and	wsp, w1, #0xff00ff
 1a4:	32009c20 	orr	w0, w1, #0xff00ff
 1a8:	32009c00 	orr	w0, w0, #0xff00ff
 1ac:	32009fe0 	mov	w0, #0xff00ff              	// #16711935
 1b0:	32009c3f 	orr	wsp, w1, #0xff00ff
 1b4:	52009c20 	eor	w0, w1, #0xff00ff
 1b8:	52009c00 	eor	w0, w0, #0xff00ff
 1bc:	52009fe0 	eor	w0, wzr, #0xff00ff
 1c0:	52009c3f 	eor	wsp, w1, #0xff00ff
 1c4:	72009c20 	ands	w0, w1, #0xff00ff
 1c8:	72009c00 	ands	w0, w0, #0xff00ff
 1cc:	72009fe0 	ands	w0, wzr, #0xff00ff
 1d0:	72009c3f 	tst	w1, #0xff00ff
 1d4:	72009fff 	tst	wzr, #0xff00ff
 1d8:	1201f020 	and	w0, w1, #0xaaaaaaaa
 1dc:	1201f000 	and	w0, w0, #0xaaaaaaaa
 1e0:	1201f3e0 	and	w0, wzr, #0xaaaaaaaa
 1e4:	1201f03f 	and	wsp, w1, #0xaaaaaaaa
 1e8:	3201f020 	orr	w0, w1, #0xaaaaaaaa
 1ec:	3201f000 	orr	w0, w0, #0xaaaaaaaa
 1f0:	3201f3e0 	mov	w0, #0xaaaaaaaa            	// #-1431655766
 1f4:	3201f03f 	orr	wsp, w1, #0xaaaaaaaa
 1f8:	5201f020 	eor	w0, w1, #0xaaaaaaaa
 1fc:	5201f000 	eor	w0, w0, #0xaaaaaaaa
 200:	5201f3e0 	eor	w0, wzr, #0xaaaaaaaa
 204:	5201f03f 	eor	wsp, w1, #0xaaaaaaaa
 208:	7201f020 	ands	w0, w1, #0xaaaaaaaa
 20c:	7201f000 	ands	w0, w0, #0xaaaaaaaa
 210:	7201f3e0 	ands	w0, wzr, #0xaaaaaaaa
 214:	7201f03f 	tst	w1, #0xaaaaaaaa
 218:	7201f3ff 	tst	wzr, #0xaaaaaaaa
 21c:	2a0103e0 	mov	w0, w1
 220:	52800fe0 	mov	w0, #0x7f                  	// #127
 224:	72bbd5a0 	movk	w0, #0xdead, lsl #16
 228:	110003e0 	mov	w0, wsp
 22c:	1100001f 	mov	wsp, w0
 230:	2a2103e0 	mvn	w0, w1
 234:	4b0103e0 	neg	w0, w1
 238:	5ac00820 	rev	w0, w1
 23c:	5ac00420 	rev16	w0, w1
 240:	13001c20 	sxtb	w0, w1
 244:	13003c20 	sxth	w0, w1
 248:	2a2103e0 	mvn	w0, w1
 24c:	2a2107e0 	mvn	w0, w1, lsl #1
 250:	2a217fe0 	mvn	w0, w1, lsl #31
 254:	2a6103e0 	mvn	w0, w1, lsr #0
 258:	2a6107e0 	mvn	w0, w1, lsr #1
 25c:	2a617fe0 	mvn	w0, w1, lsr #31
 260:	2aa103e0 	mvn	w0, w1, asr #0
 264:	2aa107e0 	mvn	w0, w1, asr #1
 268:	2aa17fe0 	mvn	w0, w1, asr #31
 26c:	2ae103e0 	mvn	w0, w1, ror #0
 270:	2ae107e0 	mvn	w0, w1, ror #1
 274:	2ae17fe0 	mvn	w0, w1, ror #31
 278:	4b0103e0 	neg	w0, w1
 27c:	4b0107e0 	neg	w0, w1, lsl #1
 280:	4b017fe0 	neg	w0, w1, lsl #31
 284:	4b4103e0 	neg	w0, w1, lsr #0
 288:	4b4107e0 	neg	w0, w1, lsr #1
 28c:	4b417fe0 	neg	w0, w1, lsr #31
 290:	4b8103e0 	neg	w0, w1, asr #0
 294:	4b8107e0 	neg	w0, w1, asr #1
 298:	4b817fe0 	neg	w0, w1, asr #31
 29c:	1b027c20 	mul	w0, w1, w2
 2a0:	1ac20820 	udiv	w0, w1, w2
 2a4:	1b020c20 	madd	w0, w1, w2, w3
 2a8:	1b028c20 	msub	w0, w1, w2, w3
 2ac:	1ac22020 	lsl	w0, w1, w2
 2b0:	53007c20 	lsr	w0, w1, #0
 2b4:	531f7820 	lsl	w0, w1, #1
 2b8:	53196020 	lsl	w0, w1, #7
 2bc:	53010020 	lsl	w0, w1, #31
 2c0:	1ac22420 	lsr	w0, w1, w2
 2c4:	53007c20 	lsr	w0, w1, #0
 2c8:	53017c20 	lsr	w0, w1, #1
 2cc:	53077c20 	lsr	w0, w1, #7
 2d0:	531f7c20 	lsr	w0, w1, #31
 2d4:	1ac22820 	asr	w0, w1, w2
 2d8:	13007c20 	asr	w0, w1, #0
 2dc:	13017c20 	asr	w0, w1, #1
 2e0:	13077c20 	asr	w0, w1, #7
 2e4:	131f7c20 	asr	w0, w1, #31
 2e8:	1ac22c20 	ror	w0, w1, w2
 2ec:	13810020 	ror	w0, w1, #0
 2f0:	13810420 	ror	w0, w1, #1
 2f4:	13811c20 	ror	w0, w1, #7
 2f8:	13817c20 	ror	w0, w1, #31
 2fc:	13821c20 	extr	w0, w1, w2, #7
 300:	53074c20 	ubfx	w0, w1, #7, #13
 304:	13074c20 	sbfx	w0, w1, #7, #13
 308:	53193020 	ubfiz	w0, w1, #7, #13
 30c:	33074c20 	bfxil	w0, w1, #7, #13
 310:	33193020 	bfi	w0, w1, #7, #13
 314:	1a820020 	csel	w0, w1, w2, eq	// eq = none
 318:	1a820420 	csinc	w0, w1, w2, eq	// eq = none
 31c:	5a820020 	csinv	w0, w1, w2, eq	// eq = none
 320:	5a820420 	csneg	w0, w1, w2, eq	// eq = none
 324:	1a811420 	cinc	w0, w1, eq	// eq = none
 328:	5a811020 	cinv	w0, w1, eq	// eq = none
 32c:	5a811420 	cneg	w0, w1, eq	// eq = none
 330:	1a9f17e0 	cset	w0, eq	// eq = none
 334:	5a9f13e0 	csetm	w0, eq	// eq = none
 338:	7a420025 	ccmp	w1, w2, #0x5, eq	// eq = none
 33c:	7a47082a 	ccmp	w1, #0x7, #0xa, eq	// eq = none
 340:	1a821020 	csel	w0, w1, w2, ne	// ne = any
 344:	1a821420 	csinc	w0, w1, w2, ne	// ne = any
 348:	5a821020 	csinv	w0, w1, w2, ne	// ne = any
 34c:	5a821420 	csneg	w0, w1, w2, ne	// ne = any
 350:	1a810420 	cinc	w0, w1, ne	// ne = any
 354:	5a810020 	cinv	w0, w1, ne	// ne = any
 358:	5a810420 	cneg	w0, w1, ne	// ne = any
 35c:	1a9f07e0 	cset	w0, ne	// ne = any
 360:	5a9f03e0 	csetm	w0, ne	// ne = any
 364:	7a421025 	ccmp	w1, w2, #0x5, ne	// ne = any
 368:	7a47182a 	ccmp	w1, #0x7, #0xa, ne	// ne = any
 36c:	1a822020 	csel	w0, w1, w2, cs	// cs = hs, nlast
 370:	1a822420 	csinc	w0, w1, w2, cs	// cs = hs, nlast
 374:	5a822020 	csinv	w0, w1, w2, cs	// cs = hs, nlast
 378:	5a822420 	csneg	w0, w1, w2, cs	// cs = hs, nlast
 37c:	1a813420 	cinc	w0, w1, cs	// cs = hs, nlast
 380:	5a813020 	cinv	w0, w1, cs	// cs = hs, nlast
 384:	5a813420 	cneg	w0, w1, cs	// cs = hs, nlast
 388:	1a9f37e0 	cset	w0, cs	// cs = hs, nlast
 38c:	5a9f33e0 	csetm	w0, cs	// cs = hs, nlast
 390:	7a422025 	ccmp	w1, w2, #0x5, cs	// cs = hs, nlast
 394:	7a47282a 	ccmp	w1, #0x7, #0xa, cs	// cs = hs, nlast
 398:	1a823020 	csel	w0, w1, w2, cc	// cc = lo, ul, last
 39c:	1a823420 	csinc	w0, w1, w2, cc	// cc = lo, ul, last
 3a0:	5a823020 	csinv	w0, w1, w2, cc	// cc = lo, ul, last
 3a4:	5a823420 	csneg	w0, w1, w2, cc	// cc = lo, ul, last
 3a8:	1a812420 	cinc	w0, w1, cc	// cc = lo, ul, last
 3ac:	5a812020 	cinv	w0, w1, cc	// cc = lo, ul, last
 3b0:	5a812420 	cneg	w0, w1, cc	// cc = lo, ul, last
 3b4:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
 3b8:	5a9f23e0 	csetm	w0, cc	// cc = lo, ul, last
 3bc:	7a423025 	ccmp	w1, w2, #0x5, cc	// cc = lo, ul, last
 3c0:	7a47382a 	ccmp	w1, #0x7, #0xa, cc	// cc = lo, ul, last
 3c4:	1a824020 	csel	w0, w1, w2, mi	// mi = first
 3c8:	1a824420 	csinc	w0, w1, w2, mi	// mi = first
 3cc:	5a824020 	csinv	w0, w1, w2, mi	// mi = first
 3d0:	5a824420 	csneg	w0, w1, w2, mi	// mi = first
 3d4:	1a815420 	cinc	w0, w1, mi	// mi = first
 3d8:	5a815020 	cinv	w0, w1, mi	// mi = first
 3dc:	5a815420 	cneg	w0, w1, mi	// mi = first
 3e0:	1a9f57e0 	cset	w0, mi	// mi = first
 3e4:	5a9f53e0 	csetm	w0, mi	// mi = first
 3e8:	7a424025 	ccmp	w1, w2, #0x5, mi	// mi = first
 3ec:	7a47482a 	ccmp	w1, #0x7, #0xa, mi	// mi = first
 3f0:	1a825020 	csel	w0, w1, w2, pl	// pl = nfrst
 3f4:	1a825420 	csinc	w0, w1, w2, pl	// pl = nfrst
 3f8:	5a825020 	csinv	w0, w1, w2, pl	// pl = nfrst
 3fc:	5a825420 	csneg	w0, w1, w2, pl	// pl = nfrst
 400:	1a814420 	cinc	w0, w1, pl	// pl = nfrst
 404:	5a814020 	cinv	w0, w1, pl	// pl = nfrst
 408:	5a814420 	cneg	w0, w1, pl	// pl = nfrst
 40c:	1a9f47e0 	cset	w0, pl	// pl = nfrst
 410:	5a9f43e0 	csetm	w0, pl	// pl = nfrst
 414:	7a425025 	ccmp	w1, w2, #0x5, pl	// pl = nfrst
 418:	7a47582a 	ccmp	w1, #0x7, #0xa, pl	// pl = nfrst
 41c:	1a826020 	csel	w0, w1, w2, vs
 420:	1a826420 	csinc	w0, w1, w2, vs
 424:	5a826020 	csinv	w0, w1, w2, vs
 428:	5a826420 	csneg	w0, w1, w2, vs
 42c:	1a817420 	cinc	w0, w1, vs
 430:	5a817020 	cinv	w0, w1, vs
 434:	5a817420 	cneg	w0, w1, vs
 438:	1a9f77e0 	cset	w0, vs
 43c:	5a9f73e0 	csetm	w0, vs
 440:	7a426025 	ccmp	w1, w2, #0x5, vs
 444:	7a47682a 	ccmp	w1, #0x7, #0xa, vs
 448:	1a827020 	csel	w0, w1, w2, vc
 44c:	1a827420 	csinc	w0, w1, w2, vc
 450:	5a827020 	csinv	w0, w1, w2, vc
 454:	5a827420 	csneg	w0, w1, w2, vc
 458:	1a816420 	cinc	w0, w1, vc
 45c:	5a816020 	cinv	w0, w1, vc
 460:	5a816420 	cneg	w0, w1, vc
 464:	1a9f67e0 	cset	w0, vc
 468:	5a9f63e0 	csetm	w0, vc
 46c:	7a427025 	ccmp	w1, w2, #0x5, vc
 470:	7a47782a 	ccmp	w1, #0x7, #0xa, vc
 474:	1a828020 	csel	w0, w1, w2, hi	// hi = pmore
 478:	1a828420 	csinc	w0, w1, w2, hi	// hi = pmore
 47c:	5a828020 	csinv	w0, w1, w2, hi	// hi = pmore
 480:	5a828420 	csneg	w0, w1, w2, hi	// hi = pmore
 484:	1a819420 	cinc	w0, w1, hi	// hi = pmore
 488:	5a819020 	cinv	w0, w1, hi	// hi = pmore
 48c:	5a819420 	cneg	w0, w1, hi	// hi = pmore
 490:	1a9f97e0 	cset	w0, hi	// hi = pmore
 494:	5a9f93e0 	csetm	w0, hi	// hi = pmore
 498:	7a428025 	ccmp	w1, w2, #0x5, hi	// hi = pmore
 49c:	7a47882a 	ccmp	w1, #0x7, #0xa, hi	// hi = pmore
 4a0:	1a829020 	csel	w0, w1, w2, ls	// ls = plast
 4a4:	1a829420 	csinc	w0, w1, w2, ls	// ls = plast
 4a8:	5a829020 	csinv	w0, w1, w2, ls	// ls = plast
 4ac:	5a829420 	csneg	w0, w1, w2, ls	// ls = plast
 4b0:	1a818420 	cinc	w0, w1, ls	// ls = plast
 4b4:	5a818020 	cinv	w0, w1, ls	// ls = plast
 4b8:	5a818420 	cneg	w0, w1, ls	// ls = plast
 4bc:	1a9f87e0 	cset	w0, ls	// ls = plast
 4c0:	5a9f83e0 	csetm	w0, ls	// ls = plast
 4c4:	7a429025 	ccmp	w1, w2, #0x5, ls	// ls = plast
 4c8:	7a47982a 	ccmp	w1, #0x7, #0xa, ls	// ls = plast
 4cc:	1a82a020 	csel	w0, w1, w2, ge	// ge = tcont
 4d0:	1a82a420 	csinc	w0, w1, w2, ge	// ge = tcont
 4d4:	5a82a020 	csinv	w0, w1, w2, ge	// ge = tcont
 4d8:	5a82a420 	csneg	w0, w1, w2, ge	// ge = tcont
 4dc:	1a81b420 	cinc	w0, w1, ge	// ge = tcont
 4e0:	5a81b020 	cinv	w0, w1, ge	// ge = tcont
 4e4:	5a81b420 	cneg	w0, w1, ge	// ge = tcont
 4e8:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 4ec:	5a9fb3e0 	csetm	w0, ge	// ge = tcont
 4f0:	7a42a025 	ccmp	w1, w2, #0x5, ge	// ge = tcont
 4f4:	7a47a82a 	ccmp	w1, #0x7, #0xa, ge	// ge = tcont
 4f8:	1a82b020 	csel	w0, w1, w2, lt	// lt = tstop
 4fc:	1a82b420 	csinc	w0, w1, w2, lt	// lt = tstop
 500:	5a82b020 	csinv	w0, w1, w2, lt	// lt = tstop
 504:	5a82b420 	csneg	w0, w1, w2, lt	// lt = tstop
 508:	1a81a420 	cinc	w0, w1, lt	// lt = tstop
 50c:	5a81a020 	cinv	w0, w1, lt	// lt = tstop
 510:	5a81a420 	cneg	w0, w1, lt	// lt = tstop
 514:	1a9fa7e0 	cset	w0, lt	// lt = tstop
 518:	5a9fa3e0 	csetm	w0, lt	// lt = tstop
 51c:	7a42b025 	ccmp	w1, w2, #0x5, lt	// lt = tstop
 520:	7a47b82a 	ccmp	w1, #0x7, #0xa, lt	// lt = tstop
 524:	1a82c020 	csel	w0, w1, w2, gt
 528:	1a82c420 	csinc	w0, w1, w2, gt
 52c:	5a82c020 	csinv	w0, w1, w2, gt
 530:	5a82c420 	csneg	w0, w1, w2, gt
 534:	1a81d420 	cinc	w0, w1, gt
 538:	5a81d020 	cinv	w0, w1, gt
 53c:	5a81d420 	cneg	w0, w1, gt
 540:	1a9fd7e0 	cset	w0, gt
 544:	5a9fd3e0 	csetm	w0, gt
 548:	7a42c025 	ccmp	w1, w2, #0x5, gt
 54c:	7a47c82a 	ccmp	w1, #0x7, #0xa, gt
 550:	1a82d020 	csel	w0, w1, w2, le
 554:	1a82d420 	csinc	w0, w1, w2, le
 558:	5a82d020 	csinv	w0, w1, w2, le
 55c:	5a82d420 	csneg	w0, w1, w2, le
 560:	1a81c420 	cinc	w0, w1, le
 564:	5a81c020 	cinv	w0, w1, le
 568:	5a81c420 	cneg	w0, w1, le
 56c:	1a9fc7e0 	cset	w0, le
 570:	5a9fc3e0 	csetm	w0, le
 574:	7a42d025 	ccmp	w1, w2, #0x5, le
 578:	7a47d82a 	ccmp	w1, #0x7, #0xa, le
 57c:	1a82e020 	csel	w0, w1, w2, al
 580:	1a82e420 	csinc	w0, w1, w2, al
 584:	5a82e020 	csinv	w0, w1, w2, al
 588:	5a82e420 	csneg	w0, w1, w2, al
 58c:	7a42e025 	ccmp	w1, w2, #0x5, al
 590:	7a47e82a 	ccmp	w1, #0x7, #0xa, al
 594:	1a82f020 	csel	w0, w1, w2, nv
 598:	1a82f420 	csinc	w0, w1, w2, nv
 59c:	5a82f020 	csinv	w0, w1, w2, nv
 5a0:	5a82f420 	csneg	w0, w1, w2, nv
 5a4:	7a42f025 	ccmp	w1, w2, #0x5, nv
 5a8:	7a47f82a 	ccmp	w1, #0x7, #0xa, nv
 5ac:	b9400880 	ldr	w0, [x4, #8]
 5b0:	b9000880 	str	w0, [x4, #8]
 5b4:	b8408080 	ldur	w0, [x4, #8]
 5b8:	b8008080 	stur	w0, [x4, #8]
 5bc:	b8408c80 	ldr	w0, [x4, #8]!
 5c0:	b8408480 	ldr	w0, [x4], #8
 5c4:	b8657880 	ldr	w0, [x4, x5, lsl #2]
 5c8:	b8008c80 	str	w0, [x4, #8]!
 5cc:	b8008480 	str	w0, [x4], #8
 5d0:	b8257880 	str	w0, [x4, x5, lsl #2]
 5d4:	39402080 	ldrb	w0, [x4, #8]
 5d8:	79401080 	ldrh	w0, [x4, #8]
 5dc:	39002080 	strb	w0, [x4, #8]
 5e0:	79001080 	strh	w0, [x4, #8]
 5e4:	39c02080 	ldrsb	w0, [x4, #8]
 5e8:	79c01080 	ldrsh	w0, [x4, #8]
 5ec:	8b020020 	add	x0, x1, x2
 5f0:	8b020c20 	add	x0, x1, x2, lsl #3
 5f4:	9101fc20 	add	x0, x1, #0x7f
 5f8:	cb020020 	sub	x0, x1, x2
 5fc:	cb020c20 	sub	x0, x1, x2, lsl #3
 600:	d101fc20 	sub	x0, x1, #0x7f
 604:	8a020020 	and	x0, x1, x2
 608:	8a020c20 	and	x0, x1, x2, lsl #3
 60c:	8a220020 	bic	x0, x1, x2
 610:	8a220c20 	bic	x0, x1, x2, lsl #3
 614:	ca020020 	eor	x0, x1, x2
 618:	ca020c20 	eor	x0, x1, x2, lsl #3
 61c:	aa020020 	orr	x0, x1, x2
 620:	aa020c20 	orr	x0, x1, x2, lsl #3
 624:	aa220020 	orn	x0, x1, x2
 628:	aa220c20 	orn	x0, x1, x2, lsl #3
 62c:	ab020020 	adds	x0, x1, x2
 630:	ab020c20 	adds	x0, x1, x2, lsl #3
 634:	b101fc20 	adds	x0, x1, #0x7f
 638:	eb020020 	subs	x0, x1, x2
 63c:	eb020c20 	subs	x0, x1, x2, lsl #3
 640:	f101fc20 	subs	x0, x1, #0x7f
 644:	ea020020 	ands	x0, x1, x2
 648:	ea020c20 	ands	x0, x1, x2, lsl #3
 64c:	ea220020 	bics	x0, x1, x2
 650:	ea220c20 	bics	x0, x1, x2, lsl #3
 654:	eb02003f 	cmp	x1, x2
 658:	eb020c3f 	cmp	x1, x2, lsl #3
 65c:	ab02003f 	cmn	x1, x2
 660:	ab020c3f 	cmn	x1, x2, lsl #3
 664:	ea02003f 	tst	x1, x2
 668:	ea020c3f 	tst	x1, x2, lsl #3
 66c:	92400020 	and	x0, x1, #0x1
 670:	92400000 	and	x0, x0, #0x1
 674:	924003e0 	and	x0, xzr, #0x1
 678:	9240003f 	and	sp, x1, #0x1
 67c:	b2400020 	orr	x0, x1, #0x1
 680:	b2400000 	orr	x0, x0, #0x1
 684:	b24003e0 	orr	x0, xzr, #0x1
 688:	b240003f 	orr	sp, x1, #0x1
 68c:	d2400020 	eor	x0, x1, #0x1
 690:	d2400000 	eor	x0, x0, #0x1
 694:	d24003e0 	eor	x0, xzr, #0x1
 698:	d240003f 	eor	sp, x1, #0x1
 69c:	f2400020 	ands	x0, x1, #0x1
 6a0:	f2400000 	ands	x0, x0, #0x1
 6a4:	f24003e0 	ands	x0, xzr, #0x1
 6a8:	f240003f 	tst	x1, #0x1
 6ac:	f24003ff 	tst	xzr, #0x1
 6b0:	92401c20 	and	x0, x1, #0xff
 6b4:	92401c00 	and	x0, x0, #0xff
 6b8:	92401fe0 	and	x0, xzr, #0xff
 6bc:	92401c3f 	and	sp, x1, #0xff
 6c0:	b2401c20 	orr	x0, x1, #0xff
 6c4:	b2401c00 	orr	x0, x0, #0xff
 6c8:	b2401fe0 	orr	x0, xzr, #0xff
 6cc:	b2401c3f 	orr	sp, x1, #0xff
 6d0:	d2401c20 	eor	x0, x1, #0xff
 6d4:	d2401c00 	eor	x0, x0, #0xff
 6d8:	d2401fe0 	eor	x0, xzr, #0xff
 6dc:	d2401c3f 	eor	sp, x1, #0xff
 6e0:	f2401c20 	ands	x0, x1, #0xff
 6e4:	f2401c00 	ands	x0, x0, #0xff
 6e8:	f2401fe0 	ands	x0, xzr, #0xff
 6ec:	f2401c3f 	tst	x1, #0xff
 6f0:	f2401fff 	tst	xzr, #0xff
 6f4:	92410020 	and	x0, x1, #0x8000000000000000
 6f8:	92410000 	and	x0, x0, #0x8000000000000000
 6fc:	924103e0 	and	x0, xzr, #0x8000000000000000
 700:	9241003f 	and	sp, x1, #0x8000000000000000
 704:	b2410020 	orr	x0, x1, #0x8000000000000000
 708:	b2410000 	orr	x0, x0, #0x8000000000000000
 70c:	b24103e0 	orr	x0, xzr, #0x8000000000000000
 710:	b241003f 	orr	sp, x1, #0x8000000000000000
 714:	d2410020 	eor	x0, x1, #0x8000000000000000
 718:	d2410000 	eor	x0, x0, #0x8000000000000000
 71c:	d24103e0 	eor	x0, xzr, #0x8000000000000000
 720:	d241003f 	eor	sp, x1, #0x8000000000000000
 724:	f2410020 	ands	x0, x1, #0x8000000000000000
 728:	f2410000 	ands	x0, x0, #0x8000000000000000
 72c:	f24103e0 	ands	x0, xzr, #0x8000000000000000
 730:	f241003f 	tst	x1, #0x8000000000000000
 734:	f24103ff 	tst	xzr, #0x8000000000000000
 738:	92407c20 	and	x0, x1, #0xffffffff
 73c:	92407c00 	and	x0, x0, #0xffffffff
 740:	92407fe0 	and	x0, xzr, #0xffffffff
 744:	92407c3f 	and	sp, x1, #0xffffffff
 748:	b2407c20 	orr	x0, x1, #0xffffffff
 74c:	b2407c00 	orr	x0, x0, #0xffffffff
 750:	b2407fe0 	mov	x0, #0xffffffff            	// #4294967295
 754:	b2407c3f 	orr	sp, x1, #0xffffffff
 758:	d2407c20 	eor	x0, x1, #0xffffffff
 75c:	d2407c00 	eor	x0, x0, #0xffffffff
 760:	d2407fe0 	eor	x0, xzr, #0xffffffff
 764:	d2407c3f 	eor	sp, x1, #0xffffffff
 768:	f2407c20 	ands	x0, x1, #0xffffffff
 76c:	f2407c00 	ands	x0, x0, #0xffffffff
 770:	f2407fe0 	ands	x0, xzr, #0xffffffff
 774:	f2407c3f 	tst	x1, #0xffffffff
 778:	f2407fff 	tst	xzr, #0xffffffff
 77c:	92009c20 	and	x0, x1, #0xff00ff00ff00ff
 780:	92009c00 	and	x0, x0, #0xff00ff00ff00ff
 784:	92009fe0 	and	x0, xzr, #0xff00ff00ff00ff
 788:	92009c3f 	and	sp, x1, #0xff00ff00ff00ff
 78c:	b2009c20 	orr	x0, x1, #0xff00ff00ff00ff
 790:	b2009c00 	orr	x0, x0, #0xff00ff00ff00ff
 794:	b2009fe0 	mov	x0, #0xff00ff00ff00ff      	// #71777214294589695
 798:	b2009c3f 	orr	sp, x1, #0xff00ff00ff00ff
 79c:	d2009c20 	eor	x0, x1, #0xff00ff00ff00ff
 7a0:	d2009c00 	eor	x0, x0, #0xff00ff00ff00ff
 7a4:	d2009fe0 	eor	x0, xzr, #0xff00ff00ff00ff
 7a8:	d2009c3f 	eor	sp, x1, #0xff00ff00ff00ff
 7ac:	f2009c20 	ands	x0, x1, #0xff00ff00ff00ff
 7b0:	f2009c00 	ands	x0, x0, #0xff00ff00ff00ff
 7b4:	f2009fe0 	ands	x0, xzr, #0xff00ff00ff00ff
 7b8:	f2009c3f 	tst	x1, #0xff00ff00ff00ff
 7bc:	f2009fff 	tst	xzr, #0xff00ff00ff00ff
 7c0:	9201f020 	and	x0, x1, #0xaaaaaaaaaaaaaaaa
 7c4:	9201f000 	and	x0, x0, #0xaaaaaaaaaaaaaaaa
 7c8:	9201f3e0 	and	x0, xzr, #0xaaaaaaaaaaaaaaaa
 7cc:	9201f03f 	and	sp, x1, #0xaaaaaaaaaaaaaaaa
 7d0:	b201f020 	orr	x0, x1, #0xaaaaaaaaaaaaaaaa
 7d4:	b201f000 	orr	x0, x0, #0xaaaaaaaaaaaaaaaa
 7d8:	b201f3e0 	mov	x0, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
 7dc:	b201f03f 	orr	sp, x1, #0xaaaaaaaaaaaaaaaa
 7e0:	d201f020 	eor	x0, x1, #0xaaaaaaaaaaaaaaaa
 7e4:	d201f000 	eor	x0, x0, #0xaaaaaaaaaaaaaaaa
 7e8:	d201f3e0 	eor	x0, xzr, #0xaaaaaaaaaaaaaaaa
 7ec:	d201f03f 	eor	sp, x1, #0xaaaaaaaaaaaaaaaa
 7f0:	f201f020 	ands	x0, x1, #0xaaaaaaaaaaaaaaaa
 7f4:	f201f000 	ands	x0, x0, #0xaaaaaaaaaaaaaaaa
 7f8:	f201f3e0 	ands	x0, xzr, #0xaaaaaaaaaaaaaaaa
 7fc:	f201f03f 	tst	x1, #0xaaaaaaaaaaaaaaaa
 800:	f201f3ff 	tst	xzr, #0xaaaaaaaaaaaaaaaa
 804:	aa0103e0 	mov	x0, x1
 808:	d2800fe0 	mov	x0, #0x7f                  	// #127
 80c:	f2bbd5a0 	movk	x0, #0xdead, lsl #16
 810:	910003e0 	mov	x0, sp
 814:	9100001f 	mov	sp, x0
 818:	aa2103e0 	mvn	x0, x1
 81c:	cb0103e0 	neg	x0, x1
 820:	dac00c20 	rev	x0, x1
 824:	dac00420 	rev16	x0, x1
 828:	93401c20 	sxtb	x0, w1
 82c:	93403c20 	sxth	x0, w1
 830:	aa2103e0 	mvn	x0, x1
 834:	aa2107e0 	mvn	x0, x1, lsl #1
 838:	aa21ffe0 	mvn	x0, x1, lsl #63
 83c:	aa6103e0 	mvn	x0, x1, lsr #0
 840:	aa6107e0 	mvn	x0, x1, lsr #1
 844:	aa61ffe0 	mvn	x0, x1, lsr #63
 848:	aaa103e0 	mvn	x0, x1, asr #0
 84c:	aaa107e0 	mvn	x0, x1, asr #1
 850:	aaa1ffe0 	mvn	x0, x1, asr #63
 854:	aae103e0 	mvn	x0, x1, ror #0
 858:	aae107e0 	mvn	x0, x1, ror #1
 85c:	aae1ffe0 	mvn	x0, x1, ror #63
 860:	cb0103e0 	neg	x0, x1
 864:	cb0107e0 	neg	x0, x1, lsl #1
 868:	cb01ffe0 	neg	x0, x1, lsl #63
 86c:	cb4103e0 	neg	x0, x1, lsr #0
 870:	cb4107e0 	neg	x0, x1, lsr #1
 874:	cb41ffe0 	neg	x0, x1, lsr #63
 878:	cb8103e0 	neg	x0, x1, asr #0
 87c:	cb8107e0 	neg	x0, x1, asr #1
 880:	cb81ffe0 	neg	x0, x1, asr #63
 884:	9b027c20 	mul	x0, x1, x2
 888:	9ac20820 	udiv	x0, x1, x2
 88c:	9b020c20 	madd	x0, x1, x2, x3
 890:	9b028c20 	msub	x0, x1, x2, x3
 894:	9ac22020 	lsl	x0, x1, x2
 898:	d340fc20 	lsr	x0, x1, #0
 89c:	d37ff820 	lsl	x0, x1, #1
 8a0:	d379e020 	lsl	x0, x1, #7
 8a4:	d3618020 	lsl	x0, x1, #31
 8a8:	9ac22420 	lsr	x0, x1, x2
 8ac:	d340fc20 	lsr	x0, x1, #0
 8b0:	d341fc20 	lsr	x0, x1, #1
 8b4:	d347fc20 	lsr	x0, x1, #7
 8b8:	d35ffc20 	lsr	x0, x1, #31
 8bc:	9ac22820 	asr	x0, x1, x2
 8c0:	9340fc20 	asr	x0, x1, #0
 8c4:	9341fc20 	asr	x0, x1, #1
 8c8:	9347fc20 	asr	x0, x1, #7
 8cc:	935ffc20 	asr	x0, x1, #31
 8d0:	9ac22c20 	ror	x0, x1, x2
 8d4:	93c10020 	ror	x0, x1, #0
 8d8:	93c10420 	ror	x0, x1, #1
 8dc:	93c11c20 	ror	x0, x1, #7
 8e0:	93c17c20 	ror	x0, x1, #31
 8e4:	93c21c20 	extr	x0, x1, x2, #7
 8e8:	d3474c20 	ubfx	x0, x1, #7, #13
 8ec:	93474c20 	sbfx	x0, x1, #7, #13
 8f0:	d3793020 	ubfiz	x0, x1, #7, #13
 8f4:	b3474c20 	bfxil	x0, x1, #7, #13
 8f8:	b3793020 	bfi	x0, x1, #7, #13
 8fc:	9a820020 	csel	x0, x1, x2, eq	// eq = none
 900:	9a820420 	csinc	x0, x1, x2, eq	// eq = none
 904:	da820020 	csinv	x0, x1, x2, eq	// eq = none
 908:	da820420 	csneg	x0, x1, x2, eq	// eq = none
 90c:	9a811420 	cinc	x0, x1, eq	// eq = none
 910:	da811020 	cinv	x0, x1, eq	// eq = none
 914:	da811420 	cneg	x0, x1, eq	// eq = none
 918:	9a9f17e0 	cset	x0, eq	// eq = none
 91c:	da9f13e0 	csetm	x0, eq	// eq = none
 920:	fa420025 	ccmp	x1, x2, #0x5, eq	// eq = none
 924:	fa47082a 	ccmp	x1, #0x7, #0xa, eq	// eq = none
 928:	9a821020 	csel	x0, x1, x2, ne	// ne = any
 92c:	9a821420 	csinc	x0, x1, x2, ne	// ne = any
 930:	da821020 	csinv	x0, x1, x2, ne	// ne = any
 934:	da821420 	csneg	x0, x1, x2, ne	// ne = any
 938:	9a810420 	cinc	x0, x1, ne	// ne = any
 93c:	da810020 	cinv	x0, x1, ne	// ne = any
 940:	da810420 	cneg	x0, x1, ne	// ne = any
 944:	9a9f07e0 	cset	x0, ne	// ne = any
 948:	da9f03e0 	csetm	x0, ne	// ne = any
 94c:	fa421025 	ccmp	x1, x2, #0x5, ne	// ne = any
 950:	fa47182a 	ccmp	x1, #0x7, #0xa, ne	// ne = any
 954:	9a822020 	csel	x0, x1, x2, cs	// cs = hs, nlast
 958:	9a822420 	csinc	x0, x1, x2, cs	// cs = hs, nlast
 95c:	da822020 	csinv	x0, x1, x2, cs	// cs = hs, nlast
 960:	da822420 	csneg	x0, x1, x2, cs	// cs = hs, nlast
 964:	9a813420 	cinc	x0, x1, cs	// cs = hs, nlast
 968:	da813020 	cinv	x0, x1, cs	// cs = hs, nlast
 96c:	da813420 	cneg	x0, x1, cs	// cs = hs, nlast
 970:	9a9f37e0 	cset	x0, cs	// cs = hs, nlast
 974:	da9f33e0 	csetm	x0, cs	// cs = hs, nlast
 978:	fa422025 	ccmp	x1, x2, #0x5, cs	// cs = hs, nlast
 97c:	fa47282a 	ccmp	x1, #0x7, #0xa, cs	// cs = hs, nlast
 980:	9a823020 	csel	x0, x1, x2, cc	// cc = lo, ul, last
 984:	9a823420 	csinc	x0, x1, x2, cc	// cc = lo, ul, last
 988:	da823020 	csinv	x0, x1, x2, cc	// cc = lo, ul, last
 98c:	da823420 	csneg	x0, x1, x2, cc	// cc = lo, ul, last
 990:	9a812420 	cinc	x0, x1, cc	// cc = lo, ul, last
 994:	da812020 	cinv	x0, x1, cc	// cc = lo, ul, last
 998:	da812420 	cneg	x0, x1, cc	// cc = lo, ul, last
 99c:	9a9f27e0 	cset	x0, cc	// cc = lo, ul, last
 9a0:	da9f23e0 	csetm	x0, cc	// cc = lo, ul, last
 9a4:	fa423025 	ccmp	x1, x2, #0x5, cc	// cc = lo, ul, last
 9a8:	fa47382a 	ccmp	x1, #0x7, #0xa, cc	// cc = lo, ul, last
 9ac:	9a824020 	csel	x0, x1, x2, mi	// mi = first
 9b0:	9a824420 	csinc	x0, x1, x2, mi	// mi = first
 9b4:	da824020 	csinv	x0, x1, x2, mi	// mi = first
 9b8:	da824420 	csneg	x0, x1, x2, mi	// mi = first
 9bc:	9a815420 	cinc	x0, x1, mi	// mi = first
 9c0:	da815020 	cinv	x0, x1, mi	// mi = first
 9c4:	da815420 	cneg	x0, x1, mi	// mi = first
 9c8:	9a9f57e0 	cset	x0, mi	// mi = first
 9cc:	da9f53e0 	csetm	x0, mi	// mi = first
 9d0:	fa424025 	ccmp	x1, x2, #0x5, mi	// mi = first
 9d4:	fa47482a 	ccmp	x1, #0x7, #0xa, mi	// mi = first
 9d8:	9a825020 	csel	x0, x1, x2, pl	// pl = nfrst
 9dc:	9a825420 	csinc	x0, x1, x2, pl	// pl = nfrst
 9e0:	da825020 	csinv	x0, x1, x2, pl	// pl = nfrst
 9e4:	da825420 	csneg	x0, x1, x2, pl	// pl = nfrst
 9e8:	9a814420 	cinc	x0, x1, pl	// pl = nfrst
 9ec:	da814020 	cinv	x0, x1, pl	// pl = nfrst
 9f0:	da814420 	cneg	x0, x1, pl	// pl = nfrst
 9f4:	9a9f47e0 	cset	x0, pl	// pl = nfrst
 9f8:	da9f43e0 	csetm	x0, pl	// pl = nfrst
 9fc:	fa425025 	ccmp	x1, x2, #0x5, pl	// pl = nfrst
 a00:	fa47582a 	ccmp	x1, #0x7, #0xa, pl	// pl = nfrst
 a04:	9a826020 	csel	x0, x1, x2, vs
 a08:	9a826420 	csinc	x0, x1, x2, vs
 a0c:	da826020 	csinv	x0, x1, x2, vs
 a10:	da826420 	csneg	x0, x1, x2, vs
 a14:	9a817420 	cinc	x0, x1, vs
 a18:	da817020 	cinv	x0, x1, vs
 a1c:	da817420 	cneg	x0, x1, vs
 a20:	9a9f77e0 	cset	x0, vs
 a24:	da9f73e0 	csetm	x0, vs
 a28:	fa426025 	ccmp	x1, x2, #0x5, vs
 a2c:	fa47682a 	ccmp	x1, #0x7, #0xa, vs
 a30:	9a827020 	csel	x0, x1, x2, vc
 a34:	9a827420 	csinc	x0, x1, x2, vc
 a38:	da827020 	csinv	x0, x1, x2, vc
 a3c:	da827420 	csneg	x0, x1, x2, vc
 a40:	9a816420 	cinc	x0, x1, vc
 a44:	da816020 	cinv	x0, x1, vc
 a48:	da816420 	cneg	x0, x1, vc
 a4c:	9a9f67e0 	cset	x0, vc
 a50:	da9f63e0 	csetm	x0, vc
 a54:	fa427025 	ccmp	x1, x2, #0x5, vc
 a58:	fa47782a 	ccmp	x1, #0x7, #0xa, vc
 a5c:	9a828020 	csel	x0, x1, x2, hi	// hi = pmore
 a60:	9a828420 	csinc	x0, x1, x2, hi	// hi = pmore
 a64:	da828020 	csinv	x0, x1, x2, hi	// hi = pmore
 a68:	da828420 	csneg	x0, x1, x2, hi	// hi = pmore
 a6c:	9a819420 	cinc	x0, x1, hi	// hi = pmore
 a70:	da819020 	cinv	x0, x1, hi	// hi = pmore
 a74:	da819420 	cneg	x0, x1, hi	// hi = pmore
 a78:	9a9f97e0 	cset	x0, hi	// hi = pmore
 a7c:	da9f93e0 	csetm	x0, hi	// hi = pmore
 a80:	fa428025 	ccmp	x1, x2, #0x5, hi	// hi = pmore
 a84:	fa47882a 	ccmp	x1, #0x7, #0xa, hi	// hi = pmore
 a88:	9a829020 	csel	x0, x1, x2, ls	// ls = plast
 a8c:	9a829420 	csinc	x0, x1, x2, ls	// ls = plast
 a90:	da829020 	csinv	x0, x1, x2, ls	// ls = plast
 a94:	da829420 	csneg	x0, x1, x2, ls	// ls = plast
 a98:	9a818420 	cinc	x0, x1, ls	// ls = plast
 a9c:	da818020 	cinv	x0, x1, ls	// ls = plast
 aa0:	da818420 	cneg	x0, x1, ls	// ls = plast
 aa4:	9a9f87e0 	cset	x0, ls	// ls = plast
 aa8:	da9f83e0 	csetm	x0, ls	// ls = plast
 aac:	fa429025 	ccmp	x1, x2, #0x5, ls	// ls = plast
 ab0:	fa47982a 	ccmp	x1, #0x7, #0xa, ls	// ls = plast
 ab4:	9a82a020 	csel	x0, x1, x2, ge	// ge = tcont
 ab8:	9a82a420 	csinc	x0, x1, x2, ge	// ge = tcont
 abc:	da82a020 	csinv	x0, x1, x2, ge	// ge = tcont
 ac0:	da82a420 	csneg	x0, x1, x2, ge	// ge = tcont
 ac4:	9a81b420 	cinc	x0, x1, ge	// ge = tcont
 ac8:	da81b020 	cinv	x0, x1, ge	// ge = tcont
 acc:	da81b420 	cneg	x0, x1, ge	// ge = tcont
 ad0:	9a9fb7e0 	cset	x0, ge	// ge = tcont
 ad4:	da9fb3e0 	csetm	x0, ge	// ge = tcont
 ad8:	fa42a025 	ccmp	x1, x2, #0x5, ge	// ge = tcont
 adc:	fa47a82a 	ccmp	x1, #0x7, #0xa, ge	// ge = tcont
 ae0:	9a82b020 	csel	x0, x1, x2, lt	// lt = tstop
 ae4:	9a82b420 	csinc	x0, x1, x2, lt	// lt = tstop
 ae8:	da82b020 	csinv	x0, x1, x2, lt	// lt = tstop
 aec:	da82b420 	csneg	x0, x1, x2, lt	// lt = tstop
 af0:	9a81a420 	cinc	x0, x1, lt	// lt = tstop
 af4:	da81a020 	cinv	x0, x1, lt	// lt = tstop
 af8:	da81a420 	cneg	x0, x1, lt	// lt = tstop
 afc:	9a9fa7e0 	cset	x0, lt	// lt = tstop
 b00:	da9fa3e0 	csetm	x0, lt	// lt = tstop
 b04:	fa42b025 	ccmp	x1, x2, #0x5, lt	// lt = tstop
 b08:	fa47b82a 	ccmp	x1, #0x7, #0xa, lt	// lt = tstop
 b0c:	9a82c020 	csel	x0, x1, x2, gt
 b10:	9a82c420 	csinc	x0, x1, x2, gt
 b14:	da82c020 	csinv	x0, x1, x2, gt
 b18:	da82c420 	csneg	x0, x1, x2, gt
 b1c:	9a81d420 	cinc	x0, x1, gt
 b20:	da81d020 	cinv	x0, x1, gt
 b24:	da81d420 	cneg	x0, x1, gt
 b28:	9a9fd7e0 	cset	x0, gt
 b2c:	da9fd3e0 	csetm	x0, gt
 b30:	fa42c025 	ccmp	x1, x2, #0x5, gt
 b34:	fa47c82a 	ccmp	x1, #0x7, #0xa, gt
 b38:	9a82d020 	csel	x0, x1, x2, le
 b3c:	9a82d420 	csinc	x0, x1, x2, le
 b40:	da82d020 	csinv	x0, x1, x2, le
 b44:	da82d420 	csneg	x0, x1, x2, le
 b48:	9a81c420 	cinc	x0, x1, le
 b4c:	da81c020 	cinv	x0, x1, le
 b50:	da81c420 	cneg	x0, x1, le
 b54:	9a9fc7e0 	cset	x0, le
 b58:	da9fc3e0 	csetm	x0, le
 b5c:	fa42d025 	ccmp	x1, x2, #0x5, le
 b60:	fa47d82a 	ccmp	x1, #0x7, #0xa, le
 b64:	9a82e020 	csel	x0, x1, x2, al
 b68:	9a82e420 	csinc	x0, x1, x2, al
 b6c:	da82e020 	csinv	x0, x1, x2, al
 b70:	da82e420 	csneg	x0, x1, x2, al
 b74:	fa42e025 	ccmp	x1, x2, #0x5, al
 b78:	fa47e82a 	ccmp	x1, #0x7, #0xa, al
 b7c:	9a82f020 	csel	x0, x1, x2, nv
 b80:	9a82f420 	csinc	x0, x1, x2, nv
 b84:	da82f020 	csinv	x0, x1, x2, nv
 b88:	da82f420 	csneg	x0, x1, x2, nv
 b8c:	fa42f025 	ccmp	x1, x2, #0x5, nv
 b90:	fa47f82a 	ccmp	x1, #0x7, #0xa, nv
 b94:	f9400480 	ldr	x0, [x4, #8]
 b98:	f9000480 	str	x0, [x4, #8]
 b9c:	f8408080 	ldur	x0, [x4, #8]
 ba0:	f8008080 	stur	x0, [x4, #8]
 ba4:	f8408c80 	ldr	x0, [x4, #8]!
 ba8:	f8408480 	ldr	x0, [x4], #8
 bac:	f8657880 	ldr	x0, [x4, x5, lsl #3]
 bb0:	f8008c80 	str	x0, [x4, #8]!
 bb4:	f8008480 	str	x0, [x4], #8
 bb8:	f8257880 	str	x0, [x4, x5, lsl #3]
 bbc:	39802080 	ldrsb	x0, [x4, #8]
 bc0:	79801080 	ldrsh	x0, [x4, #8]
 bc4:	93407c20 	sxtw	x0, w1
 bc8:	9bc27c20 	umulh	x0, x1, x2
 bcc:	9ba27c20 	umull	x0, w1, w2
 bd0:	9ba20c20 	umaddl	x0, w1, w2, x3
 bd4:	9b220c20 	smaddl	x0, w1, w2, x3
 bd8:	b9800880 	ldrsw	x0, [x4, #8]
 bdc:	a9408480 	ldp	x0, x1, [x4, #8]
 be0:	a9008480 	stp	x0, x1, [x4, #8]
 be4:	9e670000 	fmov	d0, x0
 be8:	9e660000 	fmov	x0, d0
 bec:	1e270000 	fmov	s0, w0
 bf0:	1e260000 	fmov	w0, s0
 bf4:	0e205800 	cnt	v0.8b, v0.8b
 bf8:	4e205800 	cnt	v0.16b, v0.16b
 bfc:	2e303800 	uaddlv	h0, v0.8b
 c00:	6e303800 	uaddlv	h0, v0.16b
 c04:	3dc00480 	ldr	q0, [x4, #16]
 c08:	3d800480 	str	q0, [x4, #16]
