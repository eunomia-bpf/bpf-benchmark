#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 1U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rdx,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSP, X86_WIDTH_64);
x86_l_3:
	/* 0x3: lea    rax,[rsp-0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_8:
	/* 0x8: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a:
	/* 0xa: cmove  rsp,rax */
	X86_SIM_L_EXEC_CMOV(X86_RSP, X86_RAX, X86_WIDTH_64, X86_CC_E);
x86_l_e:
	/* 0xe: mov    rsp,rdx */
	X86_SIM_L_EXEC_MOV_REG(X86_RSP, X86_RDX, X86_WIDTH_64);
x86_l_11:
	/* 0x11: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_16:
	/* 0x16: jmp    1b <entry+0x1b> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1b:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
