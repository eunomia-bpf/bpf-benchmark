#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_4:
	/* 0x4: mov    QWORD PTR [rsp],0x25 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 37ULL);
x86_l_c:
	/* 0xc: mov    rax,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSP, X86_WIDTH_64);
x86_l_f:
	/* 0xf: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11:
	/* 0x11: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_13:
	/* 0x13: cmove  rdx,rax */
	X86_SIM_L_EXEC_CMOV(X86_RDX, X86_RAX, X86_WIDTH_64, X86_CC_E);
x86_l_17:
	/* 0x17: mov    ecx,DWORD PTR [rdx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19:
	/* 0x19: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1d:
	/* 0x1d: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_20:
	/* 0x20: jne    2c <entry+0x2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20, 0x2c, x86_l_2c);
x86_l_22:
	/* 0x22: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_27:
	/* 0x27: jmp    36 <entry+0x36> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_2c:
	/* 0x2c: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_31:
	/* 0x31: jmp    36 <entry+0x36> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_36:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
