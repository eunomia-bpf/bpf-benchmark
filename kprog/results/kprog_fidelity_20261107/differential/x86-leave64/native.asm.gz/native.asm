
/workspaces/repository/kprog/fidelity/build-x86-leave64/leave64:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040253c <observe_leave>:
  40253c:	55                   	push   rbp
  40253d:	53                   	push   rbx
  40253e:	41 54                	push   r12
  402540:	41 55                	push   r13
  402542:	41 56                	push   r14
  402544:	41 57                	push   r15
  402546:	48 89 25 d3 25 0b 00 	mov    QWORD PTR [rip+0xb25d3],rsp        # 4b4b20 <saved_rsp>
  40254d:	49 89 ff             	mov    r15,rdi
  402550:	41 ff b7 80 00 00 00 	push   QWORD PTR [r15+0x80]
  402557:	9d                   	popf
  402558:	49 8b 07             	mov    rax,QWORD PTR [r15]
  40255b:	49 8b 4f 08          	mov    rcx,QWORD PTR [r15+0x8]
  40255f:	49 8b 57 10          	mov    rdx,QWORD PTR [r15+0x10]
  402563:	49 8b 5f 18          	mov    rbx,QWORD PTR [r15+0x18]
  402567:	49 8b 6f 28          	mov    rbp,QWORD PTR [r15+0x28]
  40256b:	49 8b 77 30          	mov    rsi,QWORD PTR [r15+0x30]
  40256f:	49 8b 7f 38          	mov    rdi,QWORD PTR [r15+0x38]
  402573:	4d 8b 47 40          	mov    r8,QWORD PTR [r15+0x40]
  402577:	4d 8b 4f 48          	mov    r9,QWORD PTR [r15+0x48]
  40257b:	4d 8b 57 50          	mov    r10,QWORD PTR [r15+0x50]
  40257f:	4d 8b 5f 58          	mov    r11,QWORD PTR [r15+0x58]
  402583:	4d 8b 67 60          	mov    r12,QWORD PTR [r15+0x60]
  402587:	4d 8b 6f 68          	mov    r13,QWORD PTR [r15+0x68]
  40258b:	4d 8b 77 70          	mov    r14,QWORD PTR [r15+0x70]
  40258f:	49 8b 67 20          	mov    rsp,QWORD PTR [r15+0x20]
  402593:	4d 8b 7f 78          	mov    r15,QWORD PTR [r15+0x78]

0000000000402597 <leave_pc>:
  402597:	c9                   	leave

0000000000402598 <leave_next>:
  402598:	48 89 05 a1 25 0b 00 	mov    QWORD PTR [rip+0xb25a1],rax        # 4b4b40 <observed>
  40259f:	48 89 0d a2 25 0b 00 	mov    QWORD PTR [rip+0xb25a2],rcx        # 4b4b48 <observed+0x8>
  4025a6:	48 89 15 a3 25 0b 00 	mov    QWORD PTR [rip+0xb25a3],rdx        # 4b4b50 <observed+0x10>
  4025ad:	48 89 1d a4 25 0b 00 	mov    QWORD PTR [rip+0xb25a4],rbx        # 4b4b58 <observed+0x18>
  4025b4:	48 89 25 a5 25 0b 00 	mov    QWORD PTR [rip+0xb25a5],rsp        # 4b4b60 <observed+0x20>
  4025bb:	48 89 2d a6 25 0b 00 	mov    QWORD PTR [rip+0xb25a6],rbp        # 4b4b68 <observed+0x28>
  4025c2:	48 89 35 a7 25 0b 00 	mov    QWORD PTR [rip+0xb25a7],rsi        # 4b4b70 <observed+0x30>
  4025c9:	48 89 3d a8 25 0b 00 	mov    QWORD PTR [rip+0xb25a8],rdi        # 4b4b78 <observed+0x38>
  4025d0:	4c 89 05 a9 25 0b 00 	mov    QWORD PTR [rip+0xb25a9],r8        # 4b4b80 <observed+0x40>
  4025d7:	4c 89 0d aa 25 0b 00 	mov    QWORD PTR [rip+0xb25aa],r9        # 4b4b88 <observed+0x48>
  4025de:	4c 89 15 ab 25 0b 00 	mov    QWORD PTR [rip+0xb25ab],r10        # 4b4b90 <observed+0x50>
  4025e5:	4c 89 1d ac 25 0b 00 	mov    QWORD PTR [rip+0xb25ac],r11        # 4b4b98 <observed+0x58>
  4025ec:	4c 89 25 ad 25 0b 00 	mov    QWORD PTR [rip+0xb25ad],r12        # 4b4ba0 <observed+0x60>
  4025f3:	4c 89 2d ae 25 0b 00 	mov    QWORD PTR [rip+0xb25ae],r13        # 4b4ba8 <observed+0x68>
  4025fa:	4c 89 35 af 25 0b 00 	mov    QWORD PTR [rip+0xb25af],r14        # 4b4bb0 <observed+0x70>
  402601:	4c 89 3d b0 25 0b 00 	mov    QWORD PTR [rip+0xb25b0],r15        # 4b4bb8 <observed+0x78>
  402608:	48 8b 25 11 25 0b 00 	mov    rsp,QWORD PTR [rip+0xb2511]        # 4b4b20 <saved_rsp>
  40260f:	9c                   	pushf
  402610:	8f 05 aa 25 0b 00    	pop    QWORD PTR [rip+0xb25aa]        # 4b4bc0 <observed+0x80>
  402616:	41 5f                	pop    r15
  402618:	41 5e                	pop    r14
  40261a:	41 5d                	pop    r13
  40261c:	41 5c                	pop    r12
  40261e:	5b                   	pop    rbx
  40261f:	5d                   	pop    rbp
  402620:	c3                   	ret
  402621:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  402628:	00 00 00 
  40262b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]

Disassembly of section .fini:
