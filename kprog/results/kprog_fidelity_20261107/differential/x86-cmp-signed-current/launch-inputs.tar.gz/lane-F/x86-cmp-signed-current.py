from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
B=R/'kprog/fidelity/build-x86';O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-cmp-signed-current'
stem=F/'x86-cmp-signed-current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def state(s):stem.with_suffix('.state').write_text(s+'\n')
def run(cmd,name):
 with (O/name).open('w') as f:rc=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 return dict(command=cmd,exit=rc)
try:
 O.mkdir()
 paths=[R/'kprog/fidelity'/n for n in ['generate.py','driver.c','driver.h','Makefile','reference_check.py']]
 paths += list((R/'kprog/x86').glob('*.h'))+list((R/'kprog/x86/micro-prog').glob('*.py'))+list((R/'kprog/formal/generated').glob('*.h'))
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 emit('launch.json',dict(started=datetime.now(timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),header_commit='b46de606ccde1165966e8d9fc0d19e881bcfe00e',pins=pins,reference_sha256=sha(F/'reference-control-frozen')))
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
  t.add(__file__,arcname='lane-F/x86-cmp-signed-current.py',recursive=False)
 (O/'README.md').write_text('# Current signed-CMP CPU and canonical replay\n\nThis detached run consumes published b46de606ccde1165966e8d9fc0d19e881bcfe00e\nproduction CMP flag expression using the existing 1144-form matrix and frozen\nc110 canonical executable. The preceding d30 result remains separately published\nat ../x86-self-xor-current. Results remain pending until the terminal status and\nall per-form rows are reviewed. No production/reference/oracle change is made.\n\n~~~sh\ntaskset -c 16-19 make -C kprog/fidelity build ARCH=x86\ntaskset -c 16-19 make -f kprog/results/kprog_fidelity_20261107/differential/x86-popcnt-memory/Makefile reference OUT=/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-cmp-signed-current\n~~~\n\nThe same incremental build-x86 cache is reused after the preceding readers\nclosed; no root Lake/kernel/module/image rebuild is involved. launch.json and\nlaunch-inputs.tar.gz preserve the prelaunch identities. The actual compiled\nproduction snapshot, generated C/assembly and static binary are captured after\nbuild completion, separately from these prelaunch observations.\n')
 state('incremental_build_running')
 built=run(['taskset','-c','16-19','make','-C','kprog/fidelity','build','ARCH=x86'],'build.log')
 emit('build-status.json',built)
 if built['exit']:raise RuntimeError('CPU harness build failed; evidence retained')
 files=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
 files += [B/n for n in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json']]
 files += [R/'kprog/fidelity'/n for n in ['driver.c','driver.h','Makefile']]
 actual={str(p.relative_to(R)):sha(p) for p in files}
 emit('actual-compiled-inputs.json',actual)
 with tarfile.open(O/'actual-compiled-inputs.tar.gz','w:gz') as t:
  for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 (O/'cpu-differential-x86.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
 header=B/'snapshot/kprog/x86/x86_sim_local_bpf.h'
 published=subprocess.check_output(['git','show','b46de606ccde1165966e8d9fc0d19e881bcfe00e:kprog/x86/x86_sim_local_bpf.h'],cwd=R)
 assert header.read_bytes()==published,'actual header differs from intended published CMP snapshot'
 forms=json.loads((B/'coverage.json').read_text());assert len(forms)==1144
 emit('executable-pins.json',dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(F/'reference-control-frozen'),compiled_header_sha256=sha(header)))
 state('real_cpu_and_frozen_canonical_replay_running')
 replay=run(['taskset','-c','16-19','make','-f','kprog/results/kprog_fidelity_20261107/differential/x86-popcnt-memory/Makefile','reference','OUT='+str(O)],'reference.log')
 replay['finished']=datetime.now(timezone.utc).isoformat();emit('replay-status.json',replay)
 emit('source-drift-after.json',{p:dict(before=h,after=sha(R/p)) for p,h in pins.items() if (R/p).exists() and sha(R/p)!=h})
 for n in ['build.log','reference.log','mismatches.jsonl','reference-mismatches.jsonl','reference-unavailable.jsonl']:
  p=O/n
  if p.exists():(O/(n+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 state('closed_'+str(replay['exit'])+'_needs_independent_review_and_publication')
 stem.with_suffix('.exit').write_text(str(replay['exit'])+'\n')
except BaseException:
 stem.with_suffix('.error').write_text(traceback.format_exc());state('failed_evidence_retained')
 stem.with_suffix('.exit').write_text('1\n');raise
