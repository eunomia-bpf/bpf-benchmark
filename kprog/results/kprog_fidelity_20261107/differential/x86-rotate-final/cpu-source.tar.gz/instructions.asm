
/workspaces/repository/kprog/fidelity/build-rotate-final/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	c0 c0 00                                        	rol    al,0x0
   3:	d0 c0                                           	rol    al,1
   5:	c0 c0 07                                        	rol    al,0x7
   8:	c0 c0 08                                        	rol    al,0x8
   b:	c0 c0 0f                                        	rol    al,0xf
   e:	c0 c0 10                                        	rol    al,0x10
  11:	c0 c0 1f                                        	rol    al,0x1f
  14:	c0 c0 20                                        	rol    al,0x20
  17:	c0 c0 3f                                        	rol    al,0x3f
  1a:	c0 c0 40                                        	rol    al,0x40
  1d:	c0 c0 ff                                        	rol    al,0xff
  20:	d2 c0                                           	rol    al,cl
  22:	c0 c8 00                                        	ror    al,0x0
  25:	d0 c8                                           	ror    al,1
  27:	c0 c8 07                                        	ror    al,0x7
  2a:	c0 c8 08                                        	ror    al,0x8
  2d:	c0 c8 0f                                        	ror    al,0xf
  30:	c0 c8 10                                        	ror    al,0x10
  33:	c0 c8 1f                                        	ror    al,0x1f
  36:	c0 c8 20                                        	ror    al,0x20
  39:	c0 c8 3f                                        	ror    al,0x3f
  3c:	c0 c8 40                                        	ror    al,0x40
  3f:	c0 c8 ff                                        	ror    al,0xff
  42:	d2 c8                                           	ror    al,cl
  44:	66 c1 c0 00                                     	rol    ax,0x0
  48:	66 d1 c0                                        	rol    ax,1
  4b:	66 c1 c0 07                                     	rol    ax,0x7
  4f:	66 c1 c0 08                                     	rol    ax,0x8
  53:	66 c1 c0 0f                                     	rol    ax,0xf
  57:	66 c1 c0 10                                     	rol    ax,0x10
  5b:	66 c1 c0 1f                                     	rol    ax,0x1f
  5f:	66 c1 c0 20                                     	rol    ax,0x20
  63:	66 c1 c0 3f                                     	rol    ax,0x3f
  67:	66 c1 c0 40                                     	rol    ax,0x40
  6b:	66 c1 c0 ff                                     	rol    ax,0xff
  6f:	66 d3 c0                                        	rol    ax,cl
  72:	66 c1 c8 00                                     	ror    ax,0x0
  76:	66 d1 c8                                        	ror    ax,1
  79:	66 c1 c8 07                                     	ror    ax,0x7
  7d:	66 c1 c8 08                                     	ror    ax,0x8
  81:	66 c1 c8 0f                                     	ror    ax,0xf
  85:	66 c1 c8 10                                     	ror    ax,0x10
  89:	66 c1 c8 1f                                     	ror    ax,0x1f
  8d:	66 c1 c8 20                                     	ror    ax,0x20
  91:	66 c1 c8 3f                                     	ror    ax,0x3f
  95:	66 c1 c8 40                                     	ror    ax,0x40
  99:	66 c1 c8 ff                                     	ror    ax,0xff
  9d:	66 d3 c8                                        	ror    ax,cl
  a0:	c1 c0 00                                        	rol    eax,0x0
  a3:	d1 c0                                           	rol    eax,1
  a5:	c1 c0 07                                        	rol    eax,0x7
  a8:	c1 c0 08                                        	rol    eax,0x8
  ab:	c1 c0 0f                                        	rol    eax,0xf
  ae:	c1 c0 10                                        	rol    eax,0x10
  b1:	c1 c0 1f                                        	rol    eax,0x1f
  b4:	c1 c0 20                                        	rol    eax,0x20
  b7:	c1 c0 3f                                        	rol    eax,0x3f
  ba:	c1 c0 40                                        	rol    eax,0x40
  bd:	c1 c0 ff                                        	rol    eax,0xff
  c0:	d3 c0                                           	rol    eax,cl
  c2:	c1 c8 00                                        	ror    eax,0x0
  c5:	d1 c8                                           	ror    eax,1
  c7:	c1 c8 07                                        	ror    eax,0x7
  ca:	c1 c8 08                                        	ror    eax,0x8
  cd:	c1 c8 0f                                        	ror    eax,0xf
  d0:	c1 c8 10                                        	ror    eax,0x10
  d3:	c1 c8 1f                                        	ror    eax,0x1f
  d6:	c1 c8 20                                        	ror    eax,0x20
  d9:	c1 c8 3f                                        	ror    eax,0x3f
  dc:	c1 c8 40                                        	ror    eax,0x40
  df:	c1 c8 ff                                        	ror    eax,0xff
  e2:	d3 c8                                           	ror    eax,cl
  e4:	48 c1 c0 00                                     	rol    rax,0x0
  e8:	48 d1 c0                                        	rol    rax,1
  eb:	48 c1 c0 07                                     	rol    rax,0x7
  ef:	48 c1 c0 08                                     	rol    rax,0x8
  f3:	48 c1 c0 0f                                     	rol    rax,0xf
  f7:	48 c1 c0 10                                     	rol    rax,0x10
  fb:	48 c1 c0 1f                                     	rol    rax,0x1f
  ff:	48 c1 c0 20                                     	rol    rax,0x20
 103:	48 c1 c0 3f                                     	rol    rax,0x3f
 107:	48 c1 c0 40                                     	rol    rax,0x40
 10b:	48 c1 c0 ff                                     	rol    rax,0xff
 10f:	48 d3 c0                                        	rol    rax,cl
 112:	48 c1 c8 00                                     	ror    rax,0x0
 116:	48 d1 c8                                        	ror    rax,1
 119:	48 c1 c8 07                                     	ror    rax,0x7
 11d:	48 c1 c8 08                                     	ror    rax,0x8
 121:	48 c1 c8 0f                                     	ror    rax,0xf
 125:	48 c1 c8 10                                     	ror    rax,0x10
 129:	48 c1 c8 1f                                     	ror    rax,0x1f
 12d:	48 c1 c8 20                                     	ror    rax,0x20
 131:	48 c1 c8 3f                                     	ror    rax,0x3f
 135:	48 c1 c8 40                                     	ror    rax,0x40
 139:	48 c1 c8 ff                                     	ror    rax,0xff
 13d:	48 d3 c8                                        	ror    rax,cl
 140:	c0 c4 00                                        	rol    ah,0x0
 143:	d0 c4                                           	rol    ah,1
 145:	c0 c4 07                                        	rol    ah,0x7
 148:	c0 c4 08                                        	rol    ah,0x8
 14b:	c0 c4 0f                                        	rol    ah,0xf
 14e:	c0 c4 10                                        	rol    ah,0x10
 151:	c0 c4 1f                                        	rol    ah,0x1f
 154:	c0 c4 20                                        	rol    ah,0x20
 157:	c0 c4 3f                                        	rol    ah,0x3f
 15a:	c0 c4 40                                        	rol    ah,0x40
 15d:	c0 c4 ff                                        	rol    ah,0xff
 160:	d2 c4                                           	rol    ah,cl
 162:	c0 c5 00                                        	rol    ch,0x0
 165:	d0 c5                                           	rol    ch,1
 167:	c0 c5 07                                        	rol    ch,0x7
 16a:	c0 c5 08                                        	rol    ch,0x8
 16d:	c0 c5 0f                                        	rol    ch,0xf
 170:	c0 c5 10                                        	rol    ch,0x10
 173:	c0 c5 1f                                        	rol    ch,0x1f
 176:	c0 c5 20                                        	rol    ch,0x20
 179:	c0 c5 3f                                        	rol    ch,0x3f
 17c:	c0 c5 40                                        	rol    ch,0x40
 17f:	c0 c5 ff                                        	rol    ch,0xff
 182:	d2 c5                                           	rol    ch,cl
 184:	c0 c6 00                                        	rol    dh,0x0
 187:	d0 c6                                           	rol    dh,1
 189:	c0 c6 07                                        	rol    dh,0x7
 18c:	c0 c6 08                                        	rol    dh,0x8
 18f:	c0 c6 0f                                        	rol    dh,0xf
 192:	c0 c6 10                                        	rol    dh,0x10
 195:	c0 c6 1f                                        	rol    dh,0x1f
 198:	c0 c6 20                                        	rol    dh,0x20
 19b:	c0 c6 3f                                        	rol    dh,0x3f
 19e:	c0 c6 40                                        	rol    dh,0x40
 1a1:	c0 c6 ff                                        	rol    dh,0xff
 1a4:	d2 c6                                           	rol    dh,cl
 1a6:	c0 c7 00                                        	rol    bh,0x0
 1a9:	d0 c7                                           	rol    bh,1
 1ab:	c0 c7 07                                        	rol    bh,0x7
 1ae:	c0 c7 08                                        	rol    bh,0x8
 1b1:	c0 c7 0f                                        	rol    bh,0xf
 1b4:	c0 c7 10                                        	rol    bh,0x10
 1b7:	c0 c7 1f                                        	rol    bh,0x1f
 1ba:	c0 c7 20                                        	rol    bh,0x20
 1bd:	c0 c7 3f                                        	rol    bh,0x3f
 1c0:	c0 c7 40                                        	rol    bh,0x40
 1c3:	c0 c7 ff                                        	rol    bh,0xff
 1c6:	d2 c7                                           	rol    bh,cl
 1c8:	c0 cc 00                                        	ror    ah,0x0
 1cb:	d0 cc                                           	ror    ah,1
 1cd:	c0 cc 07                                        	ror    ah,0x7
 1d0:	c0 cc 08                                        	ror    ah,0x8
 1d3:	c0 cc 0f                                        	ror    ah,0xf
 1d6:	c0 cc 10                                        	ror    ah,0x10
 1d9:	c0 cc 1f                                        	ror    ah,0x1f
 1dc:	c0 cc 20                                        	ror    ah,0x20
 1df:	c0 cc 3f                                        	ror    ah,0x3f
 1e2:	c0 cc 40                                        	ror    ah,0x40
 1e5:	c0 cc ff                                        	ror    ah,0xff
 1e8:	d2 cc                                           	ror    ah,cl
 1ea:	c0 cd 00                                        	ror    ch,0x0
 1ed:	d0 cd                                           	ror    ch,1
 1ef:	c0 cd 07                                        	ror    ch,0x7
 1f2:	c0 cd 08                                        	ror    ch,0x8
 1f5:	c0 cd 0f                                        	ror    ch,0xf
 1f8:	c0 cd 10                                        	ror    ch,0x10
 1fb:	c0 cd 1f                                        	ror    ch,0x1f
 1fe:	c0 cd 20                                        	ror    ch,0x20
 201:	c0 cd 3f                                        	ror    ch,0x3f
 204:	c0 cd 40                                        	ror    ch,0x40
 207:	c0 cd ff                                        	ror    ch,0xff
 20a:	d2 cd                                           	ror    ch,cl
 20c:	c0 ce 00                                        	ror    dh,0x0
 20f:	d0 ce                                           	ror    dh,1
 211:	c0 ce 07                                        	ror    dh,0x7
 214:	c0 ce 08                                        	ror    dh,0x8
 217:	c0 ce 0f                                        	ror    dh,0xf
 21a:	c0 ce 10                                        	ror    dh,0x10
 21d:	c0 ce 1f                                        	ror    dh,0x1f
 220:	c0 ce 20                                        	ror    dh,0x20
 223:	c0 ce 3f                                        	ror    dh,0x3f
 226:	c0 ce 40                                        	ror    dh,0x40
 229:	c0 ce ff                                        	ror    dh,0xff
 22c:	d2 ce                                           	ror    dh,cl
 22e:	c0 cf 00                                        	ror    bh,0x0
 231:	d0 cf                                           	ror    bh,1
 233:	c0 cf 07                                        	ror    bh,0x7
 236:	c0 cf 08                                        	ror    bh,0x8
 239:	c0 cf 0f                                        	ror    bh,0xf
 23c:	c0 cf 10                                        	ror    bh,0x10
 23f:	c0 cf 1f                                        	ror    bh,0x1f
 242:	c0 cf 20                                        	ror    bh,0x20
 245:	c0 cf 3f                                        	ror    bh,0x3f
 248:	c0 cf 40                                        	ror    bh,0x40
 24b:	c0 cf ff                                        	ror    bh,0xff
 24e:	d2 cf                                           	ror    bh,cl
 250:	c0 4f 08 00                                     	ror    BYTE PTR [rdi+0x8],0x0
 254:	d0 4f 08                                        	ror    BYTE PTR [rdi+0x8],1
 257:	c0 4f 08 07                                     	ror    BYTE PTR [rdi+0x8],0x7
 25b:	c0 4f 08 08                                     	ror    BYTE PTR [rdi+0x8],0x8
 25f:	c0 4f 08 0f                                     	ror    BYTE PTR [rdi+0x8],0xf
 263:	c0 4f 08 10                                     	ror    BYTE PTR [rdi+0x8],0x10
 267:	c0 4f 08 1f                                     	ror    BYTE PTR [rdi+0x8],0x1f
 26b:	c0 4f 08 20                                     	ror    BYTE PTR [rdi+0x8],0x20
 26f:	c0 4f 08 3f                                     	ror    BYTE PTR [rdi+0x8],0x3f
 273:	c0 4f 08 40                                     	ror    BYTE PTR [rdi+0x8],0x40
 277:	c0 4f 08 ff                                     	ror    BYTE PTR [rdi+0x8],0xff
 27b:	d2 4f 08                                        	ror    BYTE PTR [rdi+0x8],cl
 27e:	66 c1 4f 08 00                                  	ror    WORD PTR [rdi+0x8],0x0
 283:	66 d1 4f 08                                     	ror    WORD PTR [rdi+0x8],1
 287:	66 c1 4f 08 07                                  	ror    WORD PTR [rdi+0x8],0x7
 28c:	66 c1 4f 08 08                                  	ror    WORD PTR [rdi+0x8],0x8
 291:	66 c1 4f 08 0f                                  	ror    WORD PTR [rdi+0x8],0xf
 296:	66 c1 4f 08 10                                  	ror    WORD PTR [rdi+0x8],0x10
 29b:	66 c1 4f 08 1f                                  	ror    WORD PTR [rdi+0x8],0x1f
 2a0:	66 c1 4f 08 20                                  	ror    WORD PTR [rdi+0x8],0x20
 2a5:	66 c1 4f 08 3f                                  	ror    WORD PTR [rdi+0x8],0x3f
 2aa:	66 c1 4f 08 40                                  	ror    WORD PTR [rdi+0x8],0x40
 2af:	66 c1 4f 08 ff                                  	ror    WORD PTR [rdi+0x8],0xff
 2b4:	66 d3 4f 08                                     	ror    WORD PTR [rdi+0x8],cl
 2b8:	c1 4f 08 00                                     	ror    DWORD PTR [rdi+0x8],0x0
 2bc:	d1 4f 08                                        	ror    DWORD PTR [rdi+0x8],1
 2bf:	c1 4f 08 07                                     	ror    DWORD PTR [rdi+0x8],0x7
 2c3:	c1 4f 08 08                                     	ror    DWORD PTR [rdi+0x8],0x8
 2c7:	c1 4f 08 0f                                     	ror    DWORD PTR [rdi+0x8],0xf
 2cb:	c1 4f 08 10                                     	ror    DWORD PTR [rdi+0x8],0x10
 2cf:	c1 4f 08 1f                                     	ror    DWORD PTR [rdi+0x8],0x1f
 2d3:	c1 4f 08 20                                     	ror    DWORD PTR [rdi+0x8],0x20
 2d7:	c1 4f 08 3f                                     	ror    DWORD PTR [rdi+0x8],0x3f
 2db:	c1 4f 08 40                                     	ror    DWORD PTR [rdi+0x8],0x40
 2df:	c1 4f 08 ff                                     	ror    DWORD PTR [rdi+0x8],0xff
 2e3:	d3 4f 08                                        	ror    DWORD PTR [rdi+0x8],cl
 2e6:	48 c1 4f 08 00                                  	ror    QWORD PTR [rdi+0x8],0x0
 2eb:	48 d1 4f 08                                     	ror    QWORD PTR [rdi+0x8],1
 2ef:	48 c1 4f 08 07                                  	ror    QWORD PTR [rdi+0x8],0x7
 2f4:	48 c1 4f 08 08                                  	ror    QWORD PTR [rdi+0x8],0x8
 2f9:	48 c1 4f 08 0f                                  	ror    QWORD PTR [rdi+0x8],0xf
 2fe:	48 c1 4f 08 10                                  	ror    QWORD PTR [rdi+0x8],0x10
 303:	48 c1 4f 08 1f                                  	ror    QWORD PTR [rdi+0x8],0x1f
 308:	48 c1 4f 08 20                                  	ror    QWORD PTR [rdi+0x8],0x20
 30d:	48 c1 4f 08 3f                                  	ror    QWORD PTR [rdi+0x8],0x3f
 312:	48 c1 4f 08 40                                  	ror    QWORD PTR [rdi+0x8],0x40
 317:	48 c1 4f 08 ff                                  	ror    QWORD PTR [rdi+0x8],0xff
 31c:	48 d3 4f 08                                     	ror    QWORD PTR [rdi+0x8],cl
