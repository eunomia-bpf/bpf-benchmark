
/workspaces/repository/kprog/fidelity/build-sp-sequences-before/native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <native_0>:
       0:	53                                              	push   rbx
       1:	55                                              	push   rbp
       2:	41 54                                           	push   r12
       4:	41 55                                           	push   r13
       6:	41 56                                           	push   r14
       8:	41 57                                           	push   r15
       a:	57                                              	push   rdi
       b:	49 89 ff                                        	mov    r15,rdi
       e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
      17:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
      1d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
      26:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
      2c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
      35:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
      3b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
      44:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
      4a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
      51:	9d                                              	popf
      52:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
      58:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
      61:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
      64:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
      68:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
      6c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
      70:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
      74:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
      78:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
      7c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
      80:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
      84:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
      88:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
      8c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
      90:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
      94:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
      98:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
      9c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # a3 <native_pc_0>

00000000000000a3 <native_pc_0>:
      a3:	48 89 e0                                        	mov    rax,rsp
      a6:	48 89 c4                                        	mov    rsp,rax

00000000000000a9 <native_next_0>:
      a9:	66 48 0f 6e ec                                  	movq   xmm5,rsp
      ae:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # b5 <native_next_0+0xc>
      b5:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
      bb:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
      c1:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
      c7:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
      cd:	41 57                                           	push   r15
      cf:	9c                                              	pushf
      d0:	50                                              	push   rax
      d1:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
      d6:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
      de:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
      e6:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
      ee:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
      f6:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
      fa:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
      fe:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     102:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     106:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     10a:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     10e:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     112:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     116:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     11a:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     11e:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     122:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     126:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     12a:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     12f:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 136 <native_next_0+0x8d>
     136:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     13a:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     13e:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     141:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     146:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     14d:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     152:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     156:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     15e:	48 83 c4 18                                     	add    rsp,0x18
     162:	5f                                              	pop    rdi
     163:	41 5f                                           	pop    r15
     165:	41 5e                                           	pop    r14
     167:	41 5d                                           	pop    r13
     169:	41 5c                                           	pop    r12
     16b:	5d                                              	pop    rbp
     16c:	5b                                              	pop    rbx
     16d:	c3                                              	ret

000000000000016e <native_1>:
     16e:	53                                              	push   rbx
     16f:	55                                              	push   rbp
     170:	41 54                                           	push   r12
     172:	41 55                                           	push   r13
     174:	41 56                                           	push   r14
     176:	41 57                                           	push   r15
     178:	57                                              	push   rdi
     179:	49 89 ff                                        	mov    r15,rdi
     17c:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     185:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     18b:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     194:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     19a:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     1a3:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     1a9:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     1b2:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     1b8:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     1bf:	9d                                              	popf
     1c0:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     1c6:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     1cf:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     1d2:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     1d6:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     1da:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     1de:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     1e2:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     1e6:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     1ea:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     1ee:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     1f2:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     1f6:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     1fa:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     1fe:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     202:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     206:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     20a:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 211 <native_pc_1>

0000000000000211 <native_pc_1>:
     211:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     216:	48 89 c4                                        	mov    rsp,rax
     219:	48 83 c4 10                                     	add    rsp,0x10

000000000000021d <native_next_1>:
     21d:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     222:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 229 <native_next_1+0xc>
     229:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     22f:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     235:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     23b:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     241:	41 57                                           	push   r15
     243:	9c                                              	pushf
     244:	50                                              	push   rax
     245:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     24a:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     252:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     25a:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     262:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     26a:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     26e:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     272:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     276:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     27a:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     27e:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     282:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     286:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     28a:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     28e:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     292:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     296:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     29a:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     29e:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     2a3:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 2aa <native_next_1+0x8d>
     2aa:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     2ae:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     2b2:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     2b5:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     2ba:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     2c1:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     2c6:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     2ca:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     2d2:	48 83 c4 18                                     	add    rsp,0x18
     2d6:	5f                                              	pop    rdi
     2d7:	41 5f                                           	pop    r15
     2d9:	41 5e                                           	pop    r14
     2db:	41 5d                                           	pop    r13
     2dd:	41 5c                                           	pop    r12
     2df:	5d                                              	pop    rbp
     2e0:	5b                                              	pop    rbx
     2e1:	c3                                              	ret

00000000000002e2 <native_2>:
     2e2:	53                                              	push   rbx
     2e3:	55                                              	push   rbp
     2e4:	41 54                                           	push   r12
     2e6:	41 55                                           	push   r13
     2e8:	41 56                                           	push   r14
     2ea:	41 57                                           	push   r15
     2ec:	57                                              	push   rdi
     2ed:	49 89 ff                                        	mov    r15,rdi
     2f0:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     2f9:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     2ff:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     308:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     30e:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     317:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     31d:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     326:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     32c:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     333:	9d                                              	popf
     334:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     33a:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     343:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     346:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     34a:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     34e:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     352:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     356:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     35a:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     35e:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     362:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     366:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     36a:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     36e:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     372:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     376:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     37a:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     37e:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 385 <native_pc_2>

0000000000000385 <native_pc_2>:
     385:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     38a:	48 8d 60 10                                     	lea    rsp,[rax+0x10]

000000000000038e <native_next_2>:
     38e:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     393:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 39a <native_next_2+0xc>
     39a:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     3a0:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     3a6:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     3ac:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     3b2:	41 57                                           	push   r15
     3b4:	9c                                              	pushf
     3b5:	50                                              	push   rax
     3b6:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     3bb:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     3c3:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     3cb:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     3d3:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     3db:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     3df:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     3e3:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     3e7:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     3eb:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     3ef:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     3f3:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     3f7:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     3fb:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     3ff:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     403:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     407:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     40b:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     40f:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     414:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 41b <native_next_2+0x8d>
     41b:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     41f:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     423:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     426:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     42b:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     432:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     437:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     43b:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     443:	48 83 c4 18                                     	add    rsp,0x18
     447:	5f                                              	pop    rdi
     448:	41 5f                                           	pop    r15
     44a:	41 5e                                           	pop    r14
     44c:	41 5d                                           	pop    r13
     44e:	41 5c                                           	pop    r12
     450:	5d                                              	pop    rbp
     451:	5b                                              	pop    rbx
     452:	c3                                              	ret

0000000000000453 <native_3>:
     453:	53                                              	push   rbx
     454:	55                                              	push   rbp
     455:	41 54                                           	push   r12
     457:	41 55                                           	push   r13
     459:	41 56                                           	push   r14
     45b:	41 57                                           	push   r15
     45d:	57                                              	push   rdi
     45e:	49 89 ff                                        	mov    r15,rdi
     461:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     46a:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     470:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     479:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     47f:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     488:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     48e:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     497:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     49d:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     4a4:	9d                                              	popf
     4a5:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     4ab:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     4b4:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     4b7:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     4bb:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     4bf:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     4c3:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     4c7:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     4cb:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     4cf:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     4d3:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     4d7:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     4db:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     4df:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     4e3:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     4e7:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     4eb:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     4ef:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 4f6 <native_pc_3>

00000000000004f6 <native_pc_3>:
     4f6:	48 89 e0                                        	mov    rax,rsp
     4f9:	48 89 c1                                        	mov    rcx,rax
     4fc:	48 39 e1                                        	cmp    rcx,rsp

00000000000004ff <native_next_3>:
     4ff:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     504:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 50b <native_next_3+0xc>
     50b:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     511:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     517:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     51d:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     523:	41 57                                           	push   r15
     525:	9c                                              	pushf
     526:	50                                              	push   rax
     527:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     52c:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     534:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     53c:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     544:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     54c:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     550:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     554:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     558:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     55c:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     560:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     564:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     568:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     56c:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     570:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     574:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     578:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     57c:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     580:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     585:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 58c <native_next_3+0x8d>
     58c:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     590:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     594:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     597:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     59c:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     5a3:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     5a8:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     5ac:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     5b4:	48 83 c4 18                                     	add    rsp,0x18
     5b8:	5f                                              	pop    rdi
     5b9:	41 5f                                           	pop    r15
     5bb:	41 5e                                           	pop    r14
     5bd:	41 5d                                           	pop    r13
     5bf:	41 5c                                           	pop    r12
     5c1:	5d                                              	pop    rbp
     5c2:	5b                                              	pop    rbx
     5c3:	c3                                              	ret

00000000000005c4 <native_4>:
     5c4:	53                                              	push   rbx
     5c5:	55                                              	push   rbp
     5c6:	41 54                                           	push   r12
     5c8:	41 55                                           	push   r13
     5ca:	41 56                                           	push   r14
     5cc:	41 57                                           	push   r15
     5ce:	57                                              	push   rdi
     5cf:	49 89 ff                                        	mov    r15,rdi
     5d2:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     5db:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     5e1:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     5ea:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     5f0:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     5f9:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     5ff:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     608:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     60e:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     615:	9d                                              	popf
     616:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     61c:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     625:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     628:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     62c:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     630:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     634:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     638:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     63c:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     640:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     644:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     648:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     64c:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     650:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     654:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     658:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     65c:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     660:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 667 <native_pc_4>

0000000000000667 <native_pc_4>:
     667:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     66c:	48 8b 10                                        	mov    rdx,QWORD PTR [rax]

000000000000066f <native_next_4>:
     66f:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     674:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 67b <native_next_4+0xc>
     67b:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     681:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     687:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     68d:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     693:	41 57                                           	push   r15
     695:	9c                                              	pushf
     696:	50                                              	push   rax
     697:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     69c:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     6a4:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     6ac:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     6b4:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     6bc:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     6c0:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     6c4:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     6c8:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     6cc:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     6d0:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     6d4:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     6d8:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     6dc:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     6e0:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     6e4:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     6e8:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     6ec:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     6f0:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     6f5:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 6fc <native_next_4+0x8d>
     6fc:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     700:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     704:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     707:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     70c:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     713:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     718:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     71c:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     724:	48 83 c4 18                                     	add    rsp,0x18
     728:	5f                                              	pop    rdi
     729:	41 5f                                           	pop    r15
     72b:	41 5e                                           	pop    r14
     72d:	41 5d                                           	pop    r13
     72f:	41 5c                                           	pop    r12
     731:	5d                                              	pop    rbp
     732:	5b                                              	pop    rbx
     733:	c3                                              	ret

0000000000000734 <native_5>:
     734:	53                                              	push   rbx
     735:	55                                              	push   rbp
     736:	41 54                                           	push   r12
     738:	41 55                                           	push   r13
     73a:	41 56                                           	push   r14
     73c:	41 57                                           	push   r15
     73e:	57                                              	push   rdi
     73f:	49 89 ff                                        	mov    r15,rdi
     742:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     74b:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     751:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     75a:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     760:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     769:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     76f:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     778:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     77e:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     785:	9d                                              	popf
     786:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     78c:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     795:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     798:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     79c:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     7a0:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     7a4:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     7a8:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     7ac:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     7b0:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     7b4:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     7b8:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     7bc:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     7c0:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     7c4:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     7c8:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     7cc:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     7d0:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 7d7 <native_pc_5>

00000000000007d7 <native_pc_5>:
     7d7:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     7dc:	89 08                                           	mov    DWORD PTR [rax],ecx

00000000000007de <native_next_5>:
     7de:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     7e3:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 7ea <native_next_5+0xc>
     7ea:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     7f0:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     7f6:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     7fc:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     802:	41 57                                           	push   r15
     804:	9c                                              	pushf
     805:	50                                              	push   rax
     806:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     80b:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     813:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     81b:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     823:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     82b:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     82f:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     833:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     837:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     83b:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     83f:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     843:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     847:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     84b:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     84f:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     853:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     857:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     85b:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     85f:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     864:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 86b <native_next_5+0x8d>
     86b:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     86f:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     873:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     876:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     87b:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     882:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     887:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     88b:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     893:	48 83 c4 18                                     	add    rsp,0x18
     897:	5f                                              	pop    rdi
     898:	41 5f                                           	pop    r15
     89a:	41 5e                                           	pop    r14
     89c:	41 5d                                           	pop    r13
     89e:	41 5c                                           	pop    r12
     8a0:	5d                                              	pop    rbp
     8a1:	5b                                              	pop    rbx
     8a2:	c3                                              	ret

00000000000008a3 <native_6>:
     8a3:	53                                              	push   rbx
     8a4:	55                                              	push   rbp
     8a5:	41 54                                           	push   r12
     8a7:	41 55                                           	push   r13
     8a9:	41 56                                           	push   r14
     8ab:	41 57                                           	push   r15
     8ad:	57                                              	push   rdi
     8ae:	49 89 ff                                        	mov    r15,rdi
     8b1:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     8ba:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     8c0:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     8c9:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     8cf:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     8d8:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     8de:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     8e7:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     8ed:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     8f4:	9d                                              	popf
     8f5:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     8fb:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     904:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     907:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     90b:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     90f:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     913:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     917:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     91b:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     91f:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     923:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     927:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     92b:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     92f:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     933:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     937:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     93b:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     93f:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 946 <native_pc_6>

0000000000000946 <native_pc_6>:
     946:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     94b:	48 8d 50 08                                     	lea    rdx,[rax+0x8]

000000000000094f <native_next_6>:
     94f:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     954:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 95b <native_next_6+0xc>
     95b:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     961:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     967:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     96d:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     973:	41 57                                           	push   r15
     975:	9c                                              	pushf
     976:	50                                              	push   rax
     977:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     97c:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     984:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     98c:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     994:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     99c:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     9a0:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     9a4:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     9a8:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     9ac:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     9b0:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     9b4:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     9b8:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     9bc:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     9c0:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     9c4:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     9c8:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     9cc:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     9d0:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     9d5:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 9dc <native_next_6+0x8d>
     9dc:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     9e0:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     9e4:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     9e7:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     9ec:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     9f3:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     9f8:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     9fc:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     a04:	48 83 c4 18                                     	add    rsp,0x18
     a08:	5f                                              	pop    rdi
     a09:	41 5f                                           	pop    r15
     a0b:	41 5e                                           	pop    r14
     a0d:	41 5d                                           	pop    r13
     a0f:	41 5c                                           	pop    r12
     a11:	5d                                              	pop    rbp
     a12:	5b                                              	pop    rbx
     a13:	c3                                              	ret

0000000000000a14 <native_7>:
     a14:	53                                              	push   rbx
     a15:	55                                              	push   rbp
     a16:	41 54                                           	push   r12
     a18:	41 55                                           	push   r13
     a1a:	41 56                                           	push   r14
     a1c:	41 57                                           	push   r15
     a1e:	57                                              	push   rdi
     a1f:	49 89 ff                                        	mov    r15,rdi
     a22:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     a2b:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     a31:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     a3a:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     a40:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     a49:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     a4f:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     a58:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     a5e:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     a65:	9d                                              	popf
     a66:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     a6c:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     a75:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     a78:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     a7c:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     a80:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     a84:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     a88:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     a8c:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     a90:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     a94:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     a98:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     a9c:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     aa0:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     aa4:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     aa8:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     aac:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     ab0:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # ab7 <native_pc_7>

0000000000000ab7 <native_pc_7>:
     ab7:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     abc:	48 89 c0                                        	mov    rax,rax

0000000000000abf <native_next_7>:
     abf:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     ac4:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # acb <native_next_7+0xc>
     acb:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     ad1:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     ad7:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     add:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     ae3:	41 57                                           	push   r15
     ae5:	9c                                              	pushf
     ae6:	50                                              	push   rax
     ae7:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     aec:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     af4:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     afc:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     b04:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     b0c:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     b10:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     b14:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     b18:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     b1c:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     b20:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     b24:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     b28:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     b2c:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     b30:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     b34:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     b38:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     b3c:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     b40:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     b45:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # b4c <native_next_7+0x8d>
     b4c:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     b50:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     b54:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     b57:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     b5c:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     b63:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     b68:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     b6c:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     b74:	48 83 c4 18                                     	add    rsp,0x18
     b78:	5f                                              	pop    rdi
     b79:	41 5f                                           	pop    r15
     b7b:	41 5e                                           	pop    r14
     b7d:	41 5d                                           	pop    r13
     b7f:	41 5c                                           	pop    r12
     b81:	5d                                              	pop    rbp
     b82:	5b                                              	pop    rbx
     b83:	c3                                              	ret

0000000000000b84 <native_8>:
     b84:	53                                              	push   rbx
     b85:	55                                              	push   rbp
     b86:	41 54                                           	push   r12
     b88:	41 55                                           	push   r13
     b8a:	41 56                                           	push   r14
     b8c:	41 57                                           	push   r15
     b8e:	57                                              	push   rdi
     b8f:	49 89 ff                                        	mov    r15,rdi
     b92:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     b9b:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     ba1:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     baa:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     bb0:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     bb9:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     bbf:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     bc8:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     bce:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     bd5:	9d                                              	popf
     bd6:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     bdc:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     be5:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     be8:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     bec:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     bf0:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     bf4:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     bf8:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     bfc:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     c00:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     c04:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     c08:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     c0c:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     c10:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     c14:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     c18:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     c1c:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     c20:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # c27 <native_pc_8>

0000000000000c27 <native_pc_8>:
     c27:	48 89 e0                                        	mov    rax,rsp
     c2a:	48 83 c0 10                                     	add    rax,0x10

0000000000000c2e <native_next_8>:
     c2e:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     c33:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # c3a <native_next_8+0xc>
     c3a:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     c40:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     c46:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     c4c:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     c52:	41 57                                           	push   r15
     c54:	9c                                              	pushf
     c55:	50                                              	push   rax
     c56:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     c5b:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     c63:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     c6b:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     c73:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     c7b:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     c7f:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     c83:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     c87:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     c8b:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     c8f:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     c93:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     c97:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     c9b:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     c9f:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     ca3:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     ca7:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     cab:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     caf:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     cb4:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # cbb <native_next_8+0x8d>
     cbb:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     cbf:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     cc3:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     cc6:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     ccb:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     cd2:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     cd7:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     cdb:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     ce3:	48 83 c4 18                                     	add    rsp,0x18
     ce7:	5f                                              	pop    rdi
     ce8:	41 5f                                           	pop    r15
     cea:	41 5e                                           	pop    r14
     cec:	41 5d                                           	pop    r13
     cee:	41 5c                                           	pop    r12
     cf0:	5d                                              	pop    rbp
     cf1:	5b                                              	pop    rbx
     cf2:	c3                                              	ret

0000000000000cf3 <native_9>:
     cf3:	53                                              	push   rbx
     cf4:	55                                              	push   rbp
     cf5:	41 54                                           	push   r12
     cf7:	41 55                                           	push   r13
     cf9:	41 56                                           	push   r14
     cfb:	41 57                                           	push   r15
     cfd:	57                                              	push   rdi
     cfe:	49 89 ff                                        	mov    r15,rdi
     d01:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     d0a:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     d10:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     d19:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     d1f:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     d28:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     d2e:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     d37:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     d3d:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     d44:	9d                                              	popf
     d45:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     d4b:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     d54:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     d57:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     d5b:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     d5f:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     d63:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     d67:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     d6b:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     d6f:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     d73:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     d77:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     d7b:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     d7f:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     d83:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     d87:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     d8b:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     d8f:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # d96 <native_pc_9>

0000000000000d96 <native_pc_9>:
     d96:	48 89 e0                                        	mov    rax,rsp
     d99:	48 83 e8 10                                     	sub    rax,0x10

0000000000000d9d <native_next_9>:
     d9d:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     da2:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # da9 <native_next_9+0xc>
     da9:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     daf:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     db5:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     dbb:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     dc1:	41 57                                           	push   r15
     dc3:	9c                                              	pushf
     dc4:	50                                              	push   rax
     dc5:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     dca:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     dd2:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     dda:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     de2:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     dea:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     dee:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     df2:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     df6:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     dfa:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     dfe:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     e02:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     e06:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     e0a:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     e0e:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     e12:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     e16:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     e1a:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     e1e:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     e23:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # e2a <native_next_9+0x8d>
     e2a:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     e2e:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     e32:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     e35:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     e3a:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     e41:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     e46:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     e4a:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     e52:	48 83 c4 18                                     	add    rsp,0x18
     e56:	5f                                              	pop    rdi
     e57:	41 5f                                           	pop    r15
     e59:	41 5e                                           	pop    r14
     e5b:	41 5d                                           	pop    r13
     e5d:	41 5c                                           	pop    r12
     e5f:	5d                                              	pop    rbp
     e60:	5b                                              	pop    rbx
     e61:	c3                                              	ret

0000000000000e62 <native_10>:
     e62:	53                                              	push   rbx
     e63:	55                                              	push   rbp
     e64:	41 54                                           	push   r12
     e66:	41 55                                           	push   r13
     e68:	41 56                                           	push   r14
     e6a:	41 57                                           	push   r15
     e6c:	57                                              	push   rdi
     e6d:	49 89 ff                                        	mov    r15,rdi
     e70:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     e79:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     e7f:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
     e88:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
     e8e:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
     e97:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
     e9d:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
     ea6:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     eac:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
     eb3:	9d                                              	popf
     eb4:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
     eba:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
     ec3:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
     ec6:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
     eca:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
     ece:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
     ed2:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
     ed6:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
     eda:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
     ede:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
     ee2:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
     ee6:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
     eea:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
     eee:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
     ef2:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
     ef6:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
     efa:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
     efe:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # f05 <native_pc_10>

0000000000000f05 <native_pc_10>:
     f05:	48 8d 44 24 f0                                  	lea    rax,[rsp-0x10]
     f0a:	48 89 44 24 f8                                  	mov    QWORD PTR [rsp-0x8],rax
     f0f:	48 8b 44 24 f8                                  	mov    rax,QWORD PTR [rsp-0x8]
     f14:	48 89 c4                                        	mov    rsp,rax
     f17:	48 83 c4 10                                     	add    rsp,0x10

0000000000000f1b <native_next_10>:
     f1b:	66 48 0f 6e ec                                  	movq   xmm5,rsp
     f20:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # f27 <native_next_10+0xc>
     f27:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
     f2d:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
     f33:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
     f39:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
     f3f:	41 57                                           	push   r15
     f41:	9c                                              	pushf
     f42:	50                                              	push   rax
     f43:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
     f48:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
     f50:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
     f58:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
     f60:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
     f68:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
     f6c:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
     f70:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
     f74:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
     f78:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
     f7c:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
     f80:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
     f84:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
     f88:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
     f8c:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
     f90:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
     f94:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
     f98:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
     f9c:	66 48 0f 7e ea                                  	movq   rdx,xmm5
     fa1:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # fa8 <native_next_10+0x8d>
     fa8:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
     fac:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
     fb0:	48 89 10                                        	mov    QWORD PTR [rax],rdx
     fb3:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
     fb8:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
     fbf:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
     fc4:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
     fc8:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
     fd0:	48 83 c4 18                                     	add    rsp,0x18
     fd4:	5f                                              	pop    rdi
     fd5:	41 5f                                           	pop    r15
     fd7:	41 5e                                           	pop    r14
     fd9:	41 5d                                           	pop    r13
     fdb:	41 5c                                           	pop    r12
     fdd:	5d                                              	pop    rbp
     fde:	5b                                              	pop    rbx
     fdf:	c3                                              	ret

0000000000000fe0 <native_11>:
     fe0:	53                                              	push   rbx
     fe1:	55                                              	push   rbp
     fe2:	41 54                                           	push   r12
     fe4:	41 55                                           	push   r13
     fe6:	41 56                                           	push   r14
     fe8:	41 57                                           	push   r15
     fea:	57                                              	push   rdi
     feb:	49 89 ff                                        	mov    r15,rdi
     fee:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
     ff7:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
     ffd:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1006:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    100c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1015:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    101b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1024:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    102a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1031:	9d                                              	popf
    1032:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1038:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1041:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1044:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1048:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    104c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1050:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1054:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1058:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    105c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1060:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1064:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1068:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    106c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1070:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1074:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1078:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    107c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1083 <native_pc_11>

0000000000001083 <native_pc_11>:
    1083:	48 89 e0                                        	mov    rax,rsp
    1086:	50                                              	push   rax
    1087:	58                                              	pop    rax

0000000000001088 <native_next_11>:
    1088:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    108d:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1094 <native_next_11+0xc>
    1094:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    109a:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    10a0:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    10a6:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    10ac:	41 57                                           	push   r15
    10ae:	9c                                              	pushf
    10af:	50                                              	push   rax
    10b0:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    10b5:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    10bd:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    10c5:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    10cd:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    10d5:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    10d9:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    10dd:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    10e1:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    10e5:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    10e9:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    10ed:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    10f1:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    10f5:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    10f9:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    10fd:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1101:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1105:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1109:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    110e:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1115 <native_next_11+0x8d>
    1115:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1119:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    111d:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1120:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1125:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    112c:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1131:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1135:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    113d:	48 83 c4 18                                     	add    rsp,0x18
    1141:	5f                                              	pop    rdi
    1142:	41 5f                                           	pop    r15
    1144:	41 5e                                           	pop    r14
    1146:	41 5d                                           	pop    r13
    1148:	41 5c                                           	pop    r12
    114a:	5d                                              	pop    rbp
    114b:	5b                                              	pop    rbx
    114c:	c3                                              	ret

000000000000114d <native_12>:
    114d:	53                                              	push   rbx
    114e:	55                                              	push   rbp
    114f:	41 54                                           	push   r12
    1151:	41 55                                           	push   r13
    1153:	41 56                                           	push   r14
    1155:	41 57                                           	push   r15
    1157:	57                                              	push   rdi
    1158:	49 89 ff                                        	mov    r15,rdi
    115b:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1164:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    116a:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1173:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1179:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1182:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1188:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1191:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1197:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    119e:	9d                                              	popf
    119f:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    11a5:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    11ae:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    11b1:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    11b5:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    11b9:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    11bd:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    11c1:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    11c5:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    11c9:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    11cd:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    11d1:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    11d5:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    11d9:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    11dd:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    11e1:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    11e5:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    11e9:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 11f0 <native_pc_12>

00000000000011f0 <native_pc_12>:
    11f0:	48 89 e0                                        	mov    rax,rsp
    11f3:	66 50                                           	push   ax
    11f5:	66 5a                                           	pop    dx

00000000000011f7 <native_next_12>:
    11f7:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    11fc:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1203 <native_next_12+0xc>
    1203:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1209:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    120f:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1215:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    121b:	41 57                                           	push   r15
    121d:	9c                                              	pushf
    121e:	50                                              	push   rax
    121f:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1224:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    122c:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    1234:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    123c:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    1244:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1248:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    124c:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1250:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    1254:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1258:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    125c:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1260:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    1264:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1268:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    126c:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1270:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1274:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1278:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    127d:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1284 <native_next_12+0x8d>
    1284:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1288:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    128c:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    128f:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1294:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    129b:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    12a0:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    12a4:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    12ac:	48 83 c4 18                                     	add    rsp,0x18
    12b0:	5f                                              	pop    rdi
    12b1:	41 5f                                           	pop    r15
    12b3:	41 5e                                           	pop    r14
    12b5:	41 5d                                           	pop    r13
    12b7:	41 5c                                           	pop    r12
    12b9:	5d                                              	pop    rbp
    12ba:	5b                                              	pop    rbx
    12bb:	c3                                              	ret

00000000000012bc <native_13>:
    12bc:	53                                              	push   rbx
    12bd:	55                                              	push   rbp
    12be:	41 54                                           	push   r12
    12c0:	41 55                                           	push   r13
    12c2:	41 56                                           	push   r14
    12c4:	41 57                                           	push   r15
    12c6:	57                                              	push   rdi
    12c7:	49 89 ff                                        	mov    r15,rdi
    12ca:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    12d3:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    12d9:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    12e2:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    12e8:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    12f1:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    12f7:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1300:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1306:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    130d:	9d                                              	popf
    130e:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1314:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    131d:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1320:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1324:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1328:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    132c:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1330:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1334:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1338:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    133c:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1340:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1344:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1348:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    134c:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1350:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1354:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1358:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 135f <native_pc_13>

000000000000135f <native_pc_13>:
    135f:	48 89 e0                                        	mov    rax,rsp
    1362:	b0 01                                           	mov    al,0x1

0000000000001364 <native_next_13>:
    1364:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1369:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1370 <native_next_13+0xc>
    1370:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1376:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    137c:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1382:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1388:	41 57                                           	push   r15
    138a:	9c                                              	pushf
    138b:	50                                              	push   rax
    138c:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1391:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1399:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    13a1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    13a9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    13b1:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    13b5:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    13b9:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    13bd:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    13c1:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    13c5:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    13c9:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    13cd:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    13d1:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    13d5:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    13d9:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    13dd:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    13e1:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    13e5:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    13ea:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 13f1 <native_next_13+0x8d>
    13f1:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    13f5:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    13f9:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    13fc:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1401:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1408:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    140d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1411:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1419:	48 83 c4 18                                     	add    rsp,0x18
    141d:	5f                                              	pop    rdi
    141e:	41 5f                                           	pop    r15
    1420:	41 5e                                           	pop    r14
    1422:	41 5d                                           	pop    r13
    1424:	41 5c                                           	pop    r12
    1426:	5d                                              	pop    rbp
    1427:	5b                                              	pop    rbx
    1428:	c3                                              	ret

0000000000001429 <native_14>:
    1429:	53                                              	push   rbx
    142a:	55                                              	push   rbp
    142b:	41 54                                           	push   r12
    142d:	41 55                                           	push   r13
    142f:	41 56                                           	push   r14
    1431:	41 57                                           	push   r15
    1433:	57                                              	push   rdi
    1434:	49 89 ff                                        	mov    r15,rdi
    1437:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1440:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1446:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    144f:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1455:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    145e:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1464:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    146d:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1473:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    147a:	9d                                              	popf
    147b:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1481:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    148a:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    148d:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1491:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1495:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1499:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    149d:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    14a1:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    14a5:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    14a9:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    14ad:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    14b1:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    14b5:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    14b9:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    14bd:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    14c1:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    14c5:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 14cc <native_pc_14>

00000000000014cc <native_pc_14>:
    14cc:	48 89 e0                                        	mov    rax,rsp
    14cf:	b4 01                                           	mov    ah,0x1

00000000000014d1 <native_next_14>:
    14d1:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    14d6:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 14dd <native_next_14+0xc>
    14dd:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    14e3:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    14e9:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    14ef:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    14f5:	41 57                                           	push   r15
    14f7:	9c                                              	pushf
    14f8:	50                                              	push   rax
    14f9:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    14fe:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1506:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    150e:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1516:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    151e:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1522:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1526:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    152a:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    152e:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1532:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1536:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    153a:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    153e:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1542:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1546:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    154a:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    154e:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1552:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1557:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 155e <native_next_14+0x8d>
    155e:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1562:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1566:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1569:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    156e:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1575:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    157a:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    157e:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1586:	48 83 c4 18                                     	add    rsp,0x18
    158a:	5f                                              	pop    rdi
    158b:	41 5f                                           	pop    r15
    158d:	41 5e                                           	pop    r14
    158f:	41 5d                                           	pop    r13
    1591:	41 5c                                           	pop    r12
    1593:	5d                                              	pop    rbp
    1594:	5b                                              	pop    rbx
    1595:	c3                                              	ret

0000000000001596 <native_15>:
    1596:	53                                              	push   rbx
    1597:	55                                              	push   rbp
    1598:	41 54                                           	push   r12
    159a:	41 55                                           	push   r13
    159c:	41 56                                           	push   r14
    159e:	41 57                                           	push   r15
    15a0:	57                                              	push   rdi
    15a1:	49 89 ff                                        	mov    r15,rdi
    15a4:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    15ad:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    15b3:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    15bc:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    15c2:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    15cb:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    15d1:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    15da:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    15e0:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    15e7:	9d                                              	popf
    15e8:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    15ee:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    15f7:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    15fa:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    15fe:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1602:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1606:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    160a:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    160e:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1612:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1616:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    161a:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    161e:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1622:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1626:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    162a:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    162e:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1632:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1639 <native_pc_15>

0000000000001639 <native_pc_15>:
    1639:	48 89 e0                                        	mov    rax,rsp
    163c:	66 b8 01 00                                     	mov    ax,0x1

0000000000001640 <native_next_15>:
    1640:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1645:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 164c <native_next_15+0xc>
    164c:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1652:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1658:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    165e:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1664:	41 57                                           	push   r15
    1666:	9c                                              	pushf
    1667:	50                                              	push   rax
    1668:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    166d:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1675:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    167d:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1685:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    168d:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1691:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1695:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1699:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    169d:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    16a1:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    16a5:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    16a9:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    16ad:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    16b1:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    16b5:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    16b9:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    16bd:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    16c1:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    16c6:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 16cd <native_next_15+0x8d>
    16cd:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    16d1:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    16d5:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    16d8:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    16dd:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    16e4:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    16e9:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    16ed:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    16f5:	48 83 c4 18                                     	add    rsp,0x18
    16f9:	5f                                              	pop    rdi
    16fa:	41 5f                                           	pop    r15
    16fc:	41 5e                                           	pop    r14
    16fe:	41 5d                                           	pop    r13
    1700:	41 5c                                           	pop    r12
    1702:	5d                                              	pop    rbp
    1703:	5b                                              	pop    rbx
    1704:	c3                                              	ret

0000000000001705 <native_16>:
    1705:	53                                              	push   rbx
    1706:	55                                              	push   rbp
    1707:	41 54                                           	push   r12
    1709:	41 55                                           	push   r13
    170b:	41 56                                           	push   r14
    170d:	41 57                                           	push   r15
    170f:	57                                              	push   rdi
    1710:	49 89 ff                                        	mov    r15,rdi
    1713:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    171c:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1722:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    172b:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1731:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    173a:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1740:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1749:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    174f:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1756:	9d                                              	popf
    1757:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    175d:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1766:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1769:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    176d:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1771:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1775:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1779:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    177d:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1781:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1785:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1789:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    178d:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1791:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1795:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1799:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    179d:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    17a1:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 17a8 <native_pc_16>

00000000000017a8 <native_pc_16>:
    17a8:	48 89 e0                                        	mov    rax,rsp
    17ab:	b8 01 00 00 00                                  	mov    eax,0x1

00000000000017b0 <native_next_16>:
    17b0:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    17b5:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 17bc <native_next_16+0xc>
    17bc:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    17c2:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    17c8:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    17ce:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    17d4:	41 57                                           	push   r15
    17d6:	9c                                              	pushf
    17d7:	50                                              	push   rax
    17d8:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    17dd:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    17e5:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    17ed:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    17f5:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    17fd:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1801:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1805:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1809:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    180d:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1811:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1815:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1819:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    181d:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1821:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1825:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1829:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    182d:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1831:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1836:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 183d <native_next_16+0x8d>
    183d:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1841:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1845:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1848:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    184d:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1854:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1859:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    185d:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1865:	48 83 c4 18                                     	add    rsp,0x18
    1869:	5f                                              	pop    rdi
    186a:	41 5f                                           	pop    r15
    186c:	41 5e                                           	pop    r14
    186e:	41 5d                                           	pop    r13
    1870:	41 5c                                           	pop    r12
    1872:	5d                                              	pop    rbp
    1873:	5b                                              	pop    rbx
    1874:	c3                                              	ret

0000000000001875 <native_17>:
    1875:	53                                              	push   rbx
    1876:	55                                              	push   rbp
    1877:	41 54                                           	push   r12
    1879:	41 55                                           	push   r13
    187b:	41 56                                           	push   r14
    187d:	41 57                                           	push   r15
    187f:	57                                              	push   rdi
    1880:	49 89 ff                                        	mov    r15,rdi
    1883:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    188c:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1892:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    189b:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    18a1:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    18aa:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    18b0:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    18b9:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    18bf:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    18c6:	9d                                              	popf
    18c7:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    18cd:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    18d6:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    18d9:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    18dd:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    18e1:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    18e5:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    18e9:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    18ed:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    18f1:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    18f5:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    18f9:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    18fd:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1901:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1905:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1909:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    190d:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1911:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1918 <native_pc_17>

0000000000001918 <native_pc_17>:
    1918:	48 89 e0                                        	mov    rax,rsp
    191b:	04 01                                           	add    al,0x1

000000000000191d <native_next_17>:
    191d:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1922:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1929 <native_next_17+0xc>
    1929:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    192f:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1935:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    193b:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1941:	41 57                                           	push   r15
    1943:	9c                                              	pushf
    1944:	50                                              	push   rax
    1945:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    194a:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1952:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    195a:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1962:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    196a:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    196e:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1972:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1976:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    197a:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    197e:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1982:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1986:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    198a:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    198e:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1992:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1996:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    199a:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    199e:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    19a3:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 19aa <native_next_17+0x8d>
    19aa:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    19ae:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    19b2:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    19b5:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    19ba:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    19c1:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    19c6:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    19ca:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    19d2:	48 83 c4 18                                     	add    rsp,0x18
    19d6:	5f                                              	pop    rdi
    19d7:	41 5f                                           	pop    r15
    19d9:	41 5e                                           	pop    r14
    19db:	41 5d                                           	pop    r13
    19dd:	41 5c                                           	pop    r12
    19df:	5d                                              	pop    rbp
    19e0:	5b                                              	pop    rbx
    19e1:	c3                                              	ret

00000000000019e2 <native_18>:
    19e2:	53                                              	push   rbx
    19e3:	55                                              	push   rbp
    19e4:	41 54                                           	push   r12
    19e6:	41 55                                           	push   r13
    19e8:	41 56                                           	push   r14
    19ea:	41 57                                           	push   r15
    19ec:	57                                              	push   rdi
    19ed:	49 89 ff                                        	mov    r15,rdi
    19f0:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    19f9:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    19ff:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1a08:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1a0e:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1a17:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1a1d:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1a26:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1a2c:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1a33:	9d                                              	popf
    1a34:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1a3a:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1a43:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1a46:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1a4a:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1a4e:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1a52:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1a56:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1a5a:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1a5e:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1a62:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1a66:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1a6a:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1a6e:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1a72:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1a76:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1a7a:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1a7e:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1a85 <native_pc_18>

0000000000001a85 <native_pc_18>:
    1a85:	48 89 e0                                        	mov    rax,rsp
    1a88:	80 c4 01                                        	add    ah,0x1

0000000000001a8b <native_next_18>:
    1a8b:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1a90:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1a97 <native_next_18+0xc>
    1a97:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1a9d:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1aa3:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1aa9:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1aaf:	41 57                                           	push   r15
    1ab1:	9c                                              	pushf
    1ab2:	50                                              	push   rax
    1ab3:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1ab8:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1ac0:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    1ac8:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1ad0:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    1ad8:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1adc:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1ae0:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1ae4:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    1ae8:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1aec:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1af0:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1af4:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    1af8:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1afc:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1b00:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1b04:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1b08:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1b0c:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1b11:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1b18 <native_next_18+0x8d>
    1b18:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1b1c:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1b20:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1b23:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1b28:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1b2f:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1b34:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1b38:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1b40:	48 83 c4 18                                     	add    rsp,0x18
    1b44:	5f                                              	pop    rdi
    1b45:	41 5f                                           	pop    r15
    1b47:	41 5e                                           	pop    r14
    1b49:	41 5d                                           	pop    r13
    1b4b:	41 5c                                           	pop    r12
    1b4d:	5d                                              	pop    rbp
    1b4e:	5b                                              	pop    rbx
    1b4f:	c3                                              	ret

0000000000001b50 <native_19>:
    1b50:	53                                              	push   rbx
    1b51:	55                                              	push   rbp
    1b52:	41 54                                           	push   r12
    1b54:	41 55                                           	push   r13
    1b56:	41 56                                           	push   r14
    1b58:	41 57                                           	push   r15
    1b5a:	57                                              	push   rdi
    1b5b:	49 89 ff                                        	mov    r15,rdi
    1b5e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1b67:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1b6d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1b76:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1b7c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1b85:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1b8b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1b94:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1b9a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1ba1:	9d                                              	popf
    1ba2:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1ba8:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1bb1:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1bb4:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1bb8:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1bbc:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1bc0:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1bc4:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1bc8:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1bcc:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1bd0:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1bd4:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1bd8:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1bdc:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1be0:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1be4:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1be8:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1bec:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1bf3 <native_pc_19>

0000000000001bf3 <native_pc_19>:
    1bf3:	48 89 e0                                        	mov    rax,rsp
    1bf6:	66 83 c0 01                                     	add    ax,0x1

0000000000001bfa <native_next_19>:
    1bfa:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1bff:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1c06 <native_next_19+0xc>
    1c06:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1c0c:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1c12:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1c18:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1c1e:	41 57                                           	push   r15
    1c20:	9c                                              	pushf
    1c21:	50                                              	push   rax
    1c22:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1c27:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1c2f:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    1c37:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1c3f:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    1c47:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1c4b:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1c4f:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1c53:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    1c57:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1c5b:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1c5f:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1c63:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    1c67:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1c6b:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1c6f:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1c73:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1c77:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1c7b:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1c80:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1c87 <native_next_19+0x8d>
    1c87:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1c8b:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1c8f:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1c92:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1c97:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1c9e:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1ca3:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1ca7:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1caf:	48 83 c4 18                                     	add    rsp,0x18
    1cb3:	5f                                              	pop    rdi
    1cb4:	41 5f                                           	pop    r15
    1cb6:	41 5e                                           	pop    r14
    1cb8:	41 5d                                           	pop    r13
    1cba:	41 5c                                           	pop    r12
    1cbc:	5d                                              	pop    rbp
    1cbd:	5b                                              	pop    rbx
    1cbe:	c3                                              	ret

0000000000001cbf <native_20>:
    1cbf:	53                                              	push   rbx
    1cc0:	55                                              	push   rbp
    1cc1:	41 54                                           	push   r12
    1cc3:	41 55                                           	push   r13
    1cc5:	41 56                                           	push   r14
    1cc7:	41 57                                           	push   r15
    1cc9:	57                                              	push   rdi
    1cca:	49 89 ff                                        	mov    r15,rdi
    1ccd:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1cd6:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1cdc:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1ce5:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1ceb:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1cf4:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1cfa:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1d03:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1d09:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1d10:	9d                                              	popf
    1d11:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1d17:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1d20:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1d23:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1d27:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1d2b:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1d2f:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1d33:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1d37:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1d3b:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1d3f:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1d43:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1d47:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1d4b:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1d4f:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1d53:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1d57:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1d5b:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1d62 <native_pc_20>

0000000000001d62 <native_pc_20>:
    1d62:	48 89 e0                                        	mov    rax,rsp
    1d65:	83 c0 01                                        	add    eax,0x1

0000000000001d68 <native_next_20>:
    1d68:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1d6d:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1d74 <native_next_20+0xc>
    1d74:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1d7a:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1d80:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1d86:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1d8c:	41 57                                           	push   r15
    1d8e:	9c                                              	pushf
    1d8f:	50                                              	push   rax
    1d90:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1d95:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1d9d:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    1da5:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1dad:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    1db5:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1db9:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1dbd:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1dc1:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    1dc5:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1dc9:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1dcd:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1dd1:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    1dd5:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1dd9:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1ddd:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1de1:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1de5:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1de9:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1dee:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1df5 <native_next_20+0x8d>
    1df5:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1df9:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1dfd:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1e00:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1e05:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1e0c:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1e11:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1e15:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1e1d:	48 83 c4 18                                     	add    rsp,0x18
    1e21:	5f                                              	pop    rdi
    1e22:	41 5f                                           	pop    r15
    1e24:	41 5e                                           	pop    r14
    1e26:	41 5d                                           	pop    r13
    1e28:	41 5c                                           	pop    r12
    1e2a:	5d                                              	pop    rbp
    1e2b:	5b                                              	pop    rbx
    1e2c:	c3                                              	ret

0000000000001e2d <native_21>:
    1e2d:	53                                              	push   rbx
    1e2e:	55                                              	push   rbp
    1e2f:	41 54                                           	push   r12
    1e31:	41 55                                           	push   r13
    1e33:	41 56                                           	push   r14
    1e35:	41 57                                           	push   r15
    1e37:	57                                              	push   rdi
    1e38:	49 89 ff                                        	mov    r15,rdi
    1e3b:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1e44:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1e4a:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1e53:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1e59:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1e62:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1e68:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1e71:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1e77:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1e7e:	9d                                              	popf
    1e7f:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1e85:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    1e8e:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    1e91:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    1e95:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    1e99:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    1e9d:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    1ea1:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    1ea5:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    1ea9:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    1ead:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    1eb1:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    1eb5:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    1eb9:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    1ebd:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    1ec1:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    1ec5:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    1ec9:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 1ed0 <native_pc_21>

0000000000001ed0 <native_pc_21>:
    1ed0:	48 89 e0                                        	mov    rax,rsp
    1ed3:	88 44 24 f0                                     	mov    BYTE PTR [rsp-0x10],al
    1ed7:	0f b6 54 24 f0                                  	movzx  edx,BYTE PTR [rsp-0x10]

0000000000001edc <native_next_21>:
    1edc:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    1ee1:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 1ee8 <native_next_21+0xc>
    1ee8:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    1eee:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    1ef4:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    1efa:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    1f00:	41 57                                           	push   r15
    1f02:	9c                                              	pushf
    1f03:	50                                              	push   rax
    1f04:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    1f09:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    1f11:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    1f19:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    1f21:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    1f29:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    1f2d:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    1f31:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    1f35:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    1f39:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    1f3d:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    1f41:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    1f45:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    1f49:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    1f4d:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    1f51:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    1f55:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    1f59:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    1f5d:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    1f62:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1f69 <native_next_21+0x8d>
    1f69:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    1f6d:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    1f71:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    1f74:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    1f79:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    1f80:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    1f85:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    1f89:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    1f91:	48 83 c4 18                                     	add    rsp,0x18
    1f95:	5f                                              	pop    rdi
    1f96:	41 5f                                           	pop    r15
    1f98:	41 5e                                           	pop    r14
    1f9a:	41 5d                                           	pop    r13
    1f9c:	41 5c                                           	pop    r12
    1f9e:	5d                                              	pop    rbp
    1f9f:	5b                                              	pop    rbx
    1fa0:	c3                                              	ret

0000000000001fa1 <native_22>:
    1fa1:	53                                              	push   rbx
    1fa2:	55                                              	push   rbp
    1fa3:	41 54                                           	push   r12
    1fa5:	41 55                                           	push   r13
    1fa7:	41 56                                           	push   r14
    1fa9:	41 57                                           	push   r15
    1fab:	57                                              	push   rdi
    1fac:	49 89 ff                                        	mov    r15,rdi
    1faf:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    1fb8:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    1fbe:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    1fc7:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    1fcd:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    1fd6:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    1fdc:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    1fe5:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1feb:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    1ff2:	9d                                              	popf
    1ff3:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    1ff9:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    2002:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    2005:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    2009:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    200d:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    2011:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    2015:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    2019:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    201d:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    2021:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    2025:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    2029:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    202d:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    2031:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    2035:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    2039:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    203d:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 2044 <native_pc_22>

0000000000002044 <native_pc_22>:
    2044:	48 89 e0                                        	mov    rax,rsp
    2047:	66 89 44 24 f0                                  	mov    WORD PTR [rsp-0x10],ax
    204c:	0f b7 54 24 f0                                  	movzx  edx,WORD PTR [rsp-0x10]

0000000000002051 <native_next_22>:
    2051:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    2056:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 205d <native_next_22+0xc>
    205d:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    2063:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    2069:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    206f:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    2075:	41 57                                           	push   r15
    2077:	9c                                              	pushf
    2078:	50                                              	push   rax
    2079:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    207e:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    2086:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    208e:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    2096:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    209e:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    20a2:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    20a6:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    20aa:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    20ae:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    20b2:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    20b6:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    20ba:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    20be:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    20c2:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    20c6:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    20ca:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    20ce:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    20d2:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    20d7:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 20de <native_next_22+0x8d>
    20de:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    20e2:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    20e6:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    20e9:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    20ee:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    20f5:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    20fa:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    20fe:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    2106:	48 83 c4 18                                     	add    rsp,0x18
    210a:	5f                                              	pop    rdi
    210b:	41 5f                                           	pop    r15
    210d:	41 5e                                           	pop    r14
    210f:	41 5d                                           	pop    r13
    2111:	41 5c                                           	pop    r12
    2113:	5d                                              	pop    rbp
    2114:	5b                                              	pop    rbx
    2115:	c3                                              	ret

0000000000002116 <native_23>:
    2116:	53                                              	push   rbx
    2117:	55                                              	push   rbp
    2118:	41 54                                           	push   r12
    211a:	41 55                                           	push   r13
    211c:	41 56                                           	push   r14
    211e:	41 57                                           	push   r15
    2120:	57                                              	push   rdi
    2121:	49 89 ff                                        	mov    r15,rdi
    2124:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    212d:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    2133:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    213c:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    2142:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    214b:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    2151:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    215a:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    2160:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    2167:	9d                                              	popf
    2168:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    216e:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    2177:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    217a:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    217e:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    2182:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    2186:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    218a:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    218e:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    2192:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    2196:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    219a:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    219e:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    21a2:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    21a6:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    21aa:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    21ae:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    21b2:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 21b9 <native_pc_23>

00000000000021b9 <native_pc_23>:
    21b9:	48 89 e0                                        	mov    rax,rsp
    21bc:	89 44 24 f0                                     	mov    DWORD PTR [rsp-0x10],eax
    21c0:	8b 54 24 f0                                     	mov    edx,DWORD PTR [rsp-0x10]

00000000000021c4 <native_next_23>:
    21c4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    21c9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 21d0 <native_next_23+0xc>
    21d0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    21d6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    21dc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    21e2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    21e8:	41 57                                           	push   r15
    21ea:	9c                                              	pushf
    21eb:	50                                              	push   rax
    21ec:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    21f1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    21f9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    2201:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    2209:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    2211:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    2215:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    2219:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    221d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    2221:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    2225:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    2229:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    222d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    2231:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    2235:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    2239:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    223d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    2241:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    2245:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    224a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 2251 <native_next_23+0x8d>
    2251:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    2255:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    2259:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    225c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    2261:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    2268:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    226d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    2271:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    2279:	48 83 c4 18                                     	add    rsp,0x18
    227d:	5f                                              	pop    rdi
    227e:	41 5f                                           	pop    r15
    2280:	41 5e                                           	pop    r14
    2282:	41 5d                                           	pop    r13
    2284:	41 5c                                           	pop    r12
    2286:	5d                                              	pop    rbp
    2287:	5b                                              	pop    rbx
    2288:	c3                                              	ret

0000000000002289 <native_24>:
    2289:	53                                              	push   rbx
    228a:	55                                              	push   rbp
    228b:	41 54                                           	push   r12
    228d:	41 55                                           	push   r13
    228f:	41 56                                           	push   r14
    2291:	41 57                                           	push   r15
    2293:	57                                              	push   rdi
    2294:	49 89 ff                                        	mov    r15,rdi
    2297:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
    22a0:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
    22a6:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
    22af:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
    22b5:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
    22be:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
    22c4:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
    22cd:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    22d3:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
    22da:	9d                                              	popf
    22db:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
    22e1:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
    22ea:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
    22ed:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
    22f1:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
    22f5:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
    22f9:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
    22fd:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
    2301:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
    2305:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
    2309:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
    230d:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
    2311:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
    2315:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
    2319:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
    231d:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
    2321:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
    2325:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 232c <native_pc_24>

000000000000232c <native_pc_24>:
    232c:	48 89 e0                                        	mov    rax,rsp
    232f:	48 89 44 24 f0                                  	mov    QWORD PTR [rsp-0x10],rax
    2334:	48 8b 54 24 f0                                  	mov    rdx,QWORD PTR [rsp-0x10]

0000000000002339 <native_next_24>:
    2339:	66 48 0f 6e ec                                  	movq   xmm5,rsp
    233e:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 2345 <native_next_24+0xc>
    2345:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
    234b:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
    2351:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
    2357:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
    235d:	41 57                                           	push   r15
    235f:	9c                                              	pushf
    2360:	50                                              	push   rax
    2361:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
    2366:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
    236e:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
    2376:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
    237e:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
    2386:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
    238a:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
    238e:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
    2392:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
    2396:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
    239a:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
    239e:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
    23a2:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
    23a6:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
    23aa:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
    23ae:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
    23b2:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
    23b6:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
    23ba:	66 48 0f 7e ea                                  	movq   rdx,xmm5
    23bf:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 23c6 <native_next_24+0x8d>
    23c6:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
    23ca:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
    23ce:	48 89 10                                        	mov    QWORD PTR [rax],rdx
    23d1:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
    23d6:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
    23dd:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
    23e2:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
    23e6:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
    23ee:	48 83 c4 18                                     	add    rsp,0x18
    23f2:	5f                                              	pop    rdi
    23f3:	41 5f                                           	pop    r15
    23f5:	41 5e                                           	pop    r14
    23f7:	41 5d                                           	pop    r13
    23f9:	41 5c                                           	pop    r12
    23fb:	5d                                              	pop    rbp
    23fc:	5b                                              	pop    rbx
    23fd:	c3                                              	ret
