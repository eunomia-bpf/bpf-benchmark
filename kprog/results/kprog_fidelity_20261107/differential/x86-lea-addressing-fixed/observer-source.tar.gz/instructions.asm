
build-x86-lea-addressing-fixed/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	66 98                                           	cbw
   9:	98                                              	cwde
   a:	48 98                                           	cdqe
   c:	66 99                                           	cwd
   e:	99                                              	cdq
   f:	48 99                                           	cqo
  11:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
  14:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
  17:	48 89 e0                                        	mov    rax,rsp
  1a:	89 e0                                           	mov    eax,esp
  1c:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  21:	48 83 fc 00                                     	cmp    rsp,0x0
  25:	48 89 c4                                        	mov    rsp,rax
  28:	89 c4                                           	mov    esp,eax
  2a:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
  2f:	48 83 c4 10                                     	add    rsp,0x10
  33:	54                                              	push   rsp
  34:	5c                                              	pop    rsp
  35:	66 54                                           	push   sp
  37:	66 5c                                           	pop    sp
  39:	68 00 00 00 80                                  	push   0xffffffff80000000
  3e:	6a 80                                           	push   0xffffffffffffff80
  40:	6a ff                                           	push   0xffffffffffffffff
  42:	6a 00                                           	push   0x0
  44:	6a 01                                           	push   0x1
  46:	6a 7f                                           	push   0x7f
  48:	68 80 00 00 00                                  	push   0x80
  4d:	68 78 56 34 12                                  	push   0x12345678
  52:	66 6a f9                                        	pushw  0xfff9
  55:	ff 77 08                                        	push   QWORD PTR [rdi+0x8]
  58:	66 ff 77 08                                     	push   WORD PTR [rdi+0x8]
  5c:	8f 47 08                                        	pop    QWORD PTR [rdi+0x8]
  5f:	66 8f 47 08                                     	pop    WORD PTR [rdi+0x8]
  63:	ff 74 24 f0                                     	push   QWORD PTR [rsp-0x10]
  67:	8f 44 24 f0                                     	pop    QWORD PTR [rsp-0x10]
  6b:	66 48 53                                        	data16 rex.W push rbx
  6e:	48                                              	rex.W
  6f:	66 53                                           	push   bx
  71:	66 48 ff f3                                     	data16 rex.W push rbx
  75:	48                                              	rex.W
  76:	66 ff f3                                        	push   bx
  79:	66 48 58                                        	data16 rex.W pop rax
  7c:	48                                              	rex.W
  7d:	66 58                                           	pop    ax
  7f:	66 48 8f c0                                     	data16 rex.W pop rax
  83:	48                                              	rex.W
  84:	66 8f c0                                        	pop    ax
  87:	88 d8                                           	mov    al,bl
  89:	b0 7f                                           	mov    al,0x7f
  8b:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  8e:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  91:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  95:	00 d8                                           	add    al,bl
  97:	04 7f                                           	add    al,0x7f
  99:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  9c:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  a0:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  a3:	10 d8                                           	adc    al,bl
  a5:	14 7f                                           	adc    al,0x7f
  a7:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  aa:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  ae:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  b1:	28 d8                                           	sub    al,bl
  b3:	2c 7f                                           	sub    al,0x7f
  b5:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  b8:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  bc:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  bf:	18 d8                                           	sbb    al,bl
  c1:	1c 7f                                           	sbb    al,0x7f
  c3:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  c6:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  ca:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  cd:	38 d8                                           	cmp    al,bl
  cf:	3c 7f                                           	cmp    al,0x7f
  d1:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  d4:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  d8:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  db:	84 d8                                           	test   al,bl
  dd:	a8 7f                                           	test   al,0x7f
  df:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  e2:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  e6:	20 d8                                           	and    al,bl
  e8:	24 7f                                           	and    al,0x7f
  ea:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  ed:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  f0:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  f4:	08 d8                                           	or     al,bl
  f6:	0c 7f                                           	or     al,0x7f
  f8:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  fb:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  fe:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
 102:	30 d8                                           	xor    al,bl
 104:	34 7f                                           	xor    al,0x7f
 106:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
 109:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
 10c:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
 110:	fe c0                                           	inc    al
 112:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
 115:	fe c8                                           	dec    al
 117:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
 11a:	f6 d8                                           	neg    al
 11c:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
 11f:	f6 d0                                           	not    al
 121:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
 124:	86 d8                                           	xchg   al,bl
 126:	c0 e0 00                                        	shl    al,0x0
 129:	d0 e0                                           	shl    al,1
 12b:	c0 e0 07                                        	shl    al,0x7
 12e:	c0 e0 08                                        	shl    al,0x8
 131:	c0 e0 0f                                        	shl    al,0xf
 134:	c0 e0 10                                        	shl    al,0x10
 137:	c0 e0 1f                                        	shl    al,0x1f
 13a:	c0 e0 20                                        	shl    al,0x20
 13d:	c0 e0 3f                                        	shl    al,0x3f
 140:	c0 e0 40                                        	shl    al,0x40
 143:	c0 e0 ff                                        	shl    al,0xff
 146:	d2 e0                                           	shl    al,cl
 148:	c0 e8 00                                        	shr    al,0x0
 14b:	d0 e8                                           	shr    al,1
 14d:	c0 e8 07                                        	shr    al,0x7
 150:	c0 e8 08                                        	shr    al,0x8
 153:	c0 e8 0f                                        	shr    al,0xf
 156:	c0 e8 10                                        	shr    al,0x10
 159:	c0 e8 1f                                        	shr    al,0x1f
 15c:	c0 e8 20                                        	shr    al,0x20
 15f:	c0 e8 3f                                        	shr    al,0x3f
 162:	c0 e8 40                                        	shr    al,0x40
 165:	c0 e8 ff                                        	shr    al,0xff
 168:	d2 e8                                           	shr    al,cl
 16a:	c0 f8 00                                        	sar    al,0x0
 16d:	d0 f8                                           	sar    al,1
 16f:	c0 f8 07                                        	sar    al,0x7
 172:	c0 f8 08                                        	sar    al,0x8
 175:	c0 f8 0f                                        	sar    al,0xf
 178:	c0 f8 10                                        	sar    al,0x10
 17b:	c0 f8 1f                                        	sar    al,0x1f
 17e:	c0 f8 20                                        	sar    al,0x20
 181:	c0 f8 3f                                        	sar    al,0x3f
 184:	c0 f8 40                                        	sar    al,0x40
 187:	c0 f8 ff                                        	sar    al,0xff
 18a:	d2 f8                                           	sar    al,cl
 18c:	c0 c0 00                                        	rol    al,0x0
 18f:	d0 c0                                           	rol    al,1
 191:	c0 c0 07                                        	rol    al,0x7
 194:	c0 c0 08                                        	rol    al,0x8
 197:	c0 c0 0f                                        	rol    al,0xf
 19a:	c0 c0 10                                        	rol    al,0x10
 19d:	c0 c0 1f                                        	rol    al,0x1f
 1a0:	c0 c0 20                                        	rol    al,0x20
 1a3:	c0 c0 3f                                        	rol    al,0x3f
 1a6:	c0 c0 40                                        	rol    al,0x40
 1a9:	c0 c0 ff                                        	rol    al,0xff
 1ac:	d2 c0                                           	rol    al,cl
 1ae:	66 89 d8                                        	mov    ax,bx
 1b1:	66 b8 7f 00                                     	mov    ax,0x7f
 1b5:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 1b9:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 1bd:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 1c3:	66 01 d8                                        	add    ax,bx
 1c6:	66 83 c0 7f                                     	add    ax,0x7f
 1ca:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 1ce:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 1d3:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 1d7:	66 11 d8                                        	adc    ax,bx
 1da:	66 83 d0 7f                                     	adc    ax,0x7f
 1de:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 1e2:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 1e7:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 1eb:	66 29 d8                                        	sub    ax,bx
 1ee:	66 83 e8 7f                                     	sub    ax,0x7f
 1f2:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 1f6:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 1fb:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 1ff:	66 19 d8                                        	sbb    ax,bx
 202:	66 83 d8 7f                                     	sbb    ax,0x7f
 206:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 20a:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 20f:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 213:	66 39 d8                                        	cmp    ax,bx
 216:	66 83 f8 7f                                     	cmp    ax,0x7f
 21a:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 21e:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 223:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 227:	66 85 d8                                        	test   ax,bx
 22a:	66 a9 7f 00                                     	test   ax,0x7f
 22e:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 232:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 238:	66 21 d8                                        	and    ax,bx
 23b:	66 83 e0 7f                                     	and    ax,0x7f
 23f:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 243:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 247:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 24c:	66 09 d8                                        	or     ax,bx
 24f:	66 83 c8 7f                                     	or     ax,0x7f
 253:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 257:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 25b:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 260:	66 31 d8                                        	xor    ax,bx
 263:	66 83 f0 7f                                     	xor    ax,0x7f
 267:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 26b:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 26f:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 274:	66 ff c0                                        	inc    ax
 277:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 27b:	66 ff c8                                        	dec    ax
 27e:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 282:	66 f7 d8                                        	neg    ax
 285:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 289:	66 f7 d0                                        	not    ax
 28c:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 290:	66 93                                           	xchg   bx,ax
 292:	66 c1 e0 00                                     	shl    ax,0x0
 296:	66 d1 e0                                        	shl    ax,1
 299:	66 c1 e0 07                                     	shl    ax,0x7
 29d:	66 c1 e0 08                                     	shl    ax,0x8
 2a1:	66 c1 e0 0f                                     	shl    ax,0xf
 2a5:	66 c1 e0 10                                     	shl    ax,0x10
 2a9:	66 c1 e0 1f                                     	shl    ax,0x1f
 2ad:	66 c1 e0 20                                     	shl    ax,0x20
 2b1:	66 c1 e0 3f                                     	shl    ax,0x3f
 2b5:	66 c1 e0 40                                     	shl    ax,0x40
 2b9:	66 c1 e0 ff                                     	shl    ax,0xff
 2bd:	66 d3 e0                                        	shl    ax,cl
 2c0:	66 c1 e8 00                                     	shr    ax,0x0
 2c4:	66 d1 e8                                        	shr    ax,1
 2c7:	66 c1 e8 07                                     	shr    ax,0x7
 2cb:	66 c1 e8 08                                     	shr    ax,0x8
 2cf:	66 c1 e8 0f                                     	shr    ax,0xf
 2d3:	66 c1 e8 10                                     	shr    ax,0x10
 2d7:	66 c1 e8 1f                                     	shr    ax,0x1f
 2db:	66 c1 e8 20                                     	shr    ax,0x20
 2df:	66 c1 e8 3f                                     	shr    ax,0x3f
 2e3:	66 c1 e8 40                                     	shr    ax,0x40
 2e7:	66 c1 e8 ff                                     	shr    ax,0xff
 2eb:	66 d3 e8                                        	shr    ax,cl
 2ee:	66 c1 f8 00                                     	sar    ax,0x0
 2f2:	66 d1 f8                                        	sar    ax,1
 2f5:	66 c1 f8 07                                     	sar    ax,0x7
 2f9:	66 c1 f8 08                                     	sar    ax,0x8
 2fd:	66 c1 f8 0f                                     	sar    ax,0xf
 301:	66 c1 f8 10                                     	sar    ax,0x10
 305:	66 c1 f8 1f                                     	sar    ax,0x1f
 309:	66 c1 f8 20                                     	sar    ax,0x20
 30d:	66 c1 f8 3f                                     	sar    ax,0x3f
 311:	66 c1 f8 40                                     	sar    ax,0x40
 315:	66 c1 f8 ff                                     	sar    ax,0xff
 319:	66 d3 f8                                        	sar    ax,cl
 31c:	66 c1 c0 00                                     	rol    ax,0x0
 320:	66 d1 c0                                        	rol    ax,1
 323:	66 c1 c0 07                                     	rol    ax,0x7
 327:	66 c1 c0 08                                     	rol    ax,0x8
 32b:	66 c1 c0 0f                                     	rol    ax,0xf
 32f:	66 c1 c0 10                                     	rol    ax,0x10
 333:	66 c1 c0 1f                                     	rol    ax,0x1f
 337:	66 c1 c0 20                                     	rol    ax,0x20
 33b:	66 c1 c0 3f                                     	rol    ax,0x3f
 33f:	66 c1 c0 40                                     	rol    ax,0x40
 343:	66 c1 c0 ff                                     	rol    ax,0xff
 347:	66 d3 c0                                        	rol    ax,cl
 34a:	66 0f af c3                                     	imul   ax,bx
 34e:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 353:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 357:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 35c:	66 f3 0f b8 c3                                  	popcnt ax,bx
 361:	66 f7 f3                                        	div    bx
 364:	66 0f a3 d8                                     	bt     ax,bx
 368:	66 0f ba e0 07                                  	bt     ax,0x7
 36d:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 373:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 379:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 37f:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 384:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 389:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 38e:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 393:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 398:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 39d:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 3a2:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 3a7:	89 d8                                           	mov    eax,ebx
 3a9:	b8 7f 00 00 00                                  	mov    eax,0x7f
 3ae:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 3b1:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 3b4:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 3bb:	01 d8                                           	add    eax,ebx
 3bd:	83 c0 7f                                        	add    eax,0x7f
 3c0:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 3c3:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 3c7:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 3ca:	11 d8                                           	adc    eax,ebx
 3cc:	83 d0 7f                                        	adc    eax,0x7f
 3cf:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 3d2:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 3d6:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 3d9:	29 d8                                           	sub    eax,ebx
 3db:	83 e8 7f                                        	sub    eax,0x7f
 3de:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 3e1:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 3e5:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 3e8:	19 d8                                           	sbb    eax,ebx
 3ea:	83 d8 7f                                        	sbb    eax,0x7f
 3ed:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 3f0:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 3f4:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 3f7:	39 d8                                           	cmp    eax,ebx
 3f9:	83 f8 7f                                        	cmp    eax,0x7f
 3fc:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 3ff:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 403:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 406:	85 d8                                           	test   eax,ebx
 408:	a9 7f 00 00 00                                  	test   eax,0x7f
 40d:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 410:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 417:	21 d8                                           	and    eax,ebx
 419:	83 e0 7f                                        	and    eax,0x7f
 41c:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 41f:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 422:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 426:	09 d8                                           	or     eax,ebx
 428:	83 c8 7f                                        	or     eax,0x7f
 42b:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 42e:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 431:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 435:	31 d8                                           	xor    eax,ebx
 437:	83 f0 7f                                        	xor    eax,0x7f
 43a:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 43d:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 440:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 444:	ff c0                                           	inc    eax
 446:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 449:	ff c8                                           	dec    eax
 44b:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 44e:	f7 d8                                           	neg    eax
 450:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 453:	f7 d0                                           	not    eax
 455:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 458:	93                                              	xchg   ebx,eax
 459:	c1 e0 00                                        	shl    eax,0x0
 45c:	d1 e0                                           	shl    eax,1
 45e:	c1 e0 07                                        	shl    eax,0x7
 461:	c1 e0 08                                        	shl    eax,0x8
 464:	c1 e0 0f                                        	shl    eax,0xf
 467:	c1 e0 10                                        	shl    eax,0x10
 46a:	c1 e0 1f                                        	shl    eax,0x1f
 46d:	c1 e0 20                                        	shl    eax,0x20
 470:	c1 e0 3f                                        	shl    eax,0x3f
 473:	c1 e0 40                                        	shl    eax,0x40
 476:	c1 e0 ff                                        	shl    eax,0xff
 479:	d3 e0                                           	shl    eax,cl
 47b:	c1 e8 00                                        	shr    eax,0x0
 47e:	d1 e8                                           	shr    eax,1
 480:	c1 e8 07                                        	shr    eax,0x7
 483:	c1 e8 08                                        	shr    eax,0x8
 486:	c1 e8 0f                                        	shr    eax,0xf
 489:	c1 e8 10                                        	shr    eax,0x10
 48c:	c1 e8 1f                                        	shr    eax,0x1f
 48f:	c1 e8 20                                        	shr    eax,0x20
 492:	c1 e8 3f                                        	shr    eax,0x3f
 495:	c1 e8 40                                        	shr    eax,0x40
 498:	c1 e8 ff                                        	shr    eax,0xff
 49b:	d3 e8                                           	shr    eax,cl
 49d:	c1 f8 00                                        	sar    eax,0x0
 4a0:	d1 f8                                           	sar    eax,1
 4a2:	c1 f8 07                                        	sar    eax,0x7
 4a5:	c1 f8 08                                        	sar    eax,0x8
 4a8:	c1 f8 0f                                        	sar    eax,0xf
 4ab:	c1 f8 10                                        	sar    eax,0x10
 4ae:	c1 f8 1f                                        	sar    eax,0x1f
 4b1:	c1 f8 20                                        	sar    eax,0x20
 4b4:	c1 f8 3f                                        	sar    eax,0x3f
 4b7:	c1 f8 40                                        	sar    eax,0x40
 4ba:	c1 f8 ff                                        	sar    eax,0xff
 4bd:	d3 f8                                           	sar    eax,cl
 4bf:	c1 c0 00                                        	rol    eax,0x0
 4c2:	d1 c0                                           	rol    eax,1
 4c4:	c1 c0 07                                        	rol    eax,0x7
 4c7:	c1 c0 08                                        	rol    eax,0x8
 4ca:	c1 c0 0f                                        	rol    eax,0xf
 4cd:	c1 c0 10                                        	rol    eax,0x10
 4d0:	c1 c0 1f                                        	rol    eax,0x1f
 4d3:	c1 c0 20                                        	rol    eax,0x20
 4d6:	c1 c0 3f                                        	rol    eax,0x3f
 4d9:	c1 c0 40                                        	rol    eax,0x40
 4dc:	c1 c0 ff                                        	rol    eax,0xff
 4df:	d3 c0                                           	rol    eax,cl
 4e1:	0f af c3                                        	imul   eax,ebx
 4e4:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 4e8:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 4eb:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 4ef:	f3 0f b8 c3                                     	popcnt eax,ebx
 4f3:	f7 f3                                           	div    ebx
 4f5:	0f a3 d8                                        	bt     eax,ebx
 4f8:	0f ba e0 07                                     	bt     eax,0x7
 4fc:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 501:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 506:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 50b:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 50f:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 513:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 517:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 51b:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 51f:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 523:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 527:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 52b:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 52f:	0f c8                                           	bswap  eax
 531:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 536:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 53c:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 541:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 547:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 54c:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 551:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 557:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 55c:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 562:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 567:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 56d:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 573:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 57a:	48 89 d8                                        	mov    rax,rbx
 57d:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 584:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 588:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 58c:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 594:	48 01 d8                                        	add    rax,rbx
 597:	48 83 c0 7f                                     	add    rax,0x7f
 59b:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 59f:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 5a4:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 5a8:	48 11 d8                                        	adc    rax,rbx
 5ab:	48 83 d0 7f                                     	adc    rax,0x7f
 5af:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 5b3:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 5b8:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 5bc:	48 29 d8                                        	sub    rax,rbx
 5bf:	48 83 e8 7f                                     	sub    rax,0x7f
 5c3:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 5c7:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 5cc:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 5d0:	48 19 d8                                        	sbb    rax,rbx
 5d3:	48 83 d8 7f                                     	sbb    rax,0x7f
 5d7:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 5db:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 5e0:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 5e4:	48 39 d8                                        	cmp    rax,rbx
 5e7:	48 83 f8 7f                                     	cmp    rax,0x7f
 5eb:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 5ef:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 5f4:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 5f8:	48 85 d8                                        	test   rax,rbx
 5fb:	48 a9 7f 00 00 00                               	test   rax,0x7f
 601:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 605:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 60d:	48 21 d8                                        	and    rax,rbx
 610:	48 83 e0 7f                                     	and    rax,0x7f
 614:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 618:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 61c:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 621:	48 09 d8                                        	or     rax,rbx
 624:	48 83 c8 7f                                     	or     rax,0x7f
 628:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 62c:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 630:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 635:	48 31 d8                                        	xor    rax,rbx
 638:	48 83 f0 7f                                     	xor    rax,0x7f
 63c:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 640:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 644:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 649:	48 ff c0                                        	inc    rax
 64c:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 650:	48 ff c8                                        	dec    rax
 653:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 657:	48 f7 d8                                        	neg    rax
 65a:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 65e:	48 f7 d0                                        	not    rax
 661:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 665:	48 93                                           	xchg   rbx,rax
 667:	48 c1 e0 00                                     	shl    rax,0x0
 66b:	48 d1 e0                                        	shl    rax,1
 66e:	48 c1 e0 07                                     	shl    rax,0x7
 672:	48 c1 e0 08                                     	shl    rax,0x8
 676:	48 c1 e0 0f                                     	shl    rax,0xf
 67a:	48 c1 e0 10                                     	shl    rax,0x10
 67e:	48 c1 e0 1f                                     	shl    rax,0x1f
 682:	48 c1 e0 20                                     	shl    rax,0x20
 686:	48 c1 e0 3f                                     	shl    rax,0x3f
 68a:	48 c1 e0 40                                     	shl    rax,0x40
 68e:	48 c1 e0 ff                                     	shl    rax,0xff
 692:	48 d3 e0                                        	shl    rax,cl
 695:	48 c1 e8 00                                     	shr    rax,0x0
 699:	48 d1 e8                                        	shr    rax,1
 69c:	48 c1 e8 07                                     	shr    rax,0x7
 6a0:	48 c1 e8 08                                     	shr    rax,0x8
 6a4:	48 c1 e8 0f                                     	shr    rax,0xf
 6a8:	48 c1 e8 10                                     	shr    rax,0x10
 6ac:	48 c1 e8 1f                                     	shr    rax,0x1f
 6b0:	48 c1 e8 20                                     	shr    rax,0x20
 6b4:	48 c1 e8 3f                                     	shr    rax,0x3f
 6b8:	48 c1 e8 40                                     	shr    rax,0x40
 6bc:	48 c1 e8 ff                                     	shr    rax,0xff
 6c0:	48 d3 e8                                        	shr    rax,cl
 6c3:	48 c1 f8 00                                     	sar    rax,0x0
 6c7:	48 d1 f8                                        	sar    rax,1
 6ca:	48 c1 f8 07                                     	sar    rax,0x7
 6ce:	48 c1 f8 08                                     	sar    rax,0x8
 6d2:	48 c1 f8 0f                                     	sar    rax,0xf
 6d6:	48 c1 f8 10                                     	sar    rax,0x10
 6da:	48 c1 f8 1f                                     	sar    rax,0x1f
 6de:	48 c1 f8 20                                     	sar    rax,0x20
 6e2:	48 c1 f8 3f                                     	sar    rax,0x3f
 6e6:	48 c1 f8 40                                     	sar    rax,0x40
 6ea:	48 c1 f8 ff                                     	sar    rax,0xff
 6ee:	48 d3 f8                                        	sar    rax,cl
 6f1:	48 c1 c0 00                                     	rol    rax,0x0
 6f5:	48 d1 c0                                        	rol    rax,1
 6f8:	48 c1 c0 07                                     	rol    rax,0x7
 6fc:	48 c1 c0 08                                     	rol    rax,0x8
 700:	48 c1 c0 0f                                     	rol    rax,0xf
 704:	48 c1 c0 10                                     	rol    rax,0x10
 708:	48 c1 c0 1f                                     	rol    rax,0x1f
 70c:	48 c1 c0 20                                     	rol    rax,0x20
 710:	48 c1 c0 3f                                     	rol    rax,0x3f
 714:	48 c1 c0 40                                     	rol    rax,0x40
 718:	48 c1 c0 ff                                     	rol    rax,0xff
 71c:	48 d3 c0                                        	rol    rax,cl
 71f:	48 0f af c3                                     	imul   rax,rbx
 723:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 728:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 72c:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 731:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 736:	48 f7 f3                                        	div    rbx
 739:	48 0f a3 d8                                     	bt     rax,rbx
 73d:	48 0f ba e0 07                                  	bt     rax,0x7
 742:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 748:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 74e:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 754:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 759:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 75e:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 763:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 768:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 76d:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 772:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 777:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 77c:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 781:	48 0f c8                                        	bswap  rax
 784:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 789:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 78f:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 794:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 79a:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 79f:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 7a4:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 7aa:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 7af:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 7b5:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 7ba:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 7c0:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 7c6:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 7cd:	88 fc                                           	mov    ah,bh
 7cf:	b4 7f                                           	mov    ah,0x7f
 7d1:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 7d4:	00 fc                                           	add    ah,bh
 7d6:	80 c4 7f                                        	add    ah,0x7f
 7d9:	10 fc                                           	adc    ah,bh
 7db:	80 d4 7f                                        	adc    ah,0x7f
 7de:	28 fc                                           	sub    ah,bh
 7e0:	80 ec 7f                                        	sub    ah,0x7f
 7e3:	18 fc                                           	sbb    ah,bh
 7e5:	80 dc 7f                                        	sbb    ah,0x7f
 7e8:	38 fc                                           	cmp    ah,bh
 7ea:	80 fc 7f                                        	cmp    ah,0x7f
 7ed:	84 fc                                           	test   ah,bh
 7ef:	f6 c4 7f                                        	test   ah,0x7f
 7f2:	fe c4                                           	inc    ah
 7f4:	fe cc                                           	dec    ah
 7f6:	f6 dc                                           	neg    ah
 7f8:	f6 d4                                           	not    ah
 7fa:	66 0f b6 c3                                     	movzx  ax,bl
 7fe:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 803:	66 0f be c3                                     	movsx  ax,bl
 807:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 80c:	0f b6 c3                                        	movzx  eax,bl
 80f:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 813:	0f be c3                                        	movsx  eax,bl
 816:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 81a:	0f b7 c3                                        	movzx  eax,bx
 81d:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 821:	0f bf c3                                        	movsx  eax,bx
 824:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 828:	48 0f b6 c3                                     	movzx  rax,bl
 82c:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 831:	48 0f be c3                                     	movsx  rax,bl
 835:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 83a:	48 0f b7 c3                                     	movzx  rax,bx
 83e:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 843:	48 0f bf c3                                     	movsx  rax,bx
 847:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 84c:	48 63 c3                                        	movsxd rax,ebx
 84f:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 853:	66 8d 03                                        	lea    ax,[rbx]
 856:	66 8d 43 7f                                     	lea    ax,[rbx+0x7f]
 85a:	66 8d 43 80                                     	lea    ax,[rbx-0x80]
 85e:	66 8d 44 4b f9                                  	lea    ax,[rbx+rcx*2-0x7]
 863:	66 43 8d 84 88 ff ff ff 7f                      	lea    ax,[r8+r9*4+0x7fffffff]
 86c:	66 43 8d 84 c8 00 00 00 80                      	lea    ax,[r8+r9*8-0x80000000]
 875:	66 8d 04 cd 7f 00 00 00                         	lea    ax,[rcx*8+0x7f]
 87d:	66 8d 04 25 78 56 34 12                         	lea    ax,ds:0x12345678
 885:	67 66 8d 44 8b f9                               	lea    ax,[ebx+ecx*4-0x7]
 88b:	67 66 43 8d 44 c8 7f                            	lea    ax,[r8d+r9d*8+0x7f]
 892:	8d 03                                           	lea    eax,[rbx]
 894:	8d 43 7f                                        	lea    eax,[rbx+0x7f]
 897:	8d 43 80                                        	lea    eax,[rbx-0x80]
 89a:	8d 44 4b f9                                     	lea    eax,[rbx+rcx*2-0x7]
 89e:	43 8d 84 88 ff ff ff 7f                         	lea    eax,[r8+r9*4+0x7fffffff]
 8a6:	43 8d 84 c8 00 00 00 80                         	lea    eax,[r8+r9*8-0x80000000]
 8ae:	8d 04 cd 7f 00 00 00                            	lea    eax,[rcx*8+0x7f]
 8b5:	8d 04 25 78 56 34 12                            	lea    eax,ds:0x12345678
 8bc:	67 8d 44 8b f9                                  	lea    eax,[ebx+ecx*4-0x7]
 8c1:	67 43 8d 44 c8 7f                               	lea    eax,[r8d+r9d*8+0x7f]
 8c7:	48 8d 03                                        	lea    rax,[rbx]
 8ca:	48 8d 43 7f                                     	lea    rax,[rbx+0x7f]
 8ce:	48 8d 43 80                                     	lea    rax,[rbx-0x80]
 8d2:	48 8d 44 4b f9                                  	lea    rax,[rbx+rcx*2-0x7]
 8d7:	4b 8d 84 88 ff ff ff 7f                         	lea    rax,[r8+r9*4+0x7fffffff]
 8df:	4b 8d 84 c8 00 00 00 80                         	lea    rax,[r8+r9*8-0x80000000]
 8e7:	48 8d 04 cd 7f 00 00 00                         	lea    rax,[rcx*8+0x7f]
 8ef:	48 8d 04 25 78 56 34 12                         	lea    rax,ds:0x12345678
 8f7:	67 48 8d 44 8b f9                               	lea    rax,[ebx+ecx*4-0x7]
 8fd:	67 4b 8d 44 c8 7f                               	lea    rax,[r8d+r9d*8+0x7f]
 903:	66 44 8d 03                                     	lea    r8w,[rbx]
 907:	66 44 8d 43 7f                                  	lea    r8w,[rbx+0x7f]
 90c:	66 44 8d 43 80                                  	lea    r8w,[rbx-0x80]
 911:	66 44 8d 44 4b f9                               	lea    r8w,[rbx+rcx*2-0x7]
 917:	66 47 8d 84 88 ff ff ff 7f                      	lea    r8w,[r8+r9*4+0x7fffffff]
 920:	66 47 8d 84 c8 00 00 00 80                      	lea    r8w,[r8+r9*8-0x80000000]
 929:	66 44 8d 04 cd 7f 00 00 00                      	lea    r8w,[rcx*8+0x7f]
 932:	66 44 8d 04 25 78 56 34 12                      	lea    r8w,ds:0x12345678
 93b:	67 66 44 8d 44 8b f9                            	lea    r8w,[ebx+ecx*4-0x7]
 942:	67 66 47 8d 44 c8 7f                            	lea    r8w,[r8d+r9d*8+0x7f]
 949:	44 8d 03                                        	lea    r8d,[rbx]
 94c:	44 8d 43 7f                                     	lea    r8d,[rbx+0x7f]
 950:	44 8d 43 80                                     	lea    r8d,[rbx-0x80]
 954:	44 8d 44 4b f9                                  	lea    r8d,[rbx+rcx*2-0x7]
 959:	47 8d 84 88 ff ff ff 7f                         	lea    r8d,[r8+r9*4+0x7fffffff]
 961:	47 8d 84 c8 00 00 00 80                         	lea    r8d,[r8+r9*8-0x80000000]
 969:	44 8d 04 cd 7f 00 00 00                         	lea    r8d,[rcx*8+0x7f]
 971:	44 8d 04 25 78 56 34 12                         	lea    r8d,ds:0x12345678
 979:	67 44 8d 44 8b f9                               	lea    r8d,[ebx+ecx*4-0x7]
 97f:	67 47 8d 44 c8 7f                               	lea    r8d,[r8d+r9d*8+0x7f]
 985:	4c 8d 03                                        	lea    r8,[rbx]
 988:	4c 8d 43 7f                                     	lea    r8,[rbx+0x7f]
 98c:	4c 8d 43 80                                     	lea    r8,[rbx-0x80]
 990:	4c 8d 44 4b f9                                  	lea    r8,[rbx+rcx*2-0x7]
 995:	4f 8d 84 88 ff ff ff 7f                         	lea    r8,[r8+r9*4+0x7fffffff]
 99d:	4f 8d 84 c8 00 00 00 80                         	lea    r8,[r8+r9*8-0x80000000]
 9a5:	4c 8d 04 cd 7f 00 00 00                         	lea    r8,[rcx*8+0x7f]
 9ad:	4c 8d 04 25 78 56 34 12                         	lea    r8,ds:0x12345678
 9b5:	67 4c 8d 44 8b f9                               	lea    r8,[ebx+ecx*4-0x7]
 9bb:	67 4f 8d 44 c8 7f                               	lea    r8,[r8d+r9d*8+0x7f]
 9c1:	48 8d 1c cb                                     	lea    rbx,[rbx+rcx*8]
 9c5:	48 8d 0c cb                                     	lea    rcx,[rbx+rcx*8]
 9c9:	4f 8d 4c 48 f9                                  	lea    r9,[r8+r9*2-0x7]
 9ce:	64 66 8d 44 4b f9                               	lea    ax,fs:[rbx+rcx*2-0x7]
 9d4:	65 66 8d 44 4b f9                               	lea    ax,gs:[rbx+rcx*2-0x7]
 9da:	64 8d 44 4b f9                                  	lea    eax,fs:[rbx+rcx*2-0x7]
 9df:	65 8d 44 4b f9                                  	lea    eax,gs:[rbx+rcx*2-0x7]
 9e4:	64 48 8d 44 4b f9                               	lea    rax,fs:[rbx+rcx*2-0x7]
 9ea:	65 48 8d 44 4b f9                               	lea    rax,gs:[rbx+rcx*2-0x7]
 9f0:	8a 67 08                                        	mov    ah,BYTE PTR [rdi+0x8]
 9f3:	8a 66 10                                        	mov    ah,BYTE PTR [rsi+0x10]
 9f6:	8a 64 24 f0                                     	mov    ah,BYTE PTR [rsp-0x10]
 9fa:	8a 6f 08                                        	mov    ch,BYTE PTR [rdi+0x8]
 9fd:	8a 6e 10                                        	mov    ch,BYTE PTR [rsi+0x10]
 a00:	8a 6c 24 f0                                     	mov    ch,BYTE PTR [rsp-0x10]
 a04:	8a 77 08                                        	mov    dh,BYTE PTR [rdi+0x8]
 a07:	8a 76 10                                        	mov    dh,BYTE PTR [rsi+0x10]
 a0a:	8a 74 24 f0                                     	mov    dh,BYTE PTR [rsp-0x10]
 a0e:	8a 7f 08                                        	mov    bh,BYTE PTR [rdi+0x8]
 a11:	8a 7e 10                                        	mov    bh,BYTE PTR [rsi+0x10]
 a14:	8a 7c 24 f0                                     	mov    bh,BYTE PTR [rsp-0x10]
 a18:	0f 97 c0                                        	seta   al
 a1b:	0f 97 c4                                        	seta   ah
 a1e:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 a22:	0f 93 c0                                        	setae  al
 a25:	0f 93 c4                                        	setae  ah
 a28:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 a2c:	0f 92 c0                                        	setb   al
 a2f:	0f 92 c4                                        	setb   ah
 a32:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 a36:	0f 96 c0                                        	setbe  al
 a39:	0f 96 c4                                        	setbe  ah
 a3c:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 a40:	0f 94 c0                                        	sete   al
 a43:	0f 94 c4                                        	sete   ah
 a46:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 a4a:	0f 9f c0                                        	setg   al
 a4d:	0f 9f c4                                        	setg   ah
 a50:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 a54:	0f 9d c0                                        	setge  al
 a57:	0f 9d c4                                        	setge  ah
 a5a:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 a5e:	0f 9c c0                                        	setl   al
 a61:	0f 9c c4                                        	setl   ah
 a64:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 a68:	0f 9e c0                                        	setle  al
 a6b:	0f 9e c4                                        	setle  ah
 a6e:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 a72:	0f 95 c0                                        	setne  al
 a75:	0f 95 c4                                        	setne  ah
 a78:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 a7c:	0f 99 c0                                        	setns  al
 a7f:	0f 99 c4                                        	setns  ah
 a82:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 a86:	0f 98 c0                                        	sets   al
 a89:	0f 98 c4                                        	sets   ah
 a8c:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 a90:	0f 90 c0                                        	seto   al
 a93:	0f 90 c4                                        	seto   ah
 a96:	0f 90 47 08                                     	seto   BYTE PTR [rdi+0x8]
 a9a:	0f 91 c0                                        	setno  al
 a9d:	0f 91 c4                                        	setno  ah
 aa0:	0f 91 47 08                                     	setno  BYTE PTR [rdi+0x8]
 aa4:	0f 9a c0                                        	setp   al
 aa7:	0f 9a c4                                        	setp   ah
 aaa:	0f 9a 47 08                                     	setp   BYTE PTR [rdi+0x8]
 aae:	0f 9a c0                                        	setp   al
 ab1:	0f 9a c4                                        	setp   ah
 ab4:	0f 9a 47 08                                     	setp   BYTE PTR [rdi+0x8]
 ab8:	0f 9b c0                                        	setnp  al
 abb:	0f 9b c4                                        	setnp  ah
 abe:	0f 9b 47 08                                     	setnp  BYTE PTR [rdi+0x8]
 ac2:	0f 9b c0                                        	setnp  al
 ac5:	0f 9b c4                                        	setnp  ah
 ac8:	0f 9b 47 08                                     	setnp  BYTE PTR [rdi+0x8]
 acc:	66 0f 47 c3                                     	cmova  ax,bx
 ad0:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 ad5:	0f 47 c3                                        	cmova  eax,ebx
 ad8:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 adc:	48 0f 47 c3                                     	cmova  rax,rbx
 ae0:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 ae5:	66 0f 42 c3                                     	cmovb  ax,bx
 ae9:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 aee:	0f 42 c3                                        	cmovb  eax,ebx
 af1:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 af5:	48 0f 42 c3                                     	cmovb  rax,rbx
 af9:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 afe:	66 0f 46 c3                                     	cmovbe ax,bx
 b02:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 b07:	0f 46 c3                                        	cmovbe eax,ebx
 b0a:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 b0e:	48 0f 46 c3                                     	cmovbe rax,rbx
 b12:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 b17:	66 0f 44 c3                                     	cmove  ax,bx
 b1b:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 b20:	0f 44 c3                                        	cmove  eax,ebx
 b23:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 b27:	48 0f 44 c3                                     	cmove  rax,rbx
 b2b:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 b30:	66 0f 4f c3                                     	cmovg  ax,bx
 b34:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 b39:	0f 4f c3                                        	cmovg  eax,ebx
 b3c:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 b40:	48 0f 4f c3                                     	cmovg  rax,rbx
 b44:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
 b49:	66 0f 4d c3                                     	cmovge ax,bx
 b4d:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 b52:	0f 4d c3                                        	cmovge eax,ebx
 b55:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 b59:	48 0f 4d c3                                     	cmovge rax,rbx
 b5d:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 b62:	66 0f 43 c3                                     	cmovae ax,bx
 b66:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 b6b:	0f 43 c3                                        	cmovae eax,ebx
 b6e:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 b72:	48 0f 43 c3                                     	cmovae rax,rbx
 b76:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 b7b:	66 0f 4c c3                                     	cmovl  ax,bx
 b7f:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 b84:	0f 4c c3                                        	cmovl  eax,ebx
 b87:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 b8b:	48 0f 4c c3                                     	cmovl  rax,rbx
 b8f:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 b94:	66 0f 4e c3                                     	cmovle ax,bx
 b98:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 b9d:	0f 4e c3                                        	cmovle eax,ebx
 ba0:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 ba4:	48 0f 4e c3                                     	cmovle rax,rbx
 ba8:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 bad:	66 0f 45 c3                                     	cmovne ax,bx
 bb1:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 bb6:	0f 45 c3                                        	cmovne eax,ebx
 bb9:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 bbd:	48 0f 45 c3                                     	cmovne rax,rbx
 bc1:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 bc6:	66 0f 49 c3                                     	cmovns ax,bx
 bca:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 bcf:	0f 49 c3                                        	cmovns eax,ebx
 bd2:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 bd6:	48 0f 49 c3                                     	cmovns rax,rbx
 bda:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 bdf:	66 0f 48 c3                                     	cmovs  ax,bx
 be3:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 be8:	0f 48 c3                                        	cmovs  eax,ebx
 beb:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 bef:	48 0f 48 c3                                     	cmovs  rax,rbx
 bf3:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
 bf8:	66 0f 40 c3                                     	cmovo  ax,bx
 bfc:	66 0f 40 47 08                                  	cmovo  ax,WORD PTR [rdi+0x8]
 c01:	0f 40 c3                                        	cmovo  eax,ebx
 c04:	0f 40 47 08                                     	cmovo  eax,DWORD PTR [rdi+0x8]
 c08:	48 0f 40 c3                                     	cmovo  rax,rbx
 c0c:	48 0f 40 47 08                                  	cmovo  rax,QWORD PTR [rdi+0x8]
 c11:	66 0f 41 c3                                     	cmovno ax,bx
 c15:	66 0f 41 47 08                                  	cmovno ax,WORD PTR [rdi+0x8]
 c1a:	0f 41 c3                                        	cmovno eax,ebx
 c1d:	0f 41 47 08                                     	cmovno eax,DWORD PTR [rdi+0x8]
 c21:	48 0f 41 c3                                     	cmovno rax,rbx
 c25:	48 0f 41 47 08                                  	cmovno rax,QWORD PTR [rdi+0x8]
 c2a:	66 0f 4a c3                                     	cmovp  ax,bx
 c2e:	66 0f 4a 47 08                                  	cmovp  ax,WORD PTR [rdi+0x8]
 c33:	0f 4a c3                                        	cmovp  eax,ebx
 c36:	0f 4a 47 08                                     	cmovp  eax,DWORD PTR [rdi+0x8]
 c3a:	48 0f 4a c3                                     	cmovp  rax,rbx
 c3e:	48 0f 4a 47 08                                  	cmovp  rax,QWORD PTR [rdi+0x8]
 c43:	66 0f 4a c3                                     	cmovp  ax,bx
 c47:	66 0f 4a 47 08                                  	cmovp  ax,WORD PTR [rdi+0x8]
 c4c:	0f 4a c3                                        	cmovp  eax,ebx
 c4f:	0f 4a 47 08                                     	cmovp  eax,DWORD PTR [rdi+0x8]
 c53:	48 0f 4a c3                                     	cmovp  rax,rbx
 c57:	48 0f 4a 47 08                                  	cmovp  rax,QWORD PTR [rdi+0x8]
 c5c:	66 0f 4b c3                                     	cmovnp ax,bx
 c60:	66 0f 4b 47 08                                  	cmovnp ax,WORD PTR [rdi+0x8]
 c65:	0f 4b c3                                        	cmovnp eax,ebx
 c68:	0f 4b 47 08                                     	cmovnp eax,DWORD PTR [rdi+0x8]
 c6c:	48 0f 4b c3                                     	cmovnp rax,rbx
 c70:	48 0f 4b 47 08                                  	cmovnp rax,QWORD PTR [rdi+0x8]
 c75:	66 0f 4b c3                                     	cmovnp ax,bx
 c79:	66 0f 4b 47 08                                  	cmovnp ax,WORD PTR [rdi+0x8]
 c7e:	0f 4b c3                                        	cmovnp eax,ebx
 c81:	0f 4b 47 08                                     	cmovnp eax,DWORD PTR [rdi+0x8]
 c85:	48 0f 4b c3                                     	cmovnp rax,rbx
 c89:	48 0f 4b 47 08                                  	cmovnp rax,QWORD PTR [rdi+0x8]
