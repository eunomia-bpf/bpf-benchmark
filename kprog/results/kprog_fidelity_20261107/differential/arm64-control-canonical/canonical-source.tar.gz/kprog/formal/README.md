# Native simulator verification

Run the complete local check on an x86-64 host:

```sh
make -C kprog/formal check
```

It requires Lean/Elan, Python3, Rust/Cargo, a C compiler with UBSan,
clang18/LLVM18 tools, GNU objdump, and the `vendor/libbpf` and
`vendor/linux-framework` submodules. The target builds every Lean theorem
module, checks generated contracts and routing, rejects proof placeholders,
and runs the C semantic oracles and executable-reference checks. Papers and
paper/count checkers are not inputs.

The specification is the single executable ISA model in
[`Reference/X86.lean`](KProgFormal/Reference/X86.lean) and
[`Reference/AArch64.lean`](KProgFormal/Reference/AArch64.lean), with the shared
memory, permissions, initialization, effects and faults in
[`Reference/Memory.lean`](KProgFormal/Reference/Memory.lean). Their headers
identify the Intel/Arm architectural sources; they import no simulator or
generated implementation contracts. Unwritten native memory has arbitrary
contents, not invented zeros. Undefined x86 flags are masked by the relational
step instead of assigning them architectural guarantees. ARM memory and
exclusive accesses carry their explicit architectural/environment inputs;
control uses the current Cortex-A72 base profile without GCS/BTI state.

The proofs establish arithmetic/flags, register and tag operations, memory
accesses, routing tables, and selected whole-state handler refinements.
[`Refinement/`](KProgFormal/Refinement/) connects generated implementation
slices to those same ISA steps, retaining registers, flags, vectors, memory,
PC and ordered effects/faults. This includes scalar/logical/unary operations,
width/sign extensions, conditional operations, shifts, bit operations,
stack transfers, LEA, DIV, register XCHG, and the ARM arithmetic, vector,
memory, exclusive and control families represented there. Individual module
statements define their exact scope. Dispatcher coverage/exclusivity is
**not yet a full simulator-step refinement theorem**; completing the remaining
handler lifts and their dispatcher composition is ongoing work.

The lifts consume materialized native register/address values.
[`EntryEnvironment.lean`](KProgFormal/Refinement/EntryEnvironment.lean)
states the same-invocation SP/code/return relation, with explicit frame biases
and argument/return witnesses. Kernel/JIT, ABI and artifact certificates must
establish those witnesses and code/provenance/profile bindings. A private
stack offset alone is not a native numeric address. The entry arithmetic and
partial-write theorems preserve this distinction.

Trust boundary: Lean checks Lean models, not arbitrary C source or compiled
BPF. The Lean kernel/toolchain are trusted; `native_decide` additionally trusts
compiled evaluation. JSON-to-C/Lean generators, C compilation and native
byte lowering remain cross-language boundaries: freshness checks, independent
semantic oracles, real CPU examples and BPF access checks test them. They do
not prove compiler correctness. Hardware fidelity, verifier acceptance,
platform helpers and artifact/invocation binding require their corresponding
evidence and proofs; a local passing check does not establish them by itself.

Actual linked ARRAY/PERCPU_ARRAY instruction paths are checked against the
canonical x86 model, including bounds, reads and first faults. Inline lookup
blocks emit no helper event; direct map-type calls retain their exact target
and relocation. Callee effects, arguments, map layout, CPU inputs and checked
helper expansion use the [TV platform contract](../tv/README.md#map-lookup-inlining-and-the-proof-boundary-2026-11-07).
These fixture paths are not application invocation certificates.

Layout:

- `KProgFormal/Reference/`: executable reference ISA and shared effects.
- `KProgFormal/Refinement/`: lifts against that reference; other modules in
  `KProgFormal/` retain the original bounded handler/table theorems.
- `contracts/`, `tools/generate_*`, `generated/`, `KProgFormal/Generated/`:
  implementation contracts, generators and emitted C/Lean expressions.
- `oracles/`: retained semantic C hosts, including the former build hosts.
- `tools/`: executable reference, encoding and semantic checks;
  `tools/mutations/` retains the tracked semantic mutation batteries.
- `build/`, `.lake/`: disposable generated/compiled outputs.

The same reference builds as `.lake/build/bin/reference`: JSON lines on stdin,
one complete transition per output line. Inputs provide native bytes, actual
registers/PC and explicit memory cells (value, permissions, initialization).
x86 also supplies XMM0/FS/GS and supports finite native paths whose byte extents
and actual successors are checked. AArch64 currently accepts one four-byte
instruction per request, with explicit SIMD/environment fields when needed.
The `tools/check_reference*` scripts are concrete examples. They execute these
Lean definitions, not a second Python/C ISA interpreter. F's hardware replay
and T's path/artifact checks consume this same canonical specification.
