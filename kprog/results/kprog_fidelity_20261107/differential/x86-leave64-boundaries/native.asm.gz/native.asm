
/workspaces/repository/kprog/fidelity/build-x86-leave64-boundaries/leave64:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040278c <observe_leave>:
  40278c:	55                   	push   rbp
  40278d:	53                   	push   rbx
  40278e:	41 54                	push   r12
  402790:	41 55                	push   r13
  402792:	41 56                	push   r14
  402794:	41 57                	push   r15
  402796:	48 89 25 a3 25 0b 00 	mov    QWORD PTR [rip+0xb25a3],rsp        # 4b4d40 <saved_rsp>
  40279d:	49 89 ff             	mov    r15,rdi
  4027a0:	41 ff b7 80 00 00 00 	push   QWORD PTR [r15+0x80]
  4027a7:	9d                   	popf
  4027a8:	49 8b 07             	mov    rax,QWORD PTR [r15]
  4027ab:	49 8b 4f 08          	mov    rcx,QWORD PTR [r15+0x8]
  4027af:	49 8b 57 10          	mov    rdx,QWORD PTR [r15+0x10]
  4027b3:	49 8b 5f 18          	mov    rbx,QWORD PTR [r15+0x18]
  4027b7:	49 8b 6f 28          	mov    rbp,QWORD PTR [r15+0x28]
  4027bb:	49 8b 77 30          	mov    rsi,QWORD PTR [r15+0x30]
  4027bf:	49 8b 7f 38          	mov    rdi,QWORD PTR [r15+0x38]
  4027c3:	4d 8b 47 40          	mov    r8,QWORD PTR [r15+0x40]
  4027c7:	4d 8b 4f 48          	mov    r9,QWORD PTR [r15+0x48]
  4027cb:	4d 8b 57 50          	mov    r10,QWORD PTR [r15+0x50]
  4027cf:	4d 8b 5f 58          	mov    r11,QWORD PTR [r15+0x58]
  4027d3:	4d 8b 67 60          	mov    r12,QWORD PTR [r15+0x60]
  4027d7:	4d 8b 6f 68          	mov    r13,QWORD PTR [r15+0x68]
  4027db:	4d 8b 77 70          	mov    r14,QWORD PTR [r15+0x70]
  4027df:	49 8b 67 20          	mov    rsp,QWORD PTR [r15+0x20]
  4027e3:	4d 8b 7f 78          	mov    r15,QWORD PTR [r15+0x78]

00000000004027e7 <leave_pc>:
  4027e7:	c9                   	leave

00000000004027e8 <leave_next>:
  4027e8:	48 89 05 71 25 0b 00 	mov    QWORD PTR [rip+0xb2571],rax        # 4b4d60 <observed>
  4027ef:	48 89 0d 72 25 0b 00 	mov    QWORD PTR [rip+0xb2572],rcx        # 4b4d68 <observed+0x8>
  4027f6:	48 89 15 73 25 0b 00 	mov    QWORD PTR [rip+0xb2573],rdx        # 4b4d70 <observed+0x10>
  4027fd:	48 89 1d 74 25 0b 00 	mov    QWORD PTR [rip+0xb2574],rbx        # 4b4d78 <observed+0x18>
  402804:	48 89 25 75 25 0b 00 	mov    QWORD PTR [rip+0xb2575],rsp        # 4b4d80 <observed+0x20>
  40280b:	48 89 2d 76 25 0b 00 	mov    QWORD PTR [rip+0xb2576],rbp        # 4b4d88 <observed+0x28>
  402812:	48 89 35 77 25 0b 00 	mov    QWORD PTR [rip+0xb2577],rsi        # 4b4d90 <observed+0x30>
  402819:	48 89 3d 78 25 0b 00 	mov    QWORD PTR [rip+0xb2578],rdi        # 4b4d98 <observed+0x38>
  402820:	4c 89 05 79 25 0b 00 	mov    QWORD PTR [rip+0xb2579],r8        # 4b4da0 <observed+0x40>
  402827:	4c 89 0d 7a 25 0b 00 	mov    QWORD PTR [rip+0xb257a],r9        # 4b4da8 <observed+0x48>
  40282e:	4c 89 15 7b 25 0b 00 	mov    QWORD PTR [rip+0xb257b],r10        # 4b4db0 <observed+0x50>
  402835:	4c 89 1d 7c 25 0b 00 	mov    QWORD PTR [rip+0xb257c],r11        # 4b4db8 <observed+0x58>
  40283c:	4c 89 25 7d 25 0b 00 	mov    QWORD PTR [rip+0xb257d],r12        # 4b4dc0 <observed+0x60>
  402843:	4c 89 2d 7e 25 0b 00 	mov    QWORD PTR [rip+0xb257e],r13        # 4b4dc8 <observed+0x68>
  40284a:	4c 89 35 7f 25 0b 00 	mov    QWORD PTR [rip+0xb257f],r14        # 4b4dd0 <observed+0x70>
  402851:	4c 89 3d 80 25 0b 00 	mov    QWORD PTR [rip+0xb2580],r15        # 4b4dd8 <observed+0x78>
  402858:	48 8b 25 e1 24 0b 00 	mov    rsp,QWORD PTR [rip+0xb24e1]        # 4b4d40 <saved_rsp>
  40285f:	9c                   	pushf
  402860:	8f 05 7a 25 0b 00    	pop    QWORD PTR [rip+0xb257a]        # 4b4de0 <observed+0x80>
  402866:	41 5f                	pop    r15
  402868:	41 5e                	pop    r14
  40286a:	41 5d                	pop    r13
  40286c:	41 5c                	pop    r12
  40286e:	5b                   	pop    rbx
  40286f:	5d                   	pop    rbp
  402870:	c3                   	ret
  402871:	66 2e 0f 1f 84 00 00 	cs nop WORD PTR [rax+rax*1+0x0]
  402878:	00 00 00 
  40287b:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]

Disassembly of section .fini:
