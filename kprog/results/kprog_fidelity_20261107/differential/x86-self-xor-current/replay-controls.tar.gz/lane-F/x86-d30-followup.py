from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
B=R/'kprog/fidelity/build-x86'
base=R/'kprog/results/kprog_fidelity_20261107/differential/x86-post-d30'
out=R/'kprog/results/kprog_fidelity_20261107/differential/x86-self-xor-current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def closed(pid):
 try:fd=os.pidfd_open(pid)
 except ProcessLookupError:return
 select.select([fd],[],[]);os.close(fd)
def run(cmd,log):
 with log.open('w') as f:return subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
def capture(dest):
 files=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
 files += [B/n for n in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json']]
 files += [R/'kprog/fidelity'/n for n in ['driver.c','driver.h','Makefile']]
 pins={str(p.relative_to(R)):sha(p) for p in files}
 emit(dest/'actual-compiled-inputs.json',pins)
 with tarfile.open(dest/'actual-compiled-inputs.tar.gz','w:gz') as t:
  for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 (dest/'cpu-differential-x86.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
 return pins
def package_logs(dest):
 for name in ['build.log','run.log','reference.log']:
  p=dest/name
  if p.exists():(dest/(name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
def base_result():
 rc=int((F/'x86-post-d30.exit').read_text())
 summary=dict(recorded=datetime.now(timezone.utc).isoformat(),exit=rc,complete=False)
 if (base/'forms.tsv').exists():
  rows=list(csv.DictReader((base/'forms.tsv').open(),delimiter='\t'))
  summary.update(forms=len(rows),cases=sum(int(x['cases']) for x in rows),mismatches=sum(int(x['mismatches']) for x in rows))
  summary['complete']=len(rows)==1080 and all(int(x['cases'])==1024 for x in rows)
 pins=capture(base);summary['binary_sha256']=sha(B/'cpu-differential')
 summary['compiled_header_sha256']=sha(B/'snapshot/kprog/x86/x86_sim_local_bpf.h')
 summary['root_source_drift']=json.loads((base/'input-drift.json').read_text())
 summary['self_xor_forms']=0
 summary['scope']='CPU/C only; not a fresh canonical replay or application/ABI validation'
 emit(base/'summary.json',summary);package_logs(base)
 if (base/'mismatches.jsonl').exists():(base/'mismatches.jsonl.gz').write_bytes(gzip.compress((base/'mismatches.jsonl').read_bytes(),mtime=0))
 (base/'README.md').write_text(
 '# Current d30 production x86 CPU differential\n\n'
 +f"The detached existing Make build/run exited {rc}. Completed={summary['complete']}; "
 +f"{summary.get('forms',0)} forms, {summary.get('cases',0)} cases, "
 +f"{summary.get('mismatches',0)} CPU/C mismatches. Per-form counts are in forms.tsv; "
 +'mismatches.jsonl.gz retains every counterexample with input/output states and memory.\n\n'
 +'The actual compiled header SHA256 is '+summary['compiled_header_sha256']+'. '
 +'The executable, generated C/assembly, production include/import snapshot and observer source '
 +'are preserved losslessly with hashes. This is the existing 1080-form matrix on the owner '
 +'d30 header snapshot; the source was not yet published when captured. Root-source drift '
 +'is retained separately: F added 64 same-register XOR forms after this generation completed. '
 +'The actual pre-change generator is in compiled-inputs.tar.gz. This run contains no self-XOR '
 +'forms and cannot independently validate the new self-zero gate. A separate follow-up covers them.\n\n'
 +'The observer compares all captured GPRs, XMM0, 64 stack bytes, 256 external memory bytes '
 +'and every defined arithmetic flag. Undefined flags follow the unchanged existing masks. '
 +'No fresh canonical comparison, complete O1-O4 proof or invocation/ABI claim is made here.\n\n'
 +'~~~sh\n'
 +'taskset -c 16-19 make -C kprog/fidelity build ARCH=x86\n'
 +'taskset -c 16-19 make -C kprog/fidelity run-built ARCH=x86 CASES=1024 OUT=/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-post-d30\n'
 +'~~~\n')
 return summary
try:
 (F/'x86-d30-followup.state').write_text('waiting_for_existing_2878514\n')
 closed(int((F/'x86-post-d30.pid').read_text()))
 s=base_result()
 if not (s['exit']==0 and s['complete'] and s['mismatches']==0):
  raise RuntimeError('base CPU run did not complete successfully; evidence retained, follow-up not started')
 out.mkdir(parents=True,exist_ok=True)
 source=R/'kprog/fidelity/generate.py'
 emit(out/'source-pins-before.json',{str(source.relative_to(R)):sha(source),'kprog/x86/x86_sim_local_bpf.h':sha(R/'kprog/x86/x86_sim_local_bpf.h')})
 (out/'generator-source.py').write_bytes(source.read_bytes())
 (F/'x86-d30-followup.state').write_text('building_existing_matrix_with_64_self_xor_forms\n')
 rc=run(['taskset','-c','16-19','make','-C','kprog/fidelity','build','ARCH=x86'],out/'build.log')
 emit(out/'build-status.json',dict(exit=rc))
 if rc:raise RuntimeError('expanded matrix build failed')
 pins=capture(out)
 forms=json.loads((B/'coverage.json').read_text())
 new=[r for r in forms if r['assembly'].startswith('xor ') and len(set(r['assembly'][4:].split(', ')))==1]
 assert len(forms)==1144 and len(new)==64,(len(forms),len(new))
 emit(out/'self-xor-forms.json',new)
 ref=F/'reference-control-frozen';emit(out/'executable-pins.json',dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(ref)))
 (F/'x86-d30-followup.state').write_text('cpu_and_frozen_canonical_replay_running\n')
 rc=run(['taskset','-c','16-19','make','-f','kprog/results/kprog_fidelity_20261107/differential/x86-popcnt-memory/Makefile','reference','OUT='+str(out)],out/'reference.log')
 emit(out/'replay-status.json',dict(exit=rc,finished=datetime.now(timezone.utc).isoformat()))
 package_logs(out)
 (F/'x86-d30-followup.state').write_text('finished_reference_'+str(rc)+'_needs_result_review_and_publication\n')
 (F/'x86-d30-followup.exit').write_text(str(rc)+'\n')
except BaseException:
 (F/'x86-d30-followup.error').write_text(traceback.format_exc())
 (F/'x86-d30-followup.state').write_text('failed_evidence_retained\n')
 (F/'x86-d30-followup.exit').write_text('1\n')
 raise
