
/workspaces/repository/kprog/fidelity/build-shift-published/source/kprog/fidelity/build-cpu/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	c0 e0 00                                        	shl    al,0x0
   3:	d0 e0                                           	shl    al,1
   5:	c0 e0 07                                        	shl    al,0x7
   8:	c0 e0 08                                        	shl    al,0x8
   b:	c0 e0 0f                                        	shl    al,0xf
   e:	c0 e0 10                                        	shl    al,0x10
  11:	c0 e0 1f                                        	shl    al,0x1f
  14:	c0 e0 20                                        	shl    al,0x20
  17:	c0 e0 3f                                        	shl    al,0x3f
  1a:	c0 e0 40                                        	shl    al,0x40
  1d:	c0 e0 ff                                        	shl    al,0xff
  20:	d2 e0                                           	shl    al,cl
  22:	c0 e8 00                                        	shr    al,0x0
  25:	d0 e8                                           	shr    al,1
  27:	c0 e8 07                                        	shr    al,0x7
  2a:	c0 e8 08                                        	shr    al,0x8
  2d:	c0 e8 0f                                        	shr    al,0xf
  30:	c0 e8 10                                        	shr    al,0x10
  33:	c0 e8 1f                                        	shr    al,0x1f
  36:	c0 e8 20                                        	shr    al,0x20
  39:	c0 e8 3f                                        	shr    al,0x3f
  3c:	c0 e8 40                                        	shr    al,0x40
  3f:	c0 e8 ff                                        	shr    al,0xff
  42:	d2 e8                                           	shr    al,cl
  44:	c0 f8 00                                        	sar    al,0x0
  47:	d0 f8                                           	sar    al,1
  49:	c0 f8 07                                        	sar    al,0x7
  4c:	c0 f8 08                                        	sar    al,0x8
  4f:	c0 f8 0f                                        	sar    al,0xf
  52:	c0 f8 10                                        	sar    al,0x10
  55:	c0 f8 1f                                        	sar    al,0x1f
  58:	c0 f8 20                                        	sar    al,0x20
  5b:	c0 f8 3f                                        	sar    al,0x3f
  5e:	c0 f8 40                                        	sar    al,0x40
  61:	c0 f8 ff                                        	sar    al,0xff
  64:	d2 f8                                           	sar    al,cl
  66:	c0 c0 00                                        	rol    al,0x0
  69:	d0 c0                                           	rol    al,1
  6b:	c0 c0 07                                        	rol    al,0x7
  6e:	c0 c0 08                                        	rol    al,0x8
  71:	c0 c0 0f                                        	rol    al,0xf
  74:	c0 c0 10                                        	rol    al,0x10
  77:	c0 c0 1f                                        	rol    al,0x1f
  7a:	c0 c0 20                                        	rol    al,0x20
  7d:	c0 c0 3f                                        	rol    al,0x3f
  80:	c0 c0 40                                        	rol    al,0x40
  83:	c0 c0 ff                                        	rol    al,0xff
  86:	d2 c0                                           	rol    al,cl
  88:	66 c1 e0 00                                     	shl    ax,0x0
  8c:	66 d1 e0                                        	shl    ax,1
  8f:	66 c1 e0 07                                     	shl    ax,0x7
  93:	66 c1 e0 08                                     	shl    ax,0x8
  97:	66 c1 e0 0f                                     	shl    ax,0xf
  9b:	66 c1 e0 10                                     	shl    ax,0x10
  9f:	66 c1 e0 1f                                     	shl    ax,0x1f
  a3:	66 c1 e0 20                                     	shl    ax,0x20
  a7:	66 c1 e0 3f                                     	shl    ax,0x3f
  ab:	66 c1 e0 40                                     	shl    ax,0x40
  af:	66 c1 e0 ff                                     	shl    ax,0xff
  b3:	66 d3 e0                                        	shl    ax,cl
  b6:	66 c1 e8 00                                     	shr    ax,0x0
  ba:	66 d1 e8                                        	shr    ax,1
  bd:	66 c1 e8 07                                     	shr    ax,0x7
  c1:	66 c1 e8 08                                     	shr    ax,0x8
  c5:	66 c1 e8 0f                                     	shr    ax,0xf
  c9:	66 c1 e8 10                                     	shr    ax,0x10
  cd:	66 c1 e8 1f                                     	shr    ax,0x1f
  d1:	66 c1 e8 20                                     	shr    ax,0x20
  d5:	66 c1 e8 3f                                     	shr    ax,0x3f
  d9:	66 c1 e8 40                                     	shr    ax,0x40
  dd:	66 c1 e8 ff                                     	shr    ax,0xff
  e1:	66 d3 e8                                        	shr    ax,cl
  e4:	66 c1 f8 00                                     	sar    ax,0x0
  e8:	66 d1 f8                                        	sar    ax,1
  eb:	66 c1 f8 07                                     	sar    ax,0x7
  ef:	66 c1 f8 08                                     	sar    ax,0x8
  f3:	66 c1 f8 0f                                     	sar    ax,0xf
  f7:	66 c1 f8 10                                     	sar    ax,0x10
  fb:	66 c1 f8 1f                                     	sar    ax,0x1f
  ff:	66 c1 f8 20                                     	sar    ax,0x20
 103:	66 c1 f8 3f                                     	sar    ax,0x3f
 107:	66 c1 f8 40                                     	sar    ax,0x40
 10b:	66 c1 f8 ff                                     	sar    ax,0xff
 10f:	66 d3 f8                                        	sar    ax,cl
 112:	66 c1 c0 00                                     	rol    ax,0x0
 116:	66 d1 c0                                        	rol    ax,1
 119:	66 c1 c0 07                                     	rol    ax,0x7
 11d:	66 c1 c0 08                                     	rol    ax,0x8
 121:	66 c1 c0 0f                                     	rol    ax,0xf
 125:	66 c1 c0 10                                     	rol    ax,0x10
 129:	66 c1 c0 1f                                     	rol    ax,0x1f
 12d:	66 c1 c0 20                                     	rol    ax,0x20
 131:	66 c1 c0 3f                                     	rol    ax,0x3f
 135:	66 c1 c0 40                                     	rol    ax,0x40
 139:	66 c1 c0 ff                                     	rol    ax,0xff
 13d:	66 d3 c0                                        	rol    ax,cl
 140:	c1 e0 00                                        	shl    eax,0x0
 143:	d1 e0                                           	shl    eax,1
 145:	c1 e0 07                                        	shl    eax,0x7
 148:	c1 e0 08                                        	shl    eax,0x8
 14b:	c1 e0 0f                                        	shl    eax,0xf
 14e:	c1 e0 10                                        	shl    eax,0x10
 151:	c1 e0 1f                                        	shl    eax,0x1f
 154:	c1 e0 20                                        	shl    eax,0x20
 157:	c1 e0 3f                                        	shl    eax,0x3f
 15a:	c1 e0 40                                        	shl    eax,0x40
 15d:	c1 e0 ff                                        	shl    eax,0xff
 160:	d3 e0                                           	shl    eax,cl
 162:	c1 e8 00                                        	shr    eax,0x0
 165:	d1 e8                                           	shr    eax,1
 167:	c1 e8 07                                        	shr    eax,0x7
 16a:	c1 e8 08                                        	shr    eax,0x8
 16d:	c1 e8 0f                                        	shr    eax,0xf
 170:	c1 e8 10                                        	shr    eax,0x10
 173:	c1 e8 1f                                        	shr    eax,0x1f
 176:	c1 e8 20                                        	shr    eax,0x20
 179:	c1 e8 3f                                        	shr    eax,0x3f
 17c:	c1 e8 40                                        	shr    eax,0x40
 17f:	c1 e8 ff                                        	shr    eax,0xff
 182:	d3 e8                                           	shr    eax,cl
 184:	c1 f8 00                                        	sar    eax,0x0
 187:	d1 f8                                           	sar    eax,1
 189:	c1 f8 07                                        	sar    eax,0x7
 18c:	c1 f8 08                                        	sar    eax,0x8
 18f:	c1 f8 0f                                        	sar    eax,0xf
 192:	c1 f8 10                                        	sar    eax,0x10
 195:	c1 f8 1f                                        	sar    eax,0x1f
 198:	c1 f8 20                                        	sar    eax,0x20
 19b:	c1 f8 3f                                        	sar    eax,0x3f
 19e:	c1 f8 40                                        	sar    eax,0x40
 1a1:	c1 f8 ff                                        	sar    eax,0xff
 1a4:	d3 f8                                           	sar    eax,cl
 1a6:	c1 c0 00                                        	rol    eax,0x0
 1a9:	d1 c0                                           	rol    eax,1
 1ab:	c1 c0 07                                        	rol    eax,0x7
 1ae:	c1 c0 08                                        	rol    eax,0x8
 1b1:	c1 c0 0f                                        	rol    eax,0xf
 1b4:	c1 c0 10                                        	rol    eax,0x10
 1b7:	c1 c0 1f                                        	rol    eax,0x1f
 1ba:	c1 c0 20                                        	rol    eax,0x20
 1bd:	c1 c0 3f                                        	rol    eax,0x3f
 1c0:	c1 c0 40                                        	rol    eax,0x40
 1c3:	c1 c0 ff                                        	rol    eax,0xff
 1c6:	d3 c0                                           	rol    eax,cl
 1c8:	48 c1 e0 00                                     	shl    rax,0x0
 1cc:	48 d1 e0                                        	shl    rax,1
 1cf:	48 c1 e0 07                                     	shl    rax,0x7
 1d3:	48 c1 e0 08                                     	shl    rax,0x8
 1d7:	48 c1 e0 0f                                     	shl    rax,0xf
 1db:	48 c1 e0 10                                     	shl    rax,0x10
 1df:	48 c1 e0 1f                                     	shl    rax,0x1f
 1e3:	48 c1 e0 20                                     	shl    rax,0x20
 1e7:	48 c1 e0 3f                                     	shl    rax,0x3f
 1eb:	48 c1 e0 40                                     	shl    rax,0x40
 1ef:	48 c1 e0 ff                                     	shl    rax,0xff
 1f3:	48 d3 e0                                        	shl    rax,cl
 1f6:	48 c1 e8 00                                     	shr    rax,0x0
 1fa:	48 d1 e8                                        	shr    rax,1
 1fd:	48 c1 e8 07                                     	shr    rax,0x7
 201:	48 c1 e8 08                                     	shr    rax,0x8
 205:	48 c1 e8 0f                                     	shr    rax,0xf
 209:	48 c1 e8 10                                     	shr    rax,0x10
 20d:	48 c1 e8 1f                                     	shr    rax,0x1f
 211:	48 c1 e8 20                                     	shr    rax,0x20
 215:	48 c1 e8 3f                                     	shr    rax,0x3f
 219:	48 c1 e8 40                                     	shr    rax,0x40
 21d:	48 c1 e8 ff                                     	shr    rax,0xff
 221:	48 d3 e8                                        	shr    rax,cl
 224:	48 c1 f8 00                                     	sar    rax,0x0
 228:	48 d1 f8                                        	sar    rax,1
 22b:	48 c1 f8 07                                     	sar    rax,0x7
 22f:	48 c1 f8 08                                     	sar    rax,0x8
 233:	48 c1 f8 0f                                     	sar    rax,0xf
 237:	48 c1 f8 10                                     	sar    rax,0x10
 23b:	48 c1 f8 1f                                     	sar    rax,0x1f
 23f:	48 c1 f8 20                                     	sar    rax,0x20
 243:	48 c1 f8 3f                                     	sar    rax,0x3f
 247:	48 c1 f8 40                                     	sar    rax,0x40
 24b:	48 c1 f8 ff                                     	sar    rax,0xff
 24f:	48 d3 f8                                        	sar    rax,cl
 252:	48 c1 c0 00                                     	rol    rax,0x0
 256:	48 d1 c0                                        	rol    rax,1
 259:	48 c1 c0 07                                     	rol    rax,0x7
 25d:	48 c1 c0 08                                     	rol    rax,0x8
 261:	48 c1 c0 0f                                     	rol    rax,0xf
 265:	48 c1 c0 10                                     	rol    rax,0x10
 269:	48 c1 c0 1f                                     	rol    rax,0x1f
 26d:	48 c1 c0 20                                     	rol    rax,0x20
 271:	48 c1 c0 3f                                     	rol    rax,0x3f
 275:	48 c1 c0 40                                     	rol    rax,0x40
 279:	48 c1 c0 ff                                     	rol    rax,0xff
 27d:	48 d3 c0                                        	rol    rax,cl
