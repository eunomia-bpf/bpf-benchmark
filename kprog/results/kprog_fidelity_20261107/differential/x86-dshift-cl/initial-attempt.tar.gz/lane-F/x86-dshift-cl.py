from pathlib import Path
import subprocess,datetime,json,hashlib,tarfile,gzip,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-dshift-cl'
B=R/'kprog/fidelity/build-x86-dshift-cl';S=F/'x86-dshift-cl'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 S.with_suffix('.state').write_text('building_and_replaying_numeric_tokens\n')
 paths=[R/'kprog/fidelity'/n for n in ['generate.py','driver.c','driver.h','Makefile','reference_check.py']]
 paths+=list((R/'kprog/x86').glob('*.h'))+list((R/'kprog/x86/micro-prog').glob('*.py'))+list((R/'kprog/formal/generated').glob('*.h'))
 paths+=[O/'select.py',O/'Makefile']
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 launch=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
  expected_forms=64,paths=['raw','direct'],expected_tokens=['X86_OP_SHLD_IMM','X86_OP_SHRD_IMM'],
  source_sha256=pins,reference_sha256=sha(F/'reference-control-frozen'))
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
  t.add(__file__,arcname='lane-F/x86-dshift-cl.py')
 with (O/'run.log').open('w') as f:
  rc=subprocess.run(['taskset','-c','16-19','make','-f',str(O/'Makefile'),'reference'],cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 if (B/'coverage.json').exists():
  forms=json.loads((B/'coverage.json').read_text())
  assert len(forms)==64 and {r['opcode'] for r in forms}==set(launch['expected_tokens'])
  (O/'coverage.json').write_text(json.dumps(forms,indent=2)+'\n')
 if (B/'generated.c').exists():
  files=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
  files+=[B/n for n in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json','selected-generator.py','selection-review.json','numeric-bindings.json']]
  files+=[R/'kprog/fidelity'/n for n in ['driver.c','driver.h','Makefile']]
  (O/'actual-compiled-inputs.json').write_text(json.dumps({str(p.relative_to(R)):sha(p) for p in files},indent=2)+'\n')
  with tarfile.open(O/'actual-compiled-inputs.tar.gz','w:gz') as t:
   for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 if (B/'cpu-differential').exists():
  (O/'cpu-differential-x86.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
  (O/'executable-pins.json').write_text(json.dumps(dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(F/'reference-control-frozen')),indent=2)+'\n')
 drift={p:dict(before=h,after=sha(R/p)) for p,h in pins.items() if sha(R/p)!=h}
 (O/'status.json').write_text(json.dumps(dict(exit=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_drift=drift),indent=2)+'\n')
 S.with_suffix('.exit').write_text(str(rc)+'\n');S.with_suffix('.state').write_text('closed_review_pending\n')
except BaseException:
 S.with_suffix('.error').write_text(traceback.format_exc());S.with_suffix('.exit').write_text('1\n');S.with_suffix('.state').write_text('closed_error_retained\n');raise
