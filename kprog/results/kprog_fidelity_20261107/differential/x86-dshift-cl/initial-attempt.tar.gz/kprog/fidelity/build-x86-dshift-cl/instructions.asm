
/workspaces/repository/kprog/fidelity/build-x86-dshift-cl/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	0f a5 d8                                        	shld   eax,ebx,cl
   3:	0f a5 c0                                        	shld   eax,eax,cl
   6:	0f a5 c1                                        	shld   ecx,eax,cl
   9:	0f a5 c8                                        	shld   eax,ecx,cl
   c:	0f a5 c9                                        	shld   ecx,ecx,cl
   f:	0f a5 c4                                        	shld   esp,eax,cl
  12:	0f a5 e0                                        	shld   eax,esp,cl
  15:	0f a5 e4                                        	shld   esp,esp,cl
  18:	48 0f a5 d8                                     	shld   rax,rbx,cl
  1c:	48 0f a5 c0                                     	shld   rax,rax,cl
  20:	48 0f a5 c1                                     	shld   rcx,rax,cl
  24:	48 0f a5 c8                                     	shld   rax,rcx,cl
  28:	48 0f a5 c9                                     	shld   rcx,rcx,cl
  2c:	48 0f a5 c4                                     	shld   rsp,rax,cl
  30:	48 0f a5 e0                                     	shld   rax,rsp,cl
  34:	48 0f a5 e4                                     	shld   rsp,rsp,cl
  38:	0f ad d8                                        	shrd   eax,ebx,cl
  3b:	0f ad c0                                        	shrd   eax,eax,cl
  3e:	0f ad c1                                        	shrd   ecx,eax,cl
  41:	0f ad c8                                        	shrd   eax,ecx,cl
  44:	0f ad c9                                        	shrd   ecx,ecx,cl
  47:	0f ad c4                                        	shrd   esp,eax,cl
  4a:	0f ad e0                                        	shrd   eax,esp,cl
  4d:	0f ad e4                                        	shrd   esp,esp,cl
  50:	48 0f ad d8                                     	shrd   rax,rbx,cl
  54:	48 0f ad c0                                     	shrd   rax,rax,cl
  58:	48 0f ad c1                                     	shrd   rcx,rax,cl
  5c:	48 0f ad c8                                     	shrd   rax,rcx,cl
  60:	48 0f ad c9                                     	shrd   rcx,rcx,cl
  64:	48 0f ad c4                                     	shrd   rsp,rax,cl
  68:	48 0f ad e0                                     	shrd   rax,rsp,cl
  6c:	48 0f ad e4                                     	shrd   rsp,rsp,cl
