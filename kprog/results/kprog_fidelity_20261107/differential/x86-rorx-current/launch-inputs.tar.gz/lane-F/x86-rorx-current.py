from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-rorx-current'
B=R/'kprog/fidelity/build-x86-rorx';S=F/'x86-rorx-current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
try:
 S.with_suffix('.state').write_text('selected_existing_forms_build_and_replay_running\n')
 paths=[R/'kprog/fidelity'/n for n in ['generate.py','driver.c','driver.h','Makefile','reference_check.py']]
 paths += list((R/'kprog/x86').glob('*.h'))+list((R/'kprog/x86/micro-prog').glob('*.py'))+list((R/'kprog/formal/generated').glob('*.h'))
 paths += [O/'select-rorx.py',O/'Makefile']
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 emit('launch.json',dict(started=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),production_commit='2b1ab2c29449d3e80108c00133c99065717f636b',pins=pins,reference_sha256=sha(F/'reference-control-frozen')))
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
  t.add(__file__,arcname='lane-F/x86-rorx-current.py',recursive=False)
 with (O/'build-reference.log').open('w') as f:
  rc=subprocess.run(['taskset','-c','16-19','make','-f',str(O/'Makefile'),'reference'],cwd=R,stdout=f,stderr=subprocess.STDOUT).returncode
 emit('replay-status.json',dict(exit=rc,finished=datetime.now(timezone.utc).isoformat()))
 if (B/'coverage.json').exists():
  forms=json.loads((B/'coverage.json').read_text())
  emit('form-selection.json',forms)
  assert len(forms)==4 and all(r['opcode'] in {'X86_OP_RORX','X86_OP_RORX_MEM'} for r in forms),'selected matrix unexpectedly changed'
 if (B/'generated.c').exists():
  files=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
  files += [B/n for n in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json','selected-generator.py']]
  files += [R/'kprog/fidelity'/n for n in ['driver.c','driver.h','Makefile']]
  emit('actual-compiled-inputs.json',{str(p.relative_to(R)):sha(p) for p in files})
  with tarfile.open(O/'actual-compiled-inputs.tar.gz','w:gz') as t:
   for p in files:t.add(p,arcname=str(p.relative_to(R)),recursive=False)
 if (B/'cpu-differential').exists():
  (O/'cpu-differential-x86.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
  emit('executable-pins.json',dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(F/'reference-control-frozen')))
 emit('source-drift-after.json',{p:dict(before=h,after=sha(R/p)) for p,h in pins.items() if (R/p).exists() and sha(R/p)!=h})
 for n in ['build-reference.log','mismatches.jsonl','reference-mismatches.jsonl','reference-unavailable.jsonl']:
  p=O/n
  if p.exists():(O/(n+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 S.with_suffix('.state').write_text('closed_'+str(rc)+'_needs_independent_review\n');S.with_suffix('.exit').write_text(str(rc)+'\n')
except BaseException:
 S.with_suffix('.error').write_text(traceback.format_exc());S.with_suffix('.state').write_text('failed_evidence_retained\n');S.with_suffix('.exit').write_text('1\n');raise
