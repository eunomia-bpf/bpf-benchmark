# Current production RORX CPU and canonical check

Consume published 2b1ab2c29's shared RORX handler using the existing native
instruction generator, observer and production encoder. The selection adapter
adds exactly one pair-filter line after the original generator constructs its
complete matrix; all four existing RORX forms remain in order. Native code,
random states, defined flag masks, state/memory observation and canonical ISA
are unchanged. No production source is edited.

The independent warm build-x86-rorx directory preserves the active 1144-form
reference reader's build-x86 inputs. It compiles only the affected forms rather
than another complete matrix. Pending until terminal per-form review.

~~~sh
taskset -c 16-19 make -f kprog/results/kprog_fidelity_20261107/differential/x86-rorx-current/Makefile reference
~~~

The command generates the selected harness through the existing generator,
then uses the standard fidelity Make build and frozen c110 canonical reference.
Exact launch source and actual compiled inputs are archived separately.
