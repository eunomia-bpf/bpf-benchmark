#include "../driver.h"
#include <stdlib.h>
#include <string.h>
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/fidelity/build-x86-rorx/snapshot/kprog/x86/x86_sim_local_bpf.h"
extern uint64_t native_stack_base;
extern unsigned char native_pc_0, native_next_0;
extern void native_0(struct state *);
static void sim_0(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind = KPROG_ABI_KIND_XDP;
__x86_native_stack_base = native_stack_base;
__x86_rax.ptr = (void *)(uintptr_t)s->r[0];
__x86_rcx.ptr = (void *)(uintptr_t)s->r[1];
__x86_rdx.ptr = (void *)(uintptr_t)s->r[2];
__x86_rbx.ptr = (void *)(uintptr_t)s->r[3];
__x86_rsp.ptr = (void *)(uintptr_t)s->r[4];
__x86_rbp.ptr = (void *)(uintptr_t)s->r[5];
__x86_rsi.ptr = (void *)(uintptr_t)s->r[6];
__x86_rdi.ptr = (void *)(uintptr_t)s->r[7];
__x86_r8.ptr = (void *)(uintptr_t)s->r[8];
__x86_r9.ptr = (void *)(uintptr_t)s->r[9];
__x86_r10.ptr = (void *)(uintptr_t)s->r[10];
__x86_r11.ptr = (void *)(uintptr_t)s->r[11];
__x86_r12.ptr = (void *)(uintptr_t)s->r[12];
__x86_r13.ptr = (void *)(uintptr_t)s->r[13];
__x86_r14.ptr = (void *)(uintptr_t)s->r[14];
__x86_r15.ptr = (void *)(uintptr_t)s->r[15];
for (unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf = s->flags & 1; __x86_pf = (s->flags >> 2) & 1; __x86_af = (s->flags >> 4) & 1; __x86_zf = (s->flags >> 6) & 1; __x86_sf = (s->flags >> 7) & 1; __x86_of = (s->flags >> 11) & 1;
__x86_xmm0_lo = s->vec[0]; __x86_xmm0_hi = s->vec[1];
X86_SIM_L_EXEC_RORX(X86_RAX, X86_RBX, X86_WIDTH_32, 7ULL);
s->r[0] = X86_SIM_L_READ_REG(0);
s->r[1] = X86_SIM_L_READ_REG(1);
s->r[2] = X86_SIM_L_READ_REG(2);
s->r[3] = X86_SIM_L_READ_REG(3);
s->r[4] = (uintptr_t)__x86_rsp.ptr;
s->r[5] = X86_SIM_L_READ_REG(5);
s->r[6] = X86_SIM_L_READ_REG(6);
s->r[7] = X86_SIM_L_READ_REG(7);
s->r[8] = X86_SIM_L_READ_REG(8);
s->r[9] = X86_SIM_L_READ_REG(9);
s->r[10] = X86_SIM_L_READ_REG(10);
s->r[11] = X86_SIM_L_READ_REG(11);
s->r[12] = X86_SIM_L_READ_REG(12);
s->r[13] = X86_SIM_L_READ_REG(13);
s->r[14] = X86_SIM_L_READ_REG(14);
s->r[15] = X86_SIM_L_READ_REG(15);
for (unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags = __x86_cf | ((uint64_t)__x86_pf << 2) | ((uint64_t)__x86_af << 4) | ((uint64_t)__x86_zf << 6) | ((uint64_t)__x86_sf << 7) | ((uint64_t)__x86_of << 11);
s->vec[0] = __x86_xmm0_lo; s->vec[1] = __x86_xmm0_hi;
}
extern unsigned char native_pc_1, native_next_1;
extern void native_1(struct state *);
static void sim_1(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind = KPROG_ABI_KIND_XDP;
__x86_native_stack_base = native_stack_base;
__x86_rax.ptr = (void *)(uintptr_t)s->r[0];
__x86_rcx.ptr = (void *)(uintptr_t)s->r[1];
__x86_rdx.ptr = (void *)(uintptr_t)s->r[2];
__x86_rbx.ptr = (void *)(uintptr_t)s->r[3];
__x86_rsp.ptr = (void *)(uintptr_t)s->r[4];
__x86_rbp.ptr = (void *)(uintptr_t)s->r[5];
__x86_rsi.ptr = (void *)(uintptr_t)s->r[6];
__x86_rdi.ptr = (void *)(uintptr_t)s->r[7];
__x86_r8.ptr = (void *)(uintptr_t)s->r[8];
__x86_r9.ptr = (void *)(uintptr_t)s->r[9];
__x86_r10.ptr = (void *)(uintptr_t)s->r[10];
__x86_r11.ptr = (void *)(uintptr_t)s->r[11];
__x86_r12.ptr = (void *)(uintptr_t)s->r[12];
__x86_r13.ptr = (void *)(uintptr_t)s->r[13];
__x86_r14.ptr = (void *)(uintptr_t)s->r[14];
__x86_r15.ptr = (void *)(uintptr_t)s->r[15];
for (unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf = s->flags & 1; __x86_pf = (s->flags >> 2) & 1; __x86_af = (s->flags >> 4) & 1; __x86_zf = (s->flags >> 6) & 1; __x86_sf = (s->flags >> 7) & 1; __x86_of = (s->flags >> 11) & 1;
__x86_xmm0_lo = s->vec[0]; __x86_xmm0_hi = s->vec[1];
X86_SIM_L_EXEC_RORX(X86_RAX, X86_RBX, X86_WIDTH_64, 7ULL);
s->r[0] = X86_SIM_L_READ_REG(0);
s->r[1] = X86_SIM_L_READ_REG(1);
s->r[2] = X86_SIM_L_READ_REG(2);
s->r[3] = X86_SIM_L_READ_REG(3);
s->r[4] = (uintptr_t)__x86_rsp.ptr;
s->r[5] = X86_SIM_L_READ_REG(5);
s->r[6] = X86_SIM_L_READ_REG(6);
s->r[7] = X86_SIM_L_READ_REG(7);
s->r[8] = X86_SIM_L_READ_REG(8);
s->r[9] = X86_SIM_L_READ_REG(9);
s->r[10] = X86_SIM_L_READ_REG(10);
s->r[11] = X86_SIM_L_READ_REG(11);
s->r[12] = X86_SIM_L_READ_REG(12);
s->r[13] = X86_SIM_L_READ_REG(13);
s->r[14] = X86_SIM_L_READ_REG(14);
s->r[15] = X86_SIM_L_READ_REG(15);
for (unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags = __x86_cf | ((uint64_t)__x86_pf << 2) | ((uint64_t)__x86_af << 4) | ((uint64_t)__x86_zf << 6) | ((uint64_t)__x86_sf << 7) | ((uint64_t)__x86_of << 11);
s->vec[0] = __x86_xmm0_lo; s->vec[1] = __x86_xmm0_hi;
}
const struct form forms[] = {
{"rorx eax, ebx, 7", "X86_OP_RORX", native_0, sim_0, 2261U, 32, 0, 0, &native_pc_0, &native_next_0},
{"rorx rax, rbx, 7", "X86_OP_RORX", native_1, sim_1, 2261U, 64, 0, 0, &native_pc_1, &native_next_1}
};
const unsigned form_count = sizeof(forms) / sizeof(forms[0]);
