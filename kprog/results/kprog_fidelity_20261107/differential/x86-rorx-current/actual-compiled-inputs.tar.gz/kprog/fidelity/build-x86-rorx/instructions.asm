
/workspaces/repository/kprog/fidelity/build-x86-rorx/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	66 98                                           	cbw
   9:	98                                              	cwde
   a:	48 98                                           	cdqe
   c:	66 99                                           	cwd
   e:	99                                              	cdq
   f:	48 99                                           	cqo
  11:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
  14:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
  17:	48 89 e0                                        	mov    rax,rsp
  1a:	89 e0                                           	mov    eax,esp
  1c:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  21:	48 83 fc 00                                     	cmp    rsp,0x0
  25:	48 89 c4                                        	mov    rsp,rax
  28:	89 c4                                           	mov    esp,eax
  2a:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
  2f:	48 83 c4 10                                     	add    rsp,0x10
  33:	54                                              	push   rsp
  34:	5c                                              	pop    rsp
  35:	66 54                                           	push   sp
  37:	66 5c                                           	pop    sp
  39:	68 00 00 00 80                                  	push   0xffffffff80000000
  3e:	6a 80                                           	push   0xffffffffffffff80
  40:	6a ff                                           	push   0xffffffffffffffff
  42:	6a 00                                           	push   0x0
  44:	6a 01                                           	push   0x1
  46:	6a 7f                                           	push   0x7f
  48:	68 80 00 00 00                                  	push   0x80
  4d:	68 78 56 34 12                                  	push   0x12345678
  52:	66 6a f9                                        	pushw  0xfff9
  55:	ff 77 08                                        	push   QWORD PTR [rdi+0x8]
  58:	66 ff 77 08                                     	push   WORD PTR [rdi+0x8]
  5c:	8f 47 08                                        	pop    QWORD PTR [rdi+0x8]
  5f:	66 8f 47 08                                     	pop    WORD PTR [rdi+0x8]
  63:	ff 74 24 f0                                     	push   QWORD PTR [rsp-0x10]
  67:	8f 44 24 f0                                     	pop    QWORD PTR [rsp-0x10]
  6b:	66 48 53                                        	data16 rex.W push rbx
  6e:	48                                              	rex.W
  6f:	66 53                                           	push   bx
  71:	66 48 ff f3                                     	data16 rex.W push rbx
  75:	48                                              	rex.W
  76:	66 ff f3                                        	push   bx
  79:	66 48 58                                        	data16 rex.W pop rax
  7c:	48                                              	rex.W
  7d:	66 58                                           	pop    ax
  7f:	66 48 8f c0                                     	data16 rex.W pop rax
  83:	48                                              	rex.W
  84:	66 8f c0                                        	pop    ax
  87:	88 d8                                           	mov    al,bl
  89:	b0 7f                                           	mov    al,0x7f
  8b:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  8e:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  91:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  95:	00 d8                                           	add    al,bl
  97:	04 7f                                           	add    al,0x7f
  99:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  9c:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  a0:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  a3:	10 d8                                           	adc    al,bl
  a5:	14 7f                                           	adc    al,0x7f
  a7:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  aa:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  ae:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  b1:	28 d8                                           	sub    al,bl
  b3:	2c 7f                                           	sub    al,0x7f
  b5:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  b8:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  bc:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  bf:	18 d8                                           	sbb    al,bl
  c1:	1c 7f                                           	sbb    al,0x7f
  c3:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  c6:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  ca:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  cd:	38 d8                                           	cmp    al,bl
  cf:	3c 7f                                           	cmp    al,0x7f
  d1:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  d4:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  d8:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  db:	84 d8                                           	test   al,bl
  dd:	a8 7f                                           	test   al,0x7f
  df:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  e2:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  e6:	20 d8                                           	and    al,bl
  e8:	24 7f                                           	and    al,0x7f
  ea:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  ed:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  f0:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  f4:	08 d8                                           	or     al,bl
  f6:	0c 7f                                           	or     al,0x7f
  f8:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  fb:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  fe:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
 102:	30 d8                                           	xor    al,bl
 104:	34 7f                                           	xor    al,0x7f
 106:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
 109:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
 10c:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
 110:	fe c0                                           	inc    al
 112:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
 115:	fe c8                                           	dec    al
 117:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
 11a:	f6 d8                                           	neg    al
 11c:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
 11f:	f6 d0                                           	not    al
 121:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
 124:	86 d8                                           	xchg   al,bl
 126:	c0 e0 00                                        	shl    al,0x0
 129:	d0 e0                                           	shl    al,1
 12b:	c0 e0 07                                        	shl    al,0x7
 12e:	c0 e0 08                                        	shl    al,0x8
 131:	c0 e0 0f                                        	shl    al,0xf
 134:	c0 e0 10                                        	shl    al,0x10
 137:	c0 e0 1f                                        	shl    al,0x1f
 13a:	c0 e0 20                                        	shl    al,0x20
 13d:	c0 e0 3f                                        	shl    al,0x3f
 140:	c0 e0 40                                        	shl    al,0x40
 143:	c0 e0 ff                                        	shl    al,0xff
 146:	d2 e0                                           	shl    al,cl
 148:	c0 e8 00                                        	shr    al,0x0
 14b:	d0 e8                                           	shr    al,1
 14d:	c0 e8 07                                        	shr    al,0x7
 150:	c0 e8 08                                        	shr    al,0x8
 153:	c0 e8 0f                                        	shr    al,0xf
 156:	c0 e8 10                                        	shr    al,0x10
 159:	c0 e8 1f                                        	shr    al,0x1f
 15c:	c0 e8 20                                        	shr    al,0x20
 15f:	c0 e8 3f                                        	shr    al,0x3f
 162:	c0 e8 40                                        	shr    al,0x40
 165:	c0 e8 ff                                        	shr    al,0xff
 168:	d2 e8                                           	shr    al,cl
 16a:	c0 f8 00                                        	sar    al,0x0
 16d:	d0 f8                                           	sar    al,1
 16f:	c0 f8 07                                        	sar    al,0x7
 172:	c0 f8 08                                        	sar    al,0x8
 175:	c0 f8 0f                                        	sar    al,0xf
 178:	c0 f8 10                                        	sar    al,0x10
 17b:	c0 f8 1f                                        	sar    al,0x1f
 17e:	c0 f8 20                                        	sar    al,0x20
 181:	c0 f8 3f                                        	sar    al,0x3f
 184:	c0 f8 40                                        	sar    al,0x40
 187:	c0 f8 ff                                        	sar    al,0xff
 18a:	d2 f8                                           	sar    al,cl
 18c:	c0 c0 00                                        	rol    al,0x0
 18f:	d0 c0                                           	rol    al,1
 191:	c0 c0 07                                        	rol    al,0x7
 194:	c0 c0 08                                        	rol    al,0x8
 197:	c0 c0 0f                                        	rol    al,0xf
 19a:	c0 c0 10                                        	rol    al,0x10
 19d:	c0 c0 1f                                        	rol    al,0x1f
 1a0:	c0 c0 20                                        	rol    al,0x20
 1a3:	c0 c0 3f                                        	rol    al,0x3f
 1a6:	c0 c0 40                                        	rol    al,0x40
 1a9:	c0 c0 ff                                        	rol    al,0xff
 1ac:	d2 c0                                           	rol    al,cl
 1ae:	c0 c8 00                                        	ror    al,0x0
 1b1:	d0 c8                                           	ror    al,1
 1b3:	c0 c8 07                                        	ror    al,0x7
 1b6:	c0 c8 08                                        	ror    al,0x8
 1b9:	c0 c8 0f                                        	ror    al,0xf
 1bc:	c0 c8 10                                        	ror    al,0x10
 1bf:	c0 c8 1f                                        	ror    al,0x1f
 1c2:	c0 c8 20                                        	ror    al,0x20
 1c5:	c0 c8 3f                                        	ror    al,0x3f
 1c8:	c0 c8 40                                        	ror    al,0x40
 1cb:	c0 c8 ff                                        	ror    al,0xff
 1ce:	d2 c8                                           	ror    al,cl
 1d0:	66 89 d8                                        	mov    ax,bx
 1d3:	66 b8 7f 00                                     	mov    ax,0x7f
 1d7:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 1db:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 1df:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 1e5:	66 01 d8                                        	add    ax,bx
 1e8:	66 83 c0 7f                                     	add    ax,0x7f
 1ec:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 1f0:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 1f5:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 1f9:	66 11 d8                                        	adc    ax,bx
 1fc:	66 83 d0 7f                                     	adc    ax,0x7f
 200:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 204:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 209:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 20d:	66 29 d8                                        	sub    ax,bx
 210:	66 83 e8 7f                                     	sub    ax,0x7f
 214:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 218:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 21d:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 221:	66 19 d8                                        	sbb    ax,bx
 224:	66 83 d8 7f                                     	sbb    ax,0x7f
 228:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 22c:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 231:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 235:	66 39 d8                                        	cmp    ax,bx
 238:	66 83 f8 7f                                     	cmp    ax,0x7f
 23c:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 240:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 245:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 249:	66 85 d8                                        	test   ax,bx
 24c:	66 a9 7f 00                                     	test   ax,0x7f
 250:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 254:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 25a:	66 21 d8                                        	and    ax,bx
 25d:	66 83 e0 7f                                     	and    ax,0x7f
 261:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 265:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 269:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 26e:	66 09 d8                                        	or     ax,bx
 271:	66 83 c8 7f                                     	or     ax,0x7f
 275:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 279:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 27d:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 282:	66 31 d8                                        	xor    ax,bx
 285:	66 83 f0 7f                                     	xor    ax,0x7f
 289:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 28d:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 291:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 296:	66 ff c0                                        	inc    ax
 299:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 29d:	66 ff c8                                        	dec    ax
 2a0:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 2a4:	66 f7 d8                                        	neg    ax
 2a7:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 2ab:	66 f7 d0                                        	not    ax
 2ae:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 2b2:	66 93                                           	xchg   bx,ax
 2b4:	66 c1 e0 00                                     	shl    ax,0x0
 2b8:	66 d1 e0                                        	shl    ax,1
 2bb:	66 c1 e0 07                                     	shl    ax,0x7
 2bf:	66 c1 e0 08                                     	shl    ax,0x8
 2c3:	66 c1 e0 0f                                     	shl    ax,0xf
 2c7:	66 c1 e0 10                                     	shl    ax,0x10
 2cb:	66 c1 e0 1f                                     	shl    ax,0x1f
 2cf:	66 c1 e0 20                                     	shl    ax,0x20
 2d3:	66 c1 e0 3f                                     	shl    ax,0x3f
 2d7:	66 c1 e0 40                                     	shl    ax,0x40
 2db:	66 c1 e0 ff                                     	shl    ax,0xff
 2df:	66 d3 e0                                        	shl    ax,cl
 2e2:	66 c1 e8 00                                     	shr    ax,0x0
 2e6:	66 d1 e8                                        	shr    ax,1
 2e9:	66 c1 e8 07                                     	shr    ax,0x7
 2ed:	66 c1 e8 08                                     	shr    ax,0x8
 2f1:	66 c1 e8 0f                                     	shr    ax,0xf
 2f5:	66 c1 e8 10                                     	shr    ax,0x10
 2f9:	66 c1 e8 1f                                     	shr    ax,0x1f
 2fd:	66 c1 e8 20                                     	shr    ax,0x20
 301:	66 c1 e8 3f                                     	shr    ax,0x3f
 305:	66 c1 e8 40                                     	shr    ax,0x40
 309:	66 c1 e8 ff                                     	shr    ax,0xff
 30d:	66 d3 e8                                        	shr    ax,cl
 310:	66 c1 f8 00                                     	sar    ax,0x0
 314:	66 d1 f8                                        	sar    ax,1
 317:	66 c1 f8 07                                     	sar    ax,0x7
 31b:	66 c1 f8 08                                     	sar    ax,0x8
 31f:	66 c1 f8 0f                                     	sar    ax,0xf
 323:	66 c1 f8 10                                     	sar    ax,0x10
 327:	66 c1 f8 1f                                     	sar    ax,0x1f
 32b:	66 c1 f8 20                                     	sar    ax,0x20
 32f:	66 c1 f8 3f                                     	sar    ax,0x3f
 333:	66 c1 f8 40                                     	sar    ax,0x40
 337:	66 c1 f8 ff                                     	sar    ax,0xff
 33b:	66 d3 f8                                        	sar    ax,cl
 33e:	66 c1 c0 00                                     	rol    ax,0x0
 342:	66 d1 c0                                        	rol    ax,1
 345:	66 c1 c0 07                                     	rol    ax,0x7
 349:	66 c1 c0 08                                     	rol    ax,0x8
 34d:	66 c1 c0 0f                                     	rol    ax,0xf
 351:	66 c1 c0 10                                     	rol    ax,0x10
 355:	66 c1 c0 1f                                     	rol    ax,0x1f
 359:	66 c1 c0 20                                     	rol    ax,0x20
 35d:	66 c1 c0 3f                                     	rol    ax,0x3f
 361:	66 c1 c0 40                                     	rol    ax,0x40
 365:	66 c1 c0 ff                                     	rol    ax,0xff
 369:	66 d3 c0                                        	rol    ax,cl
 36c:	66 c1 c8 00                                     	ror    ax,0x0
 370:	66 d1 c8                                        	ror    ax,1
 373:	66 c1 c8 07                                     	ror    ax,0x7
 377:	66 c1 c8 08                                     	ror    ax,0x8
 37b:	66 c1 c8 0f                                     	ror    ax,0xf
 37f:	66 c1 c8 10                                     	ror    ax,0x10
 383:	66 c1 c8 1f                                     	ror    ax,0x1f
 387:	66 c1 c8 20                                     	ror    ax,0x20
 38b:	66 c1 c8 3f                                     	ror    ax,0x3f
 38f:	66 c1 c8 40                                     	ror    ax,0x40
 393:	66 c1 c8 ff                                     	ror    ax,0xff
 397:	66 d3 c8                                        	ror    ax,cl
 39a:	66 0f af c3                                     	imul   ax,bx
 39e:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 3a3:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 3a7:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 3ac:	66 f3 0f b8 c3                                  	popcnt ax,bx
 3b1:	66 f3 0f b8 47 08                               	popcnt ax,WORD PTR [rdi+0x8]
 3b7:	66 f7 f3                                        	div    bx
 3ba:	66 0f a3 d8                                     	bt     ax,bx
 3be:	66 0f ba e0 07                                  	bt     ax,0x7
 3c3:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 3c9:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 3cf:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 3d5:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 3da:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 3df:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 3e4:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 3e9:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 3ee:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 3f3:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 3f8:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 3fd:	89 d8                                           	mov    eax,ebx
 3ff:	b8 7f 00 00 00                                  	mov    eax,0x7f
 404:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 407:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 40a:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 411:	01 d8                                           	add    eax,ebx
 413:	83 c0 7f                                        	add    eax,0x7f
 416:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 419:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 41d:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 420:	11 d8                                           	adc    eax,ebx
 422:	83 d0 7f                                        	adc    eax,0x7f
 425:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 428:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 42c:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 42f:	29 d8                                           	sub    eax,ebx
 431:	83 e8 7f                                        	sub    eax,0x7f
 434:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 437:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 43b:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 43e:	19 d8                                           	sbb    eax,ebx
 440:	83 d8 7f                                        	sbb    eax,0x7f
 443:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 446:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 44a:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 44d:	39 d8                                           	cmp    eax,ebx
 44f:	83 f8 7f                                        	cmp    eax,0x7f
 452:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 455:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 459:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 45c:	85 d8                                           	test   eax,ebx
 45e:	a9 7f 00 00 00                                  	test   eax,0x7f
 463:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 466:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 46d:	21 d8                                           	and    eax,ebx
 46f:	83 e0 7f                                        	and    eax,0x7f
 472:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 475:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 478:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 47c:	09 d8                                           	or     eax,ebx
 47e:	83 c8 7f                                        	or     eax,0x7f
 481:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 484:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 487:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 48b:	31 d8                                           	xor    eax,ebx
 48d:	83 f0 7f                                        	xor    eax,0x7f
 490:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 493:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 496:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 49a:	ff c0                                           	inc    eax
 49c:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 49f:	ff c8                                           	dec    eax
 4a1:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 4a4:	f7 d8                                           	neg    eax
 4a6:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 4a9:	f7 d0                                           	not    eax
 4ab:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 4ae:	93                                              	xchg   ebx,eax
 4af:	c1 e0 00                                        	shl    eax,0x0
 4b2:	d1 e0                                           	shl    eax,1
 4b4:	c1 e0 07                                        	shl    eax,0x7
 4b7:	c1 e0 08                                        	shl    eax,0x8
 4ba:	c1 e0 0f                                        	shl    eax,0xf
 4bd:	c1 e0 10                                        	shl    eax,0x10
 4c0:	c1 e0 1f                                        	shl    eax,0x1f
 4c3:	c1 e0 20                                        	shl    eax,0x20
 4c6:	c1 e0 3f                                        	shl    eax,0x3f
 4c9:	c1 e0 40                                        	shl    eax,0x40
 4cc:	c1 e0 ff                                        	shl    eax,0xff
 4cf:	d3 e0                                           	shl    eax,cl
 4d1:	c1 e8 00                                        	shr    eax,0x0
 4d4:	d1 e8                                           	shr    eax,1
 4d6:	c1 e8 07                                        	shr    eax,0x7
 4d9:	c1 e8 08                                        	shr    eax,0x8
 4dc:	c1 e8 0f                                        	shr    eax,0xf
 4df:	c1 e8 10                                        	shr    eax,0x10
 4e2:	c1 e8 1f                                        	shr    eax,0x1f
 4e5:	c1 e8 20                                        	shr    eax,0x20
 4e8:	c1 e8 3f                                        	shr    eax,0x3f
 4eb:	c1 e8 40                                        	shr    eax,0x40
 4ee:	c1 e8 ff                                        	shr    eax,0xff
 4f1:	d3 e8                                           	shr    eax,cl
 4f3:	c1 f8 00                                        	sar    eax,0x0
 4f6:	d1 f8                                           	sar    eax,1
 4f8:	c1 f8 07                                        	sar    eax,0x7
 4fb:	c1 f8 08                                        	sar    eax,0x8
 4fe:	c1 f8 0f                                        	sar    eax,0xf
 501:	c1 f8 10                                        	sar    eax,0x10
 504:	c1 f8 1f                                        	sar    eax,0x1f
 507:	c1 f8 20                                        	sar    eax,0x20
 50a:	c1 f8 3f                                        	sar    eax,0x3f
 50d:	c1 f8 40                                        	sar    eax,0x40
 510:	c1 f8 ff                                        	sar    eax,0xff
 513:	d3 f8                                           	sar    eax,cl
 515:	c1 c0 00                                        	rol    eax,0x0
 518:	d1 c0                                           	rol    eax,1
 51a:	c1 c0 07                                        	rol    eax,0x7
 51d:	c1 c0 08                                        	rol    eax,0x8
 520:	c1 c0 0f                                        	rol    eax,0xf
 523:	c1 c0 10                                        	rol    eax,0x10
 526:	c1 c0 1f                                        	rol    eax,0x1f
 529:	c1 c0 20                                        	rol    eax,0x20
 52c:	c1 c0 3f                                        	rol    eax,0x3f
 52f:	c1 c0 40                                        	rol    eax,0x40
 532:	c1 c0 ff                                        	rol    eax,0xff
 535:	d3 c0                                           	rol    eax,cl
 537:	c1 c8 00                                        	ror    eax,0x0
 53a:	d1 c8                                           	ror    eax,1
 53c:	c1 c8 07                                        	ror    eax,0x7
 53f:	c1 c8 08                                        	ror    eax,0x8
 542:	c1 c8 0f                                        	ror    eax,0xf
 545:	c1 c8 10                                        	ror    eax,0x10
 548:	c1 c8 1f                                        	ror    eax,0x1f
 54b:	c1 c8 20                                        	ror    eax,0x20
 54e:	c1 c8 3f                                        	ror    eax,0x3f
 551:	c1 c8 40                                        	ror    eax,0x40
 554:	c1 c8 ff                                        	ror    eax,0xff
 557:	d3 c8                                           	ror    eax,cl
 559:	0f af c3                                        	imul   eax,ebx
 55c:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 560:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 563:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 567:	f3 0f b8 c3                                     	popcnt eax,ebx
 56b:	f3 0f b8 47 08                                  	popcnt eax,DWORD PTR [rdi+0x8]
 570:	f7 f3                                           	div    ebx
 572:	0f a3 d8                                        	bt     eax,ebx
 575:	0f ba e0 07                                     	bt     eax,0x7
 579:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 57e:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 583:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 588:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 58c:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 590:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 594:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 598:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 59c:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 5a0:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 5a4:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 5a8:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 5ac:	0f c8                                           	bswap  eax
 5ae:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 5b3:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 5b9:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 5be:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 5c4:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 5c9:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 5ce:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 5d4:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 5d9:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 5df:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 5e4:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 5ea:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 5f0:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 5f7:	48 89 d8                                        	mov    rax,rbx
 5fa:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 601:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 605:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 609:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 611:	48 01 d8                                        	add    rax,rbx
 614:	48 83 c0 7f                                     	add    rax,0x7f
 618:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 61c:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 621:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 625:	48 11 d8                                        	adc    rax,rbx
 628:	48 83 d0 7f                                     	adc    rax,0x7f
 62c:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 630:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 635:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 639:	48 29 d8                                        	sub    rax,rbx
 63c:	48 83 e8 7f                                     	sub    rax,0x7f
 640:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 644:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 649:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 64d:	48 19 d8                                        	sbb    rax,rbx
 650:	48 83 d8 7f                                     	sbb    rax,0x7f
 654:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 658:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 65d:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 661:	48 39 d8                                        	cmp    rax,rbx
 664:	48 83 f8 7f                                     	cmp    rax,0x7f
 668:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 66c:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 671:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 675:	48 85 d8                                        	test   rax,rbx
 678:	48 a9 7f 00 00 00                               	test   rax,0x7f
 67e:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 682:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 68a:	48 21 d8                                        	and    rax,rbx
 68d:	48 83 e0 7f                                     	and    rax,0x7f
 691:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 695:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 699:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 69e:	48 09 d8                                        	or     rax,rbx
 6a1:	48 83 c8 7f                                     	or     rax,0x7f
 6a5:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 6a9:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 6ad:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 6b2:	48 31 d8                                        	xor    rax,rbx
 6b5:	48 83 f0 7f                                     	xor    rax,0x7f
 6b9:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 6bd:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 6c1:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 6c6:	48 ff c0                                        	inc    rax
 6c9:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 6cd:	48 ff c8                                        	dec    rax
 6d0:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 6d4:	48 f7 d8                                        	neg    rax
 6d7:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 6db:	48 f7 d0                                        	not    rax
 6de:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 6e2:	48 93                                           	xchg   rbx,rax
 6e4:	48 c1 e0 00                                     	shl    rax,0x0
 6e8:	48 d1 e0                                        	shl    rax,1
 6eb:	48 c1 e0 07                                     	shl    rax,0x7
 6ef:	48 c1 e0 08                                     	shl    rax,0x8
 6f3:	48 c1 e0 0f                                     	shl    rax,0xf
 6f7:	48 c1 e0 10                                     	shl    rax,0x10
 6fb:	48 c1 e0 1f                                     	shl    rax,0x1f
 6ff:	48 c1 e0 20                                     	shl    rax,0x20
 703:	48 c1 e0 3f                                     	shl    rax,0x3f
 707:	48 c1 e0 40                                     	shl    rax,0x40
 70b:	48 c1 e0 ff                                     	shl    rax,0xff
 70f:	48 d3 e0                                        	shl    rax,cl
 712:	48 c1 e8 00                                     	shr    rax,0x0
 716:	48 d1 e8                                        	shr    rax,1
 719:	48 c1 e8 07                                     	shr    rax,0x7
 71d:	48 c1 e8 08                                     	shr    rax,0x8
 721:	48 c1 e8 0f                                     	shr    rax,0xf
 725:	48 c1 e8 10                                     	shr    rax,0x10
 729:	48 c1 e8 1f                                     	shr    rax,0x1f
 72d:	48 c1 e8 20                                     	shr    rax,0x20
 731:	48 c1 e8 3f                                     	shr    rax,0x3f
 735:	48 c1 e8 40                                     	shr    rax,0x40
 739:	48 c1 e8 ff                                     	shr    rax,0xff
 73d:	48 d3 e8                                        	shr    rax,cl
 740:	48 c1 f8 00                                     	sar    rax,0x0
 744:	48 d1 f8                                        	sar    rax,1
 747:	48 c1 f8 07                                     	sar    rax,0x7
 74b:	48 c1 f8 08                                     	sar    rax,0x8
 74f:	48 c1 f8 0f                                     	sar    rax,0xf
 753:	48 c1 f8 10                                     	sar    rax,0x10
 757:	48 c1 f8 1f                                     	sar    rax,0x1f
 75b:	48 c1 f8 20                                     	sar    rax,0x20
 75f:	48 c1 f8 3f                                     	sar    rax,0x3f
 763:	48 c1 f8 40                                     	sar    rax,0x40
 767:	48 c1 f8 ff                                     	sar    rax,0xff
 76b:	48 d3 f8                                        	sar    rax,cl
 76e:	48 c1 c0 00                                     	rol    rax,0x0
 772:	48 d1 c0                                        	rol    rax,1
 775:	48 c1 c0 07                                     	rol    rax,0x7
 779:	48 c1 c0 08                                     	rol    rax,0x8
 77d:	48 c1 c0 0f                                     	rol    rax,0xf
 781:	48 c1 c0 10                                     	rol    rax,0x10
 785:	48 c1 c0 1f                                     	rol    rax,0x1f
 789:	48 c1 c0 20                                     	rol    rax,0x20
 78d:	48 c1 c0 3f                                     	rol    rax,0x3f
 791:	48 c1 c0 40                                     	rol    rax,0x40
 795:	48 c1 c0 ff                                     	rol    rax,0xff
 799:	48 d3 c0                                        	rol    rax,cl
 79c:	48 c1 c8 00                                     	ror    rax,0x0
 7a0:	48 d1 c8                                        	ror    rax,1
 7a3:	48 c1 c8 07                                     	ror    rax,0x7
 7a7:	48 c1 c8 08                                     	ror    rax,0x8
 7ab:	48 c1 c8 0f                                     	ror    rax,0xf
 7af:	48 c1 c8 10                                     	ror    rax,0x10
 7b3:	48 c1 c8 1f                                     	ror    rax,0x1f
 7b7:	48 c1 c8 20                                     	ror    rax,0x20
 7bb:	48 c1 c8 3f                                     	ror    rax,0x3f
 7bf:	48 c1 c8 40                                     	ror    rax,0x40
 7c3:	48 c1 c8 ff                                     	ror    rax,0xff
 7c7:	48 d3 c8                                        	ror    rax,cl
 7ca:	48 0f af c3                                     	imul   rax,rbx
 7ce:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 7d3:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 7d7:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 7dc:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 7e1:	f3 48 0f b8 47 08                               	popcnt rax,QWORD PTR [rdi+0x8]
 7e7:	48 f7 f3                                        	div    rbx
 7ea:	48 0f a3 d8                                     	bt     rax,rbx
 7ee:	48 0f ba e0 07                                  	bt     rax,0x7
 7f3:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 7f9:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 7ff:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 805:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 80a:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 80f:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 814:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 819:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 81e:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 823:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 828:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 82d:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 832:	48 0f c8                                        	bswap  rax
 835:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 83a:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 840:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 845:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 84b:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 850:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 855:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 85b:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 860:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 866:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 86b:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 871:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 877:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 87e:	88 fc                                           	mov    ah,bh
 880:	b4 7f                                           	mov    ah,0x7f
 882:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 885:	00 fc                                           	add    ah,bh
 887:	80 c4 7f                                        	add    ah,0x7f
 88a:	10 fc                                           	adc    ah,bh
 88c:	80 d4 7f                                        	adc    ah,0x7f
 88f:	28 fc                                           	sub    ah,bh
 891:	80 ec 7f                                        	sub    ah,0x7f
 894:	18 fc                                           	sbb    ah,bh
 896:	80 dc 7f                                        	sbb    ah,0x7f
 899:	38 fc                                           	cmp    ah,bh
 89b:	80 fc 7f                                        	cmp    ah,0x7f
 89e:	84 fc                                           	test   ah,bh
 8a0:	f6 c4 7f                                        	test   ah,0x7f
 8a3:	fe c4                                           	inc    ah
 8a5:	fe cc                                           	dec    ah
 8a7:	f6 dc                                           	neg    ah
 8a9:	f6 d4                                           	not    ah
 8ab:	c0 c4 00                                        	rol    ah,0x0
 8ae:	d0 c4                                           	rol    ah,1
 8b0:	c0 c4 07                                        	rol    ah,0x7
 8b3:	c0 c4 08                                        	rol    ah,0x8
 8b6:	c0 c4 0f                                        	rol    ah,0xf
 8b9:	c0 c4 10                                        	rol    ah,0x10
 8bc:	c0 c4 1f                                        	rol    ah,0x1f
 8bf:	c0 c4 20                                        	rol    ah,0x20
 8c2:	c0 c4 3f                                        	rol    ah,0x3f
 8c5:	c0 c4 40                                        	rol    ah,0x40
 8c8:	c0 c4 ff                                        	rol    ah,0xff
 8cb:	d2 c4                                           	rol    ah,cl
 8cd:	c0 c5 00                                        	rol    ch,0x0
 8d0:	d0 c5                                           	rol    ch,1
 8d2:	c0 c5 07                                        	rol    ch,0x7
 8d5:	c0 c5 08                                        	rol    ch,0x8
 8d8:	c0 c5 0f                                        	rol    ch,0xf
 8db:	c0 c5 10                                        	rol    ch,0x10
 8de:	c0 c5 1f                                        	rol    ch,0x1f
 8e1:	c0 c5 20                                        	rol    ch,0x20
 8e4:	c0 c5 3f                                        	rol    ch,0x3f
 8e7:	c0 c5 40                                        	rol    ch,0x40
 8ea:	c0 c5 ff                                        	rol    ch,0xff
 8ed:	d2 c5                                           	rol    ch,cl
 8ef:	c0 c6 00                                        	rol    dh,0x0
 8f2:	d0 c6                                           	rol    dh,1
 8f4:	c0 c6 07                                        	rol    dh,0x7
 8f7:	c0 c6 08                                        	rol    dh,0x8
 8fa:	c0 c6 0f                                        	rol    dh,0xf
 8fd:	c0 c6 10                                        	rol    dh,0x10
 900:	c0 c6 1f                                        	rol    dh,0x1f
 903:	c0 c6 20                                        	rol    dh,0x20
 906:	c0 c6 3f                                        	rol    dh,0x3f
 909:	c0 c6 40                                        	rol    dh,0x40
 90c:	c0 c6 ff                                        	rol    dh,0xff
 90f:	d2 c6                                           	rol    dh,cl
 911:	c0 c7 00                                        	rol    bh,0x0
 914:	d0 c7                                           	rol    bh,1
 916:	c0 c7 07                                        	rol    bh,0x7
 919:	c0 c7 08                                        	rol    bh,0x8
 91c:	c0 c7 0f                                        	rol    bh,0xf
 91f:	c0 c7 10                                        	rol    bh,0x10
 922:	c0 c7 1f                                        	rol    bh,0x1f
 925:	c0 c7 20                                        	rol    bh,0x20
 928:	c0 c7 3f                                        	rol    bh,0x3f
 92b:	c0 c7 40                                        	rol    bh,0x40
 92e:	c0 c7 ff                                        	rol    bh,0xff
 931:	d2 c7                                           	rol    bh,cl
 933:	c0 cc 00                                        	ror    ah,0x0
 936:	d0 cc                                           	ror    ah,1
 938:	c0 cc 07                                        	ror    ah,0x7
 93b:	c0 cc 08                                        	ror    ah,0x8
 93e:	c0 cc 0f                                        	ror    ah,0xf
 941:	c0 cc 10                                        	ror    ah,0x10
 944:	c0 cc 1f                                        	ror    ah,0x1f
 947:	c0 cc 20                                        	ror    ah,0x20
 94a:	c0 cc 3f                                        	ror    ah,0x3f
 94d:	c0 cc 40                                        	ror    ah,0x40
 950:	c0 cc ff                                        	ror    ah,0xff
 953:	d2 cc                                           	ror    ah,cl
 955:	c0 cd 00                                        	ror    ch,0x0
 958:	d0 cd                                           	ror    ch,1
 95a:	c0 cd 07                                        	ror    ch,0x7
 95d:	c0 cd 08                                        	ror    ch,0x8
 960:	c0 cd 0f                                        	ror    ch,0xf
 963:	c0 cd 10                                        	ror    ch,0x10
 966:	c0 cd 1f                                        	ror    ch,0x1f
 969:	c0 cd 20                                        	ror    ch,0x20
 96c:	c0 cd 3f                                        	ror    ch,0x3f
 96f:	c0 cd 40                                        	ror    ch,0x40
 972:	c0 cd ff                                        	ror    ch,0xff
 975:	d2 cd                                           	ror    ch,cl
 977:	c0 ce 00                                        	ror    dh,0x0
 97a:	d0 ce                                           	ror    dh,1
 97c:	c0 ce 07                                        	ror    dh,0x7
 97f:	c0 ce 08                                        	ror    dh,0x8
 982:	c0 ce 0f                                        	ror    dh,0xf
 985:	c0 ce 10                                        	ror    dh,0x10
 988:	c0 ce 1f                                        	ror    dh,0x1f
 98b:	c0 ce 20                                        	ror    dh,0x20
 98e:	c0 ce 3f                                        	ror    dh,0x3f
 991:	c0 ce 40                                        	ror    dh,0x40
 994:	c0 ce ff                                        	ror    dh,0xff
 997:	d2 ce                                           	ror    dh,cl
 999:	c0 cf 00                                        	ror    bh,0x0
 99c:	d0 cf                                           	ror    bh,1
 99e:	c0 cf 07                                        	ror    bh,0x7
 9a1:	c0 cf 08                                        	ror    bh,0x8
 9a4:	c0 cf 0f                                        	ror    bh,0xf
 9a7:	c0 cf 10                                        	ror    bh,0x10
 9aa:	c0 cf 1f                                        	ror    bh,0x1f
 9ad:	c0 cf 20                                        	ror    bh,0x20
 9b0:	c0 cf 3f                                        	ror    bh,0x3f
 9b3:	c0 cf 40                                        	ror    bh,0x40
 9b6:	c0 cf ff                                        	ror    bh,0xff
 9b9:	d2 cf                                           	ror    bh,cl
 9bb:	c0 4f 08 00                                     	ror    BYTE PTR [rdi+0x8],0x0
 9bf:	d0 4f 08                                        	ror    BYTE PTR [rdi+0x8],1
 9c2:	c0 4f 08 07                                     	ror    BYTE PTR [rdi+0x8],0x7
 9c6:	c0 4f 08 08                                     	ror    BYTE PTR [rdi+0x8],0x8
 9ca:	c0 4f 08 0f                                     	ror    BYTE PTR [rdi+0x8],0xf
 9ce:	c0 4f 08 10                                     	ror    BYTE PTR [rdi+0x8],0x10
 9d2:	c0 4f 08 1f                                     	ror    BYTE PTR [rdi+0x8],0x1f
 9d6:	c0 4f 08 20                                     	ror    BYTE PTR [rdi+0x8],0x20
 9da:	c0 4f 08 3f                                     	ror    BYTE PTR [rdi+0x8],0x3f
 9de:	c0 4f 08 40                                     	ror    BYTE PTR [rdi+0x8],0x40
 9e2:	c0 4f 08 ff                                     	ror    BYTE PTR [rdi+0x8],0xff
 9e6:	d2 4f 08                                        	ror    BYTE PTR [rdi+0x8],cl
 9e9:	66 c1 4f 08 00                                  	ror    WORD PTR [rdi+0x8],0x0
 9ee:	66 d1 4f 08                                     	ror    WORD PTR [rdi+0x8],1
 9f2:	66 c1 4f 08 07                                  	ror    WORD PTR [rdi+0x8],0x7
 9f7:	66 c1 4f 08 08                                  	ror    WORD PTR [rdi+0x8],0x8
 9fc:	66 c1 4f 08 0f                                  	ror    WORD PTR [rdi+0x8],0xf
 a01:	66 c1 4f 08 10                                  	ror    WORD PTR [rdi+0x8],0x10
 a06:	66 c1 4f 08 1f                                  	ror    WORD PTR [rdi+0x8],0x1f
 a0b:	66 c1 4f 08 20                                  	ror    WORD PTR [rdi+0x8],0x20
 a10:	66 c1 4f 08 3f                                  	ror    WORD PTR [rdi+0x8],0x3f
 a15:	66 c1 4f 08 40                                  	ror    WORD PTR [rdi+0x8],0x40
 a1a:	66 c1 4f 08 ff                                  	ror    WORD PTR [rdi+0x8],0xff
 a1f:	66 d3 4f 08                                     	ror    WORD PTR [rdi+0x8],cl
 a23:	c1 4f 08 00                                     	ror    DWORD PTR [rdi+0x8],0x0
 a27:	d1 4f 08                                        	ror    DWORD PTR [rdi+0x8],1
 a2a:	c1 4f 08 07                                     	ror    DWORD PTR [rdi+0x8],0x7
 a2e:	c1 4f 08 08                                     	ror    DWORD PTR [rdi+0x8],0x8
 a32:	c1 4f 08 0f                                     	ror    DWORD PTR [rdi+0x8],0xf
 a36:	c1 4f 08 10                                     	ror    DWORD PTR [rdi+0x8],0x10
 a3a:	c1 4f 08 1f                                     	ror    DWORD PTR [rdi+0x8],0x1f
 a3e:	c1 4f 08 20                                     	ror    DWORD PTR [rdi+0x8],0x20
 a42:	c1 4f 08 3f                                     	ror    DWORD PTR [rdi+0x8],0x3f
 a46:	c1 4f 08 40                                     	ror    DWORD PTR [rdi+0x8],0x40
 a4a:	c1 4f 08 ff                                     	ror    DWORD PTR [rdi+0x8],0xff
 a4e:	d3 4f 08                                        	ror    DWORD PTR [rdi+0x8],cl
 a51:	48 c1 4f 08 00                                  	ror    QWORD PTR [rdi+0x8],0x0
 a56:	48 d1 4f 08                                     	ror    QWORD PTR [rdi+0x8],1
 a5a:	48 c1 4f 08 07                                  	ror    QWORD PTR [rdi+0x8],0x7
 a5f:	48 c1 4f 08 08                                  	ror    QWORD PTR [rdi+0x8],0x8
 a64:	48 c1 4f 08 0f                                  	ror    QWORD PTR [rdi+0x8],0xf
 a69:	48 c1 4f 08 10                                  	ror    QWORD PTR [rdi+0x8],0x10
 a6e:	48 c1 4f 08 1f                                  	ror    QWORD PTR [rdi+0x8],0x1f
 a73:	48 c1 4f 08 20                                  	ror    QWORD PTR [rdi+0x8],0x20
 a78:	48 c1 4f 08 3f                                  	ror    QWORD PTR [rdi+0x8],0x3f
 a7d:	48 c1 4f 08 40                                  	ror    QWORD PTR [rdi+0x8],0x40
 a82:	48 c1 4f 08 ff                                  	ror    QWORD PTR [rdi+0x8],0xff
 a87:	48 d3 4f 08                                     	ror    QWORD PTR [rdi+0x8],cl
 a8b:	66 0f b6 c3                                     	movzx  ax,bl
 a8f:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 a94:	66 0f be c3                                     	movsx  ax,bl
 a98:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 a9d:	0f b6 c3                                        	movzx  eax,bl
 aa0:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 aa4:	0f be c3                                        	movsx  eax,bl
 aa7:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 aab:	0f b7 c3                                        	movzx  eax,bx
 aae:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 ab2:	0f bf c3                                        	movsx  eax,bx
 ab5:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 ab9:	48 0f b6 c3                                     	movzx  rax,bl
 abd:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 ac2:	48 0f be c3                                     	movsx  rax,bl
 ac6:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 acb:	48 0f b7 c3                                     	movzx  rax,bx
 acf:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 ad4:	48 0f bf c3                                     	movsx  rax,bx
 ad8:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 add:	48 63 c3                                        	movsxd rax,ebx
 ae0:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 ae4:	66 8d 03                                        	lea    ax,[rbx]
 ae7:	66 8d 43 7f                                     	lea    ax,[rbx+0x7f]
 aeb:	66 8d 43 80                                     	lea    ax,[rbx-0x80]
 aef:	66 8d 44 4b f9                                  	lea    ax,[rbx+rcx*2-0x7]
 af4:	66 43 8d 84 88 ff ff ff 7f                      	lea    ax,[r8+r9*4+0x7fffffff]
 afd:	66 43 8d 84 c8 00 00 00 80                      	lea    ax,[r8+r9*8-0x80000000]
 b06:	66 8d 04 cd 7f 00 00 00                         	lea    ax,[rcx*8+0x7f]
 b0e:	66 8d 04 25 78 56 34 12                         	lea    ax,ds:0x12345678
 b16:	67 66 8d 44 8b f9                               	lea    ax,[ebx+ecx*4-0x7]
 b1c:	67 66 43 8d 44 c8 7f                            	lea    ax,[r8d+r9d*8+0x7f]
 b23:	8d 03                                           	lea    eax,[rbx]
 b25:	8d 43 7f                                        	lea    eax,[rbx+0x7f]
 b28:	8d 43 80                                        	lea    eax,[rbx-0x80]
 b2b:	8d 44 4b f9                                     	lea    eax,[rbx+rcx*2-0x7]
 b2f:	43 8d 84 88 ff ff ff 7f                         	lea    eax,[r8+r9*4+0x7fffffff]
 b37:	43 8d 84 c8 00 00 00 80                         	lea    eax,[r8+r9*8-0x80000000]
 b3f:	8d 04 cd 7f 00 00 00                            	lea    eax,[rcx*8+0x7f]
 b46:	8d 04 25 78 56 34 12                            	lea    eax,ds:0x12345678
 b4d:	67 8d 44 8b f9                                  	lea    eax,[ebx+ecx*4-0x7]
 b52:	67 43 8d 44 c8 7f                               	lea    eax,[r8d+r9d*8+0x7f]
 b58:	48 8d 03                                        	lea    rax,[rbx]
 b5b:	48 8d 43 7f                                     	lea    rax,[rbx+0x7f]
 b5f:	48 8d 43 80                                     	lea    rax,[rbx-0x80]
 b63:	48 8d 44 4b f9                                  	lea    rax,[rbx+rcx*2-0x7]
 b68:	4b 8d 84 88 ff ff ff 7f                         	lea    rax,[r8+r9*4+0x7fffffff]
 b70:	4b 8d 84 c8 00 00 00 80                         	lea    rax,[r8+r9*8-0x80000000]
 b78:	48 8d 04 cd 7f 00 00 00                         	lea    rax,[rcx*8+0x7f]
 b80:	48 8d 04 25 78 56 34 12                         	lea    rax,ds:0x12345678
 b88:	67 48 8d 44 8b f9                               	lea    rax,[ebx+ecx*4-0x7]
 b8e:	67 4b 8d 44 c8 7f                               	lea    rax,[r8d+r9d*8+0x7f]
 b94:	66 44 8d 03                                     	lea    r8w,[rbx]
 b98:	66 44 8d 43 7f                                  	lea    r8w,[rbx+0x7f]
 b9d:	66 44 8d 43 80                                  	lea    r8w,[rbx-0x80]
 ba2:	66 44 8d 44 4b f9                               	lea    r8w,[rbx+rcx*2-0x7]
 ba8:	66 47 8d 84 88 ff ff ff 7f                      	lea    r8w,[r8+r9*4+0x7fffffff]
 bb1:	66 47 8d 84 c8 00 00 00 80                      	lea    r8w,[r8+r9*8-0x80000000]
 bba:	66 44 8d 04 cd 7f 00 00 00                      	lea    r8w,[rcx*8+0x7f]
 bc3:	66 44 8d 04 25 78 56 34 12                      	lea    r8w,ds:0x12345678
 bcc:	67 66 44 8d 44 8b f9                            	lea    r8w,[ebx+ecx*4-0x7]
 bd3:	67 66 47 8d 44 c8 7f                            	lea    r8w,[r8d+r9d*8+0x7f]
 bda:	44 8d 03                                        	lea    r8d,[rbx]
 bdd:	44 8d 43 7f                                     	lea    r8d,[rbx+0x7f]
 be1:	44 8d 43 80                                     	lea    r8d,[rbx-0x80]
 be5:	44 8d 44 4b f9                                  	lea    r8d,[rbx+rcx*2-0x7]
 bea:	47 8d 84 88 ff ff ff 7f                         	lea    r8d,[r8+r9*4+0x7fffffff]
 bf2:	47 8d 84 c8 00 00 00 80                         	lea    r8d,[r8+r9*8-0x80000000]
 bfa:	44 8d 04 cd 7f 00 00 00                         	lea    r8d,[rcx*8+0x7f]
 c02:	44 8d 04 25 78 56 34 12                         	lea    r8d,ds:0x12345678
 c0a:	67 44 8d 44 8b f9                               	lea    r8d,[ebx+ecx*4-0x7]
 c10:	67 47 8d 44 c8 7f                               	lea    r8d,[r8d+r9d*8+0x7f]
 c16:	4c 8d 03                                        	lea    r8,[rbx]
 c19:	4c 8d 43 7f                                     	lea    r8,[rbx+0x7f]
 c1d:	4c 8d 43 80                                     	lea    r8,[rbx-0x80]
 c21:	4c 8d 44 4b f9                                  	lea    r8,[rbx+rcx*2-0x7]
 c26:	4f 8d 84 88 ff ff ff 7f                         	lea    r8,[r8+r9*4+0x7fffffff]
 c2e:	4f 8d 84 c8 00 00 00 80                         	lea    r8,[r8+r9*8-0x80000000]
 c36:	4c 8d 04 cd 7f 00 00 00                         	lea    r8,[rcx*8+0x7f]
 c3e:	4c 8d 04 25 78 56 34 12                         	lea    r8,ds:0x12345678
 c46:	67 4c 8d 44 8b f9                               	lea    r8,[ebx+ecx*4-0x7]
 c4c:	67 4f 8d 44 c8 7f                               	lea    r8,[r8d+r9d*8+0x7f]
 c52:	48 8d 1c cb                                     	lea    rbx,[rbx+rcx*8]
 c56:	48 8d 0c cb                                     	lea    rcx,[rbx+rcx*8]
 c5a:	4f 8d 4c 48 f9                                  	lea    r9,[r8+r9*2-0x7]
 c5f:	64 66 8d 44 4b f9                               	lea    ax,fs:[rbx+rcx*2-0x7]
 c65:	65 66 8d 44 4b f9                               	lea    ax,gs:[rbx+rcx*2-0x7]
 c6b:	64 8d 44 4b f9                                  	lea    eax,fs:[rbx+rcx*2-0x7]
 c70:	65 8d 44 4b f9                                  	lea    eax,gs:[rbx+rcx*2-0x7]
 c75:	64 48 8d 44 4b f9                               	lea    rax,fs:[rbx+rcx*2-0x7]
 c7b:	65 48 8d 44 4b f9                               	lea    rax,gs:[rbx+rcx*2-0x7]
 c81:	8a 67 08                                        	mov    ah,BYTE PTR [rdi+0x8]
 c84:	8a 66 10                                        	mov    ah,BYTE PTR [rsi+0x10]
 c87:	8a 64 24 f0                                     	mov    ah,BYTE PTR [rsp-0x10]
 c8b:	8a 6f 08                                        	mov    ch,BYTE PTR [rdi+0x8]
 c8e:	8a 6e 10                                        	mov    ch,BYTE PTR [rsi+0x10]
 c91:	8a 6c 24 f0                                     	mov    ch,BYTE PTR [rsp-0x10]
 c95:	8a 77 08                                        	mov    dh,BYTE PTR [rdi+0x8]
 c98:	8a 76 10                                        	mov    dh,BYTE PTR [rsi+0x10]
 c9b:	8a 74 24 f0                                     	mov    dh,BYTE PTR [rsp-0x10]
 c9f:	8a 7f 08                                        	mov    bh,BYTE PTR [rdi+0x8]
 ca2:	8a 7e 10                                        	mov    bh,BYTE PTR [rsi+0x10]
 ca5:	8a 7c 24 f0                                     	mov    bh,BYTE PTR [rsp-0x10]
 ca9:	0f 97 c0                                        	seta   al
 cac:	0f 97 c4                                        	seta   ah
 caf:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 cb3:	0f 93 c0                                        	setae  al
 cb6:	0f 93 c4                                        	setae  ah
 cb9:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 cbd:	0f 92 c0                                        	setb   al
 cc0:	0f 92 c4                                        	setb   ah
 cc3:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 cc7:	0f 96 c0                                        	setbe  al
 cca:	0f 96 c4                                        	setbe  ah
 ccd:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 cd1:	0f 94 c0                                        	sete   al
 cd4:	0f 94 c4                                        	sete   ah
 cd7:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 cdb:	0f 9f c0                                        	setg   al
 cde:	0f 9f c4                                        	setg   ah
 ce1:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 ce5:	0f 9d c0                                        	setge  al
 ce8:	0f 9d c4                                        	setge  ah
 ceb:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 cef:	0f 9c c0                                        	setl   al
 cf2:	0f 9c c4                                        	setl   ah
 cf5:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 cf9:	0f 9e c0                                        	setle  al
 cfc:	0f 9e c4                                        	setle  ah
 cff:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 d03:	0f 95 c0                                        	setne  al
 d06:	0f 95 c4                                        	setne  ah
 d09:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 d0d:	0f 99 c0                                        	setns  al
 d10:	0f 99 c4                                        	setns  ah
 d13:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 d17:	0f 98 c0                                        	sets   al
 d1a:	0f 98 c4                                        	sets   ah
 d1d:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 d21:	0f 90 c0                                        	seto   al
 d24:	0f 90 c4                                        	seto   ah
 d27:	0f 90 47 08                                     	seto   BYTE PTR [rdi+0x8]
 d2b:	0f 91 c0                                        	setno  al
 d2e:	0f 91 c4                                        	setno  ah
 d31:	0f 91 47 08                                     	setno  BYTE PTR [rdi+0x8]
 d35:	0f 9a c0                                        	setp   al
 d38:	0f 9a c4                                        	setp   ah
 d3b:	0f 9a 47 08                                     	setp   BYTE PTR [rdi+0x8]
 d3f:	0f 9a c0                                        	setp   al
 d42:	0f 9a c4                                        	setp   ah
 d45:	0f 9a 47 08                                     	setp   BYTE PTR [rdi+0x8]
 d49:	0f 9b c0                                        	setnp  al
 d4c:	0f 9b c4                                        	setnp  ah
 d4f:	0f 9b 47 08                                     	setnp  BYTE PTR [rdi+0x8]
 d53:	0f 9b c0                                        	setnp  al
 d56:	0f 9b c4                                        	setnp  ah
 d59:	0f 9b 47 08                                     	setnp  BYTE PTR [rdi+0x8]
 d5d:	66 0f 47 c3                                     	cmova  ax,bx
 d61:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 d66:	0f 47 c3                                        	cmova  eax,ebx
 d69:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 d6d:	48 0f 47 c3                                     	cmova  rax,rbx
 d71:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 d76:	66 0f 42 c3                                     	cmovb  ax,bx
 d7a:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 d7f:	0f 42 c3                                        	cmovb  eax,ebx
 d82:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 d86:	48 0f 42 c3                                     	cmovb  rax,rbx
 d8a:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 d8f:	66 0f 46 c3                                     	cmovbe ax,bx
 d93:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 d98:	0f 46 c3                                        	cmovbe eax,ebx
 d9b:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 d9f:	48 0f 46 c3                                     	cmovbe rax,rbx
 da3:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 da8:	66 0f 44 c3                                     	cmove  ax,bx
 dac:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 db1:	0f 44 c3                                        	cmove  eax,ebx
 db4:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 db8:	48 0f 44 c3                                     	cmove  rax,rbx
 dbc:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 dc1:	66 0f 4f c3                                     	cmovg  ax,bx
 dc5:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 dca:	0f 4f c3                                        	cmovg  eax,ebx
 dcd:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 dd1:	48 0f 4f c3                                     	cmovg  rax,rbx
 dd5:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
 dda:	66 0f 4d c3                                     	cmovge ax,bx
 dde:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 de3:	0f 4d c3                                        	cmovge eax,ebx
 de6:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 dea:	48 0f 4d c3                                     	cmovge rax,rbx
 dee:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 df3:	66 0f 43 c3                                     	cmovae ax,bx
 df7:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 dfc:	0f 43 c3                                        	cmovae eax,ebx
 dff:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 e03:	48 0f 43 c3                                     	cmovae rax,rbx
 e07:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 e0c:	66 0f 4c c3                                     	cmovl  ax,bx
 e10:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 e15:	0f 4c c3                                        	cmovl  eax,ebx
 e18:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 e1c:	48 0f 4c c3                                     	cmovl  rax,rbx
 e20:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 e25:	66 0f 4e c3                                     	cmovle ax,bx
 e29:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 e2e:	0f 4e c3                                        	cmovle eax,ebx
 e31:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 e35:	48 0f 4e c3                                     	cmovle rax,rbx
 e39:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 e3e:	66 0f 45 c3                                     	cmovne ax,bx
 e42:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 e47:	0f 45 c3                                        	cmovne eax,ebx
 e4a:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 e4e:	48 0f 45 c3                                     	cmovne rax,rbx
 e52:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 e57:	66 0f 49 c3                                     	cmovns ax,bx
 e5b:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 e60:	0f 49 c3                                        	cmovns eax,ebx
 e63:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 e67:	48 0f 49 c3                                     	cmovns rax,rbx
 e6b:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 e70:	66 0f 48 c3                                     	cmovs  ax,bx
 e74:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 e79:	0f 48 c3                                        	cmovs  eax,ebx
 e7c:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 e80:	48 0f 48 c3                                     	cmovs  rax,rbx
 e84:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
 e89:	66 0f 40 c3                                     	cmovo  ax,bx
 e8d:	66 0f 40 47 08                                  	cmovo  ax,WORD PTR [rdi+0x8]
 e92:	0f 40 c3                                        	cmovo  eax,ebx
 e95:	0f 40 47 08                                     	cmovo  eax,DWORD PTR [rdi+0x8]
 e99:	48 0f 40 c3                                     	cmovo  rax,rbx
 e9d:	48 0f 40 47 08                                  	cmovo  rax,QWORD PTR [rdi+0x8]
 ea2:	66 0f 41 c3                                     	cmovno ax,bx
 ea6:	66 0f 41 47 08                                  	cmovno ax,WORD PTR [rdi+0x8]
 eab:	0f 41 c3                                        	cmovno eax,ebx
 eae:	0f 41 47 08                                     	cmovno eax,DWORD PTR [rdi+0x8]
 eb2:	48 0f 41 c3                                     	cmovno rax,rbx
 eb6:	48 0f 41 47 08                                  	cmovno rax,QWORD PTR [rdi+0x8]
 ebb:	66 0f 4a c3                                     	cmovp  ax,bx
 ebf:	66 0f 4a 47 08                                  	cmovp  ax,WORD PTR [rdi+0x8]
 ec4:	0f 4a c3                                        	cmovp  eax,ebx
 ec7:	0f 4a 47 08                                     	cmovp  eax,DWORD PTR [rdi+0x8]
 ecb:	48 0f 4a c3                                     	cmovp  rax,rbx
 ecf:	48 0f 4a 47 08                                  	cmovp  rax,QWORD PTR [rdi+0x8]
 ed4:	66 0f 4a c3                                     	cmovp  ax,bx
 ed8:	66 0f 4a 47 08                                  	cmovp  ax,WORD PTR [rdi+0x8]
 edd:	0f 4a c3                                        	cmovp  eax,ebx
 ee0:	0f 4a 47 08                                     	cmovp  eax,DWORD PTR [rdi+0x8]
 ee4:	48 0f 4a c3                                     	cmovp  rax,rbx
 ee8:	48 0f 4a 47 08                                  	cmovp  rax,QWORD PTR [rdi+0x8]
 eed:	66 0f 4b c3                                     	cmovnp ax,bx
 ef1:	66 0f 4b 47 08                                  	cmovnp ax,WORD PTR [rdi+0x8]
 ef6:	0f 4b c3                                        	cmovnp eax,ebx
 ef9:	0f 4b 47 08                                     	cmovnp eax,DWORD PTR [rdi+0x8]
 efd:	48 0f 4b c3                                     	cmovnp rax,rbx
 f01:	48 0f 4b 47 08                                  	cmovnp rax,QWORD PTR [rdi+0x8]
 f06:	66 0f 4b c3                                     	cmovnp ax,bx
 f0a:	66 0f 4b 47 08                                  	cmovnp ax,WORD PTR [rdi+0x8]
 f0f:	0f 4b c3                                        	cmovnp eax,ebx
 f12:	0f 4b 47 08                                     	cmovnp eax,DWORD PTR [rdi+0x8]
 f16:	48 0f 4b c3                                     	cmovnp rax,rbx
 f1a:	48 0f 4b 47 08                                  	cmovnp rax,QWORD PTR [rdi+0x8]
 f1f:	30 c0                                           	xor    al,al
 f21:	30 c9                                           	xor    cl,cl
 f23:	30 d2                                           	xor    dl,dl
 f25:	30 db                                           	xor    bl,bl
 f27:	40 30 e4                                        	xor    spl,spl
 f2a:	40 30 ed                                        	xor    bpl,bpl
 f2d:	40 30 f6                                        	xor    sil,sil
 f30:	40 30 ff                                        	xor    dil,dil
 f33:	66 31 c0                                        	xor    ax,ax
 f36:	66 31 c9                                        	xor    cx,cx
 f39:	66 31 d2                                        	xor    dx,dx
 f3c:	66 31 db                                        	xor    bx,bx
 f3f:	66 31 e4                                        	xor    sp,sp
 f42:	66 31 ed                                        	xor    bp,bp
 f45:	66 31 f6                                        	xor    si,si
 f48:	66 31 ff                                        	xor    di,di
 f4b:	31 c0                                           	xor    eax,eax
 f4d:	31 c9                                           	xor    ecx,ecx
 f4f:	31 d2                                           	xor    edx,edx
 f51:	31 db                                           	xor    ebx,ebx
 f53:	31 e4                                           	xor    esp,esp
 f55:	31 ed                                           	xor    ebp,ebp
 f57:	31 f6                                           	xor    esi,esi
 f59:	31 ff                                           	xor    edi,edi
 f5b:	48 31 c0                                        	xor    rax,rax
 f5e:	48 31 c9                                        	xor    rcx,rcx
 f61:	48 31 d2                                        	xor    rdx,rdx
 f64:	48 31 db                                        	xor    rbx,rbx
 f67:	48 31 e4                                        	xor    rsp,rsp
 f6a:	48 31 ed                                        	xor    rbp,rbp
 f6d:	48 31 f6                                        	xor    rsi,rsi
 f70:	48 31 ff                                        	xor    rdi,rdi
 f73:	45 30 c0                                        	xor    r8b,r8b
 f76:	66 45 31 c0                                     	xor    r8w,r8w
 f7a:	45 31 c0                                        	xor    r8d,r8d
 f7d:	4d 31 c0                                        	xor    r8,r8
 f80:	45 30 c9                                        	xor    r9b,r9b
 f83:	66 45 31 c9                                     	xor    r9w,r9w
 f87:	45 31 c9                                        	xor    r9d,r9d
 f8a:	4d 31 c9                                        	xor    r9,r9
 f8d:	45 30 d2                                        	xor    r10b,r10b
 f90:	66 45 31 d2                                     	xor    r10w,r10w
 f94:	45 31 d2                                        	xor    r10d,r10d
 f97:	4d 31 d2                                        	xor    r10,r10
 f9a:	45 30 db                                        	xor    r11b,r11b
 f9d:	66 45 31 db                                     	xor    r11w,r11w
 fa1:	45 31 db                                        	xor    r11d,r11d
 fa4:	4d 31 db                                        	xor    r11,r11
 fa7:	45 30 e4                                        	xor    r12b,r12b
 faa:	66 45 31 e4                                     	xor    r12w,r12w
 fae:	45 31 e4                                        	xor    r12d,r12d
 fb1:	4d 31 e4                                        	xor    r12,r12
 fb4:	45 30 ed                                        	xor    r13b,r13b
 fb7:	66 45 31 ed                                     	xor    r13w,r13w
 fbb:	45 31 ed                                        	xor    r13d,r13d
 fbe:	4d 31 ed                                        	xor    r13,r13
 fc1:	45 30 f6                                        	xor    r14b,r14b
 fc4:	66 45 31 f6                                     	xor    r14w,r14w
 fc8:	45 31 f6                                        	xor    r14d,r14d
 fcb:	4d 31 f6                                        	xor    r14,r14
 fce:	45 30 ff                                        	xor    r15b,r15b
 fd1:	66 45 31 ff                                     	xor    r15w,r15w
 fd5:	45 31 ff                                        	xor    r15d,r15d
 fd8:	4d 31 ff                                        	xor    r15,r15
