
/workspaces/repository/kprog/fidelity/build-multiply-xchg/source/kprog/fidelity/build-cpu/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	86 d8                                           	xchg   al,bl
   2:	66 93                                           	xchg   bx,ax
   4:	66 0f af c3                                     	imul   ax,bx
   8:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
   d:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
  11:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
  16:	93                                              	xchg   ebx,eax
  17:	0f af c3                                        	imul   eax,ebx
  1a:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
  1e:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
  21:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
  25:	48 93                                           	xchg   rbx,rax
  27:	48 0f af c3                                     	imul   rax,rbx
  2b:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
  30:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
  34:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
