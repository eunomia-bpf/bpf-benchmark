set -eu
D=/workspaces/.agent-state/kprog-lanes/C/partial-gpr-tagged-candidate
trap 'echo $? > "$D/host.exit"' EXIT
cd /workspaces/repository
cc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I"$D/include" -Ikprog/formal kprog/formal/oracles/test_x86_mov_handler_host.c -o "$D/mov-host"
"$D/mov-host"
