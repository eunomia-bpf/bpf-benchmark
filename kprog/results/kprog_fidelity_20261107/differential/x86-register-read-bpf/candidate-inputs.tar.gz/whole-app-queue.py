from pathlib import Path
import os,select,subprocess,json,hashlib
from datetime import datetime,timezone
R=Path('/workspaces/repository');C=Path('/workspaces/.agent-state/kprog-lanes/C');Q=Path(__file__).parent;H=R/'corpus/results/kprog_app_coverage_20261107/native-only-runtime';L=C/'lea-production-integration';P=C/'native-core-helper-candidate';T=C/'remaining-apps-coherent/tetragon__observer'
assert (C/'lea-stack-wrapping/run.exit').read_text().strip()=='0'
assert (C/'partial-gpr-tagged-candidate/host.exit').read_text().strip()=='0'
for app,label,image in [('katran','katran-tagged-storage','bpf-benchmark/kprog-native-only:x86-current'),('tracee/monitor','tracee-narrow-range','bpf-benchmark/kprog-native-core:c-20261107')]:
 slug=app.replace('/','__');D=Q/slug;D.mkdir();O=R/'corpus/results/kprog_app_coverage_20261107'/label;O.mkdir()
 if app=='tracee/monitor':
  with (Q/'image-build.log').open('wb') as log:b=subprocess.run(['docker','build','-f',str(P/'image-context/Dockerfile'),'-t',image,str(P/'image-context')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (Q/'image-build.exit').write_text(str(b.returncode)+'\n');b.check_returncode()
 image_json=subprocess.check_output(['docker','image','inspect',image],cwd=R);(D/'image-inputs.json').write_bytes(image_json)
 old=json.loads((T/'running-inputs.json').read_text());files=set(old['sha256'])|{'kprog/x86/micro-prog/x86_abi.py','kprog/formal/generated/x86_mem_offset.h','kprog/formal/tools/generate_x86_mem_offset_spec.py','vendor/bpf/native_compat.h'}
 files|={str(p.relative_to(R)) for root in [R/'kprog/formal/generated',R/'kprog/x86'] for p in root.glob('*.h')};files|={str(p.relative_to(R)) for p in (R/'kprog/x86/micro-prog').glob('*.py')}
 pins=dict(cpus='20-23',vcpus=8,guest_memory='12G',samples=1,duration=2,app=app,started=datetime.now(timezone.utc).isoformat(),source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sha256={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in sorted(files)},image=json.loads(image_json)[0]['Id'],producer_increments=['binary_elf_readonly_reader','finite_affine_stack_origins','lea_unit_rcx_and_wrapping_offset','consistent_external_slot_joins','wrapping_rsp_sum','private_generic_register_representation'])
 for n in sorted(files):
  if n.endswith(('.py','.h','.cpp','Makefile','Dockerfile')):
   p=D/'source-pins'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
 (D/'guest-before.py').write_bytes((H/'guest.py').read_bytes());(D/'package-inputs.json').write_bytes((H/'package-inputs.json').read_bytes())
 guest=(H/'guest.py').read_text().replace('O=Path(__file__).resolve().parent',"O=R/'corpus/results/kprog_app_coverage_20261107/native-only-runtime'").replace('bpf-benchmark/kprog-native-only:x86-current',image);(D/'guest.py').write_text(guest)
 candidate=(C/'partial-gpr-tagged-candidate/include/generated/x86_reg_write.h') if app=='katran' else (C/'narrow-read-range-candidate/include/generated/x86_reg_read.h')
 (D/'candidate-include.h').write_bytes(candidate.read_bytes());compiler=D/'clang-candidate';compiler.write_text('#!/bin/sh\nexec /usr/lib/llvm-18/bin/clang -include '+str(D/'candidate-include.h')+' "$@"\n');compiler.chmod(0o755)
 pins['candidate_include']={'source_path':str(candidate),'sha256':hashlib.sha256(candidate.read_bytes()).hexdigest()};pins['candidate_compiler']={'path':str(compiler),'sha256':hashlib.sha256(compiler.read_bytes()).hexdigest()}
 make=(H/'Makefile').read_text().replace('HERE := $(ROOT)/corpus/results/kprog_app_coverage_20261107/native-only-runtime','HERE := '+str(D)).replace("--exec 'BPFREJIT","--exec 'CLANG="+str(compiler)+" BPFREJIT");(D/'Makefile').write_text(make)
 run=(T/'run.sh').read_text().replace(str(T),str(D)).replace('make -f corpus/results/kprog_app_coverage_20261107/native-only-runtime/Makefile','make -f '+str(D/'Makefile')).replace('APPS=tetragon/observer','APPS='+app).replace(' corpus STATE=',' corpus IMAGE='+image+' STATE=');(D/'run.sh').write_text(run)
 col=(T/'collect.py').read_text().replace(str(T),str(D)).replace('native-coherent-tetragon__observer',label).replace('tetragon__observer',slug).replace("'source-pins','package-inputs.json']","'source-pins','package-inputs.json','image-inputs.json','guest.py','Makefile','candidate-include.h','clang-candidate']");(D/'collect.py').write_text(col)
 with (D/'run.log').open('wb') as log:p=subprocess.Popen(['nohup','sh',str(D/'run.sh')],cwd=R,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 pins['driver_pid']=p.pid;(D/'running-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print('APP_STARTED',app,p.pid,flush=True)
 with (C.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL C '+pins['started']+': Whole '+app+' replay START driver'+str(p.pid)+',12GiB/eight guest vCPUs/20-23,one sample/two-second workload. Runtime source captures binary readonly ELF extraction, finite affine helper stack origins and shared LEA correction; image'+pins['image']+' and kernel-owned native inputs stay explicit. Each app receives common registered service generation, kernel verification and binding.\n')
 rc=p.wait()
 with (D/'collect.log').open('wb') as log:done=subprocess.run(['python3',str(D/'collect.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (D/'collect.exit').write_text(str(done.returncode)+'\n');print('APP_CLOSED',app,'driver',rc,'collector',done.returncode,flush=True)
 if app=='tracee/monitor':
  with (D/'image-retire.log').open('wb') as log:clean=subprocess.run(['docker','image','rm',image],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  (D/'image-retire.exit').write_text(str(clean.returncode)+'\n')
print('BATCH_CLOSED',flush=True)
