	.text
	.file	"width-shapes.c"
	.globl	read_low8                       # -- Begin function read_low8
	.p2align	3
	.type	read_low8,@function
read_low8:                              # @read_low8
# %bb.0:
	r0 = r1
	#APP
	r0 &= 255
	#NO_APP
	exit
.Lfunc_end0:
	.size	read_low8, .Lfunc_end0-read_low8
                                        # -- End function
	.globl	read_high8                      # -- Begin function read_high8
	.p2align	3
	.type	read_high8,@function
read_high8:                             # @read_high8
# %bb.0:
	r0 = r1
	r0 >>= 8
	#APP
	r0 &= 255
	#NO_APP
	exit
.Lfunc_end1:
	.size	read_high8, .Lfunc_end1-read_high8
                                        # -- End function
	.globl	read_word                       # -- Begin function read_word
	.p2align	3
	.type	read_word,@function
read_word:                              # @read_word
# %bb.0:
	r0 = r1
	#APP
	r0 &= 65535
	#NO_APP
	exit
.Lfunc_end2:
	.size	read_word, .Lfunc_end2-read_word
                                        # -- End function
	.globl	read_dword                      # -- Begin function read_dword
	.p2align	3
	.type	read_dword,@function
read_dword:                             # @read_dword
# %bb.0:
	r0 = r1
	r0 <<= 32
	r0 >>= 32
	exit
.Lfunc_end3:
	.size	read_dword, .Lfunc_end3-read_dword
                                        # -- End function
	.globl	read_qword                      # -- Begin function read_qword
	.p2align	3
	.type	read_qword,@function
read_qword:                             # @read_qword
# %bb.0:
	r0 = r1
	exit
.Lfunc_end4:
	.size	read_qword, .Lfunc_end4-read_qword
                                        # -- End function
	.globl	indexed                         # -- Begin function indexed
	.p2align	3
	.type	indexed,@function
indexed:                                # @indexed
# %bb.0:
	r3 = r1
	#APP
	r3 &= 255
	#NO_APP
	w0 = 0
	if r3 > 15 goto LBB5_2
# %bb.1:
	r3 <<= 2
	r2 += r3
	w0 = *(u32 *)(r2 + 0)
	r1 >>= 8
	w0 += w1
LBB5_2:
	exit
.Lfunc_end5:
	.size	indexed, .Lfunc_end5-indexed
                                        # -- End function
	.addrsig
