	.text
	.file	"pure-mask.c"
	.globl	range_read                      # -- Begin function range_read
	.p2align	3
	.type	range_read,@function
range_read:                             # @range_read
# %bb.0:
	#APP
	r1 &= 255
	#NO_APP
	r0 = 0
	if r1 > 15 goto LBB0_2
# %bb.1:
	r1 <<= 2
	r2 += r1
	r0 = *(u32 *)(r2 + 0)
LBB0_2:
	exit
.Lfunc_end0:
	.size	range_read, .Lfunc_end0-range_read
                                        # -- End function
	.addrsig
