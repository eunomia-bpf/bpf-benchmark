typedef unsigned long long __u64;
typedef unsigned int __u32;
#define X86_WIDTH_8 1
#define X86_WIDTH_16 2
#define X86_WIDTH_32 4
#define X86_WIDTH_64 8
#define KPROG_X86_APPLY_WIDTH(V,W) ((V)&((W)==1?255ULL:(W)==2?65535ULL:(W)==4?0xffffffffULL:~0ULL))
#include "include/generated/x86_reg_read.h"
__u64 read_low8(__u64 value){return KPROG_X86_READ_REG_AT(value,1,0);}
__u64 read_high8(__u64 value){return KPROG_X86_READ_REG_AT(value,1,8);}
__u64 read_word(__u64 value){return KPROG_X86_READ_REG_AT(value,2,0);}
__u64 read_dword(__u64 value){return KPROG_X86_READ_REG_AT(value,4,0);}
__u64 read_qword(__u64 value){return KPROG_X86_READ_REG_AT(value,8,0);}
int indexed(__u64 original,const __u32 *table){
 __u64 compared=KPROG_X86_READ_REG_AT(original,1,0);
 if(compared>15) return 0;
 return table[KPROG_X86_READ_REG_AT(original,1,0)]+(original>>8);
}
