typedef unsigned long long u64;
typedef unsigned int u32;
static __attribute__((always_inline)) inline u64 low8(u64 value) {
 __asm__("%0 &= 255" : "+r"(value));
 return value;
}
int range_read(u64 original, const u32 *table) {
 u64 compared=low8(original);
 if (compared > 15) return 0;
 return table[low8(original)];
}
