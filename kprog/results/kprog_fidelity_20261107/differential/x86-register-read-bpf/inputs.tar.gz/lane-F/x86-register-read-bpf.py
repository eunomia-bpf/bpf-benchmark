from pathlib import Path
import csv,datetime,gzip,hashlib,json,platform,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf'
B=R/'kprog/fidelity/build-x86-register-read-bpf'
S=F/'x86-register-read-bpf'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 assert platform.machine()=='x86_64'
 S.with_suffix('.state').write_text('compiling_and_comparing_bpf_register_reads\n')
 paths=[p for p in O.rglob('*') if p.is_file()]
 paths += [R/'kprog/formal/generated'/n for n in ['x86_width.h','x86_reg_read.h']]
 old=json.loads((R/'kprog/results/kprog_fidelity_20261107/differential/x86-load-width/launch.json').read_text())
 paths += [R/name for name in old['inputs'] if name.startswith('vendor/llvmbpf/')]
 objects=sorted(R.glob('runner/build-llvmbpf/CMakeFiles/micro_exec.dir/workspaces/repository/vendor/llvmbpf/src/*.o'))
 assert len(objects)==4
 paths+=objects
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 launch=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
   source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
   candidate_publication='b756ee85e5253b7c0997a7446aaac25ed9536b03',
   expected_forms_per_variant=20,expected_cases_per_form=335872,
   source_sha256=pins,cached_vm_objects={str(p.relative_to(R)):sha(p) for p in objects})
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'inputs.tar.gz','w:gz') as archive:
  for p in paths:
   if p not in objects:archive.add(p,arcname=str(p.relative_to(R)),recursive=False)
  archive.add(__file__,arcname='lane-F/x86-register-read-bpf.py')
 with (O/'run.log').open('w') as log:
  rc=subprocess.run(['taskset','-c','16-19','make','-f',str(O/'Makefile'),'check'],cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
 actual=[p for variant in ['before','candidate'] for p in (O/variant).glob('*.o')]
 if (B/'host.o').exists():actual.append(B/'host.o')
 if actual:
  manifest={str(p.relative_to(R)):sha(p) for p in actual}
  (O/'compiled-objects.json').write_text(json.dumps(manifest,indent=2)+'\n')
  with tarfile.open(O/'compiled-objects.tar.gz','w:gz') as archive:
   for p in actual:archive.add(p,arcname=str(p.relative_to(R)),recursive=False)
 if (B/'check').exists():
  (O/'check-x86.gz').write_bytes(gzip.compress((B/'check').read_bytes(),mtime=0))
  (O/'executable-pins.json').write_text(json.dumps(dict(binary_sha256=sha(B/'check')),indent=2)+'\n')
  environment={n:subprocess.run(command,cwd=R,text=True,capture_output=True).stdout for n,command in dict(clang=['/usr/lib/llvm-18/bin/clang','--version'],cc=['cc','--version'],cxx=['g++','--version'],kernel=['uname','-a'],dynamic_libraries=['ldd',str(B/'check')]).items()}
  environment['cpu_model']=next(line for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
  (O/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')
 if (O/'forms.tsv').exists():
  with (O/'forms.tsv').open() as source:rows=list(csv.DictReader(source,delimiter='\t'))
  assert len(rows)==40 and all(int(row['cases'])==335872 for row in rows)
  totals={}
  for variant in ['before','candidate']:
   selected=[row for row in rows if row['variant']==variant]
   totals[variant]={key:sum(int(row[key]) for row in selected) for key in ['cases','guard_taken','jit_vs_bytes','native_vs_bytes','host_vs_bytes','jit_vs_native','memory_writes']}
   totals[variant]['forms']=len(selected)
  (O/'summary.json').write_text(json.dumps(dict(variants=totals,total_cases=sum(int(row['cases']) for row in rows),input_domain=dict(exhaustive_low16=262144,random_full64=65536,guarded_positive=8192),scope='Generic register-read BPF lowering, native read values and guarded readonly indexing.'),indent=2)+'\n')
 if (O/'mismatches.jsonl').exists():
  (O/'mismatches.jsonl.gz').write_bytes(gzip.compress((O/'mismatches.jsonl').read_bytes(),mtime=0))
 drift={name:dict(before=digest,after=sha(R/name)) for name,digest in pins.items() if sha(R/name)!=digest}
 (O/'status.json').write_text(json.dumps(dict(exit=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_drift=drift),indent=2)+'\n')
 S.with_suffix('.exit').write_text(str(rc)+'\n')
 S.with_suffix('.state').write_text('closed_review_pending\n')
except BaseException:
 S.with_suffix('.error').write_text(traceback.format_exc());S.with_suffix('.exit').write_text('1\n');S.with_suffix('.state').write_text('closed_error_retained\n');raise
