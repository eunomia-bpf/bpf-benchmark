# 1 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/reads.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 348 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/reads.c" 2
typedef unsigned long long __u64;
typedef unsigned int __u32;




# 1 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/frame.h" 1


struct Frame { unsigned long long value; unsigned int table[16]; unsigned long long canary[4]; };
# 8 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/reads.c" 2
# 1 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/x86_width.h" 1



_Static_assert(1U == 1U, "x86 width code drift");
_Static_assert(2U == 2U, "x86 width code drift");
_Static_assert(4U == 4U, "x86 width code drift");
_Static_assert(8U == 8U, "x86 width code drift");
# 9 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/reads.c" 2
# 1 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/before/x86_reg_read.h" 1
# 10 "/workspaces/repository/kprog/results/kprog_fidelity_20261107/differential/x86-register-read-bpf/reads.c" 2





__u64 read_0_0(const struct Frame *p) { return (((p->value) >> ((0) == 1U ? (0) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_0_8(const struct Frame *p) { return (((p->value) >> ((0) == 1U ? (8) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_1_0(const struct Frame *p) { return (((p->value) >> ((1) == 1U ? (0) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_1_8(const struct Frame *p) { return (((p->value) >> ((1) == 1U ? (8) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_2_0(const struct Frame *p) { return (((p->value) >> ((2) == 1U ? (0) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_2_8(const struct Frame *p) { return (((p->value) >> ((2) == 1U ? (8) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_4_0(const struct Frame *p) { return (((p->value) >> ((4) == 1U ? (0) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_4_8(const struct Frame *p) { return (((p->value) >> ((4) == 1U ? (8) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_8_0(const struct Frame *p) { return (((p->value) >> ((8) == 1U ? (0) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 read_8_8(const struct Frame *p) { return (((p->value) >> ((8) == 1U ? (8) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }
__u64 guard_0_0(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((0) == 1U ? (0) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((0) == 1U ? (0) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_0_8(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((0) == 1U ? (8) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((0) == 1U ? (8) : 0U)) & (((0)) == 1U ? 0xffULL : (((0)) == 2U ? 0xffffULL : (((0)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_1_0(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((1) == 1U ? (0) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((1) == 1U ? (0) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_1_8(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((1) == 1U ? (8) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((1) == 1U ? (8) : 0U)) & (((1)) == 1U ? 0xffULL : (((1)) == 2U ? 0xffffULL : (((1)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_2_0(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((2) == 1U ? (0) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((2) == 1U ? (0) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_2_8(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((2) == 1U ? (8) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((2) == 1U ? (8) : 0U)) & (((2)) == 1U ? 0xffULL : (((2)) == 2U ? 0xffffULL : (((2)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_4_0(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((4) == 1U ? (0) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((4) == 1U ? (0) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_4_8(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((4) == 1U ? (8) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((4) == 1U ? (8) : 0U)) & (((4)) == 1U ? 0xffULL : (((4)) == 2U ? 0xffffULL : (((4)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_8_0(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((8) == 1U ? (0) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((8) == 1U ? (0) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
__u64 guard_8_8(const struct Frame *p) { __u64 original=p->value, compared=(((original) >> ((8) == 1U ? (8) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); if(compared>15) return 0; return (__u32)(p->table[(((original) >> ((8) == 1U ? (8) : 0U)) & (((8)) == 1U ? 0xffULL : (((8)) == 2U ? 0xffffULL : (((8)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))))]+(original>>8)); }
