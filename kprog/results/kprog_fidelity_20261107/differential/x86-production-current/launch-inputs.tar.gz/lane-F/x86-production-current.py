from pathlib import Path
import datetime,gzip,hashlib,json,subprocess,tarfile,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-production-current'
B=R/'kprog/fidelity/build-x86-production-current';S=F/'x86-production-current'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
try:
 S.with_suffix('.state').write_text('building_and_replaying_production_epoch\n')
 paths=[R/'kprog/fidelity'/name for name in ['generate.py','driver.c','driver.h','Makefile','reference_check.py','tcb.py']]
 paths+=list((R/'kprog/x86').glob('*.h'))+list((R/'kprog/x86/micro-prog').glob('*.py'))+list((R/'kprog/formal/generated').glob('*.h'))
 paths+=[O/'Makefile']
 pins={str(p.relative_to(R)):sha(p) for p in paths}
 assert pins['kprog/formal/generated/x86_reg_write.h']=='cf27e323c885cdf8258974a8800907af2f6ee56093d7721822b9e75360e72994'
 assert pins['kprog/x86/x86_sim_local_bpf.h']=='6b3f31731d9d127a36183e3e35cd6b39335d8b5865649a8282fc503a7be0dc11'
 launch=dict(started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
   source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
   adopted_write_commit='9b0aa2b09c1188ede61fea3c0a9d0d3acbebded1',
   expected_forms=1144,cases_per_form=256,expected_cases=292864,
   source_sha256=pins,reference_sha256=sha(F/'reference-control-frozen'))
 (O/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as archive:
  for p in paths:archive.add(p,arcname=str(p.relative_to(R)),recursive=False)
  archive.add(__file__,arcname='lane-F/x86-production-current.py')
 with (O/'run.log').open('w') as log:
  rc=subprocess.run(['taskset','-c','16-19','make','-f',str(O/'Makefile'),'reference'],cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
 if (B/'coverage.json').exists():
  forms=json.loads((B/'coverage.json').read_text());assert len(forms)==launch['expected_forms']
  (O/'coverage.json').write_text(json.dumps(forms,indent=2)+'\n')
 if (B/'generated.c').exists():
  actual=[p for p in (B/'snapshot').rglob('*') if p.is_file()]
  actual+=[B/name for name in ['generated.c','native.S','instructions.S','instructions.asm','coverage.json']]
  actual+=[R/'kprog/fidelity'/name for name in ['driver.c','driver.h','Makefile']]
  (O/'actual-compiled-inputs.json').write_text(json.dumps({str(p.relative_to(R)):sha(p) for p in actual},indent=2)+'\n')
  with tarfile.open(O/'actual-compiled-inputs.tar.gz','w:gz') as archive:
   for p in actual:archive.add(p,arcname=str(p.relative_to(R)),recursive=False)
 if (B/'cpu-differential').exists():
  (O/'cpu-differential-x86.gz').write_bytes(gzip.compress((B/'cpu-differential').read_bytes(),mtime=0))
  (O/'executable-pins.json').write_text(json.dumps(dict(binary_sha256=sha(B/'cpu-differential'),reference_sha256=sha(F/'reference-control-frozen')),indent=2)+'\n')
 drift={name:dict(before=digest,after=sha(R/name)) for name,digest in pins.items() if sha(R/name)!=digest}
 (O/'status.json').write_text(json.dumps(dict(exit=rc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_drift=drift),indent=2)+'\n')
 trace=O/'cpu-states.bin'
 if trace.exists():
  raw_sha=sha(trace);raw_bytes=trace.stat().st_size
  packed=trace.with_suffix('.bin.zst')
  subprocess.run(['zstd','-3','-T1','--keep','--force','--quiet',str(trace),'-o',str(packed)],check=True)
  digest=hashlib.sha256();process=subprocess.Popen(['zstd','-dcq',str(packed)],stdout=subprocess.PIPE)
  while chunk:=process.stdout.read(1024*1024):digest.update(chunk)
  assert process.wait()==0 and digest.hexdigest()==raw_sha
  (O/'trace-storage.json').write_text(json.dumps(dict(raw_bytes=raw_bytes,raw_sha256=raw_sha,compressed_bytes=packed.stat().st_size,compressed_sha256=sha(packed),path=packed.name,decompressed_identity_equal=True),indent=2)+'\n')
  trace.unlink()
 S.with_suffix('.exit').write_text(str(rc)+'\n');S.with_suffix('.state').write_text('closed_review_pending\n')
except BaseException:
 S.with_suffix('.error').write_text(traceback.format_exc());S.with_suffix('.exit').write_text('1\n');S.with_suffix('.state').write_text('closed_error_retained\n');raise
