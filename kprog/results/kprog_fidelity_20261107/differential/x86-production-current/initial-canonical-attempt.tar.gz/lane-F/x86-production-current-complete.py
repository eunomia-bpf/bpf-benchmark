from pathlib import Path
import datetime,gzip,hashlib,json,os,select,subprocess,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F')
O=R/'kprog/results/kprog_fidelity_20261107/differential/x86-production-current'
CONTROL=F/'x86-production-current-complete'
P=F/'x86-production-current'
def sha(data):return hashlib.sha256(data).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args,**kwargs):return subprocess.check_output(['git',*args],cwd=R,**kwargs)
def state(value):CONTROL.with_suffix('.state').write_text(value+'\n')
try:
    state('waiting_for_original_replay')
    if not P.with_suffix('.exit').exists():
        pid=int(P.with_suffix('.pid').read_text())
        try:
            fd=os.pidfd_open(pid)
        except ProcessLookupError:
            assert P.with_suffix('.exit').exists()
        else:
            try:
                cmd=Path(f'/proc/{pid}/cmdline').read_bytes()
                assert str(P.with_suffix('.py')).encode() in cmd
                poll=select.poll();poll.register(fd,select.POLLIN);poll.poll()
            finally:os.close(fd)
    assert P.with_suffix('.state').read_text().strip()=='closed_review_pending'
    state('reviewing_complete_trace_and_sources')
    review_started=now()
    with (O/'review.log').open('w') as log:
        reviewed=subprocess.run(['python3',str(O/'review.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT).returncode
    review_bytes=(O/'review.log').read_bytes()
    (O/'review.log.gz').write_bytes(gzip.compress(review_bytes,mtime=0))
    assert reviewed==0
    summary=json.loads((O/'summary.json').read_text())
    assert summary['exit']==0 and summary['forms']==1144 and summary['cases']==292864
    assert summary['forms_awaiting_reference']==0 and all(v==0 for v in summary['differences'].values())
    assert summary['reference_sha256']=='c110b03a98238272fe72124a4c92e0095b8c759a750891e37ad31f8b81084d96'
    reference_archive=R/'kprog/results/kprog_fidelity_20261107/differential/x86-current-matrix/canonical-reference.gz'
    assert sha(gzip.decompress(reference_archive.read_bytes()))==summary['reference_sha256']
    logs=['run.log','mismatches.jsonl','reference-mismatches.jsonl','reference-unavailable.jsonl']
    for name in logs:
        raw=(O/name).read_bytes();(O/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0))
        assert gzip.decompress((O/(name+'.gz')).read_bytes())==raw
    collected=dict(exit=reviewed,started=review_started,finished=now(),
        reviewer_sha256=sha((O/'review.py').read_bytes()),review_log_sha256=sha(review_bytes),
        canonical_published_archive=str(reference_archive.relative_to(R)),
        canonical_published_uncompressed_sha256=summary['reference_sha256'],
        closure_source_sha256=sha(Path(__file__).read_bytes()))
    (O/'collection-status.json').write_text(json.dumps(collected,indent=2)+'\n')
    storage=json.loads((O/'trace-storage.json').read_text())
    source=summary['source_head'];binary=summary['binary_sha256']
    drift=json.dumps(summary['source_drift'],indent=2)
    readme=f"""# Production x86 CPU, simulator and canonical replay

The existing default matrix completes **1144 forms ×256 states =292,864 cases**
on the real x86-64 host CPU. Every form has256 CPU/C and256 canonical cases.
CPU/C, CPU/canonical and C/canonical comparisons each report **0 differences**.
All1144 forms receive canonical replay; the reference-pending count is0.
The job exits0 at {summary['finished']}.

This epoch captures production source {source}, following C's tagged-register-write
adoption9b0aa2b09c1188ede61fea3c0a9d0d3acbebded1. The compiled simulator header is
{summary['simulator_header_sha256']}; its register-write header is
{summary['register_write_sha256']}. Each of the
{summary['production_snapshot_files']} copied production sources matches that
launch Git commit exactly. All{summary['compiled_input_files']} captured inputs
match their archive hashes; derived source caches have their own literal pins.

forms.tsv preserves each real CPU/C count. reference-forms.tsv preserves each
canonical count, and observations.tsv joins them with the exact assembly/opcode
and changed-memory count. coverage.json records the generated form inventory.
The complete compressed diagnostic streams preserve each difference input.
Their zero-length decompressed streams agree with the observed totals.

## Observation domain

The original generator, native wrappers, driver and flag masks supply this run.
Each form receives128 boundary-seeded states and128 randomized states, with
random register/flag/vector/stack/memory initialization and the driver's original
operand-domain setup. The stored architectural comparison covers32 scalar cells
(including16 architectural GPRs), the six arithmetic flags under the original
definedness masks, XMM0,64 private-stack bytes and256 memory-window bytes.
Stack forms retain their original relative-RSP setup and hardware projection.
Existing branch, CALL/RET and REP composites retain their actual wrapper paths.

The256-byte memory window changes in
{summary['native_memory_write_cases']} native cases. Every resulting byte is
compared with its simulator value; private-stack bytes receive their independent
full comparison. The stream reader recomputes CPU/C differences with the same
dynamic shift/rotate masks as the original driver, reconciles every row and
checks the entire trace length and SHA256.

These sampled instruction and composite executions support the current
enumerated domains. The universal simulator/token/native-link, helper, private
arena, ABI, definedness and compiler correspondence interfaces remain with V/T.
The global numeric-token coverage ledger maintains its own token domains.

## Captured execution and state

The captured executable SHA256 is {binary}.
The sole canonical executable is the frozen published c110 reference:
{summary['reference_sha256']}.
Its bytes match ../x86-current-matrix/canonical-reference.gz.

actual-compiled-inputs.tar.gz preserves generated C, native assembly, instruction
assembly/disassembly, driver/build inputs and the actual source snapshot.
launch-inputs.tar.gz preserves the initial source vector and detached job script.
The reviewer reads generated descriptors from the compiled archive, including the
eleven signed POP setup descriptors, and retains all1144 rows independently of
the warm build directory's lifetime.

The complete Workspace state stream is cpu-states.bin.zst:
{storage['compressed_bytes']} compressed bytes, SHA256
{storage['compressed_sha256']}. Its decompressed identity is
{storage['raw_bytes']} bytes, SHA256 {storage['raw_sha256']}.
The compressed stream stays with this Workspace's raw results. The published
tables, sources, executable and full diagnostic streams retain reproducible
observation identities. The trace archive supports every recorded input and
successor. Warm incremental build objects remain in the owning F cache.

## Commands

Run from /workspaces/repository through bws.sh against the captured source epoch:

~~~sh
taskset -c 16-19 make -f kprog/results/kprog_fidelity_20261107/differential/x86-production-current/Makefile reference
taskset -c 16-19 python3 kprog/results/kprog_fidelity_20261107/differential/x86-production-current/review.py
~~~

The Make target uses the existing build-x86-production-current cache and frozen
reference-control-frozen executable. For archived observation review, restore the
full compressed trace beside the published metadata and run review.py.
The actual source and binary remain fixed while other owners advance the root
checkout. status.json records the exact later source differences:

~~~json
{drift}
~~~
"""
    (O/'README.md').write_text(readme)
    names=['Makefile','review.py','launch.json','launch-inputs.tar.gz','run.log.gz',
      'coverage.json','actual-compiled-inputs.json','actual-compiled-inputs.tar.gz',
      'cpu-differential-x86.gz','executable-pins.json','status.json','trace-storage.json',
      'forms.tsv','host.txt','native-code.json','reference-forms.tsv','mismatches.jsonl.gz',
      'reference-mismatches.jsonl.gz','reference-unavailable.jsonl.gz','observations.tsv',
      'summary.json','README.md','review.log.gz','collection-status.json']
    paths=[str((O/name).relative_to(R)) for name in names]
    expected={path:sha((R/path).read_bytes()) for path in paths}
    assert git('branch','--show-current').decode().strip()=='master'
    shared=R/git('rev-parse','--git-path','index').decode().strip()
    before=sha(shared.read_bytes())
    index=F/'x86-production-current-complete.index'
    assert not index.exists()
    env=dict(os.environ,GIT_INDEX_FILE=str(index))
    state('publishing_reviewed_epoch')
    while True:
        parent=git('rev-parse','HEAD').decode().strip()
        subprocess.run(['git','read-tree',parent],cwd=R,env=env,check=True)
        subprocess.run(['git','add','-f','--',*paths],cwd=R,env=env,check=True)
        changed=git('diff','--cached','--name-only',parent,env=env).decode().splitlines()
        assert set(changed)==set(paths)
        subprocess.run(['git','diff','--cached','--check',parent],cwd=R,env=env,check=True)
        for path,digest in expected.items():assert sha(git('show',':'+path,env=env))==digest
        tree=git('write-tree',env=env).decode().strip()
        commit=git('commit-tree',tree,'-p',parent,env=env,
          input=b'Record production x86 CPU and canonical instruction replay\n').decode().strip()
        updated=subprocess.run(['git','update-ref','HEAD',commit,parent],cwd=R,capture_output=True,text=True)
        if updated.returncode==0:break
        print('CAS retry',updated.stderr,flush=True)
    receipt=dict(commit=commit,parent=parent,tree=tree,paths=expected,
        shared_index_before=before,shared_index_after=sha(shared.read_bytes()))
    CONTROL.with_suffix('.publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
    pushed=subprocess.run(['git','push','origin','master'],cwd=R,capture_output=True,text=True)
    print(pushed.stdout,pushed.stderr,flush=True)
    receipt['push_exit']=pushed.returncode
    CONTROL.with_suffix('.publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert pushed.returncode==0
    remote=git('ls-remote','origin','refs/heads/master').decode().split()[0]
    subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True)
    for path,digest in expected.items():
        assert sha(git('show',commit+':'+path))==digest
        assert (R/path).read_bytes()==git('show','HEAD:'+path)
    receipt.update(remote_head=remote,remote_contains_commit=True,physical_head_equal=True,
        shared_index_equal=receipt['shared_index_before']==receipt['shared_index_after'])
    CONTROL.with_suffix('.publication.json').write_text(json.dumps(receipt,indent=2)+'\n')
    index.unlink()
    notice=f"- LOCAL F {now()}: PUSHED {commit} exact24own production-x86 result paths/privateindex/CAS/remoteancestor+physicalHEAD/shared-index fingerprint recorded. Captured source{source},main6b3f/regwritecf27,1144forms*256=292864realCPU/C/c110canonical cases,all3differences0/referencepending0; {summary['production_snapshot_files']}production snapshot Git equal/{summary['compiled_input_files']}actualinputs archived. Executable{binary}; complete state stream{storage['raw_bytes']}B SHA{storage['raw_sha256']} compressedlosslessly/source+allper-form counts retained. Originaldriver/generator/masks/nativewrappers preserved; signedPOP setup metadata included. Laterrootdrift explicit. V: completed productionepoch ready forF replay-ledger addition in next turn; globaltoken domains remain separate. Existing owners/caches/runtime images retained.\n"
    with Path('/workspaces/.agent-state/kprog-lanes/COORDINATION.md').open('a') as stream:stream.write('\n'+notice)
    with (F/'last.md').open('a') as stream:
        stream.write('\n## Production replay completion\n\n'+notice+
          '\nNext turn inspect x86-production-current-complete.publication.json and full summary, then add this standard production epoch to differential/replay-inputs while preserving prior rows/pins and numeric totals. Capture actual current priorities first.\n')
    for name in logs+['review.log']:
        assert gzip.decompress((O/(name+'.gz')).read_bytes())==(O/name).read_bytes()
        (O/name).unlink()
    CONTROL.with_suffix('.exit').write_text('0\n');state('published_complete')
    print(json.dumps(receipt,indent=2),flush=True)
except BaseException:
    CONTROL.with_suffix('.error').write_text(traceback.format_exc())
    CONTROL.with_suffix('.exit').write_text('1\n');state('completion_error_retained')
    raise
