
/workspaces/repository/kprog/fidelity/build-x86-partial-gpr-candidate/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	88 d8                                           	mov    al,bl
   2:	88 dc                                           	mov    ah,bl
   4:	88 e0                                           	mov    al,ah
   6:	88 c4                                           	mov    ah,al
   8:	66 89 d8                                        	mov    ax,bx
   b:	45 88 c8                                        	mov    r8b,r9b
   e:	66 45 89 c8                                     	mov    r8w,r9w
  12:	40 88 f7                                        	mov    dil,sil
  15:	40 88 d5                                        	mov    bpl,dl
  18:	40 88 c4                                        	mov    spl,al
  1b:	66 89 c4                                        	mov    sp,ax
  1e:	89 d8                                           	mov    eax,ebx
  20:	48 89 d8                                        	mov    rax,rbx
  23:	b0 7f                                           	mov    al,0x7f
  25:	b4 7f                                           	mov    ah,0x7f
  27:	66 b8 ff 7f                                     	mov    ax,0x7fff
