
/workspaces/repository/kprog/fidelity/build-arm64-memory-complete/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	b9401080 	ldr	w0, [x4, #16]
   4:	b85f0c80 	ldr	w0, [x4, #-16]!
   8:	b85f0480 	ldr	w0, [x4], #-16
   c:	b8410c80 	ldr	w0, [x4, #16]!
  10:	b8410480 	ldr	w0, [x4], #16
  14:	b8656880 	ldr	w0, [x4, x5]
  18:	b8657880 	ldr	w0, [x4, x5, lsl #2]
  1c:	b8654880 	ldr	w0, [x4, w5, uxtw]
  20:	b8655880 	ldr	w0, [x4, w5, uxtw #2]
  24:	b865c880 	ldr	w0, [x4, w5, sxtw]
  28:	b865d880 	ldr	w0, [x4, w5, sxtw #2]
  2c:	b865e880 	ldr	w0, [x4, x5, sxtx]
  30:	b865f880 	ldr	w0, [x4, x5, sxtx #2]
  34:	f9400880 	ldr	x0, [x4, #16]
  38:	f85f0c80 	ldr	x0, [x4, #-16]!
  3c:	f85f0480 	ldr	x0, [x4], #-16
  40:	f8410c80 	ldr	x0, [x4, #16]!
  44:	f8410480 	ldr	x0, [x4], #16
  48:	f8656880 	ldr	x0, [x4, x5]
  4c:	f8657880 	ldr	x0, [x4, x5, lsl #3]
  50:	f8654880 	ldr	x0, [x4, w5, uxtw]
  54:	f8655880 	ldr	x0, [x4, w5, uxtw #3]
  58:	f865c880 	ldr	x0, [x4, w5, sxtw]
  5c:	f865d880 	ldr	x0, [x4, w5, sxtw #3]
  60:	f865e880 	ldr	x0, [x4, x5, sxtx]
  64:	f865f880 	ldr	x0, [x4, x5, sxtx #3]
  68:	b9001080 	str	w0, [x4, #16]
  6c:	b81f0c80 	str	w0, [x4, #-16]!
  70:	b81f0480 	str	w0, [x4], #-16
  74:	b8010c80 	str	w0, [x4, #16]!
  78:	b8010480 	str	w0, [x4], #16
  7c:	b8256880 	str	w0, [x4, x5]
  80:	b8257880 	str	w0, [x4, x5, lsl #2]
  84:	b8254880 	str	w0, [x4, w5, uxtw]
  88:	b8255880 	str	w0, [x4, w5, uxtw #2]
  8c:	b825c880 	str	w0, [x4, w5, sxtw]
  90:	b825d880 	str	w0, [x4, w5, sxtw #2]
  94:	b825e880 	str	w0, [x4, x5, sxtx]
  98:	b825f880 	str	w0, [x4, x5, sxtx #2]
  9c:	f9000880 	str	x0, [x4, #16]
  a0:	f81f0c80 	str	x0, [x4, #-16]!
  a4:	f81f0480 	str	x0, [x4], #-16
  a8:	f8010c80 	str	x0, [x4, #16]!
  ac:	f8010480 	str	x0, [x4], #16
  b0:	f8256880 	str	x0, [x4, x5]
  b4:	f8257880 	str	x0, [x4, x5, lsl #3]
  b8:	f8254880 	str	x0, [x4, w5, uxtw]
  bc:	f8255880 	str	x0, [x4, w5, uxtw #3]
  c0:	f825c880 	str	x0, [x4, w5, sxtw]
  c4:	f825d880 	str	x0, [x4, w5, sxtw #3]
  c8:	f825e880 	str	x0, [x4, x5, sxtx]
  cc:	f825f880 	str	x0, [x4, x5, sxtx #3]
  d0:	39404080 	ldrb	w0, [x4, #16]
  d4:	385f0c80 	ldrb	w0, [x4, #-16]!
  d8:	385f0480 	ldrb	w0, [x4], #-16
  dc:	38410c80 	ldrb	w0, [x4, #16]!
  e0:	38410480 	ldrb	w0, [x4], #16
  e4:	38657880 	ldrb	w0, [x4, x5, lsl #0]
  e8:	38655880 	ldrb	w0, [x4, w5, uxtw #0]
  ec:	3865d880 	ldrb	w0, [x4, w5, sxtw #0]
  f0:	3865f880 	ldrb	w0, [x4, x5, sxtx #0]
  f4:	79402080 	ldrh	w0, [x4, #16]
  f8:	785f0c80 	ldrh	w0, [x4, #-16]!
  fc:	785f0480 	ldrh	w0, [x4], #-16
 100:	78410c80 	ldrh	w0, [x4, #16]!
 104:	78410480 	ldrh	w0, [x4], #16
 108:	78656880 	ldrh	w0, [x4, x5]
 10c:	78657880 	ldrh	w0, [x4, x5, lsl #1]
 110:	78654880 	ldrh	w0, [x4, w5, uxtw]
 114:	78655880 	ldrh	w0, [x4, w5, uxtw #1]
 118:	7865c880 	ldrh	w0, [x4, w5, sxtw]
 11c:	7865d880 	ldrh	w0, [x4, w5, sxtw #1]
 120:	7865e880 	ldrh	w0, [x4, x5, sxtx]
 124:	7865f880 	ldrh	w0, [x4, x5, sxtx #1]
 128:	39004080 	strb	w0, [x4, #16]
 12c:	381f0c80 	strb	w0, [x4, #-16]!
 130:	381f0480 	strb	w0, [x4], #-16
 134:	38010c80 	strb	w0, [x4, #16]!
 138:	38010480 	strb	w0, [x4], #16
 13c:	38257880 	strb	w0, [x4, x5, lsl #0]
 140:	38255880 	strb	w0, [x4, w5, uxtw #0]
 144:	3825d880 	strb	w0, [x4, w5, sxtw #0]
 148:	3825f880 	strb	w0, [x4, x5, sxtx #0]
 14c:	79002080 	strh	w0, [x4, #16]
 150:	781f0c80 	strh	w0, [x4, #-16]!
 154:	781f0480 	strh	w0, [x4], #-16
 158:	78010c80 	strh	w0, [x4, #16]!
 15c:	78010480 	strh	w0, [x4], #16
 160:	78256880 	strh	w0, [x4, x5]
 164:	78257880 	strh	w0, [x4, x5, lsl #1]
 168:	78254880 	strh	w0, [x4, w5, uxtw]
 16c:	78255880 	strh	w0, [x4, w5, uxtw #1]
 170:	7825c880 	strh	w0, [x4, w5, sxtw]
 174:	7825d880 	strh	w0, [x4, w5, sxtw #1]
 178:	7825e880 	strh	w0, [x4, x5, sxtx]
 17c:	7825f880 	strh	w0, [x4, x5, sxtx #1]
 180:	39c04080 	ldrsb	w0, [x4, #16]
 184:	38df0c80 	ldrsb	w0, [x4, #-16]!
 188:	38df0480 	ldrsb	w0, [x4], #-16
 18c:	38c10c80 	ldrsb	w0, [x4, #16]!
 190:	38c10480 	ldrsb	w0, [x4], #16
 194:	38e57880 	ldrsb	w0, [x4, x5, lsl #0]
 198:	38e55880 	ldrsb	w0, [x4, w5, uxtw #0]
 19c:	38e5d880 	ldrsb	w0, [x4, w5, sxtw #0]
 1a0:	38e5f880 	ldrsb	w0, [x4, x5, sxtx #0]
 1a4:	39804080 	ldrsb	x0, [x4, #16]
 1a8:	389f0c80 	ldrsb	x0, [x4, #-16]!
 1ac:	389f0480 	ldrsb	x0, [x4], #-16
 1b0:	38810c80 	ldrsb	x0, [x4, #16]!
 1b4:	38810480 	ldrsb	x0, [x4], #16
 1b8:	38a57880 	ldrsb	x0, [x4, x5, lsl #0]
 1bc:	38a55880 	ldrsb	x0, [x4, w5, uxtw #0]
 1c0:	38a5d880 	ldrsb	x0, [x4, w5, sxtw #0]
 1c4:	38a5f880 	ldrsb	x0, [x4, x5, sxtx #0]
 1c8:	79c02080 	ldrsh	w0, [x4, #16]
 1cc:	78df0c80 	ldrsh	w0, [x4, #-16]!
 1d0:	78df0480 	ldrsh	w0, [x4], #-16
 1d4:	78c10c80 	ldrsh	w0, [x4, #16]!
 1d8:	78c10480 	ldrsh	w0, [x4], #16
 1dc:	78e56880 	ldrsh	w0, [x4, x5]
 1e0:	78e57880 	ldrsh	w0, [x4, x5, lsl #1]
 1e4:	78e54880 	ldrsh	w0, [x4, w5, uxtw]
 1e8:	78e55880 	ldrsh	w0, [x4, w5, uxtw #1]
 1ec:	78e5c880 	ldrsh	w0, [x4, w5, sxtw]
 1f0:	78e5d880 	ldrsh	w0, [x4, w5, sxtw #1]
 1f4:	78e5e880 	ldrsh	w0, [x4, x5, sxtx]
 1f8:	78e5f880 	ldrsh	w0, [x4, x5, sxtx #1]
 1fc:	79802080 	ldrsh	x0, [x4, #16]
 200:	789f0c80 	ldrsh	x0, [x4, #-16]!
 204:	789f0480 	ldrsh	x0, [x4], #-16
 208:	78810c80 	ldrsh	x0, [x4, #16]!
 20c:	78810480 	ldrsh	x0, [x4], #16
 210:	78a56880 	ldrsh	x0, [x4, x5]
 214:	78a57880 	ldrsh	x0, [x4, x5, lsl #1]
 218:	78a54880 	ldrsh	x0, [x4, w5, uxtw]
 21c:	78a55880 	ldrsh	x0, [x4, w5, uxtw #1]
 220:	78a5c880 	ldrsh	x0, [x4, w5, sxtw]
 224:	78a5d880 	ldrsh	x0, [x4, w5, sxtw #1]
 228:	78a5e880 	ldrsh	x0, [x4, x5, sxtx]
 22c:	78a5f880 	ldrsh	x0, [x4, x5, sxtx #1]
 230:	b9801080 	ldrsw	x0, [x4, #16]
 234:	b89f0c80 	ldrsw	x0, [x4, #-16]!
 238:	b89f0480 	ldrsw	x0, [x4], #-16
 23c:	b8810c80 	ldrsw	x0, [x4, #16]!
 240:	b8810480 	ldrsw	x0, [x4], #16
 244:	b8a56880 	ldrsw	x0, [x4, x5]
 248:	b8a57880 	ldrsw	x0, [x4, x5, lsl #2]
 24c:	b8a54880 	ldrsw	x0, [x4, w5, uxtw]
 250:	b8a55880 	ldrsw	x0, [x4, w5, uxtw #2]
 254:	b8a5c880 	ldrsw	x0, [x4, w5, sxtw]
 258:	b8a5d880 	ldrsw	x0, [x4, w5, sxtw #2]
 25c:	b8a5e880 	ldrsw	x0, [x4, x5, sxtx]
 260:	b8a5f880 	ldrsw	x0, [x4, x5, sxtx #2]
 264:	fd400880 	ldr	d0, [x4, #16]
 268:	fc5f0c80 	ldr	d0, [x4, #-16]!
 26c:	fc5f0480 	ldr	d0, [x4], #-16
 270:	fc410c80 	ldr	d0, [x4, #16]!
 274:	fc410480 	ldr	d0, [x4], #16
 278:	fc656880 	ldr	d0, [x4, x5]
 27c:	fc657880 	ldr	d0, [x4, x5, lsl #3]
 280:	fc654880 	ldr	d0, [x4, w5, uxtw]
 284:	fc655880 	ldr	d0, [x4, w5, uxtw #3]
 288:	fc65c880 	ldr	d0, [x4, w5, sxtw]
 28c:	fc65d880 	ldr	d0, [x4, w5, sxtw #3]
 290:	fc65e880 	ldr	d0, [x4, x5, sxtx]
 294:	fc65f880 	ldr	d0, [x4, x5, sxtx #3]
 298:	3dc00480 	ldr	q0, [x4, #16]
 29c:	3cdf0c80 	ldr	q0, [x4, #-16]!
 2a0:	3cdf0480 	ldr	q0, [x4], #-16
 2a4:	3cc10c80 	ldr	q0, [x4, #16]!
 2a8:	3cc10480 	ldr	q0, [x4], #16
 2ac:	3ce56880 	ldr	q0, [x4, x5]
 2b0:	3ce57880 	ldr	q0, [x4, x5, lsl #4]
 2b4:	3ce54880 	ldr	q0, [x4, w5, uxtw]
 2b8:	3ce55880 	ldr	q0, [x4, w5, uxtw #4]
 2bc:	3ce5c880 	ldr	q0, [x4, w5, sxtw]
 2c0:	3ce5d880 	ldr	q0, [x4, w5, sxtw #4]
 2c4:	3ce5e880 	ldr	q0, [x4, x5, sxtx]
 2c8:	3ce5f880 	ldr	q0, [x4, x5, sxtx #4]
 2cc:	fd000880 	str	d0, [x4, #16]
 2d0:	fc1f0c80 	str	d0, [x4, #-16]!
 2d4:	fc1f0480 	str	d0, [x4], #-16
 2d8:	fc010c80 	str	d0, [x4, #16]!
 2dc:	fc010480 	str	d0, [x4], #16
 2e0:	fc256880 	str	d0, [x4, x5]
 2e4:	fc257880 	str	d0, [x4, x5, lsl #3]
 2e8:	fc254880 	str	d0, [x4, w5, uxtw]
 2ec:	fc255880 	str	d0, [x4, w5, uxtw #3]
 2f0:	fc25c880 	str	d0, [x4, w5, sxtw]
 2f4:	fc25d880 	str	d0, [x4, w5, sxtw #3]
 2f8:	fc25e880 	str	d0, [x4, x5, sxtx]
 2fc:	fc25f880 	str	d0, [x4, x5, sxtx #3]
 300:	3d800480 	str	q0, [x4, #16]
 304:	3c9f0c80 	str	q0, [x4, #-16]!
 308:	3c9f0480 	str	q0, [x4], #-16
 30c:	3c810c80 	str	q0, [x4, #16]!
 310:	3c810480 	str	q0, [x4], #16
 314:	3ca56880 	str	q0, [x4, x5]
 318:	3ca57880 	str	q0, [x4, x5, lsl #4]
 31c:	3ca54880 	str	q0, [x4, w5, uxtw]
 320:	3ca55880 	str	q0, [x4, w5, uxtw #4]
 324:	3ca5c880 	str	q0, [x4, w5, sxtw]
 328:	3ca5d880 	str	q0, [x4, w5, sxtw #4]
 32c:	3ca5e880 	str	q0, [x4, x5, sxtx]
 330:	3ca5f880 	str	q0, [x4, x5, sxtx #4]
 334:	b85f8080 	ldur	w0, [x4, #-8]
 338:	b8408080 	ldur	w0, [x4, #8]
 33c:	f85f8080 	ldur	x0, [x4, #-8]
 340:	f8408080 	ldur	x0, [x4, #8]
 344:	b81f8080 	stur	w0, [x4, #-8]
 348:	b8008080 	stur	w0, [x4, #8]
 34c:	f81f8080 	stur	x0, [x4, #-8]
 350:	f8008080 	stur	x0, [x4, #8]
 354:	385f8080 	ldurb	w0, [x4, #-8]
 358:	38408080 	ldurb	w0, [x4, #8]
 35c:	785f8080 	ldurh	w0, [x4, #-8]
 360:	78408080 	ldurh	w0, [x4, #8]
 364:	381f8080 	sturb	w0, [x4, #-8]
 368:	38008080 	sturb	w0, [x4, #8]
 36c:	781f8080 	sturh	w0, [x4, #-8]
 370:	78008080 	sturh	w0, [x4, #8]
 374:	b8656884 	ldr	w4, [x4, x5]
 378:	b8256884 	str	w4, [x4, x5]
 37c:	f8656884 	ldr	x4, [x4, x5]
 380:	f8256884 	str	x4, [x4, x5]
 384:	b8656885 	ldr	w5, [x4, x5]
 388:	b8256885 	str	w5, [x4, x5]
 38c:	f8656885 	ldr	x5, [x4, x5]
 390:	f8256885 	str	x5, [x4, x5]
 394:	b865689f 	ldr	wzr, [x4, x5]
 398:	b825689f 	str	wzr, [x4, x5]
 39c:	f865689f 	ldr	xzr, [x4, x5]
 3a0:	f825689f 	str	xzr, [x4, x5]
 3a4:	f87f6880 	ldr	x0, [x4, xzr]
 3a8:	f83f6880 	str	x0, [x4, xzr]
 3ac:	29420480 	ldp	w0, w1, [x4, #16]
 3b0:	29fe0480 	ldp	w0, w1, [x4, #-16]!
 3b4:	28fe0480 	ldp	w0, w1, [x4], #-16
 3b8:	29c20480 	ldp	w0, w1, [x4, #16]!
 3bc:	28c20480 	ldp	w0, w1, [x4], #16
 3c0:	29020480 	stp	w0, w1, [x4, #16]
 3c4:	29be0480 	stp	w0, w1, [x4, #-16]!
 3c8:	28be0480 	stp	w0, w1, [x4], #-16
 3cc:	29820480 	stp	w0, w1, [x4, #16]!
 3d0:	28820480 	stp	w0, w1, [x4], #16
 3d4:	a9410480 	ldp	x0, x1, [x4, #16]
 3d8:	a9ff0480 	ldp	x0, x1, [x4, #-16]!
 3dc:	a8ff0480 	ldp	x0, x1, [x4], #-16
 3e0:	a9c10480 	ldp	x0, x1, [x4, #16]!
 3e4:	a8c10480 	ldp	x0, x1, [x4], #16
 3e8:	a9010480 	stp	x0, x1, [x4, #16]
 3ec:	a9bf0480 	stp	x0, x1, [x4, #-16]!
 3f0:	a8bf0480 	stp	x0, x1, [x4], #-16
 3f4:	a9810480 	stp	x0, x1, [x4, #16]!
 3f8:	a8810480 	stp	x0, x1, [x4], #16
