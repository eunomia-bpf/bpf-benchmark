
/workspaces/repository/kprog/fidelity/build-x86-control/native.o:     file format elf64-x86-64


Disassembly of section .kprog_native:

0000000001000000 <native_0>:
 1000000:	53                                              	push   rbx
 1000001:	55                                              	push   rbp
 1000002:	41 54                                           	push   r12
 1000004:	41 55                                           	push   r13
 1000006:	41 56                                           	push   r14
 1000008:	41 57                                           	push   r15
 100000a:	57                                              	push   rdi
 100000b:	49 89 ff                                        	mov    r15,rdi
 100000e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1000017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100001d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1000026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100002c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1000035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100003b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1000044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100004a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1000051:	9d                                              	popf
 1000052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1000058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1000061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1000064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1000068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100006c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1000070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1000074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1000078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100007c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1000080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1000084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1000088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100008c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1000090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1000094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1000098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100009c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10000a3 <native_pc_0>

00000000010000a3 <native_pc_0>:
 10000a3:	48 8d 05 04 00 00 00                            	lea    rax,[rip+0x4]        # 10000ae <native_pc_0+0xb>
 10000aa:	ff d0                                           	call   rax
 10000ac:	eb 04                                           	jmp    10000b2 <outer_done_0>
 10000ae:	48 01 da                                        	add    rdx,rbx
 10000b1:	c3                                              	ret

00000000010000b2 <outer_done_0>:
 10000b2:	eb 00                                           	jmp    10000b4 <native_next_0>

00000000010000b4 <native_next_0>:
 10000b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10000b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10000c0 <native_next_0+0xc>
 10000c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10000c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10000cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10000d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10000d8:	41 57                                           	push   r15
 10000da:	9c                                              	pushf
 10000db:	50                                              	push   rax
 10000dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10000e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10000e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10000f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10000f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1000101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1000105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1000109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100010d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1000111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1000115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1000119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100011d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1000121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1000125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1000129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100012d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1000131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1000135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100013a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1000141 <native_next_0+0x8d>
 1000141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1000145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1000149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100014c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1000151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1000158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100015d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1000161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1000169:	48 83 c4 18                                     	add    rsp,0x18
 100016d:	5f                                              	pop    rdi
 100016e:	41 5f                                           	pop    r15
 1000170:	41 5e                                           	pop    r14
 1000172:	41 5d                                           	pop    r13
 1000174:	41 5c                                           	pop    r12
 1000176:	5d                                              	pop    rbp
 1000177:	5b                                              	pop    rbx
 1000178:	c3                                              	ret
	...

0000000001001000 <native_1>:
 1001000:	53                                              	push   rbx
 1001001:	55                                              	push   rbp
 1001002:	41 54                                           	push   r12
 1001004:	41 55                                           	push   r13
 1001006:	41 56                                           	push   r14
 1001008:	41 57                                           	push   r15
 100100a:	57                                              	push   rdi
 100100b:	49 89 ff                                        	mov    r15,rdi
 100100e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1001017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100101d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1001026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100102c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1001035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100103b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1001044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100104a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1001051:	9d                                              	popf
 1001052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1001058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1001061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1001064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1001068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100106c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1001070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1001074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1001078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100107c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1001080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1001084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1001088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100108c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1001090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1001094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1001098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100109c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10010a3 <native_pc_1>

00000000010010a3 <native_pc_1>:
 10010a3:	48 8d 05 02 00 00 00                            	lea    rax,[rip+0x2]        # 10010ac <native_pc_1+0x9>
 10010aa:	ff e0                                           	jmp    rax
 10010ac:	48 01 da                                        	add    rdx,rbx
 10010af:	eb 00                                           	jmp    10010b1 <outer_done_1>

00000000010010b1 <outer_done_1>:
 10010b1:	eb 00                                           	jmp    10010b3 <native_next_1>

00000000010010b3 <native_next_1>:
 10010b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10010b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10010bf <native_next_1+0xc>
 10010bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10010c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10010cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10010d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10010d7:	41 57                                           	push   r15
 10010d9:	9c                                              	pushf
 10010da:	50                                              	push   rax
 10010db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10010e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10010e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10010f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10010f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1001100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1001104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1001108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100110c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1001110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1001114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1001118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100111c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1001120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1001124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1001128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100112c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1001130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1001134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1001139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1001140 <native_next_1+0x8d>
 1001140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1001144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1001148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100114b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1001150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1001157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100115c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1001160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1001168:	48 83 c4 18                                     	add    rsp,0x18
 100116c:	5f                                              	pop    rdi
 100116d:	41 5f                                           	pop    r15
 100116f:	41 5e                                           	pop    r14
 1001171:	41 5d                                           	pop    r13
 1001173:	41 5c                                           	pop    r12
 1001175:	5d                                              	pop    rbp
 1001176:	5b                                              	pop    rbx
 1001177:	c3                                              	ret
	...

0000000001002000 <native_2>:
 1002000:	53                                              	push   rbx
 1002001:	55                                              	push   rbp
 1002002:	41 54                                           	push   r12
 1002004:	41 55                                           	push   r13
 1002006:	41 56                                           	push   r14
 1002008:	41 57                                           	push   r15
 100200a:	57                                              	push   rdi
 100200b:	49 89 ff                                        	mov    r15,rdi
 100200e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1002017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100201d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1002026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100202c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1002035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100203b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1002044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100204a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1002051:	9d                                              	popf
 1002052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1002058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1002061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1002064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1002068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100206c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1002070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1002074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1002078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100207c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1002080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1002084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1002088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100208c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1002090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1002094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1002098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100209c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10020a3 <native_pc_2>

00000000010020a3 <native_pc_2>:
 10020a3:	48 8d 0d 04 00 00 00                            	lea    rcx,[rip+0x4]        # 10020ae <native_pc_2+0xb>
 10020aa:	ff d1                                           	call   rcx
 10020ac:	eb 04                                           	jmp    10020b2 <outer_done_2>
 10020ae:	48 01 da                                        	add    rdx,rbx
 10020b1:	c3                                              	ret

00000000010020b2 <outer_done_2>:
 10020b2:	eb 00                                           	jmp    10020b4 <native_next_2>

00000000010020b4 <native_next_2>:
 10020b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10020b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10020c0 <native_next_2+0xc>
 10020c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10020c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10020cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10020d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10020d8:	41 57                                           	push   r15
 10020da:	9c                                              	pushf
 10020db:	50                                              	push   rax
 10020dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10020e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10020e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10020f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10020f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1002101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1002105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1002109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100210d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1002111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1002115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1002119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100211d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1002121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1002125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1002129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100212d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1002131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1002135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100213a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1002141 <native_next_2+0x8d>
 1002141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1002145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1002149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100214c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1002151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1002158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100215d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1002161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1002169:	48 83 c4 18                                     	add    rsp,0x18
 100216d:	5f                                              	pop    rdi
 100216e:	41 5f                                           	pop    r15
 1002170:	41 5e                                           	pop    r14
 1002172:	41 5d                                           	pop    r13
 1002174:	41 5c                                           	pop    r12
 1002176:	5d                                              	pop    rbp
 1002177:	5b                                              	pop    rbx
 1002178:	c3                                              	ret
	...

0000000001003000 <native_3>:
 1003000:	53                                              	push   rbx
 1003001:	55                                              	push   rbp
 1003002:	41 54                                           	push   r12
 1003004:	41 55                                           	push   r13
 1003006:	41 56                                           	push   r14
 1003008:	41 57                                           	push   r15
 100300a:	57                                              	push   rdi
 100300b:	49 89 ff                                        	mov    r15,rdi
 100300e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1003017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100301d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1003026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100302c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1003035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100303b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1003044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100304a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1003051:	9d                                              	popf
 1003052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1003058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1003061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1003064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1003068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100306c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1003070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1003074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1003078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100307c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1003080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1003084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1003088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100308c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1003090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1003094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1003098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100309c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10030a3 <native_pc_3>

00000000010030a3 <native_pc_3>:
 10030a3:	48 8d 0d 02 00 00 00                            	lea    rcx,[rip+0x2]        # 10030ac <native_pc_3+0x9>
 10030aa:	ff e1                                           	jmp    rcx
 10030ac:	48 01 da                                        	add    rdx,rbx
 10030af:	eb 00                                           	jmp    10030b1 <outer_done_3>

00000000010030b1 <outer_done_3>:
 10030b1:	eb 00                                           	jmp    10030b3 <native_next_3>

00000000010030b3 <native_next_3>:
 10030b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10030b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10030bf <native_next_3+0xc>
 10030bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10030c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10030cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10030d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10030d7:	41 57                                           	push   r15
 10030d9:	9c                                              	pushf
 10030da:	50                                              	push   rax
 10030db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10030e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10030e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10030f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10030f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1003100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1003104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1003108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100310c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1003110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1003114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1003118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100311c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1003120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1003124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1003128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100312c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1003130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1003134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1003139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1003140 <native_next_3+0x8d>
 1003140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1003144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1003148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100314b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1003150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1003157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100315c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1003160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1003168:	48 83 c4 18                                     	add    rsp,0x18
 100316c:	5f                                              	pop    rdi
 100316d:	41 5f                                           	pop    r15
 100316f:	41 5e                                           	pop    r14
 1003171:	41 5d                                           	pop    r13
 1003173:	41 5c                                           	pop    r12
 1003175:	5d                                              	pop    rbp
 1003176:	5b                                              	pop    rbx
 1003177:	c3                                              	ret
	...

0000000001004000 <native_4>:
 1004000:	53                                              	push   rbx
 1004001:	55                                              	push   rbp
 1004002:	41 54                                           	push   r12
 1004004:	41 55                                           	push   r13
 1004006:	41 56                                           	push   r14
 1004008:	41 57                                           	push   r15
 100400a:	57                                              	push   rdi
 100400b:	49 89 ff                                        	mov    r15,rdi
 100400e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1004017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100401d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1004026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100402c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1004035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100403b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1004044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100404a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1004051:	9d                                              	popf
 1004052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1004058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1004061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1004064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1004068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100406c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1004070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1004074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1004078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100407c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1004080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1004084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1004088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100408c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1004090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1004094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1004098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100409c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10040a3 <native_pc_4>

00000000010040a3 <native_pc_4>:
 10040a3:	48 8d 15 04 00 00 00                            	lea    rdx,[rip+0x4]        # 10040ae <native_pc_4+0xb>
 10040aa:	ff d2                                           	call   rdx
 10040ac:	eb 04                                           	jmp    10040b2 <outer_done_4>
 10040ae:	48 01 da                                        	add    rdx,rbx
 10040b1:	c3                                              	ret

00000000010040b2 <outer_done_4>:
 10040b2:	eb 00                                           	jmp    10040b4 <native_next_4>

00000000010040b4 <native_next_4>:
 10040b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10040b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10040c0 <native_next_4+0xc>
 10040c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10040c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10040cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10040d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10040d8:	41 57                                           	push   r15
 10040da:	9c                                              	pushf
 10040db:	50                                              	push   rax
 10040dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10040e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10040e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10040f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10040f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1004101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1004105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1004109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100410d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1004111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1004115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1004119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100411d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1004121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1004125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1004129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100412d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1004131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1004135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100413a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1004141 <native_next_4+0x8d>
 1004141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1004145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1004149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100414c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1004151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1004158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100415d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1004161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1004169:	48 83 c4 18                                     	add    rsp,0x18
 100416d:	5f                                              	pop    rdi
 100416e:	41 5f                                           	pop    r15
 1004170:	41 5e                                           	pop    r14
 1004172:	41 5d                                           	pop    r13
 1004174:	41 5c                                           	pop    r12
 1004176:	5d                                              	pop    rbp
 1004177:	5b                                              	pop    rbx
 1004178:	c3                                              	ret
	...

0000000001005000 <native_5>:
 1005000:	53                                              	push   rbx
 1005001:	55                                              	push   rbp
 1005002:	41 54                                           	push   r12
 1005004:	41 55                                           	push   r13
 1005006:	41 56                                           	push   r14
 1005008:	41 57                                           	push   r15
 100500a:	57                                              	push   rdi
 100500b:	49 89 ff                                        	mov    r15,rdi
 100500e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1005017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100501d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1005026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100502c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1005035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100503b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1005044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100504a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1005051:	9d                                              	popf
 1005052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1005058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1005061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1005064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1005068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100506c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1005070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1005074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1005078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100507c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1005080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1005084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1005088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100508c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1005090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1005094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1005098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100509c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10050a3 <native_pc_5>

00000000010050a3 <native_pc_5>:
 10050a3:	48 8d 15 02 00 00 00                            	lea    rdx,[rip+0x2]        # 10050ac <native_pc_5+0x9>
 10050aa:	ff e2                                           	jmp    rdx
 10050ac:	48 01 da                                        	add    rdx,rbx
 10050af:	eb 00                                           	jmp    10050b1 <outer_done_5>

00000000010050b1 <outer_done_5>:
 10050b1:	eb 00                                           	jmp    10050b3 <native_next_5>

00000000010050b3 <native_next_5>:
 10050b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10050b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10050bf <native_next_5+0xc>
 10050bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10050c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10050cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10050d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10050d7:	41 57                                           	push   r15
 10050d9:	9c                                              	pushf
 10050da:	50                                              	push   rax
 10050db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10050e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10050e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10050f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10050f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1005100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1005104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1005108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100510c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1005110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1005114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1005118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100511c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1005120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1005124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1005128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100512c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1005130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1005134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1005139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1005140 <native_next_5+0x8d>
 1005140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1005144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1005148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100514b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1005150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1005157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100515c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1005160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1005168:	48 83 c4 18                                     	add    rsp,0x18
 100516c:	5f                                              	pop    rdi
 100516d:	41 5f                                           	pop    r15
 100516f:	41 5e                                           	pop    r14
 1005171:	41 5d                                           	pop    r13
 1005173:	41 5c                                           	pop    r12
 1005175:	5d                                              	pop    rbp
 1005176:	5b                                              	pop    rbx
 1005177:	c3                                              	ret
	...

0000000001006000 <native_6>:
 1006000:	53                                              	push   rbx
 1006001:	55                                              	push   rbp
 1006002:	41 54                                           	push   r12
 1006004:	41 55                                           	push   r13
 1006006:	41 56                                           	push   r14
 1006008:	41 57                                           	push   r15
 100600a:	57                                              	push   rdi
 100600b:	49 89 ff                                        	mov    r15,rdi
 100600e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1006017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100601d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1006026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100602c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1006035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100603b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1006044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100604a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1006051:	9d                                              	popf
 1006052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1006058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1006061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1006064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1006068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100606c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1006070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1006074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1006078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100607c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1006080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1006084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1006088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100608c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1006090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1006094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1006098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100609c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10060a3 <native_pc_6>

00000000010060a3 <native_pc_6>:
 10060a3:	48 8d 1d 04 00 00 00                            	lea    rbx,[rip+0x4]        # 10060ae <native_pc_6+0xb>
 10060aa:	ff d3                                           	call   rbx
 10060ac:	eb 04                                           	jmp    10060b2 <outer_done_6>
 10060ae:	48 01 da                                        	add    rdx,rbx
 10060b1:	c3                                              	ret

00000000010060b2 <outer_done_6>:
 10060b2:	eb 00                                           	jmp    10060b4 <native_next_6>

00000000010060b4 <native_next_6>:
 10060b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10060b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10060c0 <native_next_6+0xc>
 10060c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10060c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10060cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10060d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10060d8:	41 57                                           	push   r15
 10060da:	9c                                              	pushf
 10060db:	50                                              	push   rax
 10060dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10060e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10060e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10060f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10060f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1006101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1006105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1006109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100610d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1006111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1006115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1006119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100611d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1006121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1006125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1006129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100612d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1006131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1006135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100613a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1006141 <native_next_6+0x8d>
 1006141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1006145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1006149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100614c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1006151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1006158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100615d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1006161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1006169:	48 83 c4 18                                     	add    rsp,0x18
 100616d:	5f                                              	pop    rdi
 100616e:	41 5f                                           	pop    r15
 1006170:	41 5e                                           	pop    r14
 1006172:	41 5d                                           	pop    r13
 1006174:	41 5c                                           	pop    r12
 1006176:	5d                                              	pop    rbp
 1006177:	5b                                              	pop    rbx
 1006178:	c3                                              	ret
	...

0000000001007000 <native_7>:
 1007000:	53                                              	push   rbx
 1007001:	55                                              	push   rbp
 1007002:	41 54                                           	push   r12
 1007004:	41 55                                           	push   r13
 1007006:	41 56                                           	push   r14
 1007008:	41 57                                           	push   r15
 100700a:	57                                              	push   rdi
 100700b:	49 89 ff                                        	mov    r15,rdi
 100700e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1007017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100701d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1007026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100702c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1007035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100703b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1007044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100704a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1007051:	9d                                              	popf
 1007052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1007058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1007061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1007064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1007068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100706c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1007070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1007074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1007078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100707c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1007080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1007084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1007088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100708c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1007090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1007094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1007098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100709c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10070a3 <native_pc_7>

00000000010070a3 <native_pc_7>:
 10070a3:	48 8d 1d 02 00 00 00                            	lea    rbx,[rip+0x2]        # 10070ac <native_pc_7+0x9>
 10070aa:	ff e3                                           	jmp    rbx
 10070ac:	48 01 da                                        	add    rdx,rbx
 10070af:	eb 00                                           	jmp    10070b1 <outer_done_7>

00000000010070b1 <outer_done_7>:
 10070b1:	eb 00                                           	jmp    10070b3 <native_next_7>

00000000010070b3 <native_next_7>:
 10070b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10070b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10070bf <native_next_7+0xc>
 10070bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10070c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10070cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10070d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10070d7:	41 57                                           	push   r15
 10070d9:	9c                                              	pushf
 10070da:	50                                              	push   rax
 10070db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10070e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10070e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10070f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10070f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1007100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1007104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1007108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100710c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1007110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1007114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1007118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100711c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1007120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1007124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1007128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100712c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1007130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1007134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1007139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1007140 <native_next_7+0x8d>
 1007140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1007144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1007148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100714b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1007150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1007157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100715c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1007160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1007168:	48 83 c4 18                                     	add    rsp,0x18
 100716c:	5f                                              	pop    rdi
 100716d:	41 5f                                           	pop    r15
 100716f:	41 5e                                           	pop    r14
 1007171:	41 5d                                           	pop    r13
 1007173:	41 5c                                           	pop    r12
 1007175:	5d                                              	pop    rbp
 1007176:	5b                                              	pop    rbx
 1007177:	c3                                              	ret
	...

0000000001008000 <native_8>:
 1008000:	53                                              	push   rbx
 1008001:	55                                              	push   rbp
 1008002:	41 54                                           	push   r12
 1008004:	41 55                                           	push   r13
 1008006:	41 56                                           	push   r14
 1008008:	41 57                                           	push   r15
 100800a:	57                                              	push   rdi
 100800b:	49 89 ff                                        	mov    r15,rdi
 100800e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1008017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100801d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1008026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100802c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1008035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100803b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1008044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100804a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1008051:	9d                                              	popf
 1008052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1008058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1008061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1008064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1008068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100806c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1008070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1008074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1008078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100807c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1008080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1008084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1008088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100808c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1008090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1008094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1008098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100809c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10080a3 <native_pc_8>

00000000010080a3 <native_pc_8>:
 10080a3:	48 8d 2d 04 00 00 00                            	lea    rbp,[rip+0x4]        # 10080ae <native_pc_8+0xb>
 10080aa:	ff d5                                           	call   rbp
 10080ac:	eb 04                                           	jmp    10080b2 <outer_done_8>
 10080ae:	48 01 da                                        	add    rdx,rbx
 10080b1:	c3                                              	ret

00000000010080b2 <outer_done_8>:
 10080b2:	eb 00                                           	jmp    10080b4 <native_next_8>

00000000010080b4 <native_next_8>:
 10080b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10080b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10080c0 <native_next_8+0xc>
 10080c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10080c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10080cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10080d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10080d8:	41 57                                           	push   r15
 10080da:	9c                                              	pushf
 10080db:	50                                              	push   rax
 10080dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10080e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10080e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10080f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10080f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1008101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1008105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1008109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100810d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1008111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1008115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1008119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100811d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1008121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1008125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1008129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100812d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1008131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1008135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100813a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1008141 <native_next_8+0x8d>
 1008141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1008145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1008149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100814c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1008151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1008158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100815d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1008161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1008169:	48 83 c4 18                                     	add    rsp,0x18
 100816d:	5f                                              	pop    rdi
 100816e:	41 5f                                           	pop    r15
 1008170:	41 5e                                           	pop    r14
 1008172:	41 5d                                           	pop    r13
 1008174:	41 5c                                           	pop    r12
 1008176:	5d                                              	pop    rbp
 1008177:	5b                                              	pop    rbx
 1008178:	c3                                              	ret
	...

0000000001009000 <native_9>:
 1009000:	53                                              	push   rbx
 1009001:	55                                              	push   rbp
 1009002:	41 54                                           	push   r12
 1009004:	41 55                                           	push   r13
 1009006:	41 56                                           	push   r14
 1009008:	41 57                                           	push   r15
 100900a:	57                                              	push   rdi
 100900b:	49 89 ff                                        	mov    r15,rdi
 100900e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1009017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100901d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1009026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100902c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1009035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100903b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1009044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100904a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1009051:	9d                                              	popf
 1009052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1009058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1009061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1009064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1009068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100906c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1009070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1009074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1009078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100907c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1009080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1009084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1009088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100908c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1009090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1009094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1009098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100909c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10090a3 <native_pc_9>

00000000010090a3 <native_pc_9>:
 10090a3:	48 8d 2d 02 00 00 00                            	lea    rbp,[rip+0x2]        # 10090ac <native_pc_9+0x9>
 10090aa:	ff e5                                           	jmp    rbp
 10090ac:	48 01 da                                        	add    rdx,rbx
 10090af:	eb 00                                           	jmp    10090b1 <outer_done_9>

00000000010090b1 <outer_done_9>:
 10090b1:	eb 00                                           	jmp    10090b3 <native_next_9>

00000000010090b3 <native_next_9>:
 10090b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10090b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10090bf <native_next_9+0xc>
 10090bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10090c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10090cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10090d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10090d7:	41 57                                           	push   r15
 10090d9:	9c                                              	pushf
 10090da:	50                                              	push   rax
 10090db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10090e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10090e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10090f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10090f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1009100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1009104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1009108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100910c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1009110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1009114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1009118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100911c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1009120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1009124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1009128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100912c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1009130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1009134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1009139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1009140 <native_next_9+0x8d>
 1009140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1009144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1009148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100914b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1009150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1009157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100915c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1009160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1009168:	48 83 c4 18                                     	add    rsp,0x18
 100916c:	5f                                              	pop    rdi
 100916d:	41 5f                                           	pop    r15
 100916f:	41 5e                                           	pop    r14
 1009171:	41 5d                                           	pop    r13
 1009173:	41 5c                                           	pop    r12
 1009175:	5d                                              	pop    rbp
 1009176:	5b                                              	pop    rbx
 1009177:	c3                                              	ret
	...

000000000100a000 <native_10>:
 100a000:	53                                              	push   rbx
 100a001:	55                                              	push   rbp
 100a002:	41 54                                           	push   r12
 100a004:	41 55                                           	push   r13
 100a006:	41 56                                           	push   r14
 100a008:	41 57                                           	push   r15
 100a00a:	57                                              	push   rdi
 100a00b:	49 89 ff                                        	mov    r15,rdi
 100a00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100a017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100a01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100a026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100a02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100a035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100a03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100a044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100a04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100a051:	9d                                              	popf
 100a052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100a058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100a061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100a064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100a068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100a06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100a070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100a074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100a078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100a07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100a080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100a084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100a088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100a08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100a090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100a094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100a098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100a09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100a0a3 <native_pc_10>

000000000100a0a3 <native_pc_10>:
 100a0a3:	48 8d 35 04 00 00 00                            	lea    rsi,[rip+0x4]        # 100a0ae <native_pc_10+0xb>
 100a0aa:	ff d6                                           	call   rsi
 100a0ac:	eb 04                                           	jmp    100a0b2 <outer_done_10>
 100a0ae:	48 01 da                                        	add    rdx,rbx
 100a0b1:	c3                                              	ret

000000000100a0b2 <outer_done_10>:
 100a0b2:	eb 00                                           	jmp    100a0b4 <native_next_10>

000000000100a0b4 <native_next_10>:
 100a0b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100a0b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100a0c0 <native_next_10+0xc>
 100a0c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100a0c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100a0cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100a0d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100a0d8:	41 57                                           	push   r15
 100a0da:	9c                                              	pushf
 100a0db:	50                                              	push   rax
 100a0dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100a0e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100a0e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100a0f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100a0f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100a101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100a105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100a109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100a10d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100a111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100a115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100a119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100a11d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100a121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100a125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100a129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100a12d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100a131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100a135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100a13a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100a141 <native_next_10+0x8d>
 100a141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100a145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100a149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100a14c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100a151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100a158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100a15d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100a161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100a169:	48 83 c4 18                                     	add    rsp,0x18
 100a16d:	5f                                              	pop    rdi
 100a16e:	41 5f                                           	pop    r15
 100a170:	41 5e                                           	pop    r14
 100a172:	41 5d                                           	pop    r13
 100a174:	41 5c                                           	pop    r12
 100a176:	5d                                              	pop    rbp
 100a177:	5b                                              	pop    rbx
 100a178:	c3                                              	ret
	...

000000000100b000 <native_11>:
 100b000:	53                                              	push   rbx
 100b001:	55                                              	push   rbp
 100b002:	41 54                                           	push   r12
 100b004:	41 55                                           	push   r13
 100b006:	41 56                                           	push   r14
 100b008:	41 57                                           	push   r15
 100b00a:	57                                              	push   rdi
 100b00b:	49 89 ff                                        	mov    r15,rdi
 100b00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100b017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100b01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100b026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100b02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100b035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100b03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100b044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100b04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100b051:	9d                                              	popf
 100b052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100b058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100b061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100b064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100b068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100b06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100b070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100b074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100b078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100b07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100b080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100b084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100b088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100b08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100b090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100b094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100b098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100b09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100b0a3 <native_pc_11>

000000000100b0a3 <native_pc_11>:
 100b0a3:	48 8d 35 02 00 00 00                            	lea    rsi,[rip+0x2]        # 100b0ac <native_pc_11+0x9>
 100b0aa:	ff e6                                           	jmp    rsi
 100b0ac:	48 01 da                                        	add    rdx,rbx
 100b0af:	eb 00                                           	jmp    100b0b1 <outer_done_11>

000000000100b0b1 <outer_done_11>:
 100b0b1:	eb 00                                           	jmp    100b0b3 <native_next_11>

000000000100b0b3 <native_next_11>:
 100b0b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100b0b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100b0bf <native_next_11+0xc>
 100b0bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100b0c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100b0cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100b0d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100b0d7:	41 57                                           	push   r15
 100b0d9:	9c                                              	pushf
 100b0da:	50                                              	push   rax
 100b0db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100b0e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100b0e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100b0f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100b0f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100b100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100b104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100b108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100b10c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100b110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100b114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100b118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100b11c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100b120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100b124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100b128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100b12c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100b130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100b134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100b139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100b140 <native_next_11+0x8d>
 100b140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100b144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100b148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100b14b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100b150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100b157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100b15c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100b160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100b168:	48 83 c4 18                                     	add    rsp,0x18
 100b16c:	5f                                              	pop    rdi
 100b16d:	41 5f                                           	pop    r15
 100b16f:	41 5e                                           	pop    r14
 100b171:	41 5d                                           	pop    r13
 100b173:	41 5c                                           	pop    r12
 100b175:	5d                                              	pop    rbp
 100b176:	5b                                              	pop    rbx
 100b177:	c3                                              	ret
	...

000000000100c000 <native_12>:
 100c000:	53                                              	push   rbx
 100c001:	55                                              	push   rbp
 100c002:	41 54                                           	push   r12
 100c004:	41 55                                           	push   r13
 100c006:	41 56                                           	push   r14
 100c008:	41 57                                           	push   r15
 100c00a:	57                                              	push   rdi
 100c00b:	49 89 ff                                        	mov    r15,rdi
 100c00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100c017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100c01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100c026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100c02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100c035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100c03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100c044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100c04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100c051:	9d                                              	popf
 100c052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100c058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100c061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100c064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100c068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100c06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100c070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100c074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100c078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100c07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100c080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100c084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100c088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100c08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100c090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100c094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100c098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100c09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100c0a3 <native_pc_12>

000000000100c0a3 <native_pc_12>:
 100c0a3:	48 8d 3d 04 00 00 00                            	lea    rdi,[rip+0x4]        # 100c0ae <native_pc_12+0xb>
 100c0aa:	ff d7                                           	call   rdi
 100c0ac:	eb 04                                           	jmp    100c0b2 <outer_done_12>
 100c0ae:	48 01 da                                        	add    rdx,rbx
 100c0b1:	c3                                              	ret

000000000100c0b2 <outer_done_12>:
 100c0b2:	eb 00                                           	jmp    100c0b4 <native_next_12>

000000000100c0b4 <native_next_12>:
 100c0b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100c0b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100c0c0 <native_next_12+0xc>
 100c0c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100c0c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100c0cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100c0d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100c0d8:	41 57                                           	push   r15
 100c0da:	9c                                              	pushf
 100c0db:	50                                              	push   rax
 100c0dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100c0e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100c0e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100c0f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100c0f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100c101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100c105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100c109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100c10d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100c111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100c115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100c119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100c11d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100c121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100c125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100c129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100c12d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100c131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100c135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100c13a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100c141 <native_next_12+0x8d>
 100c141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100c145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100c149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100c14c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100c151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100c158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100c15d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100c161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100c169:	48 83 c4 18                                     	add    rsp,0x18
 100c16d:	5f                                              	pop    rdi
 100c16e:	41 5f                                           	pop    r15
 100c170:	41 5e                                           	pop    r14
 100c172:	41 5d                                           	pop    r13
 100c174:	41 5c                                           	pop    r12
 100c176:	5d                                              	pop    rbp
 100c177:	5b                                              	pop    rbx
 100c178:	c3                                              	ret
	...

000000000100d000 <native_13>:
 100d000:	53                                              	push   rbx
 100d001:	55                                              	push   rbp
 100d002:	41 54                                           	push   r12
 100d004:	41 55                                           	push   r13
 100d006:	41 56                                           	push   r14
 100d008:	41 57                                           	push   r15
 100d00a:	57                                              	push   rdi
 100d00b:	49 89 ff                                        	mov    r15,rdi
 100d00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100d017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100d01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100d026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100d02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100d035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100d03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100d044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100d04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100d051:	9d                                              	popf
 100d052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100d058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100d061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100d064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100d068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100d06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100d070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100d074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100d078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100d07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100d080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100d084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100d088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100d08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100d090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100d094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100d098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100d09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100d0a3 <native_pc_13>

000000000100d0a3 <native_pc_13>:
 100d0a3:	48 8d 3d 02 00 00 00                            	lea    rdi,[rip+0x2]        # 100d0ac <native_pc_13+0x9>
 100d0aa:	ff e7                                           	jmp    rdi
 100d0ac:	48 01 da                                        	add    rdx,rbx
 100d0af:	eb 00                                           	jmp    100d0b1 <outer_done_13>

000000000100d0b1 <outer_done_13>:
 100d0b1:	eb 00                                           	jmp    100d0b3 <native_next_13>

000000000100d0b3 <native_next_13>:
 100d0b3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100d0b8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100d0bf <native_next_13+0xc>
 100d0bf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100d0c5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100d0cb:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100d0d1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100d0d7:	41 57                                           	push   r15
 100d0d9:	9c                                              	pushf
 100d0da:	50                                              	push   rax
 100d0db:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100d0e0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100d0e8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100d0f0:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100d0f8:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100d100:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100d104:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100d108:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100d10c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100d110:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100d114:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100d118:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100d11c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100d120:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100d124:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100d128:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100d12c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100d130:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100d134:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100d139:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100d140 <native_next_13+0x8d>
 100d140:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100d144:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100d148:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100d14b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100d150:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100d157:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100d15c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100d160:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100d168:	48 83 c4 18                                     	add    rsp,0x18
 100d16c:	5f                                              	pop    rdi
 100d16d:	41 5f                                           	pop    r15
 100d16f:	41 5e                                           	pop    r14
 100d171:	41 5d                                           	pop    r13
 100d173:	41 5c                                           	pop    r12
 100d175:	5d                                              	pop    rbp
 100d176:	5b                                              	pop    rbx
 100d177:	c3                                              	ret
	...

000000000100e000 <native_14>:
 100e000:	53                                              	push   rbx
 100e001:	55                                              	push   rbp
 100e002:	41 54                                           	push   r12
 100e004:	41 55                                           	push   r13
 100e006:	41 56                                           	push   r14
 100e008:	41 57                                           	push   r15
 100e00a:	57                                              	push   rdi
 100e00b:	49 89 ff                                        	mov    r15,rdi
 100e00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100e017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100e01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100e026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100e02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100e035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100e03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100e044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100e04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100e051:	9d                                              	popf
 100e052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100e058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100e061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100e064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100e068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100e06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100e070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100e074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100e078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100e07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100e080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100e084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100e088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100e08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100e090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100e094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100e098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100e09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100e0a3 <native_pc_14>

000000000100e0a3 <native_pc_14>:
 100e0a3:	4c 8d 05 05 00 00 00                            	lea    r8,[rip+0x5]        # 100e0af <native_pc_14+0xc>
 100e0aa:	41 ff d0                                        	call   r8
 100e0ad:	eb 04                                           	jmp    100e0b3 <outer_done_14>
 100e0af:	48 01 da                                        	add    rdx,rbx
 100e0b2:	c3                                              	ret

000000000100e0b3 <outer_done_14>:
 100e0b3:	eb 00                                           	jmp    100e0b5 <native_next_14>

000000000100e0b5 <native_next_14>:
 100e0b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100e0ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100e0c1 <native_next_14+0xc>
 100e0c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100e0c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100e0cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100e0d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100e0d9:	41 57                                           	push   r15
 100e0db:	9c                                              	pushf
 100e0dc:	50                                              	push   rax
 100e0dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100e0e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100e0ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100e0f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100e0fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100e102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100e106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100e10a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100e10e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100e112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100e116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100e11a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100e11e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100e122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100e126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100e12a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100e12e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100e132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100e136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100e13b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100e142 <native_next_14+0x8d>
 100e142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100e146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100e14a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100e14d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100e152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100e159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100e15e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100e162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100e16a:	48 83 c4 18                                     	add    rsp,0x18
 100e16e:	5f                                              	pop    rdi
 100e16f:	41 5f                                           	pop    r15
 100e171:	41 5e                                           	pop    r14
 100e173:	41 5d                                           	pop    r13
 100e175:	41 5c                                           	pop    r12
 100e177:	5d                                              	pop    rbp
 100e178:	5b                                              	pop    rbx
 100e179:	c3                                              	ret
	...

000000000100f000 <native_15>:
 100f000:	53                                              	push   rbx
 100f001:	55                                              	push   rbp
 100f002:	41 54                                           	push   r12
 100f004:	41 55                                           	push   r13
 100f006:	41 56                                           	push   r14
 100f008:	41 57                                           	push   r15
 100f00a:	57                                              	push   rdi
 100f00b:	49 89 ff                                        	mov    r15,rdi
 100f00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 100f017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 100f01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 100f026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 100f02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 100f035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 100f03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 100f044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100f04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 100f051:	9d                                              	popf
 100f052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 100f058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 100f061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 100f064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 100f068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 100f06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 100f070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 100f074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 100f078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 100f07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 100f080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 100f084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 100f088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 100f08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 100f090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 100f094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 100f098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 100f09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 100f0a3 <native_pc_15>

000000000100f0a3 <native_pc_15>:
 100f0a3:	4c 8d 05 03 00 00 00                            	lea    r8,[rip+0x3]        # 100f0ad <native_pc_15+0xa>
 100f0aa:	41 ff e0                                        	jmp    r8
 100f0ad:	48 01 da                                        	add    rdx,rbx
 100f0b0:	eb 00                                           	jmp    100f0b2 <outer_done_15>

000000000100f0b2 <outer_done_15>:
 100f0b2:	eb 00                                           	jmp    100f0b4 <native_next_15>

000000000100f0b4 <native_next_15>:
 100f0b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 100f0b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 100f0c0 <native_next_15+0xc>
 100f0c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 100f0c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 100f0cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 100f0d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 100f0d8:	41 57                                           	push   r15
 100f0da:	9c                                              	pushf
 100f0db:	50                                              	push   rax
 100f0dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 100f0e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 100f0e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 100f0f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 100f0f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 100f101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 100f105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 100f109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 100f10d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 100f111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 100f115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 100f119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 100f11d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 100f121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 100f125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 100f129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 100f12d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 100f131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 100f135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 100f13a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 100f141 <native_next_15+0x8d>
 100f141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 100f145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 100f149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 100f14c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 100f151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 100f158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 100f15d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 100f161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 100f169:	48 83 c4 18                                     	add    rsp,0x18
 100f16d:	5f                                              	pop    rdi
 100f16e:	41 5f                                           	pop    r15
 100f170:	41 5e                                           	pop    r14
 100f172:	41 5d                                           	pop    r13
 100f174:	41 5c                                           	pop    r12
 100f176:	5d                                              	pop    rbp
 100f177:	5b                                              	pop    rbx
 100f178:	c3                                              	ret
	...

0000000001010000 <native_16>:
 1010000:	53                                              	push   rbx
 1010001:	55                                              	push   rbp
 1010002:	41 54                                           	push   r12
 1010004:	41 55                                           	push   r13
 1010006:	41 56                                           	push   r14
 1010008:	41 57                                           	push   r15
 101000a:	57                                              	push   rdi
 101000b:	49 89 ff                                        	mov    r15,rdi
 101000e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1010017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101001d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1010026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101002c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1010035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101003b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1010044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101004a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1010051:	9d                                              	popf
 1010052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1010058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1010061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1010064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1010068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101006c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1010070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1010074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1010078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101007c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1010080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1010084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1010088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101008c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1010090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1010094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1010098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101009c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10100a3 <native_pc_16>

00000000010100a3 <native_pc_16>:
 10100a3:	4c 8d 0d 05 00 00 00                            	lea    r9,[rip+0x5]        # 10100af <native_pc_16+0xc>
 10100aa:	41 ff d1                                        	call   r9
 10100ad:	eb 04                                           	jmp    10100b3 <outer_done_16>
 10100af:	48 01 da                                        	add    rdx,rbx
 10100b2:	c3                                              	ret

00000000010100b3 <outer_done_16>:
 10100b3:	eb 00                                           	jmp    10100b5 <native_next_16>

00000000010100b5 <native_next_16>:
 10100b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10100ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10100c1 <native_next_16+0xc>
 10100c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10100c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10100cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10100d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10100d9:	41 57                                           	push   r15
 10100db:	9c                                              	pushf
 10100dc:	50                                              	push   rax
 10100dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10100e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10100ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10100f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10100fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1010102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1010106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101010a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101010e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1010112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1010116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101011a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101011e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1010122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1010126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101012a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101012e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1010132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1010136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101013b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1010142 <native_next_16+0x8d>
 1010142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1010146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101014a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101014d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1010152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1010159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101015e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1010162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101016a:	48 83 c4 18                                     	add    rsp,0x18
 101016e:	5f                                              	pop    rdi
 101016f:	41 5f                                           	pop    r15
 1010171:	41 5e                                           	pop    r14
 1010173:	41 5d                                           	pop    r13
 1010175:	41 5c                                           	pop    r12
 1010177:	5d                                              	pop    rbp
 1010178:	5b                                              	pop    rbx
 1010179:	c3                                              	ret
	...

0000000001011000 <native_17>:
 1011000:	53                                              	push   rbx
 1011001:	55                                              	push   rbp
 1011002:	41 54                                           	push   r12
 1011004:	41 55                                           	push   r13
 1011006:	41 56                                           	push   r14
 1011008:	41 57                                           	push   r15
 101100a:	57                                              	push   rdi
 101100b:	49 89 ff                                        	mov    r15,rdi
 101100e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1011017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101101d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1011026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101102c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1011035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101103b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1011044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101104a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1011051:	9d                                              	popf
 1011052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1011058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1011061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1011064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1011068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101106c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1011070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1011074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1011078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101107c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1011080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1011084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1011088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101108c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1011090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1011094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1011098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101109c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10110a3 <native_pc_17>

00000000010110a3 <native_pc_17>:
 10110a3:	4c 8d 0d 03 00 00 00                            	lea    r9,[rip+0x3]        # 10110ad <native_pc_17+0xa>
 10110aa:	41 ff e1                                        	jmp    r9
 10110ad:	48 01 da                                        	add    rdx,rbx
 10110b0:	eb 00                                           	jmp    10110b2 <outer_done_17>

00000000010110b2 <outer_done_17>:
 10110b2:	eb 00                                           	jmp    10110b4 <native_next_17>

00000000010110b4 <native_next_17>:
 10110b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10110b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10110c0 <native_next_17+0xc>
 10110c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10110c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10110cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10110d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10110d8:	41 57                                           	push   r15
 10110da:	9c                                              	pushf
 10110db:	50                                              	push   rax
 10110dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10110e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10110e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10110f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10110f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1011101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1011105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1011109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101110d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1011111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1011115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1011119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101111d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1011121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1011125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1011129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101112d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1011131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1011135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101113a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1011141 <native_next_17+0x8d>
 1011141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1011145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1011149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101114c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1011151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1011158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101115d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1011161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1011169:	48 83 c4 18                                     	add    rsp,0x18
 101116d:	5f                                              	pop    rdi
 101116e:	41 5f                                           	pop    r15
 1011170:	41 5e                                           	pop    r14
 1011172:	41 5d                                           	pop    r13
 1011174:	41 5c                                           	pop    r12
 1011176:	5d                                              	pop    rbp
 1011177:	5b                                              	pop    rbx
 1011178:	c3                                              	ret
	...

0000000001012000 <native_18>:
 1012000:	53                                              	push   rbx
 1012001:	55                                              	push   rbp
 1012002:	41 54                                           	push   r12
 1012004:	41 55                                           	push   r13
 1012006:	41 56                                           	push   r14
 1012008:	41 57                                           	push   r15
 101200a:	57                                              	push   rdi
 101200b:	49 89 ff                                        	mov    r15,rdi
 101200e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1012017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101201d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1012026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101202c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1012035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101203b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1012044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101204a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1012051:	9d                                              	popf
 1012052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1012058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1012061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1012064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1012068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101206c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1012070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1012074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1012078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101207c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1012080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1012084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1012088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101208c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1012090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1012094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1012098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101209c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10120a3 <native_pc_18>

00000000010120a3 <native_pc_18>:
 10120a3:	4c 8d 15 05 00 00 00                            	lea    r10,[rip+0x5]        # 10120af <native_pc_18+0xc>
 10120aa:	41 ff d2                                        	call   r10
 10120ad:	eb 04                                           	jmp    10120b3 <outer_done_18>
 10120af:	48 01 da                                        	add    rdx,rbx
 10120b2:	c3                                              	ret

00000000010120b3 <outer_done_18>:
 10120b3:	eb 00                                           	jmp    10120b5 <native_next_18>

00000000010120b5 <native_next_18>:
 10120b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10120ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10120c1 <native_next_18+0xc>
 10120c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10120c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10120cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10120d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10120d9:	41 57                                           	push   r15
 10120db:	9c                                              	pushf
 10120dc:	50                                              	push   rax
 10120dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10120e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10120ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10120f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10120fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1012102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1012106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101210a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101210e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1012112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1012116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101211a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101211e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1012122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1012126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101212a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101212e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1012132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1012136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101213b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1012142 <native_next_18+0x8d>
 1012142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1012146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101214a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101214d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1012152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1012159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101215e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1012162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101216a:	48 83 c4 18                                     	add    rsp,0x18
 101216e:	5f                                              	pop    rdi
 101216f:	41 5f                                           	pop    r15
 1012171:	41 5e                                           	pop    r14
 1012173:	41 5d                                           	pop    r13
 1012175:	41 5c                                           	pop    r12
 1012177:	5d                                              	pop    rbp
 1012178:	5b                                              	pop    rbx
 1012179:	c3                                              	ret
	...

0000000001013000 <native_19>:
 1013000:	53                                              	push   rbx
 1013001:	55                                              	push   rbp
 1013002:	41 54                                           	push   r12
 1013004:	41 55                                           	push   r13
 1013006:	41 56                                           	push   r14
 1013008:	41 57                                           	push   r15
 101300a:	57                                              	push   rdi
 101300b:	49 89 ff                                        	mov    r15,rdi
 101300e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1013017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101301d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1013026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101302c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1013035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101303b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1013044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101304a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1013051:	9d                                              	popf
 1013052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1013058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1013061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1013064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1013068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101306c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1013070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1013074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1013078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101307c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1013080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1013084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1013088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101308c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1013090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1013094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1013098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101309c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10130a3 <native_pc_19>

00000000010130a3 <native_pc_19>:
 10130a3:	4c 8d 15 03 00 00 00                            	lea    r10,[rip+0x3]        # 10130ad <native_pc_19+0xa>
 10130aa:	41 ff e2                                        	jmp    r10
 10130ad:	48 01 da                                        	add    rdx,rbx
 10130b0:	eb 00                                           	jmp    10130b2 <outer_done_19>

00000000010130b2 <outer_done_19>:
 10130b2:	eb 00                                           	jmp    10130b4 <native_next_19>

00000000010130b4 <native_next_19>:
 10130b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10130b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10130c0 <native_next_19+0xc>
 10130c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10130c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10130cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10130d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10130d8:	41 57                                           	push   r15
 10130da:	9c                                              	pushf
 10130db:	50                                              	push   rax
 10130dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10130e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10130e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10130f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10130f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1013101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1013105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1013109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101310d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1013111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1013115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1013119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101311d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1013121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1013125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1013129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101312d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1013131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1013135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101313a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1013141 <native_next_19+0x8d>
 1013141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1013145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1013149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101314c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1013151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1013158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101315d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1013161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1013169:	48 83 c4 18                                     	add    rsp,0x18
 101316d:	5f                                              	pop    rdi
 101316e:	41 5f                                           	pop    r15
 1013170:	41 5e                                           	pop    r14
 1013172:	41 5d                                           	pop    r13
 1013174:	41 5c                                           	pop    r12
 1013176:	5d                                              	pop    rbp
 1013177:	5b                                              	pop    rbx
 1013178:	c3                                              	ret
	...

0000000001014000 <native_20>:
 1014000:	53                                              	push   rbx
 1014001:	55                                              	push   rbp
 1014002:	41 54                                           	push   r12
 1014004:	41 55                                           	push   r13
 1014006:	41 56                                           	push   r14
 1014008:	41 57                                           	push   r15
 101400a:	57                                              	push   rdi
 101400b:	49 89 ff                                        	mov    r15,rdi
 101400e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1014017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101401d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1014026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101402c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1014035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101403b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1014044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101404a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1014051:	9d                                              	popf
 1014052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1014058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1014061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1014064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1014068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101406c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1014070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1014074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1014078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101407c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1014080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1014084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1014088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101408c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1014090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1014094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1014098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101409c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10140a3 <native_pc_20>

00000000010140a3 <native_pc_20>:
 10140a3:	4c 8d 1d 05 00 00 00                            	lea    r11,[rip+0x5]        # 10140af <native_pc_20+0xc>
 10140aa:	41 ff d3                                        	call   r11
 10140ad:	eb 04                                           	jmp    10140b3 <outer_done_20>
 10140af:	48 01 da                                        	add    rdx,rbx
 10140b2:	c3                                              	ret

00000000010140b3 <outer_done_20>:
 10140b3:	eb 00                                           	jmp    10140b5 <native_next_20>

00000000010140b5 <native_next_20>:
 10140b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10140ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10140c1 <native_next_20+0xc>
 10140c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10140c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10140cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10140d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10140d9:	41 57                                           	push   r15
 10140db:	9c                                              	pushf
 10140dc:	50                                              	push   rax
 10140dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10140e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10140ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10140f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10140fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1014102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1014106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101410a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101410e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1014112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1014116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101411a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101411e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1014122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1014126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101412a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101412e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1014132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1014136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101413b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1014142 <native_next_20+0x8d>
 1014142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1014146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101414a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101414d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1014152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1014159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101415e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1014162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101416a:	48 83 c4 18                                     	add    rsp,0x18
 101416e:	5f                                              	pop    rdi
 101416f:	41 5f                                           	pop    r15
 1014171:	41 5e                                           	pop    r14
 1014173:	41 5d                                           	pop    r13
 1014175:	41 5c                                           	pop    r12
 1014177:	5d                                              	pop    rbp
 1014178:	5b                                              	pop    rbx
 1014179:	c3                                              	ret
	...

0000000001015000 <native_21>:
 1015000:	53                                              	push   rbx
 1015001:	55                                              	push   rbp
 1015002:	41 54                                           	push   r12
 1015004:	41 55                                           	push   r13
 1015006:	41 56                                           	push   r14
 1015008:	41 57                                           	push   r15
 101500a:	57                                              	push   rdi
 101500b:	49 89 ff                                        	mov    r15,rdi
 101500e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1015017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101501d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1015026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101502c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1015035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101503b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1015044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101504a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1015051:	9d                                              	popf
 1015052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1015058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1015061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1015064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1015068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101506c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1015070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1015074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1015078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101507c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1015080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1015084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1015088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101508c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1015090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1015094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1015098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101509c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10150a3 <native_pc_21>

00000000010150a3 <native_pc_21>:
 10150a3:	4c 8d 1d 03 00 00 00                            	lea    r11,[rip+0x3]        # 10150ad <native_pc_21+0xa>
 10150aa:	41 ff e3                                        	jmp    r11
 10150ad:	48 01 da                                        	add    rdx,rbx
 10150b0:	eb 00                                           	jmp    10150b2 <outer_done_21>

00000000010150b2 <outer_done_21>:
 10150b2:	eb 00                                           	jmp    10150b4 <native_next_21>

00000000010150b4 <native_next_21>:
 10150b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10150b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10150c0 <native_next_21+0xc>
 10150c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10150c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10150cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10150d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10150d8:	41 57                                           	push   r15
 10150da:	9c                                              	pushf
 10150db:	50                                              	push   rax
 10150dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10150e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10150e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10150f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10150f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1015101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1015105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1015109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101510d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1015111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1015115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1015119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101511d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1015121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1015125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1015129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101512d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1015131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1015135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101513a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1015141 <native_next_21+0x8d>
 1015141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1015145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1015149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101514c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1015151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1015158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101515d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1015161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1015169:	48 83 c4 18                                     	add    rsp,0x18
 101516d:	5f                                              	pop    rdi
 101516e:	41 5f                                           	pop    r15
 1015170:	41 5e                                           	pop    r14
 1015172:	41 5d                                           	pop    r13
 1015174:	41 5c                                           	pop    r12
 1015176:	5d                                              	pop    rbp
 1015177:	5b                                              	pop    rbx
 1015178:	c3                                              	ret
	...

0000000001016000 <native_22>:
 1016000:	53                                              	push   rbx
 1016001:	55                                              	push   rbp
 1016002:	41 54                                           	push   r12
 1016004:	41 55                                           	push   r13
 1016006:	41 56                                           	push   r14
 1016008:	41 57                                           	push   r15
 101600a:	57                                              	push   rdi
 101600b:	49 89 ff                                        	mov    r15,rdi
 101600e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1016017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101601d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1016026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101602c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1016035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101603b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1016044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101604a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1016051:	9d                                              	popf
 1016052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1016058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1016061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1016064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1016068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101606c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1016070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1016074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1016078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101607c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1016080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1016084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1016088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101608c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1016090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1016094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1016098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101609c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10160a3 <native_pc_22>

00000000010160a3 <native_pc_22>:
 10160a3:	4c 8d 25 05 00 00 00                            	lea    r12,[rip+0x5]        # 10160af <native_pc_22+0xc>
 10160aa:	41 ff d4                                        	call   r12
 10160ad:	eb 04                                           	jmp    10160b3 <outer_done_22>
 10160af:	48 01 da                                        	add    rdx,rbx
 10160b2:	c3                                              	ret

00000000010160b3 <outer_done_22>:
 10160b3:	eb 00                                           	jmp    10160b5 <native_next_22>

00000000010160b5 <native_next_22>:
 10160b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10160ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10160c1 <native_next_22+0xc>
 10160c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10160c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10160cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10160d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10160d9:	41 57                                           	push   r15
 10160db:	9c                                              	pushf
 10160dc:	50                                              	push   rax
 10160dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10160e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10160ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10160f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10160fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1016102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1016106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101610a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101610e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1016112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1016116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101611a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101611e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1016122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1016126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101612a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101612e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1016132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1016136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101613b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1016142 <native_next_22+0x8d>
 1016142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1016146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101614a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101614d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1016152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1016159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101615e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1016162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101616a:	48 83 c4 18                                     	add    rsp,0x18
 101616e:	5f                                              	pop    rdi
 101616f:	41 5f                                           	pop    r15
 1016171:	41 5e                                           	pop    r14
 1016173:	41 5d                                           	pop    r13
 1016175:	41 5c                                           	pop    r12
 1016177:	5d                                              	pop    rbp
 1016178:	5b                                              	pop    rbx
 1016179:	c3                                              	ret
	...

0000000001017000 <native_23>:
 1017000:	53                                              	push   rbx
 1017001:	55                                              	push   rbp
 1017002:	41 54                                           	push   r12
 1017004:	41 55                                           	push   r13
 1017006:	41 56                                           	push   r14
 1017008:	41 57                                           	push   r15
 101700a:	57                                              	push   rdi
 101700b:	49 89 ff                                        	mov    r15,rdi
 101700e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1017017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101701d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1017026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101702c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1017035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101703b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1017044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101704a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1017051:	9d                                              	popf
 1017052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1017058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1017061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1017064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1017068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101706c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1017070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1017074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1017078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101707c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1017080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1017084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1017088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101708c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1017090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1017094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1017098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101709c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10170a3 <native_pc_23>

00000000010170a3 <native_pc_23>:
 10170a3:	4c 8d 25 03 00 00 00                            	lea    r12,[rip+0x3]        # 10170ad <native_pc_23+0xa>
 10170aa:	41 ff e4                                        	jmp    r12
 10170ad:	48 01 da                                        	add    rdx,rbx
 10170b0:	eb 00                                           	jmp    10170b2 <outer_done_23>

00000000010170b2 <outer_done_23>:
 10170b2:	eb 00                                           	jmp    10170b4 <native_next_23>

00000000010170b4 <native_next_23>:
 10170b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10170b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10170c0 <native_next_23+0xc>
 10170c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10170c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10170cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10170d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10170d8:	41 57                                           	push   r15
 10170da:	9c                                              	pushf
 10170db:	50                                              	push   rax
 10170dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10170e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10170e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10170f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10170f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1017101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1017105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1017109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101710d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1017111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1017115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1017119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101711d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1017121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1017125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1017129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101712d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1017131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1017135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101713a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1017141 <native_next_23+0x8d>
 1017141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1017145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1017149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101714c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1017151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1017158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101715d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1017161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1017169:	48 83 c4 18                                     	add    rsp,0x18
 101716d:	5f                                              	pop    rdi
 101716e:	41 5f                                           	pop    r15
 1017170:	41 5e                                           	pop    r14
 1017172:	41 5d                                           	pop    r13
 1017174:	41 5c                                           	pop    r12
 1017176:	5d                                              	pop    rbp
 1017177:	5b                                              	pop    rbx
 1017178:	c3                                              	ret
	...

0000000001018000 <native_24>:
 1018000:	53                                              	push   rbx
 1018001:	55                                              	push   rbp
 1018002:	41 54                                           	push   r12
 1018004:	41 55                                           	push   r13
 1018006:	41 56                                           	push   r14
 1018008:	41 57                                           	push   r15
 101800a:	57                                              	push   rdi
 101800b:	49 89 ff                                        	mov    r15,rdi
 101800e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1018017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101801d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1018026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101802c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1018035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101803b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1018044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101804a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1018051:	9d                                              	popf
 1018052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1018058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1018061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1018064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1018068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101806c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1018070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1018074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1018078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101807c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1018080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1018084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1018088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101808c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1018090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1018094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1018098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101809c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10180a3 <native_pc_24>

00000000010180a3 <native_pc_24>:
 10180a3:	4c 8d 2d 05 00 00 00                            	lea    r13,[rip+0x5]        # 10180af <native_pc_24+0xc>
 10180aa:	41 ff d5                                        	call   r13
 10180ad:	eb 04                                           	jmp    10180b3 <outer_done_24>
 10180af:	48 01 da                                        	add    rdx,rbx
 10180b2:	c3                                              	ret

00000000010180b3 <outer_done_24>:
 10180b3:	eb 00                                           	jmp    10180b5 <native_next_24>

00000000010180b5 <native_next_24>:
 10180b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10180ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10180c1 <native_next_24+0xc>
 10180c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10180c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10180cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10180d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10180d9:	41 57                                           	push   r15
 10180db:	9c                                              	pushf
 10180dc:	50                                              	push   rax
 10180dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10180e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10180ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10180f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10180fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1018102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1018106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101810a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101810e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1018112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1018116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101811a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101811e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1018122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1018126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101812a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101812e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1018132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1018136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101813b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1018142 <native_next_24+0x8d>
 1018142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1018146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101814a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101814d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1018152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1018159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101815e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1018162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101816a:	48 83 c4 18                                     	add    rsp,0x18
 101816e:	5f                                              	pop    rdi
 101816f:	41 5f                                           	pop    r15
 1018171:	41 5e                                           	pop    r14
 1018173:	41 5d                                           	pop    r13
 1018175:	41 5c                                           	pop    r12
 1018177:	5d                                              	pop    rbp
 1018178:	5b                                              	pop    rbx
 1018179:	c3                                              	ret
	...

0000000001019000 <native_25>:
 1019000:	53                                              	push   rbx
 1019001:	55                                              	push   rbp
 1019002:	41 54                                           	push   r12
 1019004:	41 55                                           	push   r13
 1019006:	41 56                                           	push   r14
 1019008:	41 57                                           	push   r15
 101900a:	57                                              	push   rdi
 101900b:	49 89 ff                                        	mov    r15,rdi
 101900e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1019017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101901d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1019026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101902c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1019035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101903b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1019044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101904a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1019051:	9d                                              	popf
 1019052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1019058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1019061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1019064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1019068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101906c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1019070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1019074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1019078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101907c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1019080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1019084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1019088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101908c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1019090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1019094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1019098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101909c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10190a3 <native_pc_25>

00000000010190a3 <native_pc_25>:
 10190a3:	4c 8d 2d 03 00 00 00                            	lea    r13,[rip+0x3]        # 10190ad <native_pc_25+0xa>
 10190aa:	41 ff e5                                        	jmp    r13
 10190ad:	48 01 da                                        	add    rdx,rbx
 10190b0:	eb 00                                           	jmp    10190b2 <outer_done_25>

00000000010190b2 <outer_done_25>:
 10190b2:	eb 00                                           	jmp    10190b4 <native_next_25>

00000000010190b4 <native_next_25>:
 10190b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10190b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10190c0 <native_next_25+0xc>
 10190c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10190c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10190cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10190d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10190d8:	41 57                                           	push   r15
 10190da:	9c                                              	pushf
 10190db:	50                                              	push   rax
 10190dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10190e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10190e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10190f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10190f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1019101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1019105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1019109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101910d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1019111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1019115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1019119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101911d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1019121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1019125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1019129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101912d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1019131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1019135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101913a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1019141 <native_next_25+0x8d>
 1019141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1019145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1019149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101914c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1019151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1019158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101915d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1019161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1019169:	48 83 c4 18                                     	add    rsp,0x18
 101916d:	5f                                              	pop    rdi
 101916e:	41 5f                                           	pop    r15
 1019170:	41 5e                                           	pop    r14
 1019172:	41 5d                                           	pop    r13
 1019174:	41 5c                                           	pop    r12
 1019176:	5d                                              	pop    rbp
 1019177:	5b                                              	pop    rbx
 1019178:	c3                                              	ret
	...

000000000101a000 <native_26>:
 101a000:	53                                              	push   rbx
 101a001:	55                                              	push   rbp
 101a002:	41 54                                           	push   r12
 101a004:	41 55                                           	push   r13
 101a006:	41 56                                           	push   r14
 101a008:	41 57                                           	push   r15
 101a00a:	57                                              	push   rdi
 101a00b:	49 89 ff                                        	mov    r15,rdi
 101a00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101a017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101a01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101a026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101a02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101a035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101a03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101a044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101a04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101a051:	9d                                              	popf
 101a052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101a058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101a061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101a064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101a068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101a06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101a070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101a074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101a078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101a07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101a080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101a084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101a088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101a08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101a090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101a094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101a098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101a09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101a0a3 <native_pc_26>

000000000101a0a3 <native_pc_26>:
 101a0a3:	4c 8d 35 05 00 00 00                            	lea    r14,[rip+0x5]        # 101a0af <native_pc_26+0xc>
 101a0aa:	41 ff d6                                        	call   r14
 101a0ad:	eb 04                                           	jmp    101a0b3 <outer_done_26>
 101a0af:	48 01 da                                        	add    rdx,rbx
 101a0b2:	c3                                              	ret

000000000101a0b3 <outer_done_26>:
 101a0b3:	eb 00                                           	jmp    101a0b5 <native_next_26>

000000000101a0b5 <native_next_26>:
 101a0b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101a0ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101a0c1 <native_next_26+0xc>
 101a0c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101a0c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101a0cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101a0d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101a0d9:	41 57                                           	push   r15
 101a0db:	9c                                              	pushf
 101a0dc:	50                                              	push   rax
 101a0dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101a0e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101a0ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101a0f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101a0fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101a102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101a106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101a10a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101a10e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101a112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101a116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101a11a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101a11e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101a122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101a126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101a12a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101a12e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101a132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101a136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101a13b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101a142 <native_next_26+0x8d>
 101a142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101a146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101a14a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101a14d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101a152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101a159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101a15e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101a162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101a16a:	48 83 c4 18                                     	add    rsp,0x18
 101a16e:	5f                                              	pop    rdi
 101a16f:	41 5f                                           	pop    r15
 101a171:	41 5e                                           	pop    r14
 101a173:	41 5d                                           	pop    r13
 101a175:	41 5c                                           	pop    r12
 101a177:	5d                                              	pop    rbp
 101a178:	5b                                              	pop    rbx
 101a179:	c3                                              	ret
	...

000000000101b000 <native_27>:
 101b000:	53                                              	push   rbx
 101b001:	55                                              	push   rbp
 101b002:	41 54                                           	push   r12
 101b004:	41 55                                           	push   r13
 101b006:	41 56                                           	push   r14
 101b008:	41 57                                           	push   r15
 101b00a:	57                                              	push   rdi
 101b00b:	49 89 ff                                        	mov    r15,rdi
 101b00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101b017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101b01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101b026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101b02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101b035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101b03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101b044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101b04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101b051:	9d                                              	popf
 101b052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101b058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101b061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101b064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101b068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101b06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101b070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101b074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101b078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101b07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101b080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101b084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101b088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101b08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101b090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101b094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101b098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101b09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101b0a3 <native_pc_27>

000000000101b0a3 <native_pc_27>:
 101b0a3:	4c 8d 35 03 00 00 00                            	lea    r14,[rip+0x3]        # 101b0ad <native_pc_27+0xa>
 101b0aa:	41 ff e6                                        	jmp    r14
 101b0ad:	48 01 da                                        	add    rdx,rbx
 101b0b0:	eb 00                                           	jmp    101b0b2 <outer_done_27>

000000000101b0b2 <outer_done_27>:
 101b0b2:	eb 00                                           	jmp    101b0b4 <native_next_27>

000000000101b0b4 <native_next_27>:
 101b0b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101b0b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101b0c0 <native_next_27+0xc>
 101b0c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101b0c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101b0cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101b0d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101b0d8:	41 57                                           	push   r15
 101b0da:	9c                                              	pushf
 101b0db:	50                                              	push   rax
 101b0dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101b0e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101b0e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101b0f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101b0f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101b101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101b105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101b109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101b10d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101b111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101b115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101b119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101b11d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101b121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101b125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101b129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101b12d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101b131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101b135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101b13a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101b141 <native_next_27+0x8d>
 101b141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101b145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101b149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101b14c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101b151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101b158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101b15d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101b161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101b169:	48 83 c4 18                                     	add    rsp,0x18
 101b16d:	5f                                              	pop    rdi
 101b16e:	41 5f                                           	pop    r15
 101b170:	41 5e                                           	pop    r14
 101b172:	41 5d                                           	pop    r13
 101b174:	41 5c                                           	pop    r12
 101b176:	5d                                              	pop    rbp
 101b177:	5b                                              	pop    rbx
 101b178:	c3                                              	ret
	...

000000000101c000 <native_28>:
 101c000:	53                                              	push   rbx
 101c001:	55                                              	push   rbp
 101c002:	41 54                                           	push   r12
 101c004:	41 55                                           	push   r13
 101c006:	41 56                                           	push   r14
 101c008:	41 57                                           	push   r15
 101c00a:	57                                              	push   rdi
 101c00b:	49 89 ff                                        	mov    r15,rdi
 101c00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101c017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101c01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101c026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101c02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101c035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101c03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101c044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101c04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101c051:	9d                                              	popf
 101c052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101c058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101c061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101c064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101c068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101c06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101c070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101c074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101c078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101c07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101c080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101c084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101c088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101c08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101c090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101c094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101c098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101c09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101c0a3 <native_pc_28>

000000000101c0a3 <native_pc_28>:
 101c0a3:	4c 8d 3d 05 00 00 00                            	lea    r15,[rip+0x5]        # 101c0af <native_pc_28+0xc>
 101c0aa:	41 ff d7                                        	call   r15
 101c0ad:	eb 04                                           	jmp    101c0b3 <outer_done_28>
 101c0af:	48 01 da                                        	add    rdx,rbx
 101c0b2:	c3                                              	ret

000000000101c0b3 <outer_done_28>:
 101c0b3:	eb 00                                           	jmp    101c0b5 <native_next_28>

000000000101c0b5 <native_next_28>:
 101c0b5:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101c0ba:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101c0c1 <native_next_28+0xc>
 101c0c1:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101c0c7:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101c0cd:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101c0d3:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101c0d9:	41 57                                           	push   r15
 101c0db:	9c                                              	pushf
 101c0dc:	50                                              	push   rax
 101c0dd:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101c0e2:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101c0ea:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101c0f2:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101c0fa:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101c102:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101c106:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101c10a:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101c10e:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101c112:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101c116:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101c11a:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101c11e:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101c122:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101c126:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101c12a:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101c12e:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101c132:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101c136:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101c13b:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101c142 <native_next_28+0x8d>
 101c142:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101c146:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101c14a:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101c14d:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101c152:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101c159:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101c15e:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101c162:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101c16a:	48 83 c4 18                                     	add    rsp,0x18
 101c16e:	5f                                              	pop    rdi
 101c16f:	41 5f                                           	pop    r15
 101c171:	41 5e                                           	pop    r14
 101c173:	41 5d                                           	pop    r13
 101c175:	41 5c                                           	pop    r12
 101c177:	5d                                              	pop    rbp
 101c178:	5b                                              	pop    rbx
 101c179:	c3                                              	ret
	...

000000000101d000 <native_29>:
 101d000:	53                                              	push   rbx
 101d001:	55                                              	push   rbp
 101d002:	41 54                                           	push   r12
 101d004:	41 55                                           	push   r13
 101d006:	41 56                                           	push   r14
 101d008:	41 57                                           	push   r15
 101d00a:	57                                              	push   rdi
 101d00b:	49 89 ff                                        	mov    r15,rdi
 101d00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101d017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101d01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101d026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101d02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101d035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101d03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101d044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101d04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101d051:	9d                                              	popf
 101d052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101d058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101d061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101d064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101d068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101d06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101d070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101d074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101d078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101d07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101d080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101d084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101d088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101d08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101d090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101d094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101d098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101d09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101d0a3 <native_pc_29>

000000000101d0a3 <native_pc_29>:
 101d0a3:	4c 8d 3d 03 00 00 00                            	lea    r15,[rip+0x3]        # 101d0ad <native_pc_29+0xa>
 101d0aa:	41 ff e7                                        	jmp    r15
 101d0ad:	48 01 da                                        	add    rdx,rbx
 101d0b0:	eb 00                                           	jmp    101d0b2 <outer_done_29>

000000000101d0b2 <outer_done_29>:
 101d0b2:	eb 00                                           	jmp    101d0b4 <native_next_29>

000000000101d0b4 <native_next_29>:
 101d0b4:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101d0b9:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101d0c0 <native_next_29+0xc>
 101d0c0:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101d0c6:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101d0cc:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101d0d2:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101d0d8:	41 57                                           	push   r15
 101d0da:	9c                                              	pushf
 101d0db:	50                                              	push   rax
 101d0dc:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101d0e1:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101d0e9:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101d0f1:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101d0f9:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101d101:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101d105:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101d109:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101d10d:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101d111:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101d115:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101d119:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101d11d:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101d121:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101d125:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101d129:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101d12d:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101d131:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101d135:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101d13a:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101d141 <native_next_29+0x8d>
 101d141:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101d145:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101d149:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101d14c:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101d151:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101d158:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101d15d:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101d161:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101d169:	48 83 c4 18                                     	add    rsp,0x18
 101d16d:	5f                                              	pop    rdi
 101d16e:	41 5f                                           	pop    r15
 101d170:	41 5e                                           	pop    r14
 101d172:	41 5d                                           	pop    r13
 101d174:	41 5c                                           	pop    r12
 101d176:	5d                                              	pop    rbp
 101d177:	5b                                              	pop    rbx
 101d178:	c3                                              	ret
	...

000000000101e000 <native_30>:
 101e000:	53                                              	push   rbx
 101e001:	55                                              	push   rbp
 101e002:	41 54                                           	push   r12
 101e004:	41 55                                           	push   r13
 101e006:	41 56                                           	push   r14
 101e008:	41 57                                           	push   r15
 101e00a:	57                                              	push   rdi
 101e00b:	49 89 ff                                        	mov    r15,rdi
 101e00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101e017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101e01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101e026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101e02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101e035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101e03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101e044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101e04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101e051:	9d                                              	popf
 101e052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101e058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101e061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101e064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101e068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101e06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101e070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101e074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101e078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101e07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101e080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101e084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101e088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101e08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101e090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101e094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101e098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101e09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101e0a3 <native_pc_30>

000000000101e0a3 <native_pc_30>:
 101e0a3:	f6 c2 01                                        	test   dl,0x1
 101e0a6:	74 09                                           	je     101e0b1 <native_pc_30+0xe>
 101e0a8:	4c 8d 15 0e 00 00 00                            	lea    r10,[rip+0xe]        # 101e0bd <native_pc_30+0x1a>
 101e0af:	eb 07                                           	jmp    101e0b8 <native_pc_30+0x15>
 101e0b1:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 101e0c1 <native_pc_30+0x1e>
 101e0b8:	41 ff d2                                        	call   r10
 101e0bb:	eb 08                                           	jmp    101e0c5 <outer_done_30>
 101e0bd:	48 01 d8                                        	add    rax,rbx
 101e0c0:	c3                                              	ret
 101e0c1:	48 29 d8                                        	sub    rax,rbx
 101e0c4:	c3                                              	ret

000000000101e0c5 <outer_done_30>:
 101e0c5:	eb 00                                           	jmp    101e0c7 <native_next_30>

000000000101e0c7 <native_next_30>:
 101e0c7:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101e0cc:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101e0d3 <native_next_30+0xc>
 101e0d3:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101e0d9:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101e0df:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101e0e5:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101e0eb:	41 57                                           	push   r15
 101e0ed:	9c                                              	pushf
 101e0ee:	50                                              	push   rax
 101e0ef:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101e0f4:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101e0fc:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101e104:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101e10c:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101e114:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101e118:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101e11c:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101e120:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101e124:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101e128:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101e12c:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101e130:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101e134:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101e138:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101e13c:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101e140:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101e144:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101e148:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101e14d:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101e154 <native_next_30+0x8d>
 101e154:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101e158:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101e15c:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101e15f:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101e164:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101e16b:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101e170:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101e174:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101e17c:	48 83 c4 18                                     	add    rsp,0x18
 101e180:	5f                                              	pop    rdi
 101e181:	41 5f                                           	pop    r15
 101e183:	41 5e                                           	pop    r14
 101e185:	41 5d                                           	pop    r13
 101e187:	41 5c                                           	pop    r12
 101e189:	5d                                              	pop    rbp
 101e18a:	5b                                              	pop    rbx
 101e18b:	c3                                              	ret
	...

000000000101f000 <native_31>:
 101f000:	53                                              	push   rbx
 101f001:	55                                              	push   rbp
 101f002:	41 54                                           	push   r12
 101f004:	41 55                                           	push   r13
 101f006:	41 56                                           	push   r14
 101f008:	41 57                                           	push   r15
 101f00a:	57                                              	push   rdi
 101f00b:	49 89 ff                                        	mov    r15,rdi
 101f00e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 101f017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 101f01d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 101f026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 101f02c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 101f035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 101f03b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 101f044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101f04a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 101f051:	9d                                              	popf
 101f052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 101f058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 101f061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 101f064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 101f068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 101f06c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 101f070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 101f074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 101f078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 101f07c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 101f080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 101f084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 101f088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 101f08c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 101f090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 101f094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 101f098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 101f09c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 101f0a3 <native_pc_31>

000000000101f0a3 <native_pc_31>:
 101f0a3:	f6 c2 01                                        	test   dl,0x1
 101f0a6:	74 09                                           	je     101f0b1 <native_pc_31+0xe>
 101f0a8:	4c 8d 15 0f 00 00 00                            	lea    r10,[rip+0xf]        # 101f0be <native_pc_31+0x1b>
 101f0af:	eb 07                                           	jmp    101f0b8 <native_pc_31+0x15>
 101f0b1:	4c 8d 15 0b 00 00 00                            	lea    r10,[rip+0xb]        # 101f0c3 <native_pc_31+0x20>
 101f0b8:	4d 89 d3                                        	mov    r11,r10
 101f0bb:	41 ff e3                                        	jmp    r11
 101f0be:	48 01 d8                                        	add    rax,rbx
 101f0c1:	eb 05                                           	jmp    101f0c8 <outer_done_31>
 101f0c3:	48 29 d8                                        	sub    rax,rbx
 101f0c6:	eb 00                                           	jmp    101f0c8 <outer_done_31>

000000000101f0c8 <outer_done_31>:
 101f0c8:	eb 00                                           	jmp    101f0ca <native_next_31>

000000000101f0ca <native_next_31>:
 101f0ca:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 101f0cf:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 101f0d6 <native_next_31+0xc>
 101f0d6:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 101f0dc:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 101f0e2:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 101f0e8:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 101f0ee:	41 57                                           	push   r15
 101f0f0:	9c                                              	pushf
 101f0f1:	50                                              	push   rax
 101f0f2:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 101f0f7:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 101f0ff:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 101f107:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 101f10f:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 101f117:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 101f11b:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 101f11f:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 101f123:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 101f127:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 101f12b:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 101f12f:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 101f133:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 101f137:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 101f13b:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 101f13f:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 101f143:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 101f147:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 101f14b:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 101f150:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 101f157 <native_next_31+0x8d>
 101f157:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 101f15b:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 101f15f:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 101f162:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 101f167:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 101f16e:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 101f173:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 101f177:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 101f17f:	48 83 c4 18                                     	add    rsp,0x18
 101f183:	5f                                              	pop    rdi
 101f184:	41 5f                                           	pop    r15
 101f186:	41 5e                                           	pop    r14
 101f188:	41 5d                                           	pop    r13
 101f18a:	41 5c                                           	pop    r12
 101f18c:	5d                                              	pop    rbp
 101f18d:	5b                                              	pop    rbx
 101f18e:	c3                                              	ret
	...

0000000001020000 <native_32>:
 1020000:	53                                              	push   rbx
 1020001:	55                                              	push   rbp
 1020002:	41 54                                           	push   r12
 1020004:	41 55                                           	push   r13
 1020006:	41 56                                           	push   r14
 1020008:	41 57                                           	push   r15
 102000a:	57                                              	push   rdi
 102000b:	49 89 ff                                        	mov    r15,rdi
 102000e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1020017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 102001d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1020026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 102002c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1020035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 102003b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1020044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 102004a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1020051:	9d                                              	popf
 1020052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1020058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1020061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1020064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1020068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 102006c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1020070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1020074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1020078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 102007c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1020080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1020084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1020088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 102008c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1020090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1020094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1020098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 102009c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10200a3 <native_pc_32>

00000000010200a3 <native_pc_32>:
 10200a3:	e8 02 00 00 00                                  	call   10200aa <native_pc_32+0x7>
 10200a8:	eb 0d                                           	jmp    10200b7 <outer_done_32>
 10200aa:	e8 04 00 00 00                                  	call   10200b3 <native_pc_32+0x10>
 10200af:	48 01 d8                                        	add    rax,rbx
 10200b2:	c3                                              	ret
 10200b3:	48 01 ca                                        	add    rdx,rcx
 10200b6:	c3                                              	ret

00000000010200b7 <outer_done_32>:
 10200b7:	eb 00                                           	jmp    10200b9 <native_next_32>

00000000010200b9 <native_next_32>:
 10200b9:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10200be:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10200c5 <native_next_32+0xc>
 10200c5:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10200cb:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10200d1:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10200d7:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10200dd:	41 57                                           	push   r15
 10200df:	9c                                              	pushf
 10200e0:	50                                              	push   rax
 10200e1:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10200e6:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10200ee:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10200f6:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10200fe:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1020106:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 102010a:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 102010e:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 1020112:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1020116:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 102011a:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 102011e:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 1020122:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1020126:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 102012a:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 102012e:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 1020132:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1020136:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 102013a:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 102013f:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1020146 <native_next_32+0x8d>
 1020146:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 102014a:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 102014e:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 1020151:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1020156:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 102015d:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 1020162:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1020166:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 102016e:	48 83 c4 18                                     	add    rsp,0x18
 1020172:	5f                                              	pop    rdi
 1020173:	41 5f                                           	pop    r15
 1020175:	41 5e                                           	pop    r14
 1020177:	41 5d                                           	pop    r13
 1020179:	41 5c                                           	pop    r12
 102017b:	5d                                              	pop    rbp
 102017c:	5b                                              	pop    rbx
 102017d:	c3                                              	ret
	...

0000000001021000 <native_33>:
 1021000:	53                                              	push   rbx
 1021001:	55                                              	push   rbp
 1021002:	41 54                                           	push   r12
 1021004:	41 55                                           	push   r13
 1021006:	41 56                                           	push   r14
 1021008:	41 57                                           	push   r15
 102100a:	57                                              	push   rdi
 102100b:	49 89 ff                                        	mov    r15,rdi
 102100e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1021017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 102101d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1021026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 102102c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1021035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 102103b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1021044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 102104a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1021051:	9d                                              	popf
 1021052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1021058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1021061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1021064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1021068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 102106c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1021070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1021074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1021078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 102107c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1021080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1021084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1021088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 102108c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1021090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1021094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1021098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 102109c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10210a3 <native_pc_33>

00000000010210a3 <native_pc_33>:
 10210a3:	4c 8d 15 05 00 00 00                            	lea    r10,[rip+0x5]        # 10210af <native_pc_33+0xc>
 10210aa:	41 ff d2                                        	call   r10
 10210ad:	eb 12                                           	jmp    10210c1 <outer_done_33>
 10210af:	4c 8d 1d 07 00 00 00                            	lea    r11,[rip+0x7]        # 10210bd <native_pc_33+0x1a>
 10210b6:	41 ff d3                                        	call   r11
 10210b9:	48 01 d8                                        	add    rax,rbx
 10210bc:	c3                                              	ret
 10210bd:	48 01 ca                                        	add    rdx,rcx
 10210c0:	c3                                              	ret

00000000010210c1 <outer_done_33>:
 10210c1:	eb 00                                           	jmp    10210c3 <native_next_33>

00000000010210c3 <native_next_33>:
 10210c3:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10210c8:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10210cf <native_next_33+0xc>
 10210cf:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10210d5:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10210db:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10210e1:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10210e7:	41 57                                           	push   r15
 10210e9:	9c                                              	pushf
 10210ea:	50                                              	push   rax
 10210eb:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10210f0:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10210f8:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 1021100:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 1021108:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 1021110:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1021114:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1021118:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 102111c:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 1021120:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1021124:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1021128:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 102112c:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 1021130:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1021134:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1021138:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 102113c:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 1021140:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1021144:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1021149:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 1021150 <native_next_33+0x8d>
 1021150:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1021154:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1021158:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 102115b:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 1021160:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1021167:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 102116c:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 1021170:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1021178:	48 83 c4 18                                     	add    rsp,0x18
 102117c:	5f                                              	pop    rdi
 102117d:	41 5f                                           	pop    r15
 102117f:	41 5e                                           	pop    r14
 1021181:	41 5d                                           	pop    r13
 1021183:	41 5c                                           	pop    r12
 1021185:	5d                                              	pop    rbp
 1021186:	5b                                              	pop    rbx
 1021187:	c3                                              	ret
	...

0000000001022000 <native_34>:
 1022000:	53                                              	push   rbx
 1022001:	55                                              	push   rbp
 1022002:	41 54                                           	push   r12
 1022004:	41 55                                           	push   r13
 1022006:	41 56                                           	push   r14
 1022008:	41 57                                           	push   r15
 102200a:	57                                              	push   rdi
 102200b:	49 89 ff                                        	mov    r15,rdi
 102200e:	f3 41 0f 6f 8f 18 01 00 00                      	movdqu xmm1,XMMWORD PTR [r15+0x118]
 1022017:	f3 0f 7f 4c 24 c0                               	movdqu XMMWORD PTR [rsp-0x40],xmm1
 102201d:	f3 41 0f 6f 97 28 01 00 00                      	movdqu xmm2,XMMWORD PTR [r15+0x128]
 1022026:	f3 0f 7f 54 24 d0                               	movdqu XMMWORD PTR [rsp-0x30],xmm2
 102202c:	f3 41 0f 6f 9f 38 01 00 00                      	movdqu xmm3,XMMWORD PTR [r15+0x138]
 1022035:	f3 0f 7f 5c 24 e0                               	movdqu XMMWORD PTR [rsp-0x20],xmm3
 102203b:	f3 41 0f 6f a7 48 01 00 00                      	movdqu xmm4,XMMWORD PTR [r15+0x148]
 1022044:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 102204a:	41 ff b7 00 01 00 00                            	push   QWORD PTR [r15+0x100]
 1022051:	9d                                              	popf
 1022052:	f3 0f 7f 64 24 f0                               	movdqu XMMWORD PTR [rsp-0x10],xmm4
 1022058:	f3 41 0f 6f 87 08 01 00 00                      	movdqu xmm0,XMMWORD PTR [r15+0x108]
 1022061:	49 8b 07                                        	mov    rax,QWORD PTR [r15]
 1022064:	49 8b 4f 08                                     	mov    rcx,QWORD PTR [r15+0x8]
 1022068:	49 8b 57 10                                     	mov    rdx,QWORD PTR [r15+0x10]
 102206c:	49 8b 5f 18                                     	mov    rbx,QWORD PTR [r15+0x18]
 1022070:	49 8b 6f 28                                     	mov    rbp,QWORD PTR [r15+0x28]
 1022074:	49 8b 77 30                                     	mov    rsi,QWORD PTR [r15+0x30]
 1022078:	49 8b 7f 38                                     	mov    rdi,QWORD PTR [r15+0x38]
 102207c:	4d 8b 47 40                                     	mov    r8,QWORD PTR [r15+0x40]
 1022080:	4d 8b 4f 48                                     	mov    r9,QWORD PTR [r15+0x48]
 1022084:	4d 8b 57 50                                     	mov    r10,QWORD PTR [r15+0x50]
 1022088:	4d 8b 5f 58                                     	mov    r11,QWORD PTR [r15+0x58]
 102208c:	4d 8b 67 60                                     	mov    r12,QWORD PTR [r15+0x60]
 1022090:	4d 8b 6f 68                                     	mov    r13,QWORD PTR [r15+0x68]
 1022094:	4d 8b 77 70                                     	mov    r14,QWORD PTR [r15+0x70]
 1022098:	4d 8b 7f 78                                     	mov    r15,QWORD PTR [r15+0x78]
 102209c:	48 89 25 00 00 00 00                            	mov    QWORD PTR [rip+0x0],rsp        # 10220a3 <native_pc_34>

00000000010220a3 <native_pc_34>:
 10220a3:	e8 02 00 00 00                                  	call   10220aa <native_pc_34+0x7>
 10220a8:	eb 05                                           	jmp    10220af <outer_done_34>
 10220aa:	48 8b 04 24                                     	mov    rax,QWORD PTR [rsp]
 10220ae:	c3                                              	ret

00000000010220af <outer_done_34>:
 10220af:	eb 00                                           	jmp    10220b1 <native_next_34>

00000000010220b1 <native_next_34>:
 10220b1:	66 48 0f 6e ec                                  	movq   xmm5,rsp
 10220b6:	48 8b 25 00 00 00 00                            	mov    rsp,QWORD PTR [rip+0x0]        # 10220bd <native_next_34+0xc>
 10220bd:	f3 0f 6f 4c 24 c0                               	movdqu xmm1,XMMWORD PTR [rsp-0x40]
 10220c3:	f3 0f 6f 54 24 d0                               	movdqu xmm2,XMMWORD PTR [rsp-0x30]
 10220c9:	f3 0f 6f 5c 24 e0                               	movdqu xmm3,XMMWORD PTR [rsp-0x20]
 10220cf:	f3 0f 6f 64 24 f0                               	movdqu xmm4,XMMWORD PTR [rsp-0x10]
 10220d5:	41 57                                           	push   r15
 10220d7:	9c                                              	pushf
 10220d8:	50                                              	push   rax
 10220d9:	48 8b 44 24 18                                  	mov    rax,QWORD PTR [rsp+0x18]
 10220de:	f3 0f 7f 88 18 01 00 00                         	movdqu XMMWORD PTR [rax+0x118],xmm1
 10220e6:	f3 0f 7f 90 28 01 00 00                         	movdqu XMMWORD PTR [rax+0x128],xmm2
 10220ee:	f3 0f 7f 98 38 01 00 00                         	movdqu XMMWORD PTR [rax+0x138],xmm3
 10220f6:	f3 0f 7f a0 48 01 00 00                         	movdqu XMMWORD PTR [rax+0x148],xmm4
 10220fe:	48 89 48 08                                     	mov    QWORD PTR [rax+0x8],rcx
 1022102:	48 89 50 10                                     	mov    QWORD PTR [rax+0x10],rdx
 1022106:	48 89 58 18                                     	mov    QWORD PTR [rax+0x18],rbx
 102210a:	48 89 68 28                                     	mov    QWORD PTR [rax+0x28],rbp
 102210e:	48 89 70 30                                     	mov    QWORD PTR [rax+0x30],rsi
 1022112:	48 89 78 38                                     	mov    QWORD PTR [rax+0x38],rdi
 1022116:	4c 89 40 40                                     	mov    QWORD PTR [rax+0x40],r8
 102211a:	4c 89 48 48                                     	mov    QWORD PTR [rax+0x48],r9
 102211e:	4c 89 50 50                                     	mov    QWORD PTR [rax+0x50],r10
 1022122:	4c 89 58 58                                     	mov    QWORD PTR [rax+0x58],r11
 1022126:	4c 89 60 60                                     	mov    QWORD PTR [rax+0x60],r12
 102212a:	4c 89 68 68                                     	mov    QWORD PTR [rax+0x68],r13
 102212e:	4c 89 70 70                                     	mov    QWORD PTR [rax+0x70],r14
 1022132:	66 48 0f 7e ea                                  	movq   rdx,xmm5
 1022137:	48 2b 15 00 00 00 00                            	sub    rdx,QWORD PTR [rip+0x0]        # 102213e <native_next_34+0x8d>
 102213e:	48 89 50 20                                     	mov    QWORD PTR [rax+0x20],rdx
 1022142:	48 8b 14 24                                     	mov    rdx,QWORD PTR [rsp]
 1022146:	48 89 10                                        	mov    QWORD PTR [rax],rdx
 1022149:	48 8b 54 24 08                                  	mov    rdx,QWORD PTR [rsp+0x8]
 102214e:	48 89 90 00 01 00 00                            	mov    QWORD PTR [rax+0x100],rdx
 1022155:	48 8b 54 24 10                                  	mov    rdx,QWORD PTR [rsp+0x10]
 102215a:	48 89 50 78                                     	mov    QWORD PTR [rax+0x78],rdx
 102215e:	f3 0f 7f 80 08 01 00 00                         	movdqu XMMWORD PTR [rax+0x108],xmm0
 1022166:	48 83 c4 18                                     	add    rsp,0x18
 102216a:	5f                                              	pop    rdi
 102216b:	41 5f                                           	pop    r15
 102216d:	41 5e                                           	pop    r14
 102216f:	41 5d                                           	pop    r13
 1022171:	41 5c                                           	pop    r12
 1022173:	5d                                              	pop    rbp
 1022174:	5b                                              	pop    rbx
 1022175:	c3                                              	ret
