#include "../driver.h"
#include <stdlib.h>
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/fidelity/build-x86-control/snapshot/kprog/x86/x86_sim_local_bpf.h"
extern uint64_t native_stack_base;
extern void native_0(struct state *);
extern unsigned char native_pc_0,native_next_0;
static void sim_0(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10000a3:;
	/* 0x10000a3: lea    rax,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x10000aeULL);
x86_l_10000aa:;
	/* 0x10000aa: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10000aeULL: X86_SIM_X86_CALL(x86_l_10000ae, 0x10000acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10000ac:;
	/* 0x10000ac: jmp    10000b2 <outer_done_0> */
	X86_SIM_X86_JMP(0x10000ac, 0x10000b2, x86_l_10000b2);
x86_l_10000ae:;
	/* 0x10000ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10000b1:;
	/* 0x10000b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10000b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10000acULL: goto x86_l_10000ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_1(struct state *);
extern unsigned char native_pc_1,native_next_1;
static void sim_1(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10010a3:;
	/* 0x10010a3: lea    rax,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x10010acULL);
x86_l_10010aa:;
	/* 0x10010aa: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10010acULL: goto x86_l_10010ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10010ac:;
	/* 0x10010ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10010af:;
	/* 0x10010af: jmp    10010b1 <outer_done_1> */
	X86_SIM_X86_JMP(0x10010af, 0x10010b1, x86_l_10010b1);
x86_l_10010b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_2(struct state *);
extern unsigned char native_pc_2,native_next_2;
static void sim_2(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10020a3:;
	/* 0x10020a3: lea    rcx,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RCX, 0x10020aeULL);
x86_l_10020aa:;
	/* 0x10020aa: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10020aeULL: X86_SIM_X86_CALL(x86_l_10020ae, 0x10020acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10020ac:;
	/* 0x10020ac: jmp    10020b2 <outer_done_2> */
	X86_SIM_X86_JMP(0x10020ac, 0x10020b2, x86_l_10020b2);
x86_l_10020ae:;
	/* 0x10020ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10020b1:;
	/* 0x10020b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10020b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10020acULL: goto x86_l_10020ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_3(struct state *);
extern unsigned char native_pc_3,native_next_3;
static void sim_3(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10030a3:;
	/* 0x10030a3: lea    rcx,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RCX, 0x10030acULL);
x86_l_10030aa:;
	/* 0x10030aa: jmp    rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10030acULL: goto x86_l_10030ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10030ac:;
	/* 0x10030ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10030af:;
	/* 0x10030af: jmp    10030b1 <outer_done_3> */
	X86_SIM_X86_JMP(0x10030af, 0x10030b1, x86_l_10030b1);
x86_l_10030b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_4(struct state *);
extern unsigned char native_pc_4,native_next_4;
static void sim_4(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10040a3:;
	/* 0x10040a3: lea    rdx,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10040aeULL);
x86_l_10040aa:;
	/* 0x10040aa: call   rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10040aeULL: X86_SIM_X86_CALL(x86_l_10040ae, 0x10040acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10040ac:;
	/* 0x10040ac: jmp    10040b2 <outer_done_4> */
	X86_SIM_X86_JMP(0x10040ac, 0x10040b2, x86_l_10040b2);
x86_l_10040ae:;
	/* 0x10040ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10040b1:;
	/* 0x10040b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10040b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10040acULL: goto x86_l_10040ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_5(struct state *);
extern unsigned char native_pc_5,native_next_5;
static void sim_5(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10050a3:;
	/* 0x10050a3: lea    rdx,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10050acULL);
x86_l_10050aa:;
	/* 0x10050aa: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10050acULL: goto x86_l_10050ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10050ac:;
	/* 0x10050ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10050af:;
	/* 0x10050af: jmp    10050b1 <outer_done_5> */
	X86_SIM_X86_JMP(0x10050af, 0x10050b1, x86_l_10050b1);
x86_l_10050b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_6(struct state *);
extern unsigned char native_pc_6,native_next_6;
static void sim_6(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10060a3:;
	/* 0x10060a3: lea    rbx,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RBX, 0x10060aeULL);
x86_l_10060aa:;
	/* 0x10060aa: call   rbx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RBX);
		switch (X86_SIM_L_REG_TAG(X86_RBX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10060aeULL: X86_SIM_X86_CALL(x86_l_10060ae, 0x10060acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10060ac:;
	/* 0x10060ac: jmp    10060b2 <outer_done_6> */
	X86_SIM_X86_JMP(0x10060ac, 0x10060b2, x86_l_10060b2);
x86_l_10060ae:;
	/* 0x10060ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10060b1:;
	/* 0x10060b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10060b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10060acULL: goto x86_l_10060ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_7(struct state *);
extern unsigned char native_pc_7,native_next_7;
static void sim_7(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10070a3:;
	/* 0x10070a3: lea    rbx,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RBX, 0x10070acULL);
x86_l_10070aa:;
	/* 0x10070aa: jmp    rbx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RBX);
		switch (X86_SIM_L_REG_TAG(X86_RBX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10070acULL: goto x86_l_10070ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10070ac:;
	/* 0x10070ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10070af:;
	/* 0x10070af: jmp    10070b1 <outer_done_7> */
	X86_SIM_X86_JMP(0x10070af, 0x10070b1, x86_l_10070b1);
x86_l_10070b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_8(struct state *);
extern unsigned char native_pc_8,native_next_8;
static void sim_8(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10080a3:;
	/* 0x10080a3: lea    rbp,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RBP, 0x10080aeULL);
x86_l_10080aa:;
	/* 0x10080aa: call   rbp */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RBP);
		switch (X86_SIM_L_REG_TAG(X86_RBP)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10080aeULL: X86_SIM_X86_CALL(x86_l_10080ae, 0x10080acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10080ac:;
	/* 0x10080ac: jmp    10080b2 <outer_done_8> */
	X86_SIM_X86_JMP(0x10080ac, 0x10080b2, x86_l_10080b2);
x86_l_10080ae:;
	/* 0x10080ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10080b1:;
	/* 0x10080b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10080b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10080acULL: goto x86_l_10080ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_9(struct state *);
extern unsigned char native_pc_9,native_next_9;
static void sim_9(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10090a3:;
	/* 0x10090a3: lea    rbp,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RBP, 0x10090acULL);
x86_l_10090aa:;
	/* 0x10090aa: jmp    rbp */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RBP);
		switch (X86_SIM_L_REG_TAG(X86_RBP)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10090acULL: goto x86_l_10090ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10090ac:;
	/* 0x10090ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10090af:;
	/* 0x10090af: jmp    10090b1 <outer_done_9> */
	X86_SIM_X86_JMP(0x10090af, 0x10090b1, x86_l_10090b1);
x86_l_10090b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_10(struct state *);
extern unsigned char native_pc_10,native_next_10;
static void sim_10(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100a0a3:;
	/* 0x100a0a3: lea    rsi,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x100a0aeULL);
x86_l_100a0aa:;
	/* 0x100a0aa: call   rsi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RSI);
		switch (X86_SIM_L_REG_TAG(X86_RSI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100a0aeULL: X86_SIM_X86_CALL(x86_l_100a0ae, 0x100a0acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100a0ac:;
	/* 0x100a0ac: jmp    100a0b2 <outer_done_10> */
	X86_SIM_X86_JMP(0x100a0ac, 0x100a0b2, x86_l_100a0b2);
x86_l_100a0ae:;
	/* 0x100a0ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100a0b1:;
	/* 0x100a0b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_100a0b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x100a0acULL: goto x86_l_100a0ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_11(struct state *);
extern unsigned char native_pc_11,native_next_11;
static void sim_11(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100b0a3:;
	/* 0x100b0a3: lea    rsi,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RSI, 0x100b0acULL);
x86_l_100b0aa:;
	/* 0x100b0aa: jmp    rsi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RSI);
		switch (X86_SIM_L_REG_TAG(X86_RSI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100b0acULL: goto x86_l_100b0ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100b0ac:;
	/* 0x100b0ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100b0af:;
	/* 0x100b0af: jmp    100b0b1 <outer_done_11> */
	X86_SIM_X86_JMP(0x100b0af, 0x100b0b1, x86_l_100b0b1);
x86_l_100b0b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_12(struct state *);
extern unsigned char native_pc_12,native_next_12;
static void sim_12(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100c0a3:;
	/* 0x100c0a3: lea    rdi,[rip+0x4] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x100c0aeULL);
x86_l_100c0aa:;
	/* 0x100c0aa: call   rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100c0aeULL: X86_SIM_X86_CALL(x86_l_100c0ae, 0x100c0acULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100c0ac:;
	/* 0x100c0ac: jmp    100c0b2 <outer_done_12> */
	X86_SIM_X86_JMP(0x100c0ac, 0x100c0b2, x86_l_100c0b2);
x86_l_100c0ae:;
	/* 0x100c0ae: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100c0b1:;
	/* 0x100c0b1: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_100c0b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x100c0acULL: goto x86_l_100c0ac;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_13(struct state *);
extern unsigned char native_pc_13,native_next_13;
static void sim_13(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100d0a3:;
	/* 0x100d0a3: lea    rdi,[rip+0x2] */
	X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x100d0acULL);
x86_l_100d0aa:;
	/* 0x100d0aa: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100d0acULL: goto x86_l_100d0ac;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100d0ac:;
	/* 0x100d0ac: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100d0af:;
	/* 0x100d0af: jmp    100d0b1 <outer_done_13> */
	X86_SIM_X86_JMP(0x100d0af, 0x100d0b1, x86_l_100d0b1);
x86_l_100d0b1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_14(struct state *);
extern unsigned char native_pc_14,native_next_14;
static void sim_14(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100e0a3:;
	/* 0x100e0a3: lea    r8,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R8, 0x100e0afULL);
x86_l_100e0aa:;
	/* 0x100e0aa: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100e0afULL: X86_SIM_X86_CALL(x86_l_100e0af, 0x100e0adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100e0ad:;
	/* 0x100e0ad: jmp    100e0b3 <outer_done_14> */
	X86_SIM_X86_JMP(0x100e0ad, 0x100e0b3, x86_l_100e0b3);
x86_l_100e0af:;
	/* 0x100e0af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100e0b2:;
	/* 0x100e0b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_100e0b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x100e0adULL: goto x86_l_100e0ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_15(struct state *);
extern unsigned char native_pc_15,native_next_15;
static void sim_15(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_100f0a3:;
	/* 0x100f0a3: lea    r8,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R8, 0x100f0adULL);
x86_l_100f0aa:;
	/* 0x100f0aa: jmp    r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x100f0adULL: goto x86_l_100f0ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100f0ad:;
	/* 0x100f0ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_100f0b0:;
	/* 0x100f0b0: jmp    100f0b2 <outer_done_15> */
	X86_SIM_X86_JMP(0x100f0b0, 0x100f0b2, x86_l_100f0b2);
x86_l_100f0b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_16(struct state *);
extern unsigned char native_pc_16,native_next_16;
static void sim_16(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10100a3:;
	/* 0x10100a3: lea    r9,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x10100afULL);
x86_l_10100aa:;
	/* 0x10100aa: call   r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10100afULL: X86_SIM_X86_CALL(x86_l_10100af, 0x10100adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10100ad:;
	/* 0x10100ad: jmp    10100b3 <outer_done_16> */
	X86_SIM_X86_JMP(0x10100ad, 0x10100b3, x86_l_10100b3);
x86_l_10100af:;
	/* 0x10100af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10100b2:;
	/* 0x10100b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10100b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10100adULL: goto x86_l_10100ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_17(struct state *);
extern unsigned char native_pc_17,native_next_17;
static void sim_17(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10110a3:;
	/* 0x10110a3: lea    r9,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x10110adULL);
x86_l_10110aa:;
	/* 0x10110aa: jmp    r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10110adULL: goto x86_l_10110ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10110ad:;
	/* 0x10110ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10110b0:;
	/* 0x10110b0: jmp    10110b2 <outer_done_17> */
	X86_SIM_X86_JMP(0x10110b0, 0x10110b2, x86_l_10110b2);
x86_l_10110b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_18(struct state *);
extern unsigned char native_pc_18,native_next_18;
static void sim_18(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10120a3:;
	/* 0x10120a3: lea    r10,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x10120afULL);
x86_l_10120aa:;
	/* 0x10120aa: call   r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10120afULL: X86_SIM_X86_CALL(x86_l_10120af, 0x10120adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10120ad:;
	/* 0x10120ad: jmp    10120b3 <outer_done_18> */
	X86_SIM_X86_JMP(0x10120ad, 0x10120b3, x86_l_10120b3);
x86_l_10120af:;
	/* 0x10120af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10120b2:;
	/* 0x10120b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10120b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10120adULL: goto x86_l_10120ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_19(struct state *);
extern unsigned char native_pc_19,native_next_19;
static void sim_19(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10130a3:;
	/* 0x10130a3: lea    r10,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x10130adULL);
x86_l_10130aa:;
	/* 0x10130aa: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10130adULL: goto x86_l_10130ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10130ad:;
	/* 0x10130ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10130b0:;
	/* 0x10130b0: jmp    10130b2 <outer_done_19> */
	X86_SIM_X86_JMP(0x10130b0, 0x10130b2, x86_l_10130b2);
x86_l_10130b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_20(struct state *);
extern unsigned char native_pc_20,native_next_20;
static void sim_20(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10140a3:;
	/* 0x10140a3: lea    r11,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x10140afULL);
x86_l_10140aa:;
	/* 0x10140aa: call   r11 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10140afULL: X86_SIM_X86_CALL(x86_l_10140af, 0x10140adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10140ad:;
	/* 0x10140ad: jmp    10140b3 <outer_done_20> */
	X86_SIM_X86_JMP(0x10140ad, 0x10140b3, x86_l_10140b3);
x86_l_10140af:;
	/* 0x10140af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10140b2:;
	/* 0x10140b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10140b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10140adULL: goto x86_l_10140ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_21(struct state *);
extern unsigned char native_pc_21,native_next_21;
static void sim_21(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10150a3:;
	/* 0x10150a3: lea    r11,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x10150adULL);
x86_l_10150aa:;
	/* 0x10150aa: jmp    r11 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10150adULL: goto x86_l_10150ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10150ad:;
	/* 0x10150ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10150b0:;
	/* 0x10150b0: jmp    10150b2 <outer_done_21> */
	X86_SIM_X86_JMP(0x10150b0, 0x10150b2, x86_l_10150b2);
x86_l_10150b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_22(struct state *);
extern unsigned char native_pc_22,native_next_22;
static void sim_22(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10160a3:;
	/* 0x10160a3: lea    r12,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R12, 0x10160afULL);
x86_l_10160aa:;
	/* 0x10160aa: call   r12 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R12);
		switch (X86_SIM_L_REG_TAG(X86_R12)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10160afULL: X86_SIM_X86_CALL(x86_l_10160af, 0x10160adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10160ad:;
	/* 0x10160ad: jmp    10160b3 <outer_done_22> */
	X86_SIM_X86_JMP(0x10160ad, 0x10160b3, x86_l_10160b3);
x86_l_10160af:;
	/* 0x10160af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10160b2:;
	/* 0x10160b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10160b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10160adULL: goto x86_l_10160ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_23(struct state *);
extern unsigned char native_pc_23,native_next_23;
static void sim_23(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10170a3:;
	/* 0x10170a3: lea    r12,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R12, 0x10170adULL);
x86_l_10170aa:;
	/* 0x10170aa: jmp    r12 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R12);
		switch (X86_SIM_L_REG_TAG(X86_R12)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10170adULL: goto x86_l_10170ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10170ad:;
	/* 0x10170ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10170b0:;
	/* 0x10170b0: jmp    10170b2 <outer_done_23> */
	X86_SIM_X86_JMP(0x10170b0, 0x10170b2, x86_l_10170b2);
x86_l_10170b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_24(struct state *);
extern unsigned char native_pc_24,native_next_24;
static void sim_24(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10180a3:;
	/* 0x10180a3: lea    r13,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R13, 0x10180afULL);
x86_l_10180aa:;
	/* 0x10180aa: call   r13 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R13);
		switch (X86_SIM_L_REG_TAG(X86_R13)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10180afULL: X86_SIM_X86_CALL(x86_l_10180af, 0x10180adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10180ad:;
	/* 0x10180ad: jmp    10180b3 <outer_done_24> */
	X86_SIM_X86_JMP(0x10180ad, 0x10180b3, x86_l_10180b3);
x86_l_10180af:;
	/* 0x10180af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10180b2:;
	/* 0x10180b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10180b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10180adULL: goto x86_l_10180ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_25(struct state *);
extern unsigned char native_pc_25,native_next_25;
static void sim_25(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10190a3:;
	/* 0x10190a3: lea    r13,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R13, 0x10190adULL);
x86_l_10190aa:;
	/* 0x10190aa: jmp    r13 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R13);
		switch (X86_SIM_L_REG_TAG(X86_R13)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10190adULL: goto x86_l_10190ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10190ad:;
	/* 0x10190ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10190b0:;
	/* 0x10190b0: jmp    10190b2 <outer_done_25> */
	X86_SIM_X86_JMP(0x10190b0, 0x10190b2, x86_l_10190b2);
x86_l_10190b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_26(struct state *);
extern unsigned char native_pc_26,native_next_26;
static void sim_26(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101a0a3:;
	/* 0x101a0a3: lea    r14,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R14, 0x101a0afULL);
x86_l_101a0aa:;
	/* 0x101a0aa: call   r14 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R14);
		switch (X86_SIM_L_REG_TAG(X86_R14)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101a0afULL: X86_SIM_X86_CALL(x86_l_101a0af, 0x101a0adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101a0ad:;
	/* 0x101a0ad: jmp    101a0b3 <outer_done_26> */
	X86_SIM_X86_JMP(0x101a0ad, 0x101a0b3, x86_l_101a0b3);
x86_l_101a0af:;
	/* 0x101a0af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101a0b2:;
	/* 0x101a0b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_101a0b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x101a0adULL: goto x86_l_101a0ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_27(struct state *);
extern unsigned char native_pc_27,native_next_27;
static void sim_27(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101b0a3:;
	/* 0x101b0a3: lea    r14,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R14, 0x101b0adULL);
x86_l_101b0aa:;
	/* 0x101b0aa: jmp    r14 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R14);
		switch (X86_SIM_L_REG_TAG(X86_R14)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101b0adULL: goto x86_l_101b0ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101b0ad:;
	/* 0x101b0ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101b0b0:;
	/* 0x101b0b0: jmp    101b0b2 <outer_done_27> */
	X86_SIM_X86_JMP(0x101b0b0, 0x101b0b2, x86_l_101b0b2);
x86_l_101b0b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_28(struct state *);
extern unsigned char native_pc_28,native_next_28;
static void sim_28(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101c0a3:;
	/* 0x101c0a3: lea    r15,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R15, 0x101c0afULL);
x86_l_101c0aa:;
	/* 0x101c0aa: call   r15 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R15);
		switch (X86_SIM_L_REG_TAG(X86_R15)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101c0afULL: X86_SIM_X86_CALL(x86_l_101c0af, 0x101c0adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101c0ad:;
	/* 0x101c0ad: jmp    101c0b3 <outer_done_28> */
	X86_SIM_X86_JMP(0x101c0ad, 0x101c0b3, x86_l_101c0b3);
x86_l_101c0af:;
	/* 0x101c0af: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101c0b2:;
	/* 0x101c0b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_101c0b3:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x101c0adULL: goto x86_l_101c0ad;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_29(struct state *);
extern unsigned char native_pc_29,native_next_29;
static void sim_29(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101d0a3:;
	/* 0x101d0a3: lea    r15,[rip+0x3] */
	X86_SIM_X86_CODE_ADDRESS(X86_R15, 0x101d0adULL);
x86_l_101d0aa:;
	/* 0x101d0aa: jmp    r15 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R15);
		switch (X86_SIM_L_REG_TAG(X86_R15)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101d0adULL: goto x86_l_101d0ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101d0ad:;
	/* 0x101d0ad: add    rdx,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101d0b0:;
	/* 0x101d0b0: jmp    101d0b2 <outer_done_29> */
	X86_SIM_X86_JMP(0x101d0b0, 0x101d0b2, x86_l_101d0b2);
x86_l_101d0b2:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_30(struct state *);
extern unsigned char native_pc_30,native_next_30;
static void sim_30(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101e0a3:;
	/* 0x101e0a3: test   dl,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RDX, X86_WIDTH_8, 1ULL);
x86_l_101e0a6:;
	/* 0x101e0a6: je     101e0b1 <native_pc_30+0xe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x101e0a6, 0x101e0b1, x86_l_101e0b1);
x86_l_101e0a8:;
	/* 0x101e0a8: lea    r10,[rip+0xe] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x101e0bdULL);
x86_l_101e0af:;
	/* 0x101e0af: jmp    101e0b8 <native_pc_30+0x15> */
	X86_SIM_X86_JMP(0x101e0af, 0x101e0b8, x86_l_101e0b8);
x86_l_101e0b1:;
	/* 0x101e0b1: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x101e0c1ULL);
x86_l_101e0b8:;
	/* 0x101e0b8: call   r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101e0bdULL: X86_SIM_X86_CALL(x86_l_101e0bd, 0x101e0bbULL);
			case 0x101e0c1ULL: X86_SIM_X86_CALL(x86_l_101e0c1, 0x101e0bbULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101e0bb:;
	/* 0x101e0bb: jmp    101e0c5 <outer_done_30> */
	X86_SIM_X86_JMP(0x101e0bb, 0x101e0c5, x86_l_101e0c5);
x86_l_101e0bd:;
	/* 0x101e0bd: add    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101e0c0:;
	/* 0x101e0c0: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_101e0c1:;
	/* 0x101e0c1: sub    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_101e0c4:;
	/* 0x101e0c4: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_101e0c5:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x101e0bbULL: goto x86_l_101e0bb;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_31(struct state *);
extern unsigned char native_pc_31,native_next_31;
static void sim_31(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_101f0a3:;
	/* 0x101f0a3: test   dl,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_RDX, X86_WIDTH_8, 1ULL);
x86_l_101f0a6:;
	/* 0x101f0a6: je     101f0b1 <native_pc_31+0xe> */
	X86_SIM_X86_JCC(X86_CC_E, 0x101f0a6, 0x101f0b1, x86_l_101f0b1);
x86_l_101f0a8:;
	/* 0x101f0a8: lea    r10,[rip+0xf] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x101f0beULL);
x86_l_101f0af:;
	/* 0x101f0af: jmp    101f0b8 <native_pc_31+0x15> */
	X86_SIM_X86_JMP(0x101f0af, 0x101f0b8, x86_l_101f0b8);
x86_l_101f0b1:;
	/* 0x101f0b1: lea    r10,[rip+0xb] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x101f0c3ULL);
x86_l_101f0b8:;
	/* 0x101f0b8: mov    r11,r10 */
	X86_SIM_L_EXEC_MOV_REG(X86_R11, X86_R10, X86_WIDTH_64);
x86_l_101f0bb:;
	/* 0x101f0bb: jmp    r11 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x101f0beULL: goto x86_l_101f0be;
			case 0x101f0c3ULL: goto x86_l_101f0c3;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_101f0be:;
	/* 0x101f0be: add    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_101f0c1:;
	/* 0x101f0c1: jmp    101f0c8 <outer_done_31> */
	X86_SIM_X86_JMP(0x101f0c1, 0x101f0c8, x86_l_101f0c8);
x86_l_101f0c3:;
	/* 0x101f0c3: sub    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_SUB);
x86_l_101f0c6:;
	/* 0x101f0c6: jmp    101f0c8 <outer_done_31> */
	X86_SIM_X86_JMP(0x101f0c6, 0x101f0c8, x86_l_101f0c8);
x86_l_101f0c8:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_32(struct state *);
extern unsigned char native_pc_32,native_next_32;
static void sim_32(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10200a3:;
	/* 0x10200a3: call   10200aa <native_pc_32+0x7> */
	X86_SIM_X86_CALL(x86_l_10200aa, 0x10200a8ULL);
x86_l_10200a8:;
	/* 0x10200a8: jmp    10200b7 <outer_done_32> */
	X86_SIM_X86_JMP(0x10200a8, 0x10200b7, x86_l_10200b7);
x86_l_10200aa:;
	/* 0x10200aa: call   10200b3 <native_pc_32+0x10> */
	X86_SIM_X86_CALL(x86_l_10200b3, 0x10200afULL);
x86_l_10200af:;
	/* 0x10200af: add    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10200b2:;
	/* 0x10200b2: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10200b3:;
	/* 0x10200b3: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10200b6:;
	/* 0x10200b6: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10200b7:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10200a8ULL: goto x86_l_10200a8;
case 0x10200afULL: goto x86_l_10200af;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_33(struct state *);
extern unsigned char native_pc_33,native_next_33;
static void sim_33(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10210a3:;
	/* 0x10210a3: lea    r10,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x10210afULL);
x86_l_10210aa:;
	/* 0x10210aa: call   r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10210afULL: X86_SIM_X86_CALL(x86_l_10210af, 0x10210adULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10210ad:;
	/* 0x10210ad: jmp    10210c1 <outer_done_33> */
	X86_SIM_X86_JMP(0x10210ad, 0x10210c1, x86_l_10210c1);
x86_l_10210af:;
	/* 0x10210af: lea    r11,[rip+0x7] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x10210bdULL);
x86_l_10210b6:;
	/* 0x10210b6: call   r11 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10210bdULL: X86_SIM_X86_CALL(x86_l_10210bd, 0x10210b9ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10210b9:;
	/* 0x10210b9: add    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10210bc:;
	/* 0x10210bc: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10210bd:;
	/* 0x10210bd: add    rdx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD);
x86_l_10210c0:;
	/* 0x10210c0: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10210c1:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10210adULL: goto x86_l_10210ad;
case 0x10210b9ULL: goto x86_l_10210b9;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
extern void native_34(struct state *);
extern unsigned char native_pc_34,native_next_34;
static void sim_34(struct state *s) {
X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;
__x86_native_stack_base=native_stack_base;
__x86_rax.ptr=(void *)(uintptr_t)s->r[0];
__x86_rcx.ptr=(void *)(uintptr_t)s->r[1];
__x86_rdx.ptr=(void *)(uintptr_t)s->r[2];
__x86_rbx.ptr=(void *)(uintptr_t)s->r[3];
__x86_rsp.ptr=(void *)(uintptr_t)s->r[4];
__x86_rbp.ptr=(void *)(uintptr_t)s->r[5];
__x86_rsi.ptr=(void *)(uintptr_t)s->r[6];
__x86_rdi.ptr=(void *)(uintptr_t)s->r[7];
__x86_r8.ptr=(void *)(uintptr_t)s->r[8];
__x86_r9.ptr=(void *)(uintptr_t)s->r[9];
__x86_r10.ptr=(void *)(uintptr_t)s->r[10];
__x86_r11.ptr=(void *)(uintptr_t)s->r[11];
__x86_r12.ptr=(void *)(uintptr_t)s->r[12];
__x86_r13.ptr=(void *)(uintptr_t)s->r[13];
__x86_r14.ptr=(void *)(uintptr_t)s->r[14];
__x86_r15.ptr=(void *)(uintptr_t)s->r[15];
for(unsigned k=0;k<64;k++) __x86_stack_mem.b[k]=s->stack[k];
__x86_cf=s->flags&1; __x86_pf=(s->flags>>2)&1; __x86_af=(s->flags>>4)&1; __x86_zf=(s->flags>>6)&1; __x86_sf=(s->flags>>7)&1; __x86_of=(s->flags>>11)&1;
__x86_xmm0_lo=s->vec[0]; __x86_xmm0_hi=s->vec[1];
x86_l_10220a3:;
	/* 0x10220a3: call   10220aa <native_pc_34+0x7> */
	X86_SIM_X86_CALL(x86_l_10220aa, 0x10220a8ULL);
x86_l_10220a8:;
	/* 0x10220a8: jmp    10220af <outer_done_34> */
	X86_SIM_X86_JMP(0x10220a8, 0x10220af, x86_l_10220af);
x86_l_10220aa:;
	/* 0x10220aa: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10220ae:;
	/* 0x10220ae: ret */
	X86_SIM_X86_SUB_RET(return_dispatch);
x86_l_10220af:;
goto observed;
goto observed;
return_dispatch: switch (__x86_sim_ret_addr) {
case 0x10220a8ULL: goto x86_l_10220a8;
default: abort();
}
observed:;
s->r[0]=X86_SIM_L_READ_REG(0);
s->r[1]=X86_SIM_L_READ_REG(1);
s->r[2]=X86_SIM_L_READ_REG(2);
s->r[3]=X86_SIM_L_READ_REG(3);
s->r[4]=(uintptr_t)__x86_rsp.ptr;
s->r[5]=X86_SIM_L_READ_REG(5);
s->r[6]=X86_SIM_L_READ_REG(6);
s->r[7]=X86_SIM_L_READ_REG(7);
s->r[8]=X86_SIM_L_READ_REG(8);
s->r[9]=X86_SIM_L_READ_REG(9);
s->r[10]=X86_SIM_L_READ_REG(10);
s->r[11]=X86_SIM_L_READ_REG(11);
s->r[12]=X86_SIM_L_READ_REG(12);
s->r[13]=X86_SIM_L_READ_REG(13);
s->r[14]=X86_SIM_L_READ_REG(14);
s->r[15]=X86_SIM_L_READ_REG(15);
for(unsigned k=0;k<64;k++) s->stack[k]=__x86_stack_mem.b[k];
s->flags=__x86_cf|((uint64_t)__x86_pf<<2)|((uint64_t)__x86_af<<4)|((uint64_t)__x86_zf<<6)|((uint64_t)__x86_sf<<7)|((uint64_t)__x86_of<<11);
s->vec[0]=__x86_xmm0_lo; s->vec[1]=__x86_xmm0_hi;
}
const struct form forms[]={
{"CALL rax / RET","X86_CONTROL",native_0,sim_0,0x8d5U,64,0,6,&native_pc_0,&native_next_0},
{"JMP rax","X86_CONTROL",native_1,sim_1,0x8d5U,64,0,6,&native_pc_1,&native_next_1},
{"CALL rcx / RET","X86_CONTROL",native_2,sim_2,0x8d5U,64,0,6,&native_pc_2,&native_next_2},
{"JMP rcx","X86_CONTROL",native_3,sim_3,0x8d5U,64,0,6,&native_pc_3,&native_next_3},
{"CALL rdx / RET","X86_CONTROL",native_4,sim_4,0x8d5U,64,0,6,&native_pc_4,&native_next_4},
{"JMP rdx","X86_CONTROL",native_5,sim_5,0x8d5U,64,0,6,&native_pc_5,&native_next_5},
{"CALL rbx / RET","X86_CONTROL",native_6,sim_6,0x8d5U,64,0,6,&native_pc_6,&native_next_6},
{"JMP rbx","X86_CONTROL",native_7,sim_7,0x8d5U,64,0,6,&native_pc_7,&native_next_7},
{"CALL rbp / RET","X86_CONTROL",native_8,sim_8,0x8d5U,64,0,6,&native_pc_8,&native_next_8},
{"JMP rbp","X86_CONTROL",native_9,sim_9,0x8d5U,64,0,6,&native_pc_9,&native_next_9},
{"CALL rsi / RET","X86_CONTROL",native_10,sim_10,0x8d5U,64,0,6,&native_pc_10,&native_next_10},
{"JMP rsi","X86_CONTROL",native_11,sim_11,0x8d5U,64,0,6,&native_pc_11,&native_next_11},
{"CALL rdi / RET","X86_CONTROL",native_12,sim_12,0x8d5U,64,0,6,&native_pc_12,&native_next_12},
{"JMP rdi","X86_CONTROL",native_13,sim_13,0x8d5U,64,0,6,&native_pc_13,&native_next_13},
{"CALL r8 / RET","X86_CONTROL",native_14,sim_14,0x8d5U,64,0,6,&native_pc_14,&native_next_14},
{"JMP r8","X86_CONTROL",native_15,sim_15,0x8d5U,64,0,6,&native_pc_15,&native_next_15},
{"CALL r9 / RET","X86_CONTROL",native_16,sim_16,0x8d5U,64,0,6,&native_pc_16,&native_next_16},
{"JMP r9","X86_CONTROL",native_17,sim_17,0x8d5U,64,0,6,&native_pc_17,&native_next_17},
{"CALL r10 / RET","X86_CONTROL",native_18,sim_18,0x8d5U,64,0,6,&native_pc_18,&native_next_18},
{"JMP r10","X86_CONTROL",native_19,sim_19,0x8d5U,64,0,6,&native_pc_19,&native_next_19},
{"CALL r11 / RET","X86_CONTROL",native_20,sim_20,0x8d5U,64,0,6,&native_pc_20,&native_next_20},
{"JMP r11","X86_CONTROL",native_21,sim_21,0x8d5U,64,0,6,&native_pc_21,&native_next_21},
{"CALL r12 / RET","X86_CONTROL",native_22,sim_22,0x8d5U,64,0,6,&native_pc_22,&native_next_22},
{"JMP r12","X86_CONTROL",native_23,sim_23,0x8d5U,64,0,6,&native_pc_23,&native_next_23},
{"CALL r13 / RET","X86_CONTROL",native_24,sim_24,0x8d5U,64,0,6,&native_pc_24,&native_next_24},
{"JMP r13","X86_CONTROL",native_25,sim_25,0x8d5U,64,0,6,&native_pc_25,&native_next_25},
{"CALL r14 / RET","X86_CONTROL",native_26,sim_26,0x8d5U,64,0,6,&native_pc_26,&native_next_26},
{"JMP r14","X86_CONTROL",native_27,sim_27,0x8d5U,64,0,6,&native_pc_27,&native_next_27},
{"CALL r15 / RET","X86_CONTROL",native_28,sim_28,0x8d5U,64,0,6,&native_pc_28,&native_next_28},
{"JMP r15","X86_CONTROL",native_29,sim_29,0x8d5U,64,0,6,&native_pc_29,&native_next_29},
{"CALL finite choice","X86_CONTROL",native_30,sim_30,0x8d5U,64,0,6,&native_pc_30,&native_next_30},
{"JMP finite copied choice","X86_CONTROL",native_31,sim_31,0x8d5U,64,0,6,&native_pc_31,&native_next_31},
{"nested direct CALL","X86_CONTROL",native_32,sim_32,0x8d5U,64,0,6,&native_pc_32,&native_next_32},
{"nested indirect CALL","X86_CONTROL",native_33,sim_33,0x8d5U,64,0,6,&native_pc_33,&native_next_33},
{"CALL stack return address","X86_CONTROL",native_34,sim_34,0x8d5U,64,0,6,&native_pc_34,&native_next_34}
};
const unsigned form_count=sizeof(forms)/sizeof(forms[0]);
