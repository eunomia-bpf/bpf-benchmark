from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,traceback
R=Path('/workspaces/repository');F=Path('/workspaces/.agent-state/kprog-lanes/F');D=F/'pure-relocatable'
D.mkdir(exist_ok=True);os.chdir(R)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def run(args,log):
 with (D/log).open('w') as f:
  p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{log}: exit {p.returncode}')
def state(s):(D/'state').write_text(s+'\n')
try:
 state('building_pure_relocatable_objects')
 shutil.copy2(R/'micro/programs/build-x86/kernel_offsets.h',D/'kernel_offsets.h')
 import sys
 sys.path.insert(0,str(R))
 from micro.catalog import load_catalog
 pure=load_catalog(R/'micro/config/micro_pure_jit.yaml')
 stage2=load_catalog(R/'micro/config/micro_stage2.yaml')
 assert len(pure.targets)==29 and len(stage2.targets)==13
 assert all(t.native_kernel_object_path.suffix=='.o' and t.native_object_path.suffix=='.so' for c in [pure,stage2] for t in c.targets)
 objects=[t.native_kernel_object_path for t in pure.targets]
 originals={str(t.native_object_path.relative_to(R)):sha(t.native_object_path) for t in pure.targets}
 run(['taskset','-c','16-19','make','-j2','-C','micro/programs','CLANG=clang-18',
      'OUTPUT_DIR='+str(R/'micro/programs/build-x86'),'KERNEL_OFFSETS_INPUT='+str(D/'kernel_offsets.h'),
      *map(str,objects)],'object-build.log')
 assert sha(R/'micro/programs/build-x86/kernel_offsets.h')==sha(D/'kernel_offsets.h')
 for p,h in originals.items():assert sha(R/p)==h
 pins={}
 for p in objects:
  data=p.read_bytes()
  assert data[:4]==b'\x7fELF' and data[4:6]==b'\x02\x01'
  assert int.from_bytes(data[16:18],'little')==1 and int.from_bytes(data[18:20],'little')==62
  pins[str(p.relative_to(R))]=sha(p)
 emit(D/'object-checks.json',dict(recorded=datetime.now(timezone.utc).isoformat(),pure_objects=len(objects),
      stage2_catalog_paths=len(stage2.targets),elf_type='ET_REL',machine='EM_X86_64',
      original_userspace_so_hashes_unchanged=originals,objects=pins))
 ctx=D/'image-context';ctx.mkdir(exist_ok=True)
 (ctx/'micro').mkdir(exist_ok=True);shutil.copy2(R/'micro/catalog.py',ctx/'micro/catalog.py')
 artifact=ctx/'artifacts/user/micro-programs/x86_64';artifact.mkdir(parents=True,exist_ok=True)
 for p in objects:shutil.copy2(p,artifact/p.name)
 (ctx/'Dockerfile').write_text('FROM bpf-benchmark/kprog-micro-trusted:c-20261107\nCOPY micro/catalog.py /workspaces/repository/micro/catalog.py\nCOPY artifacts/ /artifacts/\n')
 emit(D/'source-pins-before.json',{str(p.relative_to(R)):sha(p) for p in [
  R/'micro/catalog.py',R/'micro/programs/Makefile',R/'micro/programs/common.h',
  R/'micro/config/micro_pure_jit.yaml',R/'micro/driver.py',R/'Makefile',
  R/'kprog/trusted_service.py',R/'kprog/x86/x86_sim_local_bpf.h']})
 state('building_incremental_cached_image_layer')
 run(['docker','build','--pull=false','-t','bpf-benchmark/kprog-micro-pure-relocatable:f-20261107',str(ctx)],'image-build.log')
 state('exporting_cached_image')
 run(['docker','save','-o',str(D/'runtime.image.tar'),'bpf-benchmark/kprog-micro-pure-relocatable:f-20261107'],'image-export.log')
 state('running_standard_pure_suite_kvm')
 env=os.environ.copy();env['PATH']='/usr/lib/llvm-18/bin:'+env['PATH']
 cmd=['taskset','-c','16-19','vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),
      '--cwd',str(R),'--rwdir',str(R),'--rwdir','/var/tmp='+str(D/'var-tmp'),
      '--overlay-rwdir','/tmp','--overlay-rwdir','/run','--overlay-rwdir','/usr/local',
      '--disable-monitor','--cpus','2','--memory','4G','--append','loglevel=4 panic=30 oops=panic',
      '--exec','PATH=/usr/lib/llvm-18/bin:$PATH make __runtime-vm-micro PLATFORM=kvm ARCH=x86 '
      'HOST_KINSN_DIR_X86=/workspaces/repository/kprog/tv/build-x86/corpus-modules '
      'RUNTIME_CONTAINER_IMAGE=bpf-benchmark/kprog-micro-pure-relocatable:f-20261107 '
      'RUNTIME_IMAGE_TAR=/workspaces/.agent-state/kprog-lanes/F/pure-relocatable/runtime.image.tar '
      'RUN_TOKEN=f-pure-relocatable-20261107 RUNTIMES="kernel native_kernel native_proof" '
      'SUITE=micro/config/micro_pure_jit.yaml SAMPLES=1 WARMUPS=0 INNER_REPEAT=1']
 (D/'var-tmp').mkdir(exist_ok=True);emit(D/'guest-command.json',cmd)
 with (D/'guest.log').open('w') as f:rc=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 (D/'guest.exit').write_text(str(rc)+'\n')
 before=json.loads((D/'source-pins-before.json').read_text())
 after={p:sha(R/p) for p in before};emit(D/'source-pins-after.json',after)
 emit(D/'source-drift.json',[p for p in before if before[p]!=after[p]])
 state('closed_guest_'+str(rc)+'_needs_results_review')
 (D/'exit').write_text(str(rc)+'\n')
except BaseException:
 (D/'error').write_text(traceback.format_exc());state('failed_evidence_retained');(D/'exit').write_text('1\n')
 raise
finally:
 for p in [D/'var-tmp/bpf-benchmark-docker.img',D/'runtime.image.tar']:
  if not p.exists():continue
  check=subprocess.run(['fuser','-s',str(p)],capture_output=True)
  if check.returncode==1:p.unlink()
  elif check.returncode!=0:
   with (D/'cleanup-error.log').open('a') as f:f.write(str((str(p),check.returncode,check.stderr))+'\n')
