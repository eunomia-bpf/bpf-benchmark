/*
 * libbpfrejit_shim.so — LD_PRELOAD interception + state shim for BPF apps.
 *
 * Intercept layer wraps syscall(2)/ioctl(2)/perf_event_open(2)/close(2) in
 * libc. For each observed BPF/perf control-plane call: log, then pass through.
 *
 * State tables (keyed by app-side fd) record every BPF object whose fd lives
 * in this process: programs, maps, links, perf_event handles. Each entry
 * records the kernel-side id (resolved via BPF_OBJ_GET_INFO_BY_FD), the
 * original load attr (for prog), and the attach relationship (for link /
 * perf_event). close() maintains table consistency.
 *
 * Per-pid socket implements app-level shim RPCs. Optimization is runner-driven:
 * the runner reads its yaml and sends pass steps; the shim applies them to
 * every BPF program tracked in this process, substitutes ${VAR}s, and runs
 * /bin/sh -c.
 *
 * Usage:
 *   gcc -shared -fPIC -O2 libbpfrejit_shim.c -o libbpfrejit_shim.so -ldl -lpthread
 *   BPFREJIT_SHIM_LOG=/tmp/shim.log LD_PRELOAD=./libbpfrejit_shim.so <app>
 */

#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/bpf.h>
#include <linux/perf_event.h>
#include <limits.h>
#include <pthread.h>
#include <sys/prctl.h>
#include <signal.h>
#include <spawn.h>
#include <stdarg.h>
#include <stddef.h>
#include <sys/file.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* Intentionally omit <sys/ioctl.h>: musl declares `ioctl(int, int, ...)` while
 * glibc declares `ioctl(int, unsigned long, ...)`. We pick the kernel ABI
 * (unsigned long request) and self-declare what we need from asm-generic/ioctl.h
 * via <linux/ioctl.h>. */
#include <linux/ioctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "shim_netlink.h"

extern char **environ;

#ifndef SYS_perf_event_open
#define SYS_perf_event_open 298 /* x86_64 */
#endif

#ifndef SYS_close_range
#ifdef __NR_close_range
#define SYS_close_range __NR_close_range
#else
#define SYS_close_range 436
#endif
#endif

#ifndef SYS_unshare
#ifdef __NR_unshare
#define SYS_unshare __NR_unshare
#else
#define SYS_unshare 272
#endif
#endif

#ifndef CLOSE_RANGE_UNSHARE
#define CLOSE_RANGE_UNSHARE (1U << 1)
#endif

#ifndef CLOSE_RANGE_CLOEXEC
#define CLOSE_RANGE_CLOEXEC (1U << 2)
#endif

#ifndef CLONE_FILES
#define CLONE_FILES 0x00000400
#endif

#ifndef PERF_EVENT_IOC_SET_BPF
#define PERF_EVENT_IOC_SET_BPF _IOW('$', 8, __u32)
#endif

#ifndef PERF_EVENT_IOC_QUERY_BPF
#define PERF_EVENT_IOC_QUERY_BPF _IOWR('$', 10, struct perf_event_query_bpf *)
#endif

/* Resolved real symbols. Filled at shim_init() but every interceptor must
 * also handle the case where the symbol is still NULL — heavy C++ runtime
 * apps (katran's folly/grpc) call syscall(3) from their own constructors,
 * which can race ahead of our constructor depending on dynamic init order. */
static long (*real_syscall)(long, ...);
static int (*real_ioctl)(int, unsigned long, ...);
static int (*real_close)(int);
/* sendto/sendmsg are intercepted to catch katran-style rtnetlink XDP
 * attach (RTM_SETLINK + IFLA_XDP_FD). libbpf < v0.8, iproute2-style ip-link
 * xdp, and Cilium's pre-link path all attach via these. Without intercept,
 * the netdev keeps dispatching to the original prog after ReJIT reload. */
static ssize_t (*real_sendto)(int, const void *, size_t, int,
                              const struct sockaddr *, socklen_t);
static ssize_t (*real_sendmsg)(int, const struct msghdr *, int);

/* Resolve any not-yet-resolved real symbols. Called at the top of every
 * interceptor so that apps which call syscall(3)/ioctl(2)/close(2) from a
 * constructor that runs before ours (folly/grpc/etc.) don't see NULL. */
static void ensure_syms_resolved(void) {
    if (!real_syscall)
        real_syscall = (long (*)(long, ...))dlsym(RTLD_NEXT, "syscall");
    if (!real_ioctl)
        real_ioctl = (int (*)(int, unsigned long, ...))dlsym(RTLD_NEXT, "ioctl");
    if (!real_sendto)
        real_sendto = (ssize_t (*)(int, const void *, size_t, int,
                                   const struct sockaddr *, socklen_t))
                      dlsym(RTLD_NEXT, "sendto");
    if (!real_sendmsg)
        real_sendmsg = (ssize_t (*)(int, const struct msghdr *, int))
                       dlsym(RTLD_NEXT, "sendmsg");
    if (!real_close)
        real_close = (int (*)(int))dlsym(RTLD_NEXT, "close");
}

static FILE *log_file;
static pthread_mutex_t log_mutex = PTHREAD_MUTEX_INITIALIZER;

/* Recursion guard: shim-internal syscalls must not re-enter the logger. */
static __thread int in_shim;

#include "shim_state.h"
#include "shim_json.h"
#include "shim_snapshot.h"
#include "shim_loadtime.h"
#include "shim_native_loader.h"

static int capture_prog_load_exact_map_refs(struct prog_entry *prog,
                                            const union bpf_attr *attr) {
    if (!prog || !attr || !attr->insns || attr->insn_cnt == 0)
        return 0;

    struct shim_map_ref *refs = NULL;
    uint32_t ref_n = 0;
    const struct bpf_insn *insns =
        (const struct bpf_insn *)(uintptr_t)attr->insns;
    if (collect_current_map_refs(insns, attr->insn_cnt, &refs, &ref_n) != 0)
        return -1;
    if (ref_n == 0) {
        free(refs);
        return 0;
    }

    uint32_t *fds = (uint32_t *)calloc(ref_n, sizeof(uint32_t));
    uint32_t *kids = (uint32_t *)calloc(ref_n, sizeof(uint32_t));
    uint32_t *types = (uint32_t *)calloc(ref_n, sizeof(uint32_t));
    if (!fds || !kids || !types) {
        free(fds);
        free(kids);
        free(types);
        free(refs);
        return -1;
    }

    uint32_t n = 0;
    for (uint32_t r = 0; r < ref_n; r++) {
        if (refs[r].loader_fd < 0 || refs[r].kernel_id == 0)
            continue;
        int dup = 0;
        for (uint32_t i = 0; i < n; i++) {
            if (fds[i] == (uint32_t)refs[r].loader_fd) {
                dup = 1;
                break;
            }
        }
        if (dup)
            continue;
        fds[n] = (uint32_t)refs[r].loader_fd;
        kids[n] = refs[r].kernel_id;
        types[n] = refs[r].map_type;
        n++;
    }
    free(refs);

    if (n == 0) {
        free(fds);
        free(kids);
        free(types);
        return 0;
    }

    free(prog->snap_fds);
    free(prog->snap_kids);
    free(prog->snap_types);
    prog->snap_fds = fds;
    prog->snap_kids = kids;
    prog->snap_types = types;
    prog->snap_n = n;
    return 0;
}

static void *worker_thread(void *arg);  /* forward decl */
static void *socket_thread(void *arg);  /* forward decl */

static int read_perf_pmu_type(const char *name, int *cache) {
    if (*cache != -2)
        return *cache;

    char path[128];
    snprintf(path, sizeof(path), "/sys/bus/event_source/devices/%s/type", name);
    FILE *f = fopen(path, "r");
    if (!f) {
        *cache = -1;
        return *cache;
    }
    int value = -1;
    if (fscanf(f, "%d", &value) != 1)
        value = -1;
    fclose(f);
    *cache = value;
    return *cache;
}

static void format_perf_event_extra(const struct perf_event_attr *pa,
                                    char *buf, size_t len) {
    if (!buf || len == 0)
        return;
    buf[0] = '\0';
    if (!pa)
        return;

    static int kprobe_type = -2;
    static int uprobe_type = -2;
    int kt = read_perf_pmu_type("kprobe", &kprobe_type);
    int ut = read_perf_pmu_type("uprobe", &uprobe_type);

    if ((int)pa->type == kt && pa->kprobe_func) {
        const char *fn = (const char *)(uintptr_t)pa->kprobe_func;
        snprintf(buf, len, " kprobe_func=%.*s kprobe_addr=%llu", 120, fn,
                 (unsigned long long)pa->kprobe_addr);
    } else if ((int)pa->type == ut && pa->uprobe_path) {
        const char *path = (const char *)(uintptr_t)pa->uprobe_path;
        snprintf(buf, len, " uprobe_path=%.*s probe_offset=%llu", 120, path,
                 (unsigned long long)pa->probe_offset);
    }
}

static void copy_perf_probe_target(const struct perf_event_attr *pa,
                                   char *out, size_t out_sz) {
    if (!out || out_sz == 0)
        return;
    out[0] = '\0';
    if (!pa)
        return;

    static int kprobe_type = -2;
    static int uprobe_type = -2;
    int kt = read_perf_pmu_type("kprobe", &kprobe_type);
    int ut = read_perf_pmu_type("uprobe", &uprobe_type);
    const char *source = NULL;
    if ((int)pa->type == kt && pa->kprobe_func)
        source = (const char *)(uintptr_t)pa->kprobe_func;
    else if ((int)pa->type == ut && pa->uprobe_path)
        source = (const char *)(uintptr_t)pa->uprobe_path;
    if (source)
        snprintf(out, out_sz, "%s", source);
}

static void log_task_fd_query(uint32_t target_fd, uint32_t attach_type) {
    if (target_fd == 0)
        return;

    char probe[256];
    memset(probe, 0, sizeof(probe));
    union bpf_attr q;
    memset(&q, 0, sizeof(q));
    q.task_fd_query.pid = (uint32_t)getpid();
    q.task_fd_query.fd = target_fd;
    q.task_fd_query.buf_len = sizeof(probe);
    q.task_fd_query.buf = (uintptr_t)probe;

    long ret = real_syscall(SYS_bpf, BPF_TASK_FD_QUERY, &q, sizeof(q));
    int saved_errno = errno;
    log_line("BPF_TASK_FD_QUERY target_fd=%u attach_type=%u -> ret=%ld "
             "errno=%d fd_type=%u prog_id=%u probe_offset=%llu "
             "probe_addr=%llu symbol=%s",
             target_fd, attach_type, ret, ret < 0 ? saved_errno : 0,
             q.task_fd_query.fd_type, q.task_fd_query.prog_id,
             (unsigned long long)q.task_fd_query.probe_offset,
             (unsigned long long)q.task_fd_query.probe_addr, probe);
    errno = saved_errno;
}

static int fd_is_bpf_prog(int fd) {
    if (fd < 0)
        return 0;
    char fdpath[64], link_target[64];
    snprintf(fdpath, sizeof(fdpath), "/proc/self/fd/%d", fd);
    ssize_t lr = readlink(fdpath, link_target, sizeof(link_target) - 1);
    if (lr <= 0)
        return 0;
    link_target[lr] = 0;
    return strcmp(link_target, "anon_inode:bpf-prog") == 0;
}

static int shim_pgo_hold_prog_fds_enabled(void) {
    return shim_env_truthy("BPFREJIT_SHIM_PGO_HOLD_PROG_FDS");
}

static int prog_profile_hold_fd_is_locked(int fd) {
    if (fd < 0)
        return 0;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++)
        for (struct prog_entry *p = prog_table[b]; p; p = p->next)
            if (p->profile_hold_fd == fd)
                return 1;
    return 0;
}

static int prog_profile_hold_fd_is(int fd) {
    int ret;
    pthread_mutex_lock(&state_mutex);
    ret = prog_profile_hold_fd_is_locked(fd);
    pthread_mutex_unlock(&state_mutex);
    return ret;
}

/* Retire every piece of state associated with an fd before either closing it
 * or recording a newly returned kernel object at the same number.  Native
 * runtimes such as Go issue close(2) without crossing the libc/LD_PRELOAD
 * boundary, so fd reuse is sometimes the first observable proof that the old
 * attachment disappeared.  Caller holds state_mutex. */
static void shim_forget_fd_state_locked(int fd) {
    if (fd < 0)
        return;
    prog_forget_loader_fd(fd);
    map_remove(fd);
    link_remove(fd);
    raw_tp_remove(fd);
    perf_remove(fd);
    prog_table_drop_attach_fd(fd);
}

static int shim_close_observed_fd(int fd) {
    ensure_syms_resolved();
    if (shim_pgo_hold_prog_fds_enabled() && prog_profile_hold_fd_is(fd)) {
        log_line("PGO hold fd close skipped fd=%d", fd);
        return 0;
    }
    pthread_mutex_lock(&state_mutex);
    int retained_link_fd = link_owned_fd_is_locked(fd);
    pthread_mutex_unlock(&state_mutex);
    if (retained_link_fd) {
        log_line("retained BPF link fd close skipped fd=%d", fd);
        return 0;
    }
    if (fd >= 0) {
        pthread_mutex_lock(&state_mutex);
        shim_forget_fd_state_locked(fd);
        pthread_mutex_unlock(&state_mutex);
    }
    in_shim = 1;
    int ret = real_close(fd);
    int saved_errno = errno;
    in_shim = 0;
    errno = saved_errno;
    return ret;
}

/* A loader may reopen a pinned BPF link and update it to a newly loaded
 * program. The link fd then has no creation-time table entry, and the old
 * program's attachment record is stale. Retain a private duplicate of the
 * live link and transfer ownership to the new program so a later
 * execute_plan uses BPF_LINK_UPDATE rather than misclassifying the attachment
 * as legacy netlink XDP. */
static int track_successful_link_update(const union bpf_attr *attr) {
    if (!attr)
        return -1;
    int app_link_fd = (int)attr->link_update.link_fd;
    int new_prog_fd = (int)attr->link_update.new_prog_fd;
    uint32_t link_id = resolve_kernel_id(app_link_fd);
    uint32_t new_prog_id = resolve_kernel_id(new_prog_fd);
    if (!link_id || !new_prog_id) {
        log_line("BPF_LINK_UPDATE tracking could not resolve link/prog ids "
                 "link_fd=%d link_id=%u new_prog_fd=%d prog_id=%u",
                 app_link_fd, link_id, new_prog_fd, new_prog_id);
        return -1;
    }

    int retained_fd = -1;
    int previous_tracked_fd = -1;
    pthread_mutex_lock(&state_mutex);
    struct link_entry *link = link_find_by_kernel_id(link_id);
    if (link)
        previous_tracked_fd = link->fd;
    if (!link || !link->fd_owned_by_shim) {
        long duplicate = real_syscall(SYS_fcntl, app_link_fd,
                                      F_DUPFD_CLOEXEC, 3);
        if (duplicate < 0) {
            int duplicate_errno = errno;
            pthread_mutex_unlock(&state_mutex);
            log_line("BPF_LINK_UPDATE tracking could not retain link_id=%u "
                     "fd=%d errno=%d",
                     link_id, app_link_fd, duplicate_errno);
            return -1;
        }
        retained_fd = (int)duplicate;
        if (link) {
            int old_fd = link->fd;
            link->fd = retained_fd;
            link->fd_owned_by_shim = 1;
            link_rebucket_locked(link, old_fd);
        } else {
            link = (struct link_entry *)calloc(1, sizeof(*link));
            if (!link) {
                pthread_mutex_unlock(&state_mutex);
                real_close(retained_fd);
                log_line("BPF_LINK_UPDATE tracking allocation failed "
                         "link_id=%u", link_id);
                return -1;
            }
            link->fd = retained_fd;
            link->fd_owned_by_shim = 1;
            link->prog_fd = (uint32_t)new_prog_fd;
            link->attach_type = BPF_XDP;
            link->kernel_link_id = link_id;
            link->target_hold_fd = -1;
            link_insert(link);
        }
    } else {
        retained_fd = link->fd;
    }

    struct prog_entry *new_prog =
        prog_find_attachment_target(new_prog_fd, new_prog_id);
    if (!new_prog) {
        pthread_mutex_unlock(&state_mutex);
        log_line("BPF_LINK_UPDATE tracking found no new prog entry "
                 "link_id=%u new_prog_id=%u", link_id, new_prog_id);
        return -1;
    }
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct prog_entry *prog = prog_table[b]; prog; prog = prog->next) {
            prog_attach_drop(prog->attached_link_fds, &prog->n_links,
                             app_link_fd);
            if (previous_tracked_fd != app_link_fd)
                prog_attach_drop(prog->attached_link_fds, &prog->n_links,
                                 previous_tracked_fd);
            if (retained_fd != app_link_fd)
                prog_attach_drop(prog->attached_link_fds, &prog->n_links,
                                 retained_fd);
        }
    }
    if (prog_attach_append(&new_prog->attached_link_fds, &new_prog->n_links,
                           retained_fd) != 0) {
        pthread_mutex_unlock(&state_mutex);
        log_line("BPF_LINK_UPDATE tracking could not attach retained fd=%d "
                 "to new_prog_id=%u", retained_fd, new_prog_id);
        return -1;
    }
    link->prog_fd = (uint32_t)new_prog_fd;
    if (link->create_attr_size >= sizeof(uint32_t))
        memcpy(link->create_attr_blob, &link->prog_fd, sizeof(link->prog_fd));
    pthread_mutex_unlock(&state_mutex);
    log_line("BPF_LINK_UPDATE tracking retargeted link_id=%u retained_fd=%d "
             "new_prog_id=%u", link_id, retained_fd, new_prog_id);
    return 0;
}

static long shim_close_range_observed(unsigned int first,
                                      unsigned int last,
                                      unsigned int flags) {
    if (flags & CLOSE_RANGE_UNSHARE) {
        long ur = real_syscall(SYS_unshare, CLONE_FILES);
        if (ur < 0)
            return -1;
    }

    DIR *fd_dir = opendir("/proc/self/fd");
    if (!fd_dir)
        return -1;
    int dir_fd = dirfd(fd_dir);
    int *fds = NULL;
    size_t n = 0, cap = 0;
    struct dirent *de;
    while ((de = readdir(fd_dir)) != NULL) {
        if (de->d_name[0] < '0' || de->d_name[0] > '9')
            continue;
        char *end = NULL;
        errno = 0;
        unsigned long raw = strtoul(de->d_name, &end, 10);
        if (errno || !end || *end)
            continue;
        if (raw > INT_MAX)
            continue;
        int fd = (int)raw;
        if (fd == dir_fd)
            continue;
        if ((unsigned int)fd < first || (unsigned int)fd > last)
            continue;
        if (prog_profile_hold_fd_is(fd))
            continue;
        if (n == cap) {
            size_t next = cap ? cap * 2 : 64;
            int *grown = (int *)realloc(fds, next * sizeof(*grown));
            if (!grown) {
                int saved = errno ? errno : ENOMEM;
                free(fds);
                closedir(fd_dir);
                errno = saved;
                return -1;
            }
            fds = grown;
            cap = next;
        }
        fds[n++] = fd;
    }
    closedir(fd_dir);

    for (size_t i = 0; i < n; i++) {
        if (shim_close_observed_fd(fds[i]) != 0) {
            int saved = errno;
            free(fds);
            errno = saved;
            return -1;
        }
    }
    free(fds);
    log_line("close_range observed fds and preserved profile holds "
             "first=%u last=%u flags=0x%x",
             first, last, flags);
    return 0;
}

static long shim_close_range(unsigned int first, unsigned int last,
                             unsigned int flags) {
    ensure_syms_resolved();
    if (last < first) {
        errno = EINVAL;
        return -1;
    }
    if (flags & ~(CLOSE_RANGE_UNSHARE | CLOSE_RANGE_CLOEXEC)) {
        errno = EINVAL;
        return -1;
    }

    if (flags & CLOSE_RANGE_CLOEXEC) {
        in_shim = 1;
        long ret = real_syscall(SYS_close_range, first, last, flags);
        int saved_errno = errno;
        in_shim = 0;
        errno = saved_errno;
        return ret;
    }

    /* Every real close must retire the fd from the shim's typed tables and
     * from each program's attachment lists.  A direct close_range syscall
     * leaves stale raw-tracepoint/link/perf attachment fds behind; after the
     * kernel reuses one of those fd numbers, live replacement tries to replay
     * a detached attachment using unrelated state.  Enumerating the open
     * range also lets the profiling path preserve its private hold fds. */
    return shim_close_range_observed(first, last, flags);
}

static void log_prog_array_update(const union bpf_attr *attr, long ret,
                                  int saved_errno) {
    if (!attr)
        return;

    char map_name[17] = {0};
    uint32_t map_type = 0;
    uint32_t key_size = 0;
    uint32_t value_size = 0;
    uint32_t map_id = 0;
    ensure_syms_resolved();
    if (!real_syscall)
        return;

    /* A loader can close a map fd and later reuse the same integer for a
     * BPF_OBJ_GET of another map. The creation-time fd table is therefore
     * only a capture aid, never authoritative for an update syscall. */
    struct bpf_map_info info;
    memset(&info, 0, sizeof(info));
    union bpf_attr info_attr = {0};
    info_attr.info.bpf_fd = attr->map_fd;
    info_attr.info.info_len = sizeof(info);
    info_attr.info.info = (uintptr_t)&info;
    long info_ret = real_syscall(SYS_bpf, BPF_OBJ_GET_INFO_BY_FD,
                                 &info_attr, sizeof(info_attr));
    if (info_ret < 0)
        return;

    map_type = info.type;
    key_size = info.key_size;
    value_size = info.value_size;
    map_id = info.id;
    memcpy(map_name, info.name, sizeof(map_name) - 1);

    if (map_type != BPF_MAP_TYPE_PROG_ARRAY || key_size != sizeof(uint32_t) ||
        value_size != sizeof(uint32_t) || attr->key == 0 || attr->value == 0) {
        return;
    }

    uint32_t key = 0;
    uint32_t prog_fd = 0;
    memcpy(&key, (const void *)(uintptr_t)attr->key, sizeof(key));
    memcpy(&prog_fd, (const void *)(uintptr_t)attr->value, sizeof(prog_fd));

    uint32_t prog_id = 0;
    pthread_mutex_lock(&state_mutex);
    struct prog_entry *prog = prog_find((int)prog_fd);
    if (prog)
        prog_id = prog->kernel_prog_id;
    pthread_mutex_unlock(&state_mutex);
    if (prog_id == 0)
        prog_id = resolve_kernel_id((int)prog_fd);

    log_line("BPF_MAP_UPDATE_ELEM prog_array name=%s map_fd=%u map_id=%u key=%u "
             "prog_fd=%u prog_id=%u flags=%llu ret=%ld errno=%d",
             map_name, attr->map_fd, map_id, key, prog_fd, prog_id,
             (unsigned long long)attr->flags, ret,
             ret < 0 ? saved_errno : 0);
    kmsg_line("BPF_MAP_UPDATE_ELEM prog_array name=%s map_fd=%u map_id=%u key=%u "
              "prog_fd=%u prog_id=%u flags=%llu ret=%ld errno=%d",
              map_name, attr->map_fd, map_id, key, prog_fd, prog_id,
              (unsigned long long)attr->flags, ret,
              ret < 0 ? saved_errno : 0);
    if (ret >= 0)
        shim_native_loader_log_jit_info("prog_array-target", (int)prog_fd);
    if (ret >= 0 && map_id != 0 && prog_id != 0) {
        pthread_mutex_lock(&state_mutex);
        int track_rc = prog_array_slot_upsert(map_id, key, prog_id);
        pthread_mutex_unlock(&state_mutex);
        if (track_rc != 0)
            log_line("failed to track prog_array map_id=%u key=%u prog_id=%u",
                     map_id, key, prog_id);
    }
}

static int is_u32_prog_array_fd(uint32_t map_fd) {
    struct bpf_map_info info;
    memset(&info, 0, sizeof(info));
    union bpf_attr info_attr = {0};
    info_attr.info.bpf_fd = map_fd;
    info_attr.info.info_len = sizeof(info);
    info_attr.info.info = (uintptr_t)&info;
    if (real_syscall(SYS_bpf, BPF_OBJ_GET_INFO_BY_FD, &info_attr,
                     sizeof(info_attr)) < 0) {
        return 0;
    }

    return info.type == BPF_MAP_TYPE_PROG_ARRAY &&
           info.key_size == sizeof(uint32_t) &&
           info.value_size == sizeof(uint32_t);
}

static void track_prog_array_delete(const union bpf_attr *attr, long ret) {
    if (!attr || ret < 0 || attr->key == 0)
        return;
    struct bpf_map_info info;
    memset(&info, 0, sizeof(info));
    union bpf_attr info_attr = {0};
    info_attr.info.bpf_fd = attr->map_fd;
    info_attr.info.info_len = sizeof(info);
    info_attr.info.info = (uintptr_t)&info;
    if (real_syscall(SYS_bpf, BPF_OBJ_GET_INFO_BY_FD, &info_attr,
                     sizeof(info_attr)) < 0)
        return;
    if (info.type != BPF_MAP_TYPE_PROG_ARRAY ||
        info.key_size != sizeof(uint32_t))
        return;
    uint32_t key = 0;
    memcpy(&key, (const void *)(uintptr_t)attr->key, sizeof(key));
    pthread_mutex_lock(&state_mutex);
    prog_array_slot_remove(info.id, key);
    pthread_mutex_unlock(&state_mutex);
}

__attribute__((constructor)) static void shim_init(void) {
    real_syscall = dlsym(RTLD_NEXT, "syscall");
    real_ioctl = dlsym(RTLD_NEXT, "ioctl");
    real_close = dlsym(RTLD_NEXT, "close");

    /* Auto-create the bytecode dump dir. */
    const char *dir = getenv("BPFREJIT_SHIM_DIR");
    if (!dir) dir = "/tmp";
    mkdir(dir, 0755); /* idempotent */

    const char *log_path = getenv("BPFREJIT_SHIM_LOG");
    if (!log_path)
        log_path = "/tmp/bpfrejit_shim.log";
    log_file = fopen(log_path, "a");
    if (log_file) {
        setvbuf(log_file, NULL, _IOLBF, 0);
        char exe[256] = {0};
        ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
        if (n > 0) exe[n] = 0;
        log_line("shim_init pid=%d exe=%s", getpid(), exe);
        kmsg_line("shim-init exe=%s", exe);
    }

    /* Periodic dump worker, if enabled by env. */
    pthread_t tid;
    pthread_create(&tid, NULL, worker_thread, NULL);
    pthread_detach(tid);

    /* Socket server thread — per-pid app-level shim socket.
     * Disable by setting BPFREJIT_SHIM_SOCK_DISABLE=1. */
    if (!getenv("BPFREJIT_SHIM_SOCK_DISABLE")) {
        pthread_t stid;
        pthread_create(&stid, NULL, socket_thread, NULL);
        pthread_detach(stid);
    }
}

/* Intercept syscall(2). */
long syscall(long number, ...) {
    /* Forward 6 long args verbatim — kernel-side ABI takes <= 6, reading
     * unused-but-not-passed va_args is UB but practically safe on x86_64
     * because syscall(2) callers always pass through the same register
     * convention. We do not introspect args for non-bpf syscalls. */
    ensure_syms_resolved();
    va_list ap;
    va_start(ap, number);
    long a0 = va_arg(ap, long);
    long a1 = va_arg(ap, long);
    long a2 = va_arg(ap, long);
    long a3 = va_arg(ap, long);
    long a4 = va_arg(ap, long);
    long a5 = va_arg(ap, long);
    va_end(ap);

    if (!in_shim && number == SYS_close)
        return shim_close_observed_fd((int)a0);

    if (!in_shim && number == SYS_close_range)
        return shim_close_range((unsigned int)a0, (unsigned int)a1,
                                (unsigned int)a2);

    if (in_shim || number != SYS_bpf) {
        if (number == SYS_perf_event_open && !in_shim) {
            const struct perf_event_attr *pa =
                (const struct perf_event_attr *)a0;
            pid_t pid = (pid_t)a1;
            int cpu = (int)a2;
            int group_fd = (int)a3;
            unsigned long flags = (unsigned long)a4;
            in_shim = 1;
            long ret = real_syscall(number, a0, a1, a2, a3, a4, a5);
            int saved_errno = errno;
            if (ret >= 0 && pa) {
                struct perf_entry *e = (struct perf_entry *)calloc(1, sizeof(*e));
                if (e) {
                    e->fd = (int)ret;
                    e->type = pa->type;
                    e->config = pa->config;
                    e->pid = pid;
                    e->cpu = cpu;
                    e->group_fd = group_fd;
                    e->open_flags = (uint32_t)flags;
                    e->attached_prog_fd = -1;
                    /* Save the full perf_event_attr so reload_and_reattach
                     * can recreate the event when SET_BPF rejects replacement. */
                    uint32_t asize = pa->size;
                    if (asize == 0 || asize > sizeof(e->attr_blob))
                        asize = sizeof(e->attr_blob);
                    if (asize > sizeof(struct perf_event_attr))
                        asize = sizeof(struct perf_event_attr);
                    memcpy(e->attr_blob, pa, asize);
                    e->attr_size = asize;
                    copy_perf_probe_target(pa, e->probe_target,
                                           sizeof(e->probe_target));
                    pthread_mutex_lock(&state_mutex);
                    shim_forget_fd_state_locked(e->fd);
                    perf_insert(e);
                    pthread_mutex_unlock(&state_mutex);
                }
            }
            in_shim = 0;
            char perf_extra[192];
            format_perf_event_extra(pa, perf_extra, sizeof(perf_extra));
            log_line("perf_event_open type=%u config=%llu config1=%llu "
                     "config2=%llu pid=%d cpu=%d group_fd=%d flags=%lu%s "
                     "-> fd=%ld errno=%d",
                     pa ? pa->type : 0,
                     pa ? (unsigned long long)pa->config : 0,
                     pa ? (unsigned long long)pa->config1 : 0,
                     pa ? (unsigned long long)pa->config2 : 0, pid, cpu,
                     group_fd, flags, perf_extra, ret,
                     ret < 0 ? saved_errno : 0);
            kmsg_line("perf-open type=%u config=%llu config1=%llu "
                      "config2=%llu pid=%d cpu=%d group_fd=%d flags=%lu%s "
                      "ret=%ld errno=%d",
                      pa ? pa->type : 0,
                      pa ? (unsigned long long)pa->config : 0,
                      pa ? (unsigned long long)pa->config1 : 0,
                      pa ? (unsigned long long)pa->config2 : 0, pid, cpu,
                      group_fd, flags, perf_extra, ret,
                      ret < 0 ? saved_errno : 0);
            errno = saved_errno;
            return ret;
        }
        return real_syscall(number, a0, a1, a2, a3, a4, a5);
    }

    int cmd = (int)a0;
    union bpf_attr *attr = (union bpf_attr *)a1;
    unsigned int size = (unsigned int)a2;

    /* libbpf callers may reuse a bpf_attr and its key/value storage from
     * another thread as soon as the real syscall returns. Prog-array state
     * must therefore not dereference caller-owned memory after that point:
     * use one pre-call snapshot for both the kernel operation and the shim's
     * post-call attachment bookkeeping. */
    union bpf_attr stable_prog_array_attr;
    uint32_t stable_prog_array_key = 0;
    uint32_t stable_prog_array_value = 0;
    if (!in_shim && attr &&
        (cmd == BPF_MAP_UPDATE_ELEM || cmd == BPF_MAP_DELETE_ELEM)) {
        memset(&stable_prog_array_attr, 0, sizeof(stable_prog_array_attr));
        size_t attr_copy_size = size;
        if (attr_copy_size > sizeof(stable_prog_array_attr))
            attr_copy_size = sizeof(stable_prog_array_attr);
        memcpy(&stable_prog_array_attr, attr, attr_copy_size);
        if (stable_prog_array_attr.key != 0 &&
            (cmd != BPF_MAP_UPDATE_ELEM ||
             stable_prog_array_attr.value != 0) &&
            is_u32_prog_array_fd(stable_prog_array_attr.map_fd)) {
            memcpy(&stable_prog_array_key,
                   (const void *)(uintptr_t)stable_prog_array_attr.key,
                   sizeof(stable_prog_array_key));
            stable_prog_array_attr.key =
                (uintptr_t)&stable_prog_array_key;
            if (cmd == BPF_MAP_UPDATE_ELEM) {
                memcpy(&stable_prog_array_value,
                       (const void *)(uintptr_t)stable_prog_array_attr.value,
                       sizeof(stable_prog_array_value));
                stable_prog_array_attr.value =
                    (uintptr_t)&stable_prog_array_value;
            }
            attr = &stable_prog_array_attr;
            a1 = (long)(uintptr_t)attr;
        }
    }

    if (!in_shim && cmd == BPF_OBJ_GET_INFO_BY_FD && attr) {
        int query_fd = (int)attr->info.bpf_fd;
        int original_info_fd = -1;
        int is_prog_fd = fd_is_bpf_prog(query_fd);
        uint32_t actual_prog_id = 0;
        if (is_prog_fd) {
            int probe_errno = errno;
            actual_prog_id = resolve_kernel_id(query_fd);
            errno = probe_errno;
        }
        pthread_mutex_lock(&state_mutex);
        struct prog_entry *pe = prog_find(query_fd);
        if (pe && is_prog_fd && actual_prog_id != 0 &&
            pe->kernel_prog_id == actual_prog_id &&
            pe->native_loader_original_fd >= 0) {
            original_info_fd = pe->native_loader_original_fd;
        } else if (pe && (!is_prog_fd ||
                          (actual_prog_id != 0 &&
                           pe->kernel_prog_id != actual_prog_id))) {
            prog_forget_loader_fd(query_fd);
        }
        pthread_mutex_unlock(&state_mutex);
        if (original_info_fd >= 0) {
            union bpf_attr rewritten = *attr;
            rewritten.info.bpf_fd = (uint32_t)original_info_fd;
            in_shim = 1;
            long info_ret = real_syscall(number, a0, &rewritten, a2,
                                         a3, a4, a5);
            int info_errno = errno;
            in_shim = 0;
            log_line("native-loader redirected OBJ_GET_INFO_BY_FD fd=%u "
                     "original_fd=%d -> ret=%ld errno=%d",
                     attr->info.bpf_fd, original_info_fd, info_ret,
                     info_ret < 0 ? info_errno : 0);
            errno = info_errno;
            return info_ret;
        }
    }

    struct shim_native_load_scope native_scope
        __attribute__((cleanup(shim_native_load_scope_end))) = {0};
    if (cmd == BPF_PROG_LOAD && attr && !in_shim &&
        shim_native_loader_enabled() && shim_native_loader_requires_bound_proof()) {
        native_scope.active = 1;
        __atomic_add_fetch(&shim_native_loads_inflight, 1, __ATOMIC_SEQ_CST);
    }

    /* Pre-call captures: one pending pointer per kind. Each capture_*
     * allocates a heap entry we insert into the corresponding table iff
     * the syscall succeeds. */
    struct prog_entry *pending_prog = NULL;
    struct map_entry *pending_map = NULL;
    struct link_entry *pending_link = NULL;
    struct raw_tp_entry *pending_raw_tp = NULL;
    struct loadtime_result loadtime = {0};
    int loadtime_active = 0;
    if (!in_shim && attr) {
        in_shim = 1;
        switch (cmd) {
        case BPF_PROG_LOAD:
            pending_prog = capture_prog_load(attr, size);
            break;
        case BPF_MAP_CREATE:
            pending_map = capture_map_create(attr);
            break;
        case BPF_LINK_CREATE:
            pending_link = capture_link_create(attr, size);
            log_line("BPF_LINK_CREATE prog_fd=%u target_fd=%u attach_type=%u "
                     "flags=%u",
                     attr->link_create.prog_fd, attr->link_create.target_fd,
                     attr->link_create.attach_type, attr->link_create.flags);
            kmsg_line("attach link-create begin prog_fd=%u target_fd=%u "
                      "attach_type=%u flags=%u",
                      attr->link_create.prog_fd, attr->link_create.target_fd,
                      attr->link_create.attach_type,
                      attr->link_create.flags);
            break;
        case BPF_LINK_UPDATE:
            on_link_update(attr);
            break;
        case BPF_PROG_ATTACH:
            on_prog_attach(attr);
            break;
        case BPF_RAW_TRACEPOINT_OPEN:
            pending_raw_tp = capture_raw_tp_open(attr);
            if (pending_raw_tp)
                kmsg_line("attach raw-tp begin name=%s prog_fd=%u",
                          pending_raw_tp->name, pending_raw_tp->prog_fd);
            break;
        default:
            break;
        }
        if (cmd == BPF_PROG_LOAD && pending_prog) {
            if (capture_prog_load_exact_map_refs(pending_prog, attr) != 0) {
                in_shim = 0;
                log_line("failed to capture BPF_PROG_LOAD map refs");
                prog_free(pending_prog);
                errno = EINVAL;
                return -1;
            }
            char opt_err[512];
            int opt_rc = loadtime_optimize_prog_load(
                attr, size, pending_prog->policy_hash, &loadtime, opt_err,
                sizeof(opt_err));
            if (opt_rc < 0) {
                in_shim = 0;
                log_line("loadtime optimization failed: %s", opt_err);
                prog_free(pending_prog);
                errno = EINVAL;
                return -1;
            }
            loadtime_active = opt_rc > 0;
        }
        in_shim = 0;
    }

    in_shim = 1;
    long ret = real_syscall(number, a0,
                            loadtime_active ? (long)(uintptr_t)loadtime.attr_buf : a1,
                            loadtime_active ? (long)loadtime.attr_size : a2,
                            a3, a4, a5);
    int saved_errno = errno;

    uint32_t resolved_id = 0;
    if (pending_prog) {
        if (ret >= 0) {
            long native_ret =
                shim_maybe_replace_with_native_fd(ret, pending_prog);
            if (native_ret < 0) {
                int native_errno = errno;
                real_close((int)ret);
                prog_free(pending_prog);
                if (loadtime_active)
                    loadtime_result_free(&loadtime);
                in_shim = 0;
                errno = native_errno;
                return -1;
            }
            ret = native_ret;
            pending_prog->fd = (int)ret;
            resolved_id = resolve_kernel_id((int)ret);
            pending_prog->kernel_prog_id = resolved_id;
            if (shim_pgo_hold_prog_fds_enabled()) {
                int hold_fd = fcntl((int)ret, F_DUPFD_CLOEXEC, 3);
                if (hold_fd < 0) {
                    int hold_errno = errno;
                    real_close((int)ret);
                    prog_free(pending_prog);
                    if (loadtime_active)
                        loadtime_result_free(&loadtime);
                    in_shim = 0;
                    errno = hold_errno;
                    return -1;
                }
                pending_prog->profile_hold_fd = hold_fd;
                log_line("PGO hold fd retained app_fd=%ld hold_fd=%d kid=%u",
                         ret, hold_fd, resolved_id);
            }
            /* Capture only the maps THIS prog actually references. Earlier we
             * enumerated all of /proc/self/fd, but for a long-lived loader
             * (e.g. tracee with 158 progs) that snapshot accumulates every
             * map fd ever opened (hundreds), and the kernel rejects PROG_LOAD
             * with -E2BIG once nr_maps > MAX_USED_MAPS=64. Use the prog's own
             * used_maps list (kernel-authoritative) and only map those ids
             * back to loader fds via a single /proc/self/fd scan. */
            int map_info_fd =
                pending_prog->native_loader_original_fd >= 0
                    ? pending_prog->native_loader_original_fd
                    : (int)ret;
            uint32_t pmap_ids[64] = {0};
            uint32_t pmap_n = 0;
            {
                struct bpf_prog_info pi;
                memset(&pi, 0, sizeof(pi));
                pi.nr_map_ids = 64;
                pi.map_ids = (uintptr_t)pmap_ids;
                union bpf_attr pa = {0};
                pa.info.bpf_fd = (uint32_t)map_info_fd;
                pa.info.info_len = sizeof(pi);
                pa.info.info = (uintptr_t)&pi;
                long pr = real_syscall(SYS_bpf, BPF_OBJ_GET_INFO_BY_FD,
                                       &pa, sizeof(pa));
                if (pr >= 0) {
                    pmap_n = pi.nr_map_ids;
                    if (pmap_n > 64) pmap_n = 64;
                }
            }
            if (pending_prog->snap_n == 0) {
                uint32_t cap = pmap_n ? pmap_n : 1, n = 0;
                uint32_t *fds = (uint32_t *)calloc(cap, sizeof(uint32_t));
                uint32_t *kids = (uint32_t *)calloc(cap, sizeof(uint32_t));
                uint32_t *types = (uint32_t *)calloc(cap, sizeof(uint32_t));
                DIR *fd_dir = pmap_n > 0 ? opendir("/proc/self/fd") : NULL;
                if (fd_dir && fds && kids && types) {
                    struct dirent *de;
                    while ((de = readdir(fd_dir)) != NULL && n < pmap_n) {
                        if (de->d_name[0] < '0' || de->d_name[0] > '9') continue;
                        int probe_fd = atoi(de->d_name);
                        if (probe_fd < 0) continue;
                        char fdpath[64], link_target[64];
                        snprintf(fdpath, sizeof(fdpath), "/proc/self/fd/%d", probe_fd);
                        ssize_t lr = readlink(fdpath, link_target, sizeof(link_target) - 1);
                        if (lr <= 0) continue;
                        link_target[lr] = 0;
                        if (strcmp(link_target, "anon_inode:bpf-map") != 0) continue;
                        struct bpf_map_info mi;
                        memset(&mi, 0, sizeof(mi));
                        union bpf_attr ia = {0};
                        ia.info.bpf_fd = (uint32_t)probe_fd;
                        ia.info.info_len = sizeof(mi);
                        ia.info.info = (uintptr_t)&mi;
                        long r = real_syscall(SYS_bpf, BPF_OBJ_GET_INFO_BY_FD,
                                              &ia, sizeof(ia));
                        if (r < 0 || mi.id == 0) continue;
                        /* Only keep fds whose kernel map id is in this prog's
                         * used_maps list. */
                        int wanted = 0;
                        for (uint32_t i = 0; i < pmap_n; i++)
                            if (pmap_ids[i] == mi.id) { wanted = 1; break; }
                        if (!wanted) continue;
                        /* Skip duplicates — multiple loader fds may alias the
                         * same kernel id; one representative is enough for
                         * non-fd-immediate discovery. */
                        int dup = 0;
                        for (uint32_t i = 0; i < n; i++)
                            if (kids[i] == mi.id) { dup = 1; break; }
                        if (dup) continue;
                        fds[n] = (uint32_t)probe_fd;
                        kids[n] = mi.id;
                        types[n] = mi.type;
                        n++;
                    }
                    pending_prog->snap_fds = fds;
                    pending_prog->snap_kids = kids;
                    pending_prog->snap_types = types;
                    pending_prog->snap_n = n;
                } else {
                    free(fds); free(kids); free(types);
                }
                if (fd_dir) closedir(fd_dir);
            }
            pthread_mutex_lock(&state_mutex);
            shim_forget_fd_state_locked(pending_prog->fd);
            prog_insert(pending_prog);
            pthread_mutex_unlock(&state_mutex);
        } else {
            free(pending_prog);
            pending_prog = NULL;
        }
    }
    if (pending_map) {
        if (ret >= 0) {
            pending_map->fd = (int)ret;
            resolved_id = resolve_kernel_id((int)ret);
            pending_map->kernel_map_id = resolved_id;
            pthread_mutex_lock(&state_mutex);
            shim_forget_fd_state_locked(pending_map->fd);
            map_insert(pending_map);
            pthread_mutex_unlock(&state_mutex);
        } else {
            free(pending_map);
        }
    }
    if (pending_link) {
        if (ret >= 0) {
            uint32_t attached_prog_id =
                resolve_kernel_id((int)pending_link->prog_fd);
            pending_link->fd = (int)ret;
            resolved_id = resolve_kernel_id((int)ret);
            pending_link->kernel_link_id = resolved_id;
            if (pending_link->attach_type == BPF_PERF_EVENT) {
                long hold_fd = real_syscall(
                    SYS_fcntl, (int)pending_link->target_fd,
                    F_DUPFD_CLOEXEC, 3);
                if (hold_fd >= 0) {
                    pending_link->target_hold_fd = (int)hold_fd;
                    log_line("BPF_PERF_EVENT target retained target_fd=%u "
                             "hold_fd=%ld link_fd=%ld",
                             pending_link->target_fd, hold_fd, ret);
                } else {
                    log_line("BPF_PERF_EVENT target retain failed "
                             "target_fd=%u link_fd=%ld errno=%d",
                             pending_link->target_fd, ret, errno);
                }
            }
            pthread_mutex_lock(&state_mutex);
            shim_forget_fd_state_locked(pending_link->fd);
            link_insert(pending_link);
            /* Record this attach on the prog so reload_and_reattach can
             * BPF_LINK_UPDATE us to the optimized prog later. */
            struct prog_entry *pe = prog_find_attachment_target(
                (int)pending_link->prog_fd, attached_prog_id);
            if (pe)
                (void)prog_attach_append(&pe->attached_link_fds,
                                         &pe->n_links, (int)ret);
            else
                log_line("BPF_LINK_CREATE attachment prog_fd=%u kid=%u "
                         "has no tracked prog_entry",
                         pending_link->prog_fd, attached_prog_id);
            if (pending_link->attach_type == BPF_PERF_EVENT) {
                struct perf_entry *target =
                    perf_find((int)pending_link->target_fd);
                if (target && target->attr_size > 0) {
                    memcpy(pending_link->target_perf_attr_blob,
                           target->attr_blob, target->attr_size);
                    pending_link->target_perf_attr_size = target->attr_size;
                    pending_link->target_perf_pid = target->pid;
                    pending_link->target_perf_cpu = target->cpu;
                    pending_link->target_perf_group_fd = target->group_fd;
                    pending_link->target_perf_open_flags = target->open_flags;
                    snprintf(pending_link->target_perf_probe_target,
                             sizeof(pending_link->target_perf_probe_target),
                             "%s", target->probe_target);
                }
            }
            pthread_mutex_unlock(&state_mutex);
            if (pending_link->attach_type == BPF_PERF_EVENT)
                log_task_fd_query(pending_link->target_fd,
                                  pending_link->attach_type);
        } else {
            link_entry_free(pending_link);
        }
    }
    if (cmd == BPF_PROG_ATTACH && ret >= 0 && attr) {
        uint32_t attached_prog_id =
            resolve_kernel_id((int)attr->attach_bpf_fd);
        pthread_mutex_lock(&state_mutex);
        struct prog_entry *pe = prog_find_attachment_target(
            (int)attr->attach_bpf_fd, attached_prog_id);
        if (pe) {
            struct prog_attach_point point = {
                .target_fd = (int)attr->target_fd,
                .attach_type = attr->attach_type,
                .attach_flags = attr->attach_flags,
            };
            (void)prog_attach_point_append(&pe->prog_attaches,
                                           &pe->n_prog_attaches, point);
        }
        pthread_mutex_unlock(&state_mutex);
    }
    if (pending_raw_tp) {
        if (ret >= 0) {
            uint32_t attached_prog_id =
                resolve_kernel_id((int)pending_raw_tp->prog_fd);
            pending_raw_tp->fd = (int)ret;
            pending_raw_tp->prog_id = attached_prog_id;
            pthread_mutex_lock(&state_mutex);
            shim_forget_fd_state_locked(pending_raw_tp->fd);
            raw_tp_insert(pending_raw_tp);
            struct prog_entry *pe = prog_find_attachment_target(
                (int)pending_raw_tp->prog_fd, attached_prog_id);
            if (pe)
                (void)prog_attach_append(&pe->attached_raw_tp_fds,
                                         &pe->n_raw_tps, (int)ret);
            pthread_mutex_unlock(&state_mutex);
        } else {
            free(pending_raw_tp);
        }
    }
    if (cmd == BPF_MAP_UPDATE_ELEM && attr)
        log_prog_array_update(attr, ret, saved_errno);
    if (cmd == BPF_MAP_DELETE_ELEM && attr)
        track_prog_array_delete(attr, ret);
    if (cmd == BPF_LINK_UPDATE && ret >= 0 && attr)
        (void)track_successful_link_update(attr);
    in_shim = 0;
    if (loadtime_active)
        loadtime_result_free(&loadtime);

    if (cmd == BPF_PROG_LOAD) {
        log_line("  PROG_LOAD -> fd=%ld errno=%d kernel_prog_id=%u", ret,
                 ret < 0 ? saved_errno : 0, resolved_id);
        if (pending_prog)
            kmsg_line("prog-load done name=%s ret=%ld errno=%d kid=%u",
                      pending_prog->name, ret, ret < 0 ? saved_errno : 0,
                      resolved_id);
    } else if (cmd == BPF_LINK_CREATE) {
        log_line("  LINK_CREATE -> fd=%ld errno=%d kernel_link_id=%u", ret,
                 ret < 0 ? saved_errno : 0, resolved_id);
        if (attr)
            kmsg_line("attach link-create done prog_fd=%u target_fd=%u "
                      "attach_type=%u ret=%ld errno=%d kid=%u",
                      attr->link_create.prog_fd, attr->link_create.target_fd,
                      attr->link_create.attach_type, ret,
                      ret < 0 ? saved_errno : 0, resolved_id);
    } else if (cmd == BPF_LINK_UPDATE) {
        log_line("  LINK_UPDATE -> ret=%ld errno=%d", ret,
                 ret < 0 ? saved_errno : 0);
    } else if (cmd == BPF_MAP_CREATE) {
        log_line("  MAP_CREATE -> fd=%ld errno=%d kernel_map_id=%u", ret,
                 ret < 0 ? saved_errno : 0, resolved_id);
    } else if (cmd == BPF_PROG_ATTACH) {
        log_line("  PROG_ATTACH -> ret=%ld errno=%d", ret,
                 ret < 0 ? saved_errno : 0);
        if (attr)
            kmsg_line("attach prog-attach done target_fd=%u prog_fd=%u "
                      "attach_type=%u ret=%ld errno=%d",
                      attr->target_fd, attr->attach_bpf_fd,
                      attr->attach_type, ret, ret < 0 ? saved_errno : 0);
    } else if (cmd == BPF_RAW_TRACEPOINT_OPEN) {
        log_line("  RAW_TRACEPOINT_OPEN -> fd=%ld errno=%d", ret,
                 ret < 0 ? saved_errno : 0);
        if (attr) {
            const char *name = attr->raw_tracepoint.name
                                   ? (const char *)(uintptr_t)attr->raw_tracepoint.name
                                   : "";
            kmsg_line("attach raw-tp done name=%.*s prog_fd=%u ret=%ld errno=%d",
                      80, name, attr->raw_tracepoint.prog_fd, ret,
                      ret < 0 ? saved_errno : 0);
        }
    }

    errno = saved_errno;
    return ret;
}

/* Intercept ioctl(2) to catch PERF_EVENT_IOC_SET_BPF on perf_event fds. */
int ioctl(int fd, unsigned long request, ...) {
    ensure_syms_resolved();
    void *arg;
    va_list ap;
    va_start(ap, request);
    arg = va_arg(ap, void *);
    va_end(ap);

    if (!in_shim) {
        if (request == PERF_EVENT_IOC_SET_BPF) {
            int prog_fd = (int)(intptr_t)arg;
            log_line("PERF_EVENT_IOC_SET_BPF event_fd=%d prog_fd=%d", fd,
                     prog_fd);
            kmsg_line("attach perf-set-bpf begin event_fd=%d prog_fd=%d",
                      fd, prog_fd);
        } else if (request == PERF_EVENT_IOC_ENABLE) {
            log_line("PERF_EVENT_IOC_ENABLE event_fd=%d", fd);
        } else if (request == PERF_EVENT_IOC_DISABLE) {
            log_line("PERF_EVENT_IOC_DISABLE event_fd=%d", fd);
        }
    }

    in_shim = 1;
    int ret = real_ioctl(fd, request, arg);
    int saved_errno = errno;
    in_shim = 0;

    if (request == PERF_EVENT_IOC_SET_BPF) {
        if (ret == 0) {
            int prog_fd = (int)(intptr_t)arg;
            uint32_t attached_prog_id = resolve_kernel_id(prog_fd);
            pthread_mutex_lock(&state_mutex);
            struct perf_entry *e = perf_find(fd);
            if (!e) {
                /* perf_event was opened before the shim attached (early
                 * constructor, fd inherited from a parent, etc.) — recover
                 * the attr from /proc/self/fdinfo/<fd>. This is best-effort:
                 * we only need type+config for perf_event_open re-creation
                 * during reload_and_reattach. */
                char fdpath[64], line[256];
                snprintf(fdpath, sizeof(fdpath), "/proc/self/fdinfo/%d", fd);
                FILE *fpi = fopen(fdpath, "r");
                if (fpi) {
                    struct perf_event_attr attr;
                    memset(&attr, 0, sizeof(attr));
                    attr.size = sizeof(attr);
                    int got = 0;
                    while (fgets(line, sizeof(line), fpi)) {
                        unsigned long long v;
                        if (sscanf(line, "attr_type: %llu", &v) == 1) {
                            attr.type = (uint32_t)v; got |= 1;
                        } else if (sscanf(line, "attr_config: %llu", &v) == 1) {
                            attr.config = (uint64_t)v; got |= 2;
                        } else if (sscanf(line, "attr_config1: %llu", &v) == 1) {
                            attr.config1 = (uint64_t)v;
                        } else if (sscanf(line, "attr_config2: %llu", &v) == 1) {
                            attr.config2 = (uint64_t)v;
                        }
                    }
                    fclose(fpi);
                    if ((got & 3) == 3) {
                        e = (struct perf_entry *)calloc(1, sizeof(*e));
                        if (e) {
                            e->fd = fd;
                            e->type = attr.type;
                            e->config = attr.config;
                            e->pid = -1;
                            e->cpu = -1;
                            e->group_fd = -1;
                            e->open_flags = 0;
                            e->attached_prog_fd = -1;
                            memcpy(e->attr_blob, &attr, sizeof(attr));
                            e->attr_size = sizeof(attr);
                            perf_insert(e);
                            log_line("perf recover from fdinfo: fd=%d "
                                     "type=%u config=%llu",
                                     fd, attr.type,
                                     (unsigned long long)attr.config);
                        }
                    }
                }
            }
            if (e) e->attached_prog_fd = prog_fd;
            /* Record this attach on the prog so reload_and_reattach can
             * re-issue SET_BPF with the optimized prog fd later. */
            struct prog_entry *pe = prog_find_attachment_target(
                prog_fd, attached_prog_id);
            if (pe)
                (void)prog_attach_append(&pe->attached_perf_fds,
                                         &pe->n_perfs, fd);
            pthread_mutex_unlock(&state_mutex);
        }
        log_line("  PERF_EVENT_IOC_SET_BPF -> ret=%d errno=%d", ret,
                 ret < 0 ? saved_errno : 0);
        kmsg_line("attach perf-set-bpf done event_fd=%d prog_fd=%d ret=%d "
                  "errno=%d",
                  fd, (int)(intptr_t)arg, ret, ret < 0 ? saved_errno : 0);
    }

    errno = saved_errno;
    return ret;
}

/* Drop or insert an XDP attach record for `prog_fd`. Holds state_mutex
 * for the duration; safe to call without external locking. `prog_fd<0`
 * variant (detach) is dispatched via prog_xdp_detach_by_ifindex below. */
static void prog_xdp_attach_set(int prog_fd, uint32_t ifindex,
                                uint32_t xdp_flags, int old_prog_fd) {
    pthread_mutex_lock(&state_mutex);
    struct prog_entry *p = prog_find(prog_fd);
    if (!p) {
        pthread_mutex_unlock(&state_mutex);
        log_line("netlink RTM_SETLINK IFLA_XDP_FD=%d ifindex=%u: no known "
                 "prog_entry — attach won't survive reload",
                 prog_fd, ifindex);
        return;
    }
    /* Dedup by ifindex; newest flags + old_prog_fd win. */
    for (uint32_t i = 0; i < p->n_xdp; i++) {
        if (p->xdp_attaches[i].ifindex == ifindex) {
            p->xdp_attaches[i].xdp_flags = xdp_flags;
            uint32_t kid = p->kernel_prog_id;
            pthread_mutex_unlock(&state_mutex);
            log_line("netlink RTM_SETLINK update: prog_fd=%d kid=%u "
                     "ifindex=%u flags=0x%x", prog_fd, kid, ifindex, xdp_flags);
            return;
        }
    }
    struct xdp_nl_attach *grown =
        (struct xdp_nl_attach *)realloc(p->xdp_attaches,
                                        (p->n_xdp + 1) * sizeof(*grown));
    if (!grown) { pthread_mutex_unlock(&state_mutex); return; }
    grown[p->n_xdp].ifindex = ifindex;
    grown[p->n_xdp].xdp_flags = xdp_flags;
    p->xdp_attaches = grown;
    p->n_xdp++;
    uint32_t kid = p->kernel_prog_id;
    pthread_mutex_unlock(&state_mutex);
    log_line("netlink RTM_SETLINK captured: prog_fd=%d kid=%u ifindex=%u "
             "flags=0x%x (old_prog_fd=%d)", prog_fd, kid, ifindex,
             xdp_flags, old_prog_fd);
}

/* Drop the (ifindex) attach from any prog_entry that holds it. Called on
 * observed detach (IFLA_XDP_FD == -1). */
static void prog_xdp_detach_by_ifindex(uint32_t ifindex) {
    pthread_mutex_lock(&state_mutex);
    for (unsigned b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct prog_entry *p = prog_table[b]; p; p = p->next) {
            for (uint32_t i = 0; i < p->n_xdp; ) {
                if (p->xdp_attaches[i].ifindex == ifindex) {
                    p->xdp_attaches[i] = p->xdp_attaches[p->n_xdp - 1];
                    p->n_xdp--;
                } else {
                    i++;
                }
            }
        }
    }
    pthread_mutex_unlock(&state_mutex);
    log_line("netlink RTM_SETLINK detach observed: ifindex=%u dropped from "
             "all prog_entry xdp_attaches", ifindex);
}

/* Decide whether `sock_fd` is the kind of socket we want to inspect.
 * Cached lookup via getsockopt; the cost is one syscall per send call
 * which is dwarfed by netlink RTT. */
static int sock_is_rtnetlink(int sock_fd) {
    int domain = -1, protocol = -1;
    socklen_t slen = sizeof(domain);
    if (getsockopt(sock_fd, SOL_SOCKET, SO_DOMAIN, &domain, &slen) != 0)
        return 0;
    if (domain != AF_NETLINK) return 0;
    slen = sizeof(protocol);
    if (getsockopt(sock_fd, SOL_SOCKET, SO_PROTOCOL, &protocol, &slen) != 0)
        return 0;
    return protocol == NETLINK_ROUTE;
}

/* Inspect an outgoing rtnetlink message AFTER it succeeded. Records or
 * removes XDP attach state per IFLA_XDP_FD value. */
static void netlink_observe_xdp_post(int sock_fd, const void *buf, size_t len) {
    if (!buf || len < sizeof(struct nlmsghdr)) return;
    if (!sock_is_rtnetlink(sock_fd)) return;
    uint32_t ifindex = 0, flags = 0;
    int prog_fd = -1;
    if (!nl_parse_setlink_xdp_attach(buf, len, &ifindex, &prog_fd, &flags))
        return;
    if (prog_fd < 0) {
        /* Detach: drop attach record from whichever prog held this ifindex. */
        prog_xdp_detach_by_ifindex(ifindex);
        return;
    }
    /* Attach succeeded — record. old_prog_fd not known here; replay falls
     * back to non-EXPECTED replace mode. */
    prog_xdp_attach_set(prog_fd, ifindex, flags, -1);
}

ssize_t sendto(int sockfd, const void *buf, size_t len, int flags,
               const struct sockaddr *dest_addr, socklen_t addrlen) {
    ensure_syms_resolved();
    ssize_t ret = real_sendto(sockfd, buf, len, flags, dest_addr, addrlen);
    int saved_errno = errno;
    /* Only observe AFTER kernel accepted the message — pre-syscall observe
     * would record attaches that the kernel later rejects, leading to
     * phantom replay attempts during reload. */
    if (!in_shim && ret >= 0 && buf && (size_t)ret >= sizeof(struct nlmsghdr)) {
        in_shim = 1;
        netlink_observe_xdp_post(sockfd, buf, (size_t)ret);
        in_shim = 0;
    }
    errno = saved_errno;
    return ret;
}

ssize_t sendmsg(int sockfd, const struct msghdr *msg, int flags) {
    ensure_syms_resolved();
    ssize_t ret = real_sendmsg(sockfd, msg, flags);
    int saved_errno = errno;
    if (!in_shim && ret >= 0 && msg && msg->msg_iovlen > 0) {
        in_shim = 1;
        /* Linearise iovecs if the netlink message spans multiple iovs.
         * sendmsg lets the app scatter the request across iovecs and the
         * kernel reassembles; our parser needs a flat view. */
        size_t total = 0;
        const struct iovec *iov = msg->msg_iov;
        for (size_t i = 0; i < (size_t)msg->msg_iovlen; i++)
            total += iov[i].iov_len;
        if (total >= sizeof(struct nlmsghdr) && total <= (size_t)ret) {
            char stack_buf[4096];
            char *flat = (total <= sizeof(stack_buf))
                         ? stack_buf
                         : (char *)malloc(total);
            if (flat) {
                size_t off = 0;
                for (size_t i = 0; i < (size_t)msg->msg_iovlen && off < total; i++) {
                    size_t take = iov[i].iov_len;
                    if (off + take > total) take = total - off;
                    if (iov[i].iov_base) memcpy(flat + off, iov[i].iov_base, take);
                    off += take;
                }
                netlink_observe_xdp_post(sockfd, flat, total);
                if (flat != stack_buf) free(flat);
            }
        }
        in_shim = 0;
    }
    errno = saved_errno;
    return ret;
}

/* Intercept close(2): release table entries if any (cheap; fd is unique
 * across kinds so at most one removes a real entry). */
int close(int fd) {
    if (!in_shim)
        return shim_close_observed_fd(fd);
    ensure_syms_resolved();
    return real_close(fd);
}

int close_range(unsigned int first, unsigned int last, int flags) {
    if (!in_shim)
        return (int)shim_close_range(first, last, (unsigned int)flags);
    ensure_syms_resolved();
    return (int)real_syscall(SYS_close_range, first, last, flags);
}

/* Write a JSON snapshot of all tracked objects.
 * Invoked by the periodic worker thread (BPFREJIT_SHIM_PERIODIC_DUMP_MS) and
 * by the `dump_state` socket RPC. */
static void dump_state_json(void) {
    const char *dir = getenv("BPFREJIT_SHIM_DIR");
    if (!dir) dir = "/tmp";
    char path[512];
    snprintf(path, sizeof(path), "%s/state_%d.json", dir, getpid());
    char tmp_path[544];
    snprintf(tmp_path, sizeof(tmp_path), "%s.tmp", path);
    int fd = open(tmp_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return;
    FILE *f = fdopen(fd, "w");
    if (!f) {
        real_close(fd);
        return;
    }
    fprintf(f, "{\n  \"pid\": %d,\n  \"progs\": [", getpid());
    pthread_mutex_lock(&state_mutex);
    int first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct prog_entry *e = prog_table[b]; e; e = e->next) {
            fprintf(f, "%s\n    {\"fd\":%d,\"prog_type\":%u,\"name\":\"%s\","
                       "\"insn_cnt\":%u,\"hash\":\"%016lx\",\"policy_hash\":\"%016lx\","
                       "\"branch_profile_hash\":\"%016lx\","
                       "\"kernel_prog_id\":%u,\"bytecode_path\":\"%s\","
                       "\"expected_attach\":%u,\"attach_btf_id\":%u}",
                    first ? "" : ",", e->fd, e->prog_type, e->name,
                    e->insn_cnt, e->hash, e->policy_hash,
                    e->branch_profile_hash,
                    e->kernel_prog_id, e->bytecode_path,
                    e->expected_attach_type, e->attach_btf_id);
            first = 0;
        }
    }
    fprintf(f, "\n  ],\n  \"maps\": [");
    first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct map_entry *e = map_table[b]; e; e = e->next) {
            fprintf(f, "%s\n    {\"fd\":%d,\"map_type\":%u,\"name\":\"%s\","
                       "\"key_size\":%u,\"value_size\":%u,"
                       "\"max_entries\":%u,\"kernel_map_id\":%u}",
                    first ? "" : ",", e->fd, e->map_type, e->name,
                    e->key_size, e->value_size, e->max_entries,
                    e->kernel_map_id);
            first = 0;
        }
    }
    fprintf(f, "\n  ],\n  \"links\": [");
    first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct link_entry *e = link_table[b]; e; e = e->next) {
            fprintf(f, "%s\n    {\"fd\":%d,\"prog_fd\":%u,\"target_fd\":%u,"
                       "\"attach_type\":%u,\"kernel_link_id\":%u}",
                    first ? "" : ",", e->fd, e->prog_fd, e->target_fd,
                    e->attach_type, e->kernel_link_id);
            first = 0;
        }
    }
    fprintf(f, "\n  ],\n  \"perf_events\": [");
    first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct perf_entry *e = perf_table[b]; e; e = e->next) {
            fprintf(f, "%s\n    {\"fd\":%d,\"type\":%u,\"config\":%llu,"
                       "\"pid\":%d,\"cpu\":%d,\"attached_prog_fd\":%d}",
                    first ? "" : ",", e->fd, e->type,
                    (unsigned long long)e->config, e->pid, e->cpu,
                    e->attached_prog_fd);
            first = 0;
        }
    }
    pthread_mutex_unlock(&state_mutex);
    fprintf(f, "\n  ]\n}\n");
    if (fclose(f) != 0) {
        unlink(tmp_path);
        return;
    }
    if (rename(tmp_path, path) != 0) {
        unlink(tmp_path);
        return;
    }
    log_line("state dumped to %s", path);
}

/* =========================================================================
 * Socket server thread: per-pid JSON control socket.
 *
 * Path: $BPFREJIT_SHIM_SOCK_DIR/shim-<pid>.sock (default /var/run/bpfrejit/)
 *
 * Protocol: line-delimited JSON, one request per line, one response per line.
 *
 *   request:  {"cmd": "list_progs"}
 *   response: {"ok": true, "progs": [{"id": <kernel_prog_id>, "name": "...",
 *               "type": <prog_type>, "insn_cnt": ..., "hash": "...",
 *               "bytecode_path": "..."}]}
 *
 *   request:  {"cmd": "optimize", "enabled_passes": ["noop"]}
 *   response: {"ok": true, "passes": ["noop"]}
 *             (invokes bpfopt on all tracked progs; result via shim log)
 *
 *   request:  {"cmd": "dump_state"}
 *   response: {"ok": true, "path": "/tmp/dumps/state_<pid>.json"}
 *
 * Unknown cmd → {"ok": false, "error": "unknown cmd"}.
 *
 * Parsing is intentionally a tiny ad-hoc tokenizer; it accepts the field
 * subset listed above and ignores everything else. ===================== */

static int unix_socket_listen(const char *path) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0)
        return -1;
    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    snprintf(addr.sun_path, sizeof(addr.sun_path), "%s", path);
    unlink(path);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        real_close(fd);
        return -1;
    }
    if (listen(fd, 8) < 0) {
        real_close(fd);
        return -1;
    }
    return fd;
}

static void emit_list_progs(int cli) {
    discover_bpf_programs();
    pthread_mutex_lock(&state_mutex);
    size_t prog_count = 0;
    size_t slot_count = 0;
    size_t raw_tp_count = 0;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct prog_entry *e = prog_table[b]; e; e = e->next)
            prog_count++;
    }
    for (struct prog_array_slot *slot = prog_array_slots; slot;
         slot = slot->next)
        slot_count++;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++)
        for (struct raw_tp_entry *raw = raw_tp_table[b]; raw;
             raw = raw->next)
            raw_tp_count++;
    /* Names and paths are bounded in prog_entry; allocate once so an OOM
     * cannot leave a partially reallocated JSON buffer. */
    size_t cap = 160 + prog_count * 768 + slot_count * 192 +
                 raw_tp_count * 256;
    char *buf = (char *)malloc(cap);
    if (!buf) {
        pthread_mutex_unlock(&state_mutex);
        return;
    }
    size_t len = 0;
    len += snprintf(buf + len, cap - len,
                    "{\"ok\":true,\"native_loads_inflight\":%u,\"native_bound_completed\":%u,\"progs\":[",
                    __atomic_load_n(&shim_native_loads_inflight, __ATOMIC_SEQ_CST),
                    __atomic_load_n(&shim_native_bound_completed, __ATOMIC_SEQ_CST));
    int first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct prog_entry *e = prog_table[b]; e; e = e->next) {
            len += snprintf(
                buf + len, cap - len,
                "%s{\"id\":%u,\"name\":\"%s\",\"type\":%u,\"insn_cnt\":%u,"
                "\"hash\":\"%016lx\",\"policy_hash\":\"%016lx\","
                "\"branch_profile_hash\":\"%016lx\","
                "\"bytecode_path\":\"%s\"}",
                first ? "" : ",", e->kernel_prog_id, e->name,
                e->prog_type, e->insn_cnt, e->hash, e->policy_hash,
                e->branch_profile_hash,
                e->bytecode_path);
            first = 0;
        }
    }
    len += snprintf(buf + len, cap - len, "],\"prog_array_slots\":[");
    first = 1;
    for (struct prog_array_slot *slot = prog_array_slots; slot;
         slot = slot->next) {
        len += snprintf(buf + len, cap - len,
                        "%s{\"map_id\":%u,\"key\":%u,\"prog_id\":%u}",
                        first ? "" : ",", slot->map_id, slot->key,
                        slot->prog_id);
        first = 0;
    }
    len += snprintf(buf + len, cap - len, "],\"raw_tracepoints\":[");
    first = 1;
    for (int b = 0; b < BPF_STATE_BUCKETS; b++) {
        for (struct raw_tp_entry *raw = raw_tp_table[b]; raw;
             raw = raw->next) {
            len += snprintf(
                buf + len, cap - len,
                "%s{\"name\":\"%s\",\"prog_id\":%u}",
                first ? "" : ",", raw->name, raw->prog_id);
            first = 0;
        }
    }
    len += snprintf(buf + len, cap - len, "]}\n");
    pthread_mutex_unlock(&state_mutex);
    if (write(cli, buf, len) < 0) { /* best effort */ }
    free(buf);
}

#include "shim_reload.h"

#include "shim_measure.h"

#include "shim_execute_plan.h"

static void emit_dump_state(int cli) {
    dump_state_json();
    const char *dir = getenv("BPFREJIT_SHIM_DIR");
    if (!dir)
        dir = "/tmp";
    dprintf(cli, "{\"ok\":true,\"path\":\"%s/state_%d.json\"}\n", dir,
            getpid());
}

static void handle_client(int cli) {
    /* The runner can send arbitrarily large execute_plan payloads (e.g. tracee
     * with 158 progs × 18 steps × per-step bash command can exceed 100 KB).
     * Read until newline so we never truncate a request mid-JSON. */
    size_t cap = 16 * 1024;
    size_t len = 0;
    char *buf = (char *)malloc(cap);
    if (!buf) {
        dprintf(cli, "{\"ok\":false,\"error\":\"shim oom on request buf\"}\n");
        return;
    }
    while (1) {
        if (len + 1 >= cap) {
            size_t ncap = cap * 2;
            char *nb = (char *)realloc(buf, ncap);
            if (!nb) {
                free(buf);
                dprintf(cli, "{\"ok\":false,\"error\":\"shim oom on request grow\"}\n");
                return;
            }
            buf = nb; cap = ncap;
        }
        ssize_t n = read(cli, buf + len, cap - len - 1);
        if (n < 0) {
            if (errno == EINTR) continue;
            free(buf);
            return;
        }
        if (n == 0) break;
        len += (size_t)n;
        buf[len] = 0;
        if (memchr(buf, '\n', len) != NULL) break;
    }
    if (len == 0) { free(buf); return; }
    char cmd[64] = {0};
    if (!json_get_str(buf, "cmd", cmd, sizeof(cmd))) {
        dprintf(cli, "{\"ok\":false,\"error\":\"missing cmd\"}\n");
        free(buf);
        return;
    }
    log_line("socket: cmd=%s len=%zu", cmd, len);
    if (strcmp(cmd, "list_progs") == 0)
        emit_list_progs(cli);
    else if (strcmp(cmd, "execute_plan") == 0)
        emit_execute_plan(cli, buf);
    else if (strcmp(cmd, "has_programs") == 0)
        emit_has_programs(cli);
    else if (strcmp(cmd, "measure_start") == 0)
        emit_measure_start(cli);
    else if (strcmp(cmd, "measure_finish") == 0)
        emit_measure_finish(cli);
    else if (strcmp(cmd, "dump_state") == 0)
        emit_dump_state(cli);
    else
        dprintf(cli, "{\"ok\":false,\"error\":\"unknown cmd: %s\"}\n", cmd);
    free(buf);
}

static void *socket_thread(void *arg) {
    (void)arg;
    const char *dir = getenv("BPFREJIT_SHIM_SOCK_DIR");
    if (!dir)
        dir = "/var/run/bpfrejit";
    mkdir(dir, 0755);
    char path[256];
    snprintf(path, sizeof(path), "%s/shim-%d.sock", dir, getpid());
    int srv = unix_socket_listen(path);
    if (srv < 0) {
        /* Fallback to /tmp if the default dir is not writable. */
        snprintf(path, sizeof(path), "/tmp/bpfrejit-shim-%d.sock", getpid());
        srv = unix_socket_listen(path);
        if (srv < 0) {
            log_line("socket: failed to bind, server disabled errno=%d",
                     errno);
            return NULL;
        }
    }
    log_line("socket: listening on %s", path);
    sigset_t mask;
    sigfillset(&mask);
    pthread_sigmask(SIG_BLOCK, &mask, NULL);
    while (1) {
        int cli = accept(srv, NULL, NULL);
        if (cli < 0) {
            if (errno == EINTR)
                continue;
            break;
        }
        handle_client(cli);
        real_close(cli);
    }
    real_close(srv);
    return NULL;
}

/* Worker thread: optional periodic state JSON dump
 * (env: BPFREJIT_SHIM_PERIODIC_DUMP_MS, ms). Optimization itself is driven
 * by the runner over the socket via execute_plan, not by this thread. */
static void *worker_thread(void *arg) {
    (void)arg;
    const char *dump_env = getenv("BPFREJIT_SHIM_PERIODIC_DUMP_MS");
    int dump_ms = dump_env ? atoi(dump_env) : 0;
    if (dump_ms <= 0)
        return NULL;
    sigset_t mask;
    sigfillset(&mask);
    pthread_sigmask(SIG_BLOCK, &mask, NULL);
    while (1) {
        struct timespec ts = {dump_ms / 1000,
                              (long)(dump_ms % 1000) * 1000000L}, rem;
        while (nanosleep(&ts, &rem) == -1 && errno == EINTR)
            ts = rem;
        dump_state_json();
    }
    return NULL;
}
