
/var/tmp/kprog-tmp/S15/tc-retpoline/native-image.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	48 31 c0             	xor    rax,rax
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	48 83 f8 21          	cmp    rax,0x21
  17:	77 06                	ja     0x1f
  19:	50                   	push   rax
  1a:	48 89 e0             	mov    rax,rsp
  1d:	eb 01                	jmp    0x20
  1f:	50                   	push   rax
  20:	50                   	push   rax
  21:	53                   	push   rbx
  22:	41 55                	push   r13
  24:	41 56                	push   r14
  26:	41 57                	push   r15
  28:	f3 0f 1e fa          	endbr64
  2c:	4c 8d 1d b0 00 00 00 	lea    r11,[rip+0xb0]        # 0xe3
  33:	e8 10 a5 c9 e1       	call   0xffffffffe1c9a548
  38:	4c 8d 1d 05 00 00 00 	lea    r11,[rip+0x5]        # 0x44
  3f:	e9 04 a5 c9 e1       	jmp    0xffffffffe1c9a548
  44:	f3 0f 1e fa          	endbr64
  48:	48 83 ec 18          	sub    rsp,0x18
  4c:	48 c7 04 24 07 00 00 	mov    QWORD PTR [rsp],0x7
  53:	00 
  54:	48 b8 30 b1 c6 c3 47 	movabs rax,0xffff8f47c3c6b130
  5b:	8f ff ff 
  5e:	48 83 00 01          	add    QWORD PTR [rax],0x1
  62:	48 be 00 a6 c6 c3 47 	movabs rsi,0xffff8f47c3c6a600
  69:	8f ff ff 
  6c:	31 d2                	xor    edx,edx
  6e:	41 bb 0c 00 00 00    	mov    r11d,0xc
  74:	89 d2                	mov    edx,edx
  76:	39 96 44 00 00 00    	cmp    DWORD PTR [rsi+0x44],edx
  7c:	0f 86 4a 00 00 00    	jbe    0xcc
  82:	48 8b 85 d8 ff ff ff 	mov    rax,QWORD PTR [rbp-0x28]
  89:	48 83 38 21          	cmp    QWORD PTR [rax],0x21
  8d:	0f 83 39 00 00 00    	jae    0xcc
  93:	48 8b 8c d6 30 01 00 	mov    rcx,QWORD PTR [rsi+rdx*8+0x130]
  9a:	00 
  9b:	48 85 c9             	test   rcx,rcx
  9e:	0f 84 28 00 00 00    	je     0xcc
  a4:	48 83 00 01          	add    QWORD PTR [rax],0x1
  a8:	48 83 c4 18          	add    rsp,0x18
  ac:	41 5f                	pop    r15
  ae:	41 5e                	pop    r14
  b0:	41 5d                	pop    r13
  b2:	5b                   	pop    rbx
  b3:	58                   	pop    rax
  b4:	58                   	pop    rax
  b5:	48 81 c4 18 00 00 00 	add    rsp,0x18
  bc:	48 8b 89 48 00 00 00 	mov    rcx,QWORD PTR [rcx+0x48]
  c3:	48 83 c1 0c          	add    rcx,0xc
  c7:	e9 3c a3 c9 e1       	jmp    0xffffffffe1c9a408
  cc:	8b 04 24             	mov    eax,DWORD PTR [rsp]
  cf:	83 f8 07             	cmp    eax,0x7
  d2:	0f 94 c0             	sete   al
  d5:	0f b6 c0             	movzx  eax,al
  d8:	01 c0                	add    eax,eax
  da:	48 83 c4 18          	add    rsp,0x18
  de:	e9 0e 00 00 00       	jmp    0xf1
  e3:	f3 0f 1e fa          	endbr64
  e7:	b8 00 00 00 00       	mov    eax,0x0
  ec:	e9 07 5a f3 e0       	jmp    0xffffffffe0f35af8
  f1:	41 5f                	pop    r15
  f3:	41 5e                	pop    r14
  f5:	41 5d                	pop    r13
  f7:	5b                   	pop    rbx
  f8:	c9                   	leave
  f9:	c3                   	ret
