import json,subprocess,os,shutil
from pathlib import Path
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
def bind(a,b):subprocess.run(['mount','--bind',str(a),str(b)],check=True)
for name in json.loads((O/'source-identities.json').read_text()):bind(O/'source'/name,R/name)
for arch in ['x86','arm64']:
 dest=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
 dest.mkdir(exist_ok=True);bind(O/('safety-'+arch),dest)
 build=R/('kprog/formal/build/fidelity-trusted'+('-arm64' if arch=='arm64' else ''));build.mkdir(exist_ok=True);bind(O/('build-'+arch),build)
bind(O/'loader',R/'kprog/libnativeloader/build')
bind(O/'cargo/release/native-link',R/'kprog/x86/native_lab/native_link/target/release/native-link')
for arch in ['x86']:
 dest=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
 subprocess.run(['taskset','-c','8-23','python3',str(dest/'s11.py'),'build'],check=True)
assert (O/'kernel-resume.exit').read_text().strip()=='0'
assert (O/'module.exit').read_text().strip()=='0'
bind(O/'module/bpf_x86_native_lab.ko',R/'kprog/tv/build-x86/bpf_x86_native_lab.ko')
tc=O/'tc';tc.mkdir(exist_ok=True)
for name in ['tail-client','tail.bpf.o','tail.native.o','guest-tc.py']:shutil.copyfile(O/name,tc/name)
(tc/'tail-client').chmod(0o755)
out=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp';(out/'run').mkdir(exist_ok=True)
cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(tc/'guest-tc.py')+'; a=$?; PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(out/'s11.py')+' guest '+str(out/'run')+'; b=$?; echo "$a $b" > '+str(O/'guest-exits.txt')+'; test "$a" = 0'
result=subprocess.run(['taskset','-c','8-23','vng','--run',str(O/'kernel-build/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--rwdir',str(O),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','spectre_v2=retpoline loglevel=4 panic=30 oops=panic','--exec',cmd])
(O/'guest.exit').write_text(str(result.returncode)+'\n')
