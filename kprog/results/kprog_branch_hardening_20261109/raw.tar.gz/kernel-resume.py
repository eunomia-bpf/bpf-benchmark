import os,select,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S15')
try:
 fd=os.pidfd_open(3202362);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError: pass
with (O/'kernel-resume.log').open('w') as log:
 x=subprocess.run(['taskset','-c','8-23','make','-C',str(O/'kernel-src'),'O='+str(O/'kernel-build'),'-j8','bzImage'],stdout=log,stderr=subprocess.STDOUT)
(O/'kernel-resume.exit').write_text(str(x.returncode)+'\n')
if x.returncode==0:
 m=O/'module';m.mkdir(exist_ok=True)
 (m/'bpf_x86_native_lab.c').write_bytes(Path('/workspaces/repository/kinsn/module/x86/bpf_x86_native_lab.c').read_bytes())
 (m/'Makefile').write_text('ccflags-y += -I/workspaces/repository/kinsn/module/include\nobj-m += bpf_x86_native_lab.o\n')
 with (O/'module.log').open('w') as log:x=subprocess.run(['taskset','-c','8-23','make','-C',str(O/'kernel-build'),'M='+str(m),'-j4','modules'],stdout=log,stderr=subprocess.STDOUT)
 (O/'module.exit').write_text(str(x.returncode)+'\n')
