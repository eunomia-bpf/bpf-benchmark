#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH CLANG=clang-18
cd /workspaces/repository
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/rust-published.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/rust-published.exit
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/release-published.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/release-published.exit
taskset -c 8-23 python3 kprog/tv/test_native_branch_hardening.py /var/tmp/kprog-tmp/S15/cargo/release/native-link /var/tmp/kprog-tmp/S15/offline-final >/var/tmp/kprog-tmp/S15/offline-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/offline-final.exit
taskset -c 8-23 python3 kprog/tv/test_kernel_patch.py >/var/tmp/kprog-tmp/S15/patch-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/patch-final.exit
