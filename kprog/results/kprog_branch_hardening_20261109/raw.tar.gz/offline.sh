#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CLANG=clang-18 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
cd /workspaces/repository
taskset -c 8-23 python3 kprog/tv/test_native_branch_hardening.py /var/tmp/kprog-tmp/S15/cargo/release/native-link /var/tmp/kprog-tmp/S15/offline >/var/tmp/kprog-tmp/S15/offline.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/offline.exit
for arch in x86 arm64; do
 taskset -c 8-23 python3 kprog/run_micro_sim_batch.py --arch "$arch" --build-only --no-generate --no-build-loader --build-dir "/var/tmp/kprog-tmp/S15/micro-$arch" --markdown "/var/tmp/kprog-tmp/S15/micro-$arch.md" --jobs 4 >"/var/tmp/kprog-tmp/S15/micro-$arch.log" 2>&1
 echo $? >"/var/tmp/kprog-tmp/S15/micro-$arch.exit"
done
