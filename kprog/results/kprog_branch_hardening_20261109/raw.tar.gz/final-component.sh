#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo PYTHONDONTWRITEBYTECODE=1 PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH CLANG=clang-18
cd /workspaces/repository
O=/var/tmp/kprog-tmp/S15
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/rust-final2.log" 2>&1
echo $? >"$O/rust-final2.exit"
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/release-final2.log" 2>&1
echo $? >"$O/release-final2.exit"
taskset -c 8-23 python3 kprog/tv/test_native_branch_hardening.py "$O/cargo/release/native-link" "$O/offline-published" >"$O/offline-published.log" 2>&1
echo $? >"$O/offline-published.exit"
taskset -c 8-23 python3 kprog/tv/test_kernel_patch.py >"$O/patch-published.log" 2>&1
echo $? >"$O/patch-published.exit"
taskset -c 8-23 g++ -std=c++20 -O2 -Ivendor/libbpf/include/uapi -Irunner/build-llvmbpf/vendor/libbpf/prefix/include kprog/test/tail_call_frame/client.cpp "$O/loader/libnative_loader.a" runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -o "$O/tail-client" >"$O/tail-client-final.log" 2>&1
echo $? >"$O/tail-client-final.exit"
