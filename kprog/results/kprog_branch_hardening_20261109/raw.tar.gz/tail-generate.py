import sys,json
from pathlib import Path
sys.path.insert(0,'kprog/x86');import trusted_specializer as t
O=Path('/var/tmp/kprog-tmp/S15')
metadata=dict(prog_type=3,section='classifier',maps=[dict(name='tail_jumps',map_type=3,map_flags=0,key_size=4,value_size=4,max_entries=1),dict(name='tail_counter_value',map_type=2,map_flags=0,key_size=4,value_size=8,max_entries=1,value_offset=0)])
try:
 print(t.specialize((O/'tail.native.o').read_bytes(),'entry',metadata,O/'specialize-tail-final',O/'cargo/release/native-link'))
except Exception as e:
 print(type(e).__name__,str(e));raise
