__attribute__((noinline)) static unsigned long target(void *x) { __asm__ volatile(""); return 2; }
unsigned long entry(void *x) { unsigned long (*f)(void *) = target; __asm__("" : "+r"(f)); return f(x); }
