#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 16U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: lea    r11,[rip+0xb] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x17ULL);
x86_l_c:
	/* 0xc: call   11 <entry+0x11> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x17ULL: X86_SIM_X86_CALL(x86_l_17, 0x11ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11:
	/* 0x11: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_12:
	/* 0x12: jmp    17 <target> */
	X86_SIM_X86_RET();
x86_l_25:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_17 */
x86_l_17:
	/* 0x17: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_1b:
	/* 0x1b: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_20:
	/* 0x20: jmp    25 <target+0xe> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x11ULL: goto x86_l_11;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
