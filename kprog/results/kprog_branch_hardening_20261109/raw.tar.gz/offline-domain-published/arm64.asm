
/var/tmp/kprog-tmp/S15/offline-domain-published/arm64.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d503245f 	bti	c
   4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
   8:	910003fd 	mov	x29, sp
   c:	10000088 	adr	x8, 1c <target>
  10:	d63f0100 	blr	x8
  14:	a8c17bfd 	ldp	x29, x30, [sp], #16
  18:	d65f03c0 	ret

000000000000001c <target>:
  1c:	d503245f 	bti	c
  20:	52800040 	mov	w0, #0x2                   	// #2
  24:	d65f03c0 	ret
