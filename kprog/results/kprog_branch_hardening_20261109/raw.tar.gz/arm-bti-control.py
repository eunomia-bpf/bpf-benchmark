from pathlib import Path
import subprocess,shutil
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
folder=O/'arm-bti';folder.mkdir(exist_ok=True)
shutil.copy2(O/'safety-arm64/_base_check.py',folder/'_base_check.py')
source='''from pathlib import Path
import sys,importlib.util,json,os
os.environ['LD_LIBRARY_PATH']='/workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3'
R=Path('/workspaces/repository');O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bti_base',O/'_base_check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.ARCH='arm64';m.OUT=O;m.BUILD=R/'kprog/formal/build/fidelity-trusted-arm64'
m.cases=lambda:[dict(name='branch_bti_adr_jump',assembly='bti c; adr x8,1f; br x8; 1: bti j; mov w0,#2; ret',negative=False)]
if sys.argv[1]=='build':m.build()
elif sys.argv[1]=='guest':
 live=Path(sys.argv[2]);selected=json.loads((O/'cases.json').read_text());(live/'cases.json').write_text(json.dumps(selected));m.cases=lambda:selected;m.OUT=live
 try:m.check()
 finally:
  p=live/'outcomes.json';rows=json.loads(p.read_text()) if p.exists() else []
  (live/'guest.json').write_text(json.dumps(dict(ok=len(rows)==1 and rows[0]['stage']=='valid_executed',cases=len(rows))))
elif sys.argv[1]=='host':
 spec=importlib.util.spec_from_file_location('bti_transport',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py');t=importlib.util.module_from_spec(spec);spec.loader.exec_module(t)
 t.HERE=O;t.__file__=__file__;t.NATIVE_LINK=m.native_link();t.LOADER=m.loader_build();t.host()
'''
(folder/'control.py').write_text(source)
target=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp'
subprocess.run(['mount','--bind',str(folder),str(target)],check=True)
build=O/'arm-bti-build';build.mkdir(exist_ok=True)
subprocess.run(['mount','--bind',str(build),str(R/'kprog/formal/build/fidelity-trusted-arm64')],check=True)
subprocess.run(['taskset','-c','8-23','python3',str(target/'control.py'),'build'],check=True)
x=subprocess.run(['taskset','-c','8-23','python3',str(target/'control.py'),'host'])
(O/'arm-bti-controller.exit').write_text(str(x.returncode)+'\n')
