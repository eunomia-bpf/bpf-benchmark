from pathlib import Path
import json,subprocess
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
for name in json.loads((O/'source-identities.json').read_text()):
 subprocess.run(['mount','--bind',str(O/'source'/name),str(R/name)],check=True)
for arch in ['x86','arm64']:
 command=json.loads((O/f'micro-{arch}/simple.compile.json').read_text())['command']
 command[command.index('-c')+1]=str(R/f'kprog/{arch}/micro-prog/unchecked_packet_read.bpf.c')
 command[command.index('-o')+1]=str(O/f'micro-{arch}/unchecked_packet_read.bpf.o')
 result=subprocess.run(command,capture_output=True,text=True)
 (O/f'micro-{arch}-negative.json').write_text(json.dumps(dict(command=command,exit=result.returncode,stdout=result.stdout,stderr=result.stderr),indent=2)+'\n')
 print(arch,'unchecked read compile',result.returncode)
