#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
taskset -c 8-23 python3 kprog/tv/test_kernel_patch.py >/var/tmp/kprog-tmp/S15/patch.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/patch.exit
