from pathlib import Path
import os,subprocess,sys,json,threading
R=Path('/workspaces/repository');O=Path('/workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/tc-s15')
state=O/'requests';state.mkdir(parents=True)
(O/'kernel-policy.txt').write_text(Path('/sys/devices/system/cpu/vulnerabilities/spectre_v2').read_text())
env=dict(os.environ,PATH='/usr/lib/llvm-18/bin:'+os.environ['PATH'],TMPDIR='/tmp',PYTHONDONTWRITEBYTECODE='1')
service=subprocess.Popen([sys.executable,R/'kprog/trusted_service.py','--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',state,'--native-link',R/'kprog/x86/native_lab/native_link/target/release/native-link','--loader',R/'kprog/libnativeloader/build/trusted-native-loader'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env=env)
thread=None;log=None
try:
 ready=service.stdout.readline();(O/'service.log').write_text(ready);assert json.loads(ready)['ready']
 log=(O/'service.log').open('a')
 def drain():
  for line in service.stdout:log.write(line);log.flush()
 thread=threading.Thread(target=drain);thread.start()
 done=subprocess.run([O/'tail-client',O/'tail.bpf.o',O/'tail.native.o',R/'kprog/x86/native_lab/native_link/target/release/native-link',O/'native-image.bin'],text=True,capture_output=True,env=env)
 (O/'client.stdout').write_text(done.stdout);(O/'client.stderr').write_text(done.stderr)
 done.check_returncode()
finally:
 service.terminate();service.wait()
 if thread:thread.join()
 if log:log.close()
 (O/'dmesg.txt').write_text(subprocess.run(['dmesg'],capture_output=True,text=True).stdout)
