from pathlib import Path
import subprocess,json,shutil
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
def bind(a,b):subprocess.run(['mount','--bind',str(a),str(b)],check=True)
for name in json.loads((O/'source-identities.json').read_text()):bind(O/'source'/name,R/name)
for src,dst in [(O/'loader',R/'kprog/libnativeloader/build'),(O/'cargo/release/native-link',R/'kprog/x86/native_lab/native_link/target/release/native-link'),(O/'module/bpf_x86_native_lab.ko',R/'kprog/tv/build-x86/bpf_x86_native_lab.ko')]:bind(src,dst)
folder=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/tc-s15'
folder.mkdir(exist_ok=True);bind(O/'tc',folder)
script=(O/'guest-tc.py').read_text().replace("O=Path('/var/tmp/kprog-tmp/S15/tc')",'O=Path('+repr(str(folder))+')')
(folder/'guest-tc.py').write_text(script)
cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(folder/'guest-tc.py')+'; rc=$?; echo $rc > '+str(folder/'guest.exit')+'; exit $rc'
x=subprocess.run(['taskset','-c','8-23','vng','--run',str(O/'kernel-build/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','spectre_v2=retpoline loglevel=4 panic=30 oops=panic','--exec',cmd])
(O/'tc-controller.exit').write_text(str(x.returncode)+'\n')
