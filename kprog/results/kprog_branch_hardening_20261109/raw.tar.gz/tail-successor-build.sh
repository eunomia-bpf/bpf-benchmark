#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo PYTHONDONTWRITEBYTECODE=1 PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH CLANG=clang-18
cd /workspaces/repository
O=/var/tmp/kprog-tmp/S15
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/rust-tail.log" 2>&1
echo $? >"$O/rust-tail.exit"
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/release-tail.log" 2>&1
echo $? >"$O/release-tail.exit"
taskset -c 8-23 clang-18 -c kprog/test/tail_call_frame/native.S -o "$O/tail.native.o"
