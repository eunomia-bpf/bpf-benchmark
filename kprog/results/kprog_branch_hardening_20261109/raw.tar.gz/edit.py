from pathlib import Path
root=Path('/workspaces/repository')
def edit(path,fn):
 p=root/path;s=p.read_text();n=fn(s);assert n!=s,path;p.write_text(n)
# Compile P under the selected policy.
edit('vendor/bpf/Makefile',lambda s:s.replace('-march=native -mno-red-zone ', '-march=native -mno-red-zone -mretpoline-external-thunk -mfunction-return=thunk-extern -fcf-protection=branch ').replace('-mtune=neoverse-n1 -mgeneral-regs-only ', '-mtune=neoverse-n1 -mbranch-protection=bti -mgeneral-regs-only '))
edit('runner/libs/cilium_native_build.py',lambda s:s.replace('["-march=native", "-mno-red-zone"]','["-march=native", "-mno-red-zone", "-mretpoline-external-thunk",\n                   "-mfunction-return=thunk-extern", "-fcf-protection=branch"]').replace('"-mtune=neoverse-n1", "-mno-outline-atomics",','"-mtune=neoverse-n1", "-mbranch-protection=bti", "-mno-outline-atomics",'))
edit('kinsn/module/include/native_lab_binding.h',lambda s:s.replace('#define NATIVE_LAB_RELOC_X86_TAIL_STACK 11U','#define NATIVE_LAB_RELOC_X86_TAIL_STACK 11U\n/* rel32 field of a compiler or native-tail external thunk transfer. */\n#define NATIVE_LAB_RELOC_X86_THUNK 12U'))
edit('kprog/libnativeloader/src/native_loader.cpp',lambda s:s.replace('return kind == kNativeLabRelocHelperCallRel32 ||','return kind == NATIVE_LAB_RELOC_X86_THUNK || kind == kNativeLabRelocHelperCallRel32 ||').replace('case NATIVE_LAB_RELOC_X86_TAIL_COUNT:\n','case NATIVE_LAB_RELOC_X86_THUNK:\n    case NATIVE_LAB_RELOC_X86_TAIL_COUNT:\n'))
# The simulator interprets compiler thunks by their architectural transfer.
p='kprog/x86/micro-prog/generate_micro_sim_proofs.py'
def gen(s):
 s=s.replace('    return insns, section_size(proof_obj, ".text"), rodata16','''    normalized = []
    for insn in insns:
        if insn.reloc_symbol == "__x86_return_thunk":
            insn = replace(insn, mnemonic="ret", operands=(), reloc_symbol=None,
                           reloc_type=None, reloc_target=None)
        elif insn.reloc_symbol and insn.reloc_symbol.startswith("__x86_indirect_thunk_"):
            reg = insn.reloc_symbol.removeprefix("__x86_indirect_thunk_")
            if reg_info(reg) is None:
                raise ValueError(f"unknown external thunk register: {reg}")
            insn = replace(insn, operands=(reg,), reloc_symbol=None,
                           reloc_type=None, reloc_target=None)
        normalized.append(insn)
    return normalized, section_size(proof_obj, ".text"), rodata16''')
 return s.replace('if op in {"nop", "data16", "cs"}:','if op in {"nop", "data16", "cs", "endbr64"}:')
edit(p,gen)
edit('kprog/arm64/micro-prog/generate_micro_sim_proofs.py',lambda s:s.replace('if op == "nop":','if op in {"nop", "bti"}:'))
# External thunks retain their original call/jump opcodes and relocate their fields.
p='kprog/x86/native_lab/native_link/src/x86.rs'
def linker(s):
 s=s.replace('const NATIVE_LAB_RELOC_X86_TAIL_STACK: u32 = 11;','const NATIVE_LAB_RELOC_X86_TAIL_STACK: u32 = 11;\nconst NATIVE_LAB_RELOC_X86_THUNK: u32 = 12;')
 anchor='fn x86_mov_imm_to_gpr64(insn: &Instruction)'
 i=s.index(anchor)
 s=s[:i]+'''// Architectural meaning of compiler external-thunk relocations. The kernel
// chooses the concrete mitigation target when it resolves the rel32 field.
fn x86_thunk_selector(name: &str) -> Option<u64> {
    if name == "__x86_return_thunk" { return Some(16); }
    let name = name.strip_prefix("__x86_indirect_thunk_")?;
    ["rax","rcx","rdx","rbx","rsp","rbp","rsi","rdi",
     "r8","r9","r10","r11","r12","r13","r14","r15"]
        .iter().position(|reg| *reg == name).map(|n| n as u64)
}

fn x86_thunk_semantics(mut insn: Instruction, name: Option<&String>) -> Instruction {
    if let Some(target) = name.and_then(|name| x86_thunk_selector(name)) {
        if target == 16 { insn.set_code(Code::Retnq); }
        else {
            let call = insn.mnemonic() == Mnemonic::Call;
            insn.set_code(if call { Code::Call_rm64 } else { Code::Jmp_rm64 });
            insn.set_op0_kind(OpKind::Register);
            insn.set_op0_register(Register::RAX + target as u32);
        }
    }
    insn
}

'''+s[i:]
 s=s.replace('TailCallFrame { count_offset: usize, stack_offset: usize },','TailCallFrame { count_offset: usize, stack_offset: usize, thunk_offset: usize },\n    Thunk { selector: u64 },')
 s=s.replace('let helper_call_sites = scan_helper_calls(elf, included)?;','''let mut helper_call_sites = scan_helper_calls(elf, included)?;
    let thunk_sites: HashMap<_,_> = helper_call_sites.iter()
        .filter(|(_,name)| x86_thunk_selector(name).is_some())
        .map(|(key,name)| (*key,name.clone())).collect();
    helper_call_sites.retain(|key,_| !thunk_sites.contains_key(key));''')
 s=s.replace('let decoded: Vec<_> = Decoder::with_ip(64, &bytes, sym.address, DecoderOptions::NONE).into_iter().collect();','''let decoded: Vec<_> = Decoder::with_ip(64, &bytes, sym.address, DecoderOptions::NONE)
            .into_iter().map(|insn| x86_thunk_semantics(insn,
                thunk_sites.get(&local_site_key(sym, insn.ip()-sym.address)))).collect();''')
 anchor='            // An external tail jump must return through'
 i=s.index(anchor)
 s=s[:i]+'''            if let Some(name) = thunk_sites.get(&site_key) {
                let selector = x86_thunk_selector(name).expect("scanned thunk");
                if proof_mode {
                    // ELF records keep the target identity for B and step(e).
                    let opcode = if insn.mnemonic()==Mnemonic::Call { 0xe8 } else { 0xe9 };
                    push_x86_replacement(&mut local,&mut kinds,&mut insn_local_ip,local_ip,
                        declared_bytes(&[opcode,0,0,0,0])?,None);
                    continue;
                }
                let helper = helper_targets.get(&(sym.address+local_ip)).is_some_and(|values|
                    values.iter().all(|v| matches!(v,X86Callee::Id(_) | X86Callee::Symbol(_))));
                if selector == 16 || !helper {
                    let opcode = if insn.mnemonic()==Mnemonic::Call { 0xe8 } else { 0xe9 };
                    if selector == 16 && is_entry {
                        let mut jump = Instruction::with_branch(Code::Jmp_rel32_64,
                            X86_JMP_END_PLACEHOLDER_TARGET)?;
                        jump.set_ip(local_ip);
                        push_x86_replacement(&mut local,&mut kinds,&mut insn_local_ip,
                            local_ip,jump,Some(PatchKind::JmpEnd));
                    } else {
                        push_x86_replacement(&mut local,&mut kinds,&mut insn_local_ip,local_ip,
                            declared_bytes(&[opcode,0,0,0,0])?,Some(PatchKind::Thunk { selector }));
                    }
                    resolved_helper_call_sites.insert(site_key);
                    continue;
                }
                insn = x86_thunk_semantics(insn,Some(name));
            }

'''+s[i:]
 s=s.replace('let (inline, count_offset, stack_offset) = build_x86_tail_call_inline(', 'let (inline, count_offset, stack_offset, thunk_offset) = build_x86_tail_call_inline(')
 s=s.replace('PatchKind::TailCallFrame { count_offset, stack_offset }','PatchKind::TailCallFrame { count_offset, stack_offset, thunk_offset }')
 s=s.replace('for (offset, kind) in [(*count_offset, NATIVE_LAB_RELOC_X86_TAIL_COUNT),','relocs.push(RelocRecord { offset: u32::try_from(p.global_offset + thunk_offset)?,\n                    kind: NATIVE_LAB_RELOC_X86_THUNK, target: 1 });\n                for (offset, kind) in [(*count_offset, NATIVE_LAB_RELOC_X86_TAIL_COUNT),')
 s=s.replace('            PatchKind::HelperPointer { target_addr } => {','''            PatchKind::Thunk { selector } => {
                relocs.push(RelocRecord { offset: u32::try_from(p.global_offset+1)?,
                    kind: NATIVE_LAB_RELOC_X86_THUNK, target: *selector });
            }
            PatchKind::HelperPointer { target_addr } => {''')
 s=s.replace(') -> Result<(Vec<Instruction>, usize, usize)> {',') -> Result<(Vec<Instruction>, usize, usize, usize)> {')
 s=s.replace('    bytes.extend_from_slice(&[0xFF, 0xE1]); // jmp rcx','    bytes.push(0xe9); // jmp kernel-selected RCX thunk\n    let thunk_offset = bytes.len();\n    bytes.extend_from_slice(&0i32.to_le_bytes());')
 s=s.replace('Ok((declared_byte_chunks(&bytes)?, count_offset, stack_offset))','Ok((declared_byte_chunks(&bytes)?, count_offset, stack_offset, thunk_offset))')
 s=s.replace('let (instructions, count, stack) = build_x86_tail_call_inline(', 'let (instructions, count, stack, thunk) = build_x86_tail_call_inline(')
 # Landing pads precede saved GPRs and stay in emitted P.
 s=s.replace('if !is_alignment_nop(&insn) {\n            insns.push(insn);','if !is_alignment_nop(&insn) && insn.mnemonic() != Mnemonic::Endbr64 {\n            insns.push(insn);')
 return s
edit(p,linker)
