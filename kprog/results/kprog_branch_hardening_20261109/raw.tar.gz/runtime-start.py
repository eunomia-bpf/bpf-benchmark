from pathlib import Path
import subprocess,os,select
O=Path('/var/tmp/kprog-tmp/S15')
for pid in [3280187,3276101]:
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
with (O/'runtime.log').open('w') as log:
 x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'runtime-mount.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'runtime.exit').write_text(str(x.returncode)+'\n')
