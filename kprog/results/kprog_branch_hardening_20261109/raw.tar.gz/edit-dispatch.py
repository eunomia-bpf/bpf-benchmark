from pathlib import Path
p=Path('kprog/x86/native_lab/native_link/src/x86.rs');s=p.read_text()
s=s.replace('HelperDispatch { targets: Vec<(u64, u64)> },','HelperDispatch { targets: Vec<(u64, u64)>, thunk_reg: u64 },')
s=s.replace('Some(PatchKind::HelperDispatch { targets })','Some(PatchKind::HelperDispatch { targets, thunk_reg: if reg==Register::R11 { 10 } else { 11 } })')
s=s.replace('PatchKind::HelperDispatch { targets } => {','PatchKind::HelperDispatch { targets, thunk_reg } => {\n                relocs.push(RelocRecord { offset: u32::try_from(p.global_offset+12)?,\n                    kind: NATIVE_LAB_RELOC_X86_THUNK, target: *thunk_reg });')
s=s.replace('0x41 | ((index>>3)<<1),0xff,0x14,0xc0 | ((index & 7)<<3) | scratch])','0x4d | ((index>>3)<<1),0x8b,0x04 | (scratch<<3),0xc0 | ((index & 7)<<3) | scratch,\n            0xe8,0,0,0,0])')
s=s.replace('// LEA and the SIB-indirect CALL preserve flags and the original helper ID.','// LEA, table load and the external-thunk CALL preserve flags and the helper ID.')
s=s.replace('assert_eq!(insns.len(),2);\n            assert_eq!(insns[0].mnemonic(),Mnemonic::Lea);','assert_eq!(insns.len(),3);\n            assert_eq!(insns[0].mnemonic(),Mnemonic::Lea);')
s=s.replace('assert_eq!(insns[1].flow_control(),FlowControl::IndirectCall);','assert_eq!(insns[1].mnemonic(),Mnemonic::Mov);\n            assert_eq!(insns[2].flow_control(),FlowControl::Call);')
s=s.replace('assert_eq!(&bytes[stack-3..stack], &[0x48,0x81,0xc4]);','assert_eq!(&bytes[stack-3..stack], &[0x48,0x81,0xc4]);\n            assert_eq!(bytes[thunk-1],0xe9);\n            assert_eq!(&bytes[thunk..thunk+4],&[0,0,0,0]);')
p.write_text(s)
p=Path('kprog/test/tail_call_frame/native.S');s=p.read_text();s=s.replace('entry:\n','entry:\nendbr64\nlea r11, [rip+1f]\njmp __x86_indirect_thunk_r11\n1: endbr64\n');s=s.replace('\nret\n','\njmp __x86_return_thunk\n');p.write_text(s)
# Kernel selftests consume the same native compile policy.
p=Path('kprog/selftests/selftests.py');s=p.read_text().replace('"x86": ["-mno-red-zone"],','"x86": ["-mno-red-zone", "-mretpoline-external-thunk",\n                "-mfunction-return=thunk-extern", "-fcf-protection=branch"],').replace('"-march=armv8.1-a+lse",','"-march=armv8.1-a+lse", "-mbranch-protection=bti",');p.write_text(s)
