from pathlib import Path
import os,subprocess,shutil,json
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
original=R/'runner/build-arm64-llvmbpf';private=O/'arm-path'
assert not (original/'clang').exists()
shutil.copytree(original,private,copy_function=shutil.copy2,symlinks=True,dirs_exist_ok=True)
state=R/'kprog/arm64/build/trusted-transport/compiler-broker';state.mkdir(exist_ok=True)
wrapper='''#!/usr/bin/python3
import os,sys
from pathlib import Path
R=Path('/workspaces/repository')
a=sys.argv[1:]
os.execv(sys.executable,[sys.executable,str(R/'kprog/trusted_compile.py'),'submit',
 '--state',str(R/'kprog/arm64/build/trusted-transport/compiler-broker'),
 '--source',a[a.index('-c')+1],'--output',a[a.index('-o')+1],'--arch','arm64'])
'''
(private/'clang').write_text(wrapper);(private/'clang').chmod(0o755)
command=['taskset','-c','8-23','python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(R/'kprog/arm64/build/trusted-transport'),'--state',str(state),'--arm64-sysroot',str(R/'kprog/arm64/build/app-runtime-v35/root'),'--clang','/usr/lib/llvm-18/bin/clang']
with (O/'arm-compiler.log').open('w') as log:
 p=subprocess.Popen(['setsid','nohup',*command],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
(O/'arm-compiler.pid').write_text(str(p.pid)+'\n')
subprocess.run(['mount','--bind',str(private),str(original)],check=True)
(O/'arm-broker-route.json').write_text(json.dumps(dict(pid=p.pid,command=command,private_path=str(private),guest_path=str(original),capture='existing guest and inputs retained; subsequent clang invocations use the existing compile broker'),indent=2)+'\n')
print('ARM host compiler route active:',p.pid)
