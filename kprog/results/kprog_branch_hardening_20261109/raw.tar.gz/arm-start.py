import os,select,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S15')
try:
 fd=os.pidfd_open(3295747);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with (O/'arm-controller.log').open('w') as log:x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'arm-mount.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'arm-start.exit').write_text(str(x.returncode)+'\n')
