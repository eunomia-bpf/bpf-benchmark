#!/bin/bash
set -e
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CLANG=clang-18 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
cd /workspaces/repository
taskset -c 8-23 python3 kprog/tv/test_native_branch_hardening.py /var/tmp/kprog-tmp/S15/cargo/release/native-link /var/tmp/kprog-tmp/S15/offline-final-source >/var/tmp/kprog-tmp/S15/offline-final-source.log 2>&1
git status --short --branch >/var/tmp/kprog-tmp/S15/tail-precommit-status.txt
git diff --check -- kprog/x86/native_lab/native_link/src/x86.rs kprog/test/tail_call_frame/native.S kprog/tv/test_native_branch_hardening.py
git commit --only -m 'Align thunked tail transfers with the complete JIT save frame' -- kprog/x86/native_lab/native_link/src/x86.rs kprog/test/tail_call_frame/native.S kprog/tv/test_native_branch_hardening.py
git push origin master
git rev-parse HEAD >/var/tmp/kprog-tmp/S15/tail-commit.txt
