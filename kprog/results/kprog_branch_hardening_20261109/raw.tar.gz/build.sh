#!/bin/bash
ulimit -c 0
export PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo
cd /workspaces/repository
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/rust.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/rust.exit
