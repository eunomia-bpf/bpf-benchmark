#!/bin/bash
set -e
ulimit -c 0
export PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
export TMPDIR=/var/tmp/kprog-tmp/S15
O=/var/tmp/kprog-tmp/S15
cp -a --reflink=auto /var/tmp/kprog-tmp/CK/linux "$O/kernel-src"
cp -a --reflink=auto /var/tmp/kprog-tmp/CK/build "$O/kernel-build"
rm "$O/kernel-build/source"
ln -s "$O/kernel-src" "$O/kernel-build/source"
python3 - <<'PY'
from pathlib import Path
p=Path('/var/tmp/kprog-tmp/S15/kernel-src/arch/x86/net/bpf_jit_comp.c')
s=p.read_text();body=Path('/var/tmp/kprog-tmp/S15/kernel-addition.txt').read_text()
a='#define BPF_TAIL_CALL_CNT_PTR_STACK_OFF(stack)'
s=s.replace(a,body+'\n'+a);p.write_text(s)
p=Path('/var/tmp/kprog-tmp/S15/kernel-build/Makefile');s=p.read_text().replace('/var/tmp/kprog-tmp/CK/linux','/var/tmp/kprog-tmp/S15/kernel-src');p.write_text(s)
PY
make -C "$O/kernel-src" O="$O/kernel-build" -j8 bzImage
mkdir -p "$O/module"
cp /workspaces/repository/kinsn/module/x86/bpf_x86_native_lab.c "$O/module/"
printf 'ccflags-y += -I/workspaces/repository/kinsn/module/include\nobj-m += bpf_x86_native_lab.o\n' >"$O/module/Makefile"
make -C "$O/kernel-build" M="$O/module" -j4 modules
