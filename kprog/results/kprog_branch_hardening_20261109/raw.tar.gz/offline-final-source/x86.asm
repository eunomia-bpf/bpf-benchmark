
/var/tmp/kprog-tmp/S15/offline-final-source/x86.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f3 0f 1e fa          	endbr64
   4:	50                   	push   rax
   5:	4c 8d 1d 14 00 00 00 	lea    r11,[rip+0x14]        # 20 <target>
   c:	e8 00 00 00 00       	call   11 <entry+0x11>
			d: R_X86_64_PLT32	__x86_indirect_thunk_r11-0x4
  11:	59                   	pop    rcx
  12:	e9 00 00 00 00       	jmp    17 <entry+0x17>
			13: R_X86_64_PLT32	__x86_return_thunk-0x4
  17:	66 0f 1f 84 00 00 00 	nop    WORD PTR [rax+rax*1+0x0]
  1e:	00 00 

0000000000000020 <target>:
  20:	f3 0f 1e fa          	endbr64
  24:	b8 02 00 00 00       	mov    eax,0x2
  29:	e9 00 00 00 00       	jmp    2e <target+0xe>
			2a: R_X86_64_PLT32	__x86_return_thunk-0x4
