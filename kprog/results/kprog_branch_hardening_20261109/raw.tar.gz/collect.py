from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess,tarfile,gzip
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15');D=R/'kprog/results/kprog_branch_hardening_20261109'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def asm(p,binary=False):
 return subprocess.check_output(['objdump',*(['-D','-b','binary','-m','i386:x86-64'] if binary else ['-dr']),'-Mintel',str(p)],text=True)
def plain(text):return re.findall(r'\b(?:call|jmp)\s+(?:[er][a-z0-9]+|QWORD PTR)',text)
x86=read(O/'safety-x86/run/outcomes.json')
arm_summary=read(O/'safety-arm64/trusted-arm64-service-result/summary.json')
assert arm_summary.get('finished')
arm_archive=O/'safety-arm64/trusted-arm64-service-result'/arm_summary['archive']
with tarfile.open(arm_archive) as t:
 name=next(m.name for m in t.getmembers() if m.name.endswith('/outcomes.json'))
 arm=json.loads(t.extractfile(name).read())
bti_summary=read(O/'arm-bti/trusted-arm64-service-result/summary.json')
with tarfile.open(O/'arm-bti/trusted-arm64-service-result'/bti_summary['archive']) as t:
    name=next(m.name for m in t.getmembers() if m.name.endswith('/outcomes.json'))
    bti=json.loads(t.extractfile(name).read())
assert bti_summary['ok'] and len(bti)==1 and bti[0]['stage']=='valid_executed'
assert len(x86)==45 and len(arm)==42
assert all(not r['unsafe_native_executed'] for r in x86+arm)
controls={}
for name in ['tc-success','tc-retpoline','tc-current']:
 lines=[json.loads(s) for s in (O/name/'client.stdout').read_text().splitlines()]
 assert len(lines)==3 and all(r['retval']==2 and r['invocations']==34 and r['tail_transfers']==33 for r in lines[1:])
 text=asm(O/name/'native-image.bin',True);assert not plain(text)
 (O/name/'native-image.asm').write_text(text)
 controls[name]=dict(observations=lines,policy=(O/name/'kernel-policy.txt').read_text().strip(),plain_indirect_branches=0,jit_sha256=sha(O/name/'native-image.bin'))
# Relative symbol differences establish each pure-retpoline selected target.
nm=subprocess.check_output(['nm','-n',str(O/'kernel-build/vmlinux')],text=True)
current_symbols={m.group(2):int(m.group(1),16) for m in re.finditer(r'^([0-9a-f]+) [tT] (\S+)$',nm,re.M)}
for name,symbols in [('tc-retpoline',read(O/'kernel-symbols-measured.json')),('tc-current',current_symbols)]:
    text=(O/name/'native-image.asm').read_text()
    call=int(re.search(r'\bcall\s+(0xffffffff[0-9a-f]+)',text).group(1),16)
    external=[int(x,16) for x in re.findall(r'\bjmp\s+(0xffffffff[0-9a-f]+)',text)]
    reference=(call-symbols['__x86_indirect_thunk_r11'])%(1<<64)
    assert any((x-symbols['__x86_indirect_thunk_rcx'])%(1<<64)==reference for x in external)
    assert any((x-symbols['bpf_native_plain_return'])%(1<<64)==reference for x in external)
    controls[name]['selected_kernel_symbol_differences']='R11 CALL/JMP, RCX tail JMP and kernel plain-return fallback agree'
assert not plain(asm(O/'tc-retpoline/tail.native.o'))
summary=dict(commits=['731a91ee6b87cbad5340976de90f146afa912a25',(O/'tail-commit.txt').read_text().strip(),(O/'domain-commit.txt').read_text().strip(),(O/'policy-commit.txt').read_text().strip()],
 implementation='external thunk and landing flags; same-field kind12 kernel policy relocations; complete tail save mask15',
 components=dict(rust_tests=91,trusted_service_tests=9,register_transfer_layouts=30,compiled_B_adapters=['x86','arm64'],patch_idempotence='passed',kernel_build_exit=int((O/'kernel-resume.exit').read_text()),module_build_exit=int((O/'module.exit').read_text())),
 micro={a:dict(positive_compiles=len(list((O/('micro-'+a)).glob('*.compile.json'))),unchecked_read_compile=read(O/('micro-'+a+'-negative.json'))['exit'],batch_exit=int((O/('micro-'+a+'.exit')).read_text())) for a in ['x86','arm64']},
 x86=dict(cases=45,outcomes=dict(Counter(r['stage'] for r in x86)),findings=[r['name'] for r in x86 if r['stage']=='accepted_finding'],negative_executions=0),
 arm64=dict(cases=42,original_cases=41,original_outcomes=dict(Counter(r['stage'] for r in arm if r['name']!='branch_hardened')),outcomes=dict(Counter(r['stage'] for r in arm)),findings=[r['name'] for r in arm if r['stage']=='accepted_finding'],compiler_indirect_call_control=next(r['stage'] for r in arm if r['name']=='branch_hardened'),branch_control=bti[0]['stage'],bti_control_guest_exit=bti_summary['guest_exit'],bti_control_qemu_exit=bti_summary['qemu_returncode'],negative_executions=0,guest_exit=arm_summary['guest_exit'],qemu_exit=arm_summary['qemu_returncode'],compiler_host_jobs=len((O/'arm-transport/compiler-broker/jobs.jsonl').read_text().splitlines())),
 controls=controls,o4='partial-universal-component; V owns physical thunk, compiled source and full composition',
 inherited_frontier='ARM ordinary ADRP+ADD code-address discovery and compiled indirect-call saved-frame equality precision; architectural BTI ADR/BR control executes')
assert summary['arm64']['branch_control']=='valid_executed'
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(D/'source-identities.json').write_bytes((O/'source-identities.json').read_bytes())
(D/'kernel-source-epoch.json').write_bytes((O/'kernel-source-epoch.json').read_bytes())
(D/'runtime-identities.json').write_text(json.dumps({str(p.relative_to(O)):sha(p) for base in ['arm-runtime','module'] for p in (O/base).iterdir() if p.is_file()},indent=2)+'\n')
with gzip.open(O/'kernel.config.gz','wb') as f:f.write((O/'kernel-build/.config').read_bytes())
dirs=['source','offline-final-source','offline-domain-final','offline-domain-published','arm-bti','arm-bti-build','tc-current','tc','tc-final','tc-success','tc-retpoline','safety-x86','safety-arm64','micro-x86','micro-arm64']
files=[p for name in dirs for p in (O/name).rglob('*') if p.is_file() and not p.is_symlink()]
files += [p for p in O.iterdir() if p.is_file() and p.suffix in {'.py','.sh','.txt','.log','.exit','.json','.gz'}]
files += [p for p in (O/'arm-transport/compiler-broker').iterdir() if p.is_file() and p.name!='owner.lock']
files += [O/'arm-path/clang']
files=sorted(set(files))
manifest={str(p.relative_to(O)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
with tarfile.open(D/'raw.tar.gz','w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(O)),recursive=False)
(D/'raw-manifest.json').write_text(json.dumps(dict(archive_sha256=sha(D/'raw.tar.gz'),files=manifest),indent=2)+'\n')
print(json.dumps(summary,indent=2))
print('archive bytes', (D/'raw.tar.gz').stat().st_size)
