from pathlib import Path
import subprocess,os,select,shutil
O=Path('/var/tmp/kprog-tmp/S15')
try:
 fd=os.pidfd_open(3261512);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
assert (O/'kernel-resume.exit').read_text().strip()=='0'
for name in ['module.log','module.exit']:
 p=O/name
 if p.exists():shutil.copyfile(p,O/('first-current-'+name))
shutil.copyfile(O/'kernel-build/vmlinux.symvers',O/'kernel-build/Module.symvers')
shutil.copyfile(Path('/workspaces/repository/kinsn/module/x86/bpf_x86_native_lab.c'),O/'module/bpf_x86_native_lab.c')
with (O/'module.log').open('w') as log:x=subprocess.run(['taskset','-c','8-23','make','-C',str(O/'kernel-build'),'M='+str(O/'module'),'-j4','modules'],stdout=log,stderr=subprocess.STDOUT)
(O/'module.exit').write_text(str(x.returncode)+'\n')
