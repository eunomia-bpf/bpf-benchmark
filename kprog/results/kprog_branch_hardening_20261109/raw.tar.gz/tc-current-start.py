import os,select,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S15')
for pid in [3326963,3326965,3329327]:
 try:
  fd=os.pidfd_open(pid);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
assert (O/'kernel-resume.exit').read_text().strip()=='0'
assert (O/'module.exit').read_text().strip()=='0'
assert (O/'domain-commit.txt').exists()
with (O/'tc-current-controller.log').open('w') as log:x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'tc-current-mount.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'tc-current-start.exit').write_text(str(x.returncode)+'\n')
