import os,select,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S15')
try:
 fd=os.pidfd_open(3323895);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
p=O/'kernel-src/arch/x86/net/bpf_jit_comp.c';p.touch()
with (O/'kernel-policy-finish.log').open('w') as log:x=subprocess.run(['taskset','-c','8-23','python3',str(O/'kernel-resume.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'kernel-policy-finish.exit').write_text(str(x.returncode)+'\n')
