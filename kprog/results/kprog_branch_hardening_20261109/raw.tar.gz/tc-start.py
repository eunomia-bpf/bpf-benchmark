import os,select,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S15')
try:
 fd=os.pidfd_open(3281042);select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with (O/'tc-controller.log').open('w') as log:x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'tc-mount.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'tc-start.exit').write_text(str(x.returncode)+'\n')
