
/var/tmp/kprog-tmp/S15/tc-success/native-image.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
   0:	0f 1f 44 00 00       	nop    DWORD PTR [rax+rax*1+0x0]
   5:	48 31 c0             	xor    rax,rax
   8:	55                   	push   rbp
   9:	48 89 e5             	mov    rbp,rsp
   c:	48 81 ec 18 00 00 00 	sub    rsp,0x18
  13:	48 83 f8 21          	cmp    rax,0x21
  17:	77 06                	ja     0x1f
  19:	50                   	push   rax
  1a:	48 89 e0             	mov    rax,rsp
  1d:	eb 01                	jmp    0x20
  1f:	50                   	push   rax
  20:	50                   	push   rax
  21:	53                   	push   rbx
  22:	41 55                	push   r13
  24:	41 56                	push   r14
  26:	41 57                	push   r15
  28:	f3 0f 1e fa          	endbr64
  2c:	4c 8d 1d 05 00 00 00 	lea    r11,[rip+0x5]        # 0x38
  33:	e9 08 a5 c1 d6       	jmp    0xffffffffd6c1a540
  38:	f3 0f 1e fa          	endbr64
  3c:	48 83 ec 18          	sub    rsp,0x18
  40:	48 c7 04 24 07 00 00 	mov    QWORD PTR [rsp],0x7
  47:	00 
  48:	48 b8 30 c5 a2 82 7c 	movabs rax,0xffff8d7c82a2c530
  4f:	8d ff ff 
  52:	48 83 00 01          	add    QWORD PTR [rax],0x1
  56:	48 be 00 ac b8 84 7c 	movabs rsi,0xffff8d7c84b8ac00
  5d:	8d ff ff 
  60:	31 d2                	xor    edx,edx
  62:	41 bb 0c 00 00 00    	mov    r11d,0xc
  68:	89 d2                	mov    edx,edx
  6a:	39 96 44 00 00 00    	cmp    DWORD PTR [rsi+0x44],edx
  70:	0f 86 4a 00 00 00    	jbe    0xc0
  76:	48 8b 85 d8 ff ff ff 	mov    rax,QWORD PTR [rbp-0x28]
  7d:	48 83 38 21          	cmp    QWORD PTR [rax],0x21
  81:	0f 83 39 00 00 00    	jae    0xc0
  87:	48 8b 8c d6 30 01 00 	mov    rcx,QWORD PTR [rsi+rdx*8+0x130]
  8e:	00 
  8f:	48 85 c9             	test   rcx,rcx
  92:	0f 84 28 00 00 00    	je     0xc0
  98:	48 83 00 01          	add    QWORD PTR [rax],0x1
  9c:	48 83 c4 18          	add    rsp,0x18
  a0:	41 5f                	pop    r15
  a2:	41 5e                	pop    r14
  a4:	41 5d                	pop    r13
  a6:	5b                   	pop    rbx
  a7:	58                   	pop    rax
  a8:	58                   	pop    rax
  a9:	48 81 c4 18 00 00 00 	add    rsp,0x18
  b0:	48 8b 89 48 00 00 00 	mov    rcx,QWORD PTR [rcx+0x48]
  b7:	48 83 c1 0c          	add    rcx,0xc
  bb:	e9 40 a3 c1 d6       	jmp    0xffffffffd6c1a400
  c0:	8b 04 24             	mov    eax,DWORD PTR [rsp]
  c3:	83 f8 07             	cmp    eax,0x7
  c6:	0f 94 c0             	sete   al
  c9:	0f b6 c0             	movzx  eax,al
  cc:	01 c0                	add    eax,eax
  ce:	48 83 c4 18          	add    rsp,0x18
  d2:	41 5f                	pop    r15
  d4:	41 5e                	pop    r14
  d6:	41 5d                	pop    r13
  d8:	5b                   	pop    rbx
  d9:	c9                   	leave
  da:	e9 21 af c1 d6       	jmp    0xffffffffd6c1b000
