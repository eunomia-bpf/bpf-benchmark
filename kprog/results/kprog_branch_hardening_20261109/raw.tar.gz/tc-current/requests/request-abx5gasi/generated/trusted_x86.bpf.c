#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 24U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 tail_counter_value[] __ksym;
extern __u8 tail_jumps[] __ksym;
SEC("classifier")
int trusted_x86_x86_sim_xdp(struct __sk_buff *ctx)
{
	X86_SIM_ENTRY_SKB(ctx);
x86_l_0:
	/* 0x0: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_4:
	/* 0x4: lea    r11,[rip+0x57] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x62ULL);
x86_l_b:
	/* 0xb: call   10 <entry+0x10> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x62ULL: X86_SIM_X86_CALL(x86_l_62, 0x10ULL);
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10:
	/* 0x10: lea    r11,[rip+0x5] */
	X86_SIM_X86_CODE_ADDRESS(X86_R11, 0x1cULL);
x86_l_17:
	/* 0x17: jmp    1c <entry+0x1c> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x1cULL: goto x86_l_1c;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c:
	/* 0x1c: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_20:
	/* 0x20: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_24:
	/* 0x24: mov    QWORD PTR [rsp],0x7 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 7ULL);
x86_l_2c:
	/* 0x2c: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)tail_counter_value));
x86_l_33:
	/* 0x33: add    QWORD PTR [rax],0x1 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_RAX, X86_WIDTH_64, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 1ULL);
x86_l_37:
	/* 0x37: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)tail_jumps));
x86_l_3e:
	/* 0x3e: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_40:
	/* 0x40: mov    r11d,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_R11, X86_WIDTH_32, 12ULL);
x86_l_46:
	/* 0x46: call   4b <entry+0x4b> */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R11);
		switch (X86_SIM_L_REG_TAG(X86_R11)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4b:
	/* 0x4b: mov    eax,DWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4e:
	/* 0x4e: cmp    eax,0x7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 7ULL);
x86_l_51:
	/* 0x51: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_54:
	/* 0x54: movzx  eax,al */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_57:
	/* 0x57: add    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_59:
	/* 0x59: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_5d:
	/* 0x5d: jmp    62 <subreturn> */
	X86_SIM_X86_RET();
x86_l_70:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
	/* native subroutine native_link_sub_62 */
x86_l_62:
	/* 0x62: endbr64 */
	X86_SIM_RUN_OP(X86_OP_NOP, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_66:
	/* 0x66: mov    eax,0x0 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 0ULL);
x86_l_6b:
	/* 0x6b: jmp    70 <subreturn+0xe> */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x10ULL: goto x86_l_10;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();
