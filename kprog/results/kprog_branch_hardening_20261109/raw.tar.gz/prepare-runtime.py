from pathlib import Path
import json,shutil,hashlib,subprocess,tarfile
R=Path.cwd();O=Path('/var/tmp/kprog-tmp/S15')
# Pin simulator/service source for the upcoming private namespace.
paths=['kprog/trusted_service.py','kprog/trusted_generation.py','kprog/trusted_compile.py','kprog/fidelity/negative.py']
for arch in ['x86','arm64']:
 paths += [str(p.relative_to(R)) for p in (R/'kprog'/arch).glob('*.h')]
 paths += [str(p.relative_to(R)) for p in (R/'kprog'/arch/'micro-prog').glob('*.py')]
 paths += ['kprog/'+arch+'/trusted_specializer.py']
manifest={}
for name in paths:
 src=R/name;dst=O/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);manifest[name]=hashlib.sha256(dst.read_bytes()).hexdigest()
(O/'source-identities.json').write_text(json.dumps(manifest,indent=2)+'\n')
for arch in ['x86','arm64']:
 out=O/('safety-'+arch);out.mkdir(exist_ok=True)
 shutil.copyfile(R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/check.py',out/'_base_check.py')
 # Preserve the existing harness and cases. ARM carries its existing four positives.
 with tarfile.open(R/'kprog/results/kprog_s11_context_tail_flags_20261109/raw.tar.gz') as tar:
  source=tar.extractfile('safety-prepare.py').read().decode().replace('/var/tmp/kprog-tmp/S11','/var/tmp/kprog-tmp/S15')
 # The archived preparation creates both wrappers using the original suite.
 if arch=='x86':
  (O/'archived-safety-prepare.py').write_text(source)
  subprocess.run(['python3',str(O/'archived-safety-prepare.py')],check=True)
# Guest service and tail fixture use the lane's private artifacts directly.
with tarfile.open(R/'kprog/results/kprog_s11_context_tail_flags_20261109/raw.tar.gz') as tar:
 guest=tar.extractfile('guest-tc.py').read().decode()
guest=guest.replace("O=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/tc'","O=Path('/var/tmp/kprog-tmp/S15/tc')")
(O/'guest-tc.py').write_text(guest)
