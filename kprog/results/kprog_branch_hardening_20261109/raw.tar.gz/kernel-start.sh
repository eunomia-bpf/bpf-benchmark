#!/bin/bash
O=/var/tmp/kprog-tmp/S15
taskset -c 8-23 bash "$O/kernel-build.sh" >"$O/kernel.log" 2>&1
echo $? >"$O/kernel.exit"
