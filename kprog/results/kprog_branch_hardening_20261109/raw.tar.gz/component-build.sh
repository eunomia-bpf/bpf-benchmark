#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo PYTHONDONTWRITEBYTECODE=1
export PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH
cd /workspaces/repository
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/release.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/release.exit
taskset -c 8-23 make -C kprog/libnativeloader trusted-service-check BUILD_DIR=/var/tmp/kprog-tmp/S15/loader >/var/tmp/kprog-tmp/S15/loader.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/loader.exit
