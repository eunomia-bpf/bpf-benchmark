#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CLANG=clang-18 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo
cd /workspaces/repository
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/rust-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/rust-final.exit
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S15/release-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/release-final.exit
taskset -c 8-23 clang-18 -O2 -g -target bpf -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c kprog/test/tail_call_frame/program.c -o /var/tmp/kprog-tmp/S15/tail.bpf.o
echo $? >/var/tmp/kprog-tmp/S15/tail-bpf.exit
taskset -c 8-23 g++ -std=c++20 -O2 -Ivendor/libbpf/include/uapi -Irunner/build-llvmbpf/vendor/libbpf/prefix/include kprog/test/tail_call_frame/client.cpp /var/tmp/kprog-tmp/S15/loader/libnative_loader.a runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -o /var/tmp/kprog-tmp/S15/tail-client >/var/tmp/kprog-tmp/S15/tail-client.log 2>&1
echo $? >/var/tmp/kprog-tmp/S15/tail-client.exit
