from pathlib import Path
import subprocess,json,shutil,hashlib
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S15')
def bind(a,b):subprocess.run(['mount','--bind',str(a),str(b)],check=True)
for name in json.loads((O/'source-identities.json').read_text()):bind(O/'source'/name,R/name)
source=Path('/var/tmp/kprog-tmp/A/dynptr-access/qemu/runtime')
runtime=O/'arm-runtime';runtime.mkdir(exist_ok=True)
for p in source.iterdir():
 if p.is_file():shutil.copy2(p,runtime/p.name)
loader=R/'kprog/libnativeloader/build-arm64-a-map-order-v3'
local_loader=O/'arm-loader';local_loader.mkdir(exist_ok=True)
for name in ['trusted-native-loader','trusted-service-client','libnative_loader.so']:
 shutil.copy2(runtime/name,local_loader/name)
shutil.copy2(loader/'libnative_loader.a',local_loader/'libnative_loader.a')
shutil.copy2(loader/'trusted-native.o',local_loader/'trusted-native.o')
bind(local_loader,loader)
bind(runtime/'native-link',R/'kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link')
bind(runtime/'Image',R/'vendor/build/arm64/linux/arch/arm64/boot/Image')
bind(runtime/'bpf_arm64_native_lab.ko',R/'kinsn/module/arm64/build-native-resources/bpf_arm64_native_lab.ko')
folder=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp';folder.mkdir(exist_ok=True);bind(O/'safety-arm64',folder)
build=R/'kprog/formal/build/fidelity-trusted-arm64';build.mkdir(exist_ok=True);bind(O/'build-arm64',build)
transport=O/'arm-transport';transport.mkdir(exist_ok=True);bind(transport,R/'kprog/arm64/build/trusted-transport')
wrapper=folder/'s11.py'
subprocess.run(['taskset','-c','8-23','python3',str(wrapper),'build'],check=True)
# Compile-policy control travels through the same submitted native-only manifest.
native=build/'branch_hardened.native.o';shutil.copy2(O/'offline-published/arm64.native.o',native)
manifest=folder/'branch_hardened.manifest.json';manifest.write_text(json.dumps(dict(objects=[dict(program='neg_source',source_btf_symbol='neg_source',native_object=str(native),symbol='entry')])))
p=folder/'cases.json';rows=json.loads(p.read_text());rows.append(dict(name='branch_hardened',assembly='Clang tiny-model BTI indirect-call control',negative=False,native_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),manifest=str(manifest)));p.write_text(json.dumps(rows,indent=2)+'\n')
x=subprocess.run(['taskset','-c','8-23','python3',str(wrapper),'host'])
(O/'arm-controller.exit').write_text(str(x.returncode)+'\n')
