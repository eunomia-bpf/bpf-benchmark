#!/bin/bash
set -e
export TMPDIR=/var/tmp/kprog-tmp/S15 PYTHONDONTWRITEBYTECODE=1 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S15/cargo CLANG=clang-18 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
cd /workspaces/repository
O=/var/tmp/kprog-tmp/S15
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/rust-domain.log" 2>&1
taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >"$O/release-domain.log" 2>&1
taskset -c 8-23 python3 kprog/tv/test_native_branch_hardening.py "$O/cargo/release/native-link" "$O/offline-domain-published" >"$O/offline-domain-published.log" 2>&1
git status --short --branch >"$O/domain-precommit-status.txt"
git diff --check -- kprog/x86/native_lab/native_link/src/x86.rs kprog/tv/test_native_branch_hardening.py
git commit --only -m 'Preserve the compiler thunk register domain in relocation decoding' -- kprog/x86/native_lab/native_link/src/x86.rs kprog/tv/test_native_branch_hardening.py
git push origin master
git rev-parse HEAD >"$O/domain-commit.txt"
