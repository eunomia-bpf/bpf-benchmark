from pathlib import Path
r=Path('/workspaces/repository')
p=r/'kinsn/module/x86/bpf_x86_native_lab.c';s=p.read_text()
s=s.replace('#define NATIVE_LAB_RELOC_HELPER_CALL_REL32 1','#define NATIVE_LAB_RELOC_HELPER_CALL_REL32 1\nextern void *bpf_x86_native_thunk(u32 selector, bool call);')
a='\t\t\t\tcase NATIVE_LAB_RELOC_X86_TAIL_COUNT:'
i=s.index(a)
s=s[:i]+'''\t\t\t\tcase NATIVE_LAB_RELOC_X86_THUNK: {
                    void *target = bpf_x86_native_thunk(r->target,
                        blob->bytes[r->offset - 1] == 0xe8);
                    s64 displacement;
                    s32 field;

                    if (IS_ERR(target)) { err = PTR_ERR(target); break; }
                    displacement = (s64)(unsigned long)target -
                        (s64)(unsigned long)(final_emit_at + r->offset + 4);
                    field = displacement;
                    if ((s64)field != displacement) { err = -ERANGE; break; }
                    memcpy(emit_at + r->offset, &field, sizeof(field));
                    break;
                }

'''+s[i:];p.write_text(s)
# Add a kernel-owned symbol resolver alongside emit_return. Its return arm
# shares the active return target; register thunks receive kernel alternatives.
body='''
/* Compiler external thunks and native tail transfers use this same policy. */
extern void bpf_native_plain_return(void);
asm(".pushsection .text\\n"
    ".type bpf_native_plain_return,@function\\n"
    "bpf_native_plain_return:\\n"
    ANNOTATE_NOENDBR
    ANNOTATE_UNRET_SAFE
    "ret\\nint3\\n"
    ".size bpf_native_plain_return,.-bpf_native_plain_return\\n"
    ".popsection\\n");

void *bpf_x86_native_thunk(u32 selector, bool call)
{
    if (selector == 16)
        return cpu_wants_rethunk() ? (void *)x86_return_thunk :
                                    (void *)bpf_native_plain_return;
    if (selector >= 16)
        return ERR_PTR(-EINVAL);
    if (cpu_feature_enabled(X86_FEATURE_INDIRECT_THUNK_ITS))
        return its_static_thunk(selector);
#ifdef CONFIG_MITIGATION_CALL_DEPTH_TRACKING
    if (cpu_feature_enabled(X86_FEATURE_CALL_DEPTH))
        return call ? (void *)__x86_indirect_call_thunk_array[selector] :
                      (void *)__x86_indirect_jump_thunk_array[selector];
#endif
#ifdef CONFIG_MITIGATION_RETPOLINE
    /* This array receives the stock LFENCE/retpoline/direct alternatives. */
    return __x86_indirect_thunk_array[selector];
#else
    return ERR_PTR(-EOPNOTSUPP);
#endif
}
EXPORT_SYMBOL_GPL(bpf_x86_native_thunk);
'''
p=r/'kprog/tv/native-proof-regions.patch';s=p.read_text();anchor='diff --git a/arch/x86/net/bpf_jit_comp.c b/arch/x86/net/bpf_jit_comp.c'
i=s.index(anchor);h=s.index('@@ ',i)
new='@@ -787,0 +788,'+str(len(body.splitlines()))+' @@\n'+''.join('+'+line+'\n' for line in body.splitlines())
# Place after existing x86 hunks so patch follows increasing source order.
j=s.index('\ndiff --git ',h)
# Hunk source order requires inserting after the emit_kinsn hunks and before1813.
k=s.index('@@ -1813',h);s=s[:k]+new+s[k:];p.write_text(s)
# Keep implementation text for applying the new addition to existing caches.
Path('/var/tmp/kprog-tmp/S15/kernel-addition.txt').write_text(body)
