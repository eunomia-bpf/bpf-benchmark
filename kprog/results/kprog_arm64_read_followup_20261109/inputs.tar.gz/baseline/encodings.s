.text
.arch armv8.1-a+lse
casp w0,w1,w2,w3,[x4]
casp x0,x1,x2,x3,[x4]
cas x0,x1,[x4]
cas w0,w1,[x4]
casb w0,w1,[x4]
cash w0,w1,[x4]
stxp w2,x3,xzr,[x1]
ldxp x0,xzr,[x1]
stxp w2,w3,wzr,[x1]
ldxp w0,wzr,[x1]
