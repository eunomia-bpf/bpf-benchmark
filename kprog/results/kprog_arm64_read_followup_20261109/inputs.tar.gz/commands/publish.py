from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path('/workspaces/repository');S=Path('/var/tmp/kprog-tmp/S10')
def publish(paths,message,label):
 env=dict(os.environ,GIT_INDEX_FILE=str(S/(label+'.index')))
 def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=R,env=env,input=input).decode().strip()
 while True:
  base=git('rev-parse','HEAD');git('read-tree',base);pins={}
  for p in paths:
   data=(R/p).read_bytes();obj=git('hash-object','-w','--stdin',input=data);git('update-index','--add','--cacheinfo','100644',obj,p);pins[p]=hashlib.sha256(data).hexdigest()
  git('diff','--cached','--check');tree=git('write-tree');commit=git('commit-tree',tree,'-p',base,'-m',message)
  if subprocess.run(['git','update-ref','refs/heads/master',commit,base],cwd=R,capture_output=True).returncode==0:break
 subprocess.run(['git','push','origin','HEAD:master'],cwd=R,check=True)
 remote=git('ls-remote','origin','refs/heads/master').split()[0];subprocess.run(['git','merge-base','--is-ancestor',commit,remote],cwd=R,check=True)
 result=dict(commit=commit,sha256=pins,paths=paths,remote_ancestor_verified=True);(S/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');return result
if __name__=='__main__':print(json.dumps(publish(sys.argv[3:],sys.argv[1],sys.argv[2]),indent=2))
