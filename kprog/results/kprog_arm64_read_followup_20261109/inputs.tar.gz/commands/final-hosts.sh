export TMPDIR=/var/tmp/kprog-tmp/S10
ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -k -f /var/tmp/kprog-tmp/S10/commands/hosts.mk s10-hosts > /var/tmp/kprog-tmp/S10/hosts.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/hosts.exit
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/commands/micro.mk s10-micro > /var/tmp/kprog-tmp/S10/micro.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/micro.exit
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/commands/micro.mk s10-negative-micro > /var/tmp/kprog-tmp/S10/negative-micro.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/negative-micro.exit
