from pathlib import Path
import os,subprocess,sys
R=Path('/workspaces/repository');S=Path('/var/tmp/kprog-tmp/S10')
for p in sorted((S/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(S/'source'))],check=True)
pairs=[(S/'transport',R/'kprog/arm64/build/trusted-transport'),(S/'suite',R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp'),(S/'safety-build',R/'kprog/formal/build/fidelity-trusted-arm64'),(S/'fixture',R/'kprog/arm64/build/native-load-recovery/null-fixture'),(S/'module-output/bpf_arm64_native_lab.ko',R/'kprog/arm64/build/native-load-recovery/recovery/bpf_arm64_native_lab.ko'),(S/'commands/transport3.py',R/'corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py')]
for target in ['kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link','kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/native-link-arm64-entry-resources']:
 pairs.append((S/'cargo-build/aarch64-unknown-linux-gnu/release/native-link',R/target))
stage=R/'kprog/arm64/build/native-load-recovery/recovery'
for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:
 pairs.append((stage/name,R/'runner/build-arm64-llvmbpf/native_loader'/name))
for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:
 dst=R/'kprog/libnativeloader/build-arm64-a-map-order-v3'/name
 if dst.exists():pairs.append((stage/name,dst))
for src,dst in pairs:subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
os.execvp('make',['make','-f',str(S/'commands/guest.mk'),'guest'])
