include /workspaces/repository/kprog/formal/Makefile

s10-hosts:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cond_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_cond_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_cond_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cc_decode_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_cc_decode_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_cc_decode_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_helper_idents_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_idents_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_idents_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_tag_host.c -o /var/tmp/kprog-tmp/S10/hosts/cross_isa_tag_host
	/var/tmp/kprog-tmp/S10/hosts/cross_isa_tag_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_differential_host.c -o /var/tmp/kprog-tmp/S10/hosts/cross_isa_differential_host
	/var/tmp/kprog-tmp/S10/hosts/cross_isa_differential_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_width_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_width_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_width_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_width_effective_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_width_effective_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_width_effective_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_width_effective_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_width_effective_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_width_effective_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flags_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_flags_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_flags_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_result_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_result_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_result_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_handler_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_handler_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_operand_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flag_operand_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_operand_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_operand_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_imm_operand_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_imm_operand_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_imm_operand_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_imm_operand_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_imm_operand_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_imm_operand_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_operand_select_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_select_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_select_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_alu_operand_select_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_select_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_alu_operand_select_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flag_handler_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_handler_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_logic_flag_handler_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_logic_flag_handler_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_logic_flag_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ccmp_handler_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_ccmp_handler_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_ccmp_handler_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ccmp_decode_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_ccmp_decode_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_ccmp_decode_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dispatch_family_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_family_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_family_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_family_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_family_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_family_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dispatch_singleton_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_singleton_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_singleton_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dispatch_singleton_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mod_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mod_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mod_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_bitfield_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_bitfield_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_bitfield_host
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. oracles/test_arm64_mul_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mul_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_flag_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_flag_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_csel_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mul_wide_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_wide_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mul_wide_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_extrev_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_extrev_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_extrev_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_csel_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_csel_ptr_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_ptr_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_csel_ptr_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_branch_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_branch_emit_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_emit_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_emit_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_movk_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_movk_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_movk_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_shift_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_shift_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_shift_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_reduction_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reduction_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reduction_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_unary_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_unary_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_unary_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_unary_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_unary_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_unary_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_cneg_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_cneg_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_cneg_route_host
	$(CC) -include oracles/arm64_entry_environment_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stlxr_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stlxr_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stlxr_route_host
	$(CC) -include oracles/arm64_entry_environment_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_memory_tokens_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_memory_tokens_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_memory_tokens_host
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_return_token_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_return_token_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_return_token_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reduction_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reduction_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reduction_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_adrp_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_adrp_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_adrp_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_extrev_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_extrev_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_extrev_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_orn_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_orn_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_orn_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_branch_emit_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_emit_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_branch_emit_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_cbz_tbz_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_cbz_tbz_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_cbz_tbz_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_call_ret_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_call_ret_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_call_ret_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_call_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_call_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_call_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_entry_context_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_entry_context_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_entry_context_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cneg_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_cneg_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_cneg_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_orn_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_orn_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_orn_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_adrp_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_adrp_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_adrp_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stlxr_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stlxr_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stlxr_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mov_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mov_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mov_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ldrsx_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ldrsx_op_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_op_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_op_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ldrsx_op_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_op_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_ldrsx_op_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_load_tag_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_load_tag_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_load_tag_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_pair_load_tag_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_load_tag_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_load_tag_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_offset_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_offset_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_offset_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_index_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_index_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_reg_presence_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_presence_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_presence_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reg_presence_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_presence_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_presence_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_reg_dispatch_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_dispatch_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_dispatch_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reg_dispatch_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_dispatch_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_reg_dispatch_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_fmov_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_fmov_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_fmov_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_fmov_dest_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_fmov_dest_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_fmov_dest_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_load_bytes_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_load_bytes_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_load_bytes_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_store_bytes_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_store_bytes_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_store_bytes_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_store_bytes_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_store_bytes_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_store_bytes_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_byte_lane_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_byte_lane_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_byte_lane_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_dispatch_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_dispatch_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_dispatch_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_write_arm_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_write_arm_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_write_arm_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_write_arm_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_write_arm_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_write_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_tag_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_tag_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_tag_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_arm_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arm_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arm_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_arm_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arm_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_write_lanes_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_lanes_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_lanes_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_write_lanes_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_lanes_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_lanes_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_write_tag_action_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_tag_action_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_tag_action_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_write_tag_action_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_tag_action_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_write_tag_action_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_read_tag_source_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_read_tag_source_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_read_tag_source_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_read_tag_source_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_read_tag_source_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_read_tag_source_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_helper_arg_ptr_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_arg_ptr_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_arg_ptr_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_arg_ptr_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_arg_ptr_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_helper_arg_ptr_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_base_src_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_base_src_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_base_src_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_base_src_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_base_src_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_base_src_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_index_value_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_value_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_value_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_index_value_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_value_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_index_value_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dq_mem_extra_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_extra_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_extra_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_extra_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_extra_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_extra_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_vreg_field_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_field_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_field_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_field_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_field_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_field_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_write_arm_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_write_arm_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_write_arm_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_write_arm_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_write_arm_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_write_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dq_mem_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_dq_mem_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_pair_mem_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_mem_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_mem_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_pair_mem_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_mem_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_pair_mem_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_prepost_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_prepost_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_prepost_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_prepost_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_prepost_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_mem_prepost_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_vreg_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_vreg_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../arm64 oracles/test_arm64_aux_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_aux_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_aux_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_aux_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_aux_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_aux_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_arena_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arena_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arena_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_index_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_index_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_index_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_arena_route_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arena_route_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_stack_arena_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 oracles/test_arm64_decode_host.c -o /var/tmp/kprog-tmp/S10/hosts/test_arm64_decode_host
	/var/tmp/kprog-tmp/S10/hosts/test_arm64_decode_host
