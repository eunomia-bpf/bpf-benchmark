set -e
cd /workspaces/repository
mount --bind /var/tmp/kprog-tmp/S10/hosts/control-header.h kprog/arm64/arm64_sim_local_bpf.h
cd kprog/formal
export TMPDIR=/var/tmp/kprog-tmp/S10
set +e
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/commands/baseline-all.mk s10-oracle-53 > /var/tmp/kprog-tmp/S10/hosts/helper-control.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/hosts/helper-control.exit
