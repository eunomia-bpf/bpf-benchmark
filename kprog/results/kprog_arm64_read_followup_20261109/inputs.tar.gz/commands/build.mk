R := /workspaces/repository
S := /var/tmp/kprog-tmp/S10
K := /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/cache
module:
	$(MAKE) -C $(R)/vendor/linux-framework O=$(K) M=$(S)/module-source MO=$(S)/module-output ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j2 modules
native-link:
	CARGO_TARGET_AARCH64_UNKNOWN_LINUX_GNU_LINKER=aarch64-linux-gnu-gcc CARGO_TARGET_DIR=$(S)/cargo-build cargo build --release --target aarch64-unknown-linux-gnu -j2 --manifest-path $(S)/cargo-source/Cargo.toml

fixture:
	$(MAKE) -C $(R)/vendor/linux-framework O=$(K) M=$(S)/fixture-source MO=$(S)/fixture/module ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- -j2 modules
	$(R)/vendor/build/x86/bpftool/bin/bpftool btf dump file $(K)/vmlinux format c > $(S)/fixture/vmlinux.h
	clang-18 --target=aarch64-linux-gnu -O3 -g -fPIC -mgeneral-regs-only -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -fno-stack-protector -fno-asynchronous-unwind-tables -fno-unwind-tables -fno-jump-tables -fno-optimize-sibling-calls -I$(S)/fixture -c $(S)/fixture-source/native.c -o $(S)/fixture/native.o
	clang-18 --target=aarch64-linux-gnu -O3 -g -fPIC -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -fno-stack-protector -fno-asynchronous-unwind-tables -fno-unwind-tables -fno-jump-tables -fno-optimize-sibling-calls -I$(S)/fixture -c $(S)/fixture-source/arm64.c -o $(S)/fixture/arm64.o
	aarch64-linux-gnu-g++ -std=c++20 -O2 -I$(R)/runner/build-arm64-llvmbpf/vendor/libbpf/prefix/include -I$(R)/kprog/test/native_load_fault $(S)/fixture-source/probe.cpp $(R)/runner/build-arm64-llvmbpf/native_loader/libnative_loader.a $(R)/runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -L$(R)/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu -Wl,-rpath-link,$(R)/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu -lelf -lz -ldl -pthread -o $(S)/fixture/probe

vector-fixture:
	clang-18 --target=aarch64-linux-gnu -O3 -g -fPIC -mno-outline-atomics -ffixed-x18 -ffixed-x26 -ffixed-x27 -ffixed-x28 -fno-stack-protector -fno-asynchronous-unwind-tables -fno-unwind-tables -fno-jump-tables -fno-optimize-sibling-calls -Wno-unknown-attributes -I$(S)/fixture -c $(S)/fixture4-source/arm64.c -o $(S)/fixture4/arm64.o
	aarch64-linux-gnu-g++ -std=c++20 -O2 -I$(R)/runner/build-arm64-llvmbpf/vendor/libbpf/prefix/include -I$(R)/kprog/test/native_load_fault $(S)/fixture4-source/probe.cpp $(R)/runner/build-arm64-llvmbpf/native_loader/libnative_loader.a $(R)/runner/build-arm64-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -L$(R)/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu -Wl,-rpath-link,$(R)/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu -lelf -lz -ldl -pthread -o $(S)/fixture4/probe
