guest:
	python3 /workspaces/repository/corpus/results/kprog_arm64_app_coverage_20261106/trusted_service_arm64.py host control /var/tmp/kprog-tmp/S10/guest-result
