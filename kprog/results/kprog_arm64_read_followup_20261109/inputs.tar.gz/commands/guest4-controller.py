from pathlib import Path
import os,select,subprocess
S=Path('/var/tmp/kprog-tmp/S10')
try:
 fd=os.pidfd_open(int((S/'final-guest-controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
if (S/'guest-result').exists():(S/'guest-result').rename(S/'guest-attempt3')
(S/'guest3.exit').rename(S/'guest-attempt3.exit')
with (S/'guest4.log').open('w') as out:
 p=subprocess.run(['taskset','-c','8-23','unshare','--mount','--propagation','private','python3',str(S/'commands/mount-guest4.py')],stdout=out,stderr=subprocess.STDOUT)
(S/'guest4.exit').write_text(str(p.returncode)+'\n')
