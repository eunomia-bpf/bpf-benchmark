from pathlib import Path
import os,select,subprocess
S=Path('/var/tmp/kprog-tmp/S10')
try:
 fd=os.pidfd_open(int((S/'guest2-controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
if (S/'guest-result').exists():(S/'guest-result').rename(S/'guest-attempt2')
(S/'guest.exit').rename(S/'guest-attempt2.exit')
with (S/'guest3.log').open('w') as out:
 p=subprocess.run(['taskset','-c','8-23','unshare','--mount','--propagation','private','python3',str(S/'commands/mount-guest3.py')],stdout=out,stderr=subprocess.STDOUT)
(S/'guest3.exit').write_text(str(p.returncode)+'\n')
