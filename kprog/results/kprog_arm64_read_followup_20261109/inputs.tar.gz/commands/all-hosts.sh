export TMPDIR=/var/tmp/kprog-tmp/S10
ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -k -f /var/tmp/kprog-tmp/S10/commands/all-hosts.mk s10-all > /var/tmp/kprog-tmp/S10/all-hosts.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/all-hosts.exit
