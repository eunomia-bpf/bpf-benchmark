ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/hosts.mk s10-hosts > /var/tmp/kprog-tmp/S10/hosts.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/hosts.exit
