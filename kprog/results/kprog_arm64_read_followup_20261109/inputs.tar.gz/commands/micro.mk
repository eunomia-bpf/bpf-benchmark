s10-micro:
	python3 /workspaces/repository/kprog/arm64/micro-prog/generate_micro_sim_proofs.py --config /workspaces/repository/micro/config/micro_pure_jit.yaml --proof-object-dir /workspaces/repository/kprog/arm64/micro-prog/build/native-link --output-dir /var/tmp/kprog-tmp/S10/micro-src
	python3 /var/tmp/kprog-tmp/S10/commands/compile-micros.py
s10-negative-micro:
	python3 /workspaces/repository/kprog/arm64/micro-prog/generate_micro_sim_proofs.py --config /workspaces/repository/kprog/test/kprog_negative_stage2.yaml --proof-object-dir /workspaces/repository/kprog/arm64/micro-prog/build/native-link --output-dir /var/tmp/kprog-tmp/S10/negative-src
	python3 /var/tmp/kprog-tmp/S10/commands/compile-negative.py
