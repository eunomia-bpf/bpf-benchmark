export PATH=/root/.cargo/bin:/usr/local/cargo/bin:$PATH
export TMPDIR=/var/tmp/kprog-tmp/S10
ulimit -c 0
taskset -c 8-23 unshare --mount --propagation private sh /var/tmp/kprog-tmp/S10/commands/build-module.sh > /var/tmp/kprog-tmp/S10/module.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/module.exit
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/commands/build.mk native-link > /var/tmp/kprog-tmp/S10/native-link.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/native-link.exit
