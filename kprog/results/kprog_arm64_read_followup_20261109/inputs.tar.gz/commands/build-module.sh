set -eu
cd /workspaces/repository
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/cache /workspaces/repository/vendor/build/arm64/linux
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/kernel/bpf/verifier.c /workspaces/repository/vendor/linux-framework/kernel/bpf/verifier.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/kernel/bpf/core.c /workspaces/repository/vendor/linux-framework/kernel/bpf/core.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/kernel/bpf/btf.c /workspaces/repository/vendor/linux-framework/kernel/bpf/btf.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/kernel/bpf/syscall.c /workspaces/repository/vendor/linux-framework/kernel/bpf/syscall.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/kernel/bpf/offload.c /workspaces/repository/vendor/linux-framework/kernel/bpf/offload.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/arch/x86/net/bpf_jit_comp.c /workspaces/repository/vendor/linux-framework/arch/x86/net/bpf_jit_comp.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/arch/arm64/net/bpf_jit_comp.c /workspaces/repository/vendor/linux-framework/arch/arm64/net/bpf_jit_comp.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/include/linux/bpf_verifier.h /workspaces/repository/vendor/linux-framework/include/linux/bpf_verifier.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/include/linux/bpf.h /workspaces/repository/vendor/linux-framework/include/linux/bpf.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/kernel-source/include/linux/bpf_native_input.h /workspaces/repository/vendor/linux-framework/include/linux/bpf_native_input.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/stack-frame/kernel-link/verifier.c /workspaces/repository/vendor/linux-framework/kernel/bpf/verifier.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/byte-atomic/btf.c /workspaces/repository/vendor/linux-framework/kernel/bpf/btf.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-extent/bpf_jit_comp.c /workspaces/repository/vendor/linux-framework/arch/arm64/net/bpf_jit_comp.c
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/lsm_hook_defs.h /workspaces/repository/vendor/linux-framework/include/linux/lsm_hook_defs.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/bpf.h /workspaces/repository/vendor/linux-framework/include/linux/bpf.h
mount --bind /workspaces/.agent-state/kprog-lanes/A/native-load-recovery/arm64/bpf_jit_comp.c /workspaces/repository/vendor/linux-framework/arch/arm64/net/bpf_jit_comp.c
exec make -f /var/tmp/kprog-tmp/S10/commands/build.mk module
