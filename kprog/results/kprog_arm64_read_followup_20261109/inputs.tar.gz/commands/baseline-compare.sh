set -e
cd /workspaces/repository
mount --bind /var/tmp/kprog-tmp/S10/baseline/arm64_sim_local_bpf.h kprog/arm64/arm64_sim_local_bpf.h
cd kprog/formal
export TMPDIR=/var/tmp/kprog-tmp/S10
set +e
taskset -c 8-23 make -k -f /var/tmp/kprog-tmp/S10/commands/baseline-all.mk s10-oracle-16 s10-oracle-24 s10-oracle-45 s10-oracle-53 s10-oracle-62 s10-oracle-91 s10-oracle-93 s10-oracle-97 s10-oracle-99 s10-oracle-103 s10-oracle-105 s10-oracle-107 s10-oracle-109 > /var/tmp/kprog-tmp/S10/baseline/host-compare.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/baseline/host-compare.exit
