export TMPDIR=/var/tmp/kprog-tmp/S10
ulimit -c 0
taskset -c 8-23 unshare --mount --propagation private python3 /var/tmp/kprog-tmp/S10/commands/mount-guest.py > /var/tmp/kprog-tmp/S10/guest.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/guest.exit
