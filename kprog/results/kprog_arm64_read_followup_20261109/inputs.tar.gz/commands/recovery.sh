ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/recovery.mk s10-recovery > /var/tmp/kprog-tmp/S10/recovery.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/recovery.exit
