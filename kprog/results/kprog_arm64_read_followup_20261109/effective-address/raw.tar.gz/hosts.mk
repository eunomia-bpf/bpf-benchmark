include /workspaces/repository/kprog/formal/Makefile


.PHONY: s10-all s10-oracle-0 s10-oracle-1 s10-oracle-2 s10-oracle-3 s10-oracle-4 s10-oracle-5 s10-oracle-6 s10-oracle-7 s10-oracle-8 s10-oracle-9 s10-oracle-10 s10-oracle-11 s10-oracle-12 s10-oracle-13 s10-oracle-14 s10-oracle-15 s10-oracle-16 s10-oracle-17 s10-oracle-18 s10-oracle-19 s10-oracle-20 s10-oracle-21 s10-oracle-22 s10-oracle-23 s10-oracle-24 s10-oracle-25 s10-oracle-26 s10-oracle-27 s10-oracle-28 s10-oracle-29 s10-oracle-30 s10-oracle-31 s10-oracle-32 s10-oracle-33 s10-oracle-34 s10-oracle-35 s10-oracle-36 s10-oracle-37 s10-oracle-38 s10-oracle-39 s10-oracle-40 s10-oracle-41 s10-oracle-42 s10-oracle-43 s10-oracle-44 s10-oracle-45 s10-oracle-46 s10-oracle-47 s10-oracle-48 s10-oracle-49 s10-oracle-50 s10-oracle-51 s10-oracle-52 s10-oracle-53 s10-oracle-54 s10-oracle-55 s10-oracle-56 s10-oracle-57 s10-oracle-58 s10-oracle-59 s10-oracle-60 s10-oracle-61 s10-oracle-62 s10-oracle-63 s10-oracle-64 s10-oracle-65 s10-oracle-66 s10-oracle-67 s10-oracle-68 s10-oracle-69 s10-oracle-70 s10-oracle-71 s10-oracle-72 s10-oracle-73 s10-oracle-74 s10-oracle-75 s10-oracle-76 s10-oracle-77 s10-oracle-78 s10-oracle-79 s10-oracle-80 s10-oracle-81 s10-oracle-82 s10-oracle-83 s10-oracle-84 s10-oracle-85 s10-oracle-86 s10-oracle-87 s10-oracle-88 s10-oracle-89 s10-oracle-90 s10-oracle-91 s10-oracle-92 s10-oracle-93 s10-oracle-94 s10-oracle-95 s10-oracle-96 s10-oracle-97 s10-oracle-98 s10-oracle-99 s10-oracle-100 s10-oracle-101 s10-oracle-102 s10-oracle-103 s10-oracle-104 s10-oracle-105 s10-oracle-106 s10-oracle-107 s10-oracle-108 s10-oracle-109 s10-oracle-110 s10-oracle-111 s10-oracle-112 s10-oracle-113 s10-oracle-114 s10-oracle-115
s10-all: s10-oracle-0 s10-oracle-1 s10-oracle-2 s10-oracle-3 s10-oracle-4 s10-oracle-5 s10-oracle-6 s10-oracle-7 s10-oracle-8 s10-oracle-9 s10-oracle-10 s10-oracle-11 s10-oracle-12 s10-oracle-13 s10-oracle-14 s10-oracle-15 s10-oracle-16 s10-oracle-17 s10-oracle-18 s10-oracle-19 s10-oracle-20 s10-oracle-21 s10-oracle-22 s10-oracle-23 s10-oracle-24 s10-oracle-25 s10-oracle-26 s10-oracle-27 s10-oracle-28 s10-oracle-29 s10-oracle-30 s10-oracle-31 s10-oracle-32 s10-oracle-33 s10-oracle-34 s10-oracle-35 s10-oracle-36 s10-oracle-37 s10-oracle-38 s10-oracle-39 s10-oracle-40 s10-oracle-41 s10-oracle-42 s10-oracle-43 s10-oracle-44 s10-oracle-45 s10-oracle-46 s10-oracle-47 s10-oracle-48 s10-oracle-49 s10-oracle-50 s10-oracle-51 s10-oracle-52 s10-oracle-53 s10-oracle-54 s10-oracle-55 s10-oracle-56 s10-oracle-57 s10-oracle-58 s10-oracle-59 s10-oracle-60 s10-oracle-61 s10-oracle-62 s10-oracle-63 s10-oracle-64 s10-oracle-65 s10-oracle-66 s10-oracle-67 s10-oracle-68 s10-oracle-69 s10-oracle-70 s10-oracle-71 s10-oracle-72 s10-oracle-73 s10-oracle-74 s10-oracle-75 s10-oracle-76 s10-oracle-77 s10-oracle-78 s10-oracle-79 s10-oracle-80 s10-oracle-81 s10-oracle-82 s10-oracle-83 s10-oracle-84 s10-oracle-85 s10-oracle-86 s10-oracle-87 s10-oracle-88 s10-oracle-89 s10-oracle-90 s10-oracle-91 s10-oracle-92 s10-oracle-93 s10-oracle-94 s10-oracle-95 s10-oracle-96 s10-oracle-97 s10-oracle-98 s10-oracle-99 s10-oracle-100 s10-oracle-101 s10-oracle-102 s10-oracle-103 s10-oracle-104 s10-oracle-105 s10-oracle-106 s10-oracle-107 s10-oracle-108 s10-oracle-109 s10-oracle-110 s10-oracle-111 s10-oracle-112 s10-oracle-113 s10-oracle-114 s10-oracle-115

s10-oracle-0:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cond_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cond_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cond_host

s10-oracle-1:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cc_decode_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cc_decode_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cc_decode_host

s10-oracle-2:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_helper_idents_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_idents_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_idents_host

s10-oracle-3:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_tag_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/cross_isa_tag_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/cross_isa_tag_host

s10-oracle-4:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_differential_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/cross_isa_differential_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/cross_isa_differential_host

s10-oracle-5:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_width_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_host

s10-oracle-6:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_width_effective_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_effective_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_effective_host

s10-oracle-7:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_width_effective_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_effective_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_width_effective_route_host

s10-oracle-8:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flags_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flags_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flags_host

s10-oracle-9:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_result_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_result_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_result_host

s10-oracle-10:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_handler_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_handler_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_handler_host

s10-oracle-11:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_operand_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_host

s10-oracle-12:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flag_operand_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_operand_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_operand_host

s10-oracle-13:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_imm_operand_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_imm_operand_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_imm_operand_host

s10-oracle-14:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_imm_operand_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_imm_operand_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_imm_operand_route_host

s10-oracle-15:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_alu_operand_select_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_select_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_select_host

s10-oracle-16:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_alu_operand_select_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_select_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_alu_operand_select_route_host

s10-oracle-17:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_flag_handler_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_handler_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_handler_host

s10-oracle-18:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_logic_flag_handler_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_logic_flag_handler_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_logic_flag_handler_host

s10-oracle-19:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ccmp_handler_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ccmp_handler_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ccmp_handler_host

s10-oracle-20:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ccmp_decode_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ccmp_decode_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ccmp_decode_host

s10-oracle-21:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dispatch_family_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_family_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_family_host

s10-oracle-22:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_family_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_family_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_family_route_host

s10-oracle-23:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dispatch_singleton_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_singleton_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_singleton_host

s10-oracle-24:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dispatch_singleton_route_host

s10-oracle-25:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mod_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mod_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mod_host

s10-oracle-26:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_bitfield_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_bitfield_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_bitfield_host

s10-oracle-27:
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. oracles/test_arm64_mul_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_host

s10-oracle-28:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mul_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_route_host

s10-oracle-29:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_flag_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_flag_route_host

s10-oracle-30:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_csel_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_route_host

s10-oracle-31:
	$(CC) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mul_wide_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_wide_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mul_wide_host

s10-oracle-32:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_extrev_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_extrev_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_extrev_host

s10-oracle-33:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_csel_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_host

s10-oracle-34:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_csel_ptr_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_ptr_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_csel_ptr_host

s10-oracle-35:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_branch_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_host

s10-oracle-36:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_branch_emit_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_emit_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_emit_host

s10-oracle-37:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_movk_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_movk_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_movk_host

s10-oracle-38:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_shift_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_shift_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_shift_host

s10-oracle-39:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_reduction_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reduction_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reduction_host

s10-oracle-40:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_unary_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_unary_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_unary_host

s10-oracle-41:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_unary_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_unary_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_unary_route_host

s10-oracle-42:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_cneg_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cneg_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cneg_route_host

s10-oracle-43:
	$(CC) -include oracles/arm64_entry_environment_host.h -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stlxr_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stlxr_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stlxr_route_host

s10-oracle-44:
	$(CC) -include oracles/arm64_entry_environment_host.h -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_memory_tokens_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_memory_tokens_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_memory_tokens_host

s10-oracle-45:
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=all -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_return_token_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_return_token_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_return_token_host

s10-oracle-46:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reduction_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reduction_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reduction_route_host

s10-oracle-47:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_adrp_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_adrp_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_adrp_route_host

s10-oracle-48:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_extrev_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_extrev_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_extrev_route_host

s10-oracle-49:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_orn_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_orn_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_orn_route_host

s10-oracle-50:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_branch_emit_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_emit_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_branch_emit_route_host

s10-oracle-51:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_cbz_tbz_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cbz_tbz_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cbz_tbz_route_host

s10-oracle-52:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_call_ret_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_call_ret_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_call_ret_route_host

s10-oracle-53:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_call_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_call_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_call_host

s10-oracle-54:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_entry_context_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_entry_context_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_entry_context_host

s10-oracle-55:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_cneg_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cneg_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_cneg_host

s10-oracle-56:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_orn_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_orn_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_orn_host

s10-oracle-57:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_adrp_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_adrp_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_adrp_host

s10-oracle-58:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stlxr_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stlxr_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stlxr_host

s10-oracle-59:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mov_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mov_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mov_host

s10-oracle-60:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ldrsx_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_host

s10-oracle-61:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_ldrsx_op_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_op_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_op_host

s10-oracle-62:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_ldrsx_op_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_op_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_ldrsx_op_route_host

s10-oracle-63:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_load_tag_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_load_tag_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_load_tag_host

s10-oracle-64:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_pair_load_tag_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_load_tag_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_load_tag_host

s10-oracle-65:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_offset_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_offset_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_offset_host

s10-oracle-66:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_index_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_host

s10-oracle-67:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_index_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_route_host

s10-oracle-68:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_reg_presence_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_presence_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_presence_host

s10-oracle-69:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reg_presence_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_presence_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_presence_route_host

s10-oracle-70:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_reg_dispatch_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_dispatch_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_dispatch_host

s10-oracle-71:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_reg_dispatch_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_dispatch_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_reg_dispatch_route_host

s10-oracle-72:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_fmov_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_fmov_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_fmov_host

s10-oracle-73:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_fmov_dest_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_fmov_dest_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_fmov_dest_host

s10-oracle-74:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_load_bytes_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_load_bytes_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_load_bytes_host

s10-oracle-75:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_store_bytes_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_store_bytes_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_store_bytes_host

s10-oracle-76:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_store_bytes_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_store_bytes_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_store_bytes_route_host

s10-oracle-77:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_byte_lane_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_byte_lane_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_byte_lane_host

s10-oracle-78:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_dispatch_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_dispatch_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_dispatch_host

s10-oracle-79:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_write_arm_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_write_arm_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_write_arm_host

s10-oracle-80:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_write_arm_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_write_arm_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_write_arm_route_host

s10-oracle-81:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_tag_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_tag_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_tag_host

s10-oracle-82:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_arm_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arm_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arm_host

s10-oracle-83:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_arm_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arm_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arm_route_host

s10-oracle-84:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_write_lanes_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_lanes_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_lanes_host

s10-oracle-85:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_write_lanes_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_lanes_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_lanes_route_host

s10-oracle-86:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_write_tag_action_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_tag_action_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_tag_action_host

s10-oracle-87:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_write_tag_action_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_tag_action_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_write_tag_action_route_host

s10-oracle-88:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_read_tag_source_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_read_tag_source_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_read_tag_source_host

s10-oracle-89:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_read_tag_source_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_read_tag_source_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_read_tag_source_route_host

s10-oracle-90:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_helper_arg_ptr_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_arg_ptr_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_arg_ptr_host

s10-oracle-91:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_helper_arg_ptr_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_arg_ptr_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_helper_arg_ptr_route_host

s10-oracle-92:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_base_src_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_base_src_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_base_src_host

s10-oracle-93:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_base_src_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_base_src_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_base_src_route_host

s10-oracle-94:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_index_value_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_value_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_value_host

s10-oracle-95:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_index_value_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_value_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_index_value_route_host

s10-oracle-96:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dq_mem_extra_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_extra_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_extra_host

s10-oracle-97:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_extra_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_extra_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_extra_route_host

s10-oracle-98:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_vreg_field_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_field_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_field_host

s10-oracle-99:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_field_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_field_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_field_route_host

s10-oracle-100:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_write_arm_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_write_arm_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_write_arm_host

s10-oracle-101:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_write_arm_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_write_arm_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_write_arm_route_host

s10-oracle-102:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_dq_mem_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_host

s10-oracle-103:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_dq_mem_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_dq_mem_route_host

s10-oracle-104:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_pair_mem_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_mem_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_mem_host

s10-oracle-105:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_pair_mem_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_mem_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_pair_mem_route_host

s10-oracle-106:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_mem_prepost_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_prepost_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_prepost_host

s10-oracle-107:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_mem_prepost_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_prepost_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_mem_prepost_route_host

s10-oracle-108:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_arm64_vreg_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_host

s10-oracle-109:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_vreg_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_vreg_route_host

s10-oracle-110:
	$(CC) -Wall -Wextra -O2 -I. -I../arm64 oracles/test_arm64_aux_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_aux_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_aux_host

s10-oracle-111:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_aux_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_aux_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_aux_route_host

s10-oracle-112:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_arena_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arena_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arena_host

s10-oracle-113:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. oracles/test_arm64_stack_index_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_index_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_index_host

s10-oracle-114:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_arm64_stack_arena_route_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arena_route_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_stack_arena_route_host

s10-oracle-115:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 oracles/test_arm64_decode_host.c -o /var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_decode_host
	/var/tmp/kprog-tmp/S10/effective-address/hosts/test_arm64_decode_host
