export TMPDIR=/var/tmp/kprog-tmp/S10
ulimit -c 0
cd /workspaces/repository/kprog/formal
taskset -c 8-23 make -k -f /var/tmp/kprog-tmp/S10/effective-address/hosts.mk s10-all > /var/tmp/kprog-tmp/S10/effective-address/hosts.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/effective-address/hosts.exit
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S10/commands/micro.mk s10-micro s10-negative-micro > /var/tmp/kprog-tmp/S10/effective-address/compile.log 2>&1
echo $? > /var/tmp/kprog-tmp/S10/effective-address/compile.exit
