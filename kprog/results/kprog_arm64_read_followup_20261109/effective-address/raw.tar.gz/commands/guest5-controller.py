from pathlib import Path
import os,select,subprocess
S=Path('/var/tmp/kprog-tmp/S10')
try:
 fd=os.pidfd_open(int((S/'guest4-controller.pid').read_text()));select.select([fd],[],[]);os.close(fd)
except ProcessLookupError:pass
with (S/'guest5.log').open('w') as out:
 p=subprocess.run(['taskset','-c','8-23','unshare','--mount','--propagation','private','python3',str(S/'commands/mount-guest5.py')],stdout=out,stderr=subprocess.STDOUT)
(S/'guest5.exit').write_text(str(p.returncode)+chr(10))
