
/var/tmp/kprog-tmp/perf/lpm-c-lto/generation/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section kprobe/lpm_fixture:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 48 83 ec 18                  	subq	$0x18, %rsp
       4: 48 b8 60 00 00 00 5a 5a 5a 5a	movabsq	$0x5a5a5a5a00000060, %rax # imm = 0x5A5A5A5A00000060
       e: 48 8d 88 fa 59 5a 5a         	leaq	0x5a5a59fa(%rax), %rcx
      15: 48 89 4c 24 08               	movq	%rcx, 0x8(%rsp)
      1a: 48 89 04 24                  	movq	%rax, (%rsp)
      1e: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x25 <trusted_x86_x86_sim_xdp+0x25>
      25: 48 8b 80 20 01 00 00         	movq	0x120(%rax), %rax
      2c: 48 85 c0                     	testq	%rax, %rax
      2f: 0f 84 ae 00 00 00            	je	0xe3 <trusted_x86_x86_sim_xdp+0xe3>
      35: 48 8b 54 24 04               	movq	0x4(%rsp), %rdx
      3a: 31 c9                        	xorl	%ecx, %ecx
      3c: be 5a 5a 5a 5a               	movl	$0x5a5a5a5a, %esi       # imm = 0x5A5A5A5A
      41: eb 4d                        	jmp	0x90 <trusted_x86_x86_sim_xdp+0x90>
      43: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)
      50: 49 0f c8                     	bswapq	%r8
      53: 41 89 f9                     	movl	%edi, %r9d
      56: 41 f6 d9                     	negb	%r9b
      59: c4 42 b3 f7 c0               	shrxq	%r9, %r8, %r8
      5e: 4d 85 c0                     	testq	%r8, %r8
      61: 75 6d                        	jne	0xd0 <trusted_x86_x86_sim_xdp+0xd0>
      63: f6 40 14 01                  	testb	$0x1, 0x14(%rax)
      67: 48 0f 44 c8                  	cmoveq	%rax, %rcx
      6b: 41 89 f8                     	movl	%edi, %r8d
      6e: 41 c1 e8 03                  	shrl	$0x3, %r8d
      72: 46 0f b6 44 04 04            	movzbl	0x4(%rsp,%r8), %r8d
      78: 40 f6 d7                     	notb	%dil
      7b: 40 80 e7 07                  	andb	$0x7, %dil
      7f: c4 c2 43 f7 f8               	shrxl	%edi, %r8d, %edi
      84: 83 e7 01                     	andl	$0x1, %edi
      87: 48 8b 04 f8                  	movq	(%rax,%rdi,8), %rax
      8b: 48 85 c0                     	testq	%rax, %rax
      8e: 74 40                        	je	0xd0 <trusted_x86_x86_sim_xdp+0xd0>
      90: 8b 78 10                     	movl	0x10(%rax), %edi
      93: 48 83 ff 60                  	cmpq	$0x60, %rdi
      97: 77 37                        	ja	0xd0 <trusted_x86_x86_sim_xdp+0xd0>
      99: 48 85 ff                     	testq	%rdi, %rdi
      9c: 74 c5                        	je	0x63 <trusted_x86_x86_sim_xdp+0x63>
      9e: 4c 8b 40 18                  	movq	0x18(%rax), %r8
      a2: 49 31 d0                     	xorq	%rdx, %r8
      a5: 83 ff 40                     	cmpl	$0x40, %edi
      a8: 76 a6                        	jbe	0x50 <trusted_x86_x86_sim_xdp+0x50>
      aa: 4d 85 c0                     	testq	%r8, %r8
      ad: 75 21                        	jne	0xd0 <trusted_x86_x86_sim_xdp+0xd0>
      af: 44 8b 40 20                  	movl	0x20(%rax), %r8d
      b3: 41 31 f0                     	xorl	%esi, %r8d
      b6: 41 0f c8                     	bswapl	%r8d
      b9: 41 89 f9                     	movl	%edi, %r9d
      bc: 41 f6 d9                     	negb	%r9b
      bf: c4 42 33 f7 c0               	shrxl	%r9d, %r8d, %r8d
      c4: 45 85 c0                     	testl	%r8d, %r8d
      c7: 75 07                        	jne	0xd0 <trusted_x86_x86_sim_xdp+0xd0>
      c9: 83 ff 60                     	cmpl	$0x60, %edi
      cc: 75 95                        	jne	0x63 <trusted_x86_x86_sim_xdp+0x63>
      ce: eb 08                        	jmp	0xd8 <trusted_x86_x86_sim_xdp+0xd8>
      d0: 48 89 c8                     	movq	%rcx, %rax
      d3: 48 85 c9                     	testq	%rcx, %rcx
      d6: 74 0b                        	je	0xe3 <trusted_x86_x86_sim_xdp+0xe3>
      d8: 48 83 c0 24                  	addq	$0x24, %rax
      dc: 8b 00                        	movl	(%rax), %eax
      de: 48 83 c4 18                  	addq	$0x18, %rsp
      e2: c3                           	retq
      e3: 31 c0                        	xorl	%eax, %eax
      e5: 48 83 c4 18                  	addq	$0x18, %rsp
      e9: c3                           	retq
