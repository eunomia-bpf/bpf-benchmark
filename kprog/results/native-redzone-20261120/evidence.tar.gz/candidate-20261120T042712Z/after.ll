; ModuleID = '/var/tmp/kprog-tmp/perf/lpm-c-lto/generation/checked-simulator.linked.bc'
source_filename = "llvm-link"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%union.x86_sim_stack_mem = type { [3 x i64] }

@LICENSE = global [4 x i8] c"GPL\00", section "license", align 1, !dbg !0
@map_a = external global [0 x i8], section ".ksyms", align 1, !dbg !272
@map_b = external global [0 x i8], align 1
@llvm.compiler.used = appending global [2 x ptr] [ptr @LICENSE, ptr @trusted_x86_x86_sim_xdp], section "llvm.metadata"

; Function Attrs: noredzone nounwind
define i32 @trusted_x86_x86_sim_xdp(ptr nocapture readnone %0) #0 section "kprobe/lpm_fixture" !dbg !286 {
  %2 = alloca %union.x86_sim_stack_mem, align 8, !DIAssignID !451
  call void @llvm.dbg.assign(metadata i1 undef, metadata !383, metadata !DIExpression(), metadata !451, metadata ptr %2, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.assign(metadata i1 undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 128), metadata !453, metadata ptr undef, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.assign(metadata i1 undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1360, 48), metadata !454, metadata ptr undef, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !290, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.assign(metadata i8 0, metadata !291, metadata !DIExpression(), metadata !455, metadata ptr undef, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !310, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i8 2, metadata !311, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !366, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !367, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !368, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !369, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !370, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !371, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !372, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 384, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 448, 8)), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1344, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1408, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1472, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1536, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1600, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1664, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1728, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1792, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1856, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1920, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1984, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 0, metadata !373, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !374, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !375, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !376, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !377, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !378, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !379, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !380, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !381, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i64 0, metadata !382, metadata !DIExpression()), !dbg !452
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %2) #4, !dbg !456
  call void @llvm.dbg.value(metadata i64 poison, metadata !373, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !371, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !372, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 1, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 8)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr %2, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 640, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 704, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr undef, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr poison, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 64)), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1344, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i8 2, metadata !398, metadata !DIExpression(DW_OP_LLVM_fragment, 1352, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !429), !dbg !457
  call void @llvm.dbg.value(metadata i64 poison, metadata !374, metadata !DIExpression(DW_OP_constu, 24, DW_OP_lt, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !375, metadata !DIExpression(DW_OP_constu, 24, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !376, metadata !DIExpression(DW_OP_constu, 24, DW_OP_minus, DW_OP_constu, 63, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison, i64 poison), metadata !377, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_minus, DW_OP_LLVM_arg, 1, DW_OP_and, DW_OP_constu, 63, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison, i64 poison), metadata !378, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_minus, DW_OP_constu, 4, DW_OP_shr, DW_OP_LLVM_arg, 2, DW_OP_constu, 24, DW_OP_minus, DW_OP_xor, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_constu, 15, DW_OP_and, DW_OP_shr, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !379, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 24, DW_OP_minus, DW_OP_LLVM_arg, 1, DW_OP_xor, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 18446744073709551615, DW_OP_xor, DW_OP_constu, 4, DW_OP_shr, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata ptr inttoptr (i64 -24 to ptr), metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !430), !dbg !458
  call void @llvm.dbg.value(metadata ptr inttoptr (i64 6510615555426900570 to ptr), metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !431), !dbg !459
  call void @llvm.dbg.value(metadata i8 0, metadata !368, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !369, metadata !DIExpression()), !dbg !452
  %3 = getelementptr inbounds [3 x i64], ptr %2, i64 0, i64 1, !dbg !460
  store i64 6510615555426900570, ptr %3, align 8, !dbg !460, !tbaa !461
  call void @llvm.dbg.label(metadata !432), !dbg !464
  call void @llvm.dbg.value(metadata ptr inttoptr (i64 6510615553911029856 to ptr), metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !433), !dbg !465
  call void @llvm.dbg.value(metadata i8 0, metadata !366, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !367, metadata !DIExpression()), !dbg !452
  store i64 6510615553911029856, ptr %2, align 8, !dbg !466, !tbaa !461
  call void @llvm.dbg.label(metadata !434), !dbg !467
  call void @llvm.dbg.value(metadata ptr @map_a, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 5, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !435), !dbg !468
  call void @llvm.dbg.value(metadata ptr %2, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 4, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !436), !dbg !469
  %4 = getelementptr inbounds i8, ptr %2, i64 4, !dbg !470
  %5 = load volatile ptr, ptr getelementptr inbounds ([0 x i8], ptr @map_a, i64 0, i64 288), align 8, !dbg !470, !tbaa !471
  %6 = icmp eq ptr %5, null, !dbg !470
  br i1 %6, label %__kprog_array_lookup.exit.thread, label %7, !dbg !470

7:                                                ; preds = %1
  %8 = load i64, ptr %4, align 4
  br label %9, !dbg !470

9:                                                ; preds = %40, %7
  %10 = phi ptr [ %5, %7 ], [ %58, %40 ], !dbg !470
  %11 = phi ptr [ null, %7 ], [ %45, %40 ], !dbg !470
  %12 = getelementptr inbounds i8, ptr %10, i64 16, !dbg !470
  %13 = load i32, ptr %12, align 1, !dbg !470, !tbaa !461
  %14 = icmp ugt i32 %13, 96, !dbg !470
  br i1 %14, label %60, label %15, !dbg !470

15:                                               ; preds = %9
  %16 = icmp eq i32 %13, 0, !dbg !470
  br i1 %16, label %40, label %17, !dbg !470

17:                                               ; preds = %15
  %18 = getelementptr inbounds i8, ptr %10, i64 24, !dbg !470
  %19 = load i64, ptr %18, align 1, !dbg !470, !tbaa !461
  %20 = xor i64 %8, %19, !dbg !470
  %21 = icmp ult i32 %13, 65, !dbg !470
  br i1 %21, label %22, label %28, !dbg !470

22:                                               ; preds = %17
  %23 = tail call i64 @llvm.bswap.i64(i64 %20), !dbg !470
  %24 = sub nuw nsw i32 64, %13, !dbg !470
  %25 = zext nneg i32 %24 to i64, !dbg !470
  %26 = lshr i64 %23, %25, !dbg !470
  %27 = icmp eq i64 %26, 0, !dbg !470
  br i1 %27, label %40, label %60, !dbg !470

28:                                               ; preds = %17
  %29 = icmp eq i64 %20, 0, !dbg !470
  br i1 %29, label %30, label %60, !dbg !470

30:                                               ; preds = %28
  %31 = getelementptr inbounds i8, ptr %10, i64 32, !dbg !470
  %32 = load i32, ptr %31, align 1, !dbg !470, !tbaa !461
  %33 = xor i32 %32, 1515870810, !dbg !470
  %34 = tail call i32 @llvm.bswap.i32(i32 %33), !dbg !470
  %35 = sub nuw nsw i32 96, %13, !dbg !470
  %36 = lshr i32 %34, %35, !dbg !470
  %37 = icmp eq i32 %36, 0, !dbg !470
  br i1 %37, label %38, label %60, !dbg !470

38:                                               ; preds = %30
  %39 = icmp eq i32 %13, 96, !dbg !470
  br i1 %39, label %__kprog_array_lookup.exit, label %40, !dbg !470

40:                                               ; preds = %38, %22, %15
  %41 = getelementptr inbounds i8, ptr %10, i64 20, !dbg !470
  %42 = load i32, ptr %41, align 1, !dbg !470, !tbaa !461
  %43 = and i32 %42, 1, !dbg !470
  %44 = icmp eq i32 %43, 0, !dbg !470
  %45 = select i1 %44, ptr %10, ptr %11, !dbg !470
  %46 = lshr i32 %13, 3, !dbg !470
  %47 = zext nneg i32 %46 to i64, !dbg !470
  %48 = getelementptr i8, ptr %4, i64 %47, !dbg !470
  %49 = load i8, ptr %48, align 1, !dbg !470, !tbaa !461
  %50 = zext i8 %49 to i32, !dbg !470
  %51 = and i32 %13, 7, !dbg !470
  %52 = xor i32 %51, 7, !dbg !470
  %53 = lshr i32 %50, %52, !dbg !470
  %54 = shl nuw nsw i32 %53, 3, !dbg !470
  %55 = and i32 %54, 8, !dbg !470
  %56 = zext nneg i32 %55 to i64, !dbg !470
  %57 = getelementptr inbounds i8, ptr %10, i64 %56, !dbg !470
  %58 = load volatile ptr, ptr %57, align 8, !dbg !470, !tbaa !471
  %59 = icmp eq ptr %58, null, !dbg !470
  br i1 %59, label %60, label %9, !dbg !470

60:                                               ; preds = %40, %30, %28, %22, %9
  %61 = phi ptr [ %11, %22 ], [ %45, %40 ], [ %11, %30 ], [ %11, %9 ], [ %11, %28 ], !dbg !470
  %62 = icmp eq ptr %61, null, !dbg !470
  br i1 %62, label %__kprog_array_lookup.exit.thread, label %__kprog_array_lookup.exit, !dbg !470

__kprog_array_lookup.exit:                        ; preds = %38, %60
  %.pn = phi ptr [ %61, %60 ], [ %10, %38 ]
  %63 = getelementptr inbounds i8, ptr %.pn, i64 36, !dbg !470
  call void @llvm.dbg.value(metadata ptr %63, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 6, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 256, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 320, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 768, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 832, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 896, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 960, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1024, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1088, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1152, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1216, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1280, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1344, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1408, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 1472, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !374, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !375, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !376, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !377, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !378, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !379, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !380, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !381, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.label(metadata !437), !dbg !473
  call void @llvm.dbg.value(metadata i8 0, metadata !374, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i1 false, metadata !375, metadata !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata ptr %63, metadata !376, metadata !DIExpression(DW_OP_constu, 63, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !377, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i16 -27031, ptr %63, ptr %63), metadata !378, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 4, DW_OP_shr, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_constu, 15, DW_OP_and, DW_OP_shr, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.label(metadata !438), !dbg !474
  tail call void asm sideeffect "", "~{memory}"() #4, !dbg !475, !srcloc !476
  call void @llvm.dbg.label(metadata !444), !dbg !477
  call void @llvm.dbg.value(metadata ptr %63, metadata !478, metadata !DIExpression()), !dbg !487
  call void @llvm.dbg.value(metadata i64 0, metadata !484, metadata !DIExpression()), !dbg !487
  call void @llvm.dbg.value(metadata i8 4, metadata !485, metadata !DIExpression()), !dbg !487
  %64 = ptrtoint ptr %63 to i64, !dbg !489
  %65 = tail call i64 asm sideeffect "", "=r,0"(i64 %64) #4, !dbg !489
  %66 = inttoptr i64 %65 to ptr, !dbg !489
  %67 = load volatile i32, ptr %66, align 1, !dbg !489
  call void @llvm.dbg.value(metadata i32 %67, metadata !486, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !487
  call void @llvm.dbg.value(metadata i32 %67, metadata !312, metadata !DIExpression(DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_stack_value, DW_OP_LLVM_fragment, 0, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 8)), !dbg !452
  call void @llvm.dbg.label(metadata !445), !dbg !492
  call void @llvm.dbg.value(metadata i64 poison, metadata !374, metadata !DIExpression(DW_OP_constu, 24, DW_OP_minus, DW_OP_constu, 18446744073709551591, DW_OP_gt, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !375, metadata !DIExpression(DW_OP_constu, 0, DW_OP_eq, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata i64 poison, metadata !376, metadata !DIExpression(DW_OP_constu, 63, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !377, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_minus, DW_OP_constu, 18446744073709551615, DW_OP_xor, DW_OP_and, DW_OP_constu, 63, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i16 poison, i64 poison, i64 poison), metadata !378, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 4, DW_OP_shr, DW_OP_LLVM_arg, 2, DW_OP_xor, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_constu, 15, DW_OP_and, DW_OP_shr, DW_OP_LLVM_convert, 16, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 1, DW_OP_and, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata !DIArgList(i64 poison, i64 poison), metadata !379, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 24, DW_OP_minus, DW_OP_xor, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_constu, 4, DW_OP_shr, DW_OP_constu, 1, DW_OP_and, DW_OP_constu, 1, DW_OP_xor, DW_OP_stack_value)), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 512, 64)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !312, metadata !DIExpression(DW_OP_LLVM_fragment, 576, 8)), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !366, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !367, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata i8 0, metadata !368, metadata !DIExpression()), !dbg !452
  call void @llvm.dbg.value(metadata ptr null, metadata !369, metadata !DIExpression()), !dbg !452
  br label %__kprog_array_lookup.exit.thread, !dbg !493

__kprog_array_lookup.exit.thread:                 ; preds = %1, %60, %__kprog_array_lookup.exit
  %68 = phi i32 [ %67, %__kprog_array_lookup.exit ], [ 0, %60 ], [ 0, %1 ]
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %2) #4, !dbg !494
  ret i32 %68, !dbg !494
}

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #1

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #1

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: alwaysinline nofree norecurse noredzone nounwind uwtable
define dso_local ptr @__kprog_array_lookup(ptr noundef readonly %0, ptr nocapture noundef readonly %1) local_unnamed_addr #3 {
  %3 = icmp eq ptr %0, @map_a
  br i1 %3, label %4, label %70

4:                                                ; preds = %2
  %5 = load i32, ptr %1, align 1, !tbaa !461
  %6 = icmp ugt i32 %5, 96
  br i1 %6, label %154, label %7

7:                                                ; preds = %4
  %8 = getelementptr i8, ptr %1, i64 4
  %9 = load volatile ptr, ptr getelementptr inbounds ([0 x i8], ptr @map_a, i64 0, i64 288), align 8, !tbaa !471
  %10 = icmp eq ptr %9, null
  br i1 %10, label %.loopexit, label %11

11:                                               ; preds = %7
  %12 = getelementptr i8, ptr %1, i64 12
  br label %13

13:                                               ; preds = %11, %46
  %14 = phi ptr [ %9, %11 ], [ %64, %46 ]
  %15 = phi ptr [ null, %11 ], [ %51, %46 ]
  %16 = getelementptr inbounds i8, ptr %14, i64 16
  %17 = load i32, ptr %16, align 1, !tbaa !461
  %18 = icmp ugt i32 %17, %5
  br i1 %18, label %.loopexit, label %19

19:                                               ; preds = %13
  %20 = icmp eq i32 %17, 0
  br i1 %20, label %46, label %21

21:                                               ; preds = %19
  %22 = getelementptr inbounds i8, ptr %14, i64 24
  %23 = load i64, ptr %22, align 1, !tbaa !461
  %24 = load i64, ptr %8, align 1, !tbaa !461
  %25 = xor i64 %24, %23
  %26 = icmp ult i32 %17, 65
  br i1 %26, label %27, label %33

27:                                               ; preds = %21
  %28 = tail call i64 @llvm.bswap.i64(i64 %25)
  %29 = sub nuw nsw i32 64, %17
  %30 = zext nneg i32 %29 to i64
  %31 = lshr i64 %28, %30
  %32 = icmp eq i64 %31, 0
  br i1 %32, label %46, label %.loopexit

33:                                               ; preds = %21
  %34 = icmp eq i64 %25, 0
  br i1 %34, label %35, label %.loopexit

35:                                               ; preds = %33
  %36 = load i32, ptr %12, align 1, !tbaa !461
  %37 = getelementptr inbounds i8, ptr %14, i64 32
  %38 = load i32, ptr %37, align 1, !tbaa !461
  %39 = xor i32 %38, %36
  %40 = tail call i32 @llvm.bswap.i32(i32 %39)
  %41 = sub nuw nsw i32 96, %17
  %42 = lshr i32 %40, %41
  %43 = icmp eq i32 %42, 0
  br i1 %43, label %44, label %.loopexit

44:                                               ; preds = %35
  %45 = icmp eq i32 %17, 96
  br i1 %45, label %.loopexit, label %46

46:                                               ; preds = %27, %19, %44
  %47 = getelementptr inbounds i8, ptr %14, i64 20
  %48 = load i32, ptr %47, align 1, !tbaa !461
  %49 = and i32 %48, 1
  %50 = icmp eq i32 %49, 0
  %51 = select i1 %50, ptr %14, ptr %15
  %52 = lshr i32 %17, 3
  %53 = zext nneg i32 %52 to i64
  %54 = getelementptr i8, ptr %8, i64 %53
  %55 = load i8, ptr %54, align 1, !tbaa !461
  %56 = zext i8 %55 to i32
  %57 = and i32 %17, 7
  %58 = xor i32 %57, 7
  %59 = lshr i32 %56, %58
  %60 = shl nuw nsw i32 %59, 3
  %61 = and i32 %60, 8
  %62 = zext nneg i32 %61 to i64
  %63 = getelementptr inbounds i8, ptr %14, i64 %62
  %64 = load volatile ptr, ptr %63, align 8, !tbaa !471
  %65 = icmp eq ptr %64, null
  br i1 %65, label %.loopexit, label %13

.loopexit:                                        ; preds = %46, %35, %13, %44, %33, %27, %7
  %66 = phi ptr [ null, %7 ], [ %15, %33 ], [ %14, %44 ], [ %15, %13 ], [ %15, %35 ], [ %51, %46 ], [ %15, %27 ]
  %67 = icmp eq ptr %66, null
  %68 = getelementptr inbounds i8, ptr %66, i64 36
  %69 = select i1 %67, ptr null, ptr %68
  br label %154

70:                                               ; preds = %2
  %71 = icmp eq ptr %0, @map_b
  br i1 %71, label %72, label %138

72:                                               ; preds = %70
  %73 = load i32, ptr %1, align 1, !tbaa !461
  %74 = icmp ugt i32 %73, 96
  br i1 %74, label %154, label %75

75:                                               ; preds = %72
  %76 = getelementptr i8, ptr %1, i64 4
  %77 = load volatile ptr, ptr getelementptr inbounds ([0 x i8], ptr @map_b, i64 0, i64 288), align 8, !tbaa !471
  %78 = icmp eq ptr %77, null
  br i1 %78, label %.loopexit10, label %79

79:                                               ; preds = %75
  %80 = getelementptr i8, ptr %1, i64 12
  br label %81

81:                                               ; preds = %79, %114
  %82 = phi ptr [ %77, %79 ], [ %132, %114 ]
  %83 = phi ptr [ null, %79 ], [ %119, %114 ]
  %84 = getelementptr inbounds i8, ptr %82, i64 16
  %85 = load i32, ptr %84, align 1, !tbaa !461
  %86 = icmp ugt i32 %85, %73
  br i1 %86, label %.loopexit10, label %87

87:                                               ; preds = %81
  %88 = icmp eq i32 %85, 0
  br i1 %88, label %114, label %89

89:                                               ; preds = %87
  %90 = getelementptr inbounds i8, ptr %82, i64 24
  %91 = load i64, ptr %90, align 1, !tbaa !461
  %92 = load i64, ptr %76, align 1, !tbaa !461
  %93 = xor i64 %92, %91
  %94 = icmp ult i32 %85, 65
  br i1 %94, label %95, label %101

95:                                               ; preds = %89
  %96 = tail call i64 @llvm.bswap.i64(i64 %93)
  %97 = sub nuw nsw i32 64, %85
  %98 = zext nneg i32 %97 to i64
  %99 = lshr i64 %96, %98
  %100 = icmp eq i64 %99, 0
  br i1 %100, label %114, label %.loopexit10

101:                                              ; preds = %89
  %102 = icmp eq i64 %93, 0
  br i1 %102, label %103, label %.loopexit10

103:                                              ; preds = %101
  %104 = load i32, ptr %80, align 1, !tbaa !461
  %105 = getelementptr inbounds i8, ptr %82, i64 32
  %106 = load i32, ptr %105, align 1, !tbaa !461
  %107 = xor i32 %106, %104
  %108 = tail call i32 @llvm.bswap.i32(i32 %107)
  %109 = sub nuw nsw i32 96, %85
  %110 = lshr i32 %108, %109
  %111 = icmp eq i32 %110, 0
  br i1 %111, label %112, label %.loopexit10

112:                                              ; preds = %103
  %113 = icmp eq i32 %85, 96
  br i1 %113, label %.loopexit10, label %114

114:                                              ; preds = %95, %87, %112
  %115 = getelementptr inbounds i8, ptr %82, i64 20
  %116 = load i32, ptr %115, align 1, !tbaa !461
  %117 = and i32 %116, 1
  %118 = icmp eq i32 %117, 0
  %119 = select i1 %118, ptr %82, ptr %83
  %120 = lshr i32 %85, 3
  %121 = zext nneg i32 %120 to i64
  %122 = getelementptr i8, ptr %76, i64 %121
  %123 = load i8, ptr %122, align 1, !tbaa !461
  %124 = zext i8 %123 to i32
  %125 = and i32 %85, 7
  %126 = xor i32 %125, 7
  %127 = lshr i32 %124, %126
  %128 = shl nuw nsw i32 %127, 3
  %129 = and i32 %128, 8
  %130 = zext nneg i32 %129 to i64
  %131 = getelementptr inbounds i8, ptr %82, i64 %130
  %132 = load volatile ptr, ptr %131, align 8, !tbaa !471
  %133 = icmp eq ptr %132, null
  br i1 %133, label %.loopexit10, label %81

.loopexit10:                                      ; preds = %114, %103, %81, %112, %101, %95, %75
  %134 = phi ptr [ null, %75 ], [ %83, %101 ], [ %82, %112 ], [ %83, %81 ], [ %83, %103 ], [ %119, %114 ], [ %83, %95 ]
  %135 = icmp eq ptr %134, null
  %136 = getelementptr inbounds i8, ptr %134, i64 36
  %137 = select i1 %135, ptr null, ptr %136
  br label %154

138:                                              ; preds = %70
  %139 = load i32, ptr %1, align 4, !tbaa !495
  %140 = getelementptr inbounds i8, ptr %0, i64 68
  %141 = load i32, ptr %140, align 4, !tbaa !495
  %142 = icmp ult i32 %139, %141
  br i1 %142, label %143, label %154

143:                                              ; preds = %138
  %144 = getelementptr inbounds i8, ptr %0, i64 288
  %145 = load i32, ptr %144, align 4, !tbaa !495
  %146 = getelementptr inbounds i8, ptr %0, i64 292
  %147 = load i32, ptr %146, align 4, !tbaa !495
  %148 = getelementptr inbounds i8, ptr %0, i64 304
  %149 = zext i32 %145 to i64
  %150 = and i32 %147, %139
  %151 = zext i32 %150 to i64
  %152 = mul nuw i64 %151, %149
  %153 = getelementptr inbounds i8, ptr %148, i64 %152
  br label %154

154:                                              ; preds = %.loopexit10, %72, %.loopexit, %4, %143, %138
  %155 = phi ptr [ %153, %143 ], [ null, %138 ], [ %69, %.loopexit ], [ null, %4 ], [ %137, %.loopexit10 ], [ null, %72 ]
  ret ptr %155
}

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

attributes #0 = { noredzone nounwind "frame-pointer"="none" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #1 = { mustprogress nocallback nofree noredzone nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree noredzone nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { alwaysinline nofree norecurse noredzone nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,-3dnow,-3dnowa,-aes,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-f16c,-fma,-fma4,-gfni,-kl,-mmx,-pclmul,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-vaes,-vpclmulqdq,-widekl,-x87,-xop" "tune-cpu"="generic" }
attributes #4 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.ident = !{!277, !277}
!llvm.module.flags = !{!278, !279, !280, !281, !282, !283, !284, !285}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "LICENSE", scope: !2, file: !274, line: 77, type: !276, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !265, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/var/tmp/kprog-tmp/perf/lpm-c-lto/generation/trusted_x86.bpf.piece0.c", directory: "/workspaces/repository")
!4 = !{!5, !114, !115, !116, !84, !10, !118, !57, !119, !120, !109, !122, !124, !126, !129, !151, !152, !153, !110, !162, !165, !218, !92, !239, !240, !249, !250, !252, !253, !255, !257, !259, !261, !263, !52}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "__sk_buff", file: !7, line: 6347, size: 1536, elements: !8)
!7 = !DIFile(filename: "vendor/libbpf/include/uapi/linux/bpf.h", directory: "/workspaces/repository")
!8 = !{!9, !13, !14, !15, !16, !17, !18, !19, !20, !21, !22, !23, !24, !28, !29, !30, !31, !32, !33, !34, !35, !36, !40, !41, !42, !43, !44, !83, !86, !87, !88, !111, !112, !113}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "len", scope: !6, file: !7, line: 6348, baseType: !10, size: 32)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u32", file: !11, line: 27, baseType: !12)
!11 = !DIFile(filename: "/usr/include/asm-generic/int-ll64.h", directory: "")
!12 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "pkt_type", scope: !6, file: !7, line: 6349, baseType: !10, size: 32, offset: 32)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !6, file: !7, line: 6350, baseType: !10, size: 32, offset: 64)
!15 = !DIDerivedType(tag: DW_TAG_member, name: "queue_mapping", scope: !6, file: !7, line: 6351, baseType: !10, size: 32, offset: 96)
!16 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !6, file: !7, line: 6352, baseType: !10, size: 32, offset: 128)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_present", scope: !6, file: !7, line: 6353, baseType: !10, size: 32, offset: 160)
!18 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_tci", scope: !6, file: !7, line: 6354, baseType: !10, size: 32, offset: 192)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "vlan_proto", scope: !6, file: !7, line: 6355, baseType: !10, size: 32, offset: 224)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !6, file: !7, line: 6356, baseType: !10, size: 32, offset: 256)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !6, file: !7, line: 6357, baseType: !10, size: 32, offset: 288)
!22 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !6, file: !7, line: 6358, baseType: !10, size: 32, offset: 320)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "tc_index", scope: !6, file: !7, line: 6359, baseType: !10, size: 32, offset: 352)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !6, file: !7, line: 6360, baseType: !25, size: 160, offset: 384)
!25 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 160, elements: !26)
!26 = !{!27}
!27 = !DISubrange(count: 5)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "hash", scope: !6, file: !7, line: 6361, baseType: !10, size: 32, offset: 544)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "tc_classid", scope: !6, file: !7, line: 6362, baseType: !10, size: 32, offset: 576)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !6, file: !7, line: 6363, baseType: !10, size: 32, offset: 608)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !6, file: !7, line: 6364, baseType: !10, size: 32, offset: 640)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "napi_id", scope: !6, file: !7, line: 6365, baseType: !10, size: 32, offset: 672)
!33 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !6, file: !7, line: 6368, baseType: !10, size: 32, offset: 704)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip4", scope: !6, file: !7, line: 6369, baseType: !10, size: 32, offset: 736)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip4", scope: !6, file: !7, line: 6370, baseType: !10, size: 32, offset: 768)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ip6", scope: !6, file: !7, line: 6371, baseType: !37, size: 128, offset: 800)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 128, elements: !38)
!38 = !{!39}
!39 = !DISubrange(count: 4)
!40 = !DIDerivedType(tag: DW_TAG_member, name: "local_ip6", scope: !6, file: !7, line: 6372, baseType: !37, size: 128, offset: 928)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "remote_port", scope: !6, file: !7, line: 6373, baseType: !10, size: 32, offset: 1056)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "local_port", scope: !6, file: !7, line: 6374, baseType: !10, size: 32, offset: 1088)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !6, file: !7, line: 6377, baseType: !10, size: 32, offset: 1120)
!44 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6378, baseType: !45, size: 64, align: 64, offset: 1152)
!45 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6378, size: 64, align: 64, elements: !46)
!46 = !{!47}
!47 = !DIDerivedType(tag: DW_TAG_member, name: "flow_keys", scope: !45, file: !7, line: 6378, baseType: !48, size: 64)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64)
!49 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_flow_keys", file: !7, line: 7436, size: 448, elements: !50)
!50 = !{!51, !54, !55, !56, !59, !60, !61, !62, !65, !66, !67, !81, !82}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "nhoff", scope: !49, file: !7, line: 7437, baseType: !52, size: 16)
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u16", file: !11, line: 24, baseType: !53)
!53 = !DIBasicType(name: "unsigned short", size: 16, encoding: DW_ATE_unsigned)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "thoff", scope: !49, file: !7, line: 7438, baseType: !52, size: 16, offset: 16)
!55 = !DIDerivedType(tag: DW_TAG_member, name: "addr_proto", scope: !49, file: !7, line: 7439, baseType: !52, size: 16, offset: 32)
!56 = !DIDerivedType(tag: DW_TAG_member, name: "is_frag", scope: !49, file: !7, line: 7440, baseType: !57, size: 8, offset: 48)
!57 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u8", file: !11, line: 21, baseType: !58)
!58 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "is_first_frag", scope: !49, file: !7, line: 7441, baseType: !57, size: 8, offset: 56)
!60 = !DIDerivedType(tag: DW_TAG_member, name: "is_encap", scope: !49, file: !7, line: 7442, baseType: !57, size: 8, offset: 64)
!61 = !DIDerivedType(tag: DW_TAG_member, name: "ip_proto", scope: !49, file: !7, line: 7443, baseType: !57, size: 8, offset: 72)
!62 = !DIDerivedType(tag: DW_TAG_member, name: "n_proto", scope: !49, file: !7, line: 7444, baseType: !63, size: 16, offset: 80)
!63 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be16", file: !64, line: 32, baseType: !52)
!64 = !DIFile(filename: "/usr/include/linux/types.h", directory: "")
!65 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !49, file: !7, line: 7445, baseType: !63, size: 16, offset: 96)
!66 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !49, file: !7, line: 7446, baseType: !63, size: 16, offset: 112)
!67 = !DIDerivedType(tag: DW_TAG_member, scope: !49, file: !7, line: 7447, baseType: !68, size: 256, offset: 128)
!68 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !49, file: !7, line: 7447, size: 256, elements: !69)
!69 = !{!70, !76}
!70 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7448, baseType: !71, size: 64)
!71 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7448, size: 64, elements: !72)
!72 = !{!73, !75}
!73 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !71, file: !7, line: 7449, baseType: !74, size: 32)
!74 = !DIDerivedType(tag: DW_TAG_typedef, name: "__be32", file: !64, line: 34, baseType: !10)
!75 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !71, file: !7, line: 7450, baseType: !74, size: 32, offset: 32)
!76 = !DIDerivedType(tag: DW_TAG_member, scope: !68, file: !7, line: 7452, baseType: !77, size: 256)
!77 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !68, file: !7, line: 7452, size: 256, elements: !78)
!78 = !{!79, !80}
!79 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !77, file: !7, line: 7453, baseType: !37, size: 128)
!80 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !77, file: !7, line: 7454, baseType: !37, size: 128, offset: 128)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !49, file: !7, line: 7457, baseType: !10, size: 32, offset: 384)
!82 = !DIDerivedType(tag: DW_TAG_member, name: "flow_label", scope: !49, file: !7, line: 7458, baseType: !74, size: 32, offset: 416)
!83 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp", scope: !6, file: !7, line: 6379, baseType: !84, size: 64, offset: 1216)
!84 = !DIDerivedType(tag: DW_TAG_typedef, name: "__u64", file: !11, line: 31, baseType: !85)
!85 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!86 = !DIDerivedType(tag: DW_TAG_member, name: "wire_len", scope: !6, file: !7, line: 6380, baseType: !10, size: 32, offset: 1280)
!87 = !DIDerivedType(tag: DW_TAG_member, name: "gso_segs", scope: !6, file: !7, line: 6381, baseType: !10, size: 32, offset: 1312)
!88 = !DIDerivedType(tag: DW_TAG_member, scope: !6, file: !7, line: 6382, baseType: !89, size: 64, align: 64, offset: 1344)
!89 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !6, file: !7, line: 6382, size: 64, align: 64, elements: !90)
!90 = !{!91}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "sk", scope: !89, file: !7, line: 6382, baseType: !92, size: 64)
!92 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !93, size: 64)
!93 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock", file: !7, line: 6451, size: 640, elements: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108}
!95 = !DIDerivedType(tag: DW_TAG_member, name: "bound_dev_if", scope: !93, file: !7, line: 6452, baseType: !10, size: 32)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !93, file: !7, line: 6453, baseType: !10, size: 32, offset: 32)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "type", scope: !93, file: !7, line: 6454, baseType: !10, size: 32, offset: 64)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "protocol", scope: !93, file: !7, line: 6455, baseType: !10, size: 32, offset: 96)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !93, file: !7, line: 6456, baseType: !10, size: 32, offset: 128)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "priority", scope: !93, file: !7, line: 6457, baseType: !10, size: 32, offset: 160)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip4", scope: !93, file: !7, line: 6459, baseType: !10, size: 32, offset: 192)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "src_ip6", scope: !93, file: !7, line: 6460, baseType: !37, size: 128, offset: 224)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "src_port", scope: !93, file: !7, line: 6461, baseType: !10, size: 32, offset: 352)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "dst_port", scope: !93, file: !7, line: 6462, baseType: !63, size: 16, offset: 384)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip4", scope: !93, file: !7, line: 6464, baseType: !10, size: 32, offset: 416)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "dst_ip6", scope: !93, file: !7, line: 6465, baseType: !37, size: 128, offset: 448)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "state", scope: !93, file: !7, line: 6466, baseType: !10, size: 32, offset: 576)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_mapping", scope: !93, file: !7, line: 6467, baseType: !109, size: 32, offset: 608)
!109 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s32", file: !11, line: 26, baseType: !110)
!110 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!111 = !DIDerivedType(tag: DW_TAG_member, name: "gso_size", scope: !6, file: !7, line: 6383, baseType: !10, size: 32, offset: 1408)
!112 = !DIDerivedType(tag: DW_TAG_member, name: "tstamp_type", scope: !6, file: !7, line: 6384, baseType: !57, size: 8, offset: 1440)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "hwtstamp", scope: !6, file: !7, line: 6386, baseType: !84, size: 64, offset: 1472)
!114 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!115 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!116 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !117, size: 64)
!117 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !85)
!118 = !DIBasicType(name: "long", size: 64, encoding: DW_ATE_signed)
!119 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64)
!120 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s64", file: !11, line: 30, baseType: !121)
!121 = !DIBasicType(name: "long long", size: 64, encoding: DW_ATE_signed)
!122 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !123, size: 64)
!123 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !57)
!124 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !125, size: 64)
!125 = !DIDerivedType(tag: DW_TAG_const_type, baseType: null)
!126 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !127, size: 64)
!127 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !128)
!128 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64)
!130 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_tunnel_key", file: !7, line: 6389, size: 352, elements: !131)
!131 = !{!132, !133, !138, !139, !140, !145, !146}
!132 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_id", scope: !130, file: !7, line: 6390, baseType: !10, size: 32)
!133 = !DIDerivedType(tag: DW_TAG_member, scope: !130, file: !7, line: 6391, baseType: !134, size: 128, offset: 32)
!134 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !130, file: !7, line: 6391, size: 128, elements: !135)
!135 = !{!136, !137}
!136 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ipv4", scope: !134, file: !7, line: 6392, baseType: !10, size: 32)
!137 = !DIDerivedType(tag: DW_TAG_member, name: "remote_ipv6", scope: !134, file: !7, line: 6393, baseType: !37, size: 128)
!138 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_tos", scope: !130, file: !7, line: 6395, baseType: !57, size: 8, offset: 160)
!139 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_ttl", scope: !130, file: !7, line: 6396, baseType: !57, size: 8, offset: 168)
!140 = !DIDerivedType(tag: DW_TAG_member, scope: !130, file: !7, line: 6397, baseType: !141, size: 16, offset: 176)
!141 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !130, file: !7, line: 6397, size: 16, elements: !142)
!142 = !{!143, !144}
!143 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_ext", scope: !141, file: !7, line: 6398, baseType: !52, size: 16)
!144 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_flags", scope: !141, file: !7, line: 6399, baseType: !63, size: 16)
!145 = !DIDerivedType(tag: DW_TAG_member, name: "tunnel_label", scope: !130, file: !7, line: 6401, baseType: !10, size: 32, offset: 192)
!146 = !DIDerivedType(tag: DW_TAG_member, scope: !130, file: !7, line: 6402, baseType: !147, size: 128, offset: 224)
!147 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !130, file: !7, line: 6402, size: 128, elements: !148)
!148 = !{!149, !150}
!149 = !DIDerivedType(tag: DW_TAG_member, name: "local_ipv4", scope: !147, file: !7, line: 6403, baseType: !10, size: 32)
!150 = !DIDerivedType(tag: DW_TAG_member, name: "local_ipv6", scope: !147, file: !7, line: 6404, baseType: !37, size: 128)
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !74, size: 64)
!152 = !DIDerivedType(tag: DW_TAG_typedef, name: "__wsum", file: !64, line: 39, baseType: !10)
!153 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !154, size: 64)
!154 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "xdp_md", file: !7, line: 6567, size: 192, elements: !155)
!155 = !{!156, !157, !158, !159, !160, !161}
!156 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !154, file: !7, line: 6568, baseType: !10, size: 32)
!157 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !154, file: !7, line: 6569, baseType: !10, size: 32, offset: 32)
!158 = !DIDerivedType(tag: DW_TAG_member, name: "data_meta", scope: !154, file: !7, line: 6570, baseType: !10, size: 32, offset: 64)
!159 = !DIDerivedType(tag: DW_TAG_member, name: "ingress_ifindex", scope: !154, file: !7, line: 6572, baseType: !10, size: 32, offset: 96)
!160 = !DIDerivedType(tag: DW_TAG_member, name: "rx_queue_index", scope: !154, file: !7, line: 6573, baseType: !10, size: 32, offset: 128)
!161 = !DIDerivedType(tag: DW_TAG_member, name: "egress_ifindex", scope: !154, file: !7, line: 6575, baseType: !10, size: 32, offset: 160)
!162 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !163, size: 64)
!163 = !DICompositeType(tag: DW_TAG_structure_type, name: "pt_regs", file: !164, line: 20, flags: DIFlagFwdDecl)
!164 = !DIFile(filename: "vendor/libbpf/src/bpf_helper_defs.h", directory: "/workspaces/repository")
!165 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !166, size: 64)
!166 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_fib_lookup", file: !7, line: 7323, size: 512, elements: !167)
!167 = !{!168, !169, !170, !171, !172, !177, !178, !184, !189, !194, !203}
!168 = !DIDerivedType(tag: DW_TAG_member, name: "family", scope: !166, file: !7, line: 7327, baseType: !57, size: 8)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "l4_protocol", scope: !166, file: !7, line: 7330, baseType: !57, size: 8, offset: 8)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !166, file: !7, line: 7331, baseType: !63, size: 16, offset: 16)
!171 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !166, file: !7, line: 7332, baseType: !63, size: 16, offset: 32)
!172 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7334, baseType: !173, size: 16, align: 16, offset: 48)
!173 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7334, size: 16, align: 16, elements: !174)
!174 = !{!175, !176}
!175 = !DIDerivedType(tag: DW_TAG_member, name: "tot_len", scope: !173, file: !7, line: 7336, baseType: !52, size: 16)
!176 = !DIDerivedType(tag: DW_TAG_member, name: "mtu_result", scope: !173, file: !7, line: 7339, baseType: !52, size: 16)
!177 = !DIDerivedType(tag: DW_TAG_member, name: "ifindex", scope: !166, file: !7, line: 7344, baseType: !10, size: 32, offset: 64)
!178 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7346, baseType: !179, size: 32, offset: 96)
!179 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7346, size: 32, elements: !180)
!180 = !{!181, !182, !183}
!181 = !DIDerivedType(tag: DW_TAG_member, name: "tos", scope: !179, file: !7, line: 7348, baseType: !57, size: 8)
!182 = !DIDerivedType(tag: DW_TAG_member, name: "flowinfo", scope: !179, file: !7, line: 7349, baseType: !74, size: 32)
!183 = !DIDerivedType(tag: DW_TAG_member, name: "rt_metric", scope: !179, file: !7, line: 7352, baseType: !10, size: 32)
!184 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7358, baseType: !185, size: 128, offset: 128)
!185 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7358, size: 128, elements: !186)
!186 = !{!187, !188}
!187 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_src", scope: !185, file: !7, line: 7359, baseType: !74, size: 32)
!188 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_src", scope: !185, file: !7, line: 7360, baseType: !37, size: 128)
!189 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7367, baseType: !190, size: 128, offset: 256)
!190 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7367, size: 128, elements: !191)
!191 = !{!192, !193}
!192 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_dst", scope: !190, file: !7, line: 7368, baseType: !74, size: 32)
!193 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_dst", scope: !190, file: !7, line: 7369, baseType: !37, size: 128)
!194 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7372, baseType: !195, size: 32, offset: 384)
!195 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7372, size: 32, elements: !196)
!196 = !{!197, !202}
!197 = !DIDerivedType(tag: DW_TAG_member, scope: !195, file: !7, line: 7373, baseType: !198, size: 32)
!198 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !195, file: !7, line: 7373, size: 32, elements: !199)
!199 = !{!200, !201}
!200 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_proto", scope: !198, file: !7, line: 7375, baseType: !63, size: 16)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "h_vlan_TCI", scope: !198, file: !7, line: 7376, baseType: !63, size: 16, offset: 16)
!202 = !DIDerivedType(tag: DW_TAG_member, name: "tbid", scope: !195, file: !7, line: 7382, baseType: !10, size: 32)
!203 = !DIDerivedType(tag: DW_TAG_member, scope: !166, file: !7, line: 7385, baseType: !204, size: 96, offset: 416)
!204 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !166, file: !7, line: 7385, size: 96, elements: !205)
!205 = !{!206, !210}
!206 = !DIDerivedType(tag: DW_TAG_member, scope: !204, file: !7, line: 7387, baseType: !207, size: 32)
!207 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !204, file: !7, line: 7387, size: 32, elements: !208)
!208 = !{!209}
!209 = !DIDerivedType(tag: DW_TAG_member, name: "mark", scope: !207, file: !7, line: 7388, baseType: !10, size: 32)
!210 = !DIDerivedType(tag: DW_TAG_member, scope: !204, file: !7, line: 7393, baseType: !211, size: 96)
!211 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !204, file: !7, line: 7393, size: 96, elements: !212)
!212 = !{!213, !217}
!213 = !DIDerivedType(tag: DW_TAG_member, name: "smac", scope: !211, file: !7, line: 7394, baseType: !214, size: 48)
!214 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 48, elements: !215)
!215 = !{!216}
!216 = !DISubrange(count: 6)
!217 = !DIDerivedType(tag: DW_TAG_member, name: "dmac", scope: !211, file: !7, line: 7395, baseType: !214, size: 48, offset: 48)
!218 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !219, size: 64)
!219 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_sock_tuple", file: !7, line: 6515, size: 288, elements: !220)
!220 = !{!221}
!221 = !DIDerivedType(tag: DW_TAG_member, scope: !219, file: !7, line: 6516, baseType: !222, size: 288)
!222 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !219, file: !7, line: 6516, size: 288, elements: !223)
!223 = !{!224, !231}
!224 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4", scope: !222, file: !7, line: 6522, baseType: !225, size: 96)
!225 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !222, file: !7, line: 6517, size: 96, elements: !226)
!226 = !{!227, !228, !229, !230}
!227 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !225, file: !7, line: 6518, baseType: !74, size: 32)
!228 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !225, file: !7, line: 6519, baseType: !74, size: 32, offset: 32)
!229 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !225, file: !7, line: 6520, baseType: !63, size: 16, offset: 64)
!230 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !225, file: !7, line: 6521, baseType: !63, size: 16, offset: 80)
!231 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6", scope: !222, file: !7, line: 6528, baseType: !232, size: 288)
!232 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !222, file: !7, line: 6523, size: 288, elements: !233)
!233 = !{!234, !236, !237, !238}
!234 = !DIDerivedType(tag: DW_TAG_member, name: "saddr", scope: !232, file: !7, line: 6524, baseType: !235, size: 128)
!235 = !DICompositeType(tag: DW_TAG_array_type, baseType: !74, size: 128, elements: !38)
!236 = !DIDerivedType(tag: DW_TAG_member, name: "daddr", scope: !232, file: !7, line: 6525, baseType: !235, size: 128, offset: 128)
!237 = !DIDerivedType(tag: DW_TAG_member, name: "sport", scope: !232, file: !7, line: 6526, baseType: !63, size: 16, offset: 256)
!238 = !DIDerivedType(tag: DW_TAG_member, name: "dport", scope: !232, file: !7, line: 6527, baseType: !63, size: 16, offset: 272)
!239 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !118, size: 64)
!240 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !241, size: 64)
!241 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "bpf_redir_neigh", file: !7, line: 7400, size: 160, elements: !242)
!242 = !{!243, !244}
!243 = !DIDerivedType(tag: DW_TAG_member, name: "nh_family", scope: !241, file: !7, line: 7402, baseType: !10, size: 32)
!244 = !DIDerivedType(tag: DW_TAG_member, scope: !241, file: !7, line: 7404, baseType: !245, size: 128, offset: 32)
!245 = distinct !DICompositeType(tag: DW_TAG_union_type, scope: !241, file: !7, line: 7404, size: 128, elements: !246)
!246 = !{!247, !248}
!247 = !DIDerivedType(tag: DW_TAG_member, name: "ipv4_nh", scope: !245, file: !7, line: 7405, baseType: !74, size: 32)
!248 = !DIDerivedType(tag: DW_TAG_member, name: "ipv6_nh", scope: !245, file: !7, line: 7406, baseType: !37, size: 128)
!249 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !10, size: 64)
!250 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !251, size: 64)
!251 = !DICompositeType(tag: DW_TAG_structure_type, name: "task_struct", file: !164, line: 31, flags: DIFlagFwdDecl)
!252 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64)
!253 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !254, size: 64)
!254 = !DICompositeType(tag: DW_TAG_structure_type, name: "file", file: !164, line: 40, flags: DIFlagFwdDecl)
!255 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s8", file: !11, line: 20, baseType: !256)
!256 = !DIBasicType(name: "signed char", size: 8, encoding: DW_ATE_signed_char)
!257 = !DIDerivedType(tag: DW_TAG_typedef, name: "__s16", file: !11, line: 23, baseType: !258)
!258 = !DIBasicType(name: "short", size: 16, encoding: DW_ATE_signed)
!259 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !260, size: 64)
!260 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !123)
!261 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !262, size: 64)
!262 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !114)
!263 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !264, size: 64)
!264 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !57)
!265 = !{!0, !266, !272}
!266 = !DIGlobalVariableExpression(var: !267, expr: !DIExpression())
!267 = distinct !DIGlobalVariable(name: "kprog_unspecified_input", scope: !2, file: !268, line: 19, type: !269, isLocal: false, isDefinition: false)
!268 = !DIFile(filename: "kprog/stock-path/bin/../include/stock_native_input.h", directory: "/workspaces/repository")
!269 = !DICompositeType(tag: DW_TAG_array_type, baseType: !85, elements: !270)
!270 = !{!271}
!271 = !DISubrange(count: -1)
!272 = !DIGlobalVariableExpression(var: !273, expr: !DIExpression())
!273 = distinct !DIGlobalVariable(name: "map_a", scope: !2, file: !274, line: 6, type: !275, isLocal: false, isDefinition: false)
!274 = !DIFile(filename: "/var/tmp/kprog-tmp/perf/lpm-c-lto/generation/trusted_x86.bpf.c", directory: "")
!275 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, elements: !270)
!276 = !DICompositeType(tag: DW_TAG_array_type, baseType: !128, size: 32, elements: !38)
!277 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!278 = !{i32 7, !"Dwarf Version", i32 5}
!279 = !{i32 2, !"Debug Info Version", i32 3}
!280 = !{i32 1, !"wchar_size", i32 4}
!281 = !{i32 7, !"frame-pointer", i32 2}
!282 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!283 = !{i32 8, !"PIC Level", i32 0}
!284 = !{i32 7, !"PIE Level", i32 2}
!285 = !{i32 7, !"uwtable", i32 2}
!286 = distinct !DISubprogram(name: "trusted_x86_x86_sim_xdp", scope: !274, file: !274, line: 20, type: !287, scopeLine: 21, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !289)
!287 = !DISubroutineType(types: !288)
!288 = !{!110, !114}
!289 = !{!290, !291, !310, !311, !312, !366, !367, !368, !369, !370, !371, !372, !373, !374, !375, !376, !377, !378, !379, !380, !381, !382, !383, !398, !429, !430, !431, !432, !433, !434, !435, !436, !437, !438, !439, !444, !445, !446, !447, !448, !449, !450}
!290 = !DILocalVariable(name: "ctx", arg: 1, scope: !286, file: !274, line: 20, type: !114)
!291 = !DILocalVariable(name: "__x86_sim_abi", scope: !286, file: !274, line: 22, type: !292)
!292 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_skb_abi", file: !293, line: 133, size: 1728, elements: !294)
!293 = !DIFile(filename: "kprog/x86/x86_sim_local_bpf.h", directory: "/workspaces/repository")
!294 = !{!295, !299, !300, !304, !305, !309}
!295 = !DIDerivedType(tag: DW_TAG_member, name: "pad0", scope: !292, file: !293, line: 134, baseType: !296, size: 384)
!296 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 384, elements: !297)
!297 = !{!298}
!298 = !DISubrange(count: 48)
!299 = !DIDerivedType(tag: DW_TAG_member, name: "cb", scope: !292, file: !293, line: 135, baseType: !25, size: 160, offset: 384)
!300 = !DIDerivedType(tag: DW_TAG_member, name: "pad1", scope: !292, file: !293, line: 136, baseType: !301, size: 96, offset: 544)
!301 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 96, elements: !302)
!302 = !{!303}
!303 = !DISubrange(count: 12)
!304 = !DIDerivedType(tag: DW_TAG_member, name: "data_end", scope: !292, file: !293, line: 137, baseType: !114, size: 64, offset: 640)
!305 = !DIDerivedType(tag: DW_TAG_member, name: "pad2", scope: !292, file: !293, line: 138, baseType: !306, size: 960, offset: 704)
!306 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 960, elements: !307)
!307 = !{!308}
!308 = !DISubrange(count: 120)
!309 = !DIDerivedType(tag: DW_TAG_member, name: "data", scope: !292, file: !293, line: 139, baseType: !114, size: 64, offset: 1664)
!310 = !DILocalVariable(name: "__x86_sim_skb_ctx", scope: !286, file: !274, line: 22, type: !5)
!311 = !DILocalVariable(name: "__x86_sim_abi_kind", scope: !286, file: !274, line: 22, type: !264)
!312 = !DILocalVariable(name: "__x86_local_gprs", scope: !286, file: !274, line: 22, type: !313)
!313 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_register_cells", file: !293, line: 398, size: 2048, elements: !314)
!314 = !{!315, !358}
!315 = !DIDerivedType(tag: DW_TAG_member, scope: !313, file: !293, line: 398, baseType: !316, size: 2048)
!316 = distinct !DICompositeType(tag: DW_TAG_structure_type, scope: !313, file: !293, line: 398, size: 2048, elements: !317)
!317 = !{!318, !327, !328, !329, !330, !331, !332, !333, !334, !335, !336, !337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !348, !349, !350, !351, !352, !353, !354, !355, !356, !357}
!318 = !DIDerivedType(tag: DW_TAG_member, name: "rax", scope: !316, file: !293, line: 398, baseType: !319, size: 64)
!319 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_gpr", file: !293, line: 153, size: 64, elements: !320)
!320 = !{!321, !322, !323}
!321 = !DIDerivedType(tag: DW_TAG_member, name: "ptr", scope: !319, file: !293, line: 154, baseType: !114, size: 64)
!322 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !319, file: !293, line: 155, baseType: !52, size: 16)
!323 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !319, file: !293, line: 156, baseType: !324, size: 64)
!324 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 64, elements: !325)
!325 = !{!326}
!326 = !DISubrange(count: 8)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "rax_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 64)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "rcx", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 128)
!329 = !DIDerivedType(tag: DW_TAG_member, name: "rcx_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 192)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "rdx", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 256)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "rdx_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 320)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "rbx", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 384)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "rbx_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 448)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "rsp", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 512)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "rsp_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 576)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "rbp", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 640)
!337 = !DIDerivedType(tag: DW_TAG_member, name: "rbp_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 704)
!338 = !DIDerivedType(tag: DW_TAG_member, name: "rsi", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 768)
!339 = !DIDerivedType(tag: DW_TAG_member, name: "rsi_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 832)
!340 = !DIDerivedType(tag: DW_TAG_member, name: "rdi", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 896)
!341 = !DIDerivedType(tag: DW_TAG_member, name: "rdi_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 960)
!342 = !DIDerivedType(tag: DW_TAG_member, name: "r8", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1024)
!343 = !DIDerivedType(tag: DW_TAG_member, name: "r8_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1088)
!344 = !DIDerivedType(tag: DW_TAG_member, name: "r9", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1152)
!345 = !DIDerivedType(tag: DW_TAG_member, name: "r9_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1216)
!346 = !DIDerivedType(tag: DW_TAG_member, name: "r10", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1280)
!347 = !DIDerivedType(tag: DW_TAG_member, name: "r10_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1344)
!348 = !DIDerivedType(tag: DW_TAG_member, name: "r11", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1408)
!349 = !DIDerivedType(tag: DW_TAG_member, name: "r11_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1472)
!350 = !DIDerivedType(tag: DW_TAG_member, name: "r12", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1536)
!351 = !DIDerivedType(tag: DW_TAG_member, name: "r12_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1600)
!352 = !DIDerivedType(tag: DW_TAG_member, name: "r13", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1664)
!353 = !DIDerivedType(tag: DW_TAG_member, name: "r13_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1728)
!354 = !DIDerivedType(tag: DW_TAG_member, name: "r14", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1792)
!355 = !DIDerivedType(tag: DW_TAG_member, name: "r14_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1856)
!356 = !DIDerivedType(tag: DW_TAG_member, name: "r15", scope: !316, file: !293, line: 398, baseType: !319, size: 64, offset: 1920)
!357 = !DIDerivedType(tag: DW_TAG_member, name: "r15_tag", scope: !316, file: !293, line: 398, baseType: !57, size: 8, offset: 1984)
!358 = !DIDerivedType(tag: DW_TAG_member, name: "gpr_cells", scope: !313, file: !293, line: 398, baseType: !359, size: 2048)
!359 = !DICompositeType(tag: DW_TAG_array_type, baseType: !360, size: 2048, elements: !364)
!360 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_gpr_cell", file: !293, line: 392, size: 128, elements: !361)
!361 = !{!362, !363}
!362 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !360, file: !293, line: 392, baseType: !319, size: 64)
!363 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !360, file: !293, line: 392, baseType: !57, size: 8, offset: 64)
!364 = !{!365}
!365 = !DISubrange(count: 16)
!366 = !DILocalVariable(name: "__x86_stack_value_tag_0", scope: !286, file: !274, line: 22, type: !57)
!367 = !DILocalVariable(name: "__x86_stack_value_ptr_0", scope: !286, file: !274, line: 22, type: !114)
!368 = !DILocalVariable(name: "__x86_stack_value_tag_1", scope: !286, file: !274, line: 22, type: !57)
!369 = !DILocalVariable(name: "__x86_stack_value_ptr_1", scope: !286, file: !274, line: 22, type: !114)
!370 = !DILocalVariable(name: "__x86_sim_is_xdp", scope: !286, file: !274, line: 22, type: !57)
!371 = !DILocalVariable(name: "__x86_sim_helper_ctx", scope: !286, file: !274, line: 22, type: !114)
!372 = !DILocalVariable(name: "__x86_sim_helper_abi_base", scope: !286, file: !274, line: 22, type: !114)
!373 = !DILocalVariable(name: "__x86_native_stack_base", scope: !286, file: !274, line: 22, type: !84)
!374 = !DILocalVariable(name: "__x86_cf", scope: !286, file: !274, line: 22, type: !57)
!375 = !DILocalVariable(name: "__x86_zf", scope: !286, file: !274, line: 22, type: !57)
!376 = !DILocalVariable(name: "__x86_sf", scope: !286, file: !274, line: 22, type: !57)
!377 = !DILocalVariable(name: "__x86_of", scope: !286, file: !274, line: 22, type: !57)
!378 = !DILocalVariable(name: "__x86_pf", scope: !286, file: !274, line: 22, type: !57)
!379 = !DILocalVariable(name: "__x86_af", scope: !286, file: !274, line: 22, type: !57)
!380 = !DILocalVariable(name: "__x86_xmm0_lo", scope: !286, file: !274, line: 22, type: !84)
!381 = !DILocalVariable(name: "__x86_xmm0_hi", scope: !286, file: !274, line: 22, type: !84)
!382 = !DILocalVariable(name: "__x86_sim_ret_addr", scope: !286, file: !274, line: 22, type: !84)
!383 = !DILocalVariable(name: "__x86_stack_mem", scope: !286, file: !274, line: 22, type: !384)
!384 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_stack_mem", file: !293, line: 166, size: 192, elements: !385)
!385 = !{!386, !390, !392, !394}
!386 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !384, file: !293, line: 167, baseType: !387, size: 192)
!387 = !DICompositeType(tag: DW_TAG_array_type, baseType: !57, size: 192, elements: !388)
!388 = !{!389}
!389 = !DISubrange(count: 24)
!390 = !DIDerivedType(tag: DW_TAG_member, name: "w", scope: !384, file: !293, line: 168, baseType: !391, size: 192)
!391 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 192, elements: !302)
!392 = !DIDerivedType(tag: DW_TAG_member, name: "d", scope: !384, file: !293, line: 169, baseType: !393, size: 192)
!393 = !DICompositeType(tag: DW_TAG_array_type, baseType: !10, size: 192, elements: !215)
!394 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !384, file: !293, line: 170, baseType: !395, size: 192)
!395 = !DICompositeType(tag: DW_TAG_array_type, baseType: !84, size: 192, elements: !396)
!396 = !{!397}
!397 = !DISubrange(count: 3)
!398 = !DILocalVariable(name: "__x86_inline_bindings", scope: !286, file: !274, line: 23, type: !399)
!399 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_inline_bindings", file: !400, line: 15, size: 1408, elements: !401)
!400 = !DIFile(filename: "kprog/x86/x86_sim_inline.h", directory: "/workspaces/repository")
!401 = !{!402, !404, !407, !414, !415, !416, !417, !418, !419, !420, !421, !422, !423, !424, !425, !426, !427, !428}
!402 = !DIDerivedType(tag: DW_TAG_member, name: "cells", scope: !399, file: !400, line: 16, baseType: !403, size: 64)
!403 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !360, size: 64)
!404 = !DIDerivedType(tag: DW_TAG_member, name: "stack", scope: !399, file: !400, line: 17, baseType: !405, size: 64, offset: 64)
!405 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !406, size: 64)
!406 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !384)
!407 = !DIDerivedType(tag: DW_TAG_member, name: "values", scope: !399, file: !400, line: 18, baseType: !408, size: 384, offset: 128)
!408 = !DICompositeType(tag: DW_TAG_array_type, baseType: !409, size: 384, elements: !396)
!409 = distinct !DICompositeType(tag: DW_TAG_structure_type, name: "x86_sim_inline_value", file: !400, line: 14, size: 128, elements: !410)
!410 = !{!411, !412}
!411 = !DIDerivedType(tag: DW_TAG_member, name: "tag", scope: !409, file: !400, line: 14, baseType: !119, size: 64)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !409, file: !400, line: 14, baseType: !413, size: 64, offset: 64)
!413 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !114, size: 64)
!414 = !DIDerivedType(tag: DW_TAG_member, name: "native_stack_base", scope: !399, file: !400, line: 19, baseType: !252, size: 64, offset: 512)
!415 = !DIDerivedType(tag: DW_TAG_member, name: "cf", scope: !399, file: !400, line: 20, baseType: !119, size: 64, offset: 576)
!416 = !DIDerivedType(tag: DW_TAG_member, name: "zf", scope: !399, file: !400, line: 21, baseType: !119, size: 64, offset: 640)
!417 = !DIDerivedType(tag: DW_TAG_member, name: "sf", scope: !399, file: !400, line: 22, baseType: !119, size: 64, offset: 704)
!418 = !DIDerivedType(tag: DW_TAG_member, name: "of", scope: !399, file: !400, line: 23, baseType: !119, size: 64, offset: 768)
!419 = !DIDerivedType(tag: DW_TAG_member, name: "pf", scope: !399, file: !400, line: 24, baseType: !119, size: 64, offset: 832)
!420 = !DIDerivedType(tag: DW_TAG_member, name: "af", scope: !399, file: !400, line: 25, baseType: !119, size: 64, offset: 896)
!421 = !DIDerivedType(tag: DW_TAG_member, name: "xmm0_lo", scope: !399, file: !400, line: 26, baseType: !252, size: 64, offset: 960)
!422 = !DIDerivedType(tag: DW_TAG_member, name: "xmm0_hi", scope: !399, file: !400, line: 27, baseType: !252, size: 64, offset: 1024)
!423 = !DIDerivedType(tag: DW_TAG_member, name: "sim_ret_addr", scope: !399, file: !400, line: 28, baseType: !252, size: 64, offset: 1088)
!424 = !DIDerivedType(tag: DW_TAG_member, name: "sim_helper_ctx", scope: !399, file: !400, line: 29, baseType: !114, size: 64, offset: 1152)
!425 = !DIDerivedType(tag: DW_TAG_member, name: "sim_helper_abi_base", scope: !399, file: !400, line: 30, baseType: !114, size: 64, offset: 1216)
!426 = !DIDerivedType(tag: DW_TAG_member, name: "sim_skb_ctx", scope: !399, file: !400, line: 31, baseType: !5, size: 64, offset: 1280)
!427 = !DIDerivedType(tag: DW_TAG_member, name: "sim_is_xdp", scope: !399, file: !400, line: 32, baseType: !57, size: 8, offset: 1344)
!428 = !DIDerivedType(tag: DW_TAG_member, name: "sim_abi_kind", scope: !399, file: !400, line: 33, baseType: !57, size: 8, offset: 1352)
!429 = !DILabel(scope: !286, name: "x86_l_0", file: !274, line: 24)
!430 = !DILabel(scope: !286, name: "x86_l_4", file: !274, line: 27)
!431 = !DILabel(scope: !286, name: "x86_l_e", file: !274, line: 30)
!432 = !DILabel(scope: !286, name: "x86_l_13", file: !274, line: 33)
!433 = !DILabel(scope: !286, name: "x86_l_1d", file: !274, line: 36)
!434 = !DILabel(scope: !286, name: "x86_l_21", file: !274, line: 39)
!435 = !DILabel(scope: !286, name: "x86_l_28", file: !274, line: 42)
!436 = !DILabel(scope: !286, name: "x86_l_2b", file: !274, line: 45)
!437 = !DILabel(scope: !286, name: "x86_l_30", file: !274, line: 48)
!438 = !DILabel(scope: !286, name: "x86_l_33", file: !274, line: 51)
!439 = !DILabel(scope: !440, name: "__x86_sim_jcc_fallthrough_53", file: !274, line: 53)
!440 = distinct !DILexicalBlock(scope: !441, file: !274, line: 53, column: 62)
!441 = distinct !DILexicalBlock(scope: !442, file: !274, line: 53, column: 57)
!442 = distinct !DILexicalBlock(scope: !443, file: !274, line: 53, column: 11)
!443 = distinct !DILexicalBlock(scope: !286, file: !274, line: 53, column: 5)
!444 = !DILabel(scope: !286, name: "x86_l_35", file: !274, line: 54)
!445 = !DILabel(scope: !286, name: "x86_l_37", file: !274, line: 57)
!446 = !DILabel(scope: !286, name: "x86_l_3b", file: !274, line: 60)
!447 = !DILabel(scope: !286, name: "x86_l_40", file: !274, line: 63)
!448 = !DILabel(scope: !286, name: "x86_l_42", file: !274, line: 66)
!449 = !DILabel(scope: !286, name: "x86_l_46", file: !274, line: 69)
!450 = !DILabel(scope: !286, name: "x86_l_4b", file: !274, line: 72)
!451 = distinct !DIAssignID()
!452 = !DILocation(line: 0, scope: !286)
!453 = distinct !DIAssignID()
!454 = distinct !DIAssignID()
!455 = distinct !DIAssignID()
!456 = !DILocation(line: 22, column: 4488, scope: !286)
!457 = !DILocation(line: 24, column: 1, scope: !286)
!458 = !DILocation(line: 27, column: 1, scope: !286)
!459 = !DILocation(line: 30, column: 1, scope: !286)
!460 = !DILocation(line: 32, column: 2, scope: !286)
!461 = !{!462, !462, i64 0}
!462 = !{!"omnipotent char", !463, i64 0}
!463 = !{!"Simple C/C++ TBAA"}
!464 = !DILocation(line: 33, column: 1, scope: !286)
!465 = !DILocation(line: 36, column: 1, scope: !286)
!466 = !DILocation(line: 38, column: 2, scope: !286)
!467 = !DILocation(line: 39, column: 1, scope: !286)
!468 = !DILocation(line: 42, column: 1, scope: !286)
!469 = !DILocation(line: 45, column: 1, scope: !286)
!470 = !DILocation(line: 47, column: 2, scope: !286)
!471 = !{!472, !472, i64 0}
!472 = !{!"any pointer", !462, i64 0}
!473 = !DILocation(line: 48, column: 1, scope: !286)
!474 = !DILocation(line: 51, column: 1, scope: !286)
!475 = !DILocation(line: 53, column: 370, scope: !443)
!476 = !{i64 3831774}
!477 = !DILocation(line: 54, column: 1, scope: !286)
!478 = !DILocalVariable(name: "base", arg: 1, scope: !479, file: !480, line: 76, type: !124)
!479 = distinct !DISubprogram(name: "kprog_x86_mem_load_fixed", scope: !480, file: !480, line: 76, type: !481, scopeLine: 77, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !483)
!480 = !DIFile(filename: "kprog/x86/../formal/generated/x86_mem_access.h", directory: "/workspaces/repository")
!481 = !DISubroutineType(types: !482)
!482 = !{!84, !124, !121, !57}
!483 = !{!478, !484, !485, !486}
!484 = !DILocalVariable(name: "displacement", arg: 2, scope: !479, file: !480, line: 76, type: !121)
!485 = !DILocalVariable(name: "width", arg: 3, scope: !479, file: !480, line: 76, type: !57)
!486 = !DILocalVariable(name: "value", scope: !479, file: !480, line: 81, type: !84)
!487 = !DILocation(line: 0, scope: !479, inlinedAt: !488)
!488 = distinct !DILocation(line: 56, column: 2, scope: !286)
!489 = !DILocation(line: 99, column: 13, scope: !490, inlinedAt: !488)
!490 = distinct !DILexicalBlock(scope: !491, file: !480, line: 96, column: 13)
!491 = distinct !DILexicalBlock(scope: !479, file: !480, line: 82, column: 33)
!492 = !DILocation(line: 57, column: 1, scope: !286)
!493 = !DILocation(line: 59, column: 2, scope: !286)
!494 = !DILocation(line: 75, column: 1, scope: !286)
!495 = !{!496, !496, i64 0}
!496 = !{!"int", !462, i64 0}
