
/var/tmp/kprog-tmp/perf/lpm-c-lto/generation/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section kprobe/lpm_fixture:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 48 b8 60 00 00 00 5a 5a 5a 5a	movabsq	$0x5a5a5a5a00000060, %rax # imm = 0x5A5A5A5A00000060
       a: 48 8d 88 fa 59 5a 5a         	leaq	0x5a5a59fa(%rax), %rcx
      11: 48 89 4c 24 f0               	movq	%rcx, -0x10(%rsp)
      16: 48 89 44 24 e8               	movq	%rax, -0x18(%rsp)
      1b: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x22 <trusted_x86_x86_sim_xdp+0x22>
      22: 48 8b 80 20 01 00 00         	movq	0x120(%rax), %rax
      29: 48 85 c0                     	testq	%rax, %rax
      2c: 0f 84 9d 00 00 00            	je	0xcf <trusted_x86_x86_sim_xdp+0xcf>
      32: 48 8b 54 24 ec               	movq	-0x14(%rsp), %rdx
      37: 31 c9                        	xorl	%ecx, %ecx
      39: be 5a 5a 5a 5a               	movl	$0x5a5a5a5a, %esi       # imm = 0x5A5A5A5A
      3e: eb 40                        	jmp	0x80 <trusted_x86_x86_sim_xdp+0x80>
      40: 49 0f c8                     	bswapq	%r8
      43: 41 89 f9                     	movl	%edi, %r9d
      46: 41 f6 d9                     	negb	%r9b
      49: c4 42 b3 f7 c0               	shrxq	%r9, %r8, %r8
      4e: 4d 85 c0                     	testq	%r8, %r8
      51: 75 6d                        	jne	0xc0 <trusted_x86_x86_sim_xdp+0xc0>
      53: f6 40 14 01                  	testb	$0x1, 0x14(%rax)
      57: 48 0f 44 c8                  	cmoveq	%rax, %rcx
      5b: 41 89 f8                     	movl	%edi, %r8d
      5e: 41 c1 e8 03                  	shrl	$0x3, %r8d
      62: 46 0f b6 44 04 ec            	movzbl	-0x14(%rsp,%r8), %r8d
      68: 40 f6 d7                     	notb	%dil
      6b: 40 80 e7 07                  	andb	$0x7, %dil
      6f: c4 c2 43 f7 f8               	shrxl	%edi, %r8d, %edi
      74: 83 e7 01                     	andl	$0x1, %edi
      77: 48 8b 04 f8                  	movq	(%rax,%rdi,8), %rax
      7b: 48 85 c0                     	testq	%rax, %rax
      7e: 74 40                        	je	0xc0 <trusted_x86_x86_sim_xdp+0xc0>
      80: 8b 78 10                     	movl	0x10(%rax), %edi
      83: 48 83 ff 60                  	cmpq	$0x60, %rdi
      87: 77 37                        	ja	0xc0 <trusted_x86_x86_sim_xdp+0xc0>
      89: 48 85 ff                     	testq	%rdi, %rdi
      8c: 74 c5                        	je	0x53 <trusted_x86_x86_sim_xdp+0x53>
      8e: 4c 8b 40 18                  	movq	0x18(%rax), %r8
      92: 49 31 d0                     	xorq	%rdx, %r8
      95: 83 ff 40                     	cmpl	$0x40, %edi
      98: 76 a6                        	jbe	0x40 <trusted_x86_x86_sim_xdp+0x40>
      9a: 4d 85 c0                     	testq	%r8, %r8
      9d: 75 21                        	jne	0xc0 <trusted_x86_x86_sim_xdp+0xc0>
      9f: 44 8b 40 20                  	movl	0x20(%rax), %r8d
      a3: 41 31 f0                     	xorl	%esi, %r8d
      a6: 41 0f c8                     	bswapl	%r8d
      a9: 41 89 f9                     	movl	%edi, %r9d
      ac: 41 f6 d9                     	negb	%r9b
      af: c4 42 33 f7 c0               	shrxl	%r9d, %r8d, %r8d
      b4: 45 85 c0                     	testl	%r8d, %r8d
      b7: 75 07                        	jne	0xc0 <trusted_x86_x86_sim_xdp+0xc0>
      b9: 83 ff 60                     	cmpl	$0x60, %edi
      bc: 75 95                        	jne	0x53 <trusted_x86_x86_sim_xdp+0x53>
      be: eb 08                        	jmp	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
      c0: 48 89 c8                     	movq	%rcx, %rax
      c3: 48 85 c9                     	testq	%rcx, %rcx
      c6: 74 07                        	je	0xcf <trusted_x86_x86_sim_xdp+0xcf>
      c8: 48 83 c0 24                  	addq	$0x24, %rax
      cc: 8b 00                        	movl	(%rax), %eax
      ce: c3                           	retq
      cf: 31 c0                        	xorl	%eax, %eax
      d1: c3                           	retq
