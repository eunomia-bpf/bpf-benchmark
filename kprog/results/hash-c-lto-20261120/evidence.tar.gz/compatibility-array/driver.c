#include <stdint.h>
#include <stdio.h>
#include <string.h>
unsigned char counts[4096] __attribute__((aligned(8))), other[4096];
static unsigned generic;
void *bpf_map_lookup_elem(void *map, const void *key) {
    (void)key; ++generic; return map;
}
extern void *selected(unsigned *), *unselected(unsigned *), *dynamic(void *, unsigned *);
int main(void) {
    unsigned tests=0;
    for(unsigned n=0;n<=17;++n) for(unsigned size=8;size<=64;size+=8) {
        unsigned mask=31;
        memcpy(counts+68,&n,4); memcpy(counts+288,&size,4); memcpy(counts+292,&mask,4);
        unsigned keys[]={0,1,16,17,31,0x80000000U,0xffffffffU};
        for(unsigned j=0;j<7;++j) {
            unsigned key=keys[j];
            void *want=key<n ? counts+304+(uint64_t)size*(key&mask):0;
            if(selected(&key)!=want || generic) return 1;
            ++tests;
        }
    }
    unsigned key=0;
    if(unselected(&key)!=other || dynamic(counts,&key)!=counts || generic!=2) return 2;
    printf("%u ARRAY boundary cases and two generic calls passed\n",tests);
}
