__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
