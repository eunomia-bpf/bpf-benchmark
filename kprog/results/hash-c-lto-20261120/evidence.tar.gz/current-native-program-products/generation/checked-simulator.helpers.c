#include "/workspaces/repository/kprog/x86/micro-prog/native_hash.h"
__KPROG_HASH_CODE
extern unsigned char __kprog_hash_map_0[] __asm__("map_a");
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_hash_map_0) return __kprog_hash_lookup(map,key,8,448,824,832,16,0,0,0,40,48);

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
