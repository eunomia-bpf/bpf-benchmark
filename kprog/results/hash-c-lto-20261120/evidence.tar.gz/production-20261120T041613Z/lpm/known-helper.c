#include "/workspaces/repository/kprog/x86/micro-prog/native_lpm.h"
__KPROG_LPM_CODE
extern unsigned char __kprog_lpm_map_0[] __asm__("map_a");
extern unsigned char __kprog_lpm_map_1[] __asm__("map_b");
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_lpm_map_0) return __kprog_lpm_lookup(map,key,12,96,288,0,16,20,24);
    if (map == __kprog_lpm_map_1) return __kprog_lpm_lookup(map,key,12,96,288,0,16,20,24);

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
