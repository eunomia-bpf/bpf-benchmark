# 1 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.piece0.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 348 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/workspaces/repository/kprog/stock-path/bin/../include/stock_native_input.h" 1
# 19 "/workspaces/repository/kprog/stock-path/bin/../include/stock_native_input.h"
extern unsigned long long kprog_unspecified_input[] __attribute__((section(".ksyms")));
# 2 "<built-in>" 2
# 1 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.piece0.c" 2
# 1 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"



# 1 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 1






# 1 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h" 1
# 11 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
# 1 "/usr/include/linux/types.h" 1 3 4




# 1 "/usr/include/x86_64-linux-gnu/asm/types.h" 1 3 4
# 1 "/usr/include/asm-generic/types.h" 1 3 4






# 1 "/usr/include/asm-generic/int-ll64.h" 1 3 4
# 12 "/usr/include/asm-generic/int-ll64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 3 4
# 1 "/usr/include/asm-generic/bitsperlong.h" 1 3 4
# 12 "/usr/include/x86_64-linux-gnu/asm/bitsperlong.h" 2 3 4
# 13 "/usr/include/asm-generic/int-ll64.h" 2 3 4







typedef __signed__ char __s8;
typedef unsigned char __u8;

typedef __signed__ short __s16;
typedef unsigned short __u16;

typedef __signed__ int __s32;
typedef unsigned int __u32;


__extension__ typedef __signed__ long long __s64;
__extension__ typedef unsigned long long __u64;
# 8 "/usr/include/asm-generic/types.h" 2 3 4
# 2 "/usr/include/x86_64-linux-gnu/asm/types.h" 2 3 4
# 6 "/usr/include/linux/types.h" 2 3 4



# 1 "/usr/include/linux/posix_types.h" 1 3 4




# 1 "/workspaces/repository/vendor/libbpf/include/uapi/linux/stddef.h" 1 3 4
# 6 "/usr/include/linux/posix_types.h" 2 3 4
# 25 "/usr/include/linux/posix_types.h" 3 4
typedef struct {
 unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;


typedef void (*__kernel_sighandler_t)(int);


typedef int __kernel_key_t;
typedef int __kernel_mqd_t;

# 1 "/usr/include/x86_64-linux-gnu/asm/posix_types.h" 1 3 4






# 1 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 3 4
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;


typedef unsigned long __kernel_old_dev_t;


# 1 "/usr/include/asm-generic/posix_types.h" 1 3 4
# 15 "/usr/include/asm-generic/posix_types.h" 3 4
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;



typedef __kernel_ulong_t __kernel_ino_t;



typedef unsigned int __kernel_mode_t;



typedef int __kernel_pid_t;



typedef int __kernel_ipc_pid_t;



typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;



typedef __kernel_long_t __kernel_suseconds_t;



typedef int __kernel_daddr_t;



typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
# 68 "/usr/include/asm-generic/posix_types.h" 3 4
typedef unsigned int __kernel_size_t;
typedef int __kernel_ssize_t;
typedef int __kernel_ptrdiff_t;
# 79 "/usr/include/asm-generic/posix_types.h" 3 4
typedef struct {
 int val[2];
} __kernel_fsid_t;





typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef __kernel_long_t __kernel_old_time_t;
typedef __kernel_long_t __kernel_time_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
# 19 "/usr/include/x86_64-linux-gnu/asm/posix_types_64.h" 2 3 4
# 8 "/usr/include/x86_64-linux-gnu/asm/posix_types.h" 2 3 4
# 37 "/usr/include/linux/posix_types.h" 2 3 4
# 10 "/usr/include/linux/types.h" 2 3 4


typedef __signed__ __int128 __s128 __attribute__((aligned(16)));
typedef unsigned __int128 __u128 __attribute__((aligned(16)));
# 31 "/usr/include/linux/types.h" 3 4
typedef __u16 __le16;
typedef __u16 __be16;
typedef __u32 __le32;
typedef __u32 __be32;
typedef __u64 __le64;
typedef __u64 __be64;

typedef __u16 __sum16;
typedef __u32 __wsum;
# 54 "/usr/include/linux/types.h" 3 4
typedef unsigned __poll_t;
# 12 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h" 2
# 1 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf_common.h" 1
# 13 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h" 2
# 57 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_cond_pseudo_jmp {
 BPF_MAY_GOTO = 0,
};


enum {
 BPF_REG_0 = 0,
 BPF_REG_1,
 BPF_REG_2,
 BPF_REG_3,
 BPF_REG_4,
 BPF_REG_5,
 BPF_REG_6,
 BPF_REG_7,
 BPF_REG_8,
 BPF_REG_9,
 BPF_REG_10,
 __MAX_BPF_REG,
};




struct bpf_insn {
 __u8 code;
 __u8 dst_reg:4;
 __u8 src_reg:4;
 __s16 off;
 __s32 imm;
};





struct bpf_lpm_trie_key {
 __u32 prefixlen;
 __u8 data[0];
};


struct bpf_lpm_trie_key_hdr {
 __u32 prefixlen;
};


struct bpf_lpm_trie_key_u8 {
 union {
  struct bpf_lpm_trie_key_hdr hdr;
  __u32 prefixlen;
 };
 __u8 data[];
};

struct bpf_cgroup_storage_key {
 __u64 cgroup_inode_id;
 __u32 attach_type;
};

enum bpf_cgroup_iter_order {
 BPF_CGROUP_ITER_ORDER_UNSPEC = 0,
 BPF_CGROUP_ITER_SELF_ONLY,
 BPF_CGROUP_ITER_DESCENDANTS_PRE,
 BPF_CGROUP_ITER_DESCENDANTS_POST,
 BPF_CGROUP_ITER_ANCESTORS_UP,







 BPF_CGROUP_ITER_CHILDREN,
};

union bpf_iter_link_info {
 struct {
  __u32 map_fd;
 } map;
 struct {
  enum bpf_cgroup_iter_order order;






  __u32 cgroup_fd;
  __u64 cgroup_id;
 } cgroup;

 struct {
  __u32 tid;
  __u32 pid;
  __u32 pid_fd;
 } task;
};
# 955 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_cmd {
 BPF_MAP_CREATE,
 BPF_MAP_LOOKUP_ELEM,
 BPF_MAP_UPDATE_ELEM,
 BPF_MAP_DELETE_ELEM,
 BPF_MAP_GET_NEXT_KEY,
 BPF_PROG_LOAD,
 BPF_OBJ_PIN,
 BPF_OBJ_GET,
 BPF_PROG_ATTACH,
 BPF_PROG_DETACH,
 BPF_PROG_TEST_RUN,
 BPF_PROG_RUN = BPF_PROG_TEST_RUN,
 BPF_PROG_GET_NEXT_ID,
 BPF_MAP_GET_NEXT_ID,
 BPF_PROG_GET_FD_BY_ID,
 BPF_MAP_GET_FD_BY_ID,
 BPF_OBJ_GET_INFO_BY_FD,
 BPF_PROG_QUERY,
 BPF_RAW_TRACEPOINT_OPEN,
 BPF_BTF_LOAD,
 BPF_BTF_GET_FD_BY_ID,
 BPF_TASK_FD_QUERY,
 BPF_MAP_LOOKUP_AND_DELETE_ELEM,
 BPF_MAP_FREEZE,
 BPF_BTF_GET_NEXT_ID,
 BPF_MAP_LOOKUP_BATCH,
 BPF_MAP_LOOKUP_AND_DELETE_BATCH,
 BPF_MAP_UPDATE_BATCH,
 BPF_MAP_DELETE_BATCH,
 BPF_LINK_CREATE,
 BPF_LINK_UPDATE,
 BPF_LINK_GET_FD_BY_ID,
 BPF_LINK_GET_NEXT_ID,
 BPF_ENABLE_STATS,
 BPF_ITER_CREATE,
 BPF_LINK_DETACH,
 BPF_PROG_BIND_MAP,
 BPF_TOKEN_CREATE,
 BPF_PROG_STREAM_READ_BY_FD,
 BPF_PROG_ASSOC_STRUCT_OPS,
 __MAX_BPF_CMD,
 BPF_COMMON_ATTRS = 1 << 16,
};

enum bpf_map_type {
 BPF_MAP_TYPE_UNSPEC,
 BPF_MAP_TYPE_HASH,
 BPF_MAP_TYPE_ARRAY,
 BPF_MAP_TYPE_PROG_ARRAY,
 BPF_MAP_TYPE_PERF_EVENT_ARRAY,
 BPF_MAP_TYPE_PERCPU_HASH,
 BPF_MAP_TYPE_PERCPU_ARRAY,
 BPF_MAP_TYPE_STACK_TRACE,
 BPF_MAP_TYPE_CGROUP_ARRAY,
 BPF_MAP_TYPE_LRU_HASH,
 BPF_MAP_TYPE_LRU_PERCPU_HASH,
 BPF_MAP_TYPE_LPM_TRIE,
 BPF_MAP_TYPE_ARRAY_OF_MAPS,
 BPF_MAP_TYPE_HASH_OF_MAPS,
 BPF_MAP_TYPE_DEVMAP,
 BPF_MAP_TYPE_SOCKMAP,
 BPF_MAP_TYPE_CPUMAP,
 BPF_MAP_TYPE_XSKMAP,
 BPF_MAP_TYPE_SOCKHASH,
 BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_CGROUP_STORAGE = BPF_MAP_TYPE_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_REUSEPORT_SOCKARRAY,
 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,






 BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE = BPF_MAP_TYPE_PERCPU_CGROUP_STORAGE_DEPRECATED,
 BPF_MAP_TYPE_QUEUE,
 BPF_MAP_TYPE_STACK,
 BPF_MAP_TYPE_SK_STORAGE,
 BPF_MAP_TYPE_DEVMAP_HASH,
 BPF_MAP_TYPE_STRUCT_OPS,
 BPF_MAP_TYPE_RINGBUF,
 BPF_MAP_TYPE_INODE_STORAGE,
 BPF_MAP_TYPE_TASK_STORAGE,
 BPF_MAP_TYPE_BLOOM_FILTER,
 BPF_MAP_TYPE_USER_RINGBUF,
 BPF_MAP_TYPE_CGRP_STORAGE,
 BPF_MAP_TYPE_ARENA,
 BPF_MAP_TYPE_INSN_ARRAY,
 __MAX_BPF_MAP_TYPE
};
# 1061 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_prog_type {
 BPF_PROG_TYPE_UNSPEC,
 BPF_PROG_TYPE_SOCKET_FILTER,
 BPF_PROG_TYPE_KPROBE,
 BPF_PROG_TYPE_SCHED_CLS,
 BPF_PROG_TYPE_SCHED_ACT,
 BPF_PROG_TYPE_TRACEPOINT,
 BPF_PROG_TYPE_XDP,
 BPF_PROG_TYPE_PERF_EVENT,
 BPF_PROG_TYPE_CGROUP_SKB,
 BPF_PROG_TYPE_CGROUP_SOCK,
 BPF_PROG_TYPE_LWT_IN,
 BPF_PROG_TYPE_LWT_OUT,
 BPF_PROG_TYPE_LWT_XMIT,
 BPF_PROG_TYPE_SOCK_OPS,
 BPF_PROG_TYPE_SK_SKB,
 BPF_PROG_TYPE_CGROUP_DEVICE,
 BPF_PROG_TYPE_SK_MSG,
 BPF_PROG_TYPE_RAW_TRACEPOINT,
 BPF_PROG_TYPE_CGROUP_SOCK_ADDR,
 BPF_PROG_TYPE_LWT_SEG6LOCAL,
 BPF_PROG_TYPE_LIRC_MODE2,
 BPF_PROG_TYPE_SK_REUSEPORT,
 BPF_PROG_TYPE_FLOW_DISSECTOR,
 BPF_PROG_TYPE_CGROUP_SYSCTL,
 BPF_PROG_TYPE_RAW_TRACEPOINT_WRITABLE,
 BPF_PROG_TYPE_CGROUP_SOCKOPT,
 BPF_PROG_TYPE_TRACING,
 BPF_PROG_TYPE_STRUCT_OPS,
 BPF_PROG_TYPE_EXT,
 BPF_PROG_TYPE_LSM,
 BPF_PROG_TYPE_SK_LOOKUP,
 BPF_PROG_TYPE_SYSCALL,
 BPF_PROG_TYPE_NETFILTER,
 __MAX_BPF_PROG_TYPE
};

enum bpf_attach_type {
 BPF_CGROUP_INET_INGRESS,
 BPF_CGROUP_INET_EGRESS,
 BPF_CGROUP_INET_SOCK_CREATE,
 BPF_CGROUP_SOCK_OPS,
 BPF_SK_SKB_STREAM_PARSER,
 BPF_SK_SKB_STREAM_VERDICT,
 BPF_CGROUP_DEVICE,
 BPF_SK_MSG_VERDICT,
 BPF_CGROUP_INET4_BIND,
 BPF_CGROUP_INET6_BIND,
 BPF_CGROUP_INET4_CONNECT,
 BPF_CGROUP_INET6_CONNECT,
 BPF_CGROUP_INET4_POST_BIND,
 BPF_CGROUP_INET6_POST_BIND,
 BPF_CGROUP_UDP4_SENDMSG,
 BPF_CGROUP_UDP6_SENDMSG,
 BPF_LIRC_MODE2,
 BPF_FLOW_DISSECTOR,
 BPF_CGROUP_SYSCTL,
 BPF_CGROUP_UDP4_RECVMSG,
 BPF_CGROUP_UDP6_RECVMSG,
 BPF_CGROUP_GETSOCKOPT,
 BPF_CGROUP_SETSOCKOPT,
 BPF_TRACE_RAW_TP,
 BPF_TRACE_FENTRY,
 BPF_TRACE_FEXIT,
 BPF_MODIFY_RETURN,
 BPF_LSM_MAC,
 BPF_TRACE_ITER,
 BPF_CGROUP_INET4_GETPEERNAME,
 BPF_CGROUP_INET6_GETPEERNAME,
 BPF_CGROUP_INET4_GETSOCKNAME,
 BPF_CGROUP_INET6_GETSOCKNAME,
 BPF_XDP_DEVMAP,
 BPF_CGROUP_INET_SOCK_RELEASE,
 BPF_XDP_CPUMAP,
 BPF_SK_LOOKUP,
 BPF_XDP,
 BPF_SK_SKB_VERDICT,
 BPF_SK_REUSEPORT_SELECT,
 BPF_SK_REUSEPORT_SELECT_OR_MIGRATE,
 BPF_PERF_EVENT,
 BPF_TRACE_KPROBE_MULTI,
 BPF_LSM_CGROUP,
 BPF_STRUCT_OPS,
 BPF_NETFILTER,
 BPF_TCX_INGRESS,
 BPF_TCX_EGRESS,
 BPF_TRACE_UPROBE_MULTI,
 BPF_CGROUP_UNIX_CONNECT,
 BPF_CGROUP_UNIX_SENDMSG,
 BPF_CGROUP_UNIX_RECVMSG,
 BPF_CGROUP_UNIX_GETPEERNAME,
 BPF_CGROUP_UNIX_GETSOCKNAME,
 BPF_NETKIT_PRIMARY,
 BPF_NETKIT_PEER,
 BPF_TRACE_KPROBE_SESSION,
 BPF_TRACE_UPROBE_SESSION,
 BPF_TRACE_FSESSION,
 __MAX_BPF_ATTACH_TYPE
};






enum bpf_link_type {
 BPF_LINK_TYPE_UNSPEC = 0,
 BPF_LINK_TYPE_RAW_TRACEPOINT = 1,
 BPF_LINK_TYPE_TRACING = 2,
 BPF_LINK_TYPE_CGROUP = 3,
 BPF_LINK_TYPE_ITER = 4,
 BPF_LINK_TYPE_NETNS = 5,
 BPF_LINK_TYPE_XDP = 6,
 BPF_LINK_TYPE_PERF_EVENT = 7,
 BPF_LINK_TYPE_KPROBE_MULTI = 8,
 BPF_LINK_TYPE_STRUCT_OPS = 9,
 BPF_LINK_TYPE_NETFILTER = 10,
 BPF_LINK_TYPE_TCX = 11,
 BPF_LINK_TYPE_UPROBE_MULTI = 12,
 BPF_LINK_TYPE_NETKIT = 13,
 BPF_LINK_TYPE_SOCKMAP = 14,
 __MAX_BPF_LINK_TYPE,
};



enum bpf_perf_event_type {
 BPF_PERF_EVENT_UNSPEC = 0,
 BPF_PERF_EVENT_UPROBE = 1,
 BPF_PERF_EVENT_URETPROBE = 2,
 BPF_PERF_EVENT_KPROBE = 3,
 BPF_PERF_EVENT_KRETPROBE = 4,
 BPF_PERF_EVENT_TRACEPOINT = 5,
 BPF_PERF_EVENT_EVENT = 6,
};
# 1317 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum {
 BPF_F_KPROBE_MULTI_RETURN = (1U << 0)
};




enum {
 BPF_F_UPROBE_MULTI_RETURN = (1U << 0)
};
# 1387 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_addr_space_cast {
 BPF_ADDR_SPACE_CAST = 1,
};


enum {
 BPF_ANY = 0,
 BPF_NOEXIST = 1,
 BPF_EXIST = 2,
 BPF_F_LOCK = 4,
 BPF_F_CPU = 8,
 BPF_F_ALL_CPUS = 16,
};


enum {
 BPF_F_NO_PREALLOC = (1U << 0),






 BPF_F_NO_COMMON_LRU = (1U << 1),

 BPF_F_NUMA_NODE = (1U << 2),


 BPF_F_RDONLY = (1U << 3),
 BPF_F_WRONLY = (1U << 4),


 BPF_F_STACK_BUILD_ID = (1U << 5),


 BPF_F_ZERO_SEED = (1U << 6),


 BPF_F_RDONLY_PROG = (1U << 7),
 BPF_F_WRONLY_PROG = (1U << 8),


 BPF_F_CLONE = (1U << 9),


 BPF_F_MMAPABLE = (1U << 10),


 BPF_F_PRESERVE_ELEMS = (1U << 11),


 BPF_F_INNER_MAP = (1U << 12),


 BPF_F_LINK = (1U << 13),


 BPF_F_PATH_FD = (1U << 14),


 BPF_F_VTYPE_BTF_OBJ_FD = (1U << 15),


 BPF_F_TOKEN_FD = (1U << 16),


 BPF_F_SEGV_ON_FAULT = (1U << 17),


 BPF_F_NO_USER_CONV = (1U << 18),


 BPF_F_RB_OVERWRITE = (1U << 19),
};
# 1480 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_stats_type {

 BPF_STATS_RUN_TIME = 0,
};

enum bpf_stack_build_id_status {

 BPF_STACK_BUILD_ID_EMPTY = 0,

 BPF_STACK_BUILD_ID_VALID = 1,

 BPF_STACK_BUILD_ID_IP = 2,
};


struct bpf_stack_build_id {
 __s32 status;
 unsigned char build_id[20];
 union {
  __u64 offset;
  __u64 ip;
 };
};

struct bpf_common_attr {
 __u64 __attribute__((aligned(8))) log_buf;
 __u32 log_size;
 __u32 log_level;
 __u32 log_true_size;
};



enum {
 BPF_STREAM_STDOUT = 1,
 BPF_STREAM_STDERR = 2,
};

union bpf_attr {
 struct {
  __u32 map_type;
  __u32 key_size;
  __u32 value_size;
  __u32 max_entries;
  __u32 map_flags;


  __u32 inner_map_fd;
  __u32 numa_node;


  char map_name[16U];
  __u32 map_ifindex;
  __u32 btf_fd;
  __u32 btf_key_type_id;
  __u32 btf_value_type_id;
  __u32 btf_vmlinux_value_type_id;
# 1549 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
  __u64 map_extra;

  __s32 value_type_btf_obj_fd;






  __s32 map_token_fd;



  __u64 __attribute__((aligned(8))) excl_prog_hash;

  __u32 excl_prog_hash_size;
 };

 struct {
  __u32 map_fd;
  __u64 __attribute__((aligned(8))) key;
  union {
   __u64 __attribute__((aligned(8))) value;
   __u64 __attribute__((aligned(8))) next_key;
  };
  __u64 flags;
 };

 struct {
  __u64 __attribute__((aligned(8))) in_batch;


  __u64 __attribute__((aligned(8))) out_batch;
  __u64 __attribute__((aligned(8))) keys;
  __u64 __attribute__((aligned(8))) values;
  __u32 count;




  __u32 map_fd;
  __u64 elem_flags;
  __u64 flags;
 } batch;

 struct {
  __u32 prog_type;
  __u32 insn_cnt;
  __u64 __attribute__((aligned(8))) insns;
  __u64 __attribute__((aligned(8))) license;
  __u32 log_level;
  __u32 log_size;
  __u64 __attribute__((aligned(8))) log_buf;
  __u32 kern_version;
  __u32 prog_flags;
  char prog_name[16U];
  __u32 prog_ifindex;




  __u32 expected_attach_type;
  __u32 prog_btf_fd;
  __u32 func_info_rec_size;
  __u64 __attribute__((aligned(8))) func_info;
  __u32 func_info_cnt;
  __u32 line_info_rec_size;
  __u64 __attribute__((aligned(8))) line_info;
  __u32 line_info_cnt;
  __u32 attach_btf_id;
  union {

   __u32 attach_prog_fd;

   __u32 attach_btf_obj_fd;
  };
  __u32 core_relo_cnt;
  __u64 __attribute__((aligned(8))) fd_array;
  __u64 __attribute__((aligned(8))) core_relos;
  __u32 core_relo_rec_size;




  __u32 log_true_size;



  __s32 prog_token_fd;
# 1647 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
  __u32 fd_array_cnt;



  __u64 __attribute__((aligned(8))) signature;

  __u32 signature_size;



  __s32 keyring_id;
 };

 struct {
  __u64 __attribute__((aligned(8))) pathname;
  __u32 bpf_fd;
  __u32 file_flags;






  __s32 path_fd;
 };

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_bpf_fd;
  __u32 attach_type;
  __u32 attach_flags;
  __u32 replace_bpf_fd;
  union {
   __u32 relative_fd;
   __u32 relative_id;
  };
  __u64 expected_revision;
 };

 struct {
  __u32 prog_fd;
  __u32 retval;
  __u32 data_size_in;
  __u32 data_size_out;



  __u64 __attribute__((aligned(8))) data_in;
  __u64 __attribute__((aligned(8))) data_out;
  __u32 repeat;
  __u32 duration;
  __u32 ctx_size_in;
  __u32 ctx_size_out;



  __u64 __attribute__((aligned(8))) ctx_in;
  __u64 __attribute__((aligned(8))) ctx_out;
  __u32 flags;
  __u32 cpu;
  __u32 batch_size;
 } test;

 struct {
  union {
   __u32 start_id;
   __u32 prog_id;
   __u32 map_id;
   __u32 btf_id;
   __u32 link_id;
  };
  __u32 next_id;
  __u32 open_flags;
  __s32 fd_by_id_token_fd;
 };

 struct {
  __u32 bpf_fd;
  __u32 info_len;
  __u64 __attribute__((aligned(8))) info;
 } info;

 struct {
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 query_flags;
  __u32 attach_flags;
  __u64 __attribute__((aligned(8))) prog_ids;
  union {
   __u32 prog_cnt;
   __u32 count;
  };
  __u32 :32;



  __u64 __attribute__((aligned(8))) prog_attach_flags;
  __u64 __attribute__((aligned(8))) link_ids;
  __u64 __attribute__((aligned(8))) link_attach_flags;
  __u64 revision;
 } query;

 struct {
  __u64 name;
  __u32 prog_fd;
  __u32 :32;
  __u64 __attribute__((aligned(8))) cookie;
 } raw_tracepoint;

 struct {
  __u64 __attribute__((aligned(8))) btf;
  __u64 __attribute__((aligned(8))) btf_log_buf;
  __u32 btf_size;
  __u32 btf_log_size;
  __u32 btf_log_level;




  __u32 btf_log_true_size;
  __u32 btf_flags;



  __s32 btf_token_fd;
 };

 struct {
  __u32 pid;
  __u32 fd;
  __u32 flags;
  __u32 buf_len;
  __u64 __attribute__((aligned(8))) buf;




  __u32 prog_id;
  __u32 fd_type;
  __u64 probe_offset;
  __u64 probe_addr;
 } task_fd_query;

 struct {
  union {
   __u32 prog_fd;
   __u32 map_fd;
  };
  union {
   __u32 target_fd;
   __u32 target_ifindex;
  };
  __u32 attach_type;
  __u32 flags;
  union {
   __u32 target_btf_id;
   struct {
    __u64 __attribute__((aligned(8))) iter_info;
    __u32 iter_info_len;
   };
   struct {




    __u64 bpf_cookie;
   } perf_event;
   struct {
    __u32 flags;
    __u32 cnt;
    __u64 __attribute__((aligned(8))) syms;
    __u64 __attribute__((aligned(8))) addrs;
    __u64 __attribute__((aligned(8))) cookies;
   } kprobe_multi;
   struct {

    __u32 target_btf_id;




    __u64 cookie;
   } tracing;
   struct {
    __u32 pf;
    __u32 hooknum;
    __s32 priority;
    __u32 flags;
   } netfilter;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } tcx;
   struct {
    __u64 __attribute__((aligned(8))) path;
    __u64 __attribute__((aligned(8))) offsets;
    __u64 __attribute__((aligned(8))) ref_ctr_offsets;
    __u64 __attribute__((aligned(8))) cookies;
    __u32 cnt;
    __u32 flags;
    __u32 pid;
   } uprobe_multi;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } netkit;
   struct {
    union {
     __u32 relative_fd;
     __u32 relative_id;
    };
    __u64 expected_revision;
   } cgroup;
  };
 } link_create;

 struct {
  __u32 link_fd;
  union {

   __u32 new_prog_fd;

   __u32 new_map_fd;
  };
  __u32 flags;
  union {



   __u32 old_prog_fd;



   __u32 old_map_fd;
  };
 } link_update;

 struct {
  __u32 link_fd;
 } link_detach;

 struct {
  __u32 type;
 } enable_stats;

 struct {
  __u32 link_fd;
  __u32 flags;
 } iter_create;

 struct {
  __u32 prog_fd;
  __u32 map_fd;
  __u32 flags;
 } prog_bind_map;

 struct {
  __u32 flags;
  __u32 bpffs_fd;
 } token_create;

 struct {
  __u64 __attribute__((aligned(8))) stream_buf;
  __u32 stream_buf_len;
  __u32 stream_id;
  __u32 prog_fd;
 } prog_stream_read;

 struct {
  __u32 map_fd;
  __u32 prog_fd;
  __u32 flags;
 } prog_assoc_struct_ops;

} __attribute__((aligned(8)));
# 6140 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_func_id {
 BPF_FUNC_unspec = 0, BPF_FUNC_map_lookup_elem = 1, BPF_FUNC_map_update_elem = 2, BPF_FUNC_map_delete_elem = 3, BPF_FUNC_probe_read = 4, BPF_FUNC_ktime_get_ns = 5, BPF_FUNC_trace_printk = 6, BPF_FUNC_get_prandom_u32 = 7, BPF_FUNC_get_smp_processor_id = 8, BPF_FUNC_skb_store_bytes = 9, BPF_FUNC_l3_csum_replace = 10, BPF_FUNC_l4_csum_replace = 11, BPF_FUNC_tail_call = 12, BPF_FUNC_clone_redirect = 13, BPF_FUNC_get_current_pid_tgid = 14, BPF_FUNC_get_current_uid_gid = 15, BPF_FUNC_get_current_comm = 16, BPF_FUNC_get_cgroup_classid = 17, BPF_FUNC_skb_vlan_push = 18, BPF_FUNC_skb_vlan_pop = 19, BPF_FUNC_skb_get_tunnel_key = 20, BPF_FUNC_skb_set_tunnel_key = 21, BPF_FUNC_perf_event_read = 22, BPF_FUNC_redirect = 23, BPF_FUNC_get_route_realm = 24, BPF_FUNC_perf_event_output = 25, BPF_FUNC_skb_load_bytes = 26, BPF_FUNC_get_stackid = 27, BPF_FUNC_csum_diff = 28, BPF_FUNC_skb_get_tunnel_opt = 29, BPF_FUNC_skb_set_tunnel_opt = 30, BPF_FUNC_skb_change_proto = 31, BPF_FUNC_skb_change_type = 32, BPF_FUNC_skb_under_cgroup = 33, BPF_FUNC_get_hash_recalc = 34, BPF_FUNC_get_current_task = 35, BPF_FUNC_probe_write_user = 36, BPF_FUNC_current_task_under_cgroup = 37, BPF_FUNC_skb_change_tail = 38, BPF_FUNC_skb_pull_data = 39, BPF_FUNC_csum_update = 40, BPF_FUNC_set_hash_invalid = 41, BPF_FUNC_get_numa_node_id = 42, BPF_FUNC_skb_change_head = 43, BPF_FUNC_xdp_adjust_head = 44, BPF_FUNC_probe_read_str = 45, BPF_FUNC_get_socket_cookie = 46, BPF_FUNC_get_socket_uid = 47, BPF_FUNC_set_hash = 48, BPF_FUNC_setsockopt = 49, BPF_FUNC_skb_adjust_room = 50, BPF_FUNC_redirect_map = 51, BPF_FUNC_sk_redirect_map = 52, BPF_FUNC_sock_map_update = 53, BPF_FUNC_xdp_adjust_meta = 54, BPF_FUNC_perf_event_read_value = 55, BPF_FUNC_perf_prog_read_value = 56, BPF_FUNC_getsockopt = 57, BPF_FUNC_override_return = 58, BPF_FUNC_sock_ops_cb_flags_set = 59, BPF_FUNC_msg_redirect_map = 60, BPF_FUNC_msg_apply_bytes = 61, BPF_FUNC_msg_cork_bytes = 62, BPF_FUNC_msg_pull_data = 63, BPF_FUNC_bind = 64, BPF_FUNC_xdp_adjust_tail = 65, BPF_FUNC_skb_get_xfrm_state = 66, BPF_FUNC_get_stack = 67, BPF_FUNC_skb_load_bytes_relative = 68, BPF_FUNC_fib_lookup = 69, BPF_FUNC_sock_hash_update = 70, BPF_FUNC_msg_redirect_hash = 71, BPF_FUNC_sk_redirect_hash = 72, BPF_FUNC_lwt_push_encap = 73, BPF_FUNC_lwt_seg6_store_bytes = 74, BPF_FUNC_lwt_seg6_adjust_srh = 75, BPF_FUNC_lwt_seg6_action = 76, BPF_FUNC_rc_repeat = 77, BPF_FUNC_rc_keydown = 78, BPF_FUNC_skb_cgroup_id = 79, BPF_FUNC_get_current_cgroup_id = 80, BPF_FUNC_get_local_storage = 81, BPF_FUNC_sk_select_reuseport = 82, BPF_FUNC_skb_ancestor_cgroup_id = 83, BPF_FUNC_sk_lookup_tcp = 84, BPF_FUNC_sk_lookup_udp = 85, BPF_FUNC_sk_release = 86, BPF_FUNC_map_push_elem = 87, BPF_FUNC_map_pop_elem = 88, BPF_FUNC_map_peek_elem = 89, BPF_FUNC_msg_push_data = 90, BPF_FUNC_msg_pop_data = 91, BPF_FUNC_rc_pointer_rel = 92, BPF_FUNC_spin_lock = 93, BPF_FUNC_spin_unlock = 94, BPF_FUNC_sk_fullsock = 95, BPF_FUNC_tcp_sock = 96, BPF_FUNC_skb_ecn_set_ce = 97, BPF_FUNC_get_listener_sock = 98, BPF_FUNC_skc_lookup_tcp = 99, BPF_FUNC_tcp_check_syncookie = 100, BPF_FUNC_sysctl_get_name = 101, BPF_FUNC_sysctl_get_current_value = 102, BPF_FUNC_sysctl_get_new_value = 103, BPF_FUNC_sysctl_set_new_value = 104, BPF_FUNC_strtol = 105, BPF_FUNC_strtoul = 106, BPF_FUNC_sk_storage_get = 107, BPF_FUNC_sk_storage_delete = 108, BPF_FUNC_send_signal = 109, BPF_FUNC_tcp_gen_syncookie = 110, BPF_FUNC_skb_output = 111, BPF_FUNC_probe_read_user = 112, BPF_FUNC_probe_read_kernel = 113, BPF_FUNC_probe_read_user_str = 114, BPF_FUNC_probe_read_kernel_str = 115, BPF_FUNC_tcp_send_ack = 116, BPF_FUNC_send_signal_thread = 117, BPF_FUNC_jiffies64 = 118, BPF_FUNC_read_branch_records = 119, BPF_FUNC_get_ns_current_pid_tgid = 120, BPF_FUNC_xdp_output = 121, BPF_FUNC_get_netns_cookie = 122, BPF_FUNC_get_current_ancestor_cgroup_id = 123, BPF_FUNC_sk_assign = 124, BPF_FUNC_ktime_get_boot_ns = 125, BPF_FUNC_seq_printf = 126, BPF_FUNC_seq_write = 127, BPF_FUNC_sk_cgroup_id = 128, BPF_FUNC_sk_ancestor_cgroup_id = 129, BPF_FUNC_ringbuf_output = 130, BPF_FUNC_ringbuf_reserve = 131, BPF_FUNC_ringbuf_submit = 132, BPF_FUNC_ringbuf_discard = 133, BPF_FUNC_ringbuf_query = 134, BPF_FUNC_csum_level = 135, BPF_FUNC_skc_to_tcp6_sock = 136, BPF_FUNC_skc_to_tcp_sock = 137, BPF_FUNC_skc_to_tcp_timewait_sock = 138, BPF_FUNC_skc_to_tcp_request_sock = 139, BPF_FUNC_skc_to_udp6_sock = 140, BPF_FUNC_get_task_stack = 141, BPF_FUNC_load_hdr_opt = 142, BPF_FUNC_store_hdr_opt = 143, BPF_FUNC_reserve_hdr_opt = 144, BPF_FUNC_inode_storage_get = 145, BPF_FUNC_inode_storage_delete = 146, BPF_FUNC_d_path = 147, BPF_FUNC_copy_from_user = 148, BPF_FUNC_snprintf_btf = 149, BPF_FUNC_seq_printf_btf = 150, BPF_FUNC_skb_cgroup_classid = 151, BPF_FUNC_redirect_neigh = 152, BPF_FUNC_per_cpu_ptr = 153, BPF_FUNC_this_cpu_ptr = 154, BPF_FUNC_redirect_peer = 155, BPF_FUNC_task_storage_get = 156, BPF_FUNC_task_storage_delete = 157, BPF_FUNC_get_current_task_btf = 158, BPF_FUNC_bprm_opts_set = 159, BPF_FUNC_ktime_get_coarse_ns = 160, BPF_FUNC_ima_inode_hash = 161, BPF_FUNC_sock_from_file = 162, BPF_FUNC_check_mtu = 163, BPF_FUNC_for_each_map_elem = 164, BPF_FUNC_snprintf = 165, BPF_FUNC_sys_bpf = 166, BPF_FUNC_btf_find_by_name_kind = 167, BPF_FUNC_sys_close = 168, BPF_FUNC_timer_init = 169, BPF_FUNC_timer_set_callback = 170, BPF_FUNC_timer_start = 171, BPF_FUNC_timer_cancel = 172, BPF_FUNC_get_func_ip = 173, BPF_FUNC_get_attach_cookie = 174, BPF_FUNC_task_pt_regs = 175, BPF_FUNC_get_branch_snapshot = 176, BPF_FUNC_trace_vprintk = 177, BPF_FUNC_skc_to_unix_sock = 178, BPF_FUNC_kallsyms_lookup_name = 179, BPF_FUNC_find_vma = 180, BPF_FUNC_loop = 181, BPF_FUNC_strncmp = 182, BPF_FUNC_get_func_arg = 183, BPF_FUNC_get_func_ret = 184, BPF_FUNC_get_func_arg_cnt = 185, BPF_FUNC_get_retval = 186, BPF_FUNC_set_retval = 187, BPF_FUNC_xdp_get_buff_len = 188, BPF_FUNC_xdp_load_bytes = 189, BPF_FUNC_xdp_store_bytes = 190, BPF_FUNC_copy_from_user_task = 191, BPF_FUNC_skb_set_tstamp = 192, BPF_FUNC_ima_file_hash = 193, BPF_FUNC_kptr_xchg = 194, BPF_FUNC_map_lookup_percpu_elem = 195, BPF_FUNC_skc_to_mptcp_sock = 196, BPF_FUNC_dynptr_from_mem = 197, BPF_FUNC_ringbuf_reserve_dynptr = 198, BPF_FUNC_ringbuf_submit_dynptr = 199, BPF_FUNC_ringbuf_discard_dynptr = 200, BPF_FUNC_dynptr_read = 201, BPF_FUNC_dynptr_write = 202, BPF_FUNC_dynptr_data = 203, BPF_FUNC_tcp_raw_gen_syncookie_ipv4 = 204, BPF_FUNC_tcp_raw_gen_syncookie_ipv6 = 205, BPF_FUNC_tcp_raw_check_syncookie_ipv4 = 206, BPF_FUNC_tcp_raw_check_syncookie_ipv6 = 207, BPF_FUNC_ktime_get_tai_ns = 208, BPF_FUNC_user_ringbuf_drain = 209, BPF_FUNC_cgrp_storage_get = 210, BPF_FUNC_cgrp_storage_delete = 211,
 __BPF_FUNC_MAX_ID,
};





enum {
 BPF_F_RECOMPUTE_CSUM = (1ULL << 0),
 BPF_F_INVALIDATE_HASH = (1ULL << 1),
};




enum {
 BPF_F_HDR_FIELD_MASK = 0xfULL,
};


enum {
 BPF_F_PSEUDO_HDR = (1ULL << 4),
 BPF_F_MARK_MANGLED_0 = (1ULL << 5),
 BPF_F_MARK_ENFORCE = (1ULL << 6),
 BPF_F_IPV6 = (1ULL << 7),
};


enum {
 BPF_F_TUNINFO_IPV6 = (1ULL << 0),
};


enum {
 BPF_F_SKIP_FIELD_MASK = 0xffULL,
 BPF_F_USER_STACK = (1ULL << 8),

 BPF_F_FAST_STACK_CMP = (1ULL << 9),
 BPF_F_REUSE_STACKID = (1ULL << 10),

 BPF_F_USER_BUILD_ID = (1ULL << 11),
};


enum {
 BPF_F_ZERO_CSUM_TX = (1ULL << 1),
 BPF_F_DONT_FRAGMENT = (1ULL << 2),
 BPF_F_SEQ_NUMBER = (1ULL << 3),
 BPF_F_NO_TUNNEL_KEY = (1ULL << 4),
};


enum {
 BPF_F_TUNINFO_FLAGS = (1ULL << 4),
};




enum {
 BPF_F_INDEX_MASK = 0xffffffffULL,
 BPF_F_CURRENT_CPU = BPF_F_INDEX_MASK,

 BPF_F_CTXLEN_MASK = (0xfffffULL << 32),
};


enum {
 BPF_F_CURRENT_NETNS = (-1L),
};


enum {
 BPF_CSUM_LEVEL_QUERY,
 BPF_CSUM_LEVEL_INC,
 BPF_CSUM_LEVEL_DEC,
 BPF_CSUM_LEVEL_RESET,
};


enum {
 BPF_F_ADJ_ROOM_FIXED_GSO = (1ULL << 0),
 BPF_F_ADJ_ROOM_ENCAP_L3_IPV4 = (1ULL << 1),
 BPF_F_ADJ_ROOM_ENCAP_L3_IPV6 = (1ULL << 2),
 BPF_F_ADJ_ROOM_ENCAP_L4_GRE = (1ULL << 3),
 BPF_F_ADJ_ROOM_ENCAP_L4_UDP = (1ULL << 4),
 BPF_F_ADJ_ROOM_NO_CSUM_RESET = (1ULL << 5),
 BPF_F_ADJ_ROOM_ENCAP_L2_ETH = (1ULL << 6),
 BPF_F_ADJ_ROOM_DECAP_L3_IPV4 = (1ULL << 7),
 BPF_F_ADJ_ROOM_DECAP_L3_IPV6 = (1ULL << 8),
};

enum {
 BPF_ADJ_ROOM_ENCAP_L2_MASK = 0xff,
 BPF_ADJ_ROOM_ENCAP_L2_SHIFT = 56,
};






enum {
 BPF_F_SYSCTL_BASE_NAME = (1ULL << 0),
};


enum {
 BPF_LOCAL_STORAGE_GET_F_CREATE = (1ULL << 0),



 BPF_SK_STORAGE_GET_F_CREATE = BPF_LOCAL_STORAGE_GET_F_CREATE,
};


enum {
 BPF_F_GET_BRANCH_RECORDS_SIZE = (1ULL << 0),
};




enum {
 BPF_RB_NO_WAKEUP = (1ULL << 0),
 BPF_RB_FORCE_WAKEUP = (1ULL << 1),
};


enum {
 BPF_RB_AVAIL_DATA = 0,
 BPF_RB_RING_SIZE = 1,
 BPF_RB_CONS_POS = 2,
 BPF_RB_PROD_POS = 3,
 BPF_RB_OVERWRITE_POS = 4,
};


enum {
 BPF_RINGBUF_BUSY_BIT = (1U << 31),
 BPF_RINGBUF_DISCARD_BIT = (1U << 30),
 BPF_RINGBUF_HDR_SZ = 8,
};


enum {
 BPF_SK_LOOKUP_F_REPLACE = (1ULL << 0),
 BPF_SK_LOOKUP_F_NO_REUSEPORT = (1ULL << 1),
};


enum bpf_adj_room_mode {
 BPF_ADJ_ROOM_NET,
 BPF_ADJ_ROOM_MAC,
};


enum bpf_hdr_start_off {
 BPF_HDR_START_MAC,
 BPF_HDR_START_NET,
};


enum bpf_lwt_encap_mode {
 BPF_LWT_ENCAP_SEG6,
 BPF_LWT_ENCAP_SEG6_INLINE,
 BPF_LWT_ENCAP_IP,
};


enum {
 BPF_F_BPRM_SECUREEXEC = (1ULL << 0),
};


enum {
 BPF_F_INGRESS = (1ULL << 0),
 BPF_F_BROADCAST = (1ULL << 3),
 BPF_F_EXCLUDE_INGRESS = (1ULL << 4),

};
# 6333 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum {
 BPF_SKB_TSTAMP_UNSPEC = 0,
 BPF_SKB_TSTAMP_DELIVERY_MONO = 1,
 BPF_SKB_CLOCK_REALTIME = 0,
 BPF_SKB_CLOCK_MONOTONIC = 1,
 BPF_SKB_CLOCK_TAI = 2,



};




struct __sk_buff {
 __u32 len;
 __u32 pkt_type;
 __u32 mark;
 __u32 queue_mapping;
 __u32 protocol;
 __u32 vlan_present;
 __u32 vlan_tci;
 __u32 vlan_proto;
 __u32 priority;
 __u32 ingress_ifindex;
 __u32 ifindex;
 __u32 tc_index;
 __u32 cb[5];
 __u32 hash;
 __u32 tc_classid;
 __u32 data;
 __u32 data_end;
 __u32 napi_id;


 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;


 __u32 data_meta;
 union { struct bpf_flow_keys * flow_keys; __u64 :64; } __attribute__((aligned(8)));
 __u64 tstamp;
 __u32 wire_len;
 __u32 gso_segs;
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
 __u32 gso_size;
 __u8 tstamp_type;
 __u32 :24;
 __u64 hwtstamp;
};

struct bpf_tunnel_key {
 __u32 tunnel_id;
 union {
  __u32 remote_ipv4;
  __u32 remote_ipv6[4];
 };
 __u8 tunnel_tos;
 __u8 tunnel_ttl;
 union {
  __u16 tunnel_ext;
  __be16 tunnel_flags;
 };
 __u32 tunnel_label;
 union {
  __u32 local_ipv4;
  __u32 local_ipv6[4];
 };
};




struct bpf_xfrm_state {
 __u32 reqid;
 __u32 spi;
 __u16 family;
 __u16 ext;
 union {
  __u32 remote_ipv4;
  __u32 remote_ipv6[4];
 };
};
# 6429 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum bpf_ret_code {
 BPF_OK = 0,

 BPF_DROP = 2,

 BPF_REDIRECT = 7,
# 6443 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_LWT_REROUTE = 128,




 BPF_FLOW_DISSECTOR_CONTINUE = 129,
};

struct bpf_sock {
 __u32 bound_dev_if;
 __u32 family;
 __u32 type;
 __u32 protocol;
 __u32 mark;
 __u32 priority;

 __u32 src_ip4;
 __u32 src_ip6[4];
 __u32 src_port;
 __be16 dst_port;
 __u16 :16;
 __u32 dst_ip4;
 __u32 dst_ip6[4];
 __u32 state;
 __s32 rx_queue_mapping;
};

struct bpf_tcp_sock {
 __u32 snd_cwnd;
 __u32 srtt_us;
 __u32 rtt_min;
 __u32 snd_ssthresh;
 __u32 rcv_nxt;
 __u32 snd_nxt;
 __u32 snd_una;
 __u32 mss_cache;
 __u32 ecn_flags;
 __u32 rate_delivered;
 __u32 rate_interval_us;
 __u32 packets_out;
 __u32 retrans_out;
 __u32 total_retrans;
 __u32 segs_in;


 __u32 data_segs_in;


 __u32 segs_out;


 __u32 data_segs_out;


 __u32 lost_out;
 __u32 sacked_out;
 __u64 bytes_received;



 __u64 bytes_acked;



 __u32 dsack_dups;


 __u32 delivered;
 __u32 delivered_ce;
 __u32 icsk_retransmits;
};

struct bpf_sock_tuple {
 union {
  struct {
   __be32 saddr;
   __be32 daddr;
   __be16 sport;
   __be16 dport;
  } ipv4;
  struct {
   __be32 saddr[4];
   __be32 daddr[4];
   __be16 sport;
   __be16 dport;
  } ipv6;
 };
};







enum tcx_action_base {
 TCX_NEXT = -1,
 TCX_PASS = 0,
 TCX_DROP = 2,
 TCX_REDIRECT = 7,
};

struct bpf_xdp_sock {
 __u32 queue_id;
};
# 6556 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum xdp_action {
 XDP_ABORTED = 0,
 XDP_DROP,
 XDP_PASS,
 XDP_TX,
 XDP_REDIRECT,
};




struct xdp_md {
 __u32 data;
 __u32 data_end;
 __u32 data_meta;

 __u32 ingress_ifindex;
 __u32 rx_queue_index;

 __u32 egress_ifindex;
};






struct bpf_devmap_val {
 __u32 ifindex;
 union {
  int fd;
  __u32 id;
 } bpf_prog;
};






struct bpf_cpumap_val {
 __u32 qsize;
 union {
  int fd;
  __u32 id;
 } bpf_prog;
};

enum sk_action {
 SK_DROP = 0,
 SK_PASS,
};




struct sk_msg_md {
 union { void * data; __u64 :64; } __attribute__((aligned(8)));
 union { void * data_end; __u64 :64; } __attribute__((aligned(8)));

 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;
 __u32 size;

 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
};

struct sk_reuseport_md {




 union { void * data; __u64 :64; } __attribute__((aligned(8)));

 union { void * data_end; __u64 :64; } __attribute__((aligned(8)));






 __u32 len;




 __u32 eth_protocol;
 __u32 ip_protocol;
 __u32 bind_inany;
 __u32 hash;
# 6663 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
 union { struct bpf_sock * migrating_sk; __u64 :64; } __attribute__((aligned(8)));
};



struct bpf_prog_info {
 __u32 type;
 __u32 id;
 __u8 tag[8];
 __u32 jited_prog_len;
 __u32 xlated_prog_len;
 __u64 __attribute__((aligned(8))) jited_prog_insns;
 __u64 __attribute__((aligned(8))) xlated_prog_insns;
 __u64 load_time;
 __u32 created_by_uid;
 __u32 nr_map_ids;
 __u64 __attribute__((aligned(8))) map_ids;
 char name[16U];
 __u32 ifindex;
 __u32 gpl_compatible:1;
 __u32 :31;
 __u64 netns_dev;
 __u64 netns_ino;
 __u32 nr_jited_ksyms;
 __u32 nr_jited_func_lens;
 __u64 __attribute__((aligned(8))) jited_ksyms;
 __u64 __attribute__((aligned(8))) jited_func_lens;
 __u32 btf_id;
 __u32 func_info_rec_size;
 __u64 __attribute__((aligned(8))) func_info;
 __u32 nr_func_info;
 __u32 nr_line_info;
 __u64 __attribute__((aligned(8))) line_info;
 __u64 __attribute__((aligned(8))) jited_line_info;
 __u32 nr_jited_line_info;
 __u32 line_info_rec_size;
 __u32 jited_line_info_rec_size;
 __u32 nr_prog_tags;
 __u64 __attribute__((aligned(8))) prog_tags;
 __u64 run_time_ns;
 __u64 run_cnt;
 __u64 recursion_misses;
 __u32 verified_insns;
 __u32 attach_btf_obj_id;
 __u32 attach_btf_id;
} __attribute__((aligned(8)));

struct bpf_map_info {
 __u32 type;
 __u32 id;
 __u32 key_size;
 __u32 value_size;
 __u32 max_entries;
 __u32 map_flags;
 char name[16U];
 __u32 ifindex;
 __u32 btf_vmlinux_value_type_id;
 __u64 netns_dev;
 __u64 netns_ino;
 __u32 btf_id;
 __u32 btf_key_type_id;
 __u32 btf_value_type_id;
 __u32 btf_vmlinux_id;
 __u64 map_extra;
 __u64 __attribute__((aligned(8))) hash;
 __u32 hash_size;
} __attribute__((aligned(8)));

struct bpf_btf_info {
 __u64 __attribute__((aligned(8))) btf;
 __u32 btf_size;
 __u32 id;
 __u64 __attribute__((aligned(8))) name;
 __u32 name_len;
 __u32 kernel_btf;
} __attribute__((aligned(8)));

struct bpf_link_info {
 __u32 type;
 __u32 id;
 __u32 prog_id;
 union {
  struct {
   __u64 __attribute__((aligned(8))) tp_name;
   __u32 tp_name_len;
   __u32 :32;
   __u64 cookie;
  } raw_tracepoint;
  struct {
   __u32 attach_type;
   __u32 target_obj_id;
   __u32 target_btf_id;
   __u32 :32;
   __u64 cookie;
  } tracing;
  struct {
   __u64 cgroup_id;
   __u32 attach_type;
  } cgroup;
  struct {
   __u64 __attribute__((aligned(8))) target_name;
   __u32 target_name_len;





   union {
    struct {
     __u32 map_id;
    } map;
   };
   union {
    struct {
     __u64 cgroup_id;
     __u32 order;
    } cgroup;
    struct {
     __u32 tid;
     __u32 pid;
    } task;
   };
  } iter;
  struct {
   __u32 netns_ino;
   __u32 attach_type;
  } netns;
  struct {
   __u32 ifindex;
  } xdp;
  struct {
   __u32 map_id;
  } struct_ops;
  struct {
   __u32 pf;
   __u32 hooknum;
   __s32 priority;
   __u32 flags;
  } netfilter;
  struct {
   __u64 __attribute__((aligned(8))) addrs;
   __u32 count;
   __u32 flags;
   __u64 missed;
   __u64 __attribute__((aligned(8))) cookies;
  } kprobe_multi;
  struct {
   __u64 __attribute__((aligned(8))) path;
   __u64 __attribute__((aligned(8))) offsets;
   __u64 __attribute__((aligned(8))) ref_ctr_offsets;
   __u64 __attribute__((aligned(8))) cookies;
   __u32 path_size;
   __u32 count;
   __u32 flags;
   __u32 pid;
  } uprobe_multi;
  struct {
   __u32 type;
   __u32 :32;
   union {
    struct {
     __u64 __attribute__((aligned(8))) file_name;
     __u32 name_len;
     __u32 offset;
     __u64 cookie;
     __u64 ref_ctr_offset;
    } uprobe;
    struct {
     __u64 __attribute__((aligned(8))) func_name;
     __u32 name_len;
     __u32 offset;
     __u64 addr;
     __u64 missed;
     __u64 cookie;
    } kprobe;
    struct {
     __u64 __attribute__((aligned(8))) tp_name;
     __u32 name_len;
     __u32 :32;
     __u64 cookie;
    } tracepoint;
    struct {
     __u64 config;
     __u32 type;
     __u32 :32;
     __u64 cookie;
    } event;
   };
  } perf_event;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } tcx;
  struct {
   __u32 ifindex;
   __u32 attach_type;
  } netkit;
  struct {
   __u32 map_id;
   __u32 attach_type;
  } sockmap;
 };
} __attribute__((aligned(8)));

struct bpf_token_info {
 __u64 allowed_cmds;
 __u64 allowed_maps;
 __u64 allowed_progs;
 __u64 allowed_attachs;
} __attribute__((aligned(8)));





struct bpf_sock_addr {
 __u32 user_family;
 __u32 user_ip4;


 __u32 user_ip6[4];


 __u32 user_port;


 __u32 family;
 __u32 type;
 __u32 protocol;
 __u32 msg_src_ip4;


 __u32 msg_src_ip6[4];


 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
};







struct bpf_sock_ops {
 __u32 op;
 union {
  __u32 args[4];
  __u32 reply;
  __u32 replylong[4];
 };
 __u32 family;
 __u32 remote_ip4;
 __u32 local_ip4;
 __u32 remote_ip6[4];
 __u32 local_ip6[4];
 __u32 remote_port;
 __u32 local_port;
 __u32 is_fullsock;



 __u32 snd_cwnd;
 __u32 srtt_us;
 __u32 bpf_sock_ops_cb_flags;
 __u32 state;
 __u32 rtt_min;
 __u32 snd_ssthresh;
 __u32 rcv_nxt;
 __u32 snd_nxt;
 __u32 snd_una;
 __u32 mss_cache;
 __u32 ecn_flags;
 __u32 rate_delivered;
 __u32 rate_interval_us;
 __u32 packets_out;
 __u32 retrans_out;
 __u32 total_retrans;
 __u32 segs_in;
 __u32 data_segs_in;
 __u32 segs_out;
 __u32 data_segs_out;
 __u32 lost_out;
 __u32 sacked_out;
 __u32 sk_txhash;
 __u64 bytes_received;
 __u64 bytes_acked;
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
# 6966 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 union { void * skb_data; __u64 :64; } __attribute__((aligned(8)));
 union { void * skb_data_end; __u64 :64; } __attribute__((aligned(8)));
 __u32 skb_len;



 __u32 skb_tcp_flags;
# 6982 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 __u64 skb_hwtstamp;
};


enum {
 BPF_SOCK_OPS_RTO_CB_FLAG = (1<<0),
 BPF_SOCK_OPS_RETRANS_CB_FLAG = (1<<1),
 BPF_SOCK_OPS_STATE_CB_FLAG = (1<<2),
 BPF_SOCK_OPS_RTT_CB_FLAG = (1<<3),
# 7009 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_PARSE_ALL_HDR_OPT_CB_FLAG = (1<<4),
# 7018 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_PARSE_UNKNOWN_HDR_OPT_CB_FLAG = (1<<5),
# 7033 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_WRITE_HDR_OPT_CB_FLAG = (1<<6),

 BPF_SOCK_OPS_ALL_CB_FLAGS = 0x7F,
};

enum {
 SK_BPF_CB_TX_TIMESTAMPING = 1<<0,
 SK_BPF_CB_MASK = (SK_BPF_CB_TX_TIMESTAMPING - 1) |
        SK_BPF_CB_TX_TIMESTAMPING
};




enum {
 BPF_SOCK_OPS_VOID,
 BPF_SOCK_OPS_TIMEOUT_INIT,


 BPF_SOCK_OPS_RWND_INIT,



 BPF_SOCK_OPS_TCP_CONNECT_CB,


 BPF_SOCK_OPS_ACTIVE_ESTABLISHED_CB,



 BPF_SOCK_OPS_PASSIVE_ESTABLISHED_CB,



 BPF_SOCK_OPS_NEEDS_ECN,


 BPF_SOCK_OPS_BASE_RTT,






 BPF_SOCK_OPS_RTO_CB,




 BPF_SOCK_OPS_RETRANS_CB,





 BPF_SOCK_OPS_STATE_CB,



 BPF_SOCK_OPS_TCP_LISTEN_CB,


 BPF_SOCK_OPS_RTT_CB,



 BPF_SOCK_OPS_PARSE_HDR_OPT_CB,
# 7113 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_HDR_OPT_LEN_CB,
# 7130 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_WRITE_HDR_OPT_CB,
# 7156 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 BPF_SOCK_OPS_TSTAMP_SCHED_CB,




 BPF_SOCK_OPS_TSTAMP_SND_SW_CB,



 BPF_SOCK_OPS_TSTAMP_SND_HW_CB,



 BPF_SOCK_OPS_TSTAMP_ACK_CB,




 BPF_SOCK_OPS_TSTAMP_SENDMSG_CB,




};






enum {
 BPF_TCP_ESTABLISHED = 1,
 BPF_TCP_SYN_SENT,
 BPF_TCP_SYN_RECV,
 BPF_TCP_FIN_WAIT1,
 BPF_TCP_FIN_WAIT2,
 BPF_TCP_TIME_WAIT,
 BPF_TCP_CLOSE,
 BPF_TCP_CLOSE_WAIT,
 BPF_TCP_LAST_ACK,
 BPF_TCP_LISTEN,
 BPF_TCP_CLOSING,
 BPF_TCP_NEW_SYN_RECV,
 BPF_TCP_BOUND_INACTIVE,

 BPF_TCP_MAX_STATES
};

enum {
 TCP_BPF_IW = 1001,
 TCP_BPF_SNDCWND_CLAMP = 1002,
 TCP_BPF_DELACK_MAX = 1003,
 TCP_BPF_RTO_MIN = 1004,
# 7241 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
 TCP_BPF_SYN = 1005,
 TCP_BPF_SYN_IP = 1006,
 TCP_BPF_SYN_MAC = 1007,
 TCP_BPF_SOCK_OPS_CB_FLAGS = 1008,
 SK_BPF_CB_FLAGS = 1009,
 SK_BPF_BYPASS_PROT_MEM = 1010,

};

enum {
 BPF_LOAD_HDR_OPT_TCP_SYN = (1ULL << 0),
};




enum {
 BPF_WRITE_HDR_TCP_CURRENT_MSS = 1,






 BPF_WRITE_HDR_TCP_SYNACK_COOKIE = 2,


};

struct bpf_perf_event_value {
 __u64 counter;
 __u64 enabled;
 __u64 running;
};

enum {
 BPF_DEVCG_ACC_MKNOD = (1ULL << 0),
 BPF_DEVCG_ACC_READ = (1ULL << 1),
 BPF_DEVCG_ACC_WRITE = (1ULL << 2),
};

enum {
 BPF_DEVCG_DEV_BLOCK = (1ULL << 0),
 BPF_DEVCG_DEV_CHAR = (1ULL << 1),
};

struct bpf_cgroup_dev_ctx {

 __u32 access_type;
 __u32 major;
 __u32 minor;
};

struct bpf_raw_tracepoint_args {
 __u64 args[0];
};




enum {
 BPF_FIB_LOOKUP_DIRECT = (1U << 0),
 BPF_FIB_LOOKUP_OUTPUT = (1U << 1),
 BPF_FIB_LOOKUP_SKIP_NEIGH = (1U << 2),
 BPF_FIB_LOOKUP_TBID = (1U << 3),
 BPF_FIB_LOOKUP_SRC = (1U << 4),
 BPF_FIB_LOOKUP_MARK = (1U << 5),
};

enum {
 BPF_FIB_LKUP_RET_SUCCESS,
 BPF_FIB_LKUP_RET_BLACKHOLE,
 BPF_FIB_LKUP_RET_UNREACHABLE,
 BPF_FIB_LKUP_RET_PROHIBIT,
 BPF_FIB_LKUP_RET_NOT_FWDED,
 BPF_FIB_LKUP_RET_FWD_DISABLED,
 BPF_FIB_LKUP_RET_UNSUPP_LWT,
 BPF_FIB_LKUP_RET_NO_NEIGH,
 BPF_FIB_LKUP_RET_FRAG_NEEDED,
 BPF_FIB_LKUP_RET_NO_SRC_ADDR,
};

struct bpf_fib_lookup {



 __u8 family;


 __u8 l4_protocol;
 __be16 sport;
 __be16 dport;

 union {

  __u16 tot_len;


  __u16 mtu_result;
 } __attribute__((packed, aligned(2)));



 __u32 ifindex;

 union {

  __u8 tos;
  __be32 flowinfo;


  __u32 rt_metric;
 };




 union {
  __be32 ipv4_src;
  __u32 ipv6_src[4];
 };





 union {
  __be32 ipv4_dst;
  __u32 ipv6_dst[4];
 };

 union {
  struct {

   __be16 h_vlan_proto;
   __be16 h_vlan_TCI;
  };




  __u32 tbid;
 };

 union {

  struct {
   __u32 mark;

  };


  struct {
   __u8 smac[6];
   __u8 dmac[6];
  };
 };
};

struct bpf_redir_neigh {

 __u32 nh_family;

 union {
  __be32 ipv4_nh;
  __u32 ipv6_nh[4];
 };
};


enum bpf_check_mtu_flags {
 BPF_MTU_CHK_SEGS = (1U << 0),
};

enum bpf_check_mtu_ret {
 BPF_MTU_CHK_RET_SUCCESS,
 BPF_MTU_CHK_RET_FRAG_NEEDED,
 BPF_MTU_CHK_RET_SEGS_TOOBIG,
};

enum bpf_task_fd_type {
 BPF_FD_TYPE_RAW_TRACEPOINT,
 BPF_FD_TYPE_TRACEPOINT,
 BPF_FD_TYPE_KPROBE,
 BPF_FD_TYPE_KRETPROBE,
 BPF_FD_TYPE_UPROBE,
 BPF_FD_TYPE_URETPROBE,
};

enum {
 BPF_FLOW_DISSECTOR_F_PARSE_1ST_FRAG = (1U << 0),
 BPF_FLOW_DISSECTOR_F_STOP_AT_FLOW_LABEL = (1U << 1),
 BPF_FLOW_DISSECTOR_F_STOP_AT_ENCAP = (1U << 2),
};

struct bpf_flow_keys {
 __u16 nhoff;
 __u16 thoff;
 __u16 addr_proto;
 __u8 is_frag;
 __u8 is_first_frag;
 __u8 is_encap;
 __u8 ip_proto;
 __be16 n_proto;
 __be16 sport;
 __be16 dport;
 union {
  struct {
   __be32 ipv4_src;
   __be32 ipv4_dst;
  };
  struct {
   __u32 ipv6_src[4];
   __u32 ipv6_dst[4];
  };
 };
 __u32 flags;
 __be32 flow_label;
};

struct bpf_func_info {
 __u32 insn_off;
 __u32 type_id;
};




struct bpf_line_info {
 __u32 insn_off;
 __u32 file_name_off;
 __u32 line_off;
 __u32 line_col;
};

struct bpf_spin_lock {
 __u32 val;
};

struct bpf_timer {
 __u64 __opaque[2];
} __attribute__((aligned(8)));

struct bpf_task_work {
 __u64 __opaque;
} __attribute__((aligned(8)));

struct bpf_wq {
 __u64 __opaque[2];
} __attribute__((aligned(8)));

struct bpf_dynptr {
 __u64 __opaque[2];
} __attribute__((aligned(8)));

struct bpf_list_head {
 __u64 __opaque[2];
} __attribute__((aligned(8)));

struct bpf_list_node {
 __u64 __opaque[3];
} __attribute__((aligned(8)));

struct bpf_rb_root {
 __u64 __opaque[2];
} __attribute__((aligned(8)));

struct bpf_rb_node {
 __u64 __opaque[4];
} __attribute__((aligned(8)));

struct bpf_refcount {
 __u32 __opaque[1];
} __attribute__((aligned(4)));

struct bpf_sysctl {
 __u32 write;


 __u32 file_pos;


};

struct bpf_sockopt {
 union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
 union { void * optval; __u64 :64; } __attribute__((aligned(8)));
 union { void * optval_end; __u64 :64; } __attribute__((aligned(8)));

 __s32 level;
 __s32 optname;
 __s32 optlen;
 __s32 retval;
};

struct bpf_pidns_info {
 __u32 pid;
 __u32 tgid;
};


struct bpf_sk_lookup {
 union {
  union { struct bpf_sock * sk; __u64 :64; } __attribute__((aligned(8)));
  __u64 cookie;
 };

 __u32 family;
 __u32 protocol;
 __u32 remote_ip4;
 __u32 remote_ip6[4];
 __be16 remote_port;
 __u16 :16;
 __u32 local_ip4;
 __u32 local_ip6[4];
 __u32 local_port;
 __u32 ingress_ifindex;
};
# 7568 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
struct btf_ptr {
 void *ptr;
 __u32 type_id;
 __u32 flags;
};
# 7583 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
enum {
 BTF_F_COMPACT = (1ULL << 0),
 BTF_F_NONAME = (1ULL << 1),
 BTF_F_PTR_RAW = (1ULL << 2),
 BTF_F_ZERO = (1ULL << 3),
};





enum bpf_core_relo_kind {
 BPF_CORE_FIELD_BYTE_OFFSET = 0,
 BPF_CORE_FIELD_BYTE_SIZE = 1,
 BPF_CORE_FIELD_EXISTS = 2,
 BPF_CORE_FIELD_SIGNED = 3,
 BPF_CORE_FIELD_LSHIFT_U64 = 4,
 BPF_CORE_FIELD_RSHIFT_U64 = 5,
 BPF_CORE_TYPE_ID_LOCAL = 6,
 BPF_CORE_TYPE_ID_TARGET = 7,
 BPF_CORE_TYPE_EXISTS = 8,
 BPF_CORE_TYPE_SIZE = 9,
 BPF_CORE_ENUMVAL_EXISTS = 10,
 BPF_CORE_ENUMVAL_VALUE = 11,
 BPF_CORE_TYPE_MATCHES = 12,
};
# 7658 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
struct bpf_core_relo {
 __u32 insn_off;
 __u32 type_id;
 __u32 access_str_off;
 enum bpf_core_relo_kind kind;
};







enum {
 BPF_F_TIMER_ABS = (1ULL << 0),
 BPF_F_TIMER_CPU_PIN = (1ULL << 1),
};


struct bpf_iter_num {



 __u64 __opaque[1];
} __attribute__((aligned(8)));






enum bpf_kfunc_flags {
 BPF_F_PAD_ZEROS = (1ULL << 0),
};
# 7706 "/workspaces/repository/vendor/libbpf/include/uapi/linux/bpf.h"
struct bpf_insn_array_value {
 __u32 orig_off;
 __u32 xlated_off;
 __u32 jitted_off;
 __u32 :32;
};
# 8 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2

# 1 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h" 1
# 11 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h"
# 1 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h" 1



struct bpf_fib_lookup;
struct bpf_sk_lookup;
struct bpf_perf_event_data;
struct bpf_perf_event_value;
struct bpf_pidns_info;
struct bpf_redir_neigh;
struct bpf_sock;
struct bpf_sock_addr;
struct bpf_sock_ops;
struct bpf_sock_tuple;
struct bpf_spin_lock;
struct bpf_sysctl;
struct bpf_tcp_sock;
struct bpf_tunnel_key;
struct bpf_xfrm_state;
struct linux_binprm;
struct pt_regs;
struct sk_reuseport_md;
struct sockaddr;
struct tcphdr;
struct seq_file;
struct tcp6_sock;
struct tcp_sock;
struct tcp_timewait_sock;
struct tcp_request_sock;
struct udp6_sock;
struct unix_sock;
struct task_struct;
struct cgroup;
struct __sk_buff;
struct sk_msg_md;
struct xdp_md;
struct path;
struct btf_ptr;
struct inode;
struct socket;
struct file;
struct bpf_timer;
struct mptcp_sock;
struct bpf_dynptr;
struct iphdr;
struct ipv6hdr;
# 64 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_map_lookup_elem)(void *map, const void *key) = (void *) 1;
# 86 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_map_update_elem)(void *map, const void *key, const void *value, __u64 flags) = (void *) 2;
# 96 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_map_delete_elem)(void *map, const void *key) = (void *) 3;
# 110 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 4;
# 122 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_ktime_get_ns)(void) = (void *) 5;
# 185 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_trace_printk)(const char *fmt, __u32 fmt_size, ...) = (void *) 6;
# 201 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_prandom_u32)(void) = (void *) 7;
# 214 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_smp_processor_id)(void) = (void *) 8;
# 239 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_store_bytes)(struct __sk_buff *skb, __u32 offset, const void *from, __u32 len, __u64 flags) = (void *) 9;
# 268 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_l3_csum_replace)(struct __sk_buff *skb, __u32 offset, __u64 from, __u64 to, __u64 size) = (void *) 10;
# 305 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_l4_csum_replace)(struct __sk_buff *skb, __u32 offset, __u64 from, __u64 to, __u64 flags) = (void *) 11;
# 340 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_tail_call)(void *ctx, void *prog_array_map, __u32 index) = (void *) 12;
# 370 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_clone_redirect)(struct __sk_buff *skb, __u32 ifindex, __u64 flags) = (void *) 13;
# 383 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_current_pid_tgid)(void) = (void *) 14;
# 394 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_current_uid_gid)(void) = (void *) 15;
# 409 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_current_comm)(void *buf, __u32 size_of_buf) = (void *) 16;
# 439 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_cgroup_classid)(struct __sk_buff *skb) = (void *) 17;
# 459 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_vlan_push)(struct __sk_buff *skb, __be16 vlan_proto, __u16 vlan_tci) = (void *) 18;
# 475 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_vlan_pop)(struct __sk_buff *skb) = (void *) 19;
# 530 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_get_tunnel_key)(struct __sk_buff *skb, struct bpf_tunnel_key *key, __u32 size, __u64 flags) = (void *) 20;
# 574 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_set_tunnel_key)(struct __sk_buff *skb, struct bpf_tunnel_key *key, __u32 size, __u64 flags) = (void *) 21;
# 607 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_perf_event_read)(void *map, __u64 flags) = (void *) 22;
# 634 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_redirect)(__u32 ifindex, __u64 flags) = (void *) 23;
# 662 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_route_realm)(struct __sk_buff *skb) = (void *) 24;
# 711 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_perf_event_output)(void *ctx, void *map, __u64 flags, void *data, __u64 size) = (void *) 25;
# 732 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_load_bytes)(const void *skb, __u32 offset, void *to, __u32 len) = (void *) 26;
# 778 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_stackid)(void *ctx, void *map, __u64 flags) = (void *) 27;
# 809 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __s64 (* const bpf_csum_diff)(__be32 *from, __u32 from_size, __be32 *to, __u32 to_size, __wsum seed) = (void *) 28;
# 831 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_get_tunnel_opt)(struct __sk_buff *skb, void *opt, __u32 size) = (void *) 29;
# 845 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_set_tunnel_opt)(struct __sk_buff *skb, void *opt, __u32 size) = (void *) 30;
# 876 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_change_proto)(struct __sk_buff *skb, __be16 proto, __u64 flags) = (void *) 31;
# 907 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_change_type)(struct __sk_buff *skb, __u32 type) = (void *) 32;
# 922 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_under_cgroup)(struct __sk_buff *skb, void *map, __u32 index) = (void *) 33;
# 942 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_hash_recalc)(struct __sk_buff *skb) = (void *) 34;
# 952 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_current_task)(void) = (void *) 35;
# 975 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_write_user)(void *dst, const void *src, __u32 len) = (void *) 36;
# 991 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_current_task_under_cgroup)(void *map, __u32 index) = (void *) 37;
# 1019 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_change_tail)(struct __sk_buff *skb, __u32 len, __u64 flags) = (void *) 38;
# 1060 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_pull_data)(struct __sk_buff *skb, __u32 len) = (void *) 39;
# 1076 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __s64 (* const bpf_csum_update)(struct __sk_buff *skb, __wsum csum) = (void *) 40;
# 1090 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void (* const bpf_set_hash_invalid)(struct __sk_buff *skb) = (void *) 41;
# 1105 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_numa_node_id)(void) = (void *) 42;
# 1130 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_change_head)(struct __sk_buff *skb, __u32 len, __u64 flags) = (void *) 43;
# 1149 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_adjust_head)(struct xdp_md *xdp_md, int delta) = (void *) 44;
# 1166 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read_str)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 45;
# 1183 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_socket_cookie)(void *ctx) = (void *) 46;
# 1197 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u32 (* const bpf_get_socket_uid)(struct __sk_buff *skb) = (void *) 47;
# 1208 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_set_hash)(struct __sk_buff *skb, __u32 hash) = (void *) 48;
# 1248 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_setsockopt)(void *bpf_socket, int level, int optname, void *optval, int optlen) = (void *) 49;
# 1309 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_adjust_room)(struct __sk_buff *skb, __s32 len_diff, __u32 mode, __u64 flags) = (void *) 50;
# 1338 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_redirect_map)(void *map, __u64 key, __u64 flags) = (void *) 51;
# 1353 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_redirect_map)(struct __sk_buff *skb, void *map, __u32 key, __u64 flags) = (void *) 52;
# 1376 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sock_map_update)(struct bpf_sock_ops *skops, void *map, void *key, __u64 flags) = (void *) 53;
# 1409 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_adjust_meta)(struct xdp_md *xdp_md, int delta) = (void *) 54;
# 1463 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_perf_event_read_value)(void *map, __u64 flags, struct bpf_perf_event_value *buf, __u32 buf_size) = (void *) 55;
# 1478 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_perf_prog_read_value)(struct bpf_perf_event_data *ctx, struct bpf_perf_event_value *buf, __u32 buf_size) = (void *) 56;
# 1505 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_getsockopt)(void *bpf_socket, int level, int optname, void *optval, int optlen) = (void *) 57;
# 1530 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_override_return)(struct pt_regs *regs, __u64 rc) = (void *) 58;
# 1578 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sock_ops_cb_flags_set)(struct bpf_sock_ops *bpf_sock, int argval) = (void *) 59;
# 1596 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_redirect_map)(struct sk_msg_md *msg, void *map, __u32 key, __u64 flags) = (void *) 60;
# 1634 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_apply_bytes)(struct sk_msg_md *msg, __u32 bytes) = (void *) 61;
# 1656 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_cork_bytes)(struct sk_msg_md *msg, __u32 bytes) = (void *) 62;
# 1691 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_pull_data)(struct sk_msg_md *msg, __u32 start, __u32 end, __u64 flags) = (void *) 63;
# 1713 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_bind)(struct bpf_sock_addr *ctx, struct sockaddr *addr, int addr_len) = (void *) 64;
# 1731 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_adjust_tail)(struct xdp_md *xdp_md, int delta) = (void *) 65;
# 1751 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_get_xfrm_state)(struct __sk_buff *skb, __u32 index, struct bpf_xfrm_state *xfrm_state, __u32 size, __u64 flags) = (void *) 66;
# 1798 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_stack)(void *ctx, void *buf, __u32 size, __u64 flags) = (void *) 67;
# 1824 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_load_bytes_relative)(const void *skb, __u32 offset, void *to, __u32 len, __u32 start_header) = (void *) 68;
# 1880 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_fib_lookup)(void *ctx, struct bpf_fib_lookup *params, int plen, __u32 flags) = (void *) 69;
# 1903 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sock_hash_update)(struct bpf_sock_ops *skops, void *map, void *key, __u64 flags) = (void *) 70;
# 1921 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_redirect_hash)(struct sk_msg_md *msg, void *map, void *key, __u64 flags) = (void *) 71;
# 1939 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_redirect_hash)(struct __sk_buff *skb, void *map, void *key, __u64 flags) = (void *) 72;
# 1980 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_lwt_push_encap)(struct __sk_buff *skb, __u32 type, void *hdr, __u32 len) = (void *) 73;
# 1999 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_lwt_seg6_store_bytes)(struct __sk_buff *skb, __u32 offset, const void *from, __u32 len) = (void *) 74;
# 2019 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_lwt_seg6_adjust_srh)(struct __sk_buff *skb, __u32 offset, __s32 delta) = (void *) 75;
# 2052 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_lwt_seg6_action)(struct __sk_buff *skb, __u32 action, void *param, __u32 param_len) = (void *) 76;
# 2075 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_rc_repeat)(void *ctx) = (void *) 77;
# 2105 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_rc_keydown)(void *ctx, __u32 protocol, __u64 scancode, __u32 toggle) = (void *) 78;
# 2125 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_skb_cgroup_id)(struct __sk_buff *skb) = (void *) 79;
# 2137 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_current_cgroup_id)(void) = (void *) 80;
# 2159 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_get_local_storage)(void *map, __u64 flags) = (void *) 81;
# 2172 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_select_reuseport)(struct sk_reuseport_md *reuse, void *map, void *key, __u64 flags) = (void *) 82;
# 2194 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_skb_ancestor_cgroup_id)(struct __sk_buff *skb, int ancestor_level) = (void *) 83;
# 2235 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_sock *(* const bpf_sk_lookup_tcp)(void *ctx, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) = (void *) 84;
# 2276 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_sock *(* const bpf_sk_lookup_udp)(void *ctx, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) = (void *) 85;
# 2288 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_release)(void *sock) = (void *) 86;
# 2302 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_map_push_elem)(void *map, const void *value, __u64 flags) = (void *) 87;
# 2312 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_map_pop_elem)(void *map, void *value) = (void *) 88;
# 2322 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_map_peek_elem)(void *map, void *value) = (void *) 89;
# 2342 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_push_data)(struct sk_msg_md *msg, __u32 start, __u32 len, __u64 flags) = (void *) 90;
# 2358 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_msg_pop_data)(struct sk_msg_md *msg, __u32 start, __u32 len, __u64 flags) = (void *) 91;
# 2376 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_rc_pointer_rel)(void *ctx, __s32 rel_x, __s32 rel_y) = (void *) 92;
# 2428 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_spin_lock)(struct bpf_spin_lock *lock) = (void *) 93;
# 2439 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_spin_unlock)(struct bpf_spin_lock *lock) = (void *) 94;
# 2451 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_sock *(* const bpf_sk_fullsock)(struct bpf_sock *sk) = (void *) 95;
# 2463 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_tcp_sock *(* const bpf_tcp_sock)(struct bpf_sock *sk) = (void *) 96;
# 2477 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_ecn_set_ce)(struct __sk_buff *skb) = (void *) 97;
# 2489 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_sock *(* const bpf_get_listener_sock)(struct bpf_sock *sk) = (void *) 98;
# 2512 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct bpf_sock *(* const bpf_skc_lookup_tcp)(void *ctx, struct bpf_sock_tuple *tuple, __u32 tuple_size, __u64 netns, __u64 flags) = (void *) 99;
# 2532 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_tcp_check_syncookie)(void *sk, void *iph, __u32 iph_len, struct tcphdr *th, __u32 th_len) = (void *) 100;
# 2552 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sysctl_get_name)(struct bpf_sysctl *ctx, char *buf, unsigned long buf_len, __u64 flags) = (void *) 101;
# 2575 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sysctl_get_current_value)(struct bpf_sysctl *ctx, char *buf, unsigned long buf_len) = (void *) 102;
# 2596 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sysctl_get_new_value)(struct bpf_sysctl *ctx, char *buf, unsigned long buf_len) = (void *) 103;
# 2617 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sysctl_set_new_value)(struct bpf_sysctl *ctx, const char *buf, unsigned long buf_len) = (void *) 104;
# 2645 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_strtol)(const char *buf, unsigned long buf_len, __u64 flags, long *res) = (void *) 105;
# 2672 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_strtoul)(const char *buf, unsigned long buf_len, __u64 flags, unsigned long *res) = (void *) 106;
# 2707 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_sk_storage_get)(void *map, void *sk, void *value, __u64 flags) = (void *) 107;
# 2720 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_storage_delete)(void *map, void *sk) = (void *) 108;
# 2739 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_send_signal)(__u32 sig) = (void *) 109;
# 2770 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __s64 (* const bpf_tcp_gen_syncookie)(void *sk, void *iph, __u32 iph_len, struct tcphdr *th, __u32 th_len) = (void *) 110;
# 2798 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_output)(void *ctx, void *map, __u64 flags, void *data, __u64 size) = (void *) 111;
# 2809 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read_user)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 112;
# 2820 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read_kernel)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 113;
# 2868 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read_user_str)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 114;
# 2880 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_probe_read_kernel_str)(void *dst, __u32 size, const void *unsafe_ptr) = (void *) 115;
# 2891 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_tcp_send_ack)(void *tp, __u32 rcv_nxt) = (void *) 116;
# 2909 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_send_signal_thread)(__u32 sig) = (void *) 117;
# 2919 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_jiffies64)(void) = (void *) 118;
# 2942 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_read_branch_records)(struct bpf_perf_event_data *ctx, void *buf, __u32 size, __u64 flags) = (void *) 119;
# 2958 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_ns_current_pid_tgid)(__u64 dev, __u64 ino, struct bpf_pidns_info *nsdata, __u32 size) = (void *) 120;
# 2986 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_output)(void *ctx, void *map, __u64 flags, void *data, __u64 size) = (void *) 121;
# 3003 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_netns_cookie)(void *ctx) = (void *) 122;
# 3025 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_current_ancestor_cgroup_id)(int ancestor_level) = (void *) 123;
# 3057 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sk_assign)(void *ctx, void *sk, __u64 flags) = (void *) 124;
# 3069 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_ktime_get_boot_ns)(void) = (void *) 125;
# 3102 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_seq_printf)(struct seq_file *m, const char *fmt, __u32 fmt_size, const void *data, __u32 data_len) = (void *) 126;
# 3116 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_seq_write)(struct seq_file *m, const void *data, __u32 len) = (void *) 127;
# 3134 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_sk_cgroup_id)(void *sk) = (void *) 128;
# 3156 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_sk_ancestor_cgroup_id)(void *sk, int ancestor_level) = (void *) 129;
# 3177 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_ringbuf_output)(void *ringbuf, void *data, __u64 size, __u64 flags) = (void *) 130;
# 3189 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_ringbuf_reserve)(void *ringbuf, __u64 size, __u64 flags) = (void *) 131;
# 3207 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void (* const bpf_ringbuf_submit)(void *data, __u64 flags) = (void *) 132;
# 3227 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void (* const bpf_ringbuf_discard)(void *data, __u64 flags) = (void *) 133;
# 3248 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_ringbuf_query)(void *ringbuf, __u64 flags) = (void *) 134;
# 3284 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_csum_level)(struct __sk_buff *skb, __u64 level) = (void *) 135;
# 3294 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct tcp6_sock *(* const bpf_skc_to_tcp6_sock)(void *sk) = (void *) 136;
# 3304 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct tcp_sock *(* const bpf_skc_to_tcp_sock)(void *sk) = (void *) 137;
# 3314 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct tcp_timewait_sock *(* const bpf_skc_to_tcp_timewait_sock)(void *sk) = (void *) 138;
# 3324 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct tcp_request_sock *(* const bpf_skc_to_tcp_request_sock)(void *sk) = (void *) 139;
# 3334 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct udp6_sock *(* const bpf_skc_to_udp6_sock)(void *sk) = (void *) 140;
# 3373 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_task_stack)(struct task_struct *task, void *buf, __u32 size, __u64 flags) = (void *) 141;
# 3440 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_load_hdr_opt)(struct bpf_sock_ops *skops, void *searchby_res, __u32 len, __u64 flags) = (void *) 142;
# 3477 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_store_hdr_opt)(struct bpf_sock_ops *skops, const void *from, __u32 len, __u64 flags) = (void *) 143;
# 3503 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_reserve_hdr_opt)(struct bpf_sock_ops *skops, __u32 len, __u64 flags) = (void *) 144;
# 3535 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_inode_storage_get)(void *map, void *inode, void *value, __u64 flags) = (void *) 145;
# 3547 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static int (* const bpf_inode_storage_delete)(void *map, void *inode) = (void *) 146;
# 3563 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_d_path)(const struct path *path, char *buf, __u32 sz) = (void *) 147;
# 3574 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_copy_from_user)(void *dst, __u32 size, const void *user_ptr) = (void *) 148;
# 3614 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_snprintf_btf)(char *str, __u32 str_size, struct btf_ptr *ptr, __u32 btf_ptr_size, __u64 flags) = (void *) 149;
# 3626 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_seq_printf_btf)(struct seq_file *m, struct btf_ptr *ptr, __u32 ptr_size, __u64 flags) = (void *) 150;
# 3639 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_skb_cgroup_classid)(struct __sk_buff *skb) = (void *) 151;
# 3664 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_redirect_neigh)(__u32 ifindex, struct bpf_redir_neigh *params, int plen, __u64 flags) = (void *) 152;
# 3685 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_per_cpu_ptr)(const void *percpu_ptr, __u32 cpu) = (void *) 153;
# 3701 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_this_cpu_ptr)(const void *percpu_ptr) = (void *) 154;
# 3724 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_redirect_peer)(__u32 ifindex, __u64 flags) = (void *) 155;
# 3756 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_task_storage_get)(void *map, struct task_struct *task, void *value, __u64 flags) = (void *) 156;
# 3768 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_task_storage_delete)(void *map, struct task_struct *task) = (void *) 157;
# 3780 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct task_struct *(* const bpf_get_current_task_btf)(void) = (void *) 158;
# 3794 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_bprm_opts_set)(struct linux_binprm *bprm, __u64 flags) = (void *) 159;
# 3808 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_ktime_get_coarse_ns)(void) = (void *) 160;
# 3822 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_ima_inode_hash)(struct inode *inode, void *dst, __u32 size) = (void *) 161;
# 3834 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct socket *(* const bpf_sock_from_file)(struct file *file) = (void *) 162;
# 3905 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_check_mtu)(void *ctx, __u32 ifindex, __u32 *mtu_len, __s32 len_diff, __u64 flags) = (void *) 163;
# 3938 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_for_each_map_elem)(void *map, void *callback_fn, void *callback_ctx, __u64 flags) = (void *) 164;
# 3970 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_snprintf)(char *str, __u32 str_size, const char *fmt, __u64 *data, __u32 data_len) = (void *) 165;
# 3980 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sys_bpf)(__u32 cmd, void *attr, __u32 attr_size) = (void *) 166;
# 3990 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_btf_find_by_name_kind)(char *name, int name_sz, __u32 kind, int flags) = (void *) 167;
# 4000 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_sys_close)(__u32 fd) = (void *) 168;
# 4021 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_timer_init)(struct bpf_timer *timer, void *map, __u64 flags) = (void *) 169;
# 4036 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_timer_set_callback)(struct bpf_timer *timer, void *callback_fn) = (void *) 170;
# 4074 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_timer_start)(struct bpf_timer *timer, __u64 nsecs, __u64 flags) = (void *) 171;
# 4088 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_timer_cancel)(struct bpf_timer *timer) = (void *) 172;
# 4104 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_func_ip)(void *ctx) = (void *) 173;
# 4123 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_get_attach_cookie)(void *ctx) = (void *) 174;
# 4133 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_task_pt_regs)(struct task_struct *task) = (void *) 175;
# 4158 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_branch_snapshot)(void *entries, __u32 size, __u64 flags) = (void *) 176;
# 4172 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_trace_vprintk)(const char *fmt, __u32 fmt_size, const void *data, __u32 data_len) = (void *) 177;
# 4182 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct unix_sock *(* const bpf_skc_to_unix_sock)(void *sk) = (void *) 178;
# 4201 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_kallsyms_lookup_name)(const char *name, int name_sz, int flags, __u64 *res) = (void *) 179;
# 4224 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_find_vma)(struct task_struct *task, __u64 addr, void *callback_fn, void *callback_ctx, __u64 flags) = (void *) 180;
# 4252 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_loop)(__u32 nr_loops, void *callback_fn, void *callback_ctx, __u64 flags) = (void *) 181;
# 4266 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_strncmp)(const char *s1, __u32 s1_sz, const char *s2) = (void *) 182;
# 4279 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_func_arg)(void *ctx, __u32 n, __u64 *value) = (void *) 183;
# 4292 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_func_ret)(void *ctx, __u64 *value) = (void *) 184;
# 4304 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_get_func_arg_cnt)(void *ctx) = (void *) 185;
# 4317 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static int (* const bpf_get_retval)(void) = (void *) 186;
# 4340 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static int (* const bpf_set_retval)(int retval) = (void *) 187;
# 4350 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_xdp_get_buff_len)(struct xdp_md *xdp_md) = (void *) 188;
# 4363 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_load_bytes)(struct xdp_md *xdp_md, __u32 offset, void *buf, __u32 len) = (void *) 189;
# 4374 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_xdp_store_bytes)(struct xdp_md *xdp_md, __u32 offset, void *buf, __u32 len) = (void *) 190;
# 4388 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_copy_from_user_task)(void *dst, __u32 size, const void *user_ptr, struct task_struct *tsk, __u64 flags) = (void *) 191;
# 4422 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_skb_set_tstamp)(struct __sk_buff *skb, __u64 tstamp, __u32 tstamp_type) = (void *) 192;
# 4436 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_ima_file_hash)(struct file *file, void *dst, __u32 size) = (void *) 193;
# 4452 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_kptr_xchg)(void *dst, void *ptr) = (void *) 194;
# 4464 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_map_lookup_percpu_elem)(void *map, const void *key, __u32 cpu) = (void *) 195;
# 4474 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static struct mptcp_sock *(* const bpf_skc_to_mptcp_sock)(void *sk) = (void *) 196;
# 4489 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_dynptr_from_mem)(void *data, __u64 size, __u64 flags, struct bpf_dynptr *ptr) = (void *) 197;
# 4504 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_ringbuf_reserve_dynptr)(void *ringbuf, __u32 size, __u64 flags, struct bpf_dynptr *ptr) = (void *) 198;
# 4519 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void (* const bpf_ringbuf_submit_dynptr)(struct bpf_dynptr *ptr, __u64 flags) = (void *) 199;
# 4533 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void (* const bpf_ringbuf_discard_dynptr)(struct bpf_dynptr *ptr, __u64 flags) = (void *) 200;
# 4547 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_dynptr_read)(void *dst, __u64 len, const struct bpf_dynptr *src, __u64 offset, __u64 flags) = (void *) 201;
# 4572 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_dynptr_write)(const struct bpf_dynptr *dst, __u64 offset, void *src, __u64 len, __u64 flags) = (void *) 202;
# 4590 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_dynptr_data)(const struct bpf_dynptr *ptr, __u64 offset, __u64 len) = (void *) 203;
# 4614 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __s64 (* const bpf_tcp_raw_gen_syncookie_ipv4)(struct iphdr *iph, struct tcphdr *th, __u32 th_len) = (void *) 204;
# 4640 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __s64 (* const bpf_tcp_raw_gen_syncookie_ipv6)(struct ipv6hdr *iph, struct tcphdr *th, __u32 th_len) = (void *) 205;
# 4659 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_tcp_raw_check_syncookie_ipv4)(struct iphdr *iph, struct tcphdr *th) = (void *) 206;
# 4680 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_tcp_raw_check_syncookie_ipv6)(struct ipv6hdr *iph, struct tcphdr *th) = (void *) 207;
# 4695 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static __u64 (* const bpf_ktime_get_tai_ns)(void) = (void *) 208;
# 4737 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_user_ringbuf_drain)(void *map, void *callback_fn, void *ctx, __u64 flags) = (void *) 209;
# 4771 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static void *(* const bpf_cgrp_storage_get)(void *map, struct cgroup *cgroup, void *value, __u64 flags) = (void *) 210;
# 4783 "/workspaces/repository/vendor/libbpf/src/bpf_helper_defs.h"
static long (* const bpf_cgrp_storage_delete)(void *map, struct cgroup *cgroup) = (void *) 211;
# 12 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h" 2
# 150 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h"
static inline __attribute__((always_inline)) void
bpf_tail_call_static(void *ctx, const void *map, const __u32 slot)
{
 if (!__builtin_constant_p(slot))
  __builtin_trap();
# 169 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h"
 asm volatile("r1 = %[ctx]\n\t"
       "r2 = %[map]\n\t"
       "r3 = %[slot]\n\t"
       "call 12"
       :: [ctx]"r"(ctx), [map]"r"(map), [slot]"i"(slot)
       : "r0", "r1", "r2", "r3", "r4", "r5");
}



enum libbpf_pin_type {
 LIBBPF_PIN_NONE,

 LIBBPF_PIN_BY_NAME,
};

enum libbpf_tristate {
 TRI_NO = 0,
 TRI_YES = 1,
 TRI_MODULE = 2,
};
# 343 "/workspaces/repository/vendor/libbpf/src/bpf_helpers.h"
struct bpf_iter_num;

extern int bpf_iter_num_new(struct bpf_iter_num *it, int start, int end) __attribute__((weak)) __attribute__((section(".ksyms")));
extern int *bpf_iter_num_next(struct bpf_iter_num *it) __attribute__((weak)) __attribute__((section(".ksyms")));
extern void bpf_iter_num_destroy(struct bpf_iter_num *it) __attribute__((weak)) __attribute__((section(".ksyms")));
# 10 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2

# 1 "/workspaces/repository/kprog/x86/x86_sim.h" 1
# 87 "/workspaces/repository/kprog/x86/x86_sim.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_opcode.h" 1
# 12 "/workspaces/repository/kprog/x86/../formal/generated/x86_opcode.h"
_Static_assert(0x00U == 0x00U, "x86 opcode nop drift");
_Static_assert(0x01U == 0x01U, "x86 opcode movImm drift");
_Static_assert(0x02U == 0x02U, "x86 opcode movReg drift");
_Static_assert(0x03U == 0x03U, "x86 opcode addImm drift");
_Static_assert(0x04U == 0x04U, "x86 opcode addReg drift");
_Static_assert(0x05U == 0x05U, "x86 opcode xorReg drift");
_Static_assert(0x06U == 0x06U, "x86 opcode movLoad drift");
_Static_assert(0x07U == 0x07U, "x86 opcode movStoreImm drift");
_Static_assert(0x08U == 0x08U, "x86 opcode movStoreReg drift");
_Static_assert(0x09U == 0x09U, "x86 opcode lea drift");
_Static_assert(0x0aU == 0x0aU, "x86 opcode aluImm drift");
_Static_assert(0x0bU == 0x0bU, "x86 opcode aluReg drift");
_Static_assert(0x0cU == 0x0cU, "x86 opcode cmpImm drift");
_Static_assert(0x0dU == 0x0dU, "x86 opcode cmpReg drift");
_Static_assert(0x0eU == 0x0eU, "x86 opcode testImm drift");
_Static_assert(0x0fU == 0x0fU, "x86 opcode testReg drift");
_Static_assert(0x10U == 0x10U, "x86 opcode jcc drift");
_Static_assert(0x11U == 0x11U, "x86 opcode jmp drift");
_Static_assert(0x12U == 0x12U, "x86 opcode push drift");
_Static_assert(0x13U == 0x13U, "x86 opcode pop drift");
_Static_assert(0x14U == 0x14U, "x86 opcode call drift");
_Static_assert(0x15U == 0x15U, "x86 opcode cmov drift");
_Static_assert(0x16U == 0x16U, "x86 opcode setcc drift");
_Static_assert(0x17U == 0x17U, "x86 opcode bswap drift");
_Static_assert(0x18U == 0x18U, "x86 opcode popcnt drift");
_Static_assert(0x19U == 0x19U, "x86 opcode xchg drift");
_Static_assert(0x1aU == 0x1aU, "x86 opcode div drift");
_Static_assert(0x1bU == 0x1bU, "x86 opcode shldImm drift");
_Static_assert(0x1cU == 0x1cU, "x86 opcode shrdImm drift");
_Static_assert(0x1dU == 0x1dU, "x86 opcode cmpMemImm drift");
_Static_assert(0x1eU == 0x1eU, "x86 opcode testMemImm drift");
_Static_assert(0x1fU == 0x1fU, "x86 opcode cmpMemReg drift");
_Static_assert(0x20U == 0x20U, "x86 opcode movzxReg drift");
_Static_assert(0x21U == 0x21U, "x86 opcode movsxReg drift");
_Static_assert(0x22U == 0x22U, "x86 opcode movsxLoad drift");
_Static_assert(0x23U == 0x23U, "x86 opcode aluMem drift");
_Static_assert(0x24U == 0x24U, "x86 opcode cmpRegMem drift");
_Static_assert(0x25U == 0x25U, "x86 opcode movLoadScalar drift");
_Static_assert(0x26U == 0x26U, "x86 opcode shiftx drift");
_Static_assert(0x27U == 0x27U, "x86 opcode rorx drift");
_Static_assert(0x28U == 0x28U, "x86 opcode movbeLoad drift");
_Static_assert(0x29U == 0x29U, "x86 opcode movbeStore drift");
_Static_assert(0x2aU == 0x2aU, "x86 opcode shiftxMem drift");
_Static_assert(0x2bU == 0x2bU, "x86 opcode rorxMem drift");
_Static_assert(0x2cU == 0x2cU, "x86 opcode movLoadMapPtr drift");
_Static_assert(0x2dU == 0x2dU, "x86 opcode movLoadHelperId drift");
_Static_assert(0x2eU == 0x2eU, "x86 opcode callHelper drift");
_Static_assert(0x2fU == 0x2fU, "x86 opcode callReg drift");
_Static_assert(0x30U == 0x30U, "x86 opcode loadXmm0 drift");
_Static_assert(0x31U == 0x31U, "x86 opcode storeXmm0 drift");
_Static_assert(0x32U == 0x32U, "x86 opcode aluMemUnary drift");
_Static_assert(0x33U == 0x33U, "x86 opcode aluMemImm drift");
_Static_assert(0x34U == 0x34U, "x86 opcode bzhi drift");
_Static_assert(0x35U == 0x35U, "x86 opcode bzhiMem drift");
_Static_assert(0x36U == 0x36U, "x86 opcode aluMemReg drift");
_Static_assert(0x37U == 0x37U, "x86 opcode bt drift");
_Static_assert(0x38U == 0x38U, "x86 opcode imulImm drift");
_Static_assert(0x39U == 0x39U, "x86 opcode mulx drift");
_Static_assert(0x3aU == 0x3aU, "x86 opcode repMovs drift");
_Static_assert(0x3bU == 0x3bU, "x86 opcode testMemReg drift");
_Static_assert(0x3cU == 0x3cU, "x86 opcode callMemset drift");
_Static_assert(0x3dU == 0x3dU, "x86 opcode andn drift");
_Static_assert(0x3eU == 0x3eU, "x86 opcode setccMem drift");
_Static_assert(0x3fU == 0x3fU, "x86 opcode callMemcpy drift");
_Static_assert(0x40U == 0x40U, "x86 opcode cmovMem drift");
_Static_assert(0x41U == 0x41U, "x86 opcode imulMemImm drift");
_Static_assert(0x42U == 0x42U, "x86 opcode btImm drift");
_Static_assert(0x43U == 0x43U, "x86 opcode btMemImm drift");
_Static_assert(0x44U == 0x44U, "x86 opcode andnMem drift");
_Static_assert(0x45U == 0x45U, "x86 opcode callMemsetReg drift");
_Static_assert(0x46U == 0x46U, "x86 opcode callMemcpyReg drift");
_Static_assert(0x47U == 0x47U, "x86 opcode popcntMem drift");
_Static_assert(0x48U == 0x48U, "x86 opcode ror drift");
_Static_assert(0x49U == 0x49U, "x86 opcode rorMem drift");
_Static_assert(0xffU == 0xffU, "x86 opcode ret drift");
_Static_assert(0x01U == 0x01U, "x86 opcode movImm64 alias drift");
_Static_assert(0x02U == 0x02U, "x86 opcode movReg64 alias drift");
_Static_assert(0x03U == 0x03U, "x86 opcode addImm64 alias drift");
_Static_assert(0x04U == 0x04U, "x86 opcode addReg64 alias drift");
_Static_assert(0x05U == 0x05U, "x86 opcode xorReg32 alias drift");
# 88 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_alu_decode.h" 1
# 89 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 111 "/workspaces/repository/kprog/x86/x86_sim.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_width.h" 1



_Static_assert(1U == 1U, "x86 width code drift");
_Static_assert(2U == 2U, "x86 width code drift");
_Static_assert(4U == 4U, "x86 width code drift");
_Static_assert(8U == 8U, "x86 width code drift");
# 112 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_immediate.h" 1
# 113 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_adc.h" 1
# 114 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_sbb_result.h" 1
# 115 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_not.h" 1
# 116 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_shift_count.h" 1
# 117 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_shift_result.h" 1



static inline __attribute__((always_inline)) __u64 kprog_x86_shl_result(__u64 value, __u64 rhs,
                                                   __u8 width)
{
 __u8 count = ((rhs) & ((width) == 8U ? 63U : 31U));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 narrowed = value & mask;

 return (narrowed << count) & mask;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_shr_result(__u64 value, __u64 rhs,
                                                   __u8 width)
{
 __u8 count = ((rhs) & ((width) == 8U ? 63U : 31U));
 __u64 narrowed = value & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));

 return narrowed >> count;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_sar_result(__u64 value, __u64 rhs,
                                                   __u8 width)
{
 __u8 count = ((rhs) & ((width) == 8U ? 63U : 31U));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 narrowed = value & mask;
 __u64 shifted;

 if (count == 0)
  return narrowed;
 shifted = narrowed >> count;
 if (narrowed & ((width) == 1U ? 0x80ULL : ((width) == 2U ? 0x8000ULL : ((width) == 4U ? 0x80000000ULL : 0x8000000000000000ULL))))
  shifted |= mask ^ (mask >> count);
 return shifted;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_rol_result(__u64 value, __u64 rhs,
                                                   __u8 width)
{
 __u32 bits = ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 count = ((rhs) & ((width) == 8U ? 63U : 31U)) & (bits - 1);
 __u64 narrowed = value & mask;

 if (count == 0)
  return narrowed;
 return ((narrowed << count) | (narrowed >> (bits - count))) & mask;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_ror_result(__u64 value, __u64 rhs,
                                                   __u8 width)
{
 __u32 bits = ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 count = ((rhs) & ((width) == 8U ? 63U : 31U)) & (bits - 1);
 __u64 narrowed = value & mask;

 if (count == 0)
  return narrowed;
 return ((narrowed >> count) | (narrowed << (bits - count))) & mask;
}
# 118 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_alu_result.h" 1
# 119 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_bswap.h" 1








static inline __attribute__((always_inline)) __u64 kprog_x86_bswap_value(__u64 value, __u8 width)
{
 if (width == 1U)
  return value & 0xffULL;
 if (width == 2U)
  return ((value & 0x00ffULL) << 8) | ((value & 0xff00ULL) >> 8);

 __u64 swapped = ((value & 0x00000000000000ffULL) << 56) |
   ((value & 0x000000000000ff00ULL) << 40) |
   ((value & 0x0000000000ff0000ULL) << 24) |
   ((value & 0x00000000ff000000ULL) << 8) |
   ((value & 0x000000ff00000000ULL) >> 8) |
   ((value & 0x0000ff0000000000ULL) >> 24) |
   ((value & 0x00ff000000000000ULL) >> 40) |
   ((value & 0xff00000000000000ULL) >> 56);

 if (width == 4U)
  return swapped >> 32;
 return swapped;
}
# 120 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_signed.h" 1
# 10 "/workspaces/repository/kprog/x86/../formal/generated/x86_signed.h"
static inline __attribute__((always_inline)) __u64 kprog_x86_sign_extend_value(__u64 value,
                                                          __u8 width)
{
 if (width == 1U)
  return (__u64)(__s64)(__s8)(value & 0xffULL);
 if (width == 2U)
  return (__u64)(__s64)(__s16)(value & 0xffffULL);
 if (width == 4U)
  return (__u64)(__s64)(__s32)(value & 0xffffffffULL);
 return value;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_abs_width_value(__u64 value,
                                                        __u8 width)
{
 __u64 narrowed = value & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));

 if (narrowed & ((width) == 1U ? 0x80ULL : ((width) == 2U ? 0x8000ULL : ((width) == 4U ? 0x80000000ULL : 0x8000000000000000ULL))))
  return ((~narrowed) + 1) & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 return narrowed;
}
# 121 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_popcount.h" 1








static inline __attribute__((always_inline)) __u64 kprog_x86_popcount_value(__u64 value)
{
 value = value - ((value >> 1) & 0x5555555555555555ULL);
 value = (value & 0x3333333333333333ULL) +
  ((value >> 2) & 0x3333333333333333ULL);
 value = (value + (value >> 4)) & 0x0f0f0f0f0f0f0f0fULL;
 return (value * 0x0101010101010101ULL) >> 56;
}
# 122 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_bitops.h" 1
# 10 "/workspaces/repository/kprog/x86/../formal/generated/x86_bitops.h"
static inline __attribute__((always_inline)) __u8 kprog_x86_bt_value(__u64 base, __u64 index,
                                                __u8 width)
{
 __u8 bit = (__u8)(index &
  (((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U))) - 1U));

 return (__u8)((((base) & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))) >> bit) & 1U);
}

static inline __attribute__((always_inline)) __u64 kprog_x86_bzhi_value(__u64 src, __u64 count,
                                                   __u8 width)
{
 __u32 bits = ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
 __u64 c = count & 0xffULL;
 __u64 result = src;

 if (c < bits)
  result &= (1ULL << c) - 1ULL;
 return ((result) & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))));
}
# 123 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_doubleshift.h" 1
# 11 "/workspaces/repository/kprog/x86/../formal/generated/x86_doubleshift.h"
static inline __attribute__((always_inline)) __u64 kprog_x86_shld_value(__u64 dst, __u64 src,
                                                   __u64 shift_count,
                                                   __u8 width)
{
 __u32 bits = ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 k = ((shift_count) & ((width) == 8U ? 63U : 31U));
 __u64 d = dst & mask;
 __u64 s = src & mask;

 if (k == 0)
  return d;
 if (k >= bits)
  return (s << (k - bits)) & mask;
 return ((d << k) | (s >> (bits - k))) & mask;
}

static inline __attribute__((always_inline)) __u64 kprog_x86_shrd_value(__u64 dst, __u64 src,
                                                   __u64 shift_count,
                                                   __u8 width)
{
 __u32 bits = ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
 __u64 mask = ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
 __u64 k = ((shift_count) & ((width) == 8U ? 63U : 31U));
 __u64 d = dst & mask;
 __u64 s = src & mask;

 if (k == 0)
  return d;
 if (k >= bits)
  return (s >> (k - bits)) & mask;
 return ((d >> k) | (s << (bits - k))) & mask;
}
# 124 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 154 "/workspaces/repository/kprog/x86/x86_sim.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mem_aux.h" 1
# 155 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 167 "/workspaces/repository/kprog/x86/x86_sim.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_lane_aux.h" 1
# 168 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_index.h" 1
# 169 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mem_offset.h" 1
# 170 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_arena.h" 1
# 171 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mem_dispatch.h" 1
# 172 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_store.h" 1
# 173 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_movbe.h" 1
# 16 "/workspaces/repository/kprog/x86/../formal/generated/x86_movbe.h"
_Static_assert(0x28U == 0x28U, "x86 movbe movbeLoad opcode drift");
_Static_assert(0x29U == 0x29U, "x86 movbe movbeStore opcode drift");
# 27 "/workspaces/repository/kprog/x86/../formal/generated/x86_movbe.h"
_Static_assert(8U == 8U, "x86 width code drift");
# 174 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_xmm0.h" 1
# 17 "/workspaces/repository/kprog/x86/../formal/generated/x86_xmm0.h"
_Static_assert(0x30U == 0x30U, "x86 xmm0 loadXmm0 opcode drift");
_Static_assert(0x31U == 0x31U, "x86 xmm0 storeXmm0 opcode drift");
# 29 "/workspaces/repository/kprog/x86/../formal/generated/x86_xmm0.h"
_Static_assert(8U == 8U, "x86 width code drift");
_Static_assert(8U == 8U,
        "x86 xmm0 lane width drift");
_Static_assert(8U - 0U ==
        8U, "x86 xmm0 lanes not consecutive");
# 175 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_callmem.h" 1




_Static_assert(0x3fU == 0x3fU, "x86 callmem callMemcpy opcode drift");
_Static_assert(0x46U == 0x46U, "x86 callmem callMemcpyReg opcode drift");
_Static_assert(0x3cU == 0x3cU, "x86 callmem callMemset opcode drift");
_Static_assert(0x45U == 0x45U, "x86 callmem callMemsetReg opcode drift");
# 176 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_pushpop.h" 1





_Static_assert(0x12U == 0x12U, "x86 pushpop push opcode drift");
_Static_assert(0x13U == 0x13U, "x86 pushpop pop opcode drift");






_Static_assert(8U == 8U, "x86 width code drift");
# 177 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_andn.h" 1
# 17 "/workspaces/repository/kprog/x86/../formal/generated/x86_andn.h"
_Static_assert(0x3dU == 0x3dU, "x86 andn andn opcode drift");
_Static_assert(0x44U == 0x44U, "x86 andn andnMem opcode drift");





_Static_assert(8U == 8U, "x86 width code drift");
# 178 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_bzhi.h" 1
# 18 "/workspaces/repository/kprog/x86/../formal/generated/x86_bzhi.h"
_Static_assert(0x34U == 0x34U, "x86 bzhi bzhi opcode drift");
_Static_assert(0x35U == 0x35U, "x86 bzhi bzhiMem opcode drift");





_Static_assert(8U == 8U, "x86 width code drift");
# 179 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_bt.h" 1
# 17 "/workspaces/repository/kprog/x86/../formal/generated/x86_bt.h"
_Static_assert(0x37U == 0x37U, "x86 bt bt opcode drift");
_Static_assert(0x42U == 0x42U, "x86 bt btImm opcode drift");
_Static_assert(0x43U == 0x43U, "x86 bt btMemImm opcode drift");





_Static_assert(8U == 8U, "x86 width code drift");
# 180 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_cmpop.h" 1
# 23 "/workspaces/repository/kprog/x86/../formal/generated/x86_cmpop.h"
_Static_assert(0x0cU == 0x0cU, "x86 cmpop cmpImm opcode drift");
_Static_assert(0x0dU == 0x0dU, "x86 cmpop cmpReg opcode drift");
_Static_assert(0x0eU == 0x0eU, "x86 cmpop testImm opcode drift");
_Static_assert(0x0fU == 0x0fU, "x86 cmpop testReg opcode drift");
_Static_assert(0x1dU == 0x1dU, "x86 cmpop cmpMemImm opcode drift");
_Static_assert(0x1eU == 0x1eU, "x86 cmpop testMemImm opcode drift");
_Static_assert(0x1fU == 0x1fU, "x86 cmpop cmpMemReg opcode drift");
_Static_assert(0x3bU == 0x3bU, "x86 cmpop testMemReg opcode drift");





_Static_assert(8U == 8U, "x86 width code drift");
# 181 "/workspaces/repository/kprog/x86/x86_sim.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_cmov.h" 1
# 15 "/workspaces/repository/kprog/x86/../formal/generated/x86_cmov.h"
_Static_assert(0x15U == 0x15U, "x86 cmov opcode drift");
_Static_assert(0x40U == 0x40U, "x86 cmov_mem opcode drift");
_Static_assert(8U == 8U, "x86 cmov width drift");
# 182 "/workspaces/repository/kprog/x86/x86_sim.h" 2

_Static_assert(((__u8)(((((__u32)(0xabU) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0x30U) & 0xffU) << 16) | (((__u32)(0x77U) & 0xffU) << 24))) & 0xffU)) == 0xabU,

 "x86 memory AUX index byte drift");
_Static_assert(((__u8)((((((__u32)(0xabU) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0x30U) & 0xffU) << 16) | (((__u32)(0x77U) & 0xffU) << 24))) >> 8) & 0xffU)) == 8U,

 "x86 memory AUX scale byte drift");
_Static_assert(((__u8)((((((__u32)(0xabU) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0x30U) & 0xffU) << 16) | (((__u32)(0x77U) & 0xffU) << 24))) >> 16) & 0xffU)) == 0x30U,

 "x86 memory AUX width byte drift");
_Static_assert(((__u8)((((((__u32)(0xabU) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0x30U) & 0xffU) << 16) | (((__u32)(0x77U) & 0xffU) << 24))) >> 24) & 0xffU)) == 0x77U,

 "x86 memory AUX opcode byte drift");
_Static_assert((((__u32)(0U) & 0xffU) | (((__u32)(0U) & 0xffU) << 8) | (((__u32)(0U) & 0xffU) << 16) | (((__u32)((8U)) & 0xffU) << 24)) == (((__u32)(0U) & 0xffU) | (((__u32)(0U) & 0xffU) << 8) | (((__u32)(0U) & 0xffU) << 16) | (((__u32)((8U)) & 0xffU) << 24)),
 "x86 source-shift and ALU-opcode AUX slots diverge");
_Static_assert(((__u8)(((((__u32)(0xabU) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0U) & 0xffU) << 16))) & 0xffU)) == 0xabU,

 "x86 register AUX payload drift");
_Static_assert(((__u8)((((((__u32)(0U) & 0xffU) | (((__u32)(8U) & 0xffU) << 8) | (((__u32)(0U) & 0xffU) << 16))) >> 8) & 0xffU)) == 8U,

 "x86 register AUX destination lane drift");
_Static_assert(((__u8)((((((__u32)(0U) & 0xffU) | (((__u32)(0U) & 0xffU) << 8) | (((__u32)(8U) & 0xffU) << 16))) >> 16) & 0xffU)) == 8U,

 "x86 register AUX source lane drift");

static inline __attribute__((always_inline)) __u64 x86_width_mask(__u8 width)
{
 return ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)));
}

static inline __attribute__((always_inline)) __u32 x86_width_bits(__u8 width)
{
 return ((width) == 1U ? 8U : ((width) == 2U ? 16U : ((width) == 4U ? 32U : 64U)));
}

static inline __attribute__((always_inline)) __u64 x86_width_sign_mask(__u8 width)
{
 return ((width) == 1U ? 0x80ULL : ((width) == 2U ? 0x8000ULL : ((width) == 4U ? 0x80000000ULL : 0x8000000000000000ULL)));
}

static inline __attribute__((always_inline)) __u64 x86_apply_width(__u64 value, __u8 width)
{
 return ((value) & ((width) == 1U ? 0xffULL : ((width) == 2U ? 0xffffULL : ((width) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL))));
}

static inline __attribute__((always_inline)) __u8 x86_width_effective(__u8 code)
{
 return ((code) != 0U ? (code) : 8U);
}

static inline __attribute__((always_inline)) __u64 x86_sign_extend(__u64 value, __u8 width)
{
 return kprog_x86_sign_extend_value(value, width);
}

static inline __attribute__((always_inline)) __u8 x86_shift_count(__u64 rhs, __u8 width)
{
 return ((rhs) & ((width) == 8U ? 63U : 31U));
}

static inline __attribute__((always_inline)) __u64 x86_signed_abs_width(__u64 value, __u8 width)
{
 return kprog_x86_abs_width_value(value, width);
}

static inline __attribute__((always_inline)) __u64 x86_ror(__u64 value, __u64 shift, __u8 width)
{
 return kprog_x86_ror_result(value, shift, width);
}

static inline __attribute__((always_inline)) __u64 x86_bswap(__u64 value, __u8 width)
{
 return kprog_x86_bswap_value(value, width);
}

static inline __attribute__((always_inline)) __u64 x86_popcount64(__u64 value)
{
 return kprog_x86_popcount_value(value);
}

static inline __attribute__((always_inline)) __u64 x86_alu_result(__u64 lhs, __u64 rhs,
         __u32 alu, __u8 width)
{
 return ({ __u64 __kprog_x86_alu_res = (lhs); switch ((alu)) { case 0U: __kprog_x86_alu_res = (((lhs) + (rhs)) + (!!(0))); break; case 1U: __kprog_x86_alu_res = (((lhs) - (rhs)) - (!!(0))); break; case 2U: __kprog_x86_alu_res = (lhs) ^ (rhs); break; case 3U: __kprog_x86_alu_res = (lhs) | (rhs); break; case 4U: __kprog_x86_alu_res = (lhs) & (rhs); break; case 5U: __kprog_x86_alu_res = kprog_x86_shl_result(lhs, rhs, width); break; case 6U: __kprog_x86_alu_res = kprog_x86_shr_result(lhs, rhs, width); break; case 7U: __kprog_x86_alu_res = kprog_x86_sar_result(lhs, rhs, width); break; case 8U: __kprog_x86_alu_res = kprog_x86_rol_result(lhs, rhs, width); break; case 9U: __kprog_x86_alu_res = (lhs) * (rhs); break; case 10U: __kprog_x86_alu_res = (((lhs) + (1)) + (!!(0))); break; case 11U: __kprog_x86_alu_res = (~(lhs)); break; case 12U: __kprog_x86_alu_res = (((lhs) - (rhs)) - (!!(0))); break; case 13U: __kprog_x86_alu_res = (((lhs) - (1)) - (!!(0))); break; case 14U: __kprog_x86_alu_res = (((0) - (lhs)) - (!!(0))); break; case 15U: __kprog_x86_alu_res = (((lhs) + (rhs)) + (!!(0))); break; default: (void)0; break; } __kprog_x86_alu_res; });
}

static inline __attribute__((always_inline)) __u64 x86_shld(__u64 dst, __u64 src, __u64 shift,
          __u8 width)
{
 return kprog_x86_shld_value(dst, src, shift, width);
}

static inline __attribute__((always_inline)) __u64 x86_shrd(__u64 dst, __u64 src, __u64 shift,
          __u8 width)
{
 return kprog_x86_shrd_value(dst, src, shift, width);
}

static inline __attribute__((always_inline)) __s64 x86_simm(__u64 value)
{
 return (__s64)value;
}

static inline __attribute__((always_inline)) __u64 x86_store_imm_value(__u64 value, __u8 width)
{
 return (((width) == 8U && (((value) & 0x80000000ULL) != 0ULL)) ? (((value) & 0xffffffffULL) | 0xffffffff00000000ULL) : ((value) & 0xffffffffULL));
}

static inline __attribute__((always_inline)) __s32 x86_store_imm_disp(__u64 value)
{
 return (__s32)(value >> 32);
}
# 12 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../../kinsn/module/include/native_lab_input.h" 1
# 13 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/abi_load.h" 1
# 14 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/ptr_add.h" 1
# 15 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_full_condition.h" 1



# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_cond.h" 1




_Static_assert(0U == 0U, "x86 condition code drift");
_Static_assert(1U == 1U, "x86 condition code drift");
_Static_assert(2U == 2U, "x86 condition code drift");
_Static_assert(3U == 3U, "x86 condition code drift");
_Static_assert(4U == 4U, "x86 condition code drift");
_Static_assert(5U == 5U, "x86 condition code drift");
_Static_assert(6U == 6U, "x86 condition code drift");
_Static_assert(7U == 7U, "x86 condition code drift");
_Static_assert(8U == 8U, "x86 condition code drift");
_Static_assert(9U == 9U, "x86 condition code drift");
_Static_assert(12U == 12U, "x86 condition code drift");
_Static_assert(13U == 13U, "x86 condition code drift");
_Static_assert(14U == 14U, "x86 condition code drift");
_Static_assert(15U == 15U, "x86 condition code drift");
# 5 "/workspaces/repository/kprog/x86/../formal/generated/x86_full_condition.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_setcc.h" 1



_Static_assert(0U == 0U, "x86 condition code drift");
_Static_assert(1U == 1U, "x86 condition code drift");
_Static_assert(2U == 2U, "x86 condition code drift");
_Static_assert(3U == 3U, "x86 condition code drift");
_Static_assert(4U == 4U, "x86 condition code drift");
_Static_assert(5U == 5U, "x86 condition code drift");
_Static_assert(6U == 6U, "x86 condition code drift");
_Static_assert(7U == 7U, "x86 condition code drift");
_Static_assert(8U == 8U, "x86 condition code drift");
_Static_assert(9U == 9U, "x86 condition code drift");
_Static_assert(12U == 12U, "x86 condition code drift");
_Static_assert(13U == 13U, "x86 condition code drift");
_Static_assert(14U == 14U, "x86 condition code drift");
_Static_assert(15U == 15U, "x86 condition code drift");

_Static_assert(0xffffU == 0xffffU, "x86 setcc no-match sentinel drift");
# 6 "/workspaces/repository/kprog/x86/../formal/generated/x86_full_condition.h" 2
_Static_assert(10U == 10U, "native parity code drift");
_Static_assert(11U == 11U, "native parity code drift");
# 16 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_logic_flags.h" 1
# 17 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_sub_flags.h" 1
# 18 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_add_flags.h" 1
# 19 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_aux_flags.h" 1
# 20 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2

# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_sbb_flags.h" 1
# 22 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2

# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_shift_flags.h" 1
# 24 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_imul_flags.h" 1
# 25 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mem_access.h" 1






typedef unsigned char kprog_x86_unaligned8 __attribute__((aligned(1),may_alias));
typedef unsigned short kprog_x86_unaligned16 __attribute__((aligned(1),may_alias));
typedef unsigned int kprog_x86_unaligned32 __attribute__((aligned(1),may_alias));
typedef __u64 kprog_x86_unaligned64 __attribute__((aligned(1),may_alias));
static __attribute__((always_inline)) inline __u64
kprog_x86_mem_load(const void *address, __u8 width)
{

    __u64 value;

    switch (width ? width : 8U) {
    case 1U:

        asm volatile("%0 = *(u8 *)(%1 + 0)" : "=r"(value) : "r"(address) : "memory");
        return (__u8)value;



    case 2U:

        asm volatile("%0 = *(u16 *)(%1 + 0)" : "=r"(value) : "r"(address) : "memory");
        return (__u16)value;



    case 4U:

        asm volatile("%0 = *(u32 *)(%1 + 0)" : "=r"(value) : "r"(address) : "memory");
        return (__u32)value;



    case 8U:

        asm volatile("%0 = *(u64 *)(%1 + 0)" : "=r"(value) : "r"(address) : "memory");
        return value;



    default: __builtin_trap();
    }
}



static __attribute__((always_inline)) inline __u64
kprog_x86_mem_load_fixed(const void *base, long long displacement, __u8 width)
{

    if (!__builtin_constant_p(displacement) || displacement < -32768 || displacement > 32767)
        return kprog_x86_mem_load((const __u8 *)base + displacement, width);
    __u64 value;
    switch (width ? width : 8U) {
    case 1U:
        if (displacement < 0)
            asm volatile("%0 = *(u8 *)(%1 - %2)" : "=r"(value) : "r"(base), "i"(-displacement) : "memory");
        else
            asm volatile("%0 = *(u8 *)(%1 + %2)" : "=r"(value) : "r"(base), "i"(displacement) : "memory");
        return (__u8)value;
    case 2U:
        if (displacement < 0)
            asm volatile("%0 = *(u16 *)(%1 - %2)" : "=r"(value) : "r"(base), "i"(-displacement) : "memory");
        else
            asm volatile("%0 = *(u16 *)(%1 + %2)" : "=r"(value) : "r"(base), "i"(displacement) : "memory");
        return (__u16)value;
    case 4U:
        if (displacement < 0)
            asm volatile("%0 = *(u32 *)(%1 - %2)" : "=r"(value) : "r"(base), "i"(-displacement) : "memory");
        else
            asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(value) : "r"(base), "i"(displacement) : "memory");
        return (__u32)value;
    case 8U:
        if (displacement < 0)
            asm volatile("%0 = *(u64 *)(%1 - %2)" : "=r"(value) : "r"(base), "i"(-displacement) : "memory");
        else
            asm volatile("%0 = *(u64 *)(%1 + %2)" : "=r"(value) : "r"(base), "i"(displacement) : "memory");
        return value;
    default: __builtin_trap();
    }



}
static __attribute__((always_inline)) inline void
kprog_x86_mem_store(void *address, __u8 width, __u64 value)
{
    switch (width ? width : 8U) {
    case 1U:

        asm volatile("*(u8 *)(%0 + 0) = %1" : : "r"(address), "r"(value) : "memory");



        return;
    case 2U:

        asm volatile("*(u16 *)(%0 + 0) = %1" : : "r"(address), "r"(value) : "memory");



        return;
    case 4U:

        asm volatile("*(u32 *)(%0 + 0) = %1" : : "r"(address), "r"(value) : "memory");



        return;
    case 8U:

        asm volatile("*(u64 *)(%0 + 0) = %1" : : "r"(address), "r"(value) : "memory");



        return;
    default: __builtin_trap();
    }
}
# 26 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_write.h" 1
# 27 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_read.h" 1
# 28 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_rep_movs.h" 1
# 13 "/workspaces/repository/kprog/x86/../formal/generated/x86_rep_movs.h"
_Static_assert(0x3aU == 0x3aU, "x86 rep_movs opcode drift");





_Static_assert(8U == 8U, "x86 width code drift");
# 29 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2

# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_setcc_mem.h" 1
# 16 "/workspaces/repository/kprog/x86/../formal/generated/x86_setcc_mem.h"
_Static_assert(0xffU == 0xffU,
        "x86 setcc_mem null-base register drift");
_Static_assert(4U == 4U,
        "x86 setcc_mem stack register drift");
_Static_assert(1U == 1U,
        "x86 setcc_mem width drift");
_Static_assert(0x3eU == 0x3eU, "x86 setcc_mem opcode drift");
# 31 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_branch_emit.h" 1
# 32 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mem_index.h" 1
# 33 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_presence.h" 1
# 34 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_dispatch.h" 1
# 27 "/workspaces/repository/kprog/x86/../formal/generated/x86_reg_dispatch.h"
_Static_assert(0U == 0U, "x86 gpr dispatch number drift");
_Static_assert(1U == 1U, "x86 gpr dispatch number drift");
_Static_assert(2U == 2U, "x86 gpr dispatch number drift");
_Static_assert(3U == 3U, "x86 gpr dispatch number drift");
_Static_assert(4U == 4U, "x86 gpr dispatch number drift");
_Static_assert(5U == 5U, "x86 gpr dispatch number drift");
_Static_assert(6U == 6U, "x86 gpr dispatch number drift");
_Static_assert(7U == 7U, "x86 gpr dispatch number drift");
_Static_assert(8U == 8U, "x86 gpr dispatch number drift");
_Static_assert(9U == 9U, "x86 gpr dispatch number drift");
_Static_assert(10U == 10U, "x86 gpr dispatch number drift");
_Static_assert(11U == 11U, "x86 gpr dispatch number drift");
_Static_assert(12U == 12U, "x86 gpr dispatch number drift");
_Static_assert(13U == 13U, "x86 gpr dispatch number drift");
_Static_assert(14U == 14U, "x86 gpr dispatch number drift");
_Static_assert(15U == 15U, "x86 gpr dispatch number drift");
_Static_assert(16U == 16U,
        "x86 gpr dispatch count drift");
# 35 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_xchg.h" 1
# 41 "/workspaces/repository/kprog/x86/../formal/generated/x86_xchg.h"
_Static_assert(0x19U == 25U,
        "x86 xchg opcode drift");
_Static_assert(8U == 8U,
        "x86 xchg full-width code drift");
_Static_assert(2U == 2U,
        "x86 xchg arm count drift");
_Static_assert(0U != 1U,
        "x86 xchg arm codes must be distinct");

_Static_assert((((__u8)((8U))) == 8U ? 0U : 1U) == 0U, "x86 xchg width arm drift");
_Static_assert((((__u8)((4U))) == 8U ? 0U : 1U) == 1U, "x86 xchg width arm drift");
_Static_assert((((__u8)((2U))) == 8U ? 0U : 1U) == 1U, "x86 xchg width arm drift");
_Static_assert((((__u8)((1U))) == 8U ? 0U : 1U) == 1U, "x86 xchg width arm drift");
# 36 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_div.h" 1
# 46 "/workspaces/repository/kprog/x86/../formal/generated/x86_div.h"
_Static_assert(0x1aU == 26U,
        "x86 div opcode drift");
_Static_assert(4U == 4U,
        "x86 div arm count drift");
_Static_assert(0U != 3U,
        "x86 div arm codes must be distinct");

_Static_assert(( (((__u8)((1U))) == 1U) ? 0U : ( (((__u8)((1U))) == 2U) ? 1U : ( (((__u8)((1U))) == 4U) ? 2U : 3U))) == 0U, "x86 div width arm drift");
_Static_assert(( (((__u8)((2U))) == 1U) ? 0U : ( (((__u8)((2U))) == 2U) ? 1U : ( (((__u8)((2U))) == 4U) ? 2U : 3U))) == 1U, "x86 div width arm drift");
_Static_assert(( (((__u8)((4U))) == 1U) ? 0U : ( (((__u8)((4U))) == 2U) ? 1U : ( (((__u8)((4U))) == 4U) ? 2U : 3U))) == 2U, "x86 div width arm drift");
_Static_assert(( (((__u8)((8U))) == 1U) ? 0U : ( (((__u8)((8U))) == 2U) ? 1U : ( (((__u8)((8U))) == 4U) ? 2U : 3U))) == 3U, "x86 div width arm drift");

_Static_assert(( (((__u8)((0))) == 1U) ? 0U : ( (((__u8)((0))) == 2U) ? 1U : ( (((__u8)((0))) == 4U) ? 2U : 3U))) == 3U,
        "x86 div absent code must reach the default arm");
# 37 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_doubleshift_arm.h" 1
# 38 "/workspaces/repository/kprog/x86/../formal/generated/x86_doubleshift_arm.h"
_Static_assert(2U == 2U,
        "x86 doubleshift arm count drift");



_Static_assert(0x1bU == 27U,
        "x86 doubleshift arm shld opcode drift");
_Static_assert(0x1cU == 28U,
        "x86 doubleshift arm shrd opcode drift");
_Static_assert(5U == 5U,
        "x86 doubleshift arm shld flag family drift");
_Static_assert(6U == 6U,
        "x86 doubleshift arm shrd flag family drift");
_Static_assert(0U != 1U,
        "x86 doubleshift arm codes must be distinct");
_Static_assert(5U != 6U,
        "x86 doubleshift arm flag families must be distinct");

_Static_assert((((__u8)((0x1bU))) == 0x1bU ? 0U : 1U) == 0U,
        "x86 doubleshift arm shld selection drift");
_Static_assert((((__u8)((0x1cU))) == 0x1bU ? 0U : 1U) == 1U,
        "x86 doubleshift arm shrd selection drift");

_Static_assert((((__u8)((0x1bU))) == 0x1bU ? 5U : 6U) == 5U,
        "x86 doubleshift arm shld flag family selection drift");
_Static_assert((((__u8)((0x1cU))) == 0x1bU ? 5U : 6U) == 6U,
        "x86 doubleshift arm shrd flag family selection drift");


_Static_assert((((__u8)((0))) == 0x1bU ? 0U : 1U) == 1U,
        "x86 doubleshift arm absent opcode must reach the default arm");
# 38 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_popcnt_flags.h" 1
# 18 "/workspaces/repository/kprog/x86/../formal/generated/x86_popcnt_flags.h"
_Static_assert(0x18U == 24U,
        "x86 popcnt opcode drift");
# 39 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_movx_shape.h" 1
# 37 "/workspaces/repository/kprog/x86/../formal/generated/x86_movx_shape.h"
_Static_assert(2U == 2U,
        "x86 movx shape count drift");
_Static_assert(0x21U == 33U,
        "x86 movx shape sign_extend opcode drift");
_Static_assert(0x20U == 32U,
        "x86 movx shape zero_extend opcode drift");
_Static_assert(0U != 1U,
        "x86 movx shape arm codes must be distinct");

_Static_assert((((__u8)((0x21U))) == 0x21U ? 0U : 1U) == 0U,
        "x86 movx shape sign_extend selection drift");
_Static_assert((((__u8)((0x20U))) == 0x21U ? 0U : 1U) == 1U,
        "x86 movx shape zero_extend selection drift");


_Static_assert((((__u8)((0))) == 0x21U ? 0U : 1U) == 1U,
        "x86 movx shape absent opcode must reach the default arm");
# 72 "/workspaces/repository/kprog/x86/../formal/generated/x86_movx_shape.h"
_Static_assert(0U == 0U,
        "x86 movx source width absent code drift");



_Static_assert(
 (((__u8)((1U))) == 0U ? (__u8)((8U)) : (__u8)((1U))) == 1U,
 "x86 movx source width w8 must be its own source width");
_Static_assert(
 (((__u8)((2U))) == 0U ? (__u8)((8U)) : (__u8)((2U))) == 2U,
 "x86 movx source width w16 must be its own source width");
_Static_assert(
 (((__u8)((4U))) == 0U ? (__u8)((8U)) : (__u8)((4U))) == 4U,
 "x86 movx source width w32 must be its own source width");
_Static_assert(
 (((__u8)((8U))) == 0U ? (__u8)((8U)) : (__u8)((8U))) == 8U,
 "x86 movx source width w64 must be its own source width");

_Static_assert(0U != 1U,
 "x86 movx source width absent code collides with w8");
_Static_assert(0U != 2U,
 "x86 movx source width absent code collides with w16");
_Static_assert(0U != 4U,
 "x86 movx source width absent code collides with w32");
_Static_assert(0U != 8U,
 "x86 movx source width absent code collides with w64");


_Static_assert(
 (((__u8)((0U))) == 0U ? (__u8)((8U)) : (__u8)((0U))) == 8U,

 "x86 movx source width absent field must fall back to the effective width");
# 40 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mov_reg_arm.h" 1
# 42 "/workspaces/repository/kprog/x86/../formal/generated/x86_mov_reg_arm.h"
_Static_assert(0x02U == 2U,
        "x86 mov_reg arm opcode drift");
_Static_assert(8U == 8U,
        "x86 mov_reg arm full-width code drift");
_Static_assert(4U == 4U,
        "x86 mov_reg arm stack-pointer code drift");
_Static_assert(3U == 3U,
        "x86 mov_reg arm count drift");
_Static_assert(0U != 1U && 1U != 2U && 0U != 2U,
        "x86 mov_reg arm codes must be distinct");

_Static_assert(((((__u8)((8U))) == 8U) ? ((((__u8)((4U))) == 4U) ? 0U : 1U) : 2U) == 0U, "x86 mov_reg arm stack-ptr selection drift");
_Static_assert(((((__u8)((8U))) == 8U) ? ((((__u8)((0U))) == 4U) ? 0U : 1U) : 2U) == 1U,
        "x86 mov_reg arm pointer selection drift");
_Static_assert(((((__u8)((4U))) == 8U) ? ((((__u8)((4U))) == 4U) ? 0U : 1U) : 2U) == 2U,
        "x86 mov_reg arm narrow selection ignores rsp drift");
_Static_assert(((((__u8)((1U))) == 8U) ? ((((__u8)((0U))) == 4U) ? 0U : 1U) : 2U) == 2U,
        "x86 mov_reg arm narrow selection drift");
# 41 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_arm.h" 1
# 32 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_arm.h"
_Static_assert(8U == 8U,
        "x86 stack arm 64-bit width code drift");
_Static_assert(8U == 8U,
        "x86 stack arm 64-bit width code drift");
_Static_assert(2U == 2U,
        "x86 stack arm count drift");
_Static_assert(1U != 0U,
        "x86 stack arm codes must be distinct");
_Static_assert(1U == 1U && 0U == 0U,
        "x86 stack arm code drift");

_Static_assert(((__u8)(((1) && (1)) ? 1 : 0)) == 1U,
        "x86 stack arm word selection drift");
_Static_assert(((__u8)(((1) && (0)) ? 1 : 0)) == 0U,
        "x86 stack arm unaligned selection drift");
_Static_assert(((__u8)(((0) && (1)) ? 1 : 0)) == 0U,
        "x86 stack arm narrow selection drift");
_Static_assert(((__u8)(((0) && (0)) ? 1 : 0)) == 0U,
        "x86 stack arm narrow unaligned selection drift");
# 42 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mulx_arm.h" 1
# 38 "/workspaces/repository/kprog/x86/../formal/generated/x86_mulx_arm.h"
_Static_assert(0x39U == 57U,
        "x86 mulx opcode drift");
_Static_assert(4U == 4U,
        "x86 mulx special-width code drift");
_Static_assert(2U == 2U,
        "x86 mulx arm count drift");
_Static_assert(0U != 1U,
        "x86 mulx arm codes must be distinct");

_Static_assert((((__u8)((4U))) == 4U ? 0U : 1U) == 0U, "x86 mulx width arm drift");
_Static_assert((((__u8)((1U))) == 4U ? 0U : 1U) == 1U, "x86 mulx width arm drift");
_Static_assert((((__u8)((2U))) == 4U ? 0U : 1U) == 1U, "x86 mulx width arm drift");
_Static_assert((((__u8)((8U))) == 4U ? 0U : 1U) == 1U, "x86 mulx width arm drift");
# 43 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_bzhi_flags.h" 1
# 12 "/workspaces/repository/kprog/x86/../formal/generated/x86_bzhi_flags.h"
_Static_assert(0x34U == 52U,
        "x86 bzhi opcode drift");
_Static_assert(0x35U == 53U,
        "x86 bzhi opcode drift");
# 44 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_write_width_arm.h" 1
# 45 "/workspaces/repository/kprog/x86/../formal/generated/x86_write_width_arm.h"
_Static_assert(4U == 4U,
        "x86 write width arm count drift");
_Static_assert(0U != 3U,
        "x86 write width arm codes must be distinct");

_Static_assert(( (((__u8)((1U))) == 1U) ? 0U : ( (((__u8)((1U))) == 2U) ? 1U : ( (((__u8)((1U))) == 4U) ? 2U : 3U))) == 0U, "x86 write width arm drift");
_Static_assert(( (((__u8)((2U))) == 1U) ? 0U : ( (((__u8)((2U))) == 2U) ? 1U : ( (((__u8)((2U))) == 4U) ? 2U : 3U))) == 1U, "x86 write width arm drift");
_Static_assert(( (((__u8)((4U))) == 1U) ? 0U : ( (((__u8)((4U))) == 2U) ? 1U : ( (((__u8)((4U))) == 4U) ? 2U : 3U))) == 2U, "x86 write width arm drift");
_Static_assert(( (((__u8)((8U))) == 1U) ? 0U : ( (((__u8)((8U))) == 2U) ? 1U : ( (((__u8)((8U))) == 4U) ? 2U : 3U))) == 3U, "x86 write width arm drift");

_Static_assert(( (((__u8)((0))) == 1U) ? 0U : ( (((__u8)((0))) == 2U) ? 1U : ( (((__u8)((0))) == 4U) ? 2U : 3U))) == 3U,
        "x86 write width absent code must reach the default body");
# 45 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_write_lanes.h" 1
# 52 "/workspaces/repository/kprog/x86/../formal/generated/x86_stack_write_lanes.h"
_Static_assert(1U == 1U, "x86 stack write lanes width code drift");
_Static_assert(2U == 2U, "x86 stack write lanes width code drift");
_Static_assert(4U == 4U, "x86 stack write lanes width code drift");
_Static_assert(8U == 8U, "x86 stack write lanes width code drift");
_Static_assert(8U == 8U,
        "x86 stack write lanes slot count drift");

_Static_assert(((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) == 0x01U,
        "x86 stack write lanes mask drift");
_Static_assert(((1U) == 1U ? 1U : ((1U) == 2U ? 2U : ((1U) == 4U ? 4U : 8U))) == 1U,
        "x86 stack write lanes count drift");
_Static_assert(((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) == 0x03U,
        "x86 stack write lanes mask drift");
_Static_assert(((2U) == 1U ? 1U : ((2U) == 2U ? 2U : ((2U) == 4U ? 4U : 8U))) == 2U,
        "x86 stack write lanes count drift");
_Static_assert(((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) == 0x0fU,
        "x86 stack write lanes mask drift");
_Static_assert(((4U) == 1U ? 1U : ((4U) == 2U ? 2U : ((4U) == 4U ? 4U : 8U))) == 4U,
        "x86 stack write lanes count drift");
_Static_assert(((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) == 0xffU,
        "x86 stack write lanes mask drift");
_Static_assert(((8U) == 1U ? 1U : ((8U) == 2U ? 2U : ((8U) == 4U ? 4U : 8U))) == 8U,
        "x86 stack write lanes count drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (0)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((1U) == 1U ? 0x01U : ((1U) == 2U ? 0x03U : ((1U) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (0)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((2U) == 1U ? 0x01U : ((2U) == 2U ? 0x03U : ((2U) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (0)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((4U) == 1U ? 0x01U : ((4U) == 2U ? 0x03U : ((4U) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U)) == 0U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (0)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
_Static_assert(((__u8)((((8U) == 1U ? 0x01U : ((8U) == 2U ? 0x03U : ((8U) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U)) == 1U,
        "x86 stack write lanes activation drift");
# 46 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_alu_flag_arm.h" 1
# 68 "/workspaces/repository/kprog/x86/../formal/generated/x86_alu_flag_arm.h"
_Static_assert(10U == 10U,
        "x86 alu flag arm count drift");
_Static_assert(0U == 0U,
        "x86 alu flag arm add token drift");
_Static_assert(15U == 15U,
        "x86 alu flag arm add token drift");
_Static_assert(10U == 10U,
        "x86 alu flag arm inc token drift");
_Static_assert(13U == 13U,
        "x86 alu flag arm dec token drift");
_Static_assert(1U == 1U,
        "x86 alu flag arm sub token drift");
_Static_assert(12U == 12U,
        "x86 alu flag arm sbb token drift");
_Static_assert(14U == 14U,
        "x86 alu flag arm neg token drift");
_Static_assert(11U == 11U,
        "x86 alu flag arm not token drift");
_Static_assert(5U == 5U,
        "x86 alu flag arm shift token drift");
_Static_assert(6U == 6U,
        "x86 alu flag arm shift token drift");
_Static_assert(7U == 7U,
        "x86 alu flag arm shift token drift");
_Static_assert(8U == 8U,
        "x86 alu flag arm shift token drift");
_Static_assert(9U == 9U,
        "x86 alu flag arm imul token drift");
_Static_assert(2U == 2U,
        "x86 alu flag arm logic token drift");
_Static_assert(3U == 3U,
        "x86 alu flag arm logic token drift");
_Static_assert(4U == 4U,
        "x86 alu flag arm logic token drift");
_Static_assert(0U != 1U && 0U != 2U && 0U != 3U && 0U != 4U && 0U != 5U && 0U != 6U && 0U != 7U && 0U != 8U && 0U != 9U && 1U != 2U && 1U != 3U && 1U != 4U && 1U != 5U && 1U != 6U && 1U != 7U && 1U != 8U && 1U != 9U && 2U != 3U && 2U != 4U && 2U != 5U && 2U != 6U && 2U != 7U && 2U != 8U && 2U != 9U && 3U != 4U && 3U != 5U && 3U != 6U && 3U != 7U && 3U != 8U && 3U != 9U && 4U != 5U && 4U != 6U && 4U != 7U && 4U != 8U && 4U != 9U && 5U != 6U && 5U != 7U && 5U != 8U && 5U != 9U && 6U != 7U && 6U != 8U && 6U != 9U && 7U != 8U && 7U != 9U && 8U != 9U,
        "x86 alu flag arm codes must be distinct");

_Static_assert(( (((__u8)((0U))) == 0U) ? 0U : ( (((__u8)((0U))) == 15U) ? 0U : ( (((__u8)((0U))) == 10U) ? 1U : ( (((__u8)((0U))) == 13U) ? 2U : ( (((__u8)((0U))) == 1U) ? 3U : ( (((__u8)((0U))) == 12U) ? 4U : ( (((__u8)((0U))) == 14U) ? 5U : ( (((__u8)((0U))) == 11U) ? 6U : ( (((__u8)((0U))) == 5U) ? 7U : ( (((__u8)((0U))) == 6U) ? 7U : ( (((__u8)((0U))) == 7U) ? 7U : ( (((__u8)((0U))) == 8U) ? 7U : ( (((__u8)((0U))) == 9U) ? 8U : 9U))))))))))))) == 0U,
        "x86 alu flag arm add selection drift");
_Static_assert(( (((__u8)((15U))) == 0U) ? 0U : ( (((__u8)((15U))) == 15U) ? 0U : ( (((__u8)((15U))) == 10U) ? 1U : ( (((__u8)((15U))) == 13U) ? 2U : ( (((__u8)((15U))) == 1U) ? 3U : ( (((__u8)((15U))) == 12U) ? 4U : ( (((__u8)((15U))) == 14U) ? 5U : ( (((__u8)((15U))) == 11U) ? 6U : ( (((__u8)((15U))) == 5U) ? 7U : ( (((__u8)((15U))) == 6U) ? 7U : ( (((__u8)((15U))) == 7U) ? 7U : ( (((__u8)((15U))) == 8U) ? 7U : ( (((__u8)((15U))) == 9U) ? 8U : 9U))))))))))))) == 0U,
        "x86 alu flag arm add selection drift");
_Static_assert(( (((__u8)((10U))) == 0U) ? 0U : ( (((__u8)((10U))) == 15U) ? 0U : ( (((__u8)((10U))) == 10U) ? 1U : ( (((__u8)((10U))) == 13U) ? 2U : ( (((__u8)((10U))) == 1U) ? 3U : ( (((__u8)((10U))) == 12U) ? 4U : ( (((__u8)((10U))) == 14U) ? 5U : ( (((__u8)((10U))) == 11U) ? 6U : ( (((__u8)((10U))) == 5U) ? 7U : ( (((__u8)((10U))) == 6U) ? 7U : ( (((__u8)((10U))) == 7U) ? 7U : ( (((__u8)((10U))) == 8U) ? 7U : ( (((__u8)((10U))) == 9U) ? 8U : 9U))))))))))))) == 1U,
        "x86 alu flag arm inc selection drift");
_Static_assert(( (((__u8)((13U))) == 0U) ? 0U : ( (((__u8)((13U))) == 15U) ? 0U : ( (((__u8)((13U))) == 10U) ? 1U : ( (((__u8)((13U))) == 13U) ? 2U : ( (((__u8)((13U))) == 1U) ? 3U : ( (((__u8)((13U))) == 12U) ? 4U : ( (((__u8)((13U))) == 14U) ? 5U : ( (((__u8)((13U))) == 11U) ? 6U : ( (((__u8)((13U))) == 5U) ? 7U : ( (((__u8)((13U))) == 6U) ? 7U : ( (((__u8)((13U))) == 7U) ? 7U : ( (((__u8)((13U))) == 8U) ? 7U : ( (((__u8)((13U))) == 9U) ? 8U : 9U))))))))))))) == 2U,
        "x86 alu flag arm dec selection drift");
_Static_assert(( (((__u8)((1U))) == 0U) ? 0U : ( (((__u8)((1U))) == 15U) ? 0U : ( (((__u8)((1U))) == 10U) ? 1U : ( (((__u8)((1U))) == 13U) ? 2U : ( (((__u8)((1U))) == 1U) ? 3U : ( (((__u8)((1U))) == 12U) ? 4U : ( (((__u8)((1U))) == 14U) ? 5U : ( (((__u8)((1U))) == 11U) ? 6U : ( (((__u8)((1U))) == 5U) ? 7U : ( (((__u8)((1U))) == 6U) ? 7U : ( (((__u8)((1U))) == 7U) ? 7U : ( (((__u8)((1U))) == 8U) ? 7U : ( (((__u8)((1U))) == 9U) ? 8U : 9U))))))))))))) == 3U,
        "x86 alu flag arm sub selection drift");
_Static_assert(( (((__u8)((12U))) == 0U) ? 0U : ( (((__u8)((12U))) == 15U) ? 0U : ( (((__u8)((12U))) == 10U) ? 1U : ( (((__u8)((12U))) == 13U) ? 2U : ( (((__u8)((12U))) == 1U) ? 3U : ( (((__u8)((12U))) == 12U) ? 4U : ( (((__u8)((12U))) == 14U) ? 5U : ( (((__u8)((12U))) == 11U) ? 6U : ( (((__u8)((12U))) == 5U) ? 7U : ( (((__u8)((12U))) == 6U) ? 7U : ( (((__u8)((12U))) == 7U) ? 7U : ( (((__u8)((12U))) == 8U) ? 7U : ( (((__u8)((12U))) == 9U) ? 8U : 9U))))))))))))) == 4U,
        "x86 alu flag arm sbb selection drift");
_Static_assert(( (((__u8)((14U))) == 0U) ? 0U : ( (((__u8)((14U))) == 15U) ? 0U : ( (((__u8)((14U))) == 10U) ? 1U : ( (((__u8)((14U))) == 13U) ? 2U : ( (((__u8)((14U))) == 1U) ? 3U : ( (((__u8)((14U))) == 12U) ? 4U : ( (((__u8)((14U))) == 14U) ? 5U : ( (((__u8)((14U))) == 11U) ? 6U : ( (((__u8)((14U))) == 5U) ? 7U : ( (((__u8)((14U))) == 6U) ? 7U : ( (((__u8)((14U))) == 7U) ? 7U : ( (((__u8)((14U))) == 8U) ? 7U : ( (((__u8)((14U))) == 9U) ? 8U : 9U))))))))))))) == 5U,
        "x86 alu flag arm neg selection drift");
_Static_assert(( (((__u8)((11U))) == 0U) ? 0U : ( (((__u8)((11U))) == 15U) ? 0U : ( (((__u8)((11U))) == 10U) ? 1U : ( (((__u8)((11U))) == 13U) ? 2U : ( (((__u8)((11U))) == 1U) ? 3U : ( (((__u8)((11U))) == 12U) ? 4U : ( (((__u8)((11U))) == 14U) ? 5U : ( (((__u8)((11U))) == 11U) ? 6U : ( (((__u8)((11U))) == 5U) ? 7U : ( (((__u8)((11U))) == 6U) ? 7U : ( (((__u8)((11U))) == 7U) ? 7U : ( (((__u8)((11U))) == 8U) ? 7U : ( (((__u8)((11U))) == 9U) ? 8U : 9U))))))))))))) == 6U,
        "x86 alu flag arm not selection drift");
_Static_assert(( (((__u8)((5U))) == 0U) ? 0U : ( (((__u8)((5U))) == 15U) ? 0U : ( (((__u8)((5U))) == 10U) ? 1U : ( (((__u8)((5U))) == 13U) ? 2U : ( (((__u8)((5U))) == 1U) ? 3U : ( (((__u8)((5U))) == 12U) ? 4U : ( (((__u8)((5U))) == 14U) ? 5U : ( (((__u8)((5U))) == 11U) ? 6U : ( (((__u8)((5U))) == 5U) ? 7U : ( (((__u8)((5U))) == 6U) ? 7U : ( (((__u8)((5U))) == 7U) ? 7U : ( (((__u8)((5U))) == 8U) ? 7U : ( (((__u8)((5U))) == 9U) ? 8U : 9U))))))))))))) == 7U,
        "x86 alu flag arm shift selection drift");
_Static_assert(( (((__u8)((6U))) == 0U) ? 0U : ( (((__u8)((6U))) == 15U) ? 0U : ( (((__u8)((6U))) == 10U) ? 1U : ( (((__u8)((6U))) == 13U) ? 2U : ( (((__u8)((6U))) == 1U) ? 3U : ( (((__u8)((6U))) == 12U) ? 4U : ( (((__u8)((6U))) == 14U) ? 5U : ( (((__u8)((6U))) == 11U) ? 6U : ( (((__u8)((6U))) == 5U) ? 7U : ( (((__u8)((6U))) == 6U) ? 7U : ( (((__u8)((6U))) == 7U) ? 7U : ( (((__u8)((6U))) == 8U) ? 7U : ( (((__u8)((6U))) == 9U) ? 8U : 9U))))))))))))) == 7U,
        "x86 alu flag arm shift selection drift");
_Static_assert(( (((__u8)((7U))) == 0U) ? 0U : ( (((__u8)((7U))) == 15U) ? 0U : ( (((__u8)((7U))) == 10U) ? 1U : ( (((__u8)((7U))) == 13U) ? 2U : ( (((__u8)((7U))) == 1U) ? 3U : ( (((__u8)((7U))) == 12U) ? 4U : ( (((__u8)((7U))) == 14U) ? 5U : ( (((__u8)((7U))) == 11U) ? 6U : ( (((__u8)((7U))) == 5U) ? 7U : ( (((__u8)((7U))) == 6U) ? 7U : ( (((__u8)((7U))) == 7U) ? 7U : ( (((__u8)((7U))) == 8U) ? 7U : ( (((__u8)((7U))) == 9U) ? 8U : 9U))))))))))))) == 7U,
        "x86 alu flag arm shift selection drift");
_Static_assert(( (((__u8)((8U))) == 0U) ? 0U : ( (((__u8)((8U))) == 15U) ? 0U : ( (((__u8)((8U))) == 10U) ? 1U : ( (((__u8)((8U))) == 13U) ? 2U : ( (((__u8)((8U))) == 1U) ? 3U : ( (((__u8)((8U))) == 12U) ? 4U : ( (((__u8)((8U))) == 14U) ? 5U : ( (((__u8)((8U))) == 11U) ? 6U : ( (((__u8)((8U))) == 5U) ? 7U : ( (((__u8)((8U))) == 6U) ? 7U : ( (((__u8)((8U))) == 7U) ? 7U : ( (((__u8)((8U))) == 8U) ? 7U : ( (((__u8)((8U))) == 9U) ? 8U : 9U))))))))))))) == 7U,
        "x86 alu flag arm shift selection drift");
_Static_assert(( (((__u8)((9U))) == 0U) ? 0U : ( (((__u8)((9U))) == 15U) ? 0U : ( (((__u8)((9U))) == 10U) ? 1U : ( (((__u8)((9U))) == 13U) ? 2U : ( (((__u8)((9U))) == 1U) ? 3U : ( (((__u8)((9U))) == 12U) ? 4U : ( (((__u8)((9U))) == 14U) ? 5U : ( (((__u8)((9U))) == 11U) ? 6U : ( (((__u8)((9U))) == 5U) ? 7U : ( (((__u8)((9U))) == 6U) ? 7U : ( (((__u8)((9U))) == 7U) ? 7U : ( (((__u8)((9U))) == 8U) ? 7U : ( (((__u8)((9U))) == 9U) ? 8U : 9U))))))))))))) == 8U,
        "x86 alu flag arm imul selection drift");


_Static_assert(( (((__u8)((2U))) == 0U) ? 0U : ( (((__u8)((2U))) == 15U) ? 0U : ( (((__u8)((2U))) == 10U) ? 1U : ( (((__u8)((2U))) == 13U) ? 2U : ( (((__u8)((2U))) == 1U) ? 3U : ( (((__u8)((2U))) == 12U) ? 4U : ( (((__u8)((2U))) == 14U) ? 5U : ( (((__u8)((2U))) == 11U) ? 6U : ( (((__u8)((2U))) == 5U) ? 7U : ( (((__u8)((2U))) == 6U) ? 7U : ( (((__u8)((2U))) == 7U) ? 7U : ( (((__u8)((2U))) == 8U) ? 7U : ( (((__u8)((2U))) == 9U) ? 8U : 9U))))))))))))) == 9U,
        "x86 alu flag arm default body drift");
_Static_assert(( (((__u8)((3U))) == 0U) ? 0U : ( (((__u8)((3U))) == 15U) ? 0U : ( (((__u8)((3U))) == 10U) ? 1U : ( (((__u8)((3U))) == 13U) ? 2U : ( (((__u8)((3U))) == 1U) ? 3U : ( (((__u8)((3U))) == 12U) ? 4U : ( (((__u8)((3U))) == 14U) ? 5U : ( (((__u8)((3U))) == 11U) ? 6U : ( (((__u8)((3U))) == 5U) ? 7U : ( (((__u8)((3U))) == 6U) ? 7U : ( (((__u8)((3U))) == 7U) ? 7U : ( (((__u8)((3U))) == 8U) ? 7U : ( (((__u8)((3U))) == 9U) ? 8U : 9U))))))))))))) == 9U,
        "x86 alu flag arm default body drift");
_Static_assert(( (((__u8)((4U))) == 0U) ? 0U : ( (((__u8)((4U))) == 15U) ? 0U : ( (((__u8)((4U))) == 10U) ? 1U : ( (((__u8)((4U))) == 13U) ? 2U : ( (((__u8)((4U))) == 1U) ? 3U : ( (((__u8)((4U))) == 12U) ? 4U : ( (((__u8)((4U))) == 14U) ? 5U : ( (((__u8)((4U))) == 11U) ? 6U : ( (((__u8)((4U))) == 5U) ? 7U : ( (((__u8)((4U))) == 6U) ? 7U : ( (((__u8)((4U))) == 7U) ? 7U : ( (((__u8)((4U))) == 8U) ? 7U : ( (((__u8)((4U))) == 9U) ? 8U : 9U))))))))))))) == 9U,
        "x86 alu flag arm default body drift");
_Static_assert(( (((__u8)((0xffU))) == 0U) ? 0U : ( (((__u8)((0xffU))) == 15U) ? 0U : ( (((__u8)((0xffU))) == 10U) ? 1U : ( (((__u8)((0xffU))) == 13U) ? 2U : ( (((__u8)((0xffU))) == 1U) ? 3U : ( (((__u8)((0xffU))) == 12U) ? 4U : ( (((__u8)((0xffU))) == 14U) ? 5U : ( (((__u8)((0xffU))) == 11U) ? 6U : ( (((__u8)((0xffU))) == 5U) ? 7U : ( (((__u8)((0xffU))) == 6U) ? 7U : ( (((__u8)((0xffU))) == 7U) ? 7U : ( (((__u8)((0xffU))) == 8U) ? 7U : ( (((__u8)((0xffU))) == 9U) ? 8U : 9U))))))))))))) == 9U,
        "x86 alu flag arm unknown token must reach the default body");
# 47 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_family.h" 1
# 18 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_family.h"
_Static_assert(0x2cU == 44U, "x86 dispatch family code drift");
_Static_assert(0x2dU == 45U, "x86 dispatch family code drift");
_Static_assert(0x20U == 32U, "x86 dispatch family code drift");
_Static_assert(0x21U == 33U, "x86 dispatch family code drift");
_Static_assert(0x06U == 6U, "x86 dispatch family code drift");
_Static_assert(0x25U == 37U, "x86 dispatch family code drift");
_Static_assert(0x22U == 34U, "x86 dispatch family code drift");
_Static_assert(0x07U == 7U, "x86 dispatch family code drift");
_Static_assert(0x08U == 8U, "x86 dispatch family code drift");
_Static_assert(0x0aU == 10U, "x86 dispatch family code drift");
_Static_assert(0x03U == 3U, "x86 dispatch family code drift");
_Static_assert(0x0bU == 11U, "x86 dispatch family code drift");
_Static_assert(0x04U == 4U, "x86 dispatch family code drift");
_Static_assert(0x05U == 5U, "x86 dispatch family code drift");
_Static_assert(0x0cU == 12U, "x86 dispatch family code drift");
_Static_assert(0x0eU == 14U, "x86 dispatch family code drift");
_Static_assert(0x0dU == 13U, "x86 dispatch family code drift");
_Static_assert(0x0fU == 15U, "x86 dispatch family code drift");
_Static_assert(0x1dU == 29U, "x86 dispatch family code drift");
_Static_assert(0x1eU == 30U, "x86 dispatch family code drift");
_Static_assert(0x1fU == 31U, "x86 dispatch family code drift");
_Static_assert(0x3bU == 59U, "x86 dispatch family code drift");
_Static_assert(0x1bU == 27U, "x86 dispatch family code drift");
_Static_assert(0x1cU == 28U, "x86 dispatch family code drift");
# 78 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_family.h"
_Static_assert((((0x2cU) == 0x2cU) || ((0x2cU) == 0x2dU)), "x86 dispatch family coverage drift");
_Static_assert((((0x2dU) == 0x2cU) || ((0x2dU) == 0x2dU)), "x86 dispatch family coverage drift");
_Static_assert((((0x20U) == 0x20U) || ((0x20U) == 0x21U)), "x86 dispatch family coverage drift");
_Static_assert((((0x21U) == 0x20U) || ((0x21U) == 0x21U)), "x86 dispatch family coverage drift");
_Static_assert((((0x06U) == 0x06U) || ((0x06U) == 0x25U) || ((0x06U) == 0x22U)), "x86 dispatch family coverage drift");
_Static_assert((((0x25U) == 0x06U) || ((0x25U) == 0x25U) || ((0x25U) == 0x22U)), "x86 dispatch family coverage drift");
_Static_assert((((0x22U) == 0x06U) || ((0x22U) == 0x25U) || ((0x22U) == 0x22U)), "x86 dispatch family coverage drift");
_Static_assert((((0x07U) == 0x07U) || ((0x07U) == 0x08U)), "x86 dispatch family coverage drift");
_Static_assert((((0x08U) == 0x07U) || ((0x08U) == 0x08U)), "x86 dispatch family coverage drift");
_Static_assert((((0x0aU) == 0x0aU) || ((0x0aU) == 0x03U)), "x86 dispatch family coverage drift");
_Static_assert((((0x03U) == 0x0aU) || ((0x03U) == 0x03U)), "x86 dispatch family coverage drift");
_Static_assert((((0x0bU) == 0x0bU) || ((0x0bU) == 0x04U) || ((0x0bU) == 0x05U)), "x86 dispatch family coverage drift");
_Static_assert((((0x04U) == 0x0bU) || ((0x04U) == 0x04U) || ((0x04U) == 0x05U)), "x86 dispatch family coverage drift");
_Static_assert((((0x05U) == 0x0bU) || ((0x05U) == 0x04U) || ((0x05U) == 0x05U)), "x86 dispatch family coverage drift");
_Static_assert((((0x0cU) == 0x0cU) || ((0x0cU) == 0x0eU)), "x86 dispatch family coverage drift");
_Static_assert((((0x0eU) == 0x0cU) || ((0x0eU) == 0x0eU)), "x86 dispatch family coverage drift");
_Static_assert((((0x0dU) == 0x0dU) || ((0x0dU) == 0x0fU)), "x86 dispatch family coverage drift");
_Static_assert((((0x0fU) == 0x0dU) || ((0x0fU) == 0x0fU)), "x86 dispatch family coverage drift");
_Static_assert((((0x1dU) == 0x1dU) || ((0x1dU) == 0x1eU) || ((0x1dU) == 0x1fU) || ((0x1dU) == 0x3bU)), "x86 dispatch family coverage drift");
_Static_assert((((0x1eU) == 0x1dU) || ((0x1eU) == 0x1eU) || ((0x1eU) == 0x1fU) || ((0x1eU) == 0x3bU)), "x86 dispatch family coverage drift");
_Static_assert((((0x1fU) == 0x1dU) || ((0x1fU) == 0x1eU) || ((0x1fU) == 0x1fU) || ((0x1fU) == 0x3bU)), "x86 dispatch family coverage drift");
_Static_assert((((0x3bU) == 0x1dU) || ((0x3bU) == 0x1eU) || ((0x3bU) == 0x1fU) || ((0x3bU) == 0x3bU)), "x86 dispatch family coverage drift");
_Static_assert((((0x1bU) == 0x1bU) || ((0x1bU) == 0x1cU)), "x86 dispatch family coverage drift");
_Static_assert((((0x1cU) == 0x1bU) || ((0x1cU) == 0x1cU)), "x86 dispatch family coverage drift");
# 48 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_singleton.h" 1
# 21 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_singleton.h"
_Static_assert(0x00U == 0U, "x86 dispatch singleton code drift");
_Static_assert(0x3fU == 63U, "x86 dispatch singleton code drift");
_Static_assert(0x3cU == 60U, "x86 dispatch singleton code drift");
_Static_assert(0x46U == 70U, "x86 dispatch singleton code drift");
_Static_assert(0x45U == 69U, "x86 dispatch singleton code drift");
_Static_assert(0x2fU == 47U, "x86 dispatch singleton code drift");
_Static_assert(0x01U == 1U, "x86 dispatch singleton code drift");
_Static_assert(0x02U == 2U, "x86 dispatch singleton code drift");
_Static_assert(0x28U == 40U, "x86 dispatch singleton code drift");
_Static_assert(0x29U == 41U, "x86 dispatch singleton code drift");
_Static_assert(0x30U == 48U, "x86 dispatch singleton code drift");
_Static_assert(0x31U == 49U, "x86 dispatch singleton code drift");
_Static_assert(0x09U == 9U, "x86 dispatch singleton code drift");
_Static_assert(0x23U == 35U, "x86 dispatch singleton code drift");
_Static_assert(0x32U == 50U, "x86 dispatch singleton code drift");
_Static_assert(0x33U == 51U, "x86 dispatch singleton code drift");
_Static_assert(0x36U == 54U, "x86 dispatch singleton code drift");
_Static_assert(0x24U == 36U, "x86 dispatch singleton code drift");
_Static_assert(0x15U == 21U, "x86 dispatch singleton code drift");
_Static_assert(0x40U == 64U, "x86 dispatch singleton code drift");
_Static_assert(0x16U == 22U, "x86 dispatch singleton code drift");
_Static_assert(0x3eU == 62U, "x86 dispatch singleton code drift");
_Static_assert(0x17U == 23U, "x86 dispatch singleton code drift");
_Static_assert(0x18U == 24U, "x86 dispatch singleton code drift");
_Static_assert(0x26U == 38U, "x86 dispatch singleton code drift");
_Static_assert(0x2aU == 42U, "x86 dispatch singleton code drift");
_Static_assert(0x27U == 39U, "x86 dispatch singleton code drift");
_Static_assert(0x2bU == 43U, "x86 dispatch singleton code drift");
_Static_assert(0x34U == 52U, "x86 dispatch singleton code drift");
_Static_assert(0x35U == 53U, "x86 dispatch singleton code drift");
_Static_assert(0x37U == 55U, "x86 dispatch singleton code drift");
_Static_assert(0x42U == 66U, "x86 dispatch singleton code drift");
_Static_assert(0x43U == 67U, "x86 dispatch singleton code drift");
_Static_assert(0x38U == 56U, "x86 dispatch singleton code drift");
_Static_assert(0x41U == 65U, "x86 dispatch singleton code drift");
_Static_assert(0x39U == 57U, "x86 dispatch singleton code drift");
_Static_assert(0x3aU == 58U, "x86 dispatch singleton code drift");
_Static_assert(0x3dU == 61U, "x86 dispatch singleton code drift");
_Static_assert(0x44U == 68U, "x86 dispatch singleton code drift");
_Static_assert(0x19U == 25U, "x86 dispatch singleton code drift");
_Static_assert(0x1aU == 26U, "x86 dispatch singleton code drift");
_Static_assert(0x12U == 18U, "x86 dispatch singleton code drift");
_Static_assert(0x13U == 19U, "x86 dispatch singleton code drift");
_Static_assert(0x47U == 71U, "x86 dispatch singleton code drift");
_Static_assert(0x48U == 72U, "x86 dispatch singleton code drift");
_Static_assert(0x49U == 73U, "x86 dispatch singleton code drift");
# 161 "/workspaces/repository/kprog/x86/../formal/generated/x86_dispatch_singleton.h"
_Static_assert(((0x00U) == 0x00U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x3fU) == 0x3fU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x3cU) == 0x3cU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x46U) == 0x46U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x45U) == 0x45U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x2fU) == 0x2fU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x01U) == 0x01U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x02U) == 0x02U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x28U) == 0x28U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x29U) == 0x29U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x30U) == 0x30U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x31U) == 0x31U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x09U) == 0x09U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x23U) == 0x23U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x32U) == 0x32U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x33U) == 0x33U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x36U) == 0x36U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x24U) == 0x24U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x15U) == 0x15U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x40U) == 0x40U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x16U) == 0x16U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x3eU) == 0x3eU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x17U) == 0x17U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x18U) == 0x18U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x26U) == 0x26U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x2aU) == 0x2aU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x27U) == 0x27U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x2bU) == 0x2bU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x34U) == 0x34U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x35U) == 0x35U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x37U) == 0x37U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x42U) == 0x42U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x43U) == 0x43U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x38U) == 0x38U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x41U) == 0x41U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x39U) == 0x39U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x3aU) == 0x3aU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x3dU) == 0x3dU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x44U) == 0x44U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x19U) == 0x19U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x1aU) == 0x1aU), "x86 dispatch singleton coverage drift");
_Static_assert(((0x12U) == 0x12U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x13U) == 0x13U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x47U) == 0x47U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x48U) == 0x48U), "x86 dispatch singleton coverage drift");
_Static_assert(((0x49U) == 0x49U), "x86 dispatch singleton coverage drift");
# 49 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 66 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
struct x86_sim_xdp_abi {
 void *data;
 void *data_end;
 __u32 cb[5];
};

struct x86_sim_skb_abi {
 __u8 pad0[0x30LL];
 __u32 cb[5];
 __u8 pad1[0x50LL - 0x30LL - sizeof(__u32) * 5];
 void *data_end;
 __u8 pad2[0xd0LL - 0x50LL - sizeof(void *)];
 void *data;
};

_Static_assert(__builtin_offsetof(struct x86_sim_xdp_abi, data) ==
        0LL, "xdp data offset disagrees with ABI spec");
_Static_assert(__builtin_offsetof(struct x86_sim_xdp_abi, data_end) ==
        8LL,
        "xdp data_end offset disagrees with ABI spec");
_Static_assert(__builtin_offsetof(struct x86_sim_skb_abi, data) ==
        208LL, "skb data offset disagrees with ABI spec");
_Static_assert(__builtin_offsetof(struct x86_sim_skb_abi, data_end) ==
        80LL,
        "skb data_end offset disagrees with ABI spec");

union x86_sim_gpr {
 void *ptr;
 __u16 w;
 __u8 b[8];
};

_Static_assert(sizeof(union x86_sim_gpr) == sizeof(__u64),
        "x86 simulator register must hold exactly 64 bits");
_Static_assert(sizeof(void *) == sizeof(__u64),
        "x86 simulator pointer storage must hold exactly 64 bits");
_Static_assert(1234 == 1234,
        "x86 partial-register layout requires little endian");

union x86_sim_stack_mem {
 __u8 b[8U];
 __u64 q[(((__u64)(8U) + 7U) / 8U)];
};
# 127 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_ptr_write.h" 1
# 19 "/workspaces/repository/kprog/x86/../formal/generated/x86_ptr_write.h"
_Static_assert(0x2cU == 0x2cU, "x86 ptr-write movLoadMapPtr opcode drift");
_Static_assert(0x2dU == 0x2dU, "x86 ptr-write movLoadHelperId opcode drift");




_Static_assert(0U == 0U, "x86 ptr-write scalar tag drift");
_Static_assert(5U == 5U, "x86 ptr-write mapPtr tag drift");
_Static_assert(7U == 7U, "x86 ptr-write helperId tag drift");
# 59 "/workspaces/repository/kprog/x86/../formal/generated/x86_ptr_write.h"
_Static_assert(6U == 6U,
               "x86 source-map value tag drift");
# 128 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2



# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_mov_load.h" 1
# 132 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 207 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
# 1 "/workspaces/repository/kprog/x86/../formal/generated/x86_helper_dispatch.h" 1
# 90 "/workspaces/repository/kprog/x86/../formal/generated/x86_helper_dispatch.h"
_Static_assert(1ULL == 1ULL, "x86 helper id drift");
_Static_assert(2ULL == 2ULL, "x86 helper id drift");
_Static_assert(3ULL == 3ULL, "x86 helper id drift");
_Static_assert(4ULL == 4ULL, "x86 helper id drift");
_Static_assert(5ULL == 5ULL, "x86 helper id drift");
_Static_assert(6ULL == 6ULL, "x86 helper id drift");
_Static_assert(7ULL == 7ULL, "x86 helper id drift");
_Static_assert(8ULL == 8ULL, "x86 helper id drift");
_Static_assert(9ULL == 9ULL, "x86 helper id drift");
_Static_assert(10ULL == 10ULL, "x86 helper id drift");
_Static_assert(11ULL == 11ULL, "x86 helper id drift");
_Static_assert(12ULL == 12ULL, "x86 helper id drift");
_Static_assert(14ULL == 14ULL, "x86 helper id drift");
_Static_assert(15ULL == 15ULL, "x86 helper id drift");
_Static_assert(16ULL == 16ULL, "x86 helper id drift");
_Static_assert(20ULL == 20ULL, "x86 helper id drift");
_Static_assert(21ULL == 21ULL, "x86 helper id drift");
_Static_assert(23ULL == 23ULL, "x86 helper id drift");
_Static_assert(25ULL == 25ULL, "x86 helper id drift");
_Static_assert(26ULL == 26ULL, "x86 helper id drift");
_Static_assert(27ULL == 27ULL, "x86 helper id drift");
_Static_assert(28ULL == 28ULL, "x86 helper id drift");
_Static_assert(32ULL == 32ULL, "x86 helper id drift");
_Static_assert(35ULL == 35ULL, "x86 helper id drift");
_Static_assert(36ULL == 36ULL, "x86 helper id drift");
_Static_assert(37ULL == 37ULL, "x86 helper id drift");
_Static_assert(38ULL == 38ULL, "x86 helper id drift");
_Static_assert(39ULL == 39ULL, "x86 helper id drift");
_Static_assert(43ULL == 43ULL, "x86 helper id drift");
_Static_assert(44ULL == 44ULL, "x86 helper id drift");
_Static_assert(45ULL == 45ULL, "x86 helper id drift");
_Static_assert(46ULL == 46ULL, "x86 helper id drift");
_Static_assert(50ULL == 50ULL, "x86 helper id drift");
_Static_assert(54ULL == 54ULL, "x86 helper id drift");
_Static_assert(58ULL == 58ULL, "x86 helper id drift");
_Static_assert(65ULL == 65ULL, "x86 helper id drift");
_Static_assert(67ULL == 67ULL, "x86 helper id drift");
_Static_assert(68ULL == 68ULL, "x86 helper id drift");
_Static_assert(69ULL == 69ULL, "x86 helper id drift");
_Static_assert(80ULL == 80ULL, "x86 helper id drift");
_Static_assert(85ULL == 85ULL, "x86 helper id drift");
_Static_assert(86ULL == 86ULL, "x86 helper id drift");
_Static_assert(87ULL == 87ULL, "x86 helper id drift");
_Static_assert(88ULL == 88ULL, "x86 helper id drift");
_Static_assert(95ULL == 95ULL, "x86 helper id drift");
_Static_assert(99ULL == 99ULL, "x86 helper id drift");
_Static_assert(105ULL == 105ULL, "x86 helper id drift");
_Static_assert(109ULL == 109ULL, "x86 helper id drift");
_Static_assert(112ULL == 112ULL, "x86 helper id drift");
_Static_assert(113ULL == 113ULL, "x86 helper id drift");
_Static_assert(114ULL == 114ULL, "x86 helper id drift");
_Static_assert(115ULL == 115ULL, "x86 helper id drift");
_Static_assert(118ULL == 118ULL, "x86 helper id drift");
_Static_assert(122ULL == 122ULL, "x86 helper id drift");
_Static_assert(124ULL == 124ULL, "x86 helper id drift");
_Static_assert(125ULL == 125ULL, "x86 helper id drift");
_Static_assert(130ULL == 130ULL, "x86 helper id drift");
_Static_assert(148ULL == 148ULL, "x86 helper id drift");
_Static_assert(152ULL == 152ULL, "x86 helper id drift");
_Static_assert(155ULL == 155ULL, "x86 helper id drift");
_Static_assert(158ULL == 158ULL, "x86 helper id drift");
_Static_assert(160ULL == 160ULL, "x86 helper id drift");
_Static_assert(163ULL == 163ULL, "x86 helper id drift");
_Static_assert(173ULL == 173ULL, "x86 helper id drift");
_Static_assert(174ULL == 174ULL, "x86 helper id drift");
_Static_assert(175ULL == 175ULL, "x86 helper id drift");
_Static_assert(181ULL == 181ULL, "x86 helper id drift");
_Static_assert(184ULL == 184ULL, "x86 helper id drift");
_Static_assert(189ULL == 189ULL, "x86 helper id drift");
_Static_assert(193ULL == 193ULL, "x86 helper id drift");
_Static_assert(70U == 70U,
        "x86 helper dispatch count drift");


_Static_assert(((__u64)((1ULL)) == 1ULL ? 0U : ((__u64)((1ULL)) == 2ULL ? 1U : ((__u64)((1ULL)) == 3ULL ? 2U : ((__u64)((1ULL)) == 4ULL ? 3U : ((__u64)((1ULL)) == 5ULL ? 4U : ((__u64)((1ULL)) == 6ULL ? 5U : ((__u64)((1ULL)) == 7ULL ? 6U : ((__u64)((1ULL)) == 8ULL ? 7U : ((__u64)((1ULL)) == 9ULL ? 8U : ((__u64)((1ULL)) == 10ULL ? 9U : ((__u64)((1ULL)) == 11ULL ? 10U : ((__u64)((1ULL)) == 12ULL ? 11U : ((__u64)((1ULL)) == 14ULL ? 12U : ((__u64)((1ULL)) == 15ULL ? 13U : ((__u64)((1ULL)) == 16ULL ? 14U : ((__u64)((1ULL)) == 20ULL ? 15U : ((__u64)((1ULL)) == 21ULL ? 16U : ((__u64)((1ULL)) == 23ULL ? 17U : ((__u64)((1ULL)) == 25ULL ? 18U : ((__u64)((1ULL)) == 26ULL ? 19U : ((__u64)((1ULL)) == 27ULL ? 20U : ((__u64)((1ULL)) == 28ULL ? 21U : ((__u64)((1ULL)) == 32ULL ? 22U : ((__u64)((1ULL)) == 35ULL ? 23U : ((__u64)((1ULL)) == 36ULL ? 24U : ((__u64)((1ULL)) == 37ULL ? 25U : ((__u64)((1ULL)) == 38ULL ? 26U : ((__u64)((1ULL)) == 39ULL ? 27U : ((__u64)((1ULL)) == 43ULL ? 28U : ((__u64)((1ULL)) == 44ULL ? 29U : ((__u64)((1ULL)) == 45ULL ? 30U : ((__u64)((1ULL)) == 46ULL ? 31U : ((__u64)((1ULL)) == 50ULL ? 32U : ((__u64)((1ULL)) == 54ULL ? 33U : ((__u64)((1ULL)) == 58ULL ? 34U : ((__u64)((1ULL)) == 65ULL ? 35U : ((__u64)((1ULL)) == 67ULL ? 36U : ((__u64)((1ULL)) == 68ULL ? 37U : ((__u64)((1ULL)) == 69ULL ? 38U : ((__u64)((1ULL)) == 80ULL ? 39U : ((__u64)((1ULL)) == 85ULL ? 40U : ((__u64)((1ULL)) == 86ULL ? 41U : ((__u64)((1ULL)) == 87ULL ? 42U : ((__u64)((1ULL)) == 88ULL ? 43U : ((__u64)((1ULL)) == 95ULL ? 44U : ((__u64)((1ULL)) == 99ULL ? 45U : ((__u64)((1ULL)) == 105ULL ? 46U : ((__u64)((1ULL)) == 109ULL ? 47U : ((__u64)((1ULL)) == 112ULL ? 48U : ((__u64)((1ULL)) == 113ULL ? 49U : ((__u64)((1ULL)) == 114ULL ? 50U : ((__u64)((1ULL)) == 115ULL ? 51U : ((__u64)((1ULL)) == 118ULL ? 52U : ((__u64)((1ULL)) == 122ULL ? 53U : ((__u64)((1ULL)) == 124ULL ? 54U : ((__u64)((1ULL)) == 125ULL ? 55U : ((__u64)((1ULL)) == 130ULL ? 56U : ((__u64)((1ULL)) == 148ULL ? 57U : ((__u64)((1ULL)) == 152ULL ? 58U : ((__u64)((1ULL)) == 155ULL ? 59U : ((__u64)((1ULL)) == 158ULL ? 60U : ((__u64)((1ULL)) == 160ULL ? 61U : ((__u64)((1ULL)) == 163ULL ? 62U : ((__u64)((1ULL)) == 173ULL ? 63U : ((__u64)((1ULL)) == 174ULL ? 64U : ((__u64)((1ULL)) == 175ULL ? 65U : ((__u64)((1ULL)) == 181ULL ? 66U : ((__u64)((1ULL)) == 184ULL ? 67U : ((__u64)((1ULL)) == 189ULL ? 68U : ((__u64)((1ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 0U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((2ULL)) == 1ULL ? 0U : ((__u64)((2ULL)) == 2ULL ? 1U : ((__u64)((2ULL)) == 3ULL ? 2U : ((__u64)((2ULL)) == 4ULL ? 3U : ((__u64)((2ULL)) == 5ULL ? 4U : ((__u64)((2ULL)) == 6ULL ? 5U : ((__u64)((2ULL)) == 7ULL ? 6U : ((__u64)((2ULL)) == 8ULL ? 7U : ((__u64)((2ULL)) == 9ULL ? 8U : ((__u64)((2ULL)) == 10ULL ? 9U : ((__u64)((2ULL)) == 11ULL ? 10U : ((__u64)((2ULL)) == 12ULL ? 11U : ((__u64)((2ULL)) == 14ULL ? 12U : ((__u64)((2ULL)) == 15ULL ? 13U : ((__u64)((2ULL)) == 16ULL ? 14U : ((__u64)((2ULL)) == 20ULL ? 15U : ((__u64)((2ULL)) == 21ULL ? 16U : ((__u64)((2ULL)) == 23ULL ? 17U : ((__u64)((2ULL)) == 25ULL ? 18U : ((__u64)((2ULL)) == 26ULL ? 19U : ((__u64)((2ULL)) == 27ULL ? 20U : ((__u64)((2ULL)) == 28ULL ? 21U : ((__u64)((2ULL)) == 32ULL ? 22U : ((__u64)((2ULL)) == 35ULL ? 23U : ((__u64)((2ULL)) == 36ULL ? 24U : ((__u64)((2ULL)) == 37ULL ? 25U : ((__u64)((2ULL)) == 38ULL ? 26U : ((__u64)((2ULL)) == 39ULL ? 27U : ((__u64)((2ULL)) == 43ULL ? 28U : ((__u64)((2ULL)) == 44ULL ? 29U : ((__u64)((2ULL)) == 45ULL ? 30U : ((__u64)((2ULL)) == 46ULL ? 31U : ((__u64)((2ULL)) == 50ULL ? 32U : ((__u64)((2ULL)) == 54ULL ? 33U : ((__u64)((2ULL)) == 58ULL ? 34U : ((__u64)((2ULL)) == 65ULL ? 35U : ((__u64)((2ULL)) == 67ULL ? 36U : ((__u64)((2ULL)) == 68ULL ? 37U : ((__u64)((2ULL)) == 69ULL ? 38U : ((__u64)((2ULL)) == 80ULL ? 39U : ((__u64)((2ULL)) == 85ULL ? 40U : ((__u64)((2ULL)) == 86ULL ? 41U : ((__u64)((2ULL)) == 87ULL ? 42U : ((__u64)((2ULL)) == 88ULL ? 43U : ((__u64)((2ULL)) == 95ULL ? 44U : ((__u64)((2ULL)) == 99ULL ? 45U : ((__u64)((2ULL)) == 105ULL ? 46U : ((__u64)((2ULL)) == 109ULL ? 47U : ((__u64)((2ULL)) == 112ULL ? 48U : ((__u64)((2ULL)) == 113ULL ? 49U : ((__u64)((2ULL)) == 114ULL ? 50U : ((__u64)((2ULL)) == 115ULL ? 51U : ((__u64)((2ULL)) == 118ULL ? 52U : ((__u64)((2ULL)) == 122ULL ? 53U : ((__u64)((2ULL)) == 124ULL ? 54U : ((__u64)((2ULL)) == 125ULL ? 55U : ((__u64)((2ULL)) == 130ULL ? 56U : ((__u64)((2ULL)) == 148ULL ? 57U : ((__u64)((2ULL)) == 152ULL ? 58U : ((__u64)((2ULL)) == 155ULL ? 59U : ((__u64)((2ULL)) == 158ULL ? 60U : ((__u64)((2ULL)) == 160ULL ? 61U : ((__u64)((2ULL)) == 163ULL ? 62U : ((__u64)((2ULL)) == 173ULL ? 63U : ((__u64)((2ULL)) == 174ULL ? 64U : ((__u64)((2ULL)) == 175ULL ? 65U : ((__u64)((2ULL)) == 181ULL ? 66U : ((__u64)((2ULL)) == 184ULL ? 67U : ((__u64)((2ULL)) == 189ULL ? 68U : ((__u64)((2ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 1U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((3ULL)) == 1ULL ? 0U : ((__u64)((3ULL)) == 2ULL ? 1U : ((__u64)((3ULL)) == 3ULL ? 2U : ((__u64)((3ULL)) == 4ULL ? 3U : ((__u64)((3ULL)) == 5ULL ? 4U : ((__u64)((3ULL)) == 6ULL ? 5U : ((__u64)((3ULL)) == 7ULL ? 6U : ((__u64)((3ULL)) == 8ULL ? 7U : ((__u64)((3ULL)) == 9ULL ? 8U : ((__u64)((3ULL)) == 10ULL ? 9U : ((__u64)((3ULL)) == 11ULL ? 10U : ((__u64)((3ULL)) == 12ULL ? 11U : ((__u64)((3ULL)) == 14ULL ? 12U : ((__u64)((3ULL)) == 15ULL ? 13U : ((__u64)((3ULL)) == 16ULL ? 14U : ((__u64)((3ULL)) == 20ULL ? 15U : ((__u64)((3ULL)) == 21ULL ? 16U : ((__u64)((3ULL)) == 23ULL ? 17U : ((__u64)((3ULL)) == 25ULL ? 18U : ((__u64)((3ULL)) == 26ULL ? 19U : ((__u64)((3ULL)) == 27ULL ? 20U : ((__u64)((3ULL)) == 28ULL ? 21U : ((__u64)((3ULL)) == 32ULL ? 22U : ((__u64)((3ULL)) == 35ULL ? 23U : ((__u64)((3ULL)) == 36ULL ? 24U : ((__u64)((3ULL)) == 37ULL ? 25U : ((__u64)((3ULL)) == 38ULL ? 26U : ((__u64)((3ULL)) == 39ULL ? 27U : ((__u64)((3ULL)) == 43ULL ? 28U : ((__u64)((3ULL)) == 44ULL ? 29U : ((__u64)((3ULL)) == 45ULL ? 30U : ((__u64)((3ULL)) == 46ULL ? 31U : ((__u64)((3ULL)) == 50ULL ? 32U : ((__u64)((3ULL)) == 54ULL ? 33U : ((__u64)((3ULL)) == 58ULL ? 34U : ((__u64)((3ULL)) == 65ULL ? 35U : ((__u64)((3ULL)) == 67ULL ? 36U : ((__u64)((3ULL)) == 68ULL ? 37U : ((__u64)((3ULL)) == 69ULL ? 38U : ((__u64)((3ULL)) == 80ULL ? 39U : ((__u64)((3ULL)) == 85ULL ? 40U : ((__u64)((3ULL)) == 86ULL ? 41U : ((__u64)((3ULL)) == 87ULL ? 42U : ((__u64)((3ULL)) == 88ULL ? 43U : ((__u64)((3ULL)) == 95ULL ? 44U : ((__u64)((3ULL)) == 99ULL ? 45U : ((__u64)((3ULL)) == 105ULL ? 46U : ((__u64)((3ULL)) == 109ULL ? 47U : ((__u64)((3ULL)) == 112ULL ? 48U : ((__u64)((3ULL)) == 113ULL ? 49U : ((__u64)((3ULL)) == 114ULL ? 50U : ((__u64)((3ULL)) == 115ULL ? 51U : ((__u64)((3ULL)) == 118ULL ? 52U : ((__u64)((3ULL)) == 122ULL ? 53U : ((__u64)((3ULL)) == 124ULL ? 54U : ((__u64)((3ULL)) == 125ULL ? 55U : ((__u64)((3ULL)) == 130ULL ? 56U : ((__u64)((3ULL)) == 148ULL ? 57U : ((__u64)((3ULL)) == 152ULL ? 58U : ((__u64)((3ULL)) == 155ULL ? 59U : ((__u64)((3ULL)) == 158ULL ? 60U : ((__u64)((3ULL)) == 160ULL ? 61U : ((__u64)((3ULL)) == 163ULL ? 62U : ((__u64)((3ULL)) == 173ULL ? 63U : ((__u64)((3ULL)) == 174ULL ? 64U : ((__u64)((3ULL)) == 175ULL ? 65U : ((__u64)((3ULL)) == 181ULL ? 66U : ((__u64)((3ULL)) == 184ULL ? 67U : ((__u64)((3ULL)) == 189ULL ? 68U : ((__u64)((3ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 2U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((4ULL)) == 1ULL ? 0U : ((__u64)((4ULL)) == 2ULL ? 1U : ((__u64)((4ULL)) == 3ULL ? 2U : ((__u64)((4ULL)) == 4ULL ? 3U : ((__u64)((4ULL)) == 5ULL ? 4U : ((__u64)((4ULL)) == 6ULL ? 5U : ((__u64)((4ULL)) == 7ULL ? 6U : ((__u64)((4ULL)) == 8ULL ? 7U : ((__u64)((4ULL)) == 9ULL ? 8U : ((__u64)((4ULL)) == 10ULL ? 9U : ((__u64)((4ULL)) == 11ULL ? 10U : ((__u64)((4ULL)) == 12ULL ? 11U : ((__u64)((4ULL)) == 14ULL ? 12U : ((__u64)((4ULL)) == 15ULL ? 13U : ((__u64)((4ULL)) == 16ULL ? 14U : ((__u64)((4ULL)) == 20ULL ? 15U : ((__u64)((4ULL)) == 21ULL ? 16U : ((__u64)((4ULL)) == 23ULL ? 17U : ((__u64)((4ULL)) == 25ULL ? 18U : ((__u64)((4ULL)) == 26ULL ? 19U : ((__u64)((4ULL)) == 27ULL ? 20U : ((__u64)((4ULL)) == 28ULL ? 21U : ((__u64)((4ULL)) == 32ULL ? 22U : ((__u64)((4ULL)) == 35ULL ? 23U : ((__u64)((4ULL)) == 36ULL ? 24U : ((__u64)((4ULL)) == 37ULL ? 25U : ((__u64)((4ULL)) == 38ULL ? 26U : ((__u64)((4ULL)) == 39ULL ? 27U : ((__u64)((4ULL)) == 43ULL ? 28U : ((__u64)((4ULL)) == 44ULL ? 29U : ((__u64)((4ULL)) == 45ULL ? 30U : ((__u64)((4ULL)) == 46ULL ? 31U : ((__u64)((4ULL)) == 50ULL ? 32U : ((__u64)((4ULL)) == 54ULL ? 33U : ((__u64)((4ULL)) == 58ULL ? 34U : ((__u64)((4ULL)) == 65ULL ? 35U : ((__u64)((4ULL)) == 67ULL ? 36U : ((__u64)((4ULL)) == 68ULL ? 37U : ((__u64)((4ULL)) == 69ULL ? 38U : ((__u64)((4ULL)) == 80ULL ? 39U : ((__u64)((4ULL)) == 85ULL ? 40U : ((__u64)((4ULL)) == 86ULL ? 41U : ((__u64)((4ULL)) == 87ULL ? 42U : ((__u64)((4ULL)) == 88ULL ? 43U : ((__u64)((4ULL)) == 95ULL ? 44U : ((__u64)((4ULL)) == 99ULL ? 45U : ((__u64)((4ULL)) == 105ULL ? 46U : ((__u64)((4ULL)) == 109ULL ? 47U : ((__u64)((4ULL)) == 112ULL ? 48U : ((__u64)((4ULL)) == 113ULL ? 49U : ((__u64)((4ULL)) == 114ULL ? 50U : ((__u64)((4ULL)) == 115ULL ? 51U : ((__u64)((4ULL)) == 118ULL ? 52U : ((__u64)((4ULL)) == 122ULL ? 53U : ((__u64)((4ULL)) == 124ULL ? 54U : ((__u64)((4ULL)) == 125ULL ? 55U : ((__u64)((4ULL)) == 130ULL ? 56U : ((__u64)((4ULL)) == 148ULL ? 57U : ((__u64)((4ULL)) == 152ULL ? 58U : ((__u64)((4ULL)) == 155ULL ? 59U : ((__u64)((4ULL)) == 158ULL ? 60U : ((__u64)((4ULL)) == 160ULL ? 61U : ((__u64)((4ULL)) == 163ULL ? 62U : ((__u64)((4ULL)) == 173ULL ? 63U : ((__u64)((4ULL)) == 174ULL ? 64U : ((__u64)((4ULL)) == 175ULL ? 65U : ((__u64)((4ULL)) == 181ULL ? 66U : ((__u64)((4ULL)) == 184ULL ? 67U : ((__u64)((4ULL)) == 189ULL ? 68U : ((__u64)((4ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 3U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((5ULL)) == 1ULL ? 0U : ((__u64)((5ULL)) == 2ULL ? 1U : ((__u64)((5ULL)) == 3ULL ? 2U : ((__u64)((5ULL)) == 4ULL ? 3U : ((__u64)((5ULL)) == 5ULL ? 4U : ((__u64)((5ULL)) == 6ULL ? 5U : ((__u64)((5ULL)) == 7ULL ? 6U : ((__u64)((5ULL)) == 8ULL ? 7U : ((__u64)((5ULL)) == 9ULL ? 8U : ((__u64)((5ULL)) == 10ULL ? 9U : ((__u64)((5ULL)) == 11ULL ? 10U : ((__u64)((5ULL)) == 12ULL ? 11U : ((__u64)((5ULL)) == 14ULL ? 12U : ((__u64)((5ULL)) == 15ULL ? 13U : ((__u64)((5ULL)) == 16ULL ? 14U : ((__u64)((5ULL)) == 20ULL ? 15U : ((__u64)((5ULL)) == 21ULL ? 16U : ((__u64)((5ULL)) == 23ULL ? 17U : ((__u64)((5ULL)) == 25ULL ? 18U : ((__u64)((5ULL)) == 26ULL ? 19U : ((__u64)((5ULL)) == 27ULL ? 20U : ((__u64)((5ULL)) == 28ULL ? 21U : ((__u64)((5ULL)) == 32ULL ? 22U : ((__u64)((5ULL)) == 35ULL ? 23U : ((__u64)((5ULL)) == 36ULL ? 24U : ((__u64)((5ULL)) == 37ULL ? 25U : ((__u64)((5ULL)) == 38ULL ? 26U : ((__u64)((5ULL)) == 39ULL ? 27U : ((__u64)((5ULL)) == 43ULL ? 28U : ((__u64)((5ULL)) == 44ULL ? 29U : ((__u64)((5ULL)) == 45ULL ? 30U : ((__u64)((5ULL)) == 46ULL ? 31U : ((__u64)((5ULL)) == 50ULL ? 32U : ((__u64)((5ULL)) == 54ULL ? 33U : ((__u64)((5ULL)) == 58ULL ? 34U : ((__u64)((5ULL)) == 65ULL ? 35U : ((__u64)((5ULL)) == 67ULL ? 36U : ((__u64)((5ULL)) == 68ULL ? 37U : ((__u64)((5ULL)) == 69ULL ? 38U : ((__u64)((5ULL)) == 80ULL ? 39U : ((__u64)((5ULL)) == 85ULL ? 40U : ((__u64)((5ULL)) == 86ULL ? 41U : ((__u64)((5ULL)) == 87ULL ? 42U : ((__u64)((5ULL)) == 88ULL ? 43U : ((__u64)((5ULL)) == 95ULL ? 44U : ((__u64)((5ULL)) == 99ULL ? 45U : ((__u64)((5ULL)) == 105ULL ? 46U : ((__u64)((5ULL)) == 109ULL ? 47U : ((__u64)((5ULL)) == 112ULL ? 48U : ((__u64)((5ULL)) == 113ULL ? 49U : ((__u64)((5ULL)) == 114ULL ? 50U : ((__u64)((5ULL)) == 115ULL ? 51U : ((__u64)((5ULL)) == 118ULL ? 52U : ((__u64)((5ULL)) == 122ULL ? 53U : ((__u64)((5ULL)) == 124ULL ? 54U : ((__u64)((5ULL)) == 125ULL ? 55U : ((__u64)((5ULL)) == 130ULL ? 56U : ((__u64)((5ULL)) == 148ULL ? 57U : ((__u64)((5ULL)) == 152ULL ? 58U : ((__u64)((5ULL)) == 155ULL ? 59U : ((__u64)((5ULL)) == 158ULL ? 60U : ((__u64)((5ULL)) == 160ULL ? 61U : ((__u64)((5ULL)) == 163ULL ? 62U : ((__u64)((5ULL)) == 173ULL ? 63U : ((__u64)((5ULL)) == 174ULL ? 64U : ((__u64)((5ULL)) == 175ULL ? 65U : ((__u64)((5ULL)) == 181ULL ? 66U : ((__u64)((5ULL)) == 184ULL ? 67U : ((__u64)((5ULL)) == 189ULL ? 68U : ((__u64)((5ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 4U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((6ULL)) == 1ULL ? 0U : ((__u64)((6ULL)) == 2ULL ? 1U : ((__u64)((6ULL)) == 3ULL ? 2U : ((__u64)((6ULL)) == 4ULL ? 3U : ((__u64)((6ULL)) == 5ULL ? 4U : ((__u64)((6ULL)) == 6ULL ? 5U : ((__u64)((6ULL)) == 7ULL ? 6U : ((__u64)((6ULL)) == 8ULL ? 7U : ((__u64)((6ULL)) == 9ULL ? 8U : ((__u64)((6ULL)) == 10ULL ? 9U : ((__u64)((6ULL)) == 11ULL ? 10U : ((__u64)((6ULL)) == 12ULL ? 11U : ((__u64)((6ULL)) == 14ULL ? 12U : ((__u64)((6ULL)) == 15ULL ? 13U : ((__u64)((6ULL)) == 16ULL ? 14U : ((__u64)((6ULL)) == 20ULL ? 15U : ((__u64)((6ULL)) == 21ULL ? 16U : ((__u64)((6ULL)) == 23ULL ? 17U : ((__u64)((6ULL)) == 25ULL ? 18U : ((__u64)((6ULL)) == 26ULL ? 19U : ((__u64)((6ULL)) == 27ULL ? 20U : ((__u64)((6ULL)) == 28ULL ? 21U : ((__u64)((6ULL)) == 32ULL ? 22U : ((__u64)((6ULL)) == 35ULL ? 23U : ((__u64)((6ULL)) == 36ULL ? 24U : ((__u64)((6ULL)) == 37ULL ? 25U : ((__u64)((6ULL)) == 38ULL ? 26U : ((__u64)((6ULL)) == 39ULL ? 27U : ((__u64)((6ULL)) == 43ULL ? 28U : ((__u64)((6ULL)) == 44ULL ? 29U : ((__u64)((6ULL)) == 45ULL ? 30U : ((__u64)((6ULL)) == 46ULL ? 31U : ((__u64)((6ULL)) == 50ULL ? 32U : ((__u64)((6ULL)) == 54ULL ? 33U : ((__u64)((6ULL)) == 58ULL ? 34U : ((__u64)((6ULL)) == 65ULL ? 35U : ((__u64)((6ULL)) == 67ULL ? 36U : ((__u64)((6ULL)) == 68ULL ? 37U : ((__u64)((6ULL)) == 69ULL ? 38U : ((__u64)((6ULL)) == 80ULL ? 39U : ((__u64)((6ULL)) == 85ULL ? 40U : ((__u64)((6ULL)) == 86ULL ? 41U : ((__u64)((6ULL)) == 87ULL ? 42U : ((__u64)((6ULL)) == 88ULL ? 43U : ((__u64)((6ULL)) == 95ULL ? 44U : ((__u64)((6ULL)) == 99ULL ? 45U : ((__u64)((6ULL)) == 105ULL ? 46U : ((__u64)((6ULL)) == 109ULL ? 47U : ((__u64)((6ULL)) == 112ULL ? 48U : ((__u64)((6ULL)) == 113ULL ? 49U : ((__u64)((6ULL)) == 114ULL ? 50U : ((__u64)((6ULL)) == 115ULL ? 51U : ((__u64)((6ULL)) == 118ULL ? 52U : ((__u64)((6ULL)) == 122ULL ? 53U : ((__u64)((6ULL)) == 124ULL ? 54U : ((__u64)((6ULL)) == 125ULL ? 55U : ((__u64)((6ULL)) == 130ULL ? 56U : ((__u64)((6ULL)) == 148ULL ? 57U : ((__u64)((6ULL)) == 152ULL ? 58U : ((__u64)((6ULL)) == 155ULL ? 59U : ((__u64)((6ULL)) == 158ULL ? 60U : ((__u64)((6ULL)) == 160ULL ? 61U : ((__u64)((6ULL)) == 163ULL ? 62U : ((__u64)((6ULL)) == 173ULL ? 63U : ((__u64)((6ULL)) == 174ULL ? 64U : ((__u64)((6ULL)) == 175ULL ? 65U : ((__u64)((6ULL)) == 181ULL ? 66U : ((__u64)((6ULL)) == 184ULL ? 67U : ((__u64)((6ULL)) == 189ULL ? 68U : ((__u64)((6ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 5U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((7ULL)) == 1ULL ? 0U : ((__u64)((7ULL)) == 2ULL ? 1U : ((__u64)((7ULL)) == 3ULL ? 2U : ((__u64)((7ULL)) == 4ULL ? 3U : ((__u64)((7ULL)) == 5ULL ? 4U : ((__u64)((7ULL)) == 6ULL ? 5U : ((__u64)((7ULL)) == 7ULL ? 6U : ((__u64)((7ULL)) == 8ULL ? 7U : ((__u64)((7ULL)) == 9ULL ? 8U : ((__u64)((7ULL)) == 10ULL ? 9U : ((__u64)((7ULL)) == 11ULL ? 10U : ((__u64)((7ULL)) == 12ULL ? 11U : ((__u64)((7ULL)) == 14ULL ? 12U : ((__u64)((7ULL)) == 15ULL ? 13U : ((__u64)((7ULL)) == 16ULL ? 14U : ((__u64)((7ULL)) == 20ULL ? 15U : ((__u64)((7ULL)) == 21ULL ? 16U : ((__u64)((7ULL)) == 23ULL ? 17U : ((__u64)((7ULL)) == 25ULL ? 18U : ((__u64)((7ULL)) == 26ULL ? 19U : ((__u64)((7ULL)) == 27ULL ? 20U : ((__u64)((7ULL)) == 28ULL ? 21U : ((__u64)((7ULL)) == 32ULL ? 22U : ((__u64)((7ULL)) == 35ULL ? 23U : ((__u64)((7ULL)) == 36ULL ? 24U : ((__u64)((7ULL)) == 37ULL ? 25U : ((__u64)((7ULL)) == 38ULL ? 26U : ((__u64)((7ULL)) == 39ULL ? 27U : ((__u64)((7ULL)) == 43ULL ? 28U : ((__u64)((7ULL)) == 44ULL ? 29U : ((__u64)((7ULL)) == 45ULL ? 30U : ((__u64)((7ULL)) == 46ULL ? 31U : ((__u64)((7ULL)) == 50ULL ? 32U : ((__u64)((7ULL)) == 54ULL ? 33U : ((__u64)((7ULL)) == 58ULL ? 34U : ((__u64)((7ULL)) == 65ULL ? 35U : ((__u64)((7ULL)) == 67ULL ? 36U : ((__u64)((7ULL)) == 68ULL ? 37U : ((__u64)((7ULL)) == 69ULL ? 38U : ((__u64)((7ULL)) == 80ULL ? 39U : ((__u64)((7ULL)) == 85ULL ? 40U : ((__u64)((7ULL)) == 86ULL ? 41U : ((__u64)((7ULL)) == 87ULL ? 42U : ((__u64)((7ULL)) == 88ULL ? 43U : ((__u64)((7ULL)) == 95ULL ? 44U : ((__u64)((7ULL)) == 99ULL ? 45U : ((__u64)((7ULL)) == 105ULL ? 46U : ((__u64)((7ULL)) == 109ULL ? 47U : ((__u64)((7ULL)) == 112ULL ? 48U : ((__u64)((7ULL)) == 113ULL ? 49U : ((__u64)((7ULL)) == 114ULL ? 50U : ((__u64)((7ULL)) == 115ULL ? 51U : ((__u64)((7ULL)) == 118ULL ? 52U : ((__u64)((7ULL)) == 122ULL ? 53U : ((__u64)((7ULL)) == 124ULL ? 54U : ((__u64)((7ULL)) == 125ULL ? 55U : ((__u64)((7ULL)) == 130ULL ? 56U : ((__u64)((7ULL)) == 148ULL ? 57U : ((__u64)((7ULL)) == 152ULL ? 58U : ((__u64)((7ULL)) == 155ULL ? 59U : ((__u64)((7ULL)) == 158ULL ? 60U : ((__u64)((7ULL)) == 160ULL ? 61U : ((__u64)((7ULL)) == 163ULL ? 62U : ((__u64)((7ULL)) == 173ULL ? 63U : ((__u64)((7ULL)) == 174ULL ? 64U : ((__u64)((7ULL)) == 175ULL ? 65U : ((__u64)((7ULL)) == 181ULL ? 66U : ((__u64)((7ULL)) == 184ULL ? 67U : ((__u64)((7ULL)) == 189ULL ? 68U : ((__u64)((7ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 6U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((8ULL)) == 1ULL ? 0U : ((__u64)((8ULL)) == 2ULL ? 1U : ((__u64)((8ULL)) == 3ULL ? 2U : ((__u64)((8ULL)) == 4ULL ? 3U : ((__u64)((8ULL)) == 5ULL ? 4U : ((__u64)((8ULL)) == 6ULL ? 5U : ((__u64)((8ULL)) == 7ULL ? 6U : ((__u64)((8ULL)) == 8ULL ? 7U : ((__u64)((8ULL)) == 9ULL ? 8U : ((__u64)((8ULL)) == 10ULL ? 9U : ((__u64)((8ULL)) == 11ULL ? 10U : ((__u64)((8ULL)) == 12ULL ? 11U : ((__u64)((8ULL)) == 14ULL ? 12U : ((__u64)((8ULL)) == 15ULL ? 13U : ((__u64)((8ULL)) == 16ULL ? 14U : ((__u64)((8ULL)) == 20ULL ? 15U : ((__u64)((8ULL)) == 21ULL ? 16U : ((__u64)((8ULL)) == 23ULL ? 17U : ((__u64)((8ULL)) == 25ULL ? 18U : ((__u64)((8ULL)) == 26ULL ? 19U : ((__u64)((8ULL)) == 27ULL ? 20U : ((__u64)((8ULL)) == 28ULL ? 21U : ((__u64)((8ULL)) == 32ULL ? 22U : ((__u64)((8ULL)) == 35ULL ? 23U : ((__u64)((8ULL)) == 36ULL ? 24U : ((__u64)((8ULL)) == 37ULL ? 25U : ((__u64)((8ULL)) == 38ULL ? 26U : ((__u64)((8ULL)) == 39ULL ? 27U : ((__u64)((8ULL)) == 43ULL ? 28U : ((__u64)((8ULL)) == 44ULL ? 29U : ((__u64)((8ULL)) == 45ULL ? 30U : ((__u64)((8ULL)) == 46ULL ? 31U : ((__u64)((8ULL)) == 50ULL ? 32U : ((__u64)((8ULL)) == 54ULL ? 33U : ((__u64)((8ULL)) == 58ULL ? 34U : ((__u64)((8ULL)) == 65ULL ? 35U : ((__u64)((8ULL)) == 67ULL ? 36U : ((__u64)((8ULL)) == 68ULL ? 37U : ((__u64)((8ULL)) == 69ULL ? 38U : ((__u64)((8ULL)) == 80ULL ? 39U : ((__u64)((8ULL)) == 85ULL ? 40U : ((__u64)((8ULL)) == 86ULL ? 41U : ((__u64)((8ULL)) == 87ULL ? 42U : ((__u64)((8ULL)) == 88ULL ? 43U : ((__u64)((8ULL)) == 95ULL ? 44U : ((__u64)((8ULL)) == 99ULL ? 45U : ((__u64)((8ULL)) == 105ULL ? 46U : ((__u64)((8ULL)) == 109ULL ? 47U : ((__u64)((8ULL)) == 112ULL ? 48U : ((__u64)((8ULL)) == 113ULL ? 49U : ((__u64)((8ULL)) == 114ULL ? 50U : ((__u64)((8ULL)) == 115ULL ? 51U : ((__u64)((8ULL)) == 118ULL ? 52U : ((__u64)((8ULL)) == 122ULL ? 53U : ((__u64)((8ULL)) == 124ULL ? 54U : ((__u64)((8ULL)) == 125ULL ? 55U : ((__u64)((8ULL)) == 130ULL ? 56U : ((__u64)((8ULL)) == 148ULL ? 57U : ((__u64)((8ULL)) == 152ULL ? 58U : ((__u64)((8ULL)) == 155ULL ? 59U : ((__u64)((8ULL)) == 158ULL ? 60U : ((__u64)((8ULL)) == 160ULL ? 61U : ((__u64)((8ULL)) == 163ULL ? 62U : ((__u64)((8ULL)) == 173ULL ? 63U : ((__u64)((8ULL)) == 174ULL ? 64U : ((__u64)((8ULL)) == 175ULL ? 65U : ((__u64)((8ULL)) == 181ULL ? 66U : ((__u64)((8ULL)) == 184ULL ? 67U : ((__u64)((8ULL)) == 189ULL ? 68U : ((__u64)((8ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 7U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((9ULL)) == 1ULL ? 0U : ((__u64)((9ULL)) == 2ULL ? 1U : ((__u64)((9ULL)) == 3ULL ? 2U : ((__u64)((9ULL)) == 4ULL ? 3U : ((__u64)((9ULL)) == 5ULL ? 4U : ((__u64)((9ULL)) == 6ULL ? 5U : ((__u64)((9ULL)) == 7ULL ? 6U : ((__u64)((9ULL)) == 8ULL ? 7U : ((__u64)((9ULL)) == 9ULL ? 8U : ((__u64)((9ULL)) == 10ULL ? 9U : ((__u64)((9ULL)) == 11ULL ? 10U : ((__u64)((9ULL)) == 12ULL ? 11U : ((__u64)((9ULL)) == 14ULL ? 12U : ((__u64)((9ULL)) == 15ULL ? 13U : ((__u64)((9ULL)) == 16ULL ? 14U : ((__u64)((9ULL)) == 20ULL ? 15U : ((__u64)((9ULL)) == 21ULL ? 16U : ((__u64)((9ULL)) == 23ULL ? 17U : ((__u64)((9ULL)) == 25ULL ? 18U : ((__u64)((9ULL)) == 26ULL ? 19U : ((__u64)((9ULL)) == 27ULL ? 20U : ((__u64)((9ULL)) == 28ULL ? 21U : ((__u64)((9ULL)) == 32ULL ? 22U : ((__u64)((9ULL)) == 35ULL ? 23U : ((__u64)((9ULL)) == 36ULL ? 24U : ((__u64)((9ULL)) == 37ULL ? 25U : ((__u64)((9ULL)) == 38ULL ? 26U : ((__u64)((9ULL)) == 39ULL ? 27U : ((__u64)((9ULL)) == 43ULL ? 28U : ((__u64)((9ULL)) == 44ULL ? 29U : ((__u64)((9ULL)) == 45ULL ? 30U : ((__u64)((9ULL)) == 46ULL ? 31U : ((__u64)((9ULL)) == 50ULL ? 32U : ((__u64)((9ULL)) == 54ULL ? 33U : ((__u64)((9ULL)) == 58ULL ? 34U : ((__u64)((9ULL)) == 65ULL ? 35U : ((__u64)((9ULL)) == 67ULL ? 36U : ((__u64)((9ULL)) == 68ULL ? 37U : ((__u64)((9ULL)) == 69ULL ? 38U : ((__u64)((9ULL)) == 80ULL ? 39U : ((__u64)((9ULL)) == 85ULL ? 40U : ((__u64)((9ULL)) == 86ULL ? 41U : ((__u64)((9ULL)) == 87ULL ? 42U : ((__u64)((9ULL)) == 88ULL ? 43U : ((__u64)((9ULL)) == 95ULL ? 44U : ((__u64)((9ULL)) == 99ULL ? 45U : ((__u64)((9ULL)) == 105ULL ? 46U : ((__u64)((9ULL)) == 109ULL ? 47U : ((__u64)((9ULL)) == 112ULL ? 48U : ((__u64)((9ULL)) == 113ULL ? 49U : ((__u64)((9ULL)) == 114ULL ? 50U : ((__u64)((9ULL)) == 115ULL ? 51U : ((__u64)((9ULL)) == 118ULL ? 52U : ((__u64)((9ULL)) == 122ULL ? 53U : ((__u64)((9ULL)) == 124ULL ? 54U : ((__u64)((9ULL)) == 125ULL ? 55U : ((__u64)((9ULL)) == 130ULL ? 56U : ((__u64)((9ULL)) == 148ULL ? 57U : ((__u64)((9ULL)) == 152ULL ? 58U : ((__u64)((9ULL)) == 155ULL ? 59U : ((__u64)((9ULL)) == 158ULL ? 60U : ((__u64)((9ULL)) == 160ULL ? 61U : ((__u64)((9ULL)) == 163ULL ? 62U : ((__u64)((9ULL)) == 173ULL ? 63U : ((__u64)((9ULL)) == 174ULL ? 64U : ((__u64)((9ULL)) == 175ULL ? 65U : ((__u64)((9ULL)) == 181ULL ? 66U : ((__u64)((9ULL)) == 184ULL ? 67U : ((__u64)((9ULL)) == 189ULL ? 68U : ((__u64)((9ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 8U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((10ULL)) == 1ULL ? 0U : ((__u64)((10ULL)) == 2ULL ? 1U : ((__u64)((10ULL)) == 3ULL ? 2U : ((__u64)((10ULL)) == 4ULL ? 3U : ((__u64)((10ULL)) == 5ULL ? 4U : ((__u64)((10ULL)) == 6ULL ? 5U : ((__u64)((10ULL)) == 7ULL ? 6U : ((__u64)((10ULL)) == 8ULL ? 7U : ((__u64)((10ULL)) == 9ULL ? 8U : ((__u64)((10ULL)) == 10ULL ? 9U : ((__u64)((10ULL)) == 11ULL ? 10U : ((__u64)((10ULL)) == 12ULL ? 11U : ((__u64)((10ULL)) == 14ULL ? 12U : ((__u64)((10ULL)) == 15ULL ? 13U : ((__u64)((10ULL)) == 16ULL ? 14U : ((__u64)((10ULL)) == 20ULL ? 15U : ((__u64)((10ULL)) == 21ULL ? 16U : ((__u64)((10ULL)) == 23ULL ? 17U : ((__u64)((10ULL)) == 25ULL ? 18U : ((__u64)((10ULL)) == 26ULL ? 19U : ((__u64)((10ULL)) == 27ULL ? 20U : ((__u64)((10ULL)) == 28ULL ? 21U : ((__u64)((10ULL)) == 32ULL ? 22U : ((__u64)((10ULL)) == 35ULL ? 23U : ((__u64)((10ULL)) == 36ULL ? 24U : ((__u64)((10ULL)) == 37ULL ? 25U : ((__u64)((10ULL)) == 38ULL ? 26U : ((__u64)((10ULL)) == 39ULL ? 27U : ((__u64)((10ULL)) == 43ULL ? 28U : ((__u64)((10ULL)) == 44ULL ? 29U : ((__u64)((10ULL)) == 45ULL ? 30U : ((__u64)((10ULL)) == 46ULL ? 31U : ((__u64)((10ULL)) == 50ULL ? 32U : ((__u64)((10ULL)) == 54ULL ? 33U : ((__u64)((10ULL)) == 58ULL ? 34U : ((__u64)((10ULL)) == 65ULL ? 35U : ((__u64)((10ULL)) == 67ULL ? 36U : ((__u64)((10ULL)) == 68ULL ? 37U : ((__u64)((10ULL)) == 69ULL ? 38U : ((__u64)((10ULL)) == 80ULL ? 39U : ((__u64)((10ULL)) == 85ULL ? 40U : ((__u64)((10ULL)) == 86ULL ? 41U : ((__u64)((10ULL)) == 87ULL ? 42U : ((__u64)((10ULL)) == 88ULL ? 43U : ((__u64)((10ULL)) == 95ULL ? 44U : ((__u64)((10ULL)) == 99ULL ? 45U : ((__u64)((10ULL)) == 105ULL ? 46U : ((__u64)((10ULL)) == 109ULL ? 47U : ((__u64)((10ULL)) == 112ULL ? 48U : ((__u64)((10ULL)) == 113ULL ? 49U : ((__u64)((10ULL)) == 114ULL ? 50U : ((__u64)((10ULL)) == 115ULL ? 51U : ((__u64)((10ULL)) == 118ULL ? 52U : ((__u64)((10ULL)) == 122ULL ? 53U : ((__u64)((10ULL)) == 124ULL ? 54U : ((__u64)((10ULL)) == 125ULL ? 55U : ((__u64)((10ULL)) == 130ULL ? 56U : ((__u64)((10ULL)) == 148ULL ? 57U : ((__u64)((10ULL)) == 152ULL ? 58U : ((__u64)((10ULL)) == 155ULL ? 59U : ((__u64)((10ULL)) == 158ULL ? 60U : ((__u64)((10ULL)) == 160ULL ? 61U : ((__u64)((10ULL)) == 163ULL ? 62U : ((__u64)((10ULL)) == 173ULL ? 63U : ((__u64)((10ULL)) == 174ULL ? 64U : ((__u64)((10ULL)) == 175ULL ? 65U : ((__u64)((10ULL)) == 181ULL ? 66U : ((__u64)((10ULL)) == 184ULL ? 67U : ((__u64)((10ULL)) == 189ULL ? 68U : ((__u64)((10ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 9U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((11ULL)) == 1ULL ? 0U : ((__u64)((11ULL)) == 2ULL ? 1U : ((__u64)((11ULL)) == 3ULL ? 2U : ((__u64)((11ULL)) == 4ULL ? 3U : ((__u64)((11ULL)) == 5ULL ? 4U : ((__u64)((11ULL)) == 6ULL ? 5U : ((__u64)((11ULL)) == 7ULL ? 6U : ((__u64)((11ULL)) == 8ULL ? 7U : ((__u64)((11ULL)) == 9ULL ? 8U : ((__u64)((11ULL)) == 10ULL ? 9U : ((__u64)((11ULL)) == 11ULL ? 10U : ((__u64)((11ULL)) == 12ULL ? 11U : ((__u64)((11ULL)) == 14ULL ? 12U : ((__u64)((11ULL)) == 15ULL ? 13U : ((__u64)((11ULL)) == 16ULL ? 14U : ((__u64)((11ULL)) == 20ULL ? 15U : ((__u64)((11ULL)) == 21ULL ? 16U : ((__u64)((11ULL)) == 23ULL ? 17U : ((__u64)((11ULL)) == 25ULL ? 18U : ((__u64)((11ULL)) == 26ULL ? 19U : ((__u64)((11ULL)) == 27ULL ? 20U : ((__u64)((11ULL)) == 28ULL ? 21U : ((__u64)((11ULL)) == 32ULL ? 22U : ((__u64)((11ULL)) == 35ULL ? 23U : ((__u64)((11ULL)) == 36ULL ? 24U : ((__u64)((11ULL)) == 37ULL ? 25U : ((__u64)((11ULL)) == 38ULL ? 26U : ((__u64)((11ULL)) == 39ULL ? 27U : ((__u64)((11ULL)) == 43ULL ? 28U : ((__u64)((11ULL)) == 44ULL ? 29U : ((__u64)((11ULL)) == 45ULL ? 30U : ((__u64)((11ULL)) == 46ULL ? 31U : ((__u64)((11ULL)) == 50ULL ? 32U : ((__u64)((11ULL)) == 54ULL ? 33U : ((__u64)((11ULL)) == 58ULL ? 34U : ((__u64)((11ULL)) == 65ULL ? 35U : ((__u64)((11ULL)) == 67ULL ? 36U : ((__u64)((11ULL)) == 68ULL ? 37U : ((__u64)((11ULL)) == 69ULL ? 38U : ((__u64)((11ULL)) == 80ULL ? 39U : ((__u64)((11ULL)) == 85ULL ? 40U : ((__u64)((11ULL)) == 86ULL ? 41U : ((__u64)((11ULL)) == 87ULL ? 42U : ((__u64)((11ULL)) == 88ULL ? 43U : ((__u64)((11ULL)) == 95ULL ? 44U : ((__u64)((11ULL)) == 99ULL ? 45U : ((__u64)((11ULL)) == 105ULL ? 46U : ((__u64)((11ULL)) == 109ULL ? 47U : ((__u64)((11ULL)) == 112ULL ? 48U : ((__u64)((11ULL)) == 113ULL ? 49U : ((__u64)((11ULL)) == 114ULL ? 50U : ((__u64)((11ULL)) == 115ULL ? 51U : ((__u64)((11ULL)) == 118ULL ? 52U : ((__u64)((11ULL)) == 122ULL ? 53U : ((__u64)((11ULL)) == 124ULL ? 54U : ((__u64)((11ULL)) == 125ULL ? 55U : ((__u64)((11ULL)) == 130ULL ? 56U : ((__u64)((11ULL)) == 148ULL ? 57U : ((__u64)((11ULL)) == 152ULL ? 58U : ((__u64)((11ULL)) == 155ULL ? 59U : ((__u64)((11ULL)) == 158ULL ? 60U : ((__u64)((11ULL)) == 160ULL ? 61U : ((__u64)((11ULL)) == 163ULL ? 62U : ((__u64)((11ULL)) == 173ULL ? 63U : ((__u64)((11ULL)) == 174ULL ? 64U : ((__u64)((11ULL)) == 175ULL ? 65U : ((__u64)((11ULL)) == 181ULL ? 66U : ((__u64)((11ULL)) == 184ULL ? 67U : ((__u64)((11ULL)) == 189ULL ? 68U : ((__u64)((11ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 10U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((12ULL)) == 1ULL ? 0U : ((__u64)((12ULL)) == 2ULL ? 1U : ((__u64)((12ULL)) == 3ULL ? 2U : ((__u64)((12ULL)) == 4ULL ? 3U : ((__u64)((12ULL)) == 5ULL ? 4U : ((__u64)((12ULL)) == 6ULL ? 5U : ((__u64)((12ULL)) == 7ULL ? 6U : ((__u64)((12ULL)) == 8ULL ? 7U : ((__u64)((12ULL)) == 9ULL ? 8U : ((__u64)((12ULL)) == 10ULL ? 9U : ((__u64)((12ULL)) == 11ULL ? 10U : ((__u64)((12ULL)) == 12ULL ? 11U : ((__u64)((12ULL)) == 14ULL ? 12U : ((__u64)((12ULL)) == 15ULL ? 13U : ((__u64)((12ULL)) == 16ULL ? 14U : ((__u64)((12ULL)) == 20ULL ? 15U : ((__u64)((12ULL)) == 21ULL ? 16U : ((__u64)((12ULL)) == 23ULL ? 17U : ((__u64)((12ULL)) == 25ULL ? 18U : ((__u64)((12ULL)) == 26ULL ? 19U : ((__u64)((12ULL)) == 27ULL ? 20U : ((__u64)((12ULL)) == 28ULL ? 21U : ((__u64)((12ULL)) == 32ULL ? 22U : ((__u64)((12ULL)) == 35ULL ? 23U : ((__u64)((12ULL)) == 36ULL ? 24U : ((__u64)((12ULL)) == 37ULL ? 25U : ((__u64)((12ULL)) == 38ULL ? 26U : ((__u64)((12ULL)) == 39ULL ? 27U : ((__u64)((12ULL)) == 43ULL ? 28U : ((__u64)((12ULL)) == 44ULL ? 29U : ((__u64)((12ULL)) == 45ULL ? 30U : ((__u64)((12ULL)) == 46ULL ? 31U : ((__u64)((12ULL)) == 50ULL ? 32U : ((__u64)((12ULL)) == 54ULL ? 33U : ((__u64)((12ULL)) == 58ULL ? 34U : ((__u64)((12ULL)) == 65ULL ? 35U : ((__u64)((12ULL)) == 67ULL ? 36U : ((__u64)((12ULL)) == 68ULL ? 37U : ((__u64)((12ULL)) == 69ULL ? 38U : ((__u64)((12ULL)) == 80ULL ? 39U : ((__u64)((12ULL)) == 85ULL ? 40U : ((__u64)((12ULL)) == 86ULL ? 41U : ((__u64)((12ULL)) == 87ULL ? 42U : ((__u64)((12ULL)) == 88ULL ? 43U : ((__u64)((12ULL)) == 95ULL ? 44U : ((__u64)((12ULL)) == 99ULL ? 45U : ((__u64)((12ULL)) == 105ULL ? 46U : ((__u64)((12ULL)) == 109ULL ? 47U : ((__u64)((12ULL)) == 112ULL ? 48U : ((__u64)((12ULL)) == 113ULL ? 49U : ((__u64)((12ULL)) == 114ULL ? 50U : ((__u64)((12ULL)) == 115ULL ? 51U : ((__u64)((12ULL)) == 118ULL ? 52U : ((__u64)((12ULL)) == 122ULL ? 53U : ((__u64)((12ULL)) == 124ULL ? 54U : ((__u64)((12ULL)) == 125ULL ? 55U : ((__u64)((12ULL)) == 130ULL ? 56U : ((__u64)((12ULL)) == 148ULL ? 57U : ((__u64)((12ULL)) == 152ULL ? 58U : ((__u64)((12ULL)) == 155ULL ? 59U : ((__u64)((12ULL)) == 158ULL ? 60U : ((__u64)((12ULL)) == 160ULL ? 61U : ((__u64)((12ULL)) == 163ULL ? 62U : ((__u64)((12ULL)) == 173ULL ? 63U : ((__u64)((12ULL)) == 174ULL ? 64U : ((__u64)((12ULL)) == 175ULL ? 65U : ((__u64)((12ULL)) == 181ULL ? 66U : ((__u64)((12ULL)) == 184ULL ? 67U : ((__u64)((12ULL)) == 189ULL ? 68U : ((__u64)((12ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 11U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((14ULL)) == 1ULL ? 0U : ((__u64)((14ULL)) == 2ULL ? 1U : ((__u64)((14ULL)) == 3ULL ? 2U : ((__u64)((14ULL)) == 4ULL ? 3U : ((__u64)((14ULL)) == 5ULL ? 4U : ((__u64)((14ULL)) == 6ULL ? 5U : ((__u64)((14ULL)) == 7ULL ? 6U : ((__u64)((14ULL)) == 8ULL ? 7U : ((__u64)((14ULL)) == 9ULL ? 8U : ((__u64)((14ULL)) == 10ULL ? 9U : ((__u64)((14ULL)) == 11ULL ? 10U : ((__u64)((14ULL)) == 12ULL ? 11U : ((__u64)((14ULL)) == 14ULL ? 12U : ((__u64)((14ULL)) == 15ULL ? 13U : ((__u64)((14ULL)) == 16ULL ? 14U : ((__u64)((14ULL)) == 20ULL ? 15U : ((__u64)((14ULL)) == 21ULL ? 16U : ((__u64)((14ULL)) == 23ULL ? 17U : ((__u64)((14ULL)) == 25ULL ? 18U : ((__u64)((14ULL)) == 26ULL ? 19U : ((__u64)((14ULL)) == 27ULL ? 20U : ((__u64)((14ULL)) == 28ULL ? 21U : ((__u64)((14ULL)) == 32ULL ? 22U : ((__u64)((14ULL)) == 35ULL ? 23U : ((__u64)((14ULL)) == 36ULL ? 24U : ((__u64)((14ULL)) == 37ULL ? 25U : ((__u64)((14ULL)) == 38ULL ? 26U : ((__u64)((14ULL)) == 39ULL ? 27U : ((__u64)((14ULL)) == 43ULL ? 28U : ((__u64)((14ULL)) == 44ULL ? 29U : ((__u64)((14ULL)) == 45ULL ? 30U : ((__u64)((14ULL)) == 46ULL ? 31U : ((__u64)((14ULL)) == 50ULL ? 32U : ((__u64)((14ULL)) == 54ULL ? 33U : ((__u64)((14ULL)) == 58ULL ? 34U : ((__u64)((14ULL)) == 65ULL ? 35U : ((__u64)((14ULL)) == 67ULL ? 36U : ((__u64)((14ULL)) == 68ULL ? 37U : ((__u64)((14ULL)) == 69ULL ? 38U : ((__u64)((14ULL)) == 80ULL ? 39U : ((__u64)((14ULL)) == 85ULL ? 40U : ((__u64)((14ULL)) == 86ULL ? 41U : ((__u64)((14ULL)) == 87ULL ? 42U : ((__u64)((14ULL)) == 88ULL ? 43U : ((__u64)((14ULL)) == 95ULL ? 44U : ((__u64)((14ULL)) == 99ULL ? 45U : ((__u64)((14ULL)) == 105ULL ? 46U : ((__u64)((14ULL)) == 109ULL ? 47U : ((__u64)((14ULL)) == 112ULL ? 48U : ((__u64)((14ULL)) == 113ULL ? 49U : ((__u64)((14ULL)) == 114ULL ? 50U : ((__u64)((14ULL)) == 115ULL ? 51U : ((__u64)((14ULL)) == 118ULL ? 52U : ((__u64)((14ULL)) == 122ULL ? 53U : ((__u64)((14ULL)) == 124ULL ? 54U : ((__u64)((14ULL)) == 125ULL ? 55U : ((__u64)((14ULL)) == 130ULL ? 56U : ((__u64)((14ULL)) == 148ULL ? 57U : ((__u64)((14ULL)) == 152ULL ? 58U : ((__u64)((14ULL)) == 155ULL ? 59U : ((__u64)((14ULL)) == 158ULL ? 60U : ((__u64)((14ULL)) == 160ULL ? 61U : ((__u64)((14ULL)) == 163ULL ? 62U : ((__u64)((14ULL)) == 173ULL ? 63U : ((__u64)((14ULL)) == 174ULL ? 64U : ((__u64)((14ULL)) == 175ULL ? 65U : ((__u64)((14ULL)) == 181ULL ? 66U : ((__u64)((14ULL)) == 184ULL ? 67U : ((__u64)((14ULL)) == 189ULL ? 68U : ((__u64)((14ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 12U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((15ULL)) == 1ULL ? 0U : ((__u64)((15ULL)) == 2ULL ? 1U : ((__u64)((15ULL)) == 3ULL ? 2U : ((__u64)((15ULL)) == 4ULL ? 3U : ((__u64)((15ULL)) == 5ULL ? 4U : ((__u64)((15ULL)) == 6ULL ? 5U : ((__u64)((15ULL)) == 7ULL ? 6U : ((__u64)((15ULL)) == 8ULL ? 7U : ((__u64)((15ULL)) == 9ULL ? 8U : ((__u64)((15ULL)) == 10ULL ? 9U : ((__u64)((15ULL)) == 11ULL ? 10U : ((__u64)((15ULL)) == 12ULL ? 11U : ((__u64)((15ULL)) == 14ULL ? 12U : ((__u64)((15ULL)) == 15ULL ? 13U : ((__u64)((15ULL)) == 16ULL ? 14U : ((__u64)((15ULL)) == 20ULL ? 15U : ((__u64)((15ULL)) == 21ULL ? 16U : ((__u64)((15ULL)) == 23ULL ? 17U : ((__u64)((15ULL)) == 25ULL ? 18U : ((__u64)((15ULL)) == 26ULL ? 19U : ((__u64)((15ULL)) == 27ULL ? 20U : ((__u64)((15ULL)) == 28ULL ? 21U : ((__u64)((15ULL)) == 32ULL ? 22U : ((__u64)((15ULL)) == 35ULL ? 23U : ((__u64)((15ULL)) == 36ULL ? 24U : ((__u64)((15ULL)) == 37ULL ? 25U : ((__u64)((15ULL)) == 38ULL ? 26U : ((__u64)((15ULL)) == 39ULL ? 27U : ((__u64)((15ULL)) == 43ULL ? 28U : ((__u64)((15ULL)) == 44ULL ? 29U : ((__u64)((15ULL)) == 45ULL ? 30U : ((__u64)((15ULL)) == 46ULL ? 31U : ((__u64)((15ULL)) == 50ULL ? 32U : ((__u64)((15ULL)) == 54ULL ? 33U : ((__u64)((15ULL)) == 58ULL ? 34U : ((__u64)((15ULL)) == 65ULL ? 35U : ((__u64)((15ULL)) == 67ULL ? 36U : ((__u64)((15ULL)) == 68ULL ? 37U : ((__u64)((15ULL)) == 69ULL ? 38U : ((__u64)((15ULL)) == 80ULL ? 39U : ((__u64)((15ULL)) == 85ULL ? 40U : ((__u64)((15ULL)) == 86ULL ? 41U : ((__u64)((15ULL)) == 87ULL ? 42U : ((__u64)((15ULL)) == 88ULL ? 43U : ((__u64)((15ULL)) == 95ULL ? 44U : ((__u64)((15ULL)) == 99ULL ? 45U : ((__u64)((15ULL)) == 105ULL ? 46U : ((__u64)((15ULL)) == 109ULL ? 47U : ((__u64)((15ULL)) == 112ULL ? 48U : ((__u64)((15ULL)) == 113ULL ? 49U : ((__u64)((15ULL)) == 114ULL ? 50U : ((__u64)((15ULL)) == 115ULL ? 51U : ((__u64)((15ULL)) == 118ULL ? 52U : ((__u64)((15ULL)) == 122ULL ? 53U : ((__u64)((15ULL)) == 124ULL ? 54U : ((__u64)((15ULL)) == 125ULL ? 55U : ((__u64)((15ULL)) == 130ULL ? 56U : ((__u64)((15ULL)) == 148ULL ? 57U : ((__u64)((15ULL)) == 152ULL ? 58U : ((__u64)((15ULL)) == 155ULL ? 59U : ((__u64)((15ULL)) == 158ULL ? 60U : ((__u64)((15ULL)) == 160ULL ? 61U : ((__u64)((15ULL)) == 163ULL ? 62U : ((__u64)((15ULL)) == 173ULL ? 63U : ((__u64)((15ULL)) == 174ULL ? 64U : ((__u64)((15ULL)) == 175ULL ? 65U : ((__u64)((15ULL)) == 181ULL ? 66U : ((__u64)((15ULL)) == 184ULL ? 67U : ((__u64)((15ULL)) == 189ULL ? 68U : ((__u64)((15ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 13U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((16ULL)) == 1ULL ? 0U : ((__u64)((16ULL)) == 2ULL ? 1U : ((__u64)((16ULL)) == 3ULL ? 2U : ((__u64)((16ULL)) == 4ULL ? 3U : ((__u64)((16ULL)) == 5ULL ? 4U : ((__u64)((16ULL)) == 6ULL ? 5U : ((__u64)((16ULL)) == 7ULL ? 6U : ((__u64)((16ULL)) == 8ULL ? 7U : ((__u64)((16ULL)) == 9ULL ? 8U : ((__u64)((16ULL)) == 10ULL ? 9U : ((__u64)((16ULL)) == 11ULL ? 10U : ((__u64)((16ULL)) == 12ULL ? 11U : ((__u64)((16ULL)) == 14ULL ? 12U : ((__u64)((16ULL)) == 15ULL ? 13U : ((__u64)((16ULL)) == 16ULL ? 14U : ((__u64)((16ULL)) == 20ULL ? 15U : ((__u64)((16ULL)) == 21ULL ? 16U : ((__u64)((16ULL)) == 23ULL ? 17U : ((__u64)((16ULL)) == 25ULL ? 18U : ((__u64)((16ULL)) == 26ULL ? 19U : ((__u64)((16ULL)) == 27ULL ? 20U : ((__u64)((16ULL)) == 28ULL ? 21U : ((__u64)((16ULL)) == 32ULL ? 22U : ((__u64)((16ULL)) == 35ULL ? 23U : ((__u64)((16ULL)) == 36ULL ? 24U : ((__u64)((16ULL)) == 37ULL ? 25U : ((__u64)((16ULL)) == 38ULL ? 26U : ((__u64)((16ULL)) == 39ULL ? 27U : ((__u64)((16ULL)) == 43ULL ? 28U : ((__u64)((16ULL)) == 44ULL ? 29U : ((__u64)((16ULL)) == 45ULL ? 30U : ((__u64)((16ULL)) == 46ULL ? 31U : ((__u64)((16ULL)) == 50ULL ? 32U : ((__u64)((16ULL)) == 54ULL ? 33U : ((__u64)((16ULL)) == 58ULL ? 34U : ((__u64)((16ULL)) == 65ULL ? 35U : ((__u64)((16ULL)) == 67ULL ? 36U : ((__u64)((16ULL)) == 68ULL ? 37U : ((__u64)((16ULL)) == 69ULL ? 38U : ((__u64)((16ULL)) == 80ULL ? 39U : ((__u64)((16ULL)) == 85ULL ? 40U : ((__u64)((16ULL)) == 86ULL ? 41U : ((__u64)((16ULL)) == 87ULL ? 42U : ((__u64)((16ULL)) == 88ULL ? 43U : ((__u64)((16ULL)) == 95ULL ? 44U : ((__u64)((16ULL)) == 99ULL ? 45U : ((__u64)((16ULL)) == 105ULL ? 46U : ((__u64)((16ULL)) == 109ULL ? 47U : ((__u64)((16ULL)) == 112ULL ? 48U : ((__u64)((16ULL)) == 113ULL ? 49U : ((__u64)((16ULL)) == 114ULL ? 50U : ((__u64)((16ULL)) == 115ULL ? 51U : ((__u64)((16ULL)) == 118ULL ? 52U : ((__u64)((16ULL)) == 122ULL ? 53U : ((__u64)((16ULL)) == 124ULL ? 54U : ((__u64)((16ULL)) == 125ULL ? 55U : ((__u64)((16ULL)) == 130ULL ? 56U : ((__u64)((16ULL)) == 148ULL ? 57U : ((__u64)((16ULL)) == 152ULL ? 58U : ((__u64)((16ULL)) == 155ULL ? 59U : ((__u64)((16ULL)) == 158ULL ? 60U : ((__u64)((16ULL)) == 160ULL ? 61U : ((__u64)((16ULL)) == 163ULL ? 62U : ((__u64)((16ULL)) == 173ULL ? 63U : ((__u64)((16ULL)) == 174ULL ? 64U : ((__u64)((16ULL)) == 175ULL ? 65U : ((__u64)((16ULL)) == 181ULL ? 66U : ((__u64)((16ULL)) == 184ULL ? 67U : ((__u64)((16ULL)) == 189ULL ? 68U : ((__u64)((16ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 14U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((20ULL)) == 1ULL ? 0U : ((__u64)((20ULL)) == 2ULL ? 1U : ((__u64)((20ULL)) == 3ULL ? 2U : ((__u64)((20ULL)) == 4ULL ? 3U : ((__u64)((20ULL)) == 5ULL ? 4U : ((__u64)((20ULL)) == 6ULL ? 5U : ((__u64)((20ULL)) == 7ULL ? 6U : ((__u64)((20ULL)) == 8ULL ? 7U : ((__u64)((20ULL)) == 9ULL ? 8U : ((__u64)((20ULL)) == 10ULL ? 9U : ((__u64)((20ULL)) == 11ULL ? 10U : ((__u64)((20ULL)) == 12ULL ? 11U : ((__u64)((20ULL)) == 14ULL ? 12U : ((__u64)((20ULL)) == 15ULL ? 13U : ((__u64)((20ULL)) == 16ULL ? 14U : ((__u64)((20ULL)) == 20ULL ? 15U : ((__u64)((20ULL)) == 21ULL ? 16U : ((__u64)((20ULL)) == 23ULL ? 17U : ((__u64)((20ULL)) == 25ULL ? 18U : ((__u64)((20ULL)) == 26ULL ? 19U : ((__u64)((20ULL)) == 27ULL ? 20U : ((__u64)((20ULL)) == 28ULL ? 21U : ((__u64)((20ULL)) == 32ULL ? 22U : ((__u64)((20ULL)) == 35ULL ? 23U : ((__u64)((20ULL)) == 36ULL ? 24U : ((__u64)((20ULL)) == 37ULL ? 25U : ((__u64)((20ULL)) == 38ULL ? 26U : ((__u64)((20ULL)) == 39ULL ? 27U : ((__u64)((20ULL)) == 43ULL ? 28U : ((__u64)((20ULL)) == 44ULL ? 29U : ((__u64)((20ULL)) == 45ULL ? 30U : ((__u64)((20ULL)) == 46ULL ? 31U : ((__u64)((20ULL)) == 50ULL ? 32U : ((__u64)((20ULL)) == 54ULL ? 33U : ((__u64)((20ULL)) == 58ULL ? 34U : ((__u64)((20ULL)) == 65ULL ? 35U : ((__u64)((20ULL)) == 67ULL ? 36U : ((__u64)((20ULL)) == 68ULL ? 37U : ((__u64)((20ULL)) == 69ULL ? 38U : ((__u64)((20ULL)) == 80ULL ? 39U : ((__u64)((20ULL)) == 85ULL ? 40U : ((__u64)((20ULL)) == 86ULL ? 41U : ((__u64)((20ULL)) == 87ULL ? 42U : ((__u64)((20ULL)) == 88ULL ? 43U : ((__u64)((20ULL)) == 95ULL ? 44U : ((__u64)((20ULL)) == 99ULL ? 45U : ((__u64)((20ULL)) == 105ULL ? 46U : ((__u64)((20ULL)) == 109ULL ? 47U : ((__u64)((20ULL)) == 112ULL ? 48U : ((__u64)((20ULL)) == 113ULL ? 49U : ((__u64)((20ULL)) == 114ULL ? 50U : ((__u64)((20ULL)) == 115ULL ? 51U : ((__u64)((20ULL)) == 118ULL ? 52U : ((__u64)((20ULL)) == 122ULL ? 53U : ((__u64)((20ULL)) == 124ULL ? 54U : ((__u64)((20ULL)) == 125ULL ? 55U : ((__u64)((20ULL)) == 130ULL ? 56U : ((__u64)((20ULL)) == 148ULL ? 57U : ((__u64)((20ULL)) == 152ULL ? 58U : ((__u64)((20ULL)) == 155ULL ? 59U : ((__u64)((20ULL)) == 158ULL ? 60U : ((__u64)((20ULL)) == 160ULL ? 61U : ((__u64)((20ULL)) == 163ULL ? 62U : ((__u64)((20ULL)) == 173ULL ? 63U : ((__u64)((20ULL)) == 174ULL ? 64U : ((__u64)((20ULL)) == 175ULL ? 65U : ((__u64)((20ULL)) == 181ULL ? 66U : ((__u64)((20ULL)) == 184ULL ? 67U : ((__u64)((20ULL)) == 189ULL ? 68U : ((__u64)((20ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 15U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((21ULL)) == 1ULL ? 0U : ((__u64)((21ULL)) == 2ULL ? 1U : ((__u64)((21ULL)) == 3ULL ? 2U : ((__u64)((21ULL)) == 4ULL ? 3U : ((__u64)((21ULL)) == 5ULL ? 4U : ((__u64)((21ULL)) == 6ULL ? 5U : ((__u64)((21ULL)) == 7ULL ? 6U : ((__u64)((21ULL)) == 8ULL ? 7U : ((__u64)((21ULL)) == 9ULL ? 8U : ((__u64)((21ULL)) == 10ULL ? 9U : ((__u64)((21ULL)) == 11ULL ? 10U : ((__u64)((21ULL)) == 12ULL ? 11U : ((__u64)((21ULL)) == 14ULL ? 12U : ((__u64)((21ULL)) == 15ULL ? 13U : ((__u64)((21ULL)) == 16ULL ? 14U : ((__u64)((21ULL)) == 20ULL ? 15U : ((__u64)((21ULL)) == 21ULL ? 16U : ((__u64)((21ULL)) == 23ULL ? 17U : ((__u64)((21ULL)) == 25ULL ? 18U : ((__u64)((21ULL)) == 26ULL ? 19U : ((__u64)((21ULL)) == 27ULL ? 20U : ((__u64)((21ULL)) == 28ULL ? 21U : ((__u64)((21ULL)) == 32ULL ? 22U : ((__u64)((21ULL)) == 35ULL ? 23U : ((__u64)((21ULL)) == 36ULL ? 24U : ((__u64)((21ULL)) == 37ULL ? 25U : ((__u64)((21ULL)) == 38ULL ? 26U : ((__u64)((21ULL)) == 39ULL ? 27U : ((__u64)((21ULL)) == 43ULL ? 28U : ((__u64)((21ULL)) == 44ULL ? 29U : ((__u64)((21ULL)) == 45ULL ? 30U : ((__u64)((21ULL)) == 46ULL ? 31U : ((__u64)((21ULL)) == 50ULL ? 32U : ((__u64)((21ULL)) == 54ULL ? 33U : ((__u64)((21ULL)) == 58ULL ? 34U : ((__u64)((21ULL)) == 65ULL ? 35U : ((__u64)((21ULL)) == 67ULL ? 36U : ((__u64)((21ULL)) == 68ULL ? 37U : ((__u64)((21ULL)) == 69ULL ? 38U : ((__u64)((21ULL)) == 80ULL ? 39U : ((__u64)((21ULL)) == 85ULL ? 40U : ((__u64)((21ULL)) == 86ULL ? 41U : ((__u64)((21ULL)) == 87ULL ? 42U : ((__u64)((21ULL)) == 88ULL ? 43U : ((__u64)((21ULL)) == 95ULL ? 44U : ((__u64)((21ULL)) == 99ULL ? 45U : ((__u64)((21ULL)) == 105ULL ? 46U : ((__u64)((21ULL)) == 109ULL ? 47U : ((__u64)((21ULL)) == 112ULL ? 48U : ((__u64)((21ULL)) == 113ULL ? 49U : ((__u64)((21ULL)) == 114ULL ? 50U : ((__u64)((21ULL)) == 115ULL ? 51U : ((__u64)((21ULL)) == 118ULL ? 52U : ((__u64)((21ULL)) == 122ULL ? 53U : ((__u64)((21ULL)) == 124ULL ? 54U : ((__u64)((21ULL)) == 125ULL ? 55U : ((__u64)((21ULL)) == 130ULL ? 56U : ((__u64)((21ULL)) == 148ULL ? 57U : ((__u64)((21ULL)) == 152ULL ? 58U : ((__u64)((21ULL)) == 155ULL ? 59U : ((__u64)((21ULL)) == 158ULL ? 60U : ((__u64)((21ULL)) == 160ULL ? 61U : ((__u64)((21ULL)) == 163ULL ? 62U : ((__u64)((21ULL)) == 173ULL ? 63U : ((__u64)((21ULL)) == 174ULL ? 64U : ((__u64)((21ULL)) == 175ULL ? 65U : ((__u64)((21ULL)) == 181ULL ? 66U : ((__u64)((21ULL)) == 184ULL ? 67U : ((__u64)((21ULL)) == 189ULL ? 68U : ((__u64)((21ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 16U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((23ULL)) == 1ULL ? 0U : ((__u64)((23ULL)) == 2ULL ? 1U : ((__u64)((23ULL)) == 3ULL ? 2U : ((__u64)((23ULL)) == 4ULL ? 3U : ((__u64)((23ULL)) == 5ULL ? 4U : ((__u64)((23ULL)) == 6ULL ? 5U : ((__u64)((23ULL)) == 7ULL ? 6U : ((__u64)((23ULL)) == 8ULL ? 7U : ((__u64)((23ULL)) == 9ULL ? 8U : ((__u64)((23ULL)) == 10ULL ? 9U : ((__u64)((23ULL)) == 11ULL ? 10U : ((__u64)((23ULL)) == 12ULL ? 11U : ((__u64)((23ULL)) == 14ULL ? 12U : ((__u64)((23ULL)) == 15ULL ? 13U : ((__u64)((23ULL)) == 16ULL ? 14U : ((__u64)((23ULL)) == 20ULL ? 15U : ((__u64)((23ULL)) == 21ULL ? 16U : ((__u64)((23ULL)) == 23ULL ? 17U : ((__u64)((23ULL)) == 25ULL ? 18U : ((__u64)((23ULL)) == 26ULL ? 19U : ((__u64)((23ULL)) == 27ULL ? 20U : ((__u64)((23ULL)) == 28ULL ? 21U : ((__u64)((23ULL)) == 32ULL ? 22U : ((__u64)((23ULL)) == 35ULL ? 23U : ((__u64)((23ULL)) == 36ULL ? 24U : ((__u64)((23ULL)) == 37ULL ? 25U : ((__u64)((23ULL)) == 38ULL ? 26U : ((__u64)((23ULL)) == 39ULL ? 27U : ((__u64)((23ULL)) == 43ULL ? 28U : ((__u64)((23ULL)) == 44ULL ? 29U : ((__u64)((23ULL)) == 45ULL ? 30U : ((__u64)((23ULL)) == 46ULL ? 31U : ((__u64)((23ULL)) == 50ULL ? 32U : ((__u64)((23ULL)) == 54ULL ? 33U : ((__u64)((23ULL)) == 58ULL ? 34U : ((__u64)((23ULL)) == 65ULL ? 35U : ((__u64)((23ULL)) == 67ULL ? 36U : ((__u64)((23ULL)) == 68ULL ? 37U : ((__u64)((23ULL)) == 69ULL ? 38U : ((__u64)((23ULL)) == 80ULL ? 39U : ((__u64)((23ULL)) == 85ULL ? 40U : ((__u64)((23ULL)) == 86ULL ? 41U : ((__u64)((23ULL)) == 87ULL ? 42U : ((__u64)((23ULL)) == 88ULL ? 43U : ((__u64)((23ULL)) == 95ULL ? 44U : ((__u64)((23ULL)) == 99ULL ? 45U : ((__u64)((23ULL)) == 105ULL ? 46U : ((__u64)((23ULL)) == 109ULL ? 47U : ((__u64)((23ULL)) == 112ULL ? 48U : ((__u64)((23ULL)) == 113ULL ? 49U : ((__u64)((23ULL)) == 114ULL ? 50U : ((__u64)((23ULL)) == 115ULL ? 51U : ((__u64)((23ULL)) == 118ULL ? 52U : ((__u64)((23ULL)) == 122ULL ? 53U : ((__u64)((23ULL)) == 124ULL ? 54U : ((__u64)((23ULL)) == 125ULL ? 55U : ((__u64)((23ULL)) == 130ULL ? 56U : ((__u64)((23ULL)) == 148ULL ? 57U : ((__u64)((23ULL)) == 152ULL ? 58U : ((__u64)((23ULL)) == 155ULL ? 59U : ((__u64)((23ULL)) == 158ULL ? 60U : ((__u64)((23ULL)) == 160ULL ? 61U : ((__u64)((23ULL)) == 163ULL ? 62U : ((__u64)((23ULL)) == 173ULL ? 63U : ((__u64)((23ULL)) == 174ULL ? 64U : ((__u64)((23ULL)) == 175ULL ? 65U : ((__u64)((23ULL)) == 181ULL ? 66U : ((__u64)((23ULL)) == 184ULL ? 67U : ((__u64)((23ULL)) == 189ULL ? 68U : ((__u64)((23ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 17U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((25ULL)) == 1ULL ? 0U : ((__u64)((25ULL)) == 2ULL ? 1U : ((__u64)((25ULL)) == 3ULL ? 2U : ((__u64)((25ULL)) == 4ULL ? 3U : ((__u64)((25ULL)) == 5ULL ? 4U : ((__u64)((25ULL)) == 6ULL ? 5U : ((__u64)((25ULL)) == 7ULL ? 6U : ((__u64)((25ULL)) == 8ULL ? 7U : ((__u64)((25ULL)) == 9ULL ? 8U : ((__u64)((25ULL)) == 10ULL ? 9U : ((__u64)((25ULL)) == 11ULL ? 10U : ((__u64)((25ULL)) == 12ULL ? 11U : ((__u64)((25ULL)) == 14ULL ? 12U : ((__u64)((25ULL)) == 15ULL ? 13U : ((__u64)((25ULL)) == 16ULL ? 14U : ((__u64)((25ULL)) == 20ULL ? 15U : ((__u64)((25ULL)) == 21ULL ? 16U : ((__u64)((25ULL)) == 23ULL ? 17U : ((__u64)((25ULL)) == 25ULL ? 18U : ((__u64)((25ULL)) == 26ULL ? 19U : ((__u64)((25ULL)) == 27ULL ? 20U : ((__u64)((25ULL)) == 28ULL ? 21U : ((__u64)((25ULL)) == 32ULL ? 22U : ((__u64)((25ULL)) == 35ULL ? 23U : ((__u64)((25ULL)) == 36ULL ? 24U : ((__u64)((25ULL)) == 37ULL ? 25U : ((__u64)((25ULL)) == 38ULL ? 26U : ((__u64)((25ULL)) == 39ULL ? 27U : ((__u64)((25ULL)) == 43ULL ? 28U : ((__u64)((25ULL)) == 44ULL ? 29U : ((__u64)((25ULL)) == 45ULL ? 30U : ((__u64)((25ULL)) == 46ULL ? 31U : ((__u64)((25ULL)) == 50ULL ? 32U : ((__u64)((25ULL)) == 54ULL ? 33U : ((__u64)((25ULL)) == 58ULL ? 34U : ((__u64)((25ULL)) == 65ULL ? 35U : ((__u64)((25ULL)) == 67ULL ? 36U : ((__u64)((25ULL)) == 68ULL ? 37U : ((__u64)((25ULL)) == 69ULL ? 38U : ((__u64)((25ULL)) == 80ULL ? 39U : ((__u64)((25ULL)) == 85ULL ? 40U : ((__u64)((25ULL)) == 86ULL ? 41U : ((__u64)((25ULL)) == 87ULL ? 42U : ((__u64)((25ULL)) == 88ULL ? 43U : ((__u64)((25ULL)) == 95ULL ? 44U : ((__u64)((25ULL)) == 99ULL ? 45U : ((__u64)((25ULL)) == 105ULL ? 46U : ((__u64)((25ULL)) == 109ULL ? 47U : ((__u64)((25ULL)) == 112ULL ? 48U : ((__u64)((25ULL)) == 113ULL ? 49U : ((__u64)((25ULL)) == 114ULL ? 50U : ((__u64)((25ULL)) == 115ULL ? 51U : ((__u64)((25ULL)) == 118ULL ? 52U : ((__u64)((25ULL)) == 122ULL ? 53U : ((__u64)((25ULL)) == 124ULL ? 54U : ((__u64)((25ULL)) == 125ULL ? 55U : ((__u64)((25ULL)) == 130ULL ? 56U : ((__u64)((25ULL)) == 148ULL ? 57U : ((__u64)((25ULL)) == 152ULL ? 58U : ((__u64)((25ULL)) == 155ULL ? 59U : ((__u64)((25ULL)) == 158ULL ? 60U : ((__u64)((25ULL)) == 160ULL ? 61U : ((__u64)((25ULL)) == 163ULL ? 62U : ((__u64)((25ULL)) == 173ULL ? 63U : ((__u64)((25ULL)) == 174ULL ? 64U : ((__u64)((25ULL)) == 175ULL ? 65U : ((__u64)((25ULL)) == 181ULL ? 66U : ((__u64)((25ULL)) == 184ULL ? 67U : ((__u64)((25ULL)) == 189ULL ? 68U : ((__u64)((25ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 18U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((26ULL)) == 1ULL ? 0U : ((__u64)((26ULL)) == 2ULL ? 1U : ((__u64)((26ULL)) == 3ULL ? 2U : ((__u64)((26ULL)) == 4ULL ? 3U : ((__u64)((26ULL)) == 5ULL ? 4U : ((__u64)((26ULL)) == 6ULL ? 5U : ((__u64)((26ULL)) == 7ULL ? 6U : ((__u64)((26ULL)) == 8ULL ? 7U : ((__u64)((26ULL)) == 9ULL ? 8U : ((__u64)((26ULL)) == 10ULL ? 9U : ((__u64)((26ULL)) == 11ULL ? 10U : ((__u64)((26ULL)) == 12ULL ? 11U : ((__u64)((26ULL)) == 14ULL ? 12U : ((__u64)((26ULL)) == 15ULL ? 13U : ((__u64)((26ULL)) == 16ULL ? 14U : ((__u64)((26ULL)) == 20ULL ? 15U : ((__u64)((26ULL)) == 21ULL ? 16U : ((__u64)((26ULL)) == 23ULL ? 17U : ((__u64)((26ULL)) == 25ULL ? 18U : ((__u64)((26ULL)) == 26ULL ? 19U : ((__u64)((26ULL)) == 27ULL ? 20U : ((__u64)((26ULL)) == 28ULL ? 21U : ((__u64)((26ULL)) == 32ULL ? 22U : ((__u64)((26ULL)) == 35ULL ? 23U : ((__u64)((26ULL)) == 36ULL ? 24U : ((__u64)((26ULL)) == 37ULL ? 25U : ((__u64)((26ULL)) == 38ULL ? 26U : ((__u64)((26ULL)) == 39ULL ? 27U : ((__u64)((26ULL)) == 43ULL ? 28U : ((__u64)((26ULL)) == 44ULL ? 29U : ((__u64)((26ULL)) == 45ULL ? 30U : ((__u64)((26ULL)) == 46ULL ? 31U : ((__u64)((26ULL)) == 50ULL ? 32U : ((__u64)((26ULL)) == 54ULL ? 33U : ((__u64)((26ULL)) == 58ULL ? 34U : ((__u64)((26ULL)) == 65ULL ? 35U : ((__u64)((26ULL)) == 67ULL ? 36U : ((__u64)((26ULL)) == 68ULL ? 37U : ((__u64)((26ULL)) == 69ULL ? 38U : ((__u64)((26ULL)) == 80ULL ? 39U : ((__u64)((26ULL)) == 85ULL ? 40U : ((__u64)((26ULL)) == 86ULL ? 41U : ((__u64)((26ULL)) == 87ULL ? 42U : ((__u64)((26ULL)) == 88ULL ? 43U : ((__u64)((26ULL)) == 95ULL ? 44U : ((__u64)((26ULL)) == 99ULL ? 45U : ((__u64)((26ULL)) == 105ULL ? 46U : ((__u64)((26ULL)) == 109ULL ? 47U : ((__u64)((26ULL)) == 112ULL ? 48U : ((__u64)((26ULL)) == 113ULL ? 49U : ((__u64)((26ULL)) == 114ULL ? 50U : ((__u64)((26ULL)) == 115ULL ? 51U : ((__u64)((26ULL)) == 118ULL ? 52U : ((__u64)((26ULL)) == 122ULL ? 53U : ((__u64)((26ULL)) == 124ULL ? 54U : ((__u64)((26ULL)) == 125ULL ? 55U : ((__u64)((26ULL)) == 130ULL ? 56U : ((__u64)((26ULL)) == 148ULL ? 57U : ((__u64)((26ULL)) == 152ULL ? 58U : ((__u64)((26ULL)) == 155ULL ? 59U : ((__u64)((26ULL)) == 158ULL ? 60U : ((__u64)((26ULL)) == 160ULL ? 61U : ((__u64)((26ULL)) == 163ULL ? 62U : ((__u64)((26ULL)) == 173ULL ? 63U : ((__u64)((26ULL)) == 174ULL ? 64U : ((__u64)((26ULL)) == 175ULL ? 65U : ((__u64)((26ULL)) == 181ULL ? 66U : ((__u64)((26ULL)) == 184ULL ? 67U : ((__u64)((26ULL)) == 189ULL ? 68U : ((__u64)((26ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 19U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((27ULL)) == 1ULL ? 0U : ((__u64)((27ULL)) == 2ULL ? 1U : ((__u64)((27ULL)) == 3ULL ? 2U : ((__u64)((27ULL)) == 4ULL ? 3U : ((__u64)((27ULL)) == 5ULL ? 4U : ((__u64)((27ULL)) == 6ULL ? 5U : ((__u64)((27ULL)) == 7ULL ? 6U : ((__u64)((27ULL)) == 8ULL ? 7U : ((__u64)((27ULL)) == 9ULL ? 8U : ((__u64)((27ULL)) == 10ULL ? 9U : ((__u64)((27ULL)) == 11ULL ? 10U : ((__u64)((27ULL)) == 12ULL ? 11U : ((__u64)((27ULL)) == 14ULL ? 12U : ((__u64)((27ULL)) == 15ULL ? 13U : ((__u64)((27ULL)) == 16ULL ? 14U : ((__u64)((27ULL)) == 20ULL ? 15U : ((__u64)((27ULL)) == 21ULL ? 16U : ((__u64)((27ULL)) == 23ULL ? 17U : ((__u64)((27ULL)) == 25ULL ? 18U : ((__u64)((27ULL)) == 26ULL ? 19U : ((__u64)((27ULL)) == 27ULL ? 20U : ((__u64)((27ULL)) == 28ULL ? 21U : ((__u64)((27ULL)) == 32ULL ? 22U : ((__u64)((27ULL)) == 35ULL ? 23U : ((__u64)((27ULL)) == 36ULL ? 24U : ((__u64)((27ULL)) == 37ULL ? 25U : ((__u64)((27ULL)) == 38ULL ? 26U : ((__u64)((27ULL)) == 39ULL ? 27U : ((__u64)((27ULL)) == 43ULL ? 28U : ((__u64)((27ULL)) == 44ULL ? 29U : ((__u64)((27ULL)) == 45ULL ? 30U : ((__u64)((27ULL)) == 46ULL ? 31U : ((__u64)((27ULL)) == 50ULL ? 32U : ((__u64)((27ULL)) == 54ULL ? 33U : ((__u64)((27ULL)) == 58ULL ? 34U : ((__u64)((27ULL)) == 65ULL ? 35U : ((__u64)((27ULL)) == 67ULL ? 36U : ((__u64)((27ULL)) == 68ULL ? 37U : ((__u64)((27ULL)) == 69ULL ? 38U : ((__u64)((27ULL)) == 80ULL ? 39U : ((__u64)((27ULL)) == 85ULL ? 40U : ((__u64)((27ULL)) == 86ULL ? 41U : ((__u64)((27ULL)) == 87ULL ? 42U : ((__u64)((27ULL)) == 88ULL ? 43U : ((__u64)((27ULL)) == 95ULL ? 44U : ((__u64)((27ULL)) == 99ULL ? 45U : ((__u64)((27ULL)) == 105ULL ? 46U : ((__u64)((27ULL)) == 109ULL ? 47U : ((__u64)((27ULL)) == 112ULL ? 48U : ((__u64)((27ULL)) == 113ULL ? 49U : ((__u64)((27ULL)) == 114ULL ? 50U : ((__u64)((27ULL)) == 115ULL ? 51U : ((__u64)((27ULL)) == 118ULL ? 52U : ((__u64)((27ULL)) == 122ULL ? 53U : ((__u64)((27ULL)) == 124ULL ? 54U : ((__u64)((27ULL)) == 125ULL ? 55U : ((__u64)((27ULL)) == 130ULL ? 56U : ((__u64)((27ULL)) == 148ULL ? 57U : ((__u64)((27ULL)) == 152ULL ? 58U : ((__u64)((27ULL)) == 155ULL ? 59U : ((__u64)((27ULL)) == 158ULL ? 60U : ((__u64)((27ULL)) == 160ULL ? 61U : ((__u64)((27ULL)) == 163ULL ? 62U : ((__u64)((27ULL)) == 173ULL ? 63U : ((__u64)((27ULL)) == 174ULL ? 64U : ((__u64)((27ULL)) == 175ULL ? 65U : ((__u64)((27ULL)) == 181ULL ? 66U : ((__u64)((27ULL)) == 184ULL ? 67U : ((__u64)((27ULL)) == 189ULL ? 68U : ((__u64)((27ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 20U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((28ULL)) == 1ULL ? 0U : ((__u64)((28ULL)) == 2ULL ? 1U : ((__u64)((28ULL)) == 3ULL ? 2U : ((__u64)((28ULL)) == 4ULL ? 3U : ((__u64)((28ULL)) == 5ULL ? 4U : ((__u64)((28ULL)) == 6ULL ? 5U : ((__u64)((28ULL)) == 7ULL ? 6U : ((__u64)((28ULL)) == 8ULL ? 7U : ((__u64)((28ULL)) == 9ULL ? 8U : ((__u64)((28ULL)) == 10ULL ? 9U : ((__u64)((28ULL)) == 11ULL ? 10U : ((__u64)((28ULL)) == 12ULL ? 11U : ((__u64)((28ULL)) == 14ULL ? 12U : ((__u64)((28ULL)) == 15ULL ? 13U : ((__u64)((28ULL)) == 16ULL ? 14U : ((__u64)((28ULL)) == 20ULL ? 15U : ((__u64)((28ULL)) == 21ULL ? 16U : ((__u64)((28ULL)) == 23ULL ? 17U : ((__u64)((28ULL)) == 25ULL ? 18U : ((__u64)((28ULL)) == 26ULL ? 19U : ((__u64)((28ULL)) == 27ULL ? 20U : ((__u64)((28ULL)) == 28ULL ? 21U : ((__u64)((28ULL)) == 32ULL ? 22U : ((__u64)((28ULL)) == 35ULL ? 23U : ((__u64)((28ULL)) == 36ULL ? 24U : ((__u64)((28ULL)) == 37ULL ? 25U : ((__u64)((28ULL)) == 38ULL ? 26U : ((__u64)((28ULL)) == 39ULL ? 27U : ((__u64)((28ULL)) == 43ULL ? 28U : ((__u64)((28ULL)) == 44ULL ? 29U : ((__u64)((28ULL)) == 45ULL ? 30U : ((__u64)((28ULL)) == 46ULL ? 31U : ((__u64)((28ULL)) == 50ULL ? 32U : ((__u64)((28ULL)) == 54ULL ? 33U : ((__u64)((28ULL)) == 58ULL ? 34U : ((__u64)((28ULL)) == 65ULL ? 35U : ((__u64)((28ULL)) == 67ULL ? 36U : ((__u64)((28ULL)) == 68ULL ? 37U : ((__u64)((28ULL)) == 69ULL ? 38U : ((__u64)((28ULL)) == 80ULL ? 39U : ((__u64)((28ULL)) == 85ULL ? 40U : ((__u64)((28ULL)) == 86ULL ? 41U : ((__u64)((28ULL)) == 87ULL ? 42U : ((__u64)((28ULL)) == 88ULL ? 43U : ((__u64)((28ULL)) == 95ULL ? 44U : ((__u64)((28ULL)) == 99ULL ? 45U : ((__u64)((28ULL)) == 105ULL ? 46U : ((__u64)((28ULL)) == 109ULL ? 47U : ((__u64)((28ULL)) == 112ULL ? 48U : ((__u64)((28ULL)) == 113ULL ? 49U : ((__u64)((28ULL)) == 114ULL ? 50U : ((__u64)((28ULL)) == 115ULL ? 51U : ((__u64)((28ULL)) == 118ULL ? 52U : ((__u64)((28ULL)) == 122ULL ? 53U : ((__u64)((28ULL)) == 124ULL ? 54U : ((__u64)((28ULL)) == 125ULL ? 55U : ((__u64)((28ULL)) == 130ULL ? 56U : ((__u64)((28ULL)) == 148ULL ? 57U : ((__u64)((28ULL)) == 152ULL ? 58U : ((__u64)((28ULL)) == 155ULL ? 59U : ((__u64)((28ULL)) == 158ULL ? 60U : ((__u64)((28ULL)) == 160ULL ? 61U : ((__u64)((28ULL)) == 163ULL ? 62U : ((__u64)((28ULL)) == 173ULL ? 63U : ((__u64)((28ULL)) == 174ULL ? 64U : ((__u64)((28ULL)) == 175ULL ? 65U : ((__u64)((28ULL)) == 181ULL ? 66U : ((__u64)((28ULL)) == 184ULL ? 67U : ((__u64)((28ULL)) == 189ULL ? 68U : ((__u64)((28ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 21U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((32ULL)) == 1ULL ? 0U : ((__u64)((32ULL)) == 2ULL ? 1U : ((__u64)((32ULL)) == 3ULL ? 2U : ((__u64)((32ULL)) == 4ULL ? 3U : ((__u64)((32ULL)) == 5ULL ? 4U : ((__u64)((32ULL)) == 6ULL ? 5U : ((__u64)((32ULL)) == 7ULL ? 6U : ((__u64)((32ULL)) == 8ULL ? 7U : ((__u64)((32ULL)) == 9ULL ? 8U : ((__u64)((32ULL)) == 10ULL ? 9U : ((__u64)((32ULL)) == 11ULL ? 10U : ((__u64)((32ULL)) == 12ULL ? 11U : ((__u64)((32ULL)) == 14ULL ? 12U : ((__u64)((32ULL)) == 15ULL ? 13U : ((__u64)((32ULL)) == 16ULL ? 14U : ((__u64)((32ULL)) == 20ULL ? 15U : ((__u64)((32ULL)) == 21ULL ? 16U : ((__u64)((32ULL)) == 23ULL ? 17U : ((__u64)((32ULL)) == 25ULL ? 18U : ((__u64)((32ULL)) == 26ULL ? 19U : ((__u64)((32ULL)) == 27ULL ? 20U : ((__u64)((32ULL)) == 28ULL ? 21U : ((__u64)((32ULL)) == 32ULL ? 22U : ((__u64)((32ULL)) == 35ULL ? 23U : ((__u64)((32ULL)) == 36ULL ? 24U : ((__u64)((32ULL)) == 37ULL ? 25U : ((__u64)((32ULL)) == 38ULL ? 26U : ((__u64)((32ULL)) == 39ULL ? 27U : ((__u64)((32ULL)) == 43ULL ? 28U : ((__u64)((32ULL)) == 44ULL ? 29U : ((__u64)((32ULL)) == 45ULL ? 30U : ((__u64)((32ULL)) == 46ULL ? 31U : ((__u64)((32ULL)) == 50ULL ? 32U : ((__u64)((32ULL)) == 54ULL ? 33U : ((__u64)((32ULL)) == 58ULL ? 34U : ((__u64)((32ULL)) == 65ULL ? 35U : ((__u64)((32ULL)) == 67ULL ? 36U : ((__u64)((32ULL)) == 68ULL ? 37U : ((__u64)((32ULL)) == 69ULL ? 38U : ((__u64)((32ULL)) == 80ULL ? 39U : ((__u64)((32ULL)) == 85ULL ? 40U : ((__u64)((32ULL)) == 86ULL ? 41U : ((__u64)((32ULL)) == 87ULL ? 42U : ((__u64)((32ULL)) == 88ULL ? 43U : ((__u64)((32ULL)) == 95ULL ? 44U : ((__u64)((32ULL)) == 99ULL ? 45U : ((__u64)((32ULL)) == 105ULL ? 46U : ((__u64)((32ULL)) == 109ULL ? 47U : ((__u64)((32ULL)) == 112ULL ? 48U : ((__u64)((32ULL)) == 113ULL ? 49U : ((__u64)((32ULL)) == 114ULL ? 50U : ((__u64)((32ULL)) == 115ULL ? 51U : ((__u64)((32ULL)) == 118ULL ? 52U : ((__u64)((32ULL)) == 122ULL ? 53U : ((__u64)((32ULL)) == 124ULL ? 54U : ((__u64)((32ULL)) == 125ULL ? 55U : ((__u64)((32ULL)) == 130ULL ? 56U : ((__u64)((32ULL)) == 148ULL ? 57U : ((__u64)((32ULL)) == 152ULL ? 58U : ((__u64)((32ULL)) == 155ULL ? 59U : ((__u64)((32ULL)) == 158ULL ? 60U : ((__u64)((32ULL)) == 160ULL ? 61U : ((__u64)((32ULL)) == 163ULL ? 62U : ((__u64)((32ULL)) == 173ULL ? 63U : ((__u64)((32ULL)) == 174ULL ? 64U : ((__u64)((32ULL)) == 175ULL ? 65U : ((__u64)((32ULL)) == 181ULL ? 66U : ((__u64)((32ULL)) == 184ULL ? 67U : ((__u64)((32ULL)) == 189ULL ? 68U : ((__u64)((32ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 22U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((35ULL)) == 1ULL ? 0U : ((__u64)((35ULL)) == 2ULL ? 1U : ((__u64)((35ULL)) == 3ULL ? 2U : ((__u64)((35ULL)) == 4ULL ? 3U : ((__u64)((35ULL)) == 5ULL ? 4U : ((__u64)((35ULL)) == 6ULL ? 5U : ((__u64)((35ULL)) == 7ULL ? 6U : ((__u64)((35ULL)) == 8ULL ? 7U : ((__u64)((35ULL)) == 9ULL ? 8U : ((__u64)((35ULL)) == 10ULL ? 9U : ((__u64)((35ULL)) == 11ULL ? 10U : ((__u64)((35ULL)) == 12ULL ? 11U : ((__u64)((35ULL)) == 14ULL ? 12U : ((__u64)((35ULL)) == 15ULL ? 13U : ((__u64)((35ULL)) == 16ULL ? 14U : ((__u64)((35ULL)) == 20ULL ? 15U : ((__u64)((35ULL)) == 21ULL ? 16U : ((__u64)((35ULL)) == 23ULL ? 17U : ((__u64)((35ULL)) == 25ULL ? 18U : ((__u64)((35ULL)) == 26ULL ? 19U : ((__u64)((35ULL)) == 27ULL ? 20U : ((__u64)((35ULL)) == 28ULL ? 21U : ((__u64)((35ULL)) == 32ULL ? 22U : ((__u64)((35ULL)) == 35ULL ? 23U : ((__u64)((35ULL)) == 36ULL ? 24U : ((__u64)((35ULL)) == 37ULL ? 25U : ((__u64)((35ULL)) == 38ULL ? 26U : ((__u64)((35ULL)) == 39ULL ? 27U : ((__u64)((35ULL)) == 43ULL ? 28U : ((__u64)((35ULL)) == 44ULL ? 29U : ((__u64)((35ULL)) == 45ULL ? 30U : ((__u64)((35ULL)) == 46ULL ? 31U : ((__u64)((35ULL)) == 50ULL ? 32U : ((__u64)((35ULL)) == 54ULL ? 33U : ((__u64)((35ULL)) == 58ULL ? 34U : ((__u64)((35ULL)) == 65ULL ? 35U : ((__u64)((35ULL)) == 67ULL ? 36U : ((__u64)((35ULL)) == 68ULL ? 37U : ((__u64)((35ULL)) == 69ULL ? 38U : ((__u64)((35ULL)) == 80ULL ? 39U : ((__u64)((35ULL)) == 85ULL ? 40U : ((__u64)((35ULL)) == 86ULL ? 41U : ((__u64)((35ULL)) == 87ULL ? 42U : ((__u64)((35ULL)) == 88ULL ? 43U : ((__u64)((35ULL)) == 95ULL ? 44U : ((__u64)((35ULL)) == 99ULL ? 45U : ((__u64)((35ULL)) == 105ULL ? 46U : ((__u64)((35ULL)) == 109ULL ? 47U : ((__u64)((35ULL)) == 112ULL ? 48U : ((__u64)((35ULL)) == 113ULL ? 49U : ((__u64)((35ULL)) == 114ULL ? 50U : ((__u64)((35ULL)) == 115ULL ? 51U : ((__u64)((35ULL)) == 118ULL ? 52U : ((__u64)((35ULL)) == 122ULL ? 53U : ((__u64)((35ULL)) == 124ULL ? 54U : ((__u64)((35ULL)) == 125ULL ? 55U : ((__u64)((35ULL)) == 130ULL ? 56U : ((__u64)((35ULL)) == 148ULL ? 57U : ((__u64)((35ULL)) == 152ULL ? 58U : ((__u64)((35ULL)) == 155ULL ? 59U : ((__u64)((35ULL)) == 158ULL ? 60U : ((__u64)((35ULL)) == 160ULL ? 61U : ((__u64)((35ULL)) == 163ULL ? 62U : ((__u64)((35ULL)) == 173ULL ? 63U : ((__u64)((35ULL)) == 174ULL ? 64U : ((__u64)((35ULL)) == 175ULL ? 65U : ((__u64)((35ULL)) == 181ULL ? 66U : ((__u64)((35ULL)) == 184ULL ? 67U : ((__u64)((35ULL)) == 189ULL ? 68U : ((__u64)((35ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 23U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((36ULL)) == 1ULL ? 0U : ((__u64)((36ULL)) == 2ULL ? 1U : ((__u64)((36ULL)) == 3ULL ? 2U : ((__u64)((36ULL)) == 4ULL ? 3U : ((__u64)((36ULL)) == 5ULL ? 4U : ((__u64)((36ULL)) == 6ULL ? 5U : ((__u64)((36ULL)) == 7ULL ? 6U : ((__u64)((36ULL)) == 8ULL ? 7U : ((__u64)((36ULL)) == 9ULL ? 8U : ((__u64)((36ULL)) == 10ULL ? 9U : ((__u64)((36ULL)) == 11ULL ? 10U : ((__u64)((36ULL)) == 12ULL ? 11U : ((__u64)((36ULL)) == 14ULL ? 12U : ((__u64)((36ULL)) == 15ULL ? 13U : ((__u64)((36ULL)) == 16ULL ? 14U : ((__u64)((36ULL)) == 20ULL ? 15U : ((__u64)((36ULL)) == 21ULL ? 16U : ((__u64)((36ULL)) == 23ULL ? 17U : ((__u64)((36ULL)) == 25ULL ? 18U : ((__u64)((36ULL)) == 26ULL ? 19U : ((__u64)((36ULL)) == 27ULL ? 20U : ((__u64)((36ULL)) == 28ULL ? 21U : ((__u64)((36ULL)) == 32ULL ? 22U : ((__u64)((36ULL)) == 35ULL ? 23U : ((__u64)((36ULL)) == 36ULL ? 24U : ((__u64)((36ULL)) == 37ULL ? 25U : ((__u64)((36ULL)) == 38ULL ? 26U : ((__u64)((36ULL)) == 39ULL ? 27U : ((__u64)((36ULL)) == 43ULL ? 28U : ((__u64)((36ULL)) == 44ULL ? 29U : ((__u64)((36ULL)) == 45ULL ? 30U : ((__u64)((36ULL)) == 46ULL ? 31U : ((__u64)((36ULL)) == 50ULL ? 32U : ((__u64)((36ULL)) == 54ULL ? 33U : ((__u64)((36ULL)) == 58ULL ? 34U : ((__u64)((36ULL)) == 65ULL ? 35U : ((__u64)((36ULL)) == 67ULL ? 36U : ((__u64)((36ULL)) == 68ULL ? 37U : ((__u64)((36ULL)) == 69ULL ? 38U : ((__u64)((36ULL)) == 80ULL ? 39U : ((__u64)((36ULL)) == 85ULL ? 40U : ((__u64)((36ULL)) == 86ULL ? 41U : ((__u64)((36ULL)) == 87ULL ? 42U : ((__u64)((36ULL)) == 88ULL ? 43U : ((__u64)((36ULL)) == 95ULL ? 44U : ((__u64)((36ULL)) == 99ULL ? 45U : ((__u64)((36ULL)) == 105ULL ? 46U : ((__u64)((36ULL)) == 109ULL ? 47U : ((__u64)((36ULL)) == 112ULL ? 48U : ((__u64)((36ULL)) == 113ULL ? 49U : ((__u64)((36ULL)) == 114ULL ? 50U : ((__u64)((36ULL)) == 115ULL ? 51U : ((__u64)((36ULL)) == 118ULL ? 52U : ((__u64)((36ULL)) == 122ULL ? 53U : ((__u64)((36ULL)) == 124ULL ? 54U : ((__u64)((36ULL)) == 125ULL ? 55U : ((__u64)((36ULL)) == 130ULL ? 56U : ((__u64)((36ULL)) == 148ULL ? 57U : ((__u64)((36ULL)) == 152ULL ? 58U : ((__u64)((36ULL)) == 155ULL ? 59U : ((__u64)((36ULL)) == 158ULL ? 60U : ((__u64)((36ULL)) == 160ULL ? 61U : ((__u64)((36ULL)) == 163ULL ? 62U : ((__u64)((36ULL)) == 173ULL ? 63U : ((__u64)((36ULL)) == 174ULL ? 64U : ((__u64)((36ULL)) == 175ULL ? 65U : ((__u64)((36ULL)) == 181ULL ? 66U : ((__u64)((36ULL)) == 184ULL ? 67U : ((__u64)((36ULL)) == 189ULL ? 68U : ((__u64)((36ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 24U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((37ULL)) == 1ULL ? 0U : ((__u64)((37ULL)) == 2ULL ? 1U : ((__u64)((37ULL)) == 3ULL ? 2U : ((__u64)((37ULL)) == 4ULL ? 3U : ((__u64)((37ULL)) == 5ULL ? 4U : ((__u64)((37ULL)) == 6ULL ? 5U : ((__u64)((37ULL)) == 7ULL ? 6U : ((__u64)((37ULL)) == 8ULL ? 7U : ((__u64)((37ULL)) == 9ULL ? 8U : ((__u64)((37ULL)) == 10ULL ? 9U : ((__u64)((37ULL)) == 11ULL ? 10U : ((__u64)((37ULL)) == 12ULL ? 11U : ((__u64)((37ULL)) == 14ULL ? 12U : ((__u64)((37ULL)) == 15ULL ? 13U : ((__u64)((37ULL)) == 16ULL ? 14U : ((__u64)((37ULL)) == 20ULL ? 15U : ((__u64)((37ULL)) == 21ULL ? 16U : ((__u64)((37ULL)) == 23ULL ? 17U : ((__u64)((37ULL)) == 25ULL ? 18U : ((__u64)((37ULL)) == 26ULL ? 19U : ((__u64)((37ULL)) == 27ULL ? 20U : ((__u64)((37ULL)) == 28ULL ? 21U : ((__u64)((37ULL)) == 32ULL ? 22U : ((__u64)((37ULL)) == 35ULL ? 23U : ((__u64)((37ULL)) == 36ULL ? 24U : ((__u64)((37ULL)) == 37ULL ? 25U : ((__u64)((37ULL)) == 38ULL ? 26U : ((__u64)((37ULL)) == 39ULL ? 27U : ((__u64)((37ULL)) == 43ULL ? 28U : ((__u64)((37ULL)) == 44ULL ? 29U : ((__u64)((37ULL)) == 45ULL ? 30U : ((__u64)((37ULL)) == 46ULL ? 31U : ((__u64)((37ULL)) == 50ULL ? 32U : ((__u64)((37ULL)) == 54ULL ? 33U : ((__u64)((37ULL)) == 58ULL ? 34U : ((__u64)((37ULL)) == 65ULL ? 35U : ((__u64)((37ULL)) == 67ULL ? 36U : ((__u64)((37ULL)) == 68ULL ? 37U : ((__u64)((37ULL)) == 69ULL ? 38U : ((__u64)((37ULL)) == 80ULL ? 39U : ((__u64)((37ULL)) == 85ULL ? 40U : ((__u64)((37ULL)) == 86ULL ? 41U : ((__u64)((37ULL)) == 87ULL ? 42U : ((__u64)((37ULL)) == 88ULL ? 43U : ((__u64)((37ULL)) == 95ULL ? 44U : ((__u64)((37ULL)) == 99ULL ? 45U : ((__u64)((37ULL)) == 105ULL ? 46U : ((__u64)((37ULL)) == 109ULL ? 47U : ((__u64)((37ULL)) == 112ULL ? 48U : ((__u64)((37ULL)) == 113ULL ? 49U : ((__u64)((37ULL)) == 114ULL ? 50U : ((__u64)((37ULL)) == 115ULL ? 51U : ((__u64)((37ULL)) == 118ULL ? 52U : ((__u64)((37ULL)) == 122ULL ? 53U : ((__u64)((37ULL)) == 124ULL ? 54U : ((__u64)((37ULL)) == 125ULL ? 55U : ((__u64)((37ULL)) == 130ULL ? 56U : ((__u64)((37ULL)) == 148ULL ? 57U : ((__u64)((37ULL)) == 152ULL ? 58U : ((__u64)((37ULL)) == 155ULL ? 59U : ((__u64)((37ULL)) == 158ULL ? 60U : ((__u64)((37ULL)) == 160ULL ? 61U : ((__u64)((37ULL)) == 163ULL ? 62U : ((__u64)((37ULL)) == 173ULL ? 63U : ((__u64)((37ULL)) == 174ULL ? 64U : ((__u64)((37ULL)) == 175ULL ? 65U : ((__u64)((37ULL)) == 181ULL ? 66U : ((__u64)((37ULL)) == 184ULL ? 67U : ((__u64)((37ULL)) == 189ULL ? 68U : ((__u64)((37ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 25U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((38ULL)) == 1ULL ? 0U : ((__u64)((38ULL)) == 2ULL ? 1U : ((__u64)((38ULL)) == 3ULL ? 2U : ((__u64)((38ULL)) == 4ULL ? 3U : ((__u64)((38ULL)) == 5ULL ? 4U : ((__u64)((38ULL)) == 6ULL ? 5U : ((__u64)((38ULL)) == 7ULL ? 6U : ((__u64)((38ULL)) == 8ULL ? 7U : ((__u64)((38ULL)) == 9ULL ? 8U : ((__u64)((38ULL)) == 10ULL ? 9U : ((__u64)((38ULL)) == 11ULL ? 10U : ((__u64)((38ULL)) == 12ULL ? 11U : ((__u64)((38ULL)) == 14ULL ? 12U : ((__u64)((38ULL)) == 15ULL ? 13U : ((__u64)((38ULL)) == 16ULL ? 14U : ((__u64)((38ULL)) == 20ULL ? 15U : ((__u64)((38ULL)) == 21ULL ? 16U : ((__u64)((38ULL)) == 23ULL ? 17U : ((__u64)((38ULL)) == 25ULL ? 18U : ((__u64)((38ULL)) == 26ULL ? 19U : ((__u64)((38ULL)) == 27ULL ? 20U : ((__u64)((38ULL)) == 28ULL ? 21U : ((__u64)((38ULL)) == 32ULL ? 22U : ((__u64)((38ULL)) == 35ULL ? 23U : ((__u64)((38ULL)) == 36ULL ? 24U : ((__u64)((38ULL)) == 37ULL ? 25U : ((__u64)((38ULL)) == 38ULL ? 26U : ((__u64)((38ULL)) == 39ULL ? 27U : ((__u64)((38ULL)) == 43ULL ? 28U : ((__u64)((38ULL)) == 44ULL ? 29U : ((__u64)((38ULL)) == 45ULL ? 30U : ((__u64)((38ULL)) == 46ULL ? 31U : ((__u64)((38ULL)) == 50ULL ? 32U : ((__u64)((38ULL)) == 54ULL ? 33U : ((__u64)((38ULL)) == 58ULL ? 34U : ((__u64)((38ULL)) == 65ULL ? 35U : ((__u64)((38ULL)) == 67ULL ? 36U : ((__u64)((38ULL)) == 68ULL ? 37U : ((__u64)((38ULL)) == 69ULL ? 38U : ((__u64)((38ULL)) == 80ULL ? 39U : ((__u64)((38ULL)) == 85ULL ? 40U : ((__u64)((38ULL)) == 86ULL ? 41U : ((__u64)((38ULL)) == 87ULL ? 42U : ((__u64)((38ULL)) == 88ULL ? 43U : ((__u64)((38ULL)) == 95ULL ? 44U : ((__u64)((38ULL)) == 99ULL ? 45U : ((__u64)((38ULL)) == 105ULL ? 46U : ((__u64)((38ULL)) == 109ULL ? 47U : ((__u64)((38ULL)) == 112ULL ? 48U : ((__u64)((38ULL)) == 113ULL ? 49U : ((__u64)((38ULL)) == 114ULL ? 50U : ((__u64)((38ULL)) == 115ULL ? 51U : ((__u64)((38ULL)) == 118ULL ? 52U : ((__u64)((38ULL)) == 122ULL ? 53U : ((__u64)((38ULL)) == 124ULL ? 54U : ((__u64)((38ULL)) == 125ULL ? 55U : ((__u64)((38ULL)) == 130ULL ? 56U : ((__u64)((38ULL)) == 148ULL ? 57U : ((__u64)((38ULL)) == 152ULL ? 58U : ((__u64)((38ULL)) == 155ULL ? 59U : ((__u64)((38ULL)) == 158ULL ? 60U : ((__u64)((38ULL)) == 160ULL ? 61U : ((__u64)((38ULL)) == 163ULL ? 62U : ((__u64)((38ULL)) == 173ULL ? 63U : ((__u64)((38ULL)) == 174ULL ? 64U : ((__u64)((38ULL)) == 175ULL ? 65U : ((__u64)((38ULL)) == 181ULL ? 66U : ((__u64)((38ULL)) == 184ULL ? 67U : ((__u64)((38ULL)) == 189ULL ? 68U : ((__u64)((38ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 26U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((39ULL)) == 1ULL ? 0U : ((__u64)((39ULL)) == 2ULL ? 1U : ((__u64)((39ULL)) == 3ULL ? 2U : ((__u64)((39ULL)) == 4ULL ? 3U : ((__u64)((39ULL)) == 5ULL ? 4U : ((__u64)((39ULL)) == 6ULL ? 5U : ((__u64)((39ULL)) == 7ULL ? 6U : ((__u64)((39ULL)) == 8ULL ? 7U : ((__u64)((39ULL)) == 9ULL ? 8U : ((__u64)((39ULL)) == 10ULL ? 9U : ((__u64)((39ULL)) == 11ULL ? 10U : ((__u64)((39ULL)) == 12ULL ? 11U : ((__u64)((39ULL)) == 14ULL ? 12U : ((__u64)((39ULL)) == 15ULL ? 13U : ((__u64)((39ULL)) == 16ULL ? 14U : ((__u64)((39ULL)) == 20ULL ? 15U : ((__u64)((39ULL)) == 21ULL ? 16U : ((__u64)((39ULL)) == 23ULL ? 17U : ((__u64)((39ULL)) == 25ULL ? 18U : ((__u64)((39ULL)) == 26ULL ? 19U : ((__u64)((39ULL)) == 27ULL ? 20U : ((__u64)((39ULL)) == 28ULL ? 21U : ((__u64)((39ULL)) == 32ULL ? 22U : ((__u64)((39ULL)) == 35ULL ? 23U : ((__u64)((39ULL)) == 36ULL ? 24U : ((__u64)((39ULL)) == 37ULL ? 25U : ((__u64)((39ULL)) == 38ULL ? 26U : ((__u64)((39ULL)) == 39ULL ? 27U : ((__u64)((39ULL)) == 43ULL ? 28U : ((__u64)((39ULL)) == 44ULL ? 29U : ((__u64)((39ULL)) == 45ULL ? 30U : ((__u64)((39ULL)) == 46ULL ? 31U : ((__u64)((39ULL)) == 50ULL ? 32U : ((__u64)((39ULL)) == 54ULL ? 33U : ((__u64)((39ULL)) == 58ULL ? 34U : ((__u64)((39ULL)) == 65ULL ? 35U : ((__u64)((39ULL)) == 67ULL ? 36U : ((__u64)((39ULL)) == 68ULL ? 37U : ((__u64)((39ULL)) == 69ULL ? 38U : ((__u64)((39ULL)) == 80ULL ? 39U : ((__u64)((39ULL)) == 85ULL ? 40U : ((__u64)((39ULL)) == 86ULL ? 41U : ((__u64)((39ULL)) == 87ULL ? 42U : ((__u64)((39ULL)) == 88ULL ? 43U : ((__u64)((39ULL)) == 95ULL ? 44U : ((__u64)((39ULL)) == 99ULL ? 45U : ((__u64)((39ULL)) == 105ULL ? 46U : ((__u64)((39ULL)) == 109ULL ? 47U : ((__u64)((39ULL)) == 112ULL ? 48U : ((__u64)((39ULL)) == 113ULL ? 49U : ((__u64)((39ULL)) == 114ULL ? 50U : ((__u64)((39ULL)) == 115ULL ? 51U : ((__u64)((39ULL)) == 118ULL ? 52U : ((__u64)((39ULL)) == 122ULL ? 53U : ((__u64)((39ULL)) == 124ULL ? 54U : ((__u64)((39ULL)) == 125ULL ? 55U : ((__u64)((39ULL)) == 130ULL ? 56U : ((__u64)((39ULL)) == 148ULL ? 57U : ((__u64)((39ULL)) == 152ULL ? 58U : ((__u64)((39ULL)) == 155ULL ? 59U : ((__u64)((39ULL)) == 158ULL ? 60U : ((__u64)((39ULL)) == 160ULL ? 61U : ((__u64)((39ULL)) == 163ULL ? 62U : ((__u64)((39ULL)) == 173ULL ? 63U : ((__u64)((39ULL)) == 174ULL ? 64U : ((__u64)((39ULL)) == 175ULL ? 65U : ((__u64)((39ULL)) == 181ULL ? 66U : ((__u64)((39ULL)) == 184ULL ? 67U : ((__u64)((39ULL)) == 189ULL ? 68U : ((__u64)((39ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 27U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((43ULL)) == 1ULL ? 0U : ((__u64)((43ULL)) == 2ULL ? 1U : ((__u64)((43ULL)) == 3ULL ? 2U : ((__u64)((43ULL)) == 4ULL ? 3U : ((__u64)((43ULL)) == 5ULL ? 4U : ((__u64)((43ULL)) == 6ULL ? 5U : ((__u64)((43ULL)) == 7ULL ? 6U : ((__u64)((43ULL)) == 8ULL ? 7U : ((__u64)((43ULL)) == 9ULL ? 8U : ((__u64)((43ULL)) == 10ULL ? 9U : ((__u64)((43ULL)) == 11ULL ? 10U : ((__u64)((43ULL)) == 12ULL ? 11U : ((__u64)((43ULL)) == 14ULL ? 12U : ((__u64)((43ULL)) == 15ULL ? 13U : ((__u64)((43ULL)) == 16ULL ? 14U : ((__u64)((43ULL)) == 20ULL ? 15U : ((__u64)((43ULL)) == 21ULL ? 16U : ((__u64)((43ULL)) == 23ULL ? 17U : ((__u64)((43ULL)) == 25ULL ? 18U : ((__u64)((43ULL)) == 26ULL ? 19U : ((__u64)((43ULL)) == 27ULL ? 20U : ((__u64)((43ULL)) == 28ULL ? 21U : ((__u64)((43ULL)) == 32ULL ? 22U : ((__u64)((43ULL)) == 35ULL ? 23U : ((__u64)((43ULL)) == 36ULL ? 24U : ((__u64)((43ULL)) == 37ULL ? 25U : ((__u64)((43ULL)) == 38ULL ? 26U : ((__u64)((43ULL)) == 39ULL ? 27U : ((__u64)((43ULL)) == 43ULL ? 28U : ((__u64)((43ULL)) == 44ULL ? 29U : ((__u64)((43ULL)) == 45ULL ? 30U : ((__u64)((43ULL)) == 46ULL ? 31U : ((__u64)((43ULL)) == 50ULL ? 32U : ((__u64)((43ULL)) == 54ULL ? 33U : ((__u64)((43ULL)) == 58ULL ? 34U : ((__u64)((43ULL)) == 65ULL ? 35U : ((__u64)((43ULL)) == 67ULL ? 36U : ((__u64)((43ULL)) == 68ULL ? 37U : ((__u64)((43ULL)) == 69ULL ? 38U : ((__u64)((43ULL)) == 80ULL ? 39U : ((__u64)((43ULL)) == 85ULL ? 40U : ((__u64)((43ULL)) == 86ULL ? 41U : ((__u64)((43ULL)) == 87ULL ? 42U : ((__u64)((43ULL)) == 88ULL ? 43U : ((__u64)((43ULL)) == 95ULL ? 44U : ((__u64)((43ULL)) == 99ULL ? 45U : ((__u64)((43ULL)) == 105ULL ? 46U : ((__u64)((43ULL)) == 109ULL ? 47U : ((__u64)((43ULL)) == 112ULL ? 48U : ((__u64)((43ULL)) == 113ULL ? 49U : ((__u64)((43ULL)) == 114ULL ? 50U : ((__u64)((43ULL)) == 115ULL ? 51U : ((__u64)((43ULL)) == 118ULL ? 52U : ((__u64)((43ULL)) == 122ULL ? 53U : ((__u64)((43ULL)) == 124ULL ? 54U : ((__u64)((43ULL)) == 125ULL ? 55U : ((__u64)((43ULL)) == 130ULL ? 56U : ((__u64)((43ULL)) == 148ULL ? 57U : ((__u64)((43ULL)) == 152ULL ? 58U : ((__u64)((43ULL)) == 155ULL ? 59U : ((__u64)((43ULL)) == 158ULL ? 60U : ((__u64)((43ULL)) == 160ULL ? 61U : ((__u64)((43ULL)) == 163ULL ? 62U : ((__u64)((43ULL)) == 173ULL ? 63U : ((__u64)((43ULL)) == 174ULL ? 64U : ((__u64)((43ULL)) == 175ULL ? 65U : ((__u64)((43ULL)) == 181ULL ? 66U : ((__u64)((43ULL)) == 184ULL ? 67U : ((__u64)((43ULL)) == 189ULL ? 68U : ((__u64)((43ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 28U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((44ULL)) == 1ULL ? 0U : ((__u64)((44ULL)) == 2ULL ? 1U : ((__u64)((44ULL)) == 3ULL ? 2U : ((__u64)((44ULL)) == 4ULL ? 3U : ((__u64)((44ULL)) == 5ULL ? 4U : ((__u64)((44ULL)) == 6ULL ? 5U : ((__u64)((44ULL)) == 7ULL ? 6U : ((__u64)((44ULL)) == 8ULL ? 7U : ((__u64)((44ULL)) == 9ULL ? 8U : ((__u64)((44ULL)) == 10ULL ? 9U : ((__u64)((44ULL)) == 11ULL ? 10U : ((__u64)((44ULL)) == 12ULL ? 11U : ((__u64)((44ULL)) == 14ULL ? 12U : ((__u64)((44ULL)) == 15ULL ? 13U : ((__u64)((44ULL)) == 16ULL ? 14U : ((__u64)((44ULL)) == 20ULL ? 15U : ((__u64)((44ULL)) == 21ULL ? 16U : ((__u64)((44ULL)) == 23ULL ? 17U : ((__u64)((44ULL)) == 25ULL ? 18U : ((__u64)((44ULL)) == 26ULL ? 19U : ((__u64)((44ULL)) == 27ULL ? 20U : ((__u64)((44ULL)) == 28ULL ? 21U : ((__u64)((44ULL)) == 32ULL ? 22U : ((__u64)((44ULL)) == 35ULL ? 23U : ((__u64)((44ULL)) == 36ULL ? 24U : ((__u64)((44ULL)) == 37ULL ? 25U : ((__u64)((44ULL)) == 38ULL ? 26U : ((__u64)((44ULL)) == 39ULL ? 27U : ((__u64)((44ULL)) == 43ULL ? 28U : ((__u64)((44ULL)) == 44ULL ? 29U : ((__u64)((44ULL)) == 45ULL ? 30U : ((__u64)((44ULL)) == 46ULL ? 31U : ((__u64)((44ULL)) == 50ULL ? 32U : ((__u64)((44ULL)) == 54ULL ? 33U : ((__u64)((44ULL)) == 58ULL ? 34U : ((__u64)((44ULL)) == 65ULL ? 35U : ((__u64)((44ULL)) == 67ULL ? 36U : ((__u64)((44ULL)) == 68ULL ? 37U : ((__u64)((44ULL)) == 69ULL ? 38U : ((__u64)((44ULL)) == 80ULL ? 39U : ((__u64)((44ULL)) == 85ULL ? 40U : ((__u64)((44ULL)) == 86ULL ? 41U : ((__u64)((44ULL)) == 87ULL ? 42U : ((__u64)((44ULL)) == 88ULL ? 43U : ((__u64)((44ULL)) == 95ULL ? 44U : ((__u64)((44ULL)) == 99ULL ? 45U : ((__u64)((44ULL)) == 105ULL ? 46U : ((__u64)((44ULL)) == 109ULL ? 47U : ((__u64)((44ULL)) == 112ULL ? 48U : ((__u64)((44ULL)) == 113ULL ? 49U : ((__u64)((44ULL)) == 114ULL ? 50U : ((__u64)((44ULL)) == 115ULL ? 51U : ((__u64)((44ULL)) == 118ULL ? 52U : ((__u64)((44ULL)) == 122ULL ? 53U : ((__u64)((44ULL)) == 124ULL ? 54U : ((__u64)((44ULL)) == 125ULL ? 55U : ((__u64)((44ULL)) == 130ULL ? 56U : ((__u64)((44ULL)) == 148ULL ? 57U : ((__u64)((44ULL)) == 152ULL ? 58U : ((__u64)((44ULL)) == 155ULL ? 59U : ((__u64)((44ULL)) == 158ULL ? 60U : ((__u64)((44ULL)) == 160ULL ? 61U : ((__u64)((44ULL)) == 163ULL ? 62U : ((__u64)((44ULL)) == 173ULL ? 63U : ((__u64)((44ULL)) == 174ULL ? 64U : ((__u64)((44ULL)) == 175ULL ? 65U : ((__u64)((44ULL)) == 181ULL ? 66U : ((__u64)((44ULL)) == 184ULL ? 67U : ((__u64)((44ULL)) == 189ULL ? 68U : ((__u64)((44ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 29U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((45ULL)) == 1ULL ? 0U : ((__u64)((45ULL)) == 2ULL ? 1U : ((__u64)((45ULL)) == 3ULL ? 2U : ((__u64)((45ULL)) == 4ULL ? 3U : ((__u64)((45ULL)) == 5ULL ? 4U : ((__u64)((45ULL)) == 6ULL ? 5U : ((__u64)((45ULL)) == 7ULL ? 6U : ((__u64)((45ULL)) == 8ULL ? 7U : ((__u64)((45ULL)) == 9ULL ? 8U : ((__u64)((45ULL)) == 10ULL ? 9U : ((__u64)((45ULL)) == 11ULL ? 10U : ((__u64)((45ULL)) == 12ULL ? 11U : ((__u64)((45ULL)) == 14ULL ? 12U : ((__u64)((45ULL)) == 15ULL ? 13U : ((__u64)((45ULL)) == 16ULL ? 14U : ((__u64)((45ULL)) == 20ULL ? 15U : ((__u64)((45ULL)) == 21ULL ? 16U : ((__u64)((45ULL)) == 23ULL ? 17U : ((__u64)((45ULL)) == 25ULL ? 18U : ((__u64)((45ULL)) == 26ULL ? 19U : ((__u64)((45ULL)) == 27ULL ? 20U : ((__u64)((45ULL)) == 28ULL ? 21U : ((__u64)((45ULL)) == 32ULL ? 22U : ((__u64)((45ULL)) == 35ULL ? 23U : ((__u64)((45ULL)) == 36ULL ? 24U : ((__u64)((45ULL)) == 37ULL ? 25U : ((__u64)((45ULL)) == 38ULL ? 26U : ((__u64)((45ULL)) == 39ULL ? 27U : ((__u64)((45ULL)) == 43ULL ? 28U : ((__u64)((45ULL)) == 44ULL ? 29U : ((__u64)((45ULL)) == 45ULL ? 30U : ((__u64)((45ULL)) == 46ULL ? 31U : ((__u64)((45ULL)) == 50ULL ? 32U : ((__u64)((45ULL)) == 54ULL ? 33U : ((__u64)((45ULL)) == 58ULL ? 34U : ((__u64)((45ULL)) == 65ULL ? 35U : ((__u64)((45ULL)) == 67ULL ? 36U : ((__u64)((45ULL)) == 68ULL ? 37U : ((__u64)((45ULL)) == 69ULL ? 38U : ((__u64)((45ULL)) == 80ULL ? 39U : ((__u64)((45ULL)) == 85ULL ? 40U : ((__u64)((45ULL)) == 86ULL ? 41U : ((__u64)((45ULL)) == 87ULL ? 42U : ((__u64)((45ULL)) == 88ULL ? 43U : ((__u64)((45ULL)) == 95ULL ? 44U : ((__u64)((45ULL)) == 99ULL ? 45U : ((__u64)((45ULL)) == 105ULL ? 46U : ((__u64)((45ULL)) == 109ULL ? 47U : ((__u64)((45ULL)) == 112ULL ? 48U : ((__u64)((45ULL)) == 113ULL ? 49U : ((__u64)((45ULL)) == 114ULL ? 50U : ((__u64)((45ULL)) == 115ULL ? 51U : ((__u64)((45ULL)) == 118ULL ? 52U : ((__u64)((45ULL)) == 122ULL ? 53U : ((__u64)((45ULL)) == 124ULL ? 54U : ((__u64)((45ULL)) == 125ULL ? 55U : ((__u64)((45ULL)) == 130ULL ? 56U : ((__u64)((45ULL)) == 148ULL ? 57U : ((__u64)((45ULL)) == 152ULL ? 58U : ((__u64)((45ULL)) == 155ULL ? 59U : ((__u64)((45ULL)) == 158ULL ? 60U : ((__u64)((45ULL)) == 160ULL ? 61U : ((__u64)((45ULL)) == 163ULL ? 62U : ((__u64)((45ULL)) == 173ULL ? 63U : ((__u64)((45ULL)) == 174ULL ? 64U : ((__u64)((45ULL)) == 175ULL ? 65U : ((__u64)((45ULL)) == 181ULL ? 66U : ((__u64)((45ULL)) == 184ULL ? 67U : ((__u64)((45ULL)) == 189ULL ? 68U : ((__u64)((45ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 30U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((46ULL)) == 1ULL ? 0U : ((__u64)((46ULL)) == 2ULL ? 1U : ((__u64)((46ULL)) == 3ULL ? 2U : ((__u64)((46ULL)) == 4ULL ? 3U : ((__u64)((46ULL)) == 5ULL ? 4U : ((__u64)((46ULL)) == 6ULL ? 5U : ((__u64)((46ULL)) == 7ULL ? 6U : ((__u64)((46ULL)) == 8ULL ? 7U : ((__u64)((46ULL)) == 9ULL ? 8U : ((__u64)((46ULL)) == 10ULL ? 9U : ((__u64)((46ULL)) == 11ULL ? 10U : ((__u64)((46ULL)) == 12ULL ? 11U : ((__u64)((46ULL)) == 14ULL ? 12U : ((__u64)((46ULL)) == 15ULL ? 13U : ((__u64)((46ULL)) == 16ULL ? 14U : ((__u64)((46ULL)) == 20ULL ? 15U : ((__u64)((46ULL)) == 21ULL ? 16U : ((__u64)((46ULL)) == 23ULL ? 17U : ((__u64)((46ULL)) == 25ULL ? 18U : ((__u64)((46ULL)) == 26ULL ? 19U : ((__u64)((46ULL)) == 27ULL ? 20U : ((__u64)((46ULL)) == 28ULL ? 21U : ((__u64)((46ULL)) == 32ULL ? 22U : ((__u64)((46ULL)) == 35ULL ? 23U : ((__u64)((46ULL)) == 36ULL ? 24U : ((__u64)((46ULL)) == 37ULL ? 25U : ((__u64)((46ULL)) == 38ULL ? 26U : ((__u64)((46ULL)) == 39ULL ? 27U : ((__u64)((46ULL)) == 43ULL ? 28U : ((__u64)((46ULL)) == 44ULL ? 29U : ((__u64)((46ULL)) == 45ULL ? 30U : ((__u64)((46ULL)) == 46ULL ? 31U : ((__u64)((46ULL)) == 50ULL ? 32U : ((__u64)((46ULL)) == 54ULL ? 33U : ((__u64)((46ULL)) == 58ULL ? 34U : ((__u64)((46ULL)) == 65ULL ? 35U : ((__u64)((46ULL)) == 67ULL ? 36U : ((__u64)((46ULL)) == 68ULL ? 37U : ((__u64)((46ULL)) == 69ULL ? 38U : ((__u64)((46ULL)) == 80ULL ? 39U : ((__u64)((46ULL)) == 85ULL ? 40U : ((__u64)((46ULL)) == 86ULL ? 41U : ((__u64)((46ULL)) == 87ULL ? 42U : ((__u64)((46ULL)) == 88ULL ? 43U : ((__u64)((46ULL)) == 95ULL ? 44U : ((__u64)((46ULL)) == 99ULL ? 45U : ((__u64)((46ULL)) == 105ULL ? 46U : ((__u64)((46ULL)) == 109ULL ? 47U : ((__u64)((46ULL)) == 112ULL ? 48U : ((__u64)((46ULL)) == 113ULL ? 49U : ((__u64)((46ULL)) == 114ULL ? 50U : ((__u64)((46ULL)) == 115ULL ? 51U : ((__u64)((46ULL)) == 118ULL ? 52U : ((__u64)((46ULL)) == 122ULL ? 53U : ((__u64)((46ULL)) == 124ULL ? 54U : ((__u64)((46ULL)) == 125ULL ? 55U : ((__u64)((46ULL)) == 130ULL ? 56U : ((__u64)((46ULL)) == 148ULL ? 57U : ((__u64)((46ULL)) == 152ULL ? 58U : ((__u64)((46ULL)) == 155ULL ? 59U : ((__u64)((46ULL)) == 158ULL ? 60U : ((__u64)((46ULL)) == 160ULL ? 61U : ((__u64)((46ULL)) == 163ULL ? 62U : ((__u64)((46ULL)) == 173ULL ? 63U : ((__u64)((46ULL)) == 174ULL ? 64U : ((__u64)((46ULL)) == 175ULL ? 65U : ((__u64)((46ULL)) == 181ULL ? 66U : ((__u64)((46ULL)) == 184ULL ? 67U : ((__u64)((46ULL)) == 189ULL ? 68U : ((__u64)((46ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 31U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((50ULL)) == 1ULL ? 0U : ((__u64)((50ULL)) == 2ULL ? 1U : ((__u64)((50ULL)) == 3ULL ? 2U : ((__u64)((50ULL)) == 4ULL ? 3U : ((__u64)((50ULL)) == 5ULL ? 4U : ((__u64)((50ULL)) == 6ULL ? 5U : ((__u64)((50ULL)) == 7ULL ? 6U : ((__u64)((50ULL)) == 8ULL ? 7U : ((__u64)((50ULL)) == 9ULL ? 8U : ((__u64)((50ULL)) == 10ULL ? 9U : ((__u64)((50ULL)) == 11ULL ? 10U : ((__u64)((50ULL)) == 12ULL ? 11U : ((__u64)((50ULL)) == 14ULL ? 12U : ((__u64)((50ULL)) == 15ULL ? 13U : ((__u64)((50ULL)) == 16ULL ? 14U : ((__u64)((50ULL)) == 20ULL ? 15U : ((__u64)((50ULL)) == 21ULL ? 16U : ((__u64)((50ULL)) == 23ULL ? 17U : ((__u64)((50ULL)) == 25ULL ? 18U : ((__u64)((50ULL)) == 26ULL ? 19U : ((__u64)((50ULL)) == 27ULL ? 20U : ((__u64)((50ULL)) == 28ULL ? 21U : ((__u64)((50ULL)) == 32ULL ? 22U : ((__u64)((50ULL)) == 35ULL ? 23U : ((__u64)((50ULL)) == 36ULL ? 24U : ((__u64)((50ULL)) == 37ULL ? 25U : ((__u64)((50ULL)) == 38ULL ? 26U : ((__u64)((50ULL)) == 39ULL ? 27U : ((__u64)((50ULL)) == 43ULL ? 28U : ((__u64)((50ULL)) == 44ULL ? 29U : ((__u64)((50ULL)) == 45ULL ? 30U : ((__u64)((50ULL)) == 46ULL ? 31U : ((__u64)((50ULL)) == 50ULL ? 32U : ((__u64)((50ULL)) == 54ULL ? 33U : ((__u64)((50ULL)) == 58ULL ? 34U : ((__u64)((50ULL)) == 65ULL ? 35U : ((__u64)((50ULL)) == 67ULL ? 36U : ((__u64)((50ULL)) == 68ULL ? 37U : ((__u64)((50ULL)) == 69ULL ? 38U : ((__u64)((50ULL)) == 80ULL ? 39U : ((__u64)((50ULL)) == 85ULL ? 40U : ((__u64)((50ULL)) == 86ULL ? 41U : ((__u64)((50ULL)) == 87ULL ? 42U : ((__u64)((50ULL)) == 88ULL ? 43U : ((__u64)((50ULL)) == 95ULL ? 44U : ((__u64)((50ULL)) == 99ULL ? 45U : ((__u64)((50ULL)) == 105ULL ? 46U : ((__u64)((50ULL)) == 109ULL ? 47U : ((__u64)((50ULL)) == 112ULL ? 48U : ((__u64)((50ULL)) == 113ULL ? 49U : ((__u64)((50ULL)) == 114ULL ? 50U : ((__u64)((50ULL)) == 115ULL ? 51U : ((__u64)((50ULL)) == 118ULL ? 52U : ((__u64)((50ULL)) == 122ULL ? 53U : ((__u64)((50ULL)) == 124ULL ? 54U : ((__u64)((50ULL)) == 125ULL ? 55U : ((__u64)((50ULL)) == 130ULL ? 56U : ((__u64)((50ULL)) == 148ULL ? 57U : ((__u64)((50ULL)) == 152ULL ? 58U : ((__u64)((50ULL)) == 155ULL ? 59U : ((__u64)((50ULL)) == 158ULL ? 60U : ((__u64)((50ULL)) == 160ULL ? 61U : ((__u64)((50ULL)) == 163ULL ? 62U : ((__u64)((50ULL)) == 173ULL ? 63U : ((__u64)((50ULL)) == 174ULL ? 64U : ((__u64)((50ULL)) == 175ULL ? 65U : ((__u64)((50ULL)) == 181ULL ? 66U : ((__u64)((50ULL)) == 184ULL ? 67U : ((__u64)((50ULL)) == 189ULL ? 68U : ((__u64)((50ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 32U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((54ULL)) == 1ULL ? 0U : ((__u64)((54ULL)) == 2ULL ? 1U : ((__u64)((54ULL)) == 3ULL ? 2U : ((__u64)((54ULL)) == 4ULL ? 3U : ((__u64)((54ULL)) == 5ULL ? 4U : ((__u64)((54ULL)) == 6ULL ? 5U : ((__u64)((54ULL)) == 7ULL ? 6U : ((__u64)((54ULL)) == 8ULL ? 7U : ((__u64)((54ULL)) == 9ULL ? 8U : ((__u64)((54ULL)) == 10ULL ? 9U : ((__u64)((54ULL)) == 11ULL ? 10U : ((__u64)((54ULL)) == 12ULL ? 11U : ((__u64)((54ULL)) == 14ULL ? 12U : ((__u64)((54ULL)) == 15ULL ? 13U : ((__u64)((54ULL)) == 16ULL ? 14U : ((__u64)((54ULL)) == 20ULL ? 15U : ((__u64)((54ULL)) == 21ULL ? 16U : ((__u64)((54ULL)) == 23ULL ? 17U : ((__u64)((54ULL)) == 25ULL ? 18U : ((__u64)((54ULL)) == 26ULL ? 19U : ((__u64)((54ULL)) == 27ULL ? 20U : ((__u64)((54ULL)) == 28ULL ? 21U : ((__u64)((54ULL)) == 32ULL ? 22U : ((__u64)((54ULL)) == 35ULL ? 23U : ((__u64)((54ULL)) == 36ULL ? 24U : ((__u64)((54ULL)) == 37ULL ? 25U : ((__u64)((54ULL)) == 38ULL ? 26U : ((__u64)((54ULL)) == 39ULL ? 27U : ((__u64)((54ULL)) == 43ULL ? 28U : ((__u64)((54ULL)) == 44ULL ? 29U : ((__u64)((54ULL)) == 45ULL ? 30U : ((__u64)((54ULL)) == 46ULL ? 31U : ((__u64)((54ULL)) == 50ULL ? 32U : ((__u64)((54ULL)) == 54ULL ? 33U : ((__u64)((54ULL)) == 58ULL ? 34U : ((__u64)((54ULL)) == 65ULL ? 35U : ((__u64)((54ULL)) == 67ULL ? 36U : ((__u64)((54ULL)) == 68ULL ? 37U : ((__u64)((54ULL)) == 69ULL ? 38U : ((__u64)((54ULL)) == 80ULL ? 39U : ((__u64)((54ULL)) == 85ULL ? 40U : ((__u64)((54ULL)) == 86ULL ? 41U : ((__u64)((54ULL)) == 87ULL ? 42U : ((__u64)((54ULL)) == 88ULL ? 43U : ((__u64)((54ULL)) == 95ULL ? 44U : ((__u64)((54ULL)) == 99ULL ? 45U : ((__u64)((54ULL)) == 105ULL ? 46U : ((__u64)((54ULL)) == 109ULL ? 47U : ((__u64)((54ULL)) == 112ULL ? 48U : ((__u64)((54ULL)) == 113ULL ? 49U : ((__u64)((54ULL)) == 114ULL ? 50U : ((__u64)((54ULL)) == 115ULL ? 51U : ((__u64)((54ULL)) == 118ULL ? 52U : ((__u64)((54ULL)) == 122ULL ? 53U : ((__u64)((54ULL)) == 124ULL ? 54U : ((__u64)((54ULL)) == 125ULL ? 55U : ((__u64)((54ULL)) == 130ULL ? 56U : ((__u64)((54ULL)) == 148ULL ? 57U : ((__u64)((54ULL)) == 152ULL ? 58U : ((__u64)((54ULL)) == 155ULL ? 59U : ((__u64)((54ULL)) == 158ULL ? 60U : ((__u64)((54ULL)) == 160ULL ? 61U : ((__u64)((54ULL)) == 163ULL ? 62U : ((__u64)((54ULL)) == 173ULL ? 63U : ((__u64)((54ULL)) == 174ULL ? 64U : ((__u64)((54ULL)) == 175ULL ? 65U : ((__u64)((54ULL)) == 181ULL ? 66U : ((__u64)((54ULL)) == 184ULL ? 67U : ((__u64)((54ULL)) == 189ULL ? 68U : ((__u64)((54ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 33U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((58ULL)) == 1ULL ? 0U : ((__u64)((58ULL)) == 2ULL ? 1U : ((__u64)((58ULL)) == 3ULL ? 2U : ((__u64)((58ULL)) == 4ULL ? 3U : ((__u64)((58ULL)) == 5ULL ? 4U : ((__u64)((58ULL)) == 6ULL ? 5U : ((__u64)((58ULL)) == 7ULL ? 6U : ((__u64)((58ULL)) == 8ULL ? 7U : ((__u64)((58ULL)) == 9ULL ? 8U : ((__u64)((58ULL)) == 10ULL ? 9U : ((__u64)((58ULL)) == 11ULL ? 10U : ((__u64)((58ULL)) == 12ULL ? 11U : ((__u64)((58ULL)) == 14ULL ? 12U : ((__u64)((58ULL)) == 15ULL ? 13U : ((__u64)((58ULL)) == 16ULL ? 14U : ((__u64)((58ULL)) == 20ULL ? 15U : ((__u64)((58ULL)) == 21ULL ? 16U : ((__u64)((58ULL)) == 23ULL ? 17U : ((__u64)((58ULL)) == 25ULL ? 18U : ((__u64)((58ULL)) == 26ULL ? 19U : ((__u64)((58ULL)) == 27ULL ? 20U : ((__u64)((58ULL)) == 28ULL ? 21U : ((__u64)((58ULL)) == 32ULL ? 22U : ((__u64)((58ULL)) == 35ULL ? 23U : ((__u64)((58ULL)) == 36ULL ? 24U : ((__u64)((58ULL)) == 37ULL ? 25U : ((__u64)((58ULL)) == 38ULL ? 26U : ((__u64)((58ULL)) == 39ULL ? 27U : ((__u64)((58ULL)) == 43ULL ? 28U : ((__u64)((58ULL)) == 44ULL ? 29U : ((__u64)((58ULL)) == 45ULL ? 30U : ((__u64)((58ULL)) == 46ULL ? 31U : ((__u64)((58ULL)) == 50ULL ? 32U : ((__u64)((58ULL)) == 54ULL ? 33U : ((__u64)((58ULL)) == 58ULL ? 34U : ((__u64)((58ULL)) == 65ULL ? 35U : ((__u64)((58ULL)) == 67ULL ? 36U : ((__u64)((58ULL)) == 68ULL ? 37U : ((__u64)((58ULL)) == 69ULL ? 38U : ((__u64)((58ULL)) == 80ULL ? 39U : ((__u64)((58ULL)) == 85ULL ? 40U : ((__u64)((58ULL)) == 86ULL ? 41U : ((__u64)((58ULL)) == 87ULL ? 42U : ((__u64)((58ULL)) == 88ULL ? 43U : ((__u64)((58ULL)) == 95ULL ? 44U : ((__u64)((58ULL)) == 99ULL ? 45U : ((__u64)((58ULL)) == 105ULL ? 46U : ((__u64)((58ULL)) == 109ULL ? 47U : ((__u64)((58ULL)) == 112ULL ? 48U : ((__u64)((58ULL)) == 113ULL ? 49U : ((__u64)((58ULL)) == 114ULL ? 50U : ((__u64)((58ULL)) == 115ULL ? 51U : ((__u64)((58ULL)) == 118ULL ? 52U : ((__u64)((58ULL)) == 122ULL ? 53U : ((__u64)((58ULL)) == 124ULL ? 54U : ((__u64)((58ULL)) == 125ULL ? 55U : ((__u64)((58ULL)) == 130ULL ? 56U : ((__u64)((58ULL)) == 148ULL ? 57U : ((__u64)((58ULL)) == 152ULL ? 58U : ((__u64)((58ULL)) == 155ULL ? 59U : ((__u64)((58ULL)) == 158ULL ? 60U : ((__u64)((58ULL)) == 160ULL ? 61U : ((__u64)((58ULL)) == 163ULL ? 62U : ((__u64)((58ULL)) == 173ULL ? 63U : ((__u64)((58ULL)) == 174ULL ? 64U : ((__u64)((58ULL)) == 175ULL ? 65U : ((__u64)((58ULL)) == 181ULL ? 66U : ((__u64)((58ULL)) == 184ULL ? 67U : ((__u64)((58ULL)) == 189ULL ? 68U : ((__u64)((58ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 34U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((65ULL)) == 1ULL ? 0U : ((__u64)((65ULL)) == 2ULL ? 1U : ((__u64)((65ULL)) == 3ULL ? 2U : ((__u64)((65ULL)) == 4ULL ? 3U : ((__u64)((65ULL)) == 5ULL ? 4U : ((__u64)((65ULL)) == 6ULL ? 5U : ((__u64)((65ULL)) == 7ULL ? 6U : ((__u64)((65ULL)) == 8ULL ? 7U : ((__u64)((65ULL)) == 9ULL ? 8U : ((__u64)((65ULL)) == 10ULL ? 9U : ((__u64)((65ULL)) == 11ULL ? 10U : ((__u64)((65ULL)) == 12ULL ? 11U : ((__u64)((65ULL)) == 14ULL ? 12U : ((__u64)((65ULL)) == 15ULL ? 13U : ((__u64)((65ULL)) == 16ULL ? 14U : ((__u64)((65ULL)) == 20ULL ? 15U : ((__u64)((65ULL)) == 21ULL ? 16U : ((__u64)((65ULL)) == 23ULL ? 17U : ((__u64)((65ULL)) == 25ULL ? 18U : ((__u64)((65ULL)) == 26ULL ? 19U : ((__u64)((65ULL)) == 27ULL ? 20U : ((__u64)((65ULL)) == 28ULL ? 21U : ((__u64)((65ULL)) == 32ULL ? 22U : ((__u64)((65ULL)) == 35ULL ? 23U : ((__u64)((65ULL)) == 36ULL ? 24U : ((__u64)((65ULL)) == 37ULL ? 25U : ((__u64)((65ULL)) == 38ULL ? 26U : ((__u64)((65ULL)) == 39ULL ? 27U : ((__u64)((65ULL)) == 43ULL ? 28U : ((__u64)((65ULL)) == 44ULL ? 29U : ((__u64)((65ULL)) == 45ULL ? 30U : ((__u64)((65ULL)) == 46ULL ? 31U : ((__u64)((65ULL)) == 50ULL ? 32U : ((__u64)((65ULL)) == 54ULL ? 33U : ((__u64)((65ULL)) == 58ULL ? 34U : ((__u64)((65ULL)) == 65ULL ? 35U : ((__u64)((65ULL)) == 67ULL ? 36U : ((__u64)((65ULL)) == 68ULL ? 37U : ((__u64)((65ULL)) == 69ULL ? 38U : ((__u64)((65ULL)) == 80ULL ? 39U : ((__u64)((65ULL)) == 85ULL ? 40U : ((__u64)((65ULL)) == 86ULL ? 41U : ((__u64)((65ULL)) == 87ULL ? 42U : ((__u64)((65ULL)) == 88ULL ? 43U : ((__u64)((65ULL)) == 95ULL ? 44U : ((__u64)((65ULL)) == 99ULL ? 45U : ((__u64)((65ULL)) == 105ULL ? 46U : ((__u64)((65ULL)) == 109ULL ? 47U : ((__u64)((65ULL)) == 112ULL ? 48U : ((__u64)((65ULL)) == 113ULL ? 49U : ((__u64)((65ULL)) == 114ULL ? 50U : ((__u64)((65ULL)) == 115ULL ? 51U : ((__u64)((65ULL)) == 118ULL ? 52U : ((__u64)((65ULL)) == 122ULL ? 53U : ((__u64)((65ULL)) == 124ULL ? 54U : ((__u64)((65ULL)) == 125ULL ? 55U : ((__u64)((65ULL)) == 130ULL ? 56U : ((__u64)((65ULL)) == 148ULL ? 57U : ((__u64)((65ULL)) == 152ULL ? 58U : ((__u64)((65ULL)) == 155ULL ? 59U : ((__u64)((65ULL)) == 158ULL ? 60U : ((__u64)((65ULL)) == 160ULL ? 61U : ((__u64)((65ULL)) == 163ULL ? 62U : ((__u64)((65ULL)) == 173ULL ? 63U : ((__u64)((65ULL)) == 174ULL ? 64U : ((__u64)((65ULL)) == 175ULL ? 65U : ((__u64)((65ULL)) == 181ULL ? 66U : ((__u64)((65ULL)) == 184ULL ? 67U : ((__u64)((65ULL)) == 189ULL ? 68U : ((__u64)((65ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 35U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((67ULL)) == 1ULL ? 0U : ((__u64)((67ULL)) == 2ULL ? 1U : ((__u64)((67ULL)) == 3ULL ? 2U : ((__u64)((67ULL)) == 4ULL ? 3U : ((__u64)((67ULL)) == 5ULL ? 4U : ((__u64)((67ULL)) == 6ULL ? 5U : ((__u64)((67ULL)) == 7ULL ? 6U : ((__u64)((67ULL)) == 8ULL ? 7U : ((__u64)((67ULL)) == 9ULL ? 8U : ((__u64)((67ULL)) == 10ULL ? 9U : ((__u64)((67ULL)) == 11ULL ? 10U : ((__u64)((67ULL)) == 12ULL ? 11U : ((__u64)((67ULL)) == 14ULL ? 12U : ((__u64)((67ULL)) == 15ULL ? 13U : ((__u64)((67ULL)) == 16ULL ? 14U : ((__u64)((67ULL)) == 20ULL ? 15U : ((__u64)((67ULL)) == 21ULL ? 16U : ((__u64)((67ULL)) == 23ULL ? 17U : ((__u64)((67ULL)) == 25ULL ? 18U : ((__u64)((67ULL)) == 26ULL ? 19U : ((__u64)((67ULL)) == 27ULL ? 20U : ((__u64)((67ULL)) == 28ULL ? 21U : ((__u64)((67ULL)) == 32ULL ? 22U : ((__u64)((67ULL)) == 35ULL ? 23U : ((__u64)((67ULL)) == 36ULL ? 24U : ((__u64)((67ULL)) == 37ULL ? 25U : ((__u64)((67ULL)) == 38ULL ? 26U : ((__u64)((67ULL)) == 39ULL ? 27U : ((__u64)((67ULL)) == 43ULL ? 28U : ((__u64)((67ULL)) == 44ULL ? 29U : ((__u64)((67ULL)) == 45ULL ? 30U : ((__u64)((67ULL)) == 46ULL ? 31U : ((__u64)((67ULL)) == 50ULL ? 32U : ((__u64)((67ULL)) == 54ULL ? 33U : ((__u64)((67ULL)) == 58ULL ? 34U : ((__u64)((67ULL)) == 65ULL ? 35U : ((__u64)((67ULL)) == 67ULL ? 36U : ((__u64)((67ULL)) == 68ULL ? 37U : ((__u64)((67ULL)) == 69ULL ? 38U : ((__u64)((67ULL)) == 80ULL ? 39U : ((__u64)((67ULL)) == 85ULL ? 40U : ((__u64)((67ULL)) == 86ULL ? 41U : ((__u64)((67ULL)) == 87ULL ? 42U : ((__u64)((67ULL)) == 88ULL ? 43U : ((__u64)((67ULL)) == 95ULL ? 44U : ((__u64)((67ULL)) == 99ULL ? 45U : ((__u64)((67ULL)) == 105ULL ? 46U : ((__u64)((67ULL)) == 109ULL ? 47U : ((__u64)((67ULL)) == 112ULL ? 48U : ((__u64)((67ULL)) == 113ULL ? 49U : ((__u64)((67ULL)) == 114ULL ? 50U : ((__u64)((67ULL)) == 115ULL ? 51U : ((__u64)((67ULL)) == 118ULL ? 52U : ((__u64)((67ULL)) == 122ULL ? 53U : ((__u64)((67ULL)) == 124ULL ? 54U : ((__u64)((67ULL)) == 125ULL ? 55U : ((__u64)((67ULL)) == 130ULL ? 56U : ((__u64)((67ULL)) == 148ULL ? 57U : ((__u64)((67ULL)) == 152ULL ? 58U : ((__u64)((67ULL)) == 155ULL ? 59U : ((__u64)((67ULL)) == 158ULL ? 60U : ((__u64)((67ULL)) == 160ULL ? 61U : ((__u64)((67ULL)) == 163ULL ? 62U : ((__u64)((67ULL)) == 173ULL ? 63U : ((__u64)((67ULL)) == 174ULL ? 64U : ((__u64)((67ULL)) == 175ULL ? 65U : ((__u64)((67ULL)) == 181ULL ? 66U : ((__u64)((67ULL)) == 184ULL ? 67U : ((__u64)((67ULL)) == 189ULL ? 68U : ((__u64)((67ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 36U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((68ULL)) == 1ULL ? 0U : ((__u64)((68ULL)) == 2ULL ? 1U : ((__u64)((68ULL)) == 3ULL ? 2U : ((__u64)((68ULL)) == 4ULL ? 3U : ((__u64)((68ULL)) == 5ULL ? 4U : ((__u64)((68ULL)) == 6ULL ? 5U : ((__u64)((68ULL)) == 7ULL ? 6U : ((__u64)((68ULL)) == 8ULL ? 7U : ((__u64)((68ULL)) == 9ULL ? 8U : ((__u64)((68ULL)) == 10ULL ? 9U : ((__u64)((68ULL)) == 11ULL ? 10U : ((__u64)((68ULL)) == 12ULL ? 11U : ((__u64)((68ULL)) == 14ULL ? 12U : ((__u64)((68ULL)) == 15ULL ? 13U : ((__u64)((68ULL)) == 16ULL ? 14U : ((__u64)((68ULL)) == 20ULL ? 15U : ((__u64)((68ULL)) == 21ULL ? 16U : ((__u64)((68ULL)) == 23ULL ? 17U : ((__u64)((68ULL)) == 25ULL ? 18U : ((__u64)((68ULL)) == 26ULL ? 19U : ((__u64)((68ULL)) == 27ULL ? 20U : ((__u64)((68ULL)) == 28ULL ? 21U : ((__u64)((68ULL)) == 32ULL ? 22U : ((__u64)((68ULL)) == 35ULL ? 23U : ((__u64)((68ULL)) == 36ULL ? 24U : ((__u64)((68ULL)) == 37ULL ? 25U : ((__u64)((68ULL)) == 38ULL ? 26U : ((__u64)((68ULL)) == 39ULL ? 27U : ((__u64)((68ULL)) == 43ULL ? 28U : ((__u64)((68ULL)) == 44ULL ? 29U : ((__u64)((68ULL)) == 45ULL ? 30U : ((__u64)((68ULL)) == 46ULL ? 31U : ((__u64)((68ULL)) == 50ULL ? 32U : ((__u64)((68ULL)) == 54ULL ? 33U : ((__u64)((68ULL)) == 58ULL ? 34U : ((__u64)((68ULL)) == 65ULL ? 35U : ((__u64)((68ULL)) == 67ULL ? 36U : ((__u64)((68ULL)) == 68ULL ? 37U : ((__u64)((68ULL)) == 69ULL ? 38U : ((__u64)((68ULL)) == 80ULL ? 39U : ((__u64)((68ULL)) == 85ULL ? 40U : ((__u64)((68ULL)) == 86ULL ? 41U : ((__u64)((68ULL)) == 87ULL ? 42U : ((__u64)((68ULL)) == 88ULL ? 43U : ((__u64)((68ULL)) == 95ULL ? 44U : ((__u64)((68ULL)) == 99ULL ? 45U : ((__u64)((68ULL)) == 105ULL ? 46U : ((__u64)((68ULL)) == 109ULL ? 47U : ((__u64)((68ULL)) == 112ULL ? 48U : ((__u64)((68ULL)) == 113ULL ? 49U : ((__u64)((68ULL)) == 114ULL ? 50U : ((__u64)((68ULL)) == 115ULL ? 51U : ((__u64)((68ULL)) == 118ULL ? 52U : ((__u64)((68ULL)) == 122ULL ? 53U : ((__u64)((68ULL)) == 124ULL ? 54U : ((__u64)((68ULL)) == 125ULL ? 55U : ((__u64)((68ULL)) == 130ULL ? 56U : ((__u64)((68ULL)) == 148ULL ? 57U : ((__u64)((68ULL)) == 152ULL ? 58U : ((__u64)((68ULL)) == 155ULL ? 59U : ((__u64)((68ULL)) == 158ULL ? 60U : ((__u64)((68ULL)) == 160ULL ? 61U : ((__u64)((68ULL)) == 163ULL ? 62U : ((__u64)((68ULL)) == 173ULL ? 63U : ((__u64)((68ULL)) == 174ULL ? 64U : ((__u64)((68ULL)) == 175ULL ? 65U : ((__u64)((68ULL)) == 181ULL ? 66U : ((__u64)((68ULL)) == 184ULL ? 67U : ((__u64)((68ULL)) == 189ULL ? 68U : ((__u64)((68ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 37U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((69ULL)) == 1ULL ? 0U : ((__u64)((69ULL)) == 2ULL ? 1U : ((__u64)((69ULL)) == 3ULL ? 2U : ((__u64)((69ULL)) == 4ULL ? 3U : ((__u64)((69ULL)) == 5ULL ? 4U : ((__u64)((69ULL)) == 6ULL ? 5U : ((__u64)((69ULL)) == 7ULL ? 6U : ((__u64)((69ULL)) == 8ULL ? 7U : ((__u64)((69ULL)) == 9ULL ? 8U : ((__u64)((69ULL)) == 10ULL ? 9U : ((__u64)((69ULL)) == 11ULL ? 10U : ((__u64)((69ULL)) == 12ULL ? 11U : ((__u64)((69ULL)) == 14ULL ? 12U : ((__u64)((69ULL)) == 15ULL ? 13U : ((__u64)((69ULL)) == 16ULL ? 14U : ((__u64)((69ULL)) == 20ULL ? 15U : ((__u64)((69ULL)) == 21ULL ? 16U : ((__u64)((69ULL)) == 23ULL ? 17U : ((__u64)((69ULL)) == 25ULL ? 18U : ((__u64)((69ULL)) == 26ULL ? 19U : ((__u64)((69ULL)) == 27ULL ? 20U : ((__u64)((69ULL)) == 28ULL ? 21U : ((__u64)((69ULL)) == 32ULL ? 22U : ((__u64)((69ULL)) == 35ULL ? 23U : ((__u64)((69ULL)) == 36ULL ? 24U : ((__u64)((69ULL)) == 37ULL ? 25U : ((__u64)((69ULL)) == 38ULL ? 26U : ((__u64)((69ULL)) == 39ULL ? 27U : ((__u64)((69ULL)) == 43ULL ? 28U : ((__u64)((69ULL)) == 44ULL ? 29U : ((__u64)((69ULL)) == 45ULL ? 30U : ((__u64)((69ULL)) == 46ULL ? 31U : ((__u64)((69ULL)) == 50ULL ? 32U : ((__u64)((69ULL)) == 54ULL ? 33U : ((__u64)((69ULL)) == 58ULL ? 34U : ((__u64)((69ULL)) == 65ULL ? 35U : ((__u64)((69ULL)) == 67ULL ? 36U : ((__u64)((69ULL)) == 68ULL ? 37U : ((__u64)((69ULL)) == 69ULL ? 38U : ((__u64)((69ULL)) == 80ULL ? 39U : ((__u64)((69ULL)) == 85ULL ? 40U : ((__u64)((69ULL)) == 86ULL ? 41U : ((__u64)((69ULL)) == 87ULL ? 42U : ((__u64)((69ULL)) == 88ULL ? 43U : ((__u64)((69ULL)) == 95ULL ? 44U : ((__u64)((69ULL)) == 99ULL ? 45U : ((__u64)((69ULL)) == 105ULL ? 46U : ((__u64)((69ULL)) == 109ULL ? 47U : ((__u64)((69ULL)) == 112ULL ? 48U : ((__u64)((69ULL)) == 113ULL ? 49U : ((__u64)((69ULL)) == 114ULL ? 50U : ((__u64)((69ULL)) == 115ULL ? 51U : ((__u64)((69ULL)) == 118ULL ? 52U : ((__u64)((69ULL)) == 122ULL ? 53U : ((__u64)((69ULL)) == 124ULL ? 54U : ((__u64)((69ULL)) == 125ULL ? 55U : ((__u64)((69ULL)) == 130ULL ? 56U : ((__u64)((69ULL)) == 148ULL ? 57U : ((__u64)((69ULL)) == 152ULL ? 58U : ((__u64)((69ULL)) == 155ULL ? 59U : ((__u64)((69ULL)) == 158ULL ? 60U : ((__u64)((69ULL)) == 160ULL ? 61U : ((__u64)((69ULL)) == 163ULL ? 62U : ((__u64)((69ULL)) == 173ULL ? 63U : ((__u64)((69ULL)) == 174ULL ? 64U : ((__u64)((69ULL)) == 175ULL ? 65U : ((__u64)((69ULL)) == 181ULL ? 66U : ((__u64)((69ULL)) == 184ULL ? 67U : ((__u64)((69ULL)) == 189ULL ? 68U : ((__u64)((69ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 38U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((80ULL)) == 1ULL ? 0U : ((__u64)((80ULL)) == 2ULL ? 1U : ((__u64)((80ULL)) == 3ULL ? 2U : ((__u64)((80ULL)) == 4ULL ? 3U : ((__u64)((80ULL)) == 5ULL ? 4U : ((__u64)((80ULL)) == 6ULL ? 5U : ((__u64)((80ULL)) == 7ULL ? 6U : ((__u64)((80ULL)) == 8ULL ? 7U : ((__u64)((80ULL)) == 9ULL ? 8U : ((__u64)((80ULL)) == 10ULL ? 9U : ((__u64)((80ULL)) == 11ULL ? 10U : ((__u64)((80ULL)) == 12ULL ? 11U : ((__u64)((80ULL)) == 14ULL ? 12U : ((__u64)((80ULL)) == 15ULL ? 13U : ((__u64)((80ULL)) == 16ULL ? 14U : ((__u64)((80ULL)) == 20ULL ? 15U : ((__u64)((80ULL)) == 21ULL ? 16U : ((__u64)((80ULL)) == 23ULL ? 17U : ((__u64)((80ULL)) == 25ULL ? 18U : ((__u64)((80ULL)) == 26ULL ? 19U : ((__u64)((80ULL)) == 27ULL ? 20U : ((__u64)((80ULL)) == 28ULL ? 21U : ((__u64)((80ULL)) == 32ULL ? 22U : ((__u64)((80ULL)) == 35ULL ? 23U : ((__u64)((80ULL)) == 36ULL ? 24U : ((__u64)((80ULL)) == 37ULL ? 25U : ((__u64)((80ULL)) == 38ULL ? 26U : ((__u64)((80ULL)) == 39ULL ? 27U : ((__u64)((80ULL)) == 43ULL ? 28U : ((__u64)((80ULL)) == 44ULL ? 29U : ((__u64)((80ULL)) == 45ULL ? 30U : ((__u64)((80ULL)) == 46ULL ? 31U : ((__u64)((80ULL)) == 50ULL ? 32U : ((__u64)((80ULL)) == 54ULL ? 33U : ((__u64)((80ULL)) == 58ULL ? 34U : ((__u64)((80ULL)) == 65ULL ? 35U : ((__u64)((80ULL)) == 67ULL ? 36U : ((__u64)((80ULL)) == 68ULL ? 37U : ((__u64)((80ULL)) == 69ULL ? 38U : ((__u64)((80ULL)) == 80ULL ? 39U : ((__u64)((80ULL)) == 85ULL ? 40U : ((__u64)((80ULL)) == 86ULL ? 41U : ((__u64)((80ULL)) == 87ULL ? 42U : ((__u64)((80ULL)) == 88ULL ? 43U : ((__u64)((80ULL)) == 95ULL ? 44U : ((__u64)((80ULL)) == 99ULL ? 45U : ((__u64)((80ULL)) == 105ULL ? 46U : ((__u64)((80ULL)) == 109ULL ? 47U : ((__u64)((80ULL)) == 112ULL ? 48U : ((__u64)((80ULL)) == 113ULL ? 49U : ((__u64)((80ULL)) == 114ULL ? 50U : ((__u64)((80ULL)) == 115ULL ? 51U : ((__u64)((80ULL)) == 118ULL ? 52U : ((__u64)((80ULL)) == 122ULL ? 53U : ((__u64)((80ULL)) == 124ULL ? 54U : ((__u64)((80ULL)) == 125ULL ? 55U : ((__u64)((80ULL)) == 130ULL ? 56U : ((__u64)((80ULL)) == 148ULL ? 57U : ((__u64)((80ULL)) == 152ULL ? 58U : ((__u64)((80ULL)) == 155ULL ? 59U : ((__u64)((80ULL)) == 158ULL ? 60U : ((__u64)((80ULL)) == 160ULL ? 61U : ((__u64)((80ULL)) == 163ULL ? 62U : ((__u64)((80ULL)) == 173ULL ? 63U : ((__u64)((80ULL)) == 174ULL ? 64U : ((__u64)((80ULL)) == 175ULL ? 65U : ((__u64)((80ULL)) == 181ULL ? 66U : ((__u64)((80ULL)) == 184ULL ? 67U : ((__u64)((80ULL)) == 189ULL ? 68U : ((__u64)((80ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 39U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((85ULL)) == 1ULL ? 0U : ((__u64)((85ULL)) == 2ULL ? 1U : ((__u64)((85ULL)) == 3ULL ? 2U : ((__u64)((85ULL)) == 4ULL ? 3U : ((__u64)((85ULL)) == 5ULL ? 4U : ((__u64)((85ULL)) == 6ULL ? 5U : ((__u64)((85ULL)) == 7ULL ? 6U : ((__u64)((85ULL)) == 8ULL ? 7U : ((__u64)((85ULL)) == 9ULL ? 8U : ((__u64)((85ULL)) == 10ULL ? 9U : ((__u64)((85ULL)) == 11ULL ? 10U : ((__u64)((85ULL)) == 12ULL ? 11U : ((__u64)((85ULL)) == 14ULL ? 12U : ((__u64)((85ULL)) == 15ULL ? 13U : ((__u64)((85ULL)) == 16ULL ? 14U : ((__u64)((85ULL)) == 20ULL ? 15U : ((__u64)((85ULL)) == 21ULL ? 16U : ((__u64)((85ULL)) == 23ULL ? 17U : ((__u64)((85ULL)) == 25ULL ? 18U : ((__u64)((85ULL)) == 26ULL ? 19U : ((__u64)((85ULL)) == 27ULL ? 20U : ((__u64)((85ULL)) == 28ULL ? 21U : ((__u64)((85ULL)) == 32ULL ? 22U : ((__u64)((85ULL)) == 35ULL ? 23U : ((__u64)((85ULL)) == 36ULL ? 24U : ((__u64)((85ULL)) == 37ULL ? 25U : ((__u64)((85ULL)) == 38ULL ? 26U : ((__u64)((85ULL)) == 39ULL ? 27U : ((__u64)((85ULL)) == 43ULL ? 28U : ((__u64)((85ULL)) == 44ULL ? 29U : ((__u64)((85ULL)) == 45ULL ? 30U : ((__u64)((85ULL)) == 46ULL ? 31U : ((__u64)((85ULL)) == 50ULL ? 32U : ((__u64)((85ULL)) == 54ULL ? 33U : ((__u64)((85ULL)) == 58ULL ? 34U : ((__u64)((85ULL)) == 65ULL ? 35U : ((__u64)((85ULL)) == 67ULL ? 36U : ((__u64)((85ULL)) == 68ULL ? 37U : ((__u64)((85ULL)) == 69ULL ? 38U : ((__u64)((85ULL)) == 80ULL ? 39U : ((__u64)((85ULL)) == 85ULL ? 40U : ((__u64)((85ULL)) == 86ULL ? 41U : ((__u64)((85ULL)) == 87ULL ? 42U : ((__u64)((85ULL)) == 88ULL ? 43U : ((__u64)((85ULL)) == 95ULL ? 44U : ((__u64)((85ULL)) == 99ULL ? 45U : ((__u64)((85ULL)) == 105ULL ? 46U : ((__u64)((85ULL)) == 109ULL ? 47U : ((__u64)((85ULL)) == 112ULL ? 48U : ((__u64)((85ULL)) == 113ULL ? 49U : ((__u64)((85ULL)) == 114ULL ? 50U : ((__u64)((85ULL)) == 115ULL ? 51U : ((__u64)((85ULL)) == 118ULL ? 52U : ((__u64)((85ULL)) == 122ULL ? 53U : ((__u64)((85ULL)) == 124ULL ? 54U : ((__u64)((85ULL)) == 125ULL ? 55U : ((__u64)((85ULL)) == 130ULL ? 56U : ((__u64)((85ULL)) == 148ULL ? 57U : ((__u64)((85ULL)) == 152ULL ? 58U : ((__u64)((85ULL)) == 155ULL ? 59U : ((__u64)((85ULL)) == 158ULL ? 60U : ((__u64)((85ULL)) == 160ULL ? 61U : ((__u64)((85ULL)) == 163ULL ? 62U : ((__u64)((85ULL)) == 173ULL ? 63U : ((__u64)((85ULL)) == 174ULL ? 64U : ((__u64)((85ULL)) == 175ULL ? 65U : ((__u64)((85ULL)) == 181ULL ? 66U : ((__u64)((85ULL)) == 184ULL ? 67U : ((__u64)((85ULL)) == 189ULL ? 68U : ((__u64)((85ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 40U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((86ULL)) == 1ULL ? 0U : ((__u64)((86ULL)) == 2ULL ? 1U : ((__u64)((86ULL)) == 3ULL ? 2U : ((__u64)((86ULL)) == 4ULL ? 3U : ((__u64)((86ULL)) == 5ULL ? 4U : ((__u64)((86ULL)) == 6ULL ? 5U : ((__u64)((86ULL)) == 7ULL ? 6U : ((__u64)((86ULL)) == 8ULL ? 7U : ((__u64)((86ULL)) == 9ULL ? 8U : ((__u64)((86ULL)) == 10ULL ? 9U : ((__u64)((86ULL)) == 11ULL ? 10U : ((__u64)((86ULL)) == 12ULL ? 11U : ((__u64)((86ULL)) == 14ULL ? 12U : ((__u64)((86ULL)) == 15ULL ? 13U : ((__u64)((86ULL)) == 16ULL ? 14U : ((__u64)((86ULL)) == 20ULL ? 15U : ((__u64)((86ULL)) == 21ULL ? 16U : ((__u64)((86ULL)) == 23ULL ? 17U : ((__u64)((86ULL)) == 25ULL ? 18U : ((__u64)((86ULL)) == 26ULL ? 19U : ((__u64)((86ULL)) == 27ULL ? 20U : ((__u64)((86ULL)) == 28ULL ? 21U : ((__u64)((86ULL)) == 32ULL ? 22U : ((__u64)((86ULL)) == 35ULL ? 23U : ((__u64)((86ULL)) == 36ULL ? 24U : ((__u64)((86ULL)) == 37ULL ? 25U : ((__u64)((86ULL)) == 38ULL ? 26U : ((__u64)((86ULL)) == 39ULL ? 27U : ((__u64)((86ULL)) == 43ULL ? 28U : ((__u64)((86ULL)) == 44ULL ? 29U : ((__u64)((86ULL)) == 45ULL ? 30U : ((__u64)((86ULL)) == 46ULL ? 31U : ((__u64)((86ULL)) == 50ULL ? 32U : ((__u64)((86ULL)) == 54ULL ? 33U : ((__u64)((86ULL)) == 58ULL ? 34U : ((__u64)((86ULL)) == 65ULL ? 35U : ((__u64)((86ULL)) == 67ULL ? 36U : ((__u64)((86ULL)) == 68ULL ? 37U : ((__u64)((86ULL)) == 69ULL ? 38U : ((__u64)((86ULL)) == 80ULL ? 39U : ((__u64)((86ULL)) == 85ULL ? 40U : ((__u64)((86ULL)) == 86ULL ? 41U : ((__u64)((86ULL)) == 87ULL ? 42U : ((__u64)((86ULL)) == 88ULL ? 43U : ((__u64)((86ULL)) == 95ULL ? 44U : ((__u64)((86ULL)) == 99ULL ? 45U : ((__u64)((86ULL)) == 105ULL ? 46U : ((__u64)((86ULL)) == 109ULL ? 47U : ((__u64)((86ULL)) == 112ULL ? 48U : ((__u64)((86ULL)) == 113ULL ? 49U : ((__u64)((86ULL)) == 114ULL ? 50U : ((__u64)((86ULL)) == 115ULL ? 51U : ((__u64)((86ULL)) == 118ULL ? 52U : ((__u64)((86ULL)) == 122ULL ? 53U : ((__u64)((86ULL)) == 124ULL ? 54U : ((__u64)((86ULL)) == 125ULL ? 55U : ((__u64)((86ULL)) == 130ULL ? 56U : ((__u64)((86ULL)) == 148ULL ? 57U : ((__u64)((86ULL)) == 152ULL ? 58U : ((__u64)((86ULL)) == 155ULL ? 59U : ((__u64)((86ULL)) == 158ULL ? 60U : ((__u64)((86ULL)) == 160ULL ? 61U : ((__u64)((86ULL)) == 163ULL ? 62U : ((__u64)((86ULL)) == 173ULL ? 63U : ((__u64)((86ULL)) == 174ULL ? 64U : ((__u64)((86ULL)) == 175ULL ? 65U : ((__u64)((86ULL)) == 181ULL ? 66U : ((__u64)((86ULL)) == 184ULL ? 67U : ((__u64)((86ULL)) == 189ULL ? 68U : ((__u64)((86ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 41U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((87ULL)) == 1ULL ? 0U : ((__u64)((87ULL)) == 2ULL ? 1U : ((__u64)((87ULL)) == 3ULL ? 2U : ((__u64)((87ULL)) == 4ULL ? 3U : ((__u64)((87ULL)) == 5ULL ? 4U : ((__u64)((87ULL)) == 6ULL ? 5U : ((__u64)((87ULL)) == 7ULL ? 6U : ((__u64)((87ULL)) == 8ULL ? 7U : ((__u64)((87ULL)) == 9ULL ? 8U : ((__u64)((87ULL)) == 10ULL ? 9U : ((__u64)((87ULL)) == 11ULL ? 10U : ((__u64)((87ULL)) == 12ULL ? 11U : ((__u64)((87ULL)) == 14ULL ? 12U : ((__u64)((87ULL)) == 15ULL ? 13U : ((__u64)((87ULL)) == 16ULL ? 14U : ((__u64)((87ULL)) == 20ULL ? 15U : ((__u64)((87ULL)) == 21ULL ? 16U : ((__u64)((87ULL)) == 23ULL ? 17U : ((__u64)((87ULL)) == 25ULL ? 18U : ((__u64)((87ULL)) == 26ULL ? 19U : ((__u64)((87ULL)) == 27ULL ? 20U : ((__u64)((87ULL)) == 28ULL ? 21U : ((__u64)((87ULL)) == 32ULL ? 22U : ((__u64)((87ULL)) == 35ULL ? 23U : ((__u64)((87ULL)) == 36ULL ? 24U : ((__u64)((87ULL)) == 37ULL ? 25U : ((__u64)((87ULL)) == 38ULL ? 26U : ((__u64)((87ULL)) == 39ULL ? 27U : ((__u64)((87ULL)) == 43ULL ? 28U : ((__u64)((87ULL)) == 44ULL ? 29U : ((__u64)((87ULL)) == 45ULL ? 30U : ((__u64)((87ULL)) == 46ULL ? 31U : ((__u64)((87ULL)) == 50ULL ? 32U : ((__u64)((87ULL)) == 54ULL ? 33U : ((__u64)((87ULL)) == 58ULL ? 34U : ((__u64)((87ULL)) == 65ULL ? 35U : ((__u64)((87ULL)) == 67ULL ? 36U : ((__u64)((87ULL)) == 68ULL ? 37U : ((__u64)((87ULL)) == 69ULL ? 38U : ((__u64)((87ULL)) == 80ULL ? 39U : ((__u64)((87ULL)) == 85ULL ? 40U : ((__u64)((87ULL)) == 86ULL ? 41U : ((__u64)((87ULL)) == 87ULL ? 42U : ((__u64)((87ULL)) == 88ULL ? 43U : ((__u64)((87ULL)) == 95ULL ? 44U : ((__u64)((87ULL)) == 99ULL ? 45U : ((__u64)((87ULL)) == 105ULL ? 46U : ((__u64)((87ULL)) == 109ULL ? 47U : ((__u64)((87ULL)) == 112ULL ? 48U : ((__u64)((87ULL)) == 113ULL ? 49U : ((__u64)((87ULL)) == 114ULL ? 50U : ((__u64)((87ULL)) == 115ULL ? 51U : ((__u64)((87ULL)) == 118ULL ? 52U : ((__u64)((87ULL)) == 122ULL ? 53U : ((__u64)((87ULL)) == 124ULL ? 54U : ((__u64)((87ULL)) == 125ULL ? 55U : ((__u64)((87ULL)) == 130ULL ? 56U : ((__u64)((87ULL)) == 148ULL ? 57U : ((__u64)((87ULL)) == 152ULL ? 58U : ((__u64)((87ULL)) == 155ULL ? 59U : ((__u64)((87ULL)) == 158ULL ? 60U : ((__u64)((87ULL)) == 160ULL ? 61U : ((__u64)((87ULL)) == 163ULL ? 62U : ((__u64)((87ULL)) == 173ULL ? 63U : ((__u64)((87ULL)) == 174ULL ? 64U : ((__u64)((87ULL)) == 175ULL ? 65U : ((__u64)((87ULL)) == 181ULL ? 66U : ((__u64)((87ULL)) == 184ULL ? 67U : ((__u64)((87ULL)) == 189ULL ? 68U : ((__u64)((87ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 42U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((88ULL)) == 1ULL ? 0U : ((__u64)((88ULL)) == 2ULL ? 1U : ((__u64)((88ULL)) == 3ULL ? 2U : ((__u64)((88ULL)) == 4ULL ? 3U : ((__u64)((88ULL)) == 5ULL ? 4U : ((__u64)((88ULL)) == 6ULL ? 5U : ((__u64)((88ULL)) == 7ULL ? 6U : ((__u64)((88ULL)) == 8ULL ? 7U : ((__u64)((88ULL)) == 9ULL ? 8U : ((__u64)((88ULL)) == 10ULL ? 9U : ((__u64)((88ULL)) == 11ULL ? 10U : ((__u64)((88ULL)) == 12ULL ? 11U : ((__u64)((88ULL)) == 14ULL ? 12U : ((__u64)((88ULL)) == 15ULL ? 13U : ((__u64)((88ULL)) == 16ULL ? 14U : ((__u64)((88ULL)) == 20ULL ? 15U : ((__u64)((88ULL)) == 21ULL ? 16U : ((__u64)((88ULL)) == 23ULL ? 17U : ((__u64)((88ULL)) == 25ULL ? 18U : ((__u64)((88ULL)) == 26ULL ? 19U : ((__u64)((88ULL)) == 27ULL ? 20U : ((__u64)((88ULL)) == 28ULL ? 21U : ((__u64)((88ULL)) == 32ULL ? 22U : ((__u64)((88ULL)) == 35ULL ? 23U : ((__u64)((88ULL)) == 36ULL ? 24U : ((__u64)((88ULL)) == 37ULL ? 25U : ((__u64)((88ULL)) == 38ULL ? 26U : ((__u64)((88ULL)) == 39ULL ? 27U : ((__u64)((88ULL)) == 43ULL ? 28U : ((__u64)((88ULL)) == 44ULL ? 29U : ((__u64)((88ULL)) == 45ULL ? 30U : ((__u64)((88ULL)) == 46ULL ? 31U : ((__u64)((88ULL)) == 50ULL ? 32U : ((__u64)((88ULL)) == 54ULL ? 33U : ((__u64)((88ULL)) == 58ULL ? 34U : ((__u64)((88ULL)) == 65ULL ? 35U : ((__u64)((88ULL)) == 67ULL ? 36U : ((__u64)((88ULL)) == 68ULL ? 37U : ((__u64)((88ULL)) == 69ULL ? 38U : ((__u64)((88ULL)) == 80ULL ? 39U : ((__u64)((88ULL)) == 85ULL ? 40U : ((__u64)((88ULL)) == 86ULL ? 41U : ((__u64)((88ULL)) == 87ULL ? 42U : ((__u64)((88ULL)) == 88ULL ? 43U : ((__u64)((88ULL)) == 95ULL ? 44U : ((__u64)((88ULL)) == 99ULL ? 45U : ((__u64)((88ULL)) == 105ULL ? 46U : ((__u64)((88ULL)) == 109ULL ? 47U : ((__u64)((88ULL)) == 112ULL ? 48U : ((__u64)((88ULL)) == 113ULL ? 49U : ((__u64)((88ULL)) == 114ULL ? 50U : ((__u64)((88ULL)) == 115ULL ? 51U : ((__u64)((88ULL)) == 118ULL ? 52U : ((__u64)((88ULL)) == 122ULL ? 53U : ((__u64)((88ULL)) == 124ULL ? 54U : ((__u64)((88ULL)) == 125ULL ? 55U : ((__u64)((88ULL)) == 130ULL ? 56U : ((__u64)((88ULL)) == 148ULL ? 57U : ((__u64)((88ULL)) == 152ULL ? 58U : ((__u64)((88ULL)) == 155ULL ? 59U : ((__u64)((88ULL)) == 158ULL ? 60U : ((__u64)((88ULL)) == 160ULL ? 61U : ((__u64)((88ULL)) == 163ULL ? 62U : ((__u64)((88ULL)) == 173ULL ? 63U : ((__u64)((88ULL)) == 174ULL ? 64U : ((__u64)((88ULL)) == 175ULL ? 65U : ((__u64)((88ULL)) == 181ULL ? 66U : ((__u64)((88ULL)) == 184ULL ? 67U : ((__u64)((88ULL)) == 189ULL ? 68U : ((__u64)((88ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 43U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((95ULL)) == 1ULL ? 0U : ((__u64)((95ULL)) == 2ULL ? 1U : ((__u64)((95ULL)) == 3ULL ? 2U : ((__u64)((95ULL)) == 4ULL ? 3U : ((__u64)((95ULL)) == 5ULL ? 4U : ((__u64)((95ULL)) == 6ULL ? 5U : ((__u64)((95ULL)) == 7ULL ? 6U : ((__u64)((95ULL)) == 8ULL ? 7U : ((__u64)((95ULL)) == 9ULL ? 8U : ((__u64)((95ULL)) == 10ULL ? 9U : ((__u64)((95ULL)) == 11ULL ? 10U : ((__u64)((95ULL)) == 12ULL ? 11U : ((__u64)((95ULL)) == 14ULL ? 12U : ((__u64)((95ULL)) == 15ULL ? 13U : ((__u64)((95ULL)) == 16ULL ? 14U : ((__u64)((95ULL)) == 20ULL ? 15U : ((__u64)((95ULL)) == 21ULL ? 16U : ((__u64)((95ULL)) == 23ULL ? 17U : ((__u64)((95ULL)) == 25ULL ? 18U : ((__u64)((95ULL)) == 26ULL ? 19U : ((__u64)((95ULL)) == 27ULL ? 20U : ((__u64)((95ULL)) == 28ULL ? 21U : ((__u64)((95ULL)) == 32ULL ? 22U : ((__u64)((95ULL)) == 35ULL ? 23U : ((__u64)((95ULL)) == 36ULL ? 24U : ((__u64)((95ULL)) == 37ULL ? 25U : ((__u64)((95ULL)) == 38ULL ? 26U : ((__u64)((95ULL)) == 39ULL ? 27U : ((__u64)((95ULL)) == 43ULL ? 28U : ((__u64)((95ULL)) == 44ULL ? 29U : ((__u64)((95ULL)) == 45ULL ? 30U : ((__u64)((95ULL)) == 46ULL ? 31U : ((__u64)((95ULL)) == 50ULL ? 32U : ((__u64)((95ULL)) == 54ULL ? 33U : ((__u64)((95ULL)) == 58ULL ? 34U : ((__u64)((95ULL)) == 65ULL ? 35U : ((__u64)((95ULL)) == 67ULL ? 36U : ((__u64)((95ULL)) == 68ULL ? 37U : ((__u64)((95ULL)) == 69ULL ? 38U : ((__u64)((95ULL)) == 80ULL ? 39U : ((__u64)((95ULL)) == 85ULL ? 40U : ((__u64)((95ULL)) == 86ULL ? 41U : ((__u64)((95ULL)) == 87ULL ? 42U : ((__u64)((95ULL)) == 88ULL ? 43U : ((__u64)((95ULL)) == 95ULL ? 44U : ((__u64)((95ULL)) == 99ULL ? 45U : ((__u64)((95ULL)) == 105ULL ? 46U : ((__u64)((95ULL)) == 109ULL ? 47U : ((__u64)((95ULL)) == 112ULL ? 48U : ((__u64)((95ULL)) == 113ULL ? 49U : ((__u64)((95ULL)) == 114ULL ? 50U : ((__u64)((95ULL)) == 115ULL ? 51U : ((__u64)((95ULL)) == 118ULL ? 52U : ((__u64)((95ULL)) == 122ULL ? 53U : ((__u64)((95ULL)) == 124ULL ? 54U : ((__u64)((95ULL)) == 125ULL ? 55U : ((__u64)((95ULL)) == 130ULL ? 56U : ((__u64)((95ULL)) == 148ULL ? 57U : ((__u64)((95ULL)) == 152ULL ? 58U : ((__u64)((95ULL)) == 155ULL ? 59U : ((__u64)((95ULL)) == 158ULL ? 60U : ((__u64)((95ULL)) == 160ULL ? 61U : ((__u64)((95ULL)) == 163ULL ? 62U : ((__u64)((95ULL)) == 173ULL ? 63U : ((__u64)((95ULL)) == 174ULL ? 64U : ((__u64)((95ULL)) == 175ULL ? 65U : ((__u64)((95ULL)) == 181ULL ? 66U : ((__u64)((95ULL)) == 184ULL ? 67U : ((__u64)((95ULL)) == 189ULL ? 68U : ((__u64)((95ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 44U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((99ULL)) == 1ULL ? 0U : ((__u64)((99ULL)) == 2ULL ? 1U : ((__u64)((99ULL)) == 3ULL ? 2U : ((__u64)((99ULL)) == 4ULL ? 3U : ((__u64)((99ULL)) == 5ULL ? 4U : ((__u64)((99ULL)) == 6ULL ? 5U : ((__u64)((99ULL)) == 7ULL ? 6U : ((__u64)((99ULL)) == 8ULL ? 7U : ((__u64)((99ULL)) == 9ULL ? 8U : ((__u64)((99ULL)) == 10ULL ? 9U : ((__u64)((99ULL)) == 11ULL ? 10U : ((__u64)((99ULL)) == 12ULL ? 11U : ((__u64)((99ULL)) == 14ULL ? 12U : ((__u64)((99ULL)) == 15ULL ? 13U : ((__u64)((99ULL)) == 16ULL ? 14U : ((__u64)((99ULL)) == 20ULL ? 15U : ((__u64)((99ULL)) == 21ULL ? 16U : ((__u64)((99ULL)) == 23ULL ? 17U : ((__u64)((99ULL)) == 25ULL ? 18U : ((__u64)((99ULL)) == 26ULL ? 19U : ((__u64)((99ULL)) == 27ULL ? 20U : ((__u64)((99ULL)) == 28ULL ? 21U : ((__u64)((99ULL)) == 32ULL ? 22U : ((__u64)((99ULL)) == 35ULL ? 23U : ((__u64)((99ULL)) == 36ULL ? 24U : ((__u64)((99ULL)) == 37ULL ? 25U : ((__u64)((99ULL)) == 38ULL ? 26U : ((__u64)((99ULL)) == 39ULL ? 27U : ((__u64)((99ULL)) == 43ULL ? 28U : ((__u64)((99ULL)) == 44ULL ? 29U : ((__u64)((99ULL)) == 45ULL ? 30U : ((__u64)((99ULL)) == 46ULL ? 31U : ((__u64)((99ULL)) == 50ULL ? 32U : ((__u64)((99ULL)) == 54ULL ? 33U : ((__u64)((99ULL)) == 58ULL ? 34U : ((__u64)((99ULL)) == 65ULL ? 35U : ((__u64)((99ULL)) == 67ULL ? 36U : ((__u64)((99ULL)) == 68ULL ? 37U : ((__u64)((99ULL)) == 69ULL ? 38U : ((__u64)((99ULL)) == 80ULL ? 39U : ((__u64)((99ULL)) == 85ULL ? 40U : ((__u64)((99ULL)) == 86ULL ? 41U : ((__u64)((99ULL)) == 87ULL ? 42U : ((__u64)((99ULL)) == 88ULL ? 43U : ((__u64)((99ULL)) == 95ULL ? 44U : ((__u64)((99ULL)) == 99ULL ? 45U : ((__u64)((99ULL)) == 105ULL ? 46U : ((__u64)((99ULL)) == 109ULL ? 47U : ((__u64)((99ULL)) == 112ULL ? 48U : ((__u64)((99ULL)) == 113ULL ? 49U : ((__u64)((99ULL)) == 114ULL ? 50U : ((__u64)((99ULL)) == 115ULL ? 51U : ((__u64)((99ULL)) == 118ULL ? 52U : ((__u64)((99ULL)) == 122ULL ? 53U : ((__u64)((99ULL)) == 124ULL ? 54U : ((__u64)((99ULL)) == 125ULL ? 55U : ((__u64)((99ULL)) == 130ULL ? 56U : ((__u64)((99ULL)) == 148ULL ? 57U : ((__u64)((99ULL)) == 152ULL ? 58U : ((__u64)((99ULL)) == 155ULL ? 59U : ((__u64)((99ULL)) == 158ULL ? 60U : ((__u64)((99ULL)) == 160ULL ? 61U : ((__u64)((99ULL)) == 163ULL ? 62U : ((__u64)((99ULL)) == 173ULL ? 63U : ((__u64)((99ULL)) == 174ULL ? 64U : ((__u64)((99ULL)) == 175ULL ? 65U : ((__u64)((99ULL)) == 181ULL ? 66U : ((__u64)((99ULL)) == 184ULL ? 67U : ((__u64)((99ULL)) == 189ULL ? 68U : ((__u64)((99ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 45U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((105ULL)) == 1ULL ? 0U : ((__u64)((105ULL)) == 2ULL ? 1U : ((__u64)((105ULL)) == 3ULL ? 2U : ((__u64)((105ULL)) == 4ULL ? 3U : ((__u64)((105ULL)) == 5ULL ? 4U : ((__u64)((105ULL)) == 6ULL ? 5U : ((__u64)((105ULL)) == 7ULL ? 6U : ((__u64)((105ULL)) == 8ULL ? 7U : ((__u64)((105ULL)) == 9ULL ? 8U : ((__u64)((105ULL)) == 10ULL ? 9U : ((__u64)((105ULL)) == 11ULL ? 10U : ((__u64)((105ULL)) == 12ULL ? 11U : ((__u64)((105ULL)) == 14ULL ? 12U : ((__u64)((105ULL)) == 15ULL ? 13U : ((__u64)((105ULL)) == 16ULL ? 14U : ((__u64)((105ULL)) == 20ULL ? 15U : ((__u64)((105ULL)) == 21ULL ? 16U : ((__u64)((105ULL)) == 23ULL ? 17U : ((__u64)((105ULL)) == 25ULL ? 18U : ((__u64)((105ULL)) == 26ULL ? 19U : ((__u64)((105ULL)) == 27ULL ? 20U : ((__u64)((105ULL)) == 28ULL ? 21U : ((__u64)((105ULL)) == 32ULL ? 22U : ((__u64)((105ULL)) == 35ULL ? 23U : ((__u64)((105ULL)) == 36ULL ? 24U : ((__u64)((105ULL)) == 37ULL ? 25U : ((__u64)((105ULL)) == 38ULL ? 26U : ((__u64)((105ULL)) == 39ULL ? 27U : ((__u64)((105ULL)) == 43ULL ? 28U : ((__u64)((105ULL)) == 44ULL ? 29U : ((__u64)((105ULL)) == 45ULL ? 30U : ((__u64)((105ULL)) == 46ULL ? 31U : ((__u64)((105ULL)) == 50ULL ? 32U : ((__u64)((105ULL)) == 54ULL ? 33U : ((__u64)((105ULL)) == 58ULL ? 34U : ((__u64)((105ULL)) == 65ULL ? 35U : ((__u64)((105ULL)) == 67ULL ? 36U : ((__u64)((105ULL)) == 68ULL ? 37U : ((__u64)((105ULL)) == 69ULL ? 38U : ((__u64)((105ULL)) == 80ULL ? 39U : ((__u64)((105ULL)) == 85ULL ? 40U : ((__u64)((105ULL)) == 86ULL ? 41U : ((__u64)((105ULL)) == 87ULL ? 42U : ((__u64)((105ULL)) == 88ULL ? 43U : ((__u64)((105ULL)) == 95ULL ? 44U : ((__u64)((105ULL)) == 99ULL ? 45U : ((__u64)((105ULL)) == 105ULL ? 46U : ((__u64)((105ULL)) == 109ULL ? 47U : ((__u64)((105ULL)) == 112ULL ? 48U : ((__u64)((105ULL)) == 113ULL ? 49U : ((__u64)((105ULL)) == 114ULL ? 50U : ((__u64)((105ULL)) == 115ULL ? 51U : ((__u64)((105ULL)) == 118ULL ? 52U : ((__u64)((105ULL)) == 122ULL ? 53U : ((__u64)((105ULL)) == 124ULL ? 54U : ((__u64)((105ULL)) == 125ULL ? 55U : ((__u64)((105ULL)) == 130ULL ? 56U : ((__u64)((105ULL)) == 148ULL ? 57U : ((__u64)((105ULL)) == 152ULL ? 58U : ((__u64)((105ULL)) == 155ULL ? 59U : ((__u64)((105ULL)) == 158ULL ? 60U : ((__u64)((105ULL)) == 160ULL ? 61U : ((__u64)((105ULL)) == 163ULL ? 62U : ((__u64)((105ULL)) == 173ULL ? 63U : ((__u64)((105ULL)) == 174ULL ? 64U : ((__u64)((105ULL)) == 175ULL ? 65U : ((__u64)((105ULL)) == 181ULL ? 66U : ((__u64)((105ULL)) == 184ULL ? 67U : ((__u64)((105ULL)) == 189ULL ? 68U : ((__u64)((105ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 46U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((109ULL)) == 1ULL ? 0U : ((__u64)((109ULL)) == 2ULL ? 1U : ((__u64)((109ULL)) == 3ULL ? 2U : ((__u64)((109ULL)) == 4ULL ? 3U : ((__u64)((109ULL)) == 5ULL ? 4U : ((__u64)((109ULL)) == 6ULL ? 5U : ((__u64)((109ULL)) == 7ULL ? 6U : ((__u64)((109ULL)) == 8ULL ? 7U : ((__u64)((109ULL)) == 9ULL ? 8U : ((__u64)((109ULL)) == 10ULL ? 9U : ((__u64)((109ULL)) == 11ULL ? 10U : ((__u64)((109ULL)) == 12ULL ? 11U : ((__u64)((109ULL)) == 14ULL ? 12U : ((__u64)((109ULL)) == 15ULL ? 13U : ((__u64)((109ULL)) == 16ULL ? 14U : ((__u64)((109ULL)) == 20ULL ? 15U : ((__u64)((109ULL)) == 21ULL ? 16U : ((__u64)((109ULL)) == 23ULL ? 17U : ((__u64)((109ULL)) == 25ULL ? 18U : ((__u64)((109ULL)) == 26ULL ? 19U : ((__u64)((109ULL)) == 27ULL ? 20U : ((__u64)((109ULL)) == 28ULL ? 21U : ((__u64)((109ULL)) == 32ULL ? 22U : ((__u64)((109ULL)) == 35ULL ? 23U : ((__u64)((109ULL)) == 36ULL ? 24U : ((__u64)((109ULL)) == 37ULL ? 25U : ((__u64)((109ULL)) == 38ULL ? 26U : ((__u64)((109ULL)) == 39ULL ? 27U : ((__u64)((109ULL)) == 43ULL ? 28U : ((__u64)((109ULL)) == 44ULL ? 29U : ((__u64)((109ULL)) == 45ULL ? 30U : ((__u64)((109ULL)) == 46ULL ? 31U : ((__u64)((109ULL)) == 50ULL ? 32U : ((__u64)((109ULL)) == 54ULL ? 33U : ((__u64)((109ULL)) == 58ULL ? 34U : ((__u64)((109ULL)) == 65ULL ? 35U : ((__u64)((109ULL)) == 67ULL ? 36U : ((__u64)((109ULL)) == 68ULL ? 37U : ((__u64)((109ULL)) == 69ULL ? 38U : ((__u64)((109ULL)) == 80ULL ? 39U : ((__u64)((109ULL)) == 85ULL ? 40U : ((__u64)((109ULL)) == 86ULL ? 41U : ((__u64)((109ULL)) == 87ULL ? 42U : ((__u64)((109ULL)) == 88ULL ? 43U : ((__u64)((109ULL)) == 95ULL ? 44U : ((__u64)((109ULL)) == 99ULL ? 45U : ((__u64)((109ULL)) == 105ULL ? 46U : ((__u64)((109ULL)) == 109ULL ? 47U : ((__u64)((109ULL)) == 112ULL ? 48U : ((__u64)((109ULL)) == 113ULL ? 49U : ((__u64)((109ULL)) == 114ULL ? 50U : ((__u64)((109ULL)) == 115ULL ? 51U : ((__u64)((109ULL)) == 118ULL ? 52U : ((__u64)((109ULL)) == 122ULL ? 53U : ((__u64)((109ULL)) == 124ULL ? 54U : ((__u64)((109ULL)) == 125ULL ? 55U : ((__u64)((109ULL)) == 130ULL ? 56U : ((__u64)((109ULL)) == 148ULL ? 57U : ((__u64)((109ULL)) == 152ULL ? 58U : ((__u64)((109ULL)) == 155ULL ? 59U : ((__u64)((109ULL)) == 158ULL ? 60U : ((__u64)((109ULL)) == 160ULL ? 61U : ((__u64)((109ULL)) == 163ULL ? 62U : ((__u64)((109ULL)) == 173ULL ? 63U : ((__u64)((109ULL)) == 174ULL ? 64U : ((__u64)((109ULL)) == 175ULL ? 65U : ((__u64)((109ULL)) == 181ULL ? 66U : ((__u64)((109ULL)) == 184ULL ? 67U : ((__u64)((109ULL)) == 189ULL ? 68U : ((__u64)((109ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 47U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((112ULL)) == 1ULL ? 0U : ((__u64)((112ULL)) == 2ULL ? 1U : ((__u64)((112ULL)) == 3ULL ? 2U : ((__u64)((112ULL)) == 4ULL ? 3U : ((__u64)((112ULL)) == 5ULL ? 4U : ((__u64)((112ULL)) == 6ULL ? 5U : ((__u64)((112ULL)) == 7ULL ? 6U : ((__u64)((112ULL)) == 8ULL ? 7U : ((__u64)((112ULL)) == 9ULL ? 8U : ((__u64)((112ULL)) == 10ULL ? 9U : ((__u64)((112ULL)) == 11ULL ? 10U : ((__u64)((112ULL)) == 12ULL ? 11U : ((__u64)((112ULL)) == 14ULL ? 12U : ((__u64)((112ULL)) == 15ULL ? 13U : ((__u64)((112ULL)) == 16ULL ? 14U : ((__u64)((112ULL)) == 20ULL ? 15U : ((__u64)((112ULL)) == 21ULL ? 16U : ((__u64)((112ULL)) == 23ULL ? 17U : ((__u64)((112ULL)) == 25ULL ? 18U : ((__u64)((112ULL)) == 26ULL ? 19U : ((__u64)((112ULL)) == 27ULL ? 20U : ((__u64)((112ULL)) == 28ULL ? 21U : ((__u64)((112ULL)) == 32ULL ? 22U : ((__u64)((112ULL)) == 35ULL ? 23U : ((__u64)((112ULL)) == 36ULL ? 24U : ((__u64)((112ULL)) == 37ULL ? 25U : ((__u64)((112ULL)) == 38ULL ? 26U : ((__u64)((112ULL)) == 39ULL ? 27U : ((__u64)((112ULL)) == 43ULL ? 28U : ((__u64)((112ULL)) == 44ULL ? 29U : ((__u64)((112ULL)) == 45ULL ? 30U : ((__u64)((112ULL)) == 46ULL ? 31U : ((__u64)((112ULL)) == 50ULL ? 32U : ((__u64)((112ULL)) == 54ULL ? 33U : ((__u64)((112ULL)) == 58ULL ? 34U : ((__u64)((112ULL)) == 65ULL ? 35U : ((__u64)((112ULL)) == 67ULL ? 36U : ((__u64)((112ULL)) == 68ULL ? 37U : ((__u64)((112ULL)) == 69ULL ? 38U : ((__u64)((112ULL)) == 80ULL ? 39U : ((__u64)((112ULL)) == 85ULL ? 40U : ((__u64)((112ULL)) == 86ULL ? 41U : ((__u64)((112ULL)) == 87ULL ? 42U : ((__u64)((112ULL)) == 88ULL ? 43U : ((__u64)((112ULL)) == 95ULL ? 44U : ((__u64)((112ULL)) == 99ULL ? 45U : ((__u64)((112ULL)) == 105ULL ? 46U : ((__u64)((112ULL)) == 109ULL ? 47U : ((__u64)((112ULL)) == 112ULL ? 48U : ((__u64)((112ULL)) == 113ULL ? 49U : ((__u64)((112ULL)) == 114ULL ? 50U : ((__u64)((112ULL)) == 115ULL ? 51U : ((__u64)((112ULL)) == 118ULL ? 52U : ((__u64)((112ULL)) == 122ULL ? 53U : ((__u64)((112ULL)) == 124ULL ? 54U : ((__u64)((112ULL)) == 125ULL ? 55U : ((__u64)((112ULL)) == 130ULL ? 56U : ((__u64)((112ULL)) == 148ULL ? 57U : ((__u64)((112ULL)) == 152ULL ? 58U : ((__u64)((112ULL)) == 155ULL ? 59U : ((__u64)((112ULL)) == 158ULL ? 60U : ((__u64)((112ULL)) == 160ULL ? 61U : ((__u64)((112ULL)) == 163ULL ? 62U : ((__u64)((112ULL)) == 173ULL ? 63U : ((__u64)((112ULL)) == 174ULL ? 64U : ((__u64)((112ULL)) == 175ULL ? 65U : ((__u64)((112ULL)) == 181ULL ? 66U : ((__u64)((112ULL)) == 184ULL ? 67U : ((__u64)((112ULL)) == 189ULL ? 68U : ((__u64)((112ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 48U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((113ULL)) == 1ULL ? 0U : ((__u64)((113ULL)) == 2ULL ? 1U : ((__u64)((113ULL)) == 3ULL ? 2U : ((__u64)((113ULL)) == 4ULL ? 3U : ((__u64)((113ULL)) == 5ULL ? 4U : ((__u64)((113ULL)) == 6ULL ? 5U : ((__u64)((113ULL)) == 7ULL ? 6U : ((__u64)((113ULL)) == 8ULL ? 7U : ((__u64)((113ULL)) == 9ULL ? 8U : ((__u64)((113ULL)) == 10ULL ? 9U : ((__u64)((113ULL)) == 11ULL ? 10U : ((__u64)((113ULL)) == 12ULL ? 11U : ((__u64)((113ULL)) == 14ULL ? 12U : ((__u64)((113ULL)) == 15ULL ? 13U : ((__u64)((113ULL)) == 16ULL ? 14U : ((__u64)((113ULL)) == 20ULL ? 15U : ((__u64)((113ULL)) == 21ULL ? 16U : ((__u64)((113ULL)) == 23ULL ? 17U : ((__u64)((113ULL)) == 25ULL ? 18U : ((__u64)((113ULL)) == 26ULL ? 19U : ((__u64)((113ULL)) == 27ULL ? 20U : ((__u64)((113ULL)) == 28ULL ? 21U : ((__u64)((113ULL)) == 32ULL ? 22U : ((__u64)((113ULL)) == 35ULL ? 23U : ((__u64)((113ULL)) == 36ULL ? 24U : ((__u64)((113ULL)) == 37ULL ? 25U : ((__u64)((113ULL)) == 38ULL ? 26U : ((__u64)((113ULL)) == 39ULL ? 27U : ((__u64)((113ULL)) == 43ULL ? 28U : ((__u64)((113ULL)) == 44ULL ? 29U : ((__u64)((113ULL)) == 45ULL ? 30U : ((__u64)((113ULL)) == 46ULL ? 31U : ((__u64)((113ULL)) == 50ULL ? 32U : ((__u64)((113ULL)) == 54ULL ? 33U : ((__u64)((113ULL)) == 58ULL ? 34U : ((__u64)((113ULL)) == 65ULL ? 35U : ((__u64)((113ULL)) == 67ULL ? 36U : ((__u64)((113ULL)) == 68ULL ? 37U : ((__u64)((113ULL)) == 69ULL ? 38U : ((__u64)((113ULL)) == 80ULL ? 39U : ((__u64)((113ULL)) == 85ULL ? 40U : ((__u64)((113ULL)) == 86ULL ? 41U : ((__u64)((113ULL)) == 87ULL ? 42U : ((__u64)((113ULL)) == 88ULL ? 43U : ((__u64)((113ULL)) == 95ULL ? 44U : ((__u64)((113ULL)) == 99ULL ? 45U : ((__u64)((113ULL)) == 105ULL ? 46U : ((__u64)((113ULL)) == 109ULL ? 47U : ((__u64)((113ULL)) == 112ULL ? 48U : ((__u64)((113ULL)) == 113ULL ? 49U : ((__u64)((113ULL)) == 114ULL ? 50U : ((__u64)((113ULL)) == 115ULL ? 51U : ((__u64)((113ULL)) == 118ULL ? 52U : ((__u64)((113ULL)) == 122ULL ? 53U : ((__u64)((113ULL)) == 124ULL ? 54U : ((__u64)((113ULL)) == 125ULL ? 55U : ((__u64)((113ULL)) == 130ULL ? 56U : ((__u64)((113ULL)) == 148ULL ? 57U : ((__u64)((113ULL)) == 152ULL ? 58U : ((__u64)((113ULL)) == 155ULL ? 59U : ((__u64)((113ULL)) == 158ULL ? 60U : ((__u64)((113ULL)) == 160ULL ? 61U : ((__u64)((113ULL)) == 163ULL ? 62U : ((__u64)((113ULL)) == 173ULL ? 63U : ((__u64)((113ULL)) == 174ULL ? 64U : ((__u64)((113ULL)) == 175ULL ? 65U : ((__u64)((113ULL)) == 181ULL ? 66U : ((__u64)((113ULL)) == 184ULL ? 67U : ((__u64)((113ULL)) == 189ULL ? 68U : ((__u64)((113ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 49U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((114ULL)) == 1ULL ? 0U : ((__u64)((114ULL)) == 2ULL ? 1U : ((__u64)((114ULL)) == 3ULL ? 2U : ((__u64)((114ULL)) == 4ULL ? 3U : ((__u64)((114ULL)) == 5ULL ? 4U : ((__u64)((114ULL)) == 6ULL ? 5U : ((__u64)((114ULL)) == 7ULL ? 6U : ((__u64)((114ULL)) == 8ULL ? 7U : ((__u64)((114ULL)) == 9ULL ? 8U : ((__u64)((114ULL)) == 10ULL ? 9U : ((__u64)((114ULL)) == 11ULL ? 10U : ((__u64)((114ULL)) == 12ULL ? 11U : ((__u64)((114ULL)) == 14ULL ? 12U : ((__u64)((114ULL)) == 15ULL ? 13U : ((__u64)((114ULL)) == 16ULL ? 14U : ((__u64)((114ULL)) == 20ULL ? 15U : ((__u64)((114ULL)) == 21ULL ? 16U : ((__u64)((114ULL)) == 23ULL ? 17U : ((__u64)((114ULL)) == 25ULL ? 18U : ((__u64)((114ULL)) == 26ULL ? 19U : ((__u64)((114ULL)) == 27ULL ? 20U : ((__u64)((114ULL)) == 28ULL ? 21U : ((__u64)((114ULL)) == 32ULL ? 22U : ((__u64)((114ULL)) == 35ULL ? 23U : ((__u64)((114ULL)) == 36ULL ? 24U : ((__u64)((114ULL)) == 37ULL ? 25U : ((__u64)((114ULL)) == 38ULL ? 26U : ((__u64)((114ULL)) == 39ULL ? 27U : ((__u64)((114ULL)) == 43ULL ? 28U : ((__u64)((114ULL)) == 44ULL ? 29U : ((__u64)((114ULL)) == 45ULL ? 30U : ((__u64)((114ULL)) == 46ULL ? 31U : ((__u64)((114ULL)) == 50ULL ? 32U : ((__u64)((114ULL)) == 54ULL ? 33U : ((__u64)((114ULL)) == 58ULL ? 34U : ((__u64)((114ULL)) == 65ULL ? 35U : ((__u64)((114ULL)) == 67ULL ? 36U : ((__u64)((114ULL)) == 68ULL ? 37U : ((__u64)((114ULL)) == 69ULL ? 38U : ((__u64)((114ULL)) == 80ULL ? 39U : ((__u64)((114ULL)) == 85ULL ? 40U : ((__u64)((114ULL)) == 86ULL ? 41U : ((__u64)((114ULL)) == 87ULL ? 42U : ((__u64)((114ULL)) == 88ULL ? 43U : ((__u64)((114ULL)) == 95ULL ? 44U : ((__u64)((114ULL)) == 99ULL ? 45U : ((__u64)((114ULL)) == 105ULL ? 46U : ((__u64)((114ULL)) == 109ULL ? 47U : ((__u64)((114ULL)) == 112ULL ? 48U : ((__u64)((114ULL)) == 113ULL ? 49U : ((__u64)((114ULL)) == 114ULL ? 50U : ((__u64)((114ULL)) == 115ULL ? 51U : ((__u64)((114ULL)) == 118ULL ? 52U : ((__u64)((114ULL)) == 122ULL ? 53U : ((__u64)((114ULL)) == 124ULL ? 54U : ((__u64)((114ULL)) == 125ULL ? 55U : ((__u64)((114ULL)) == 130ULL ? 56U : ((__u64)((114ULL)) == 148ULL ? 57U : ((__u64)((114ULL)) == 152ULL ? 58U : ((__u64)((114ULL)) == 155ULL ? 59U : ((__u64)((114ULL)) == 158ULL ? 60U : ((__u64)((114ULL)) == 160ULL ? 61U : ((__u64)((114ULL)) == 163ULL ? 62U : ((__u64)((114ULL)) == 173ULL ? 63U : ((__u64)((114ULL)) == 174ULL ? 64U : ((__u64)((114ULL)) == 175ULL ? 65U : ((__u64)((114ULL)) == 181ULL ? 66U : ((__u64)((114ULL)) == 184ULL ? 67U : ((__u64)((114ULL)) == 189ULL ? 68U : ((__u64)((114ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 50U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((115ULL)) == 1ULL ? 0U : ((__u64)((115ULL)) == 2ULL ? 1U : ((__u64)((115ULL)) == 3ULL ? 2U : ((__u64)((115ULL)) == 4ULL ? 3U : ((__u64)((115ULL)) == 5ULL ? 4U : ((__u64)((115ULL)) == 6ULL ? 5U : ((__u64)((115ULL)) == 7ULL ? 6U : ((__u64)((115ULL)) == 8ULL ? 7U : ((__u64)((115ULL)) == 9ULL ? 8U : ((__u64)((115ULL)) == 10ULL ? 9U : ((__u64)((115ULL)) == 11ULL ? 10U : ((__u64)((115ULL)) == 12ULL ? 11U : ((__u64)((115ULL)) == 14ULL ? 12U : ((__u64)((115ULL)) == 15ULL ? 13U : ((__u64)((115ULL)) == 16ULL ? 14U : ((__u64)((115ULL)) == 20ULL ? 15U : ((__u64)((115ULL)) == 21ULL ? 16U : ((__u64)((115ULL)) == 23ULL ? 17U : ((__u64)((115ULL)) == 25ULL ? 18U : ((__u64)((115ULL)) == 26ULL ? 19U : ((__u64)((115ULL)) == 27ULL ? 20U : ((__u64)((115ULL)) == 28ULL ? 21U : ((__u64)((115ULL)) == 32ULL ? 22U : ((__u64)((115ULL)) == 35ULL ? 23U : ((__u64)((115ULL)) == 36ULL ? 24U : ((__u64)((115ULL)) == 37ULL ? 25U : ((__u64)((115ULL)) == 38ULL ? 26U : ((__u64)((115ULL)) == 39ULL ? 27U : ((__u64)((115ULL)) == 43ULL ? 28U : ((__u64)((115ULL)) == 44ULL ? 29U : ((__u64)((115ULL)) == 45ULL ? 30U : ((__u64)((115ULL)) == 46ULL ? 31U : ((__u64)((115ULL)) == 50ULL ? 32U : ((__u64)((115ULL)) == 54ULL ? 33U : ((__u64)((115ULL)) == 58ULL ? 34U : ((__u64)((115ULL)) == 65ULL ? 35U : ((__u64)((115ULL)) == 67ULL ? 36U : ((__u64)((115ULL)) == 68ULL ? 37U : ((__u64)((115ULL)) == 69ULL ? 38U : ((__u64)((115ULL)) == 80ULL ? 39U : ((__u64)((115ULL)) == 85ULL ? 40U : ((__u64)((115ULL)) == 86ULL ? 41U : ((__u64)((115ULL)) == 87ULL ? 42U : ((__u64)((115ULL)) == 88ULL ? 43U : ((__u64)((115ULL)) == 95ULL ? 44U : ((__u64)((115ULL)) == 99ULL ? 45U : ((__u64)((115ULL)) == 105ULL ? 46U : ((__u64)((115ULL)) == 109ULL ? 47U : ((__u64)((115ULL)) == 112ULL ? 48U : ((__u64)((115ULL)) == 113ULL ? 49U : ((__u64)((115ULL)) == 114ULL ? 50U : ((__u64)((115ULL)) == 115ULL ? 51U : ((__u64)((115ULL)) == 118ULL ? 52U : ((__u64)((115ULL)) == 122ULL ? 53U : ((__u64)((115ULL)) == 124ULL ? 54U : ((__u64)((115ULL)) == 125ULL ? 55U : ((__u64)((115ULL)) == 130ULL ? 56U : ((__u64)((115ULL)) == 148ULL ? 57U : ((__u64)((115ULL)) == 152ULL ? 58U : ((__u64)((115ULL)) == 155ULL ? 59U : ((__u64)((115ULL)) == 158ULL ? 60U : ((__u64)((115ULL)) == 160ULL ? 61U : ((__u64)((115ULL)) == 163ULL ? 62U : ((__u64)((115ULL)) == 173ULL ? 63U : ((__u64)((115ULL)) == 174ULL ? 64U : ((__u64)((115ULL)) == 175ULL ? 65U : ((__u64)((115ULL)) == 181ULL ? 66U : ((__u64)((115ULL)) == 184ULL ? 67U : ((__u64)((115ULL)) == 189ULL ? 68U : ((__u64)((115ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 51U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((118ULL)) == 1ULL ? 0U : ((__u64)((118ULL)) == 2ULL ? 1U : ((__u64)((118ULL)) == 3ULL ? 2U : ((__u64)((118ULL)) == 4ULL ? 3U : ((__u64)((118ULL)) == 5ULL ? 4U : ((__u64)((118ULL)) == 6ULL ? 5U : ((__u64)((118ULL)) == 7ULL ? 6U : ((__u64)((118ULL)) == 8ULL ? 7U : ((__u64)((118ULL)) == 9ULL ? 8U : ((__u64)((118ULL)) == 10ULL ? 9U : ((__u64)((118ULL)) == 11ULL ? 10U : ((__u64)((118ULL)) == 12ULL ? 11U : ((__u64)((118ULL)) == 14ULL ? 12U : ((__u64)((118ULL)) == 15ULL ? 13U : ((__u64)((118ULL)) == 16ULL ? 14U : ((__u64)((118ULL)) == 20ULL ? 15U : ((__u64)((118ULL)) == 21ULL ? 16U : ((__u64)((118ULL)) == 23ULL ? 17U : ((__u64)((118ULL)) == 25ULL ? 18U : ((__u64)((118ULL)) == 26ULL ? 19U : ((__u64)((118ULL)) == 27ULL ? 20U : ((__u64)((118ULL)) == 28ULL ? 21U : ((__u64)((118ULL)) == 32ULL ? 22U : ((__u64)((118ULL)) == 35ULL ? 23U : ((__u64)((118ULL)) == 36ULL ? 24U : ((__u64)((118ULL)) == 37ULL ? 25U : ((__u64)((118ULL)) == 38ULL ? 26U : ((__u64)((118ULL)) == 39ULL ? 27U : ((__u64)((118ULL)) == 43ULL ? 28U : ((__u64)((118ULL)) == 44ULL ? 29U : ((__u64)((118ULL)) == 45ULL ? 30U : ((__u64)((118ULL)) == 46ULL ? 31U : ((__u64)((118ULL)) == 50ULL ? 32U : ((__u64)((118ULL)) == 54ULL ? 33U : ((__u64)((118ULL)) == 58ULL ? 34U : ((__u64)((118ULL)) == 65ULL ? 35U : ((__u64)((118ULL)) == 67ULL ? 36U : ((__u64)((118ULL)) == 68ULL ? 37U : ((__u64)((118ULL)) == 69ULL ? 38U : ((__u64)((118ULL)) == 80ULL ? 39U : ((__u64)((118ULL)) == 85ULL ? 40U : ((__u64)((118ULL)) == 86ULL ? 41U : ((__u64)((118ULL)) == 87ULL ? 42U : ((__u64)((118ULL)) == 88ULL ? 43U : ((__u64)((118ULL)) == 95ULL ? 44U : ((__u64)((118ULL)) == 99ULL ? 45U : ((__u64)((118ULL)) == 105ULL ? 46U : ((__u64)((118ULL)) == 109ULL ? 47U : ((__u64)((118ULL)) == 112ULL ? 48U : ((__u64)((118ULL)) == 113ULL ? 49U : ((__u64)((118ULL)) == 114ULL ? 50U : ((__u64)((118ULL)) == 115ULL ? 51U : ((__u64)((118ULL)) == 118ULL ? 52U : ((__u64)((118ULL)) == 122ULL ? 53U : ((__u64)((118ULL)) == 124ULL ? 54U : ((__u64)((118ULL)) == 125ULL ? 55U : ((__u64)((118ULL)) == 130ULL ? 56U : ((__u64)((118ULL)) == 148ULL ? 57U : ((__u64)((118ULL)) == 152ULL ? 58U : ((__u64)((118ULL)) == 155ULL ? 59U : ((__u64)((118ULL)) == 158ULL ? 60U : ((__u64)((118ULL)) == 160ULL ? 61U : ((__u64)((118ULL)) == 163ULL ? 62U : ((__u64)((118ULL)) == 173ULL ? 63U : ((__u64)((118ULL)) == 174ULL ? 64U : ((__u64)((118ULL)) == 175ULL ? 65U : ((__u64)((118ULL)) == 181ULL ? 66U : ((__u64)((118ULL)) == 184ULL ? 67U : ((__u64)((118ULL)) == 189ULL ? 68U : ((__u64)((118ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 52U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((122ULL)) == 1ULL ? 0U : ((__u64)((122ULL)) == 2ULL ? 1U : ((__u64)((122ULL)) == 3ULL ? 2U : ((__u64)((122ULL)) == 4ULL ? 3U : ((__u64)((122ULL)) == 5ULL ? 4U : ((__u64)((122ULL)) == 6ULL ? 5U : ((__u64)((122ULL)) == 7ULL ? 6U : ((__u64)((122ULL)) == 8ULL ? 7U : ((__u64)((122ULL)) == 9ULL ? 8U : ((__u64)((122ULL)) == 10ULL ? 9U : ((__u64)((122ULL)) == 11ULL ? 10U : ((__u64)((122ULL)) == 12ULL ? 11U : ((__u64)((122ULL)) == 14ULL ? 12U : ((__u64)((122ULL)) == 15ULL ? 13U : ((__u64)((122ULL)) == 16ULL ? 14U : ((__u64)((122ULL)) == 20ULL ? 15U : ((__u64)((122ULL)) == 21ULL ? 16U : ((__u64)((122ULL)) == 23ULL ? 17U : ((__u64)((122ULL)) == 25ULL ? 18U : ((__u64)((122ULL)) == 26ULL ? 19U : ((__u64)((122ULL)) == 27ULL ? 20U : ((__u64)((122ULL)) == 28ULL ? 21U : ((__u64)((122ULL)) == 32ULL ? 22U : ((__u64)((122ULL)) == 35ULL ? 23U : ((__u64)((122ULL)) == 36ULL ? 24U : ((__u64)((122ULL)) == 37ULL ? 25U : ((__u64)((122ULL)) == 38ULL ? 26U : ((__u64)((122ULL)) == 39ULL ? 27U : ((__u64)((122ULL)) == 43ULL ? 28U : ((__u64)((122ULL)) == 44ULL ? 29U : ((__u64)((122ULL)) == 45ULL ? 30U : ((__u64)((122ULL)) == 46ULL ? 31U : ((__u64)((122ULL)) == 50ULL ? 32U : ((__u64)((122ULL)) == 54ULL ? 33U : ((__u64)((122ULL)) == 58ULL ? 34U : ((__u64)((122ULL)) == 65ULL ? 35U : ((__u64)((122ULL)) == 67ULL ? 36U : ((__u64)((122ULL)) == 68ULL ? 37U : ((__u64)((122ULL)) == 69ULL ? 38U : ((__u64)((122ULL)) == 80ULL ? 39U : ((__u64)((122ULL)) == 85ULL ? 40U : ((__u64)((122ULL)) == 86ULL ? 41U : ((__u64)((122ULL)) == 87ULL ? 42U : ((__u64)((122ULL)) == 88ULL ? 43U : ((__u64)((122ULL)) == 95ULL ? 44U : ((__u64)((122ULL)) == 99ULL ? 45U : ((__u64)((122ULL)) == 105ULL ? 46U : ((__u64)((122ULL)) == 109ULL ? 47U : ((__u64)((122ULL)) == 112ULL ? 48U : ((__u64)((122ULL)) == 113ULL ? 49U : ((__u64)((122ULL)) == 114ULL ? 50U : ((__u64)((122ULL)) == 115ULL ? 51U : ((__u64)((122ULL)) == 118ULL ? 52U : ((__u64)((122ULL)) == 122ULL ? 53U : ((__u64)((122ULL)) == 124ULL ? 54U : ((__u64)((122ULL)) == 125ULL ? 55U : ((__u64)((122ULL)) == 130ULL ? 56U : ((__u64)((122ULL)) == 148ULL ? 57U : ((__u64)((122ULL)) == 152ULL ? 58U : ((__u64)((122ULL)) == 155ULL ? 59U : ((__u64)((122ULL)) == 158ULL ? 60U : ((__u64)((122ULL)) == 160ULL ? 61U : ((__u64)((122ULL)) == 163ULL ? 62U : ((__u64)((122ULL)) == 173ULL ? 63U : ((__u64)((122ULL)) == 174ULL ? 64U : ((__u64)((122ULL)) == 175ULL ? 65U : ((__u64)((122ULL)) == 181ULL ? 66U : ((__u64)((122ULL)) == 184ULL ? 67U : ((__u64)((122ULL)) == 189ULL ? 68U : ((__u64)((122ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 53U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((124ULL)) == 1ULL ? 0U : ((__u64)((124ULL)) == 2ULL ? 1U : ((__u64)((124ULL)) == 3ULL ? 2U : ((__u64)((124ULL)) == 4ULL ? 3U : ((__u64)((124ULL)) == 5ULL ? 4U : ((__u64)((124ULL)) == 6ULL ? 5U : ((__u64)((124ULL)) == 7ULL ? 6U : ((__u64)((124ULL)) == 8ULL ? 7U : ((__u64)((124ULL)) == 9ULL ? 8U : ((__u64)((124ULL)) == 10ULL ? 9U : ((__u64)((124ULL)) == 11ULL ? 10U : ((__u64)((124ULL)) == 12ULL ? 11U : ((__u64)((124ULL)) == 14ULL ? 12U : ((__u64)((124ULL)) == 15ULL ? 13U : ((__u64)((124ULL)) == 16ULL ? 14U : ((__u64)((124ULL)) == 20ULL ? 15U : ((__u64)((124ULL)) == 21ULL ? 16U : ((__u64)((124ULL)) == 23ULL ? 17U : ((__u64)((124ULL)) == 25ULL ? 18U : ((__u64)((124ULL)) == 26ULL ? 19U : ((__u64)((124ULL)) == 27ULL ? 20U : ((__u64)((124ULL)) == 28ULL ? 21U : ((__u64)((124ULL)) == 32ULL ? 22U : ((__u64)((124ULL)) == 35ULL ? 23U : ((__u64)((124ULL)) == 36ULL ? 24U : ((__u64)((124ULL)) == 37ULL ? 25U : ((__u64)((124ULL)) == 38ULL ? 26U : ((__u64)((124ULL)) == 39ULL ? 27U : ((__u64)((124ULL)) == 43ULL ? 28U : ((__u64)((124ULL)) == 44ULL ? 29U : ((__u64)((124ULL)) == 45ULL ? 30U : ((__u64)((124ULL)) == 46ULL ? 31U : ((__u64)((124ULL)) == 50ULL ? 32U : ((__u64)((124ULL)) == 54ULL ? 33U : ((__u64)((124ULL)) == 58ULL ? 34U : ((__u64)((124ULL)) == 65ULL ? 35U : ((__u64)((124ULL)) == 67ULL ? 36U : ((__u64)((124ULL)) == 68ULL ? 37U : ((__u64)((124ULL)) == 69ULL ? 38U : ((__u64)((124ULL)) == 80ULL ? 39U : ((__u64)((124ULL)) == 85ULL ? 40U : ((__u64)((124ULL)) == 86ULL ? 41U : ((__u64)((124ULL)) == 87ULL ? 42U : ((__u64)((124ULL)) == 88ULL ? 43U : ((__u64)((124ULL)) == 95ULL ? 44U : ((__u64)((124ULL)) == 99ULL ? 45U : ((__u64)((124ULL)) == 105ULL ? 46U : ((__u64)((124ULL)) == 109ULL ? 47U : ((__u64)((124ULL)) == 112ULL ? 48U : ((__u64)((124ULL)) == 113ULL ? 49U : ((__u64)((124ULL)) == 114ULL ? 50U : ((__u64)((124ULL)) == 115ULL ? 51U : ((__u64)((124ULL)) == 118ULL ? 52U : ((__u64)((124ULL)) == 122ULL ? 53U : ((__u64)((124ULL)) == 124ULL ? 54U : ((__u64)((124ULL)) == 125ULL ? 55U : ((__u64)((124ULL)) == 130ULL ? 56U : ((__u64)((124ULL)) == 148ULL ? 57U : ((__u64)((124ULL)) == 152ULL ? 58U : ((__u64)((124ULL)) == 155ULL ? 59U : ((__u64)((124ULL)) == 158ULL ? 60U : ((__u64)((124ULL)) == 160ULL ? 61U : ((__u64)((124ULL)) == 163ULL ? 62U : ((__u64)((124ULL)) == 173ULL ? 63U : ((__u64)((124ULL)) == 174ULL ? 64U : ((__u64)((124ULL)) == 175ULL ? 65U : ((__u64)((124ULL)) == 181ULL ? 66U : ((__u64)((124ULL)) == 184ULL ? 67U : ((__u64)((124ULL)) == 189ULL ? 68U : ((__u64)((124ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 54U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((125ULL)) == 1ULL ? 0U : ((__u64)((125ULL)) == 2ULL ? 1U : ((__u64)((125ULL)) == 3ULL ? 2U : ((__u64)((125ULL)) == 4ULL ? 3U : ((__u64)((125ULL)) == 5ULL ? 4U : ((__u64)((125ULL)) == 6ULL ? 5U : ((__u64)((125ULL)) == 7ULL ? 6U : ((__u64)((125ULL)) == 8ULL ? 7U : ((__u64)((125ULL)) == 9ULL ? 8U : ((__u64)((125ULL)) == 10ULL ? 9U : ((__u64)((125ULL)) == 11ULL ? 10U : ((__u64)((125ULL)) == 12ULL ? 11U : ((__u64)((125ULL)) == 14ULL ? 12U : ((__u64)((125ULL)) == 15ULL ? 13U : ((__u64)((125ULL)) == 16ULL ? 14U : ((__u64)((125ULL)) == 20ULL ? 15U : ((__u64)((125ULL)) == 21ULL ? 16U : ((__u64)((125ULL)) == 23ULL ? 17U : ((__u64)((125ULL)) == 25ULL ? 18U : ((__u64)((125ULL)) == 26ULL ? 19U : ((__u64)((125ULL)) == 27ULL ? 20U : ((__u64)((125ULL)) == 28ULL ? 21U : ((__u64)((125ULL)) == 32ULL ? 22U : ((__u64)((125ULL)) == 35ULL ? 23U : ((__u64)((125ULL)) == 36ULL ? 24U : ((__u64)((125ULL)) == 37ULL ? 25U : ((__u64)((125ULL)) == 38ULL ? 26U : ((__u64)((125ULL)) == 39ULL ? 27U : ((__u64)((125ULL)) == 43ULL ? 28U : ((__u64)((125ULL)) == 44ULL ? 29U : ((__u64)((125ULL)) == 45ULL ? 30U : ((__u64)((125ULL)) == 46ULL ? 31U : ((__u64)((125ULL)) == 50ULL ? 32U : ((__u64)((125ULL)) == 54ULL ? 33U : ((__u64)((125ULL)) == 58ULL ? 34U : ((__u64)((125ULL)) == 65ULL ? 35U : ((__u64)((125ULL)) == 67ULL ? 36U : ((__u64)((125ULL)) == 68ULL ? 37U : ((__u64)((125ULL)) == 69ULL ? 38U : ((__u64)((125ULL)) == 80ULL ? 39U : ((__u64)((125ULL)) == 85ULL ? 40U : ((__u64)((125ULL)) == 86ULL ? 41U : ((__u64)((125ULL)) == 87ULL ? 42U : ((__u64)((125ULL)) == 88ULL ? 43U : ((__u64)((125ULL)) == 95ULL ? 44U : ((__u64)((125ULL)) == 99ULL ? 45U : ((__u64)((125ULL)) == 105ULL ? 46U : ((__u64)((125ULL)) == 109ULL ? 47U : ((__u64)((125ULL)) == 112ULL ? 48U : ((__u64)((125ULL)) == 113ULL ? 49U : ((__u64)((125ULL)) == 114ULL ? 50U : ((__u64)((125ULL)) == 115ULL ? 51U : ((__u64)((125ULL)) == 118ULL ? 52U : ((__u64)((125ULL)) == 122ULL ? 53U : ((__u64)((125ULL)) == 124ULL ? 54U : ((__u64)((125ULL)) == 125ULL ? 55U : ((__u64)((125ULL)) == 130ULL ? 56U : ((__u64)((125ULL)) == 148ULL ? 57U : ((__u64)((125ULL)) == 152ULL ? 58U : ((__u64)((125ULL)) == 155ULL ? 59U : ((__u64)((125ULL)) == 158ULL ? 60U : ((__u64)((125ULL)) == 160ULL ? 61U : ((__u64)((125ULL)) == 163ULL ? 62U : ((__u64)((125ULL)) == 173ULL ? 63U : ((__u64)((125ULL)) == 174ULL ? 64U : ((__u64)((125ULL)) == 175ULL ? 65U : ((__u64)((125ULL)) == 181ULL ? 66U : ((__u64)((125ULL)) == 184ULL ? 67U : ((__u64)((125ULL)) == 189ULL ? 68U : ((__u64)((125ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 55U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((130ULL)) == 1ULL ? 0U : ((__u64)((130ULL)) == 2ULL ? 1U : ((__u64)((130ULL)) == 3ULL ? 2U : ((__u64)((130ULL)) == 4ULL ? 3U : ((__u64)((130ULL)) == 5ULL ? 4U : ((__u64)((130ULL)) == 6ULL ? 5U : ((__u64)((130ULL)) == 7ULL ? 6U : ((__u64)((130ULL)) == 8ULL ? 7U : ((__u64)((130ULL)) == 9ULL ? 8U : ((__u64)((130ULL)) == 10ULL ? 9U : ((__u64)((130ULL)) == 11ULL ? 10U : ((__u64)((130ULL)) == 12ULL ? 11U : ((__u64)((130ULL)) == 14ULL ? 12U : ((__u64)((130ULL)) == 15ULL ? 13U : ((__u64)((130ULL)) == 16ULL ? 14U : ((__u64)((130ULL)) == 20ULL ? 15U : ((__u64)((130ULL)) == 21ULL ? 16U : ((__u64)((130ULL)) == 23ULL ? 17U : ((__u64)((130ULL)) == 25ULL ? 18U : ((__u64)((130ULL)) == 26ULL ? 19U : ((__u64)((130ULL)) == 27ULL ? 20U : ((__u64)((130ULL)) == 28ULL ? 21U : ((__u64)((130ULL)) == 32ULL ? 22U : ((__u64)((130ULL)) == 35ULL ? 23U : ((__u64)((130ULL)) == 36ULL ? 24U : ((__u64)((130ULL)) == 37ULL ? 25U : ((__u64)((130ULL)) == 38ULL ? 26U : ((__u64)((130ULL)) == 39ULL ? 27U : ((__u64)((130ULL)) == 43ULL ? 28U : ((__u64)((130ULL)) == 44ULL ? 29U : ((__u64)((130ULL)) == 45ULL ? 30U : ((__u64)((130ULL)) == 46ULL ? 31U : ((__u64)((130ULL)) == 50ULL ? 32U : ((__u64)((130ULL)) == 54ULL ? 33U : ((__u64)((130ULL)) == 58ULL ? 34U : ((__u64)((130ULL)) == 65ULL ? 35U : ((__u64)((130ULL)) == 67ULL ? 36U : ((__u64)((130ULL)) == 68ULL ? 37U : ((__u64)((130ULL)) == 69ULL ? 38U : ((__u64)((130ULL)) == 80ULL ? 39U : ((__u64)((130ULL)) == 85ULL ? 40U : ((__u64)((130ULL)) == 86ULL ? 41U : ((__u64)((130ULL)) == 87ULL ? 42U : ((__u64)((130ULL)) == 88ULL ? 43U : ((__u64)((130ULL)) == 95ULL ? 44U : ((__u64)((130ULL)) == 99ULL ? 45U : ((__u64)((130ULL)) == 105ULL ? 46U : ((__u64)((130ULL)) == 109ULL ? 47U : ((__u64)((130ULL)) == 112ULL ? 48U : ((__u64)((130ULL)) == 113ULL ? 49U : ((__u64)((130ULL)) == 114ULL ? 50U : ((__u64)((130ULL)) == 115ULL ? 51U : ((__u64)((130ULL)) == 118ULL ? 52U : ((__u64)((130ULL)) == 122ULL ? 53U : ((__u64)((130ULL)) == 124ULL ? 54U : ((__u64)((130ULL)) == 125ULL ? 55U : ((__u64)((130ULL)) == 130ULL ? 56U : ((__u64)((130ULL)) == 148ULL ? 57U : ((__u64)((130ULL)) == 152ULL ? 58U : ((__u64)((130ULL)) == 155ULL ? 59U : ((__u64)((130ULL)) == 158ULL ? 60U : ((__u64)((130ULL)) == 160ULL ? 61U : ((__u64)((130ULL)) == 163ULL ? 62U : ((__u64)((130ULL)) == 173ULL ? 63U : ((__u64)((130ULL)) == 174ULL ? 64U : ((__u64)((130ULL)) == 175ULL ? 65U : ((__u64)((130ULL)) == 181ULL ? 66U : ((__u64)((130ULL)) == 184ULL ? 67U : ((__u64)((130ULL)) == 189ULL ? 68U : ((__u64)((130ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 56U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((148ULL)) == 1ULL ? 0U : ((__u64)((148ULL)) == 2ULL ? 1U : ((__u64)((148ULL)) == 3ULL ? 2U : ((__u64)((148ULL)) == 4ULL ? 3U : ((__u64)((148ULL)) == 5ULL ? 4U : ((__u64)((148ULL)) == 6ULL ? 5U : ((__u64)((148ULL)) == 7ULL ? 6U : ((__u64)((148ULL)) == 8ULL ? 7U : ((__u64)((148ULL)) == 9ULL ? 8U : ((__u64)((148ULL)) == 10ULL ? 9U : ((__u64)((148ULL)) == 11ULL ? 10U : ((__u64)((148ULL)) == 12ULL ? 11U : ((__u64)((148ULL)) == 14ULL ? 12U : ((__u64)((148ULL)) == 15ULL ? 13U : ((__u64)((148ULL)) == 16ULL ? 14U : ((__u64)((148ULL)) == 20ULL ? 15U : ((__u64)((148ULL)) == 21ULL ? 16U : ((__u64)((148ULL)) == 23ULL ? 17U : ((__u64)((148ULL)) == 25ULL ? 18U : ((__u64)((148ULL)) == 26ULL ? 19U : ((__u64)((148ULL)) == 27ULL ? 20U : ((__u64)((148ULL)) == 28ULL ? 21U : ((__u64)((148ULL)) == 32ULL ? 22U : ((__u64)((148ULL)) == 35ULL ? 23U : ((__u64)((148ULL)) == 36ULL ? 24U : ((__u64)((148ULL)) == 37ULL ? 25U : ((__u64)((148ULL)) == 38ULL ? 26U : ((__u64)((148ULL)) == 39ULL ? 27U : ((__u64)((148ULL)) == 43ULL ? 28U : ((__u64)((148ULL)) == 44ULL ? 29U : ((__u64)((148ULL)) == 45ULL ? 30U : ((__u64)((148ULL)) == 46ULL ? 31U : ((__u64)((148ULL)) == 50ULL ? 32U : ((__u64)((148ULL)) == 54ULL ? 33U : ((__u64)((148ULL)) == 58ULL ? 34U : ((__u64)((148ULL)) == 65ULL ? 35U : ((__u64)((148ULL)) == 67ULL ? 36U : ((__u64)((148ULL)) == 68ULL ? 37U : ((__u64)((148ULL)) == 69ULL ? 38U : ((__u64)((148ULL)) == 80ULL ? 39U : ((__u64)((148ULL)) == 85ULL ? 40U : ((__u64)((148ULL)) == 86ULL ? 41U : ((__u64)((148ULL)) == 87ULL ? 42U : ((__u64)((148ULL)) == 88ULL ? 43U : ((__u64)((148ULL)) == 95ULL ? 44U : ((__u64)((148ULL)) == 99ULL ? 45U : ((__u64)((148ULL)) == 105ULL ? 46U : ((__u64)((148ULL)) == 109ULL ? 47U : ((__u64)((148ULL)) == 112ULL ? 48U : ((__u64)((148ULL)) == 113ULL ? 49U : ((__u64)((148ULL)) == 114ULL ? 50U : ((__u64)((148ULL)) == 115ULL ? 51U : ((__u64)((148ULL)) == 118ULL ? 52U : ((__u64)((148ULL)) == 122ULL ? 53U : ((__u64)((148ULL)) == 124ULL ? 54U : ((__u64)((148ULL)) == 125ULL ? 55U : ((__u64)((148ULL)) == 130ULL ? 56U : ((__u64)((148ULL)) == 148ULL ? 57U : ((__u64)((148ULL)) == 152ULL ? 58U : ((__u64)((148ULL)) == 155ULL ? 59U : ((__u64)((148ULL)) == 158ULL ? 60U : ((__u64)((148ULL)) == 160ULL ? 61U : ((__u64)((148ULL)) == 163ULL ? 62U : ((__u64)((148ULL)) == 173ULL ? 63U : ((__u64)((148ULL)) == 174ULL ? 64U : ((__u64)((148ULL)) == 175ULL ? 65U : ((__u64)((148ULL)) == 181ULL ? 66U : ((__u64)((148ULL)) == 184ULL ? 67U : ((__u64)((148ULL)) == 189ULL ? 68U : ((__u64)((148ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 57U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((152ULL)) == 1ULL ? 0U : ((__u64)((152ULL)) == 2ULL ? 1U : ((__u64)((152ULL)) == 3ULL ? 2U : ((__u64)((152ULL)) == 4ULL ? 3U : ((__u64)((152ULL)) == 5ULL ? 4U : ((__u64)((152ULL)) == 6ULL ? 5U : ((__u64)((152ULL)) == 7ULL ? 6U : ((__u64)((152ULL)) == 8ULL ? 7U : ((__u64)((152ULL)) == 9ULL ? 8U : ((__u64)((152ULL)) == 10ULL ? 9U : ((__u64)((152ULL)) == 11ULL ? 10U : ((__u64)((152ULL)) == 12ULL ? 11U : ((__u64)((152ULL)) == 14ULL ? 12U : ((__u64)((152ULL)) == 15ULL ? 13U : ((__u64)((152ULL)) == 16ULL ? 14U : ((__u64)((152ULL)) == 20ULL ? 15U : ((__u64)((152ULL)) == 21ULL ? 16U : ((__u64)((152ULL)) == 23ULL ? 17U : ((__u64)((152ULL)) == 25ULL ? 18U : ((__u64)((152ULL)) == 26ULL ? 19U : ((__u64)((152ULL)) == 27ULL ? 20U : ((__u64)((152ULL)) == 28ULL ? 21U : ((__u64)((152ULL)) == 32ULL ? 22U : ((__u64)((152ULL)) == 35ULL ? 23U : ((__u64)((152ULL)) == 36ULL ? 24U : ((__u64)((152ULL)) == 37ULL ? 25U : ((__u64)((152ULL)) == 38ULL ? 26U : ((__u64)((152ULL)) == 39ULL ? 27U : ((__u64)((152ULL)) == 43ULL ? 28U : ((__u64)((152ULL)) == 44ULL ? 29U : ((__u64)((152ULL)) == 45ULL ? 30U : ((__u64)((152ULL)) == 46ULL ? 31U : ((__u64)((152ULL)) == 50ULL ? 32U : ((__u64)((152ULL)) == 54ULL ? 33U : ((__u64)((152ULL)) == 58ULL ? 34U : ((__u64)((152ULL)) == 65ULL ? 35U : ((__u64)((152ULL)) == 67ULL ? 36U : ((__u64)((152ULL)) == 68ULL ? 37U : ((__u64)((152ULL)) == 69ULL ? 38U : ((__u64)((152ULL)) == 80ULL ? 39U : ((__u64)((152ULL)) == 85ULL ? 40U : ((__u64)((152ULL)) == 86ULL ? 41U : ((__u64)((152ULL)) == 87ULL ? 42U : ((__u64)((152ULL)) == 88ULL ? 43U : ((__u64)((152ULL)) == 95ULL ? 44U : ((__u64)((152ULL)) == 99ULL ? 45U : ((__u64)((152ULL)) == 105ULL ? 46U : ((__u64)((152ULL)) == 109ULL ? 47U : ((__u64)((152ULL)) == 112ULL ? 48U : ((__u64)((152ULL)) == 113ULL ? 49U : ((__u64)((152ULL)) == 114ULL ? 50U : ((__u64)((152ULL)) == 115ULL ? 51U : ((__u64)((152ULL)) == 118ULL ? 52U : ((__u64)((152ULL)) == 122ULL ? 53U : ((__u64)((152ULL)) == 124ULL ? 54U : ((__u64)((152ULL)) == 125ULL ? 55U : ((__u64)((152ULL)) == 130ULL ? 56U : ((__u64)((152ULL)) == 148ULL ? 57U : ((__u64)((152ULL)) == 152ULL ? 58U : ((__u64)((152ULL)) == 155ULL ? 59U : ((__u64)((152ULL)) == 158ULL ? 60U : ((__u64)((152ULL)) == 160ULL ? 61U : ((__u64)((152ULL)) == 163ULL ? 62U : ((__u64)((152ULL)) == 173ULL ? 63U : ((__u64)((152ULL)) == 174ULL ? 64U : ((__u64)((152ULL)) == 175ULL ? 65U : ((__u64)((152ULL)) == 181ULL ? 66U : ((__u64)((152ULL)) == 184ULL ? 67U : ((__u64)((152ULL)) == 189ULL ? 68U : ((__u64)((152ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 58U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((155ULL)) == 1ULL ? 0U : ((__u64)((155ULL)) == 2ULL ? 1U : ((__u64)((155ULL)) == 3ULL ? 2U : ((__u64)((155ULL)) == 4ULL ? 3U : ((__u64)((155ULL)) == 5ULL ? 4U : ((__u64)((155ULL)) == 6ULL ? 5U : ((__u64)((155ULL)) == 7ULL ? 6U : ((__u64)((155ULL)) == 8ULL ? 7U : ((__u64)((155ULL)) == 9ULL ? 8U : ((__u64)((155ULL)) == 10ULL ? 9U : ((__u64)((155ULL)) == 11ULL ? 10U : ((__u64)((155ULL)) == 12ULL ? 11U : ((__u64)((155ULL)) == 14ULL ? 12U : ((__u64)((155ULL)) == 15ULL ? 13U : ((__u64)((155ULL)) == 16ULL ? 14U : ((__u64)((155ULL)) == 20ULL ? 15U : ((__u64)((155ULL)) == 21ULL ? 16U : ((__u64)((155ULL)) == 23ULL ? 17U : ((__u64)((155ULL)) == 25ULL ? 18U : ((__u64)((155ULL)) == 26ULL ? 19U : ((__u64)((155ULL)) == 27ULL ? 20U : ((__u64)((155ULL)) == 28ULL ? 21U : ((__u64)((155ULL)) == 32ULL ? 22U : ((__u64)((155ULL)) == 35ULL ? 23U : ((__u64)((155ULL)) == 36ULL ? 24U : ((__u64)((155ULL)) == 37ULL ? 25U : ((__u64)((155ULL)) == 38ULL ? 26U : ((__u64)((155ULL)) == 39ULL ? 27U : ((__u64)((155ULL)) == 43ULL ? 28U : ((__u64)((155ULL)) == 44ULL ? 29U : ((__u64)((155ULL)) == 45ULL ? 30U : ((__u64)((155ULL)) == 46ULL ? 31U : ((__u64)((155ULL)) == 50ULL ? 32U : ((__u64)((155ULL)) == 54ULL ? 33U : ((__u64)((155ULL)) == 58ULL ? 34U : ((__u64)((155ULL)) == 65ULL ? 35U : ((__u64)((155ULL)) == 67ULL ? 36U : ((__u64)((155ULL)) == 68ULL ? 37U : ((__u64)((155ULL)) == 69ULL ? 38U : ((__u64)((155ULL)) == 80ULL ? 39U : ((__u64)((155ULL)) == 85ULL ? 40U : ((__u64)((155ULL)) == 86ULL ? 41U : ((__u64)((155ULL)) == 87ULL ? 42U : ((__u64)((155ULL)) == 88ULL ? 43U : ((__u64)((155ULL)) == 95ULL ? 44U : ((__u64)((155ULL)) == 99ULL ? 45U : ((__u64)((155ULL)) == 105ULL ? 46U : ((__u64)((155ULL)) == 109ULL ? 47U : ((__u64)((155ULL)) == 112ULL ? 48U : ((__u64)((155ULL)) == 113ULL ? 49U : ((__u64)((155ULL)) == 114ULL ? 50U : ((__u64)((155ULL)) == 115ULL ? 51U : ((__u64)((155ULL)) == 118ULL ? 52U : ((__u64)((155ULL)) == 122ULL ? 53U : ((__u64)((155ULL)) == 124ULL ? 54U : ((__u64)((155ULL)) == 125ULL ? 55U : ((__u64)((155ULL)) == 130ULL ? 56U : ((__u64)((155ULL)) == 148ULL ? 57U : ((__u64)((155ULL)) == 152ULL ? 58U : ((__u64)((155ULL)) == 155ULL ? 59U : ((__u64)((155ULL)) == 158ULL ? 60U : ((__u64)((155ULL)) == 160ULL ? 61U : ((__u64)((155ULL)) == 163ULL ? 62U : ((__u64)((155ULL)) == 173ULL ? 63U : ((__u64)((155ULL)) == 174ULL ? 64U : ((__u64)((155ULL)) == 175ULL ? 65U : ((__u64)((155ULL)) == 181ULL ? 66U : ((__u64)((155ULL)) == 184ULL ? 67U : ((__u64)((155ULL)) == 189ULL ? 68U : ((__u64)((155ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 59U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((158ULL)) == 1ULL ? 0U : ((__u64)((158ULL)) == 2ULL ? 1U : ((__u64)((158ULL)) == 3ULL ? 2U : ((__u64)((158ULL)) == 4ULL ? 3U : ((__u64)((158ULL)) == 5ULL ? 4U : ((__u64)((158ULL)) == 6ULL ? 5U : ((__u64)((158ULL)) == 7ULL ? 6U : ((__u64)((158ULL)) == 8ULL ? 7U : ((__u64)((158ULL)) == 9ULL ? 8U : ((__u64)((158ULL)) == 10ULL ? 9U : ((__u64)((158ULL)) == 11ULL ? 10U : ((__u64)((158ULL)) == 12ULL ? 11U : ((__u64)((158ULL)) == 14ULL ? 12U : ((__u64)((158ULL)) == 15ULL ? 13U : ((__u64)((158ULL)) == 16ULL ? 14U : ((__u64)((158ULL)) == 20ULL ? 15U : ((__u64)((158ULL)) == 21ULL ? 16U : ((__u64)((158ULL)) == 23ULL ? 17U : ((__u64)((158ULL)) == 25ULL ? 18U : ((__u64)((158ULL)) == 26ULL ? 19U : ((__u64)((158ULL)) == 27ULL ? 20U : ((__u64)((158ULL)) == 28ULL ? 21U : ((__u64)((158ULL)) == 32ULL ? 22U : ((__u64)((158ULL)) == 35ULL ? 23U : ((__u64)((158ULL)) == 36ULL ? 24U : ((__u64)((158ULL)) == 37ULL ? 25U : ((__u64)((158ULL)) == 38ULL ? 26U : ((__u64)((158ULL)) == 39ULL ? 27U : ((__u64)((158ULL)) == 43ULL ? 28U : ((__u64)((158ULL)) == 44ULL ? 29U : ((__u64)((158ULL)) == 45ULL ? 30U : ((__u64)((158ULL)) == 46ULL ? 31U : ((__u64)((158ULL)) == 50ULL ? 32U : ((__u64)((158ULL)) == 54ULL ? 33U : ((__u64)((158ULL)) == 58ULL ? 34U : ((__u64)((158ULL)) == 65ULL ? 35U : ((__u64)((158ULL)) == 67ULL ? 36U : ((__u64)((158ULL)) == 68ULL ? 37U : ((__u64)((158ULL)) == 69ULL ? 38U : ((__u64)((158ULL)) == 80ULL ? 39U : ((__u64)((158ULL)) == 85ULL ? 40U : ((__u64)((158ULL)) == 86ULL ? 41U : ((__u64)((158ULL)) == 87ULL ? 42U : ((__u64)((158ULL)) == 88ULL ? 43U : ((__u64)((158ULL)) == 95ULL ? 44U : ((__u64)((158ULL)) == 99ULL ? 45U : ((__u64)((158ULL)) == 105ULL ? 46U : ((__u64)((158ULL)) == 109ULL ? 47U : ((__u64)((158ULL)) == 112ULL ? 48U : ((__u64)((158ULL)) == 113ULL ? 49U : ((__u64)((158ULL)) == 114ULL ? 50U : ((__u64)((158ULL)) == 115ULL ? 51U : ((__u64)((158ULL)) == 118ULL ? 52U : ((__u64)((158ULL)) == 122ULL ? 53U : ((__u64)((158ULL)) == 124ULL ? 54U : ((__u64)((158ULL)) == 125ULL ? 55U : ((__u64)((158ULL)) == 130ULL ? 56U : ((__u64)((158ULL)) == 148ULL ? 57U : ((__u64)((158ULL)) == 152ULL ? 58U : ((__u64)((158ULL)) == 155ULL ? 59U : ((__u64)((158ULL)) == 158ULL ? 60U : ((__u64)((158ULL)) == 160ULL ? 61U : ((__u64)((158ULL)) == 163ULL ? 62U : ((__u64)((158ULL)) == 173ULL ? 63U : ((__u64)((158ULL)) == 174ULL ? 64U : ((__u64)((158ULL)) == 175ULL ? 65U : ((__u64)((158ULL)) == 181ULL ? 66U : ((__u64)((158ULL)) == 184ULL ? 67U : ((__u64)((158ULL)) == 189ULL ? 68U : ((__u64)((158ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 60U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((160ULL)) == 1ULL ? 0U : ((__u64)((160ULL)) == 2ULL ? 1U : ((__u64)((160ULL)) == 3ULL ? 2U : ((__u64)((160ULL)) == 4ULL ? 3U : ((__u64)((160ULL)) == 5ULL ? 4U : ((__u64)((160ULL)) == 6ULL ? 5U : ((__u64)((160ULL)) == 7ULL ? 6U : ((__u64)((160ULL)) == 8ULL ? 7U : ((__u64)((160ULL)) == 9ULL ? 8U : ((__u64)((160ULL)) == 10ULL ? 9U : ((__u64)((160ULL)) == 11ULL ? 10U : ((__u64)((160ULL)) == 12ULL ? 11U : ((__u64)((160ULL)) == 14ULL ? 12U : ((__u64)((160ULL)) == 15ULL ? 13U : ((__u64)((160ULL)) == 16ULL ? 14U : ((__u64)((160ULL)) == 20ULL ? 15U : ((__u64)((160ULL)) == 21ULL ? 16U : ((__u64)((160ULL)) == 23ULL ? 17U : ((__u64)((160ULL)) == 25ULL ? 18U : ((__u64)((160ULL)) == 26ULL ? 19U : ((__u64)((160ULL)) == 27ULL ? 20U : ((__u64)((160ULL)) == 28ULL ? 21U : ((__u64)((160ULL)) == 32ULL ? 22U : ((__u64)((160ULL)) == 35ULL ? 23U : ((__u64)((160ULL)) == 36ULL ? 24U : ((__u64)((160ULL)) == 37ULL ? 25U : ((__u64)((160ULL)) == 38ULL ? 26U : ((__u64)((160ULL)) == 39ULL ? 27U : ((__u64)((160ULL)) == 43ULL ? 28U : ((__u64)((160ULL)) == 44ULL ? 29U : ((__u64)((160ULL)) == 45ULL ? 30U : ((__u64)((160ULL)) == 46ULL ? 31U : ((__u64)((160ULL)) == 50ULL ? 32U : ((__u64)((160ULL)) == 54ULL ? 33U : ((__u64)((160ULL)) == 58ULL ? 34U : ((__u64)((160ULL)) == 65ULL ? 35U : ((__u64)((160ULL)) == 67ULL ? 36U : ((__u64)((160ULL)) == 68ULL ? 37U : ((__u64)((160ULL)) == 69ULL ? 38U : ((__u64)((160ULL)) == 80ULL ? 39U : ((__u64)((160ULL)) == 85ULL ? 40U : ((__u64)((160ULL)) == 86ULL ? 41U : ((__u64)((160ULL)) == 87ULL ? 42U : ((__u64)((160ULL)) == 88ULL ? 43U : ((__u64)((160ULL)) == 95ULL ? 44U : ((__u64)((160ULL)) == 99ULL ? 45U : ((__u64)((160ULL)) == 105ULL ? 46U : ((__u64)((160ULL)) == 109ULL ? 47U : ((__u64)((160ULL)) == 112ULL ? 48U : ((__u64)((160ULL)) == 113ULL ? 49U : ((__u64)((160ULL)) == 114ULL ? 50U : ((__u64)((160ULL)) == 115ULL ? 51U : ((__u64)((160ULL)) == 118ULL ? 52U : ((__u64)((160ULL)) == 122ULL ? 53U : ((__u64)((160ULL)) == 124ULL ? 54U : ((__u64)((160ULL)) == 125ULL ? 55U : ((__u64)((160ULL)) == 130ULL ? 56U : ((__u64)((160ULL)) == 148ULL ? 57U : ((__u64)((160ULL)) == 152ULL ? 58U : ((__u64)((160ULL)) == 155ULL ? 59U : ((__u64)((160ULL)) == 158ULL ? 60U : ((__u64)((160ULL)) == 160ULL ? 61U : ((__u64)((160ULL)) == 163ULL ? 62U : ((__u64)((160ULL)) == 173ULL ? 63U : ((__u64)((160ULL)) == 174ULL ? 64U : ((__u64)((160ULL)) == 175ULL ? 65U : ((__u64)((160ULL)) == 181ULL ? 66U : ((__u64)((160ULL)) == 184ULL ? 67U : ((__u64)((160ULL)) == 189ULL ? 68U : ((__u64)((160ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 61U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((163ULL)) == 1ULL ? 0U : ((__u64)((163ULL)) == 2ULL ? 1U : ((__u64)((163ULL)) == 3ULL ? 2U : ((__u64)((163ULL)) == 4ULL ? 3U : ((__u64)((163ULL)) == 5ULL ? 4U : ((__u64)((163ULL)) == 6ULL ? 5U : ((__u64)((163ULL)) == 7ULL ? 6U : ((__u64)((163ULL)) == 8ULL ? 7U : ((__u64)((163ULL)) == 9ULL ? 8U : ((__u64)((163ULL)) == 10ULL ? 9U : ((__u64)((163ULL)) == 11ULL ? 10U : ((__u64)((163ULL)) == 12ULL ? 11U : ((__u64)((163ULL)) == 14ULL ? 12U : ((__u64)((163ULL)) == 15ULL ? 13U : ((__u64)((163ULL)) == 16ULL ? 14U : ((__u64)((163ULL)) == 20ULL ? 15U : ((__u64)((163ULL)) == 21ULL ? 16U : ((__u64)((163ULL)) == 23ULL ? 17U : ((__u64)((163ULL)) == 25ULL ? 18U : ((__u64)((163ULL)) == 26ULL ? 19U : ((__u64)((163ULL)) == 27ULL ? 20U : ((__u64)((163ULL)) == 28ULL ? 21U : ((__u64)((163ULL)) == 32ULL ? 22U : ((__u64)((163ULL)) == 35ULL ? 23U : ((__u64)((163ULL)) == 36ULL ? 24U : ((__u64)((163ULL)) == 37ULL ? 25U : ((__u64)((163ULL)) == 38ULL ? 26U : ((__u64)((163ULL)) == 39ULL ? 27U : ((__u64)((163ULL)) == 43ULL ? 28U : ((__u64)((163ULL)) == 44ULL ? 29U : ((__u64)((163ULL)) == 45ULL ? 30U : ((__u64)((163ULL)) == 46ULL ? 31U : ((__u64)((163ULL)) == 50ULL ? 32U : ((__u64)((163ULL)) == 54ULL ? 33U : ((__u64)((163ULL)) == 58ULL ? 34U : ((__u64)((163ULL)) == 65ULL ? 35U : ((__u64)((163ULL)) == 67ULL ? 36U : ((__u64)((163ULL)) == 68ULL ? 37U : ((__u64)((163ULL)) == 69ULL ? 38U : ((__u64)((163ULL)) == 80ULL ? 39U : ((__u64)((163ULL)) == 85ULL ? 40U : ((__u64)((163ULL)) == 86ULL ? 41U : ((__u64)((163ULL)) == 87ULL ? 42U : ((__u64)((163ULL)) == 88ULL ? 43U : ((__u64)((163ULL)) == 95ULL ? 44U : ((__u64)((163ULL)) == 99ULL ? 45U : ((__u64)((163ULL)) == 105ULL ? 46U : ((__u64)((163ULL)) == 109ULL ? 47U : ((__u64)((163ULL)) == 112ULL ? 48U : ((__u64)((163ULL)) == 113ULL ? 49U : ((__u64)((163ULL)) == 114ULL ? 50U : ((__u64)((163ULL)) == 115ULL ? 51U : ((__u64)((163ULL)) == 118ULL ? 52U : ((__u64)((163ULL)) == 122ULL ? 53U : ((__u64)((163ULL)) == 124ULL ? 54U : ((__u64)((163ULL)) == 125ULL ? 55U : ((__u64)((163ULL)) == 130ULL ? 56U : ((__u64)((163ULL)) == 148ULL ? 57U : ((__u64)((163ULL)) == 152ULL ? 58U : ((__u64)((163ULL)) == 155ULL ? 59U : ((__u64)((163ULL)) == 158ULL ? 60U : ((__u64)((163ULL)) == 160ULL ? 61U : ((__u64)((163ULL)) == 163ULL ? 62U : ((__u64)((163ULL)) == 173ULL ? 63U : ((__u64)((163ULL)) == 174ULL ? 64U : ((__u64)((163ULL)) == 175ULL ? 65U : ((__u64)((163ULL)) == 181ULL ? 66U : ((__u64)((163ULL)) == 184ULL ? 67U : ((__u64)((163ULL)) == 189ULL ? 68U : ((__u64)((163ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 62U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((173ULL)) == 1ULL ? 0U : ((__u64)((173ULL)) == 2ULL ? 1U : ((__u64)((173ULL)) == 3ULL ? 2U : ((__u64)((173ULL)) == 4ULL ? 3U : ((__u64)((173ULL)) == 5ULL ? 4U : ((__u64)((173ULL)) == 6ULL ? 5U : ((__u64)((173ULL)) == 7ULL ? 6U : ((__u64)((173ULL)) == 8ULL ? 7U : ((__u64)((173ULL)) == 9ULL ? 8U : ((__u64)((173ULL)) == 10ULL ? 9U : ((__u64)((173ULL)) == 11ULL ? 10U : ((__u64)((173ULL)) == 12ULL ? 11U : ((__u64)((173ULL)) == 14ULL ? 12U : ((__u64)((173ULL)) == 15ULL ? 13U : ((__u64)((173ULL)) == 16ULL ? 14U : ((__u64)((173ULL)) == 20ULL ? 15U : ((__u64)((173ULL)) == 21ULL ? 16U : ((__u64)((173ULL)) == 23ULL ? 17U : ((__u64)((173ULL)) == 25ULL ? 18U : ((__u64)((173ULL)) == 26ULL ? 19U : ((__u64)((173ULL)) == 27ULL ? 20U : ((__u64)((173ULL)) == 28ULL ? 21U : ((__u64)((173ULL)) == 32ULL ? 22U : ((__u64)((173ULL)) == 35ULL ? 23U : ((__u64)((173ULL)) == 36ULL ? 24U : ((__u64)((173ULL)) == 37ULL ? 25U : ((__u64)((173ULL)) == 38ULL ? 26U : ((__u64)((173ULL)) == 39ULL ? 27U : ((__u64)((173ULL)) == 43ULL ? 28U : ((__u64)((173ULL)) == 44ULL ? 29U : ((__u64)((173ULL)) == 45ULL ? 30U : ((__u64)((173ULL)) == 46ULL ? 31U : ((__u64)((173ULL)) == 50ULL ? 32U : ((__u64)((173ULL)) == 54ULL ? 33U : ((__u64)((173ULL)) == 58ULL ? 34U : ((__u64)((173ULL)) == 65ULL ? 35U : ((__u64)((173ULL)) == 67ULL ? 36U : ((__u64)((173ULL)) == 68ULL ? 37U : ((__u64)((173ULL)) == 69ULL ? 38U : ((__u64)((173ULL)) == 80ULL ? 39U : ((__u64)((173ULL)) == 85ULL ? 40U : ((__u64)((173ULL)) == 86ULL ? 41U : ((__u64)((173ULL)) == 87ULL ? 42U : ((__u64)((173ULL)) == 88ULL ? 43U : ((__u64)((173ULL)) == 95ULL ? 44U : ((__u64)((173ULL)) == 99ULL ? 45U : ((__u64)((173ULL)) == 105ULL ? 46U : ((__u64)((173ULL)) == 109ULL ? 47U : ((__u64)((173ULL)) == 112ULL ? 48U : ((__u64)((173ULL)) == 113ULL ? 49U : ((__u64)((173ULL)) == 114ULL ? 50U : ((__u64)((173ULL)) == 115ULL ? 51U : ((__u64)((173ULL)) == 118ULL ? 52U : ((__u64)((173ULL)) == 122ULL ? 53U : ((__u64)((173ULL)) == 124ULL ? 54U : ((__u64)((173ULL)) == 125ULL ? 55U : ((__u64)((173ULL)) == 130ULL ? 56U : ((__u64)((173ULL)) == 148ULL ? 57U : ((__u64)((173ULL)) == 152ULL ? 58U : ((__u64)((173ULL)) == 155ULL ? 59U : ((__u64)((173ULL)) == 158ULL ? 60U : ((__u64)((173ULL)) == 160ULL ? 61U : ((__u64)((173ULL)) == 163ULL ? 62U : ((__u64)((173ULL)) == 173ULL ? 63U : ((__u64)((173ULL)) == 174ULL ? 64U : ((__u64)((173ULL)) == 175ULL ? 65U : ((__u64)((173ULL)) == 181ULL ? 66U : ((__u64)((173ULL)) == 184ULL ? 67U : ((__u64)((173ULL)) == 189ULL ? 68U : ((__u64)((173ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 63U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((174ULL)) == 1ULL ? 0U : ((__u64)((174ULL)) == 2ULL ? 1U : ((__u64)((174ULL)) == 3ULL ? 2U : ((__u64)((174ULL)) == 4ULL ? 3U : ((__u64)((174ULL)) == 5ULL ? 4U : ((__u64)((174ULL)) == 6ULL ? 5U : ((__u64)((174ULL)) == 7ULL ? 6U : ((__u64)((174ULL)) == 8ULL ? 7U : ((__u64)((174ULL)) == 9ULL ? 8U : ((__u64)((174ULL)) == 10ULL ? 9U : ((__u64)((174ULL)) == 11ULL ? 10U : ((__u64)((174ULL)) == 12ULL ? 11U : ((__u64)((174ULL)) == 14ULL ? 12U : ((__u64)((174ULL)) == 15ULL ? 13U : ((__u64)((174ULL)) == 16ULL ? 14U : ((__u64)((174ULL)) == 20ULL ? 15U : ((__u64)((174ULL)) == 21ULL ? 16U : ((__u64)((174ULL)) == 23ULL ? 17U : ((__u64)((174ULL)) == 25ULL ? 18U : ((__u64)((174ULL)) == 26ULL ? 19U : ((__u64)((174ULL)) == 27ULL ? 20U : ((__u64)((174ULL)) == 28ULL ? 21U : ((__u64)((174ULL)) == 32ULL ? 22U : ((__u64)((174ULL)) == 35ULL ? 23U : ((__u64)((174ULL)) == 36ULL ? 24U : ((__u64)((174ULL)) == 37ULL ? 25U : ((__u64)((174ULL)) == 38ULL ? 26U : ((__u64)((174ULL)) == 39ULL ? 27U : ((__u64)((174ULL)) == 43ULL ? 28U : ((__u64)((174ULL)) == 44ULL ? 29U : ((__u64)((174ULL)) == 45ULL ? 30U : ((__u64)((174ULL)) == 46ULL ? 31U : ((__u64)((174ULL)) == 50ULL ? 32U : ((__u64)((174ULL)) == 54ULL ? 33U : ((__u64)((174ULL)) == 58ULL ? 34U : ((__u64)((174ULL)) == 65ULL ? 35U : ((__u64)((174ULL)) == 67ULL ? 36U : ((__u64)((174ULL)) == 68ULL ? 37U : ((__u64)((174ULL)) == 69ULL ? 38U : ((__u64)((174ULL)) == 80ULL ? 39U : ((__u64)((174ULL)) == 85ULL ? 40U : ((__u64)((174ULL)) == 86ULL ? 41U : ((__u64)((174ULL)) == 87ULL ? 42U : ((__u64)((174ULL)) == 88ULL ? 43U : ((__u64)((174ULL)) == 95ULL ? 44U : ((__u64)((174ULL)) == 99ULL ? 45U : ((__u64)((174ULL)) == 105ULL ? 46U : ((__u64)((174ULL)) == 109ULL ? 47U : ((__u64)((174ULL)) == 112ULL ? 48U : ((__u64)((174ULL)) == 113ULL ? 49U : ((__u64)((174ULL)) == 114ULL ? 50U : ((__u64)((174ULL)) == 115ULL ? 51U : ((__u64)((174ULL)) == 118ULL ? 52U : ((__u64)((174ULL)) == 122ULL ? 53U : ((__u64)((174ULL)) == 124ULL ? 54U : ((__u64)((174ULL)) == 125ULL ? 55U : ((__u64)((174ULL)) == 130ULL ? 56U : ((__u64)((174ULL)) == 148ULL ? 57U : ((__u64)((174ULL)) == 152ULL ? 58U : ((__u64)((174ULL)) == 155ULL ? 59U : ((__u64)((174ULL)) == 158ULL ? 60U : ((__u64)((174ULL)) == 160ULL ? 61U : ((__u64)((174ULL)) == 163ULL ? 62U : ((__u64)((174ULL)) == 173ULL ? 63U : ((__u64)((174ULL)) == 174ULL ? 64U : ((__u64)((174ULL)) == 175ULL ? 65U : ((__u64)((174ULL)) == 181ULL ? 66U : ((__u64)((174ULL)) == 184ULL ? 67U : ((__u64)((174ULL)) == 189ULL ? 68U : ((__u64)((174ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 64U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((175ULL)) == 1ULL ? 0U : ((__u64)((175ULL)) == 2ULL ? 1U : ((__u64)((175ULL)) == 3ULL ? 2U : ((__u64)((175ULL)) == 4ULL ? 3U : ((__u64)((175ULL)) == 5ULL ? 4U : ((__u64)((175ULL)) == 6ULL ? 5U : ((__u64)((175ULL)) == 7ULL ? 6U : ((__u64)((175ULL)) == 8ULL ? 7U : ((__u64)((175ULL)) == 9ULL ? 8U : ((__u64)((175ULL)) == 10ULL ? 9U : ((__u64)((175ULL)) == 11ULL ? 10U : ((__u64)((175ULL)) == 12ULL ? 11U : ((__u64)((175ULL)) == 14ULL ? 12U : ((__u64)((175ULL)) == 15ULL ? 13U : ((__u64)((175ULL)) == 16ULL ? 14U : ((__u64)((175ULL)) == 20ULL ? 15U : ((__u64)((175ULL)) == 21ULL ? 16U : ((__u64)((175ULL)) == 23ULL ? 17U : ((__u64)((175ULL)) == 25ULL ? 18U : ((__u64)((175ULL)) == 26ULL ? 19U : ((__u64)((175ULL)) == 27ULL ? 20U : ((__u64)((175ULL)) == 28ULL ? 21U : ((__u64)((175ULL)) == 32ULL ? 22U : ((__u64)((175ULL)) == 35ULL ? 23U : ((__u64)((175ULL)) == 36ULL ? 24U : ((__u64)((175ULL)) == 37ULL ? 25U : ((__u64)((175ULL)) == 38ULL ? 26U : ((__u64)((175ULL)) == 39ULL ? 27U : ((__u64)((175ULL)) == 43ULL ? 28U : ((__u64)((175ULL)) == 44ULL ? 29U : ((__u64)((175ULL)) == 45ULL ? 30U : ((__u64)((175ULL)) == 46ULL ? 31U : ((__u64)((175ULL)) == 50ULL ? 32U : ((__u64)((175ULL)) == 54ULL ? 33U : ((__u64)((175ULL)) == 58ULL ? 34U : ((__u64)((175ULL)) == 65ULL ? 35U : ((__u64)((175ULL)) == 67ULL ? 36U : ((__u64)((175ULL)) == 68ULL ? 37U : ((__u64)((175ULL)) == 69ULL ? 38U : ((__u64)((175ULL)) == 80ULL ? 39U : ((__u64)((175ULL)) == 85ULL ? 40U : ((__u64)((175ULL)) == 86ULL ? 41U : ((__u64)((175ULL)) == 87ULL ? 42U : ((__u64)((175ULL)) == 88ULL ? 43U : ((__u64)((175ULL)) == 95ULL ? 44U : ((__u64)((175ULL)) == 99ULL ? 45U : ((__u64)((175ULL)) == 105ULL ? 46U : ((__u64)((175ULL)) == 109ULL ? 47U : ((__u64)((175ULL)) == 112ULL ? 48U : ((__u64)((175ULL)) == 113ULL ? 49U : ((__u64)((175ULL)) == 114ULL ? 50U : ((__u64)((175ULL)) == 115ULL ? 51U : ((__u64)((175ULL)) == 118ULL ? 52U : ((__u64)((175ULL)) == 122ULL ? 53U : ((__u64)((175ULL)) == 124ULL ? 54U : ((__u64)((175ULL)) == 125ULL ? 55U : ((__u64)((175ULL)) == 130ULL ? 56U : ((__u64)((175ULL)) == 148ULL ? 57U : ((__u64)((175ULL)) == 152ULL ? 58U : ((__u64)((175ULL)) == 155ULL ? 59U : ((__u64)((175ULL)) == 158ULL ? 60U : ((__u64)((175ULL)) == 160ULL ? 61U : ((__u64)((175ULL)) == 163ULL ? 62U : ((__u64)((175ULL)) == 173ULL ? 63U : ((__u64)((175ULL)) == 174ULL ? 64U : ((__u64)((175ULL)) == 175ULL ? 65U : ((__u64)((175ULL)) == 181ULL ? 66U : ((__u64)((175ULL)) == 184ULL ? 67U : ((__u64)((175ULL)) == 189ULL ? 68U : ((__u64)((175ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 65U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((181ULL)) == 1ULL ? 0U : ((__u64)((181ULL)) == 2ULL ? 1U : ((__u64)((181ULL)) == 3ULL ? 2U : ((__u64)((181ULL)) == 4ULL ? 3U : ((__u64)((181ULL)) == 5ULL ? 4U : ((__u64)((181ULL)) == 6ULL ? 5U : ((__u64)((181ULL)) == 7ULL ? 6U : ((__u64)((181ULL)) == 8ULL ? 7U : ((__u64)((181ULL)) == 9ULL ? 8U : ((__u64)((181ULL)) == 10ULL ? 9U : ((__u64)((181ULL)) == 11ULL ? 10U : ((__u64)((181ULL)) == 12ULL ? 11U : ((__u64)((181ULL)) == 14ULL ? 12U : ((__u64)((181ULL)) == 15ULL ? 13U : ((__u64)((181ULL)) == 16ULL ? 14U : ((__u64)((181ULL)) == 20ULL ? 15U : ((__u64)((181ULL)) == 21ULL ? 16U : ((__u64)((181ULL)) == 23ULL ? 17U : ((__u64)((181ULL)) == 25ULL ? 18U : ((__u64)((181ULL)) == 26ULL ? 19U : ((__u64)((181ULL)) == 27ULL ? 20U : ((__u64)((181ULL)) == 28ULL ? 21U : ((__u64)((181ULL)) == 32ULL ? 22U : ((__u64)((181ULL)) == 35ULL ? 23U : ((__u64)((181ULL)) == 36ULL ? 24U : ((__u64)((181ULL)) == 37ULL ? 25U : ((__u64)((181ULL)) == 38ULL ? 26U : ((__u64)((181ULL)) == 39ULL ? 27U : ((__u64)((181ULL)) == 43ULL ? 28U : ((__u64)((181ULL)) == 44ULL ? 29U : ((__u64)((181ULL)) == 45ULL ? 30U : ((__u64)((181ULL)) == 46ULL ? 31U : ((__u64)((181ULL)) == 50ULL ? 32U : ((__u64)((181ULL)) == 54ULL ? 33U : ((__u64)((181ULL)) == 58ULL ? 34U : ((__u64)((181ULL)) == 65ULL ? 35U : ((__u64)((181ULL)) == 67ULL ? 36U : ((__u64)((181ULL)) == 68ULL ? 37U : ((__u64)((181ULL)) == 69ULL ? 38U : ((__u64)((181ULL)) == 80ULL ? 39U : ((__u64)((181ULL)) == 85ULL ? 40U : ((__u64)((181ULL)) == 86ULL ? 41U : ((__u64)((181ULL)) == 87ULL ? 42U : ((__u64)((181ULL)) == 88ULL ? 43U : ((__u64)((181ULL)) == 95ULL ? 44U : ((__u64)((181ULL)) == 99ULL ? 45U : ((__u64)((181ULL)) == 105ULL ? 46U : ((__u64)((181ULL)) == 109ULL ? 47U : ((__u64)((181ULL)) == 112ULL ? 48U : ((__u64)((181ULL)) == 113ULL ? 49U : ((__u64)((181ULL)) == 114ULL ? 50U : ((__u64)((181ULL)) == 115ULL ? 51U : ((__u64)((181ULL)) == 118ULL ? 52U : ((__u64)((181ULL)) == 122ULL ? 53U : ((__u64)((181ULL)) == 124ULL ? 54U : ((__u64)((181ULL)) == 125ULL ? 55U : ((__u64)((181ULL)) == 130ULL ? 56U : ((__u64)((181ULL)) == 148ULL ? 57U : ((__u64)((181ULL)) == 152ULL ? 58U : ((__u64)((181ULL)) == 155ULL ? 59U : ((__u64)((181ULL)) == 158ULL ? 60U : ((__u64)((181ULL)) == 160ULL ? 61U : ((__u64)((181ULL)) == 163ULL ? 62U : ((__u64)((181ULL)) == 173ULL ? 63U : ((__u64)((181ULL)) == 174ULL ? 64U : ((__u64)((181ULL)) == 175ULL ? 65U : ((__u64)((181ULL)) == 181ULL ? 66U : ((__u64)((181ULL)) == 184ULL ? 67U : ((__u64)((181ULL)) == 189ULL ? 68U : ((__u64)((181ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 66U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((184ULL)) == 1ULL ? 0U : ((__u64)((184ULL)) == 2ULL ? 1U : ((__u64)((184ULL)) == 3ULL ? 2U : ((__u64)((184ULL)) == 4ULL ? 3U : ((__u64)((184ULL)) == 5ULL ? 4U : ((__u64)((184ULL)) == 6ULL ? 5U : ((__u64)((184ULL)) == 7ULL ? 6U : ((__u64)((184ULL)) == 8ULL ? 7U : ((__u64)((184ULL)) == 9ULL ? 8U : ((__u64)((184ULL)) == 10ULL ? 9U : ((__u64)((184ULL)) == 11ULL ? 10U : ((__u64)((184ULL)) == 12ULL ? 11U : ((__u64)((184ULL)) == 14ULL ? 12U : ((__u64)((184ULL)) == 15ULL ? 13U : ((__u64)((184ULL)) == 16ULL ? 14U : ((__u64)((184ULL)) == 20ULL ? 15U : ((__u64)((184ULL)) == 21ULL ? 16U : ((__u64)((184ULL)) == 23ULL ? 17U : ((__u64)((184ULL)) == 25ULL ? 18U : ((__u64)((184ULL)) == 26ULL ? 19U : ((__u64)((184ULL)) == 27ULL ? 20U : ((__u64)((184ULL)) == 28ULL ? 21U : ((__u64)((184ULL)) == 32ULL ? 22U : ((__u64)((184ULL)) == 35ULL ? 23U : ((__u64)((184ULL)) == 36ULL ? 24U : ((__u64)((184ULL)) == 37ULL ? 25U : ((__u64)((184ULL)) == 38ULL ? 26U : ((__u64)((184ULL)) == 39ULL ? 27U : ((__u64)((184ULL)) == 43ULL ? 28U : ((__u64)((184ULL)) == 44ULL ? 29U : ((__u64)((184ULL)) == 45ULL ? 30U : ((__u64)((184ULL)) == 46ULL ? 31U : ((__u64)((184ULL)) == 50ULL ? 32U : ((__u64)((184ULL)) == 54ULL ? 33U : ((__u64)((184ULL)) == 58ULL ? 34U : ((__u64)((184ULL)) == 65ULL ? 35U : ((__u64)((184ULL)) == 67ULL ? 36U : ((__u64)((184ULL)) == 68ULL ? 37U : ((__u64)((184ULL)) == 69ULL ? 38U : ((__u64)((184ULL)) == 80ULL ? 39U : ((__u64)((184ULL)) == 85ULL ? 40U : ((__u64)((184ULL)) == 86ULL ? 41U : ((__u64)((184ULL)) == 87ULL ? 42U : ((__u64)((184ULL)) == 88ULL ? 43U : ((__u64)((184ULL)) == 95ULL ? 44U : ((__u64)((184ULL)) == 99ULL ? 45U : ((__u64)((184ULL)) == 105ULL ? 46U : ((__u64)((184ULL)) == 109ULL ? 47U : ((__u64)((184ULL)) == 112ULL ? 48U : ((__u64)((184ULL)) == 113ULL ? 49U : ((__u64)((184ULL)) == 114ULL ? 50U : ((__u64)((184ULL)) == 115ULL ? 51U : ((__u64)((184ULL)) == 118ULL ? 52U : ((__u64)((184ULL)) == 122ULL ? 53U : ((__u64)((184ULL)) == 124ULL ? 54U : ((__u64)((184ULL)) == 125ULL ? 55U : ((__u64)((184ULL)) == 130ULL ? 56U : ((__u64)((184ULL)) == 148ULL ? 57U : ((__u64)((184ULL)) == 152ULL ? 58U : ((__u64)((184ULL)) == 155ULL ? 59U : ((__u64)((184ULL)) == 158ULL ? 60U : ((__u64)((184ULL)) == 160ULL ? 61U : ((__u64)((184ULL)) == 163ULL ? 62U : ((__u64)((184ULL)) == 173ULL ? 63U : ((__u64)((184ULL)) == 174ULL ? 64U : ((__u64)((184ULL)) == 175ULL ? 65U : ((__u64)((184ULL)) == 181ULL ? 66U : ((__u64)((184ULL)) == 184ULL ? 67U : ((__u64)((184ULL)) == 189ULL ? 68U : ((__u64)((184ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 67U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((189ULL)) == 1ULL ? 0U : ((__u64)((189ULL)) == 2ULL ? 1U : ((__u64)((189ULL)) == 3ULL ? 2U : ((__u64)((189ULL)) == 4ULL ? 3U : ((__u64)((189ULL)) == 5ULL ? 4U : ((__u64)((189ULL)) == 6ULL ? 5U : ((__u64)((189ULL)) == 7ULL ? 6U : ((__u64)((189ULL)) == 8ULL ? 7U : ((__u64)((189ULL)) == 9ULL ? 8U : ((__u64)((189ULL)) == 10ULL ? 9U : ((__u64)((189ULL)) == 11ULL ? 10U : ((__u64)((189ULL)) == 12ULL ? 11U : ((__u64)((189ULL)) == 14ULL ? 12U : ((__u64)((189ULL)) == 15ULL ? 13U : ((__u64)((189ULL)) == 16ULL ? 14U : ((__u64)((189ULL)) == 20ULL ? 15U : ((__u64)((189ULL)) == 21ULL ? 16U : ((__u64)((189ULL)) == 23ULL ? 17U : ((__u64)((189ULL)) == 25ULL ? 18U : ((__u64)((189ULL)) == 26ULL ? 19U : ((__u64)((189ULL)) == 27ULL ? 20U : ((__u64)((189ULL)) == 28ULL ? 21U : ((__u64)((189ULL)) == 32ULL ? 22U : ((__u64)((189ULL)) == 35ULL ? 23U : ((__u64)((189ULL)) == 36ULL ? 24U : ((__u64)((189ULL)) == 37ULL ? 25U : ((__u64)((189ULL)) == 38ULL ? 26U : ((__u64)((189ULL)) == 39ULL ? 27U : ((__u64)((189ULL)) == 43ULL ? 28U : ((__u64)((189ULL)) == 44ULL ? 29U : ((__u64)((189ULL)) == 45ULL ? 30U : ((__u64)((189ULL)) == 46ULL ? 31U : ((__u64)((189ULL)) == 50ULL ? 32U : ((__u64)((189ULL)) == 54ULL ? 33U : ((__u64)((189ULL)) == 58ULL ? 34U : ((__u64)((189ULL)) == 65ULL ? 35U : ((__u64)((189ULL)) == 67ULL ? 36U : ((__u64)((189ULL)) == 68ULL ? 37U : ((__u64)((189ULL)) == 69ULL ? 38U : ((__u64)((189ULL)) == 80ULL ? 39U : ((__u64)((189ULL)) == 85ULL ? 40U : ((__u64)((189ULL)) == 86ULL ? 41U : ((__u64)((189ULL)) == 87ULL ? 42U : ((__u64)((189ULL)) == 88ULL ? 43U : ((__u64)((189ULL)) == 95ULL ? 44U : ((__u64)((189ULL)) == 99ULL ? 45U : ((__u64)((189ULL)) == 105ULL ? 46U : ((__u64)((189ULL)) == 109ULL ? 47U : ((__u64)((189ULL)) == 112ULL ? 48U : ((__u64)((189ULL)) == 113ULL ? 49U : ((__u64)((189ULL)) == 114ULL ? 50U : ((__u64)((189ULL)) == 115ULL ? 51U : ((__u64)((189ULL)) == 118ULL ? 52U : ((__u64)((189ULL)) == 122ULL ? 53U : ((__u64)((189ULL)) == 124ULL ? 54U : ((__u64)((189ULL)) == 125ULL ? 55U : ((__u64)((189ULL)) == 130ULL ? 56U : ((__u64)((189ULL)) == 148ULL ? 57U : ((__u64)((189ULL)) == 152ULL ? 58U : ((__u64)((189ULL)) == 155ULL ? 59U : ((__u64)((189ULL)) == 158ULL ? 60U : ((__u64)((189ULL)) == 160ULL ? 61U : ((__u64)((189ULL)) == 163ULL ? 62U : ((__u64)((189ULL)) == 173ULL ? 63U : ((__u64)((189ULL)) == 174ULL ? 64U : ((__u64)((189ULL)) == 175ULL ? 65U : ((__u64)((189ULL)) == 181ULL ? 66U : ((__u64)((189ULL)) == 184ULL ? 67U : ((__u64)((189ULL)) == 189ULL ? 68U : ((__u64)((189ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 68U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((193ULL)) == 1ULL ? 0U : ((__u64)((193ULL)) == 2ULL ? 1U : ((__u64)((193ULL)) == 3ULL ? 2U : ((__u64)((193ULL)) == 4ULL ? 3U : ((__u64)((193ULL)) == 5ULL ? 4U : ((__u64)((193ULL)) == 6ULL ? 5U : ((__u64)((193ULL)) == 7ULL ? 6U : ((__u64)((193ULL)) == 8ULL ? 7U : ((__u64)((193ULL)) == 9ULL ? 8U : ((__u64)((193ULL)) == 10ULL ? 9U : ((__u64)((193ULL)) == 11ULL ? 10U : ((__u64)((193ULL)) == 12ULL ? 11U : ((__u64)((193ULL)) == 14ULL ? 12U : ((__u64)((193ULL)) == 15ULL ? 13U : ((__u64)((193ULL)) == 16ULL ? 14U : ((__u64)((193ULL)) == 20ULL ? 15U : ((__u64)((193ULL)) == 21ULL ? 16U : ((__u64)((193ULL)) == 23ULL ? 17U : ((__u64)((193ULL)) == 25ULL ? 18U : ((__u64)((193ULL)) == 26ULL ? 19U : ((__u64)((193ULL)) == 27ULL ? 20U : ((__u64)((193ULL)) == 28ULL ? 21U : ((__u64)((193ULL)) == 32ULL ? 22U : ((__u64)((193ULL)) == 35ULL ? 23U : ((__u64)((193ULL)) == 36ULL ? 24U : ((__u64)((193ULL)) == 37ULL ? 25U : ((__u64)((193ULL)) == 38ULL ? 26U : ((__u64)((193ULL)) == 39ULL ? 27U : ((__u64)((193ULL)) == 43ULL ? 28U : ((__u64)((193ULL)) == 44ULL ? 29U : ((__u64)((193ULL)) == 45ULL ? 30U : ((__u64)((193ULL)) == 46ULL ? 31U : ((__u64)((193ULL)) == 50ULL ? 32U : ((__u64)((193ULL)) == 54ULL ? 33U : ((__u64)((193ULL)) == 58ULL ? 34U : ((__u64)((193ULL)) == 65ULL ? 35U : ((__u64)((193ULL)) == 67ULL ? 36U : ((__u64)((193ULL)) == 68ULL ? 37U : ((__u64)((193ULL)) == 69ULL ? 38U : ((__u64)((193ULL)) == 80ULL ? 39U : ((__u64)((193ULL)) == 85ULL ? 40U : ((__u64)((193ULL)) == 86ULL ? 41U : ((__u64)((193ULL)) == 87ULL ? 42U : ((__u64)((193ULL)) == 88ULL ? 43U : ((__u64)((193ULL)) == 95ULL ? 44U : ((__u64)((193ULL)) == 99ULL ? 45U : ((__u64)((193ULL)) == 105ULL ? 46U : ((__u64)((193ULL)) == 109ULL ? 47U : ((__u64)((193ULL)) == 112ULL ? 48U : ((__u64)((193ULL)) == 113ULL ? 49U : ((__u64)((193ULL)) == 114ULL ? 50U : ((__u64)((193ULL)) == 115ULL ? 51U : ((__u64)((193ULL)) == 118ULL ? 52U : ((__u64)((193ULL)) == 122ULL ? 53U : ((__u64)((193ULL)) == 124ULL ? 54U : ((__u64)((193ULL)) == 125ULL ? 55U : ((__u64)((193ULL)) == 130ULL ? 56U : ((__u64)((193ULL)) == 148ULL ? 57U : ((__u64)((193ULL)) == 152ULL ? 58U : ((__u64)((193ULL)) == 155ULL ? 59U : ((__u64)((193ULL)) == 158ULL ? 60U : ((__u64)((193ULL)) == 160ULL ? 61U : ((__u64)((193ULL)) == 163ULL ? 62U : ((__u64)((193ULL)) == 173ULL ? 63U : ((__u64)((193ULL)) == 174ULL ? 64U : ((__u64)((193ULL)) == 175ULL ? 65U : ((__u64)((193ULL)) == 181ULL ? 66U : ((__u64)((193ULL)) == 184ULL ? 67U : ((__u64)((193ULL)) == 189ULL ? 68U : ((__u64)((193ULL)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) == 69U, "x86 helper dispatch slot drift");
_Static_assert(((__u64)((0U)) == 1ULL ? 0U : ((__u64)((0U)) == 2ULL ? 1U : ((__u64)((0U)) == 3ULL ? 2U : ((__u64)((0U)) == 4ULL ? 3U : ((__u64)((0U)) == 5ULL ? 4U : ((__u64)((0U)) == 6ULL ? 5U : ((__u64)((0U)) == 7ULL ? 6U : ((__u64)((0U)) == 8ULL ? 7U : ((__u64)((0U)) == 9ULL ? 8U : ((__u64)((0U)) == 10ULL ? 9U : ((__u64)((0U)) == 11ULL ? 10U : ((__u64)((0U)) == 12ULL ? 11U : ((__u64)((0U)) == 14ULL ? 12U : ((__u64)((0U)) == 15ULL ? 13U : ((__u64)((0U)) == 16ULL ? 14U : ((__u64)((0U)) == 20ULL ? 15U : ((__u64)((0U)) == 21ULL ? 16U : ((__u64)((0U)) == 23ULL ? 17U : ((__u64)((0U)) == 25ULL ? 18U : ((__u64)((0U)) == 26ULL ? 19U : ((__u64)((0U)) == 27ULL ? 20U : ((__u64)((0U)) == 28ULL ? 21U : ((__u64)((0U)) == 32ULL ? 22U : ((__u64)((0U)) == 35ULL ? 23U : ((__u64)((0U)) == 36ULL ? 24U : ((__u64)((0U)) == 37ULL ? 25U : ((__u64)((0U)) == 38ULL ? 26U : ((__u64)((0U)) == 39ULL ? 27U : ((__u64)((0U)) == 43ULL ? 28U : ((__u64)((0U)) == 44ULL ? 29U : ((__u64)((0U)) == 45ULL ? 30U : ((__u64)((0U)) == 46ULL ? 31U : ((__u64)((0U)) == 50ULL ? 32U : ((__u64)((0U)) == 54ULL ? 33U : ((__u64)((0U)) == 58ULL ? 34U : ((__u64)((0U)) == 65ULL ? 35U : ((__u64)((0U)) == 67ULL ? 36U : ((__u64)((0U)) == 68ULL ? 37U : ((__u64)((0U)) == 69ULL ? 38U : ((__u64)((0U)) == 80ULL ? 39U : ((__u64)((0U)) == 85ULL ? 40U : ((__u64)((0U)) == 86ULL ? 41U : ((__u64)((0U)) == 87ULL ? 42U : ((__u64)((0U)) == 88ULL ? 43U : ((__u64)((0U)) == 95ULL ? 44U : ((__u64)((0U)) == 99ULL ? 45U : ((__u64)((0U)) == 105ULL ? 46U : ((__u64)((0U)) == 109ULL ? 47U : ((__u64)((0U)) == 112ULL ? 48U : ((__u64)((0U)) == 113ULL ? 49U : ((__u64)((0U)) == 114ULL ? 50U : ((__u64)((0U)) == 115ULL ? 51U : ((__u64)((0U)) == 118ULL ? 52U : ((__u64)((0U)) == 122ULL ? 53U : ((__u64)((0U)) == 124ULL ? 54U : ((__u64)((0U)) == 125ULL ? 55U : ((__u64)((0U)) == 130ULL ? 56U : ((__u64)((0U)) == 148ULL ? 57U : ((__u64)((0U)) == 152ULL ? 58U : ((__u64)((0U)) == 155ULL ? 59U : ((__u64)((0U)) == 158ULL ? 60U : ((__u64)((0U)) == 160ULL ? 61U : ((__u64)((0U)) == 163ULL ? 62U : ((__u64)((0U)) == 173ULL ? 63U : ((__u64)((0U)) == 174ULL ? 64U : ((__u64)((0U)) == 175ULL ? 65U : ((__u64)((0U)) == 181ULL ? 66U : ((__u64)((0U)) == 184ULL ? 67U : ((__u64)((0U)) == 189ULL ? 68U : ((__u64)((0U)) == 193ULL ? 69U : 0xffU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) ==
        0xffU,
        "x86 helper dispatch none drift");
# 208 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h" 2
# 243 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
_Static_assert(((__u8)((0U))) == 0U,
        "x86 gpr dispatch cell drift");
_Static_assert(((__u8)((8U))) == 8U,
        "x86 gpr dispatch cell drift");
_Static_assert(((__u8)((15U))) == 15U,
        "x86 gpr dispatch cell drift");



struct x86_sim_stack_value { void *pointer; __u8 tag; };
# 320 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
struct x86_sim_state {
 union x86_sim_gpr rax; __u8 rax_tag; union x86_sim_gpr rcx; __u8 rcx_tag; union x86_sim_gpr rdx; __u8 rdx_tag; union x86_sim_gpr rbx; __u8 rbx_tag; union x86_sim_gpr rsp; __u8 rsp_tag; union x86_sim_gpr rbp; __u8 rbp_tag; union x86_sim_gpr rsi; __u8 rsi_tag; union x86_sim_gpr rdi; __u8 rdi_tag; union x86_sim_gpr r8; __u8 r8_tag; union x86_sim_gpr r9; __u8 r9_tag; union x86_sim_gpr r10; __u8 r10_tag; union x86_sim_gpr r11; __u8 r11_tag; union x86_sim_gpr r12; __u8 r12_tag; union x86_sim_gpr r13; __u8 r13_tag; union x86_sim_gpr r14; __u8 r14_tag; union x86_sim_gpr r15; __u8 r15_tag;
 __u64 native_stack_base;
 __u8 cf;
 __u8 zf;
 __u8 sf;
 __u8 of;
 __u8 pf;
 __u8 af;
 __u64 xmm0_lo;
 __u64 xmm0_hi;
 __u64 ret_addr;
 __u32 call_depth;
 union x86_sim_stack_mem stack_mem;
 struct x86_sim_xdp_abi xdp_abi;
 struct x86_sim_skb_abi skb_abi;
 struct __sk_buff *skb_ctx;
 void *helper_ctx;
 __u8 is_xdp;
 void *helper_abi_base;
 __u8 abi_kind;
};
# 493 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
_Static_assert(2U != 0U &&
               2U != 1U,
               "raw context must not acquire packet ABI pointer tags");
# 1118 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
extern void *bpf_cast_to_kern_ctx(void *) __attribute__((section(".ksyms")));
# 2693 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
struct x86_sim_divmod64 {
    __u64 quotient;
    __u64 remainder;
};




static inline __attribute__((always_inline)) struct x86_sim_divmod64
x86_sim_divmod128(__u64 high, __u64 low, __u64 divisor)
{
    struct x86_sim_divmod64 result = {0, high};

#pragma unroll

    for (int bit = 63; bit >= 0; --bit) {
        __u64 carry = result.remainder >> 63;
        result.remainder = (result.remainder << 1) | ((low >> bit) & 1ULL);
        result.quotient <<= 1;
        if (carry || result.remainder >= divisor) {
            result.remainder -= divisor;
            result.quotient |= 1ULL;
        }
    }
    return result;
}
# 3070 "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
extern void __x86_sim_unsupported_helper(void)
    __attribute__((error("unresolved x86 helper ID")));
# 5 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c" 2


static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
 asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}





extern __s32 bpf_strnstr(const __u8 *, const __u8 *, __u64) __attribute__((section(".ksyms"))) __attribute__((weak));
extern void kprog_missing_function(void) __attribute__((section(".ksyms"))) __attribute__((weak));
#pragma GCC diagnostic push
# 18 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma GCC diagnostic ignored "-Wignored-attributes"
# 18 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 __attribute__((section("kprobe/trusted"), used))
# 18 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma GCC diagnostic pop
int trusted_x86_x86_sim_xdp(void *ctx)
{
 struct x86_sim_skb_abi __x86_sim_abi = {}; struct __sk_buff *__x86_sim_skb_ctx = (struct __sk_buff *)0; __u8 __x86_sim_abi_kind = 2U; __u8 __x86_stack_value_tag_0=0; void *__x86_stack_value_ptr_0=0;; __u8 __x86_sim_is_xdp = 0; void *__x86_sim_helper_ctx = (void *)0; void *__x86_sim_helper_abi_base = (void *)0; union x86_sim_gpr __x86_rax = { .ptr = (0U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rax_tag = 0U; union x86_sim_gpr __x86_rcx = { .ptr = (1U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rcx_tag = 0U; union x86_sim_gpr __x86_rdx = { .ptr = (2U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rdx_tag = 0U; union x86_sim_gpr __x86_rbx = { .ptr = (3U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rbx_tag = 0U; union x86_sim_gpr __x86_rsp = { .ptr = (4U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rsp_tag = 0U; union x86_sim_gpr __x86_rbp = { .ptr = (5U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rbp_tag = 0U; union x86_sim_gpr __x86_rsi = { .ptr = (6U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rsi_tag = 0U; union x86_sim_gpr __x86_rdi = { .ptr = (7U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_rdi_tag = 0U; union x86_sim_gpr __x86_r8 = { .ptr = (8U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r8_tag = 0U; union x86_sim_gpr __x86_r9 = { .ptr = (9U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r9_tag = 0U; union x86_sim_gpr __x86_r10 = { .ptr = (10U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r10_tag = 0U; union x86_sim_gpr __x86_r11 = { .ptr = (11U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r11_tag = 0U; union x86_sim_gpr __x86_r12 = { .ptr = (12U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r12_tag = 0U; union x86_sim_gpr __x86_r13 = { .ptr = (13U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r13_tag = 0U; union x86_sim_gpr __x86_r14 = { .ptr = (14U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r14_tag = 0U; union x86_sim_gpr __x86_r15 = { .ptr = (15U) == 4U ? (void *)0 : (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) }; __u8 __x86_r15_tag = 0U; __u64 __x86_native_stack_base = 0; __u8 __x86_cf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u8 __x86_zf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u8 __x86_sf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u8 __x86_of = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u8 __x86_pf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u8 __x86_af = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __u64 __x86_xmm0_lo = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __u64 __x86_xmm0_hi = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __u64 __x86_sim_ret_addr = 0; volatile union { __u8 b[8U]; __u16 w[(8U + 1U) / 2U]; __u32 d[(8U + 3U) / 4U]; __u64 q[(8U + 7U) / 8U]; } __x86_stack_mem; __x86_native_stack_base = ({ (void)(1); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_sim_helper_ctx = (void *)(ctx); __x86_sim_helper_abi_base = (void *)(ctx); __x86_rdi.ptr = (void *)(ctx); __x86_rdi_tag = 1U;
#pragma kprog_preprocessed_piece
# 22 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
x86_l_0:

 do { if ((((__u32)(0) >> 24) & 0xffU) == 2U && ({ int __x86_read_recovered = 0; if (((__u8)((((3U)) != 0xffU) ? 1 : 0)) && ((3U)) != 4U && ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 0U && ((__u64)(({ __u8 __x86_rd_reg = ((3U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }) + (__u64)((__s64)({ __s64 __kprog_x86_mo_disp = ((((x86_simm(0))))); int __kprog_x86_mo_has_index = ((((__u8)(((((__u8)((((0))) & 0xffU))) != 0xffU) ? 1 : 0)))) ? 1 : 0; __u64 __kprog_x86_mo_result = (__u64)__kprog_x86_mo_disp; if (__kprog_x86_mo_has_index) { __u8 __kprog_x86_mo_scale = ((__u8)(((((((0))))) >> 8) & 0xffU)); __u64 __kprog_x86_mo_index = (((((__u8)(((((__u8)((((0))) & 0xffU))) != 0xffU) ? 1 : 0)) ? ({ __u8 __x86_rd_reg = ((((__u8)((((0))) & 0xffU)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }) : 0))); __kprog_x86_mo_result += (__kprog_x86_mo_scale < 64U ? (__kprog_x86_mo_index << __kprog_x86_mo_scale) : 0); } (__s64)__kprog_x86_mo_result; }))) < 4096U || (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1U))) { if (((0xffU))==4U) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((0)); union x86_sim_gpr __x86_wr_cell = { .ptr = (((((0xffU)))) == 0U ? __x86_rax.ptr : ((((0xffU)))) == 1U ? __x86_rcx.ptr : ((((0xffU)))) == 2U ? __x86_rdx.ptr : ((((0xffU)))) == 3U ? __x86_rbx.ptr : ((((0xffU)))) == 4U ? __x86_rsp.ptr : ((((0xffU)))) == 5U ? __x86_rbp.ptr : ((((0xffU)))) == 6U ? __x86_rsi.ptr : ((((0xffU)))) == 7U ? __x86_rdi.ptr : ((((0xffU)))) == 8U ? __x86_r8.ptr : ((((0xffU)))) == 9U ? __x86_r9.ptr : ((((0xffU)))) == 10U ? __x86_r10.ptr : ((((0xffU)))) == 11U ? __x86_r11.ptr : ((((0xffU)))) == 12U ? __x86_r12.ptr : ((((0xffU)))) == 13U ? __x86_r13.ptr : ((((0xffU)))) == 14U ? __x86_r14.ptr : ((((0xffU)))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((((0xffU)))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((((0xffU)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((0xffU))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); __x86_read_recovered = 1; } __x86_read_recovered; })) break; if ((((__u32)(0) >> 24) & 0xffU) != 1U && (((__u32)(0) >> 24) & 0xffU) != 2U) { do { if ((0U) && ({ int __x86_read_recovered = 0; if (((__u8)((((4U)) != 0xffU) ? 1 : 0)) && ((4U)) != 4U && ({ __u8 __x86_l_tag = 0U; switch ((4U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 0U && ((__u64)(({ __u8 __x86_rd_reg = ((4U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); })) < 4096U || (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1U))) { if (((0xffU))==4U) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((0)); union x86_sim_gpr __x86_wr_cell = { .ptr = (((((0xffU)))) == 0U ? __x86_rax.ptr : ((((0xffU)))) == 1U ? __x86_rcx.ptr : ((((0xffU)))) == 2U ? __x86_rdx.ptr : ((((0xffU)))) == 3U ? __x86_rbx.ptr : ((((0xffU)))) == 4U ? __x86_rsp.ptr : ((((0xffU)))) == 5U ? __x86_rbp.ptr : ((((0xffU)))) == 6U ? __x86_rsi.ptr : ((((0xffU)))) == 7U ? __x86_rdi.ptr : ((((0xffU)))) == 8U ? __x86_r8.ptr : ((((0xffU)))) == 9U ? __x86_r9.ptr : ((((0xffU)))) == 10U ? __x86_r10.ptr : ((((0xffU)))) == 11U ? __x86_r11.ptr : ((((0xffU)))) == 12U ? __x86_r12.ptr : ((((0xffU)))) == 13U ? __x86_r13.ptr : ((((0xffU)))) == 14U ? __x86_r14.ptr : ((((0xffU)))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((((0xffU)))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((((0xffU)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((0xffU))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); __x86_read_recovered = 1; } __x86_read_recovered; })) break; __u8 __x86_l_pp_dir = ((0U) ? 1U : 0U); __u8 __x86_l_pp_flags_width = (((((8U))) == 0U) ? 1U : 0U); __u8 __x86_l_pp_width = (__x86_l_pp_flags_width == 1U) ? 8U : (((8U))); __u64 __x86_l_pp_step = (__u64)((__x86_l_pp_width) == 1U ? 1U : (__x86_l_pp_width) == 2U ? 2U : (__x86_l_pp_width) == 4U ? 4U : 8U); if (__x86_l_pp_dir == 0U) { __u64 __x86_l_pp_value = ({ __u8 __x86_rd_reg = ((((3U)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(-__x86_l_pp_step))); do { do { __u64 __x86_sv_index=(((__u64)((__s64)(long)__x86_rsp.ptr) + (__u64)(8U))),__x86_sv_width=x86_width_effective((__x86_l_pp_width)); do { __u64 __x86_sv_start=(__u64)(0)*8U; if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); do { __s64 __x86_loss_off=(((__s64)(long)__x86_rsp.ptr)); __u8 __x86_loss_width=x86_width_effective((__x86_l_pp_width)); __u64 __x86_loss_value=((__x86_l_pp_value)); do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off) + (__u64)(8U)); if (((__u8)((((x86_width_effective(__x86_loss_width)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (__x86_loss_value); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((__x86_loss_width)); __u64 __x86_stw_narrowed = ((__x86_loss_value)) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); if (__x86_loss_off<((__s64)(long)__x86_rsp.ptr)) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_loss_i=0; __x86_loss_i<8U; ++__x86_loss_i) if (__x86_loss_i<__x86_loss_width && __x86_loss_off+__x86_loss_i<((__s64)(long)__x86_rsp.ptr)) do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off+__x86_loss_i) + (__u64)(8U)); if (((__u8)((((x86_width_effective(1U)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((1U)); __u64 __x86_stw_narrowed = ((({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }))) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); } } while(0); } while(0); } else { __u64 __x86_l_pp_value = ({ __u64 __x86_observed=({ __u64 __x86_str_index = ((__u64)(((__s64)(long)__x86_rsp.ptr)) + (__u64)(8U)); __u64 __x86_str_value; if (((__u8)((((x86_width_effective((__x86_l_pp_width))) == 8U) && (((((__u64)(__x86_str_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_str_value = __x86_stack_mem.q [((__u64)(__x86_str_index) >> 3)]; } else if (x86_width_effective((__x86_l_pp_width)) == 4U && (__x86_str_index & 3U) == 0) { __x86_str_value = __x86_stack_mem.d[__x86_str_index / 4U]; } else if (x86_width_effective((__x86_l_pp_width)) == 2U && (__x86_str_index & 1U) == 0) { __x86_str_value = __x86_stack_mem.w[__x86_str_index / 2U]; } else { volatile __u8 *__x86_str_bytes = __x86_stack_mem.b; __u8 __x86_str_width = x86_width_effective((__x86_l_pp_width)); __x86_str_value = __x86_str_bytes[__x86_str_index]; if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 1]))) << (8U * (__u32)(1))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 2]))) << (8U * (__u32)(2))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 3]))) << (8U * (__u32)(3))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 4]))) << (8U * (__u32)(4))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 5]))) << (8U * (__u32)(5))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 6]))) << (8U * (__u32)(6))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 7]))) << (8U * (__u32)(7))); } __x86_str_value; }); if ((__s64)((__s64)(long)__x86_rsp.ptr)<((__s64)(long)__x86_rsp.ptr)) __x86_observed=x86_apply_width(({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }),x86_width_effective(__x86_l_pp_width)); __x86_observed; }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_pp_step))); do { __s64 __x86_release_old=((__s64)(long)__x86_rsp.ptr - __x86_l_pp_step), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((__x86_l_pp_width)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((__x86_l_pp_value)); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((0xffU))) == 0U ? __x86_rax.ptr : (((0xffU))) == 1U ? __x86_rcx.ptr : (((0xffU))) == 2U ? __x86_rdx.ptr : (((0xffU))) == 3U ? __x86_rbx.ptr : (((0xffU))) == 4U ? __x86_rsp.ptr : (((0xffU))) == 5U ? __x86_rbp.ptr : (((0xffU))) == 6U ? __x86_rsi.ptr : (((0xffU))) == 7U ? __x86_rdi.ptr : (((0xffU))) == 8U ? __x86_r8.ptr : (((0xffU))) == 9U ? __x86_r9.ptr : (((0xffU))) == 10U ? __x86_r10.ptr : (((0xffU))) == 11U ? __x86_r11.ptr : (((0xffU))) == 12U ? __x86_r12.ptr : (((0xffU))) == 13U ? __x86_r13.ptr : (((0xffU))) == 14U ? __x86_r14.ptr : (((0xffU))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((0xffU))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((0xffU))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((0xffU))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((0xffU))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((0xffU))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((0xffU)))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0); } else { __u8 __x86_pp_width = (8U) ? (8U) : 8U; __u64 __x86_pp_value = (((__u32)(0) >> 24) & 0xffU) == 1U ? (__u64)(0) : ({ void *__x86_l_base_ptr = (void *)0; __u8 __x86_l_read_mem_width = x86_width_effective(__x86_pp_width); __s64 __x86_l_disp = (0) ? x86_store_imm_disp((0)) : x86_simm((0)); __x86_l_disp = ((__s64)({ __s64 __kprog_x86_mo_disp = (((__x86_l_disp))); int __kprog_x86_mo_has_index = ((((__u8)(((((__u8)((((0))) & 0xffU))) != 0xffU) ? 1 : 0)))) ? 1 : 0; __u64 __kprog_x86_mo_result = (__u64)__kprog_x86_mo_disp; if (__kprog_x86_mo_has_index) { __u8 __kprog_x86_mo_scale = ((__u8)(((((((0))))) >> 8) & 0xffU)); __u64 __kprog_x86_mo_index = (((((__u8)(((((__u8)((((0))) & 0xffU))) != 0xffU) ? 1 : 0)) ? ({ __u8 __x86_rd_reg = ((((__u8)((((0))) & 0xffU)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }) : 0))); __kprog_x86_mo_result += (__kprog_x86_mo_scale < 64U ? (__kprog_x86_mo_index << __kprog_x86_mo_scale) : 0); } (__s64)__kprog_x86_mo_result; })); if (({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) != 1U) asm volatile("" : "+r"(__x86_l_disp)); if (((__u8)((((3U)) != 0xffU) ? 1 : 0))) __x86_l_base_ptr = (((3U)) == 0U ? __x86_rax.ptr : ((3U)) == 1U ? __x86_rcx.ptr : ((3U)) == 2U ? __x86_rdx.ptr : ((3U)) == 3U ? __x86_rbx.ptr : ((3U)) == 4U ? __x86_rsp.ptr : ((3U)) == 5U ? __x86_rbp.ptr : ((3U)) == 6U ? __x86_rsi.ptr : ((3U)) == 7U ? __x86_rdi.ptr : ((3U)) == 8U ? __x86_r8.ptr : ((3U)) == 9U ? __x86_r9.ptr : ((3U)) == 10U ? __x86_r10.ptr : ((3U)) == 11U ? __x86_r11.ptr : ((3U)) == 12U ? __x86_r12.ptr : ((3U)) == 13U ? __x86_r13.ptr : ((3U)) == 14U ? __x86_r14.ptr : ((3U)) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_l_value; void *__x86_l_addr = ((__u8)((((3U)) != 0xffU) ? 1 : 0)) ? ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_l_base_ptr) + (__u64)(__x86_l_disp))) : (void *)(unsigned long)__x86_l_disp; if ((__x86_sim_is_xdp) && ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 1U) __x86_l_value = ({ __s64 __x86_xdp_off = ((__s64)((__u64)(long)((__x86_l_base_ptr)) - (__u64)(long)__x86_sim_helper_abi_base + (__u64)((__x86_l_disp)))); volatile struct xdp_md *__x86_xdp_ctx = __x86_sim_helper_ctx; __u64 __x86_xdp_value = 0; if ((__x86_l_read_mem_width) == 8U && __x86_xdp_off == 0LL) __x86_xdp_value = (__u64)(long)(void *)(long) __x86_xdp_ctx->data; else if ((__x86_l_read_mem_width) == 8U && __x86_xdp_off == 8LL) __x86_xdp_value = (__u64)(long)(void *)(long) __x86_xdp_ctx->data_end; else if ((__x86_l_read_mem_width) == 8U && __x86_xdp_off == 16) __x86_xdp_value = (__u64)(long)(void *)(long) __x86_xdp_ctx->data_meta; else __x86_xdp_value = ({ __u64 __x86_snr_value; if (__builtin_constant_p((__x86_l_disp))) __x86_snr_value=kprog_x86_mem_load_fixed((((__x86_l_base_ptr))), (((__x86_l_disp))), (((__x86_l_read_mem_width)))); else __x86_snr_value=kprog_x86_mem_load((((__u8 *)((__x86_l_base_ptr))+((__x86_l_disp)))), ((((__x86_l_read_mem_width))))); __x86_snr_value; }); asm volatile("" : "+r"(__x86_xdp_value)); __x86_xdp_value; }); else if (__x86_sim_abi_kind == 1U && ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 1U) __x86_l_value = ({ __u8 __x86_sr_width=(__x86_l_read_mem_width); __s64 __x86_sr_off = ((__s64)((__u64)(long)(((((3U)))) == 0U ? __x86_rax.ptr : ((((3U)))) == 1U ? __x86_rcx.ptr : ((((3U)))) == 2U ? __x86_rdx.ptr : ((((3U)))) == 3U ? __x86_rbx.ptr : ((((3U)))) == 4U ? __x86_rsp.ptr : ((((3U)))) == 5U ? __x86_rbp.ptr : ((((3U)))) == 6U ? __x86_rsi.ptr : ((((3U)))) == 7U ? __x86_rdi.ptr : ((((3U)))) == 8U ? __x86_r8.ptr : ((((3U)))) == 9U ? __x86_r9.ptr : ((((3U)))) == 10U ? __x86_r10.ptr : ((((3U)))) == 11U ? __x86_r11.ptr : ((((3U)))) == 12U ? __x86_r12.ptr : ((((3U)))) == 13U ? __x86_r13.ptr : ((((3U)))) == 14U ? __x86_r14.ptr : ((((3U)))) == 15U ? __x86_r15.ptr : (void *)0) - (__u64)(long)__x86_sim_helper_abi_base + (__u64)((__x86_l_disp)))); struct __sk_buff *__x86_sr_ctx = __x86_sim_helper_ctx; __u64 __x86_sr_value; if (((__x86_sr_off >= 0xd0LL && __x86_sr_off <= 0xd0LL + 8 - (__x86_l_read_mem_width)) || (__x86_sr_off >= 0x50LL && __x86_sr_off <= 0x50LL + 8 - (__x86_l_read_mem_width)))) { __s64 __x86_sr_lane; if (__x86_sr_off >= 0xd0LL) { __x86_sr_value=({ __u64 __x86_sf_value; asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(__x86_sf_value) : "r"(__x86_sr_ctx), "i"(__builtin_offsetof(struct __sk_buff,data)) : "memory"); __x86_sf_value; }); __x86_sr_lane=__x86_sr_off-0xd0LL; } else { __x86_sr_value=({ __u64 __x86_sf_value; asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(__x86_sf_value) : "r"(__x86_sr_ctx), "i"(__builtin_offsetof(struct __sk_buff,data_end)) : "memory"); __x86_sf_value; }); __x86_sr_lane=__x86_sr_off-0x50LL; } if ((__x86_l_read_mem_width) != 8U) __x86_sr_value=x86_apply_width(({ (void)(__x86_sr_value); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) >> (__x86_sr_lane*8), (__x86_l_read_mem_width)); } else if (__x86_sr_off >= 0x30LL && __x86_sr_off <= 0x30LL + 20 - (__x86_l_read_mem_width)) __x86_sr_value=({ __u64 __x86_cbr_value, __x86_cbr_temp; if (__builtin_constant_p(__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))) { if (((__x86_l_read_mem_width)) == 8) __asm__ __volatile__("%0 = *(u8 *)(%2 + %3)\n%1 = *(u8 *)(%2 + %4)\n%1 <<= 8\n%0 |= %1\n%1 = *(u8 *)(%2 + %5)\n%1 <<= 16\n%0 |= %1\n%1 = *(u8 *)(%2 + %6)\n%1 <<= 24\n%0 |= %1\n%1 = *(u8 *)(%2 + %7)\n%1 <<= 32\n%0 |= %1\n%1 = *(u8 *)(%2 + %8)\n%1 <<= 40\n%0 |= %1\n%1 = *(u8 *)(%2 + %9)\n%1 <<= 48\n%0 |= %1\n%1 = *(u8 *)(%2 + %10)\n%1 <<= 56\n%0 |= %1" : "=&r"(__x86_cbr_value), "=&r"(__x86_cbr_temp) : "r"(__x86_sr_ctx), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+0), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+1), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+2), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+3), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+4), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+5), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+6), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+7) : "memory"); else if (((__x86_l_read_mem_width)) == 4) __asm__ __volatile__("%0 = *(u8 *)(%2 + %3)\n%1 = *(u8 *)(%2 + %4)\n%1 <<= 8\n%0 |= %1\n%1 = *(u8 *)(%2 + %5)\n%1 <<= 16\n%0 |= %1\n%1 = *(u8 *)(%2 + %6)\n%1 <<= 24\n%0 |= %1" : "=&r"(__x86_cbr_value), "=&r"(__x86_cbr_temp) : "r"(__x86_sr_ctx), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+0), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+1), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+2), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+3) : "memory"); else if (((__x86_l_read_mem_width)) == 2) __asm__ __volatile__("%0 = *(u8 *)(%2 + %3)\n%1 = *(u8 *)(%2 + %4)\n%1 <<= 8\n%0 |= %1" : "=&r"(__x86_cbr_value), "=&r"(__x86_cbr_temp) : "r"(__x86_sr_ctx), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+0), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+1) : "memory"); else if (((__x86_l_read_mem_width)) == 1) __asm__ __volatile__("%0 = *(u8 *)(%2 + %3)" : "=&r"(__x86_cbr_value), "=&r"(__x86_cbr_temp) : "r"(__x86_sr_ctx), "i"((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))+0) : "memory"); } else __x86_cbr_value=({ volatile const __u8 *__x86_cbr_addr=(volatile const __u8 *)((__x86_sr_ctx))+((__x86_sr_off-0x30LL +(__s64)__builtin_offsetof(struct __sk_buff,cb))); __u64 __x86_cbr_value=__x86_cbr_addr[0]; if ((((__x86_l_read_mem_width))) >= 2U) __x86_cbr_value |= (__u64)__x86_cbr_addr[1] << 8; if ((((__x86_l_read_mem_width))) >= 4U) __x86_cbr_value |= (__u64)__x86_cbr_addr[2] << 16; if ((((__x86_l_read_mem_width))) >= 4U) __x86_cbr_value |= (__u64)__x86_cbr_addr[3] << 24; if ((((__x86_l_read_mem_width))) >= 8U) __x86_cbr_value |= (__u64)__x86_cbr_addr[4] << 32; if ((((__x86_l_read_mem_width))) >= 8U) __x86_cbr_value |= (__u64)__x86_cbr_addr[5] << 40; if ((((__x86_l_read_mem_width))) >= 8U) __x86_cbr_value |= (__u64)__x86_cbr_addr[6] << 48; if ((((__x86_l_read_mem_width))) >= 8U) __x86_cbr_value |= (__u64)__x86_cbr_addr[7] << 56; __x86_cbr_value; }); __x86_cbr_value; }); else if (__x86_sr_off >= (134) && __x86_sr_off <= (134)+(2)-(__x86_sr_width)) __x86_sr_value=x86_apply_width(({ __u64 __x86_sf_value; asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(__x86_sf_value) : "r"(__x86_sr_ctx), "i"(__builtin_offsetof(struct __sk_buff,tc_index)) : "memory"); __x86_sf_value; }) >> ((__x86_sr_off-(134))*8),(__x86_sr_width)); else if (__x86_sr_off >= (144) && __x86_sr_off <= (144)+(4)-(__x86_sr_width)) __x86_sr_value=x86_apply_width(({ __u64 __x86_sf_value; asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(__x86_sf_value) : "r"(__x86_sr_ctx), "i"(__builtin_offsetof(struct __sk_buff,priority)) : "memory"); __x86_sf_value; }) >> ((__x86_sr_off-(144))*8),(__x86_sr_width)); else if (__x86_sr_off >= (168) && __x86_sr_off <= (168)+(4)-(__x86_sr_width)) __x86_sr_value=x86_apply_width(({ __u64 __x86_sf_value; asm volatile("%0 = *(u32 *)(%1 + %2)" : "=r"(__x86_sf_value) : "r"(__x86_sr_ctx), "i"(__builtin_offsetof(struct __sk_buff,mark)) : "memory"); __x86_sf_value; }) >> ((__x86_sr_off-(168))*8),(__x86_sr_width)); else __x86_sr_value=({ __u64 __x86_snr_value; if (__builtin_constant_p((__x86_l_disp))) __x86_snr_value=kprog_x86_mem_load_fixed(((((((3U))) == 0U ? __x86_rax.ptr : (((3U))) == 1U ? __x86_rcx.ptr : (((3U))) == 2U ? __x86_rdx.ptr : (((3U))) == 3U ? __x86_rbx.ptr : (((3U))) == 4U ? __x86_rsp.ptr : (((3U))) == 5U ? __x86_rbp.ptr : (((3U))) == 6U ? __x86_rsi.ptr : (((3U))) == 7U ? __x86_rdi.ptr : (((3U))) == 8U ? __x86_r8.ptr : (((3U))) == 9U ? __x86_r9.ptr : (((3U))) == 10U ? __x86_r10.ptr : (((3U))) == 11U ? __x86_r11.ptr : (((3U))) == 12U ? __x86_r12.ptr : (((3U))) == 13U ? __x86_r13.ptr : (((3U))) == 14U ? __x86_r14.ptr : (((3U))) == 15U ? __x86_r15.ptr : (void *)0))), (((__x86_l_disp))), (((__x86_l_read_mem_width)))); else __x86_snr_value=kprog_x86_mem_load((((__u8 *)(((((3U))) == 0U ? __x86_rax.ptr : (((3U))) == 1U ? __x86_rcx.ptr : (((3U))) == 2U ? __x86_rdx.ptr : (((3U))) == 3U ? __x86_rbx.ptr : (((3U))) == 4U ? __x86_rsp.ptr : (((3U))) == 5U ? __x86_rbp.ptr : (((3U))) == 6U ? __x86_rsi.ptr : (((3U))) == 7U ? __x86_rdi.ptr : (((3U))) == 8U ? __x86_r8.ptr : (((3U))) == 9U ? __x86_r9.ptr : (((3U))) == 10U ? __x86_r10.ptr : (((3U))) == 11U ? __x86_r11.ptr : (((3U))) == 12U ? __x86_r12.ptr : (((3U))) == 13U ? __x86_r13.ptr : (((3U))) == 14U ? __x86_r14.ptr : (((3U))) == 15U ? __x86_r15.ptr : (void *)0))+((__x86_l_disp)))), ((((__x86_l_read_mem_width))))); __x86_snr_value; }); __x86_sr_value; }); else switch (({ __u8 __kprog_x86_md_src; if ((((3U)) == 4U)) __kprog_x86_md_src = 0U; else if ((({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })) == 1U && ((__x86_l_read_mem_width)) == 8U) __kprog_x86_md_src = 1U; else __kprog_x86_md_src = 2U; __kprog_x86_md_src; })) { case 0U: __x86_l_value = ({ __u64 __x86_observed=({ __u64 __x86_str_index = ((__u64)(((__s64)(long)__x86_l_base_ptr + __x86_l_disp)) + (__u64)(8U)); __u64 __x86_str_value; if (((__u8)((((x86_width_effective((__x86_l_read_mem_width))) == 8U) && (((((__u64)(__x86_str_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_str_value = __x86_stack_mem.q [((__u64)(__x86_str_index) >> 3)]; } else if (x86_width_effective((__x86_l_read_mem_width)) == 4U && (__x86_str_index & 3U) == 0) { __x86_str_value = __x86_stack_mem.d[__x86_str_index / 4U]; } else if (x86_width_effective((__x86_l_read_mem_width)) == 2U && (__x86_str_index & 1U) == 0) { __x86_str_value = __x86_stack_mem.w[__x86_str_index / 2U]; } else { volatile __u8 *__x86_str_bytes = __x86_stack_mem.b; __u8 __x86_str_width = x86_width_effective((__x86_l_read_mem_width)); __x86_str_value = __x86_str_bytes[__x86_str_index]; if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 1]))) << (8U * (__u32)(1))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 2]))) << (8U * (__u32)(2))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 3]))) << (8U * (__u32)(3))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 4]))) << (8U * (__u32)(4))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 5]))) << (8U * (__u32)(5))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 6]))) << (8U * (__u32)(6))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 7]))) << (8U * (__u32)(7))); } __x86_str_value; }); if ((__s64)((__s64)(long)__x86_l_base_ptr + __x86_l_disp)<((__s64)(long)__x86_rsp.ptr)) __x86_observed=x86_apply_width(({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }),x86_width_effective(__x86_l_read_mem_width)); __x86_observed; }); break; case 1U: if (((__u8)(((0)) & 0xffU)) == 0xffU) __x86_l_value = kprog_x86_mem_load_fixed((__x86_l_base_ptr), ((0) ? x86_store_imm_disp((0)) : x86_simm((0))), (__x86_l_read_mem_width)); else __x86_l_value = (__u64)(long)(*(void * volatile *)(__x86_l_addr)); break; default: if (((__u8)(((0)) & 0xffU)) == 0xffU) __x86_l_value = kprog_x86_mem_load_fixed((__x86_l_base_ptr), ((0) ? x86_store_imm_disp((0)) : x86_simm((0))), (__x86_l_read_mem_width)); else __x86_l_value = ({ __u64 __x86_alias_observed=kprog_x86_mem_load(((((__u8 *)(unsigned long)((__u64)(unsigned long)(((__x86_l_base_ptr))) + (__u64)(((__x86_l_disp))))))), ((((__x86_l_read_mem_width))))); if ((({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==4U && ({ __u64 __x86_alias_delta=(__u64)(long)(((__u8 *)(unsigned long)((__u64)(unsigned long)((__x86_l_base_ptr)) + (__u64)((__x86_l_disp)))))-(__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_alias_delta)); (__s64)__x86_alias_delta; })<((__s64)(long)__x86_rsp.ptr)) __x86_alias_observed=x86_apply_width(({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }),x86_width_effective(__x86_l_read_mem_width)); __x86_alias_observed; }); break; } __x86_l_value; }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(-(__u64)((__x86_pp_width) == 1U ? 1U : (__x86_pp_width) == 2U ? 2U : (__x86_pp_width) == 4U ? 4U : 8U)))); do { do { __u64 __x86_sv_index=(((__u64)((__s64)(long)__x86_rsp.ptr) + (__u64)(8U))),__x86_sv_width=x86_width_effective((__x86_pp_width)); do { __u64 __x86_sv_start=(__u64)(0)*8U; if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); do { __s64 __x86_loss_off=(((__s64)(long)__x86_rsp.ptr)); __u8 __x86_loss_width=x86_width_effective((__x86_pp_width)); __u64 __x86_loss_value=((__x86_pp_value)); do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off) + (__u64)(8U)); if (((__u8)((((x86_width_effective(__x86_loss_width)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (__x86_loss_value); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((__x86_loss_width)); __u64 __x86_stw_narrowed = ((__x86_loss_value)) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); if (__x86_loss_off<((__s64)(long)__x86_rsp.ptr)) {
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 24 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_loss_i=0; __x86_loss_i<8U; ++__x86_loss_i) if (__x86_loss_i<__x86_loss_width && __x86_loss_off+__x86_loss_i<((__s64)(long)__x86_rsp.ptr)) do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off+__x86_loss_i) + (__u64)(8U)); if (((__u8)((((x86_width_effective(1U)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((1U)); __u64 __x86_stw_narrowed = ((({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }))) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); } } while(0); } while(0); } } while (0);
x86_l_1:

 do { __u8 __x86_l_width = x86_width_effective((4U)); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (((__u8)(((0U) >> 8) & 0xffU))); __u64 __x86_wr_next = (((7ULL))); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((3U))) == 0U ? __x86_rax.ptr : (((3U))) == 1U ? __x86_rcx.ptr : (((3U))) == 2U ? __x86_rdx.ptr : (((3U))) == 3U ? __x86_rbx.ptr : (((3U))) == 4U ? __x86_rsp.ptr : (((3U))) == 5U ? __x86_rbp.ptr : (((3U))) == 6U ? __x86_rsi.ptr : (((3U))) == 7U ? __x86_rdi.ptr : (((3U))) == 8U ? __x86_r8.ptr : (((3U))) == 9U ? __x86_r9.ptr : (((3U))) == 10U ? __x86_r10.ptr : (((3U))) == 11U ? __x86_r11.ptr : (((3U))) == 12U ? __x86_r12.ptr : (((3U))) == 13U ? __x86_r13.ptr : (((3U))) == 14U ? __x86_r14.ptr : (((3U))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((3U))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((3U))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((3U)))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 27 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 27 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } while (0);
x86_l_6:
 do {
     __u64 __kf_left = (__u64)(long)&bpf_strnstr;
     __u64 __kf_right = 0ULL;
     __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, 8U);
     do { __u8 __x86_sub_width = x86_width_effective(8U); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (__kf_left) & __x86_sub_mask; __u64 __x86_sub_b = (__kf_right) & __x86_sub_mask; __u64 __x86_sub_r = (__kf_value) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0);
 } while (0);
x86_l_e:

 do { if (((__u8)(((((0x1d))) <= (((0xe)))) ? 1 : 0))) { do { if (!(((((4U)))) == 10U ? (__x86_pf) : ((((4U)))) == 11U ? !(__x86_pf) : ((((((4U))))) == 0U ? ((__x86_of)) : (((((4U))))) == 1U ? (!((__x86_of))) : (((((4U))))) == 2U ? ((__x86_cf)) : (((((4U))))) == 3U ? (!((__x86_cf))) : (((((4U))))) == 4U ? ((__x86_zf)) : (((((4U))))) == 5U ? (!((__x86_zf))) : (((((4U))))) == 6U ? (((__x86_cf)) || ((__x86_zf))) : (((((4U))))) == 7U ? ((!((__x86_cf))) && (!((__x86_zf)))) : (((((4U))))) == 8U ? ((__x86_sf)) : (((((4U))))) == 9U ? (!((__x86_sf))) : (((((4U))))) == 12U ? (((__x86_sf)) != ((__x86_of))) : (((((4U))))) == 13U ? (((__x86_sf)) == ((__x86_of))) : (((((4U))))) == 14U ? (((__x86_zf)) || (((__x86_sf)) != ((__x86_of)))) : (((((4U))))) == 15U ? ((!((__x86_zf))) && (((__x86_sf)) == ((__x86_of)))) : 0))) { goto __x86_sim_jcc_fallthrough_37; } goto x86_l_1d; __x86_sim_jcc_fallthrough_37: ; } while (0); } else if (((((4U))) == 10U ? (__x86_pf) : (((4U))) == 11U ? !(__x86_pf) : (((((4U)))) == 0U ? ((__x86_of)) : ((((4U)))) == 1U ? (!((__x86_of))) : ((((4U)))) == 2U ? ((__x86_cf)) : ((((4U)))) == 3U ? (!((__x86_cf))) : ((((4U)))) == 4U ? ((__x86_zf)) : ((((4U)))) == 5U ? (!((__x86_zf))) : ((((4U)))) == 6U ? (((__x86_cf)) || ((__x86_zf))) : ((((4U)))) == 7U ? ((!((__x86_cf))) && (!((__x86_zf)))) : ((((4U)))) == 8U ? ((__x86_sf)) : ((((4U)))) == 9U ? (!((__x86_sf))) : ((((4U)))) == 12U ? (((__x86_sf)) != ((__x86_of))) : ((((4U)))) == 13U ? (((__x86_sf)) == ((__x86_of))) : ((((4U)))) == 14U ? (((__x86_zf)) || (((__x86_sf)) != ((__x86_of)))) : ((((4U)))) == 15U ? ((!((__x86_zf))) && (((__x86_sf)) == ((__x86_of)))) : 0))) { do { (void)(((0xe))); (void)(((0x1d))); goto x86_l_1d; } while (0); } asm volatile("" ::: "memory"); } while (0);
x86_l_10:

 do { __u8 __x86_l_width = x86_width_effective(4U); __u32 __x86_l_aux = (2U); __u8 __x86_l_alu = ((__u8)((__x86_l_aux) & 0xffU)); __u8 __x86_l_dst_shift = ((__u8)(((__x86_l_aux) >> 8) & 0xffU)); __u8 __x86_l_src_shift = ((__u8)(((__x86_l_aux) >> 16) & 0xffU)); __u64 __x86_l_lhs = 0, __x86_l_rhs = 0; if (!(__x86_l_alu == 2U && (7U) == (7U) && __x86_l_dst_shift == __x86_l_src_shift)) { __x86_l_lhs = ({ __u8 __x86_rd_reg = ((7U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_dst_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_l_rhs = ({ __u8 __x86_rd_reg = ((7U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_src_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } __u64 __x86_l_result; if (((__x86_l_alu) == 12U)) { __u8 __x86_l_borrow = __x86_cf; __x86_l_result = (((__x86_l_lhs) - (__x86_l_rhs)) - (!!(__x86_l_borrow))); do { __u8 __x86_sbb_width = x86_width_effective(__x86_l_width); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = (__x86_l_lhs) & __x86_sbb_mask; __u64 __x86_sbb_b = (__x86_l_rhs) & __x86_sbb_mask; __u64 __x86_sbb_r = (__x86_l_result) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((__x86_l_borrow))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else if (((__x86_l_alu) == 15U)) { __u8 __x86_l_carry = __x86_cf; __x86_l_result = (((__x86_l_lhs) + (__x86_l_rhs)) + (!!(__x86_l_carry))); do { __u8 __x86_adc_width = x86_width_effective(__x86_l_width); __u64 __x86_adc_mask = x86_width_mask(__x86_adc_width); __u64 __x86_adc_a = (__x86_l_lhs) & __x86_adc_mask; __u64 __x86_adc_b = (__x86_l_rhs) & __x86_adc_mask; __u64 __x86_adc_r = (__x86_l_result) & __x86_adc_mask; __u64 __x86_adc_sign = x86_width_sign_mask(__x86_adc_width); do { (__x86_cf) = (((__x86_adc_r) < (__x86_adc_a)) || ((!!((__x86_l_carry))) && ((__x86_adc_r) == (__x86_adc_a)))); (__x86_zf) = ((__x86_adc_r) == 0); (__x86_sf) = (((__x86_adc_r) & (__x86_adc_sign)) != 0); (__x86_of) = (((~((__x86_adc_a) ^ (__x86_adc_b))) & (((__x86_adc_a) ^ (__x86_adc_r)) & (__x86_adc_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_adc_r) ^ ((__x86_adc_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_adc_a) ^ (__x86_adc_b) ^ (__x86_adc_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else { __x86_l_result = x86_alu_result(__x86_l_lhs, __x86_l_rhs, __x86_l_alu, __x86_l_width); do { __u8 __x86_l_old_cf = __x86_cf; switch (( (((__u8)(((__x86_l_alu)))) == 0U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 15U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 10U) ? 1U : ( (((__u8)(((__x86_l_alu)))) == 13U) ? 2U : ( (((__u8)(((__x86_l_alu)))) == 1U) ? 3U : ( (((__u8)(((__x86_l_alu)))) == 12U) ? 4U : ( (((__u8)(((__x86_l_alu)))) == 14U) ? 5U : ( (((__u8)(((__x86_l_alu)))) == 11U) ? 6U : ( (((__u8)(((__x86_l_alu)))) == 5U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 6U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 7U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 8U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 9U) ? 8U : 9U)))))))))))))) { case 0U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = ((__x86_l_rhs)) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); break; case 1U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = (1) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 2U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = (1) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 3U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_rhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 4U: do { __u8 __x86_sbb_width = x86_width_effective((__x86_l_width)); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = ((__x86_l_lhs)) & __x86_sbb_mask; __u64 __x86_sbb_b = ((__x86_l_rhs)) & __x86_sbb_mask; __u64 __x86_sbb_r = ((__x86_l_result)) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((0))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); break; case 5U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (0) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 6U: do { (void)0; } while (0); break; case 7U: do { __u8 __x86_sh_raw_width = ((__x86_l_width)); __u8 __x86_sh_width = x86_width_effective(__x86_sh_raw_width); __u32 __x86_sh_bits = x86_width_bits(__x86_sh_width); __u64 __x86_sh_mask = x86_width_mask(__x86_sh_width); __u64 __x86_sh_a = ((__x86_l_lhs)) & __x86_sh_mask; __u64 __x86_sh_r = ((__x86_l_result)) & __x86_sh_mask; __u8 __x86_sh_count = x86_shift_count(((__x86_l_rhs)), __x86_sh_width); __u64 __x86_sh_sign = 1ULL << (__x86_sh_bits - 1); __u8 __x86_sh_alu = ((__x86_l_alu)); do { if ((__x86_sh_count) != 0) { if ((__x86_sh_alu) == 8U) { (__x86_cf) = (__x86_sh_r) & 1; if ((__x86_sh_count) == 1) (__x86_of) = (((__x86_sh_r) & (__x86_sh_sign)) != 0) ^ (__x86_cf); } else { (__x86_zf) = (__x86_sh_r) == 0; (__x86_sf) = ((__x86_sh_r) & (__x86_sh_sign)) != 0; if ((__x86_sh_alu) == 5U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_bits) - (__x86_sh_count))) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = (__x86_sf) ^ (__x86_cf); } else if ((__x86_sh_alu) == 6U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = ((__x86_sh_a) & (__x86_sh_sign)) != 0; } else { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : ((__x86_sh_a) & (__x86_sh_sign)) != 0; if ((__x86_sh_count) == 1) (__x86_of) = 0; } } } } while (0); if (__x86_sh_count != 0 && (__x86_sh_alu == 5U || __x86_sh_alu == 6U || __x86_sh_alu == 7U)) __x86_pf = ((38505U >> (((__x86_sh_r) ^ ((__x86_sh_r) >> 4U)) & 15U)) & 1U); } while (0); break; case 8U: do { __u8 __x86_imul_width = x86_width_effective((__x86_l_width)); __u64 __x86_imul_a_abs = x86_signed_abs_width(((__x86_l_lhs)), __x86_imul_width); __u64 __x86_imul_b_abs = x86_signed_abs_width(((__x86_l_rhs)), __x86_imul_width); __u64 __x86_imul_sign = 1ULL << (x86_width_bits(__x86_imul_width) - 1); __u64 __x86_imul_limit = ((((__x86_l_lhs)) ^ ((__x86_l_rhs))) & __x86_imul_sign) ? __x86_imul_sign : __x86_imul_sign - 1; do { __u8 __kprog_imul_overflow = ((__x86_imul_a_abs) != 0 && (__x86_imul_b_abs) > (__x86_imul_limit) / (__x86_imul_a_abs)); (__x86_cf) = __kprog_imul_overflow; (__x86_of) = __kprog_imul_overflow; } while (0); } while (0); break; default: do { __u8 __x86_fl_width = x86_width_effective((__x86_l_width)); __u64 __x86_fl_value = x86_apply_width(((__x86_l_result)), __x86_fl_width); __u32 __x86_fl_bits = x86_width_bits(__x86_fl_width); do { (__x86_cf) = 0; (__x86_zf) = __x86_fl_value == 0; (__x86_sf) = (__x86_fl_value >> (__x86_fl_bits - 1)) & 1; (__x86_of) = 0; } while (0); __x86_pf = ((38505U >> (((__x86_fl_value) ^ ((__x86_fl_value) >> 4U)) & 15U)) & 1U); } while (0); break; } } while (0); if ((7U)==4U && __x86_l_width==8U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = (0U); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && (((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U) && ({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((7U) == 0U ? __x86_rax.ptr : (7U) == 1U ? __x86_rcx.ptr : (7U) == 2U ? __x86_rdx.ptr : (7U) == 3U ? __x86_rbx.ptr : (7U) == 4U ? __x86_rsp.ptr : (7U) == 5U ? __x86_rbp.ptr : (7U) == 6U ? __x86_rsi.ptr : (7U) == 7U ? __x86_rdi.ptr : (7U) == 8U ? __x86_r8.ptr : (7U) == 9U ? __x86_r9.ptr : (7U) == 10U ? __x86_r10.ptr : (7U) == 11U ? __x86_r11.ptr : (7U) == 12U ? __x86_r12.ptr : (7U) == 13U ? __x86_r13.ptr : (7U) == 14U ? __x86_r14.ptr : (7U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && __x86_l_alu==0U && ({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((7U) == 0U ? __x86_rax.ptr : (7U) == 1U ? __x86_rcx.ptr : (7U) == 2U ? __x86_rdx.ptr : (7U) == 3U ? __x86_rbx.ptr : (7U) == 4U ? __x86_rsp.ptr : (7U) == 5U ? __x86_rbp.ptr : (7U) == 6U ? __x86_rsi.ptr : (7U) == 7U ? __x86_rdi.ptr : (7U) == 8U ? __x86_r8.ptr : (7U) == 9U ? __x86_r9.ptr : (7U) == 10U ? __x86_r10.ptr : (7U) == 11U ? __x86_r11.ptr : (7U) == 12U ? __x86_r12.ptr : (7U) == 13U ? __x86_r13.ptr : (7U) == 14U ? __x86_r14.ptr : (7U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_lhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 40 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_12:

 do { __u8 __x86_l_width = x86_width_effective(4U); __u32 __x86_l_aux = (2U); __u8 __x86_l_alu = ((__u8)((__x86_l_aux) & 0xffU)); __u8 __x86_l_dst_shift = ((__u8)(((__x86_l_aux) >> 8) & 0xffU)); __u8 __x86_l_src_shift = ((__u8)(((__x86_l_aux) >> 16) & 0xffU)); __u64 __x86_l_lhs = 0, __x86_l_rhs = 0; if (!(__x86_l_alu == 2U && (6U) == (6U) && __x86_l_dst_shift == __x86_l_src_shift)) { __x86_l_lhs = ({ __u8 __x86_rd_reg = ((6U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_dst_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_l_rhs = ({ __u8 __x86_rd_reg = ((6U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_src_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } __u64 __x86_l_result; if (((__x86_l_alu) == 12U)) { __u8 __x86_l_borrow = __x86_cf; __x86_l_result = (((__x86_l_lhs) - (__x86_l_rhs)) - (!!(__x86_l_borrow))); do { __u8 __x86_sbb_width = x86_width_effective(__x86_l_width); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = (__x86_l_lhs) & __x86_sbb_mask; __u64 __x86_sbb_b = (__x86_l_rhs) & __x86_sbb_mask; __u64 __x86_sbb_r = (__x86_l_result) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((__x86_l_borrow))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((6U)) == 0U ? __x86_rax.ptr : ((6U)) == 1U ? __x86_rcx.ptr : ((6U)) == 2U ? __x86_rdx.ptr : ((6U)) == 3U ? __x86_rbx.ptr : ((6U)) == 4U ? __x86_rsp.ptr : ((6U)) == 5U ? __x86_rbp.ptr : ((6U)) == 6U ? __x86_rsi.ptr : ((6U)) == 7U ? __x86_rdi.ptr : ((6U)) == 8U ? __x86_r8.ptr : ((6U)) == 9U ? __x86_r9.ptr : ((6U)) == 10U ? __x86_r10.ptr : ((6U)) == 11U ? __x86_r11.ptr : ((6U)) == 12U ? __x86_r12.ptr : ((6U)) == 13U ? __x86_r13.ptr : ((6U)) == 14U ? __x86_r14.ptr : ((6U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((6U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else if (((__x86_l_alu) == 15U)) { __u8 __x86_l_carry = __x86_cf; __x86_l_result = (((__x86_l_lhs) + (__x86_l_rhs)) + (!!(__x86_l_carry))); do { __u8 __x86_adc_width = x86_width_effective(__x86_l_width); __u64 __x86_adc_mask = x86_width_mask(__x86_adc_width); __u64 __x86_adc_a = (__x86_l_lhs) & __x86_adc_mask; __u64 __x86_adc_b = (__x86_l_rhs) & __x86_adc_mask; __u64 __x86_adc_r = (__x86_l_result) & __x86_adc_mask; __u64 __x86_adc_sign = x86_width_sign_mask(__x86_adc_width); do { (__x86_cf) = (((__x86_adc_r) < (__x86_adc_a)) || ((!!((__x86_l_carry))) && ((__x86_adc_r) == (__x86_adc_a)))); (__x86_zf) = ((__x86_adc_r) == 0); (__x86_sf) = (((__x86_adc_r) & (__x86_adc_sign)) != 0); (__x86_of) = (((~((__x86_adc_a) ^ (__x86_adc_b))) & (((__x86_adc_a) ^ (__x86_adc_r)) & (__x86_adc_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_adc_r) ^ ((__x86_adc_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_adc_a) ^ (__x86_adc_b) ^ (__x86_adc_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((6U)) == 0U ? __x86_rax.ptr : ((6U)) == 1U ? __x86_rcx.ptr : ((6U)) == 2U ? __x86_rdx.ptr : ((6U)) == 3U ? __x86_rbx.ptr : ((6U)) == 4U ? __x86_rsp.ptr : ((6U)) == 5U ? __x86_rbp.ptr : ((6U)) == 6U ? __x86_rsi.ptr : ((6U)) == 7U ? __x86_rdi.ptr : ((6U)) == 8U ? __x86_r8.ptr : ((6U)) == 9U ? __x86_r9.ptr : ((6U)) == 10U ? __x86_r10.ptr : ((6U)) == 11U ? __x86_r11.ptr : ((6U)) == 12U ? __x86_r12.ptr : ((6U)) == 13U ? __x86_r13.ptr : ((6U)) == 14U ? __x86_r14.ptr : ((6U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((6U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else { __x86_l_result = x86_alu_result(__x86_l_lhs, __x86_l_rhs, __x86_l_alu, __x86_l_width); do { __u8 __x86_l_old_cf = __x86_cf; switch (( (((__u8)(((__x86_l_alu)))) == 0U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 15U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 10U) ? 1U : ( (((__u8)(((__x86_l_alu)))) == 13U) ? 2U : ( (((__u8)(((__x86_l_alu)))) == 1U) ? 3U : ( (((__u8)(((__x86_l_alu)))) == 12U) ? 4U : ( (((__u8)(((__x86_l_alu)))) == 14U) ? 5U : ( (((__u8)(((__x86_l_alu)))) == 11U) ? 6U : ( (((__u8)(((__x86_l_alu)))) == 5U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 6U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 7U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 8U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 9U) ? 8U : 9U)))))))))))))) { case 0U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = ((__x86_l_rhs)) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); break; case 1U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = (1) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 2U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = (1) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 3U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_rhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 4U: do { __u8 __x86_sbb_width = x86_width_effective((__x86_l_width)); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = ((__x86_l_lhs)) & __x86_sbb_mask; __u64 __x86_sbb_b = ((__x86_l_rhs)) & __x86_sbb_mask; __u64 __x86_sbb_r = ((__x86_l_result)) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((0))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); break; case 5U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (0) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 6U: do { (void)0; } while (0); break; case 7U: do { __u8 __x86_sh_raw_width = ((__x86_l_width)); __u8 __x86_sh_width = x86_width_effective(__x86_sh_raw_width); __u32 __x86_sh_bits = x86_width_bits(__x86_sh_width); __u64 __x86_sh_mask = x86_width_mask(__x86_sh_width); __u64 __x86_sh_a = ((__x86_l_lhs)) & __x86_sh_mask; __u64 __x86_sh_r = ((__x86_l_result)) & __x86_sh_mask; __u8 __x86_sh_count = x86_shift_count(((__x86_l_rhs)), __x86_sh_width); __u64 __x86_sh_sign = 1ULL << (__x86_sh_bits - 1); __u8 __x86_sh_alu = ((__x86_l_alu)); do { if ((__x86_sh_count) != 0) { if ((__x86_sh_alu) == 8U) { (__x86_cf) = (__x86_sh_r) & 1; if ((__x86_sh_count) == 1) (__x86_of) = (((__x86_sh_r) & (__x86_sh_sign)) != 0) ^ (__x86_cf); } else { (__x86_zf) = (__x86_sh_r) == 0; (__x86_sf) = ((__x86_sh_r) & (__x86_sh_sign)) != 0; if ((__x86_sh_alu) == 5U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_bits) - (__x86_sh_count))) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = (__x86_sf) ^ (__x86_cf); } else if ((__x86_sh_alu) == 6U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = ((__x86_sh_a) & (__x86_sh_sign)) != 0; } else { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : ((__x86_sh_a) & (__x86_sh_sign)) != 0; if ((__x86_sh_count) == 1) (__x86_of) = 0; } } } } while (0); if (__x86_sh_count != 0 && (__x86_sh_alu == 5U || __x86_sh_alu == 6U || __x86_sh_alu == 7U)) __x86_pf = ((38505U >> (((__x86_sh_r) ^ ((__x86_sh_r) >> 4U)) & 15U)) & 1U); } while (0); break; case 8U: do { __u8 __x86_imul_width = x86_width_effective((__x86_l_width)); __u64 __x86_imul_a_abs = x86_signed_abs_width(((__x86_l_lhs)), __x86_imul_width); __u64 __x86_imul_b_abs = x86_signed_abs_width(((__x86_l_rhs)), __x86_imul_width); __u64 __x86_imul_sign = 1ULL << (x86_width_bits(__x86_imul_width) - 1); __u64 __x86_imul_limit = ((((__x86_l_lhs)) ^ ((__x86_l_rhs))) & __x86_imul_sign) ? __x86_imul_sign : __x86_imul_sign - 1; do { __u8 __kprog_imul_overflow = ((__x86_imul_a_abs) != 0 && (__x86_imul_b_abs) > (__x86_imul_limit) / (__x86_imul_a_abs)); (__x86_cf) = __kprog_imul_overflow; (__x86_of) = __kprog_imul_overflow; } while (0); } while (0); break; default: do { __u8 __x86_fl_width = x86_width_effective((__x86_l_width)); __u64 __x86_fl_value = x86_apply_width(((__x86_l_result)), __x86_fl_width); __u32 __x86_fl_bits = x86_width_bits(__x86_fl_width); do { (__x86_cf) = 0; (__x86_zf) = __x86_fl_value == 0; (__x86_sf) = (__x86_fl_value >> (__x86_fl_bits - 1)) & 1; (__x86_of) = 0; } while (0); __x86_pf = ((38505U >> (((__x86_fl_value) ^ ((__x86_fl_value) >> 4U)) & 15U)) & 1U); } while (0); break; } } while (0); if ((6U)==4U && __x86_l_width==8U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = (0U); switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && (((({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U) && ({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((6U) == 0U ? __x86_rax.ptr : (6U) == 1U ? __x86_rcx.ptr : (6U) == 2U ? __x86_rdx.ptr : (6U) == 3U ? __x86_rbx.ptr : (6U) == 4U ? __x86_rsp.ptr : (6U) == 5U ? __x86_rbp.ptr : (6U) == 6U ? __x86_rsi.ptr : (6U) == 7U ? __x86_rdi.ptr : (6U) == 8U ? __x86_r8.ptr : (6U) == 9U ? __x86_r9.ptr : (6U) == 10U ? __x86_r10.ptr : (6U) == 11U ? __x86_r11.ptr : (6U) == 12U ? __x86_r12.ptr : (6U) == 13U ? __x86_r13.ptr : (6U) == 14U ? __x86_r14.ptr : (6U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && __x86_l_alu==0U && ({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (((({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((6U) == 0U ? __x86_rax.ptr : (6U) == 1U ? __x86_rcx.ptr : (6U) == 2U ? __x86_rdx.ptr : (6U) == 3U ? __x86_rbx.ptr : (6U) == 4U ? __x86_rsp.ptr : (6U) == 5U ? __x86_rbp.ptr : (6U) == 6U ? __x86_rsi.ptr : (6U) == 7U ? __x86_rdi.ptr : (6U) == 8U ? __x86_r8.ptr : (6U) == 9U ? __x86_r9.ptr : (6U) == 10U ? __x86_r10.ptr : (6U) == 11U ? __x86_r11.ptr : (6U) == 12U ? __x86_r12.ptr : (6U) == 13U ? __x86_r13.ptr : (6U) == 14U ? __x86_r14.ptr : (6U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_lhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (6U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((6U)) == 0U ? __x86_rax.ptr : ((6U)) == 1U ? __x86_rcx.ptr : ((6U)) == 2U ? __x86_rdx.ptr : ((6U)) == 3U ? __x86_rbx.ptr : ((6U)) == 4U ? __x86_rsp.ptr : ((6U)) == 5U ? __x86_rbp.ptr : ((6U)) == 6U ? __x86_rsi.ptr : ((6U)) == 7U ? __x86_rdi.ptr : ((6U)) == 8U ? __x86_r8.ptr : ((6U)) == 9U ? __x86_r9.ptr : ((6U)) == 10U ? __x86_r10.ptr : ((6U)) == 11U ? __x86_r11.ptr : ((6U)) == 12U ? __x86_r12.ptr : ((6U)) == 13U ? __x86_r13.ptr : ((6U)) == 14U ? __x86_r14.ptr : ((6U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((6U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((6U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((6U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((6U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 43 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_14:

 do { __u8 __x86_l_width = x86_width_effective(4U); __u32 __x86_l_aux = (2U); __u8 __x86_l_alu = ((__u8)((__x86_l_aux) & 0xffU)); __u8 __x86_l_dst_shift = ((__u8)(((__x86_l_aux) >> 8) & 0xffU)); __u8 __x86_l_src_shift = ((__u8)(((__x86_l_aux) >> 16) & 0xffU)); __u64 __x86_l_lhs = 0, __x86_l_rhs = 0; if (!(__x86_l_alu == 2U && (2U) == (2U) && __x86_l_dst_shift == __x86_l_src_shift)) { __x86_l_lhs = ({ __u8 __x86_rd_reg = ((2U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_dst_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_l_rhs = ({ __u8 __x86_rd_reg = ((2U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_src_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } __u64 __x86_l_result; if (((__x86_l_alu) == 12U)) { __u8 __x86_l_borrow = __x86_cf; __x86_l_result = (((__x86_l_lhs) - (__x86_l_rhs)) - (!!(__x86_l_borrow))); do { __u8 __x86_sbb_width = x86_width_effective(__x86_l_width); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = (__x86_l_lhs) & __x86_sbb_mask; __u64 __x86_sbb_b = (__x86_l_rhs) & __x86_sbb_mask; __u64 __x86_sbb_r = (__x86_l_result) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((__x86_l_borrow))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((2U)) == 0U ? __x86_rax.ptr : ((2U)) == 1U ? __x86_rcx.ptr : ((2U)) == 2U ? __x86_rdx.ptr : ((2U)) == 3U ? __x86_rbx.ptr : ((2U)) == 4U ? __x86_rsp.ptr : ((2U)) == 5U ? __x86_rbp.ptr : ((2U)) == 6U ? __x86_rsi.ptr : ((2U)) == 7U ? __x86_rdi.ptr : ((2U)) == 8U ? __x86_r8.ptr : ((2U)) == 9U ? __x86_r9.ptr : ((2U)) == 10U ? __x86_r10.ptr : ((2U)) == 11U ? __x86_r11.ptr : ((2U)) == 12U ? __x86_r12.ptr : ((2U)) == 13U ? __x86_r13.ptr : ((2U)) == 14U ? __x86_r14.ptr : ((2U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((2U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else if (((__x86_l_alu) == 15U)) { __u8 __x86_l_carry = __x86_cf; __x86_l_result = (((__x86_l_lhs) + (__x86_l_rhs)) + (!!(__x86_l_carry))); do { __u8 __x86_adc_width = x86_width_effective(__x86_l_width); __u64 __x86_adc_mask = x86_width_mask(__x86_adc_width); __u64 __x86_adc_a = (__x86_l_lhs) & __x86_adc_mask; __u64 __x86_adc_b = (__x86_l_rhs) & __x86_adc_mask; __u64 __x86_adc_r = (__x86_l_result) & __x86_adc_mask; __u64 __x86_adc_sign = x86_width_sign_mask(__x86_adc_width); do { (__x86_cf) = (((__x86_adc_r) < (__x86_adc_a)) || ((!!((__x86_l_carry))) && ((__x86_adc_r) == (__x86_adc_a)))); (__x86_zf) = ((__x86_adc_r) == 0); (__x86_sf) = (((__x86_adc_r) & (__x86_adc_sign)) != 0); (__x86_of) = (((~((__x86_adc_a) ^ (__x86_adc_b))) & (((__x86_adc_a) ^ (__x86_adc_r)) & (__x86_adc_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_adc_r) ^ ((__x86_adc_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_adc_a) ^ (__x86_adc_b) ^ (__x86_adc_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((2U)) == 0U ? __x86_rax.ptr : ((2U)) == 1U ? __x86_rcx.ptr : ((2U)) == 2U ? __x86_rdx.ptr : ((2U)) == 3U ? __x86_rbx.ptr : ((2U)) == 4U ? __x86_rsp.ptr : ((2U)) == 5U ? __x86_rbp.ptr : ((2U)) == 6U ? __x86_rsi.ptr : ((2U)) == 7U ? __x86_rdi.ptr : ((2U)) == 8U ? __x86_r8.ptr : ((2U)) == 9U ? __x86_r9.ptr : ((2U)) == 10U ? __x86_r10.ptr : ((2U)) == 11U ? __x86_r11.ptr : ((2U)) == 12U ? __x86_r12.ptr : ((2U)) == 13U ? __x86_r13.ptr : ((2U)) == 14U ? __x86_r14.ptr : ((2U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((2U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else { __x86_l_result = x86_alu_result(__x86_l_lhs, __x86_l_rhs, __x86_l_alu, __x86_l_width); do { __u8 __x86_l_old_cf = __x86_cf; switch (( (((__u8)(((__x86_l_alu)))) == 0U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 15U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 10U) ? 1U : ( (((__u8)(((__x86_l_alu)))) == 13U) ? 2U : ( (((__u8)(((__x86_l_alu)))) == 1U) ? 3U : ( (((__u8)(((__x86_l_alu)))) == 12U) ? 4U : ( (((__u8)(((__x86_l_alu)))) == 14U) ? 5U : ( (((__u8)(((__x86_l_alu)))) == 11U) ? 6U : ( (((__u8)(((__x86_l_alu)))) == 5U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 6U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 7U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 8U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 9U) ? 8U : 9U)))))))))))))) { case 0U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = ((__x86_l_rhs)) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); break; case 1U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = (1) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 2U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = (1) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 3U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_rhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 4U: do { __u8 __x86_sbb_width = x86_width_effective((__x86_l_width)); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = ((__x86_l_lhs)) & __x86_sbb_mask; __u64 __x86_sbb_b = ((__x86_l_rhs)) & __x86_sbb_mask; __u64 __x86_sbb_r = ((__x86_l_result)) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((0))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); break; case 5U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (0) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 6U: do { (void)0; } while (0); break; case 7U: do { __u8 __x86_sh_raw_width = ((__x86_l_width)); __u8 __x86_sh_width = x86_width_effective(__x86_sh_raw_width); __u32 __x86_sh_bits = x86_width_bits(__x86_sh_width); __u64 __x86_sh_mask = x86_width_mask(__x86_sh_width); __u64 __x86_sh_a = ((__x86_l_lhs)) & __x86_sh_mask; __u64 __x86_sh_r = ((__x86_l_result)) & __x86_sh_mask; __u8 __x86_sh_count = x86_shift_count(((__x86_l_rhs)), __x86_sh_width); __u64 __x86_sh_sign = 1ULL << (__x86_sh_bits - 1); __u8 __x86_sh_alu = ((__x86_l_alu)); do { if ((__x86_sh_count) != 0) { if ((__x86_sh_alu) == 8U) { (__x86_cf) = (__x86_sh_r) & 1; if ((__x86_sh_count) == 1) (__x86_of) = (((__x86_sh_r) & (__x86_sh_sign)) != 0) ^ (__x86_cf); } else { (__x86_zf) = (__x86_sh_r) == 0; (__x86_sf) = ((__x86_sh_r) & (__x86_sh_sign)) != 0; if ((__x86_sh_alu) == 5U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_bits) - (__x86_sh_count))) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = (__x86_sf) ^ (__x86_cf); } else if ((__x86_sh_alu) == 6U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = ((__x86_sh_a) & (__x86_sh_sign)) != 0; } else { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : ((__x86_sh_a) & (__x86_sh_sign)) != 0; if ((__x86_sh_count) == 1) (__x86_of) = 0; } } } } while (0); if (__x86_sh_count != 0 && (__x86_sh_alu == 5U || __x86_sh_alu == 6U || __x86_sh_alu == 7U)) __x86_pf = ((38505U >> (((__x86_sh_r) ^ ((__x86_sh_r) >> 4U)) & 15U)) & 1U); } while (0); break; case 8U: do { __u8 __x86_imul_width = x86_width_effective((__x86_l_width)); __u64 __x86_imul_a_abs = x86_signed_abs_width(((__x86_l_lhs)), __x86_imul_width); __u64 __x86_imul_b_abs = x86_signed_abs_width(((__x86_l_rhs)), __x86_imul_width); __u64 __x86_imul_sign = 1ULL << (x86_width_bits(__x86_imul_width) - 1); __u64 __x86_imul_limit = ((((__x86_l_lhs)) ^ ((__x86_l_rhs))) & __x86_imul_sign) ? __x86_imul_sign : __x86_imul_sign - 1; do { __u8 __kprog_imul_overflow = ((__x86_imul_a_abs) != 0 && (__x86_imul_b_abs) > (__x86_imul_limit) / (__x86_imul_a_abs)); (__x86_cf) = __kprog_imul_overflow; (__x86_of) = __kprog_imul_overflow; } while (0); } while (0); break; default: do { __u8 __x86_fl_width = x86_width_effective((__x86_l_width)); __u64 __x86_fl_value = x86_apply_width(((__x86_l_result)), __x86_fl_width); __u32 __x86_fl_bits = x86_width_bits(__x86_fl_width); do { (__x86_cf) = 0; (__x86_zf) = __x86_fl_value == 0; (__x86_sf) = (__x86_fl_value >> (__x86_fl_bits - 1)) & 1; (__x86_of) = 0; } while (0); __x86_pf = ((38505U >> (((__x86_fl_value) ^ ((__x86_fl_value) >> 4U)) & 15U)) & 1U); } while (0); break; } } while (0); if ((2U)==4U && __x86_l_width==8U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = (0U); switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && (((({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U) && ({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((2U) == 0U ? __x86_rax.ptr : (2U) == 1U ? __x86_rcx.ptr : (2U) == 2U ? __x86_rdx.ptr : (2U) == 3U ? __x86_rbx.ptr : (2U) == 4U ? __x86_rsp.ptr : (2U) == 5U ? __x86_rbp.ptr : (2U) == 6U ? __x86_rsi.ptr : (2U) == 7U ? __x86_rdi.ptr : (2U) == 8U ? __x86_r8.ptr : (2U) == 9U ? __x86_r9.ptr : (2U) == 10U ? __x86_r10.ptr : (2U) == 11U ? __x86_r11.ptr : (2U) == 12U ? __x86_r12.ptr : (2U) == 13U ? __x86_r13.ptr : (2U) == 14U ? __x86_r14.ptr : (2U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && __x86_l_alu==0U && ({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (((({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((2U) == 0U ? __x86_rax.ptr : (2U) == 1U ? __x86_rcx.ptr : (2U) == 2U ? __x86_rdx.ptr : (2U) == 3U ? __x86_rbx.ptr : (2U) == 4U ? __x86_rsp.ptr : (2U) == 5U ? __x86_rbp.ptr : (2U) == 6U ? __x86_rsi.ptr : (2U) == 7U ? __x86_rdi.ptr : (2U) == 8U ? __x86_r8.ptr : (2U) == 9U ? __x86_r9.ptr : (2U) == 10U ? __x86_r10.ptr : (2U) == 11U ? __x86_r11.ptr : (2U) == 12U ? __x86_r12.ptr : (2U) == 13U ? __x86_r13.ptr : (2U) == 14U ? __x86_r14.ptr : (2U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_lhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (2U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((2U)) == 0U ? __x86_rax.ptr : ((2U)) == 1U ? __x86_rcx.ptr : ((2U)) == 2U ? __x86_rdx.ptr : ((2U)) == 3U ? __x86_rbx.ptr : ((2U)) == 4U ? __x86_rsp.ptr : ((2U)) == 5U ? __x86_rbp.ptr : ((2U)) == 6U ? __x86_rsi.ptr : ((2U)) == 7U ? __x86_rdi.ptr : ((2U)) == 8U ? __x86_r8.ptr : ((2U)) == 9U ? __x86_r9.ptr : ((2U)) == 10U ? __x86_r10.ptr : ((2U)) == 11U ? __x86_r11.ptr : ((2U)) == 12U ? __x86_r12.ptr : ((2U)) == 13U ? __x86_r13.ptr : ((2U)) == 14U ? __x86_r14.ptr : ((2U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((2U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((2U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((2U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((2U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 46 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_16:
 do {
     __u64 __kfunc_result = (__u64)bpf_strnstr((const __u8 *)((7U) == 0U ? __x86_rax.ptr : (7U) == 1U ? __x86_rcx.ptr : (7U) == 2U ? __x86_rdx.ptr : (7U) == 3U ? __x86_rbx.ptr : (7U) == 4U ? __x86_rsp.ptr : (7U) == 5U ? __x86_rbp.ptr : (7U) == 6U ? __x86_rsi.ptr : (7U) == 7U ? __x86_rdi.ptr : (7U) == 8U ? __x86_r8.ptr : (7U) == 9U ? __x86_r9.ptr : (7U) == 10U ? __x86_r10.ptr : (7U) == 11U ? __x86_r11.ptr : (7U) == 12U ? __x86_r12.ptr : (7U) == 13U ? __x86_r13.ptr : (7U) == 14U ? __x86_r14.ptr : (7U) == 15U ? __x86_r15.ptr : (void *)0), (const __u8 *)((6U) == 0U ? __x86_rax.ptr : (6U) == 1U ? __x86_rcx.ptr : (6U) == 2U ? __x86_rdx.ptr : (6U) == 3U ? __x86_rbx.ptr : (6U) == 4U ? __x86_rsp.ptr : (6U) == 5U ? __x86_rbp.ptr : (6U) == 6U ? __x86_rsi.ptr : (6U) == 7U ? __x86_rdi.ptr : (6U) == 8U ? __x86_r8.ptr : (6U) == 9U ? __x86_r9.ptr : (6U) == 10U ? __x86_r10.ptr : (6U) == 11U ? __x86_r11.ptr : (6U) == 12U ? __x86_r12.ptr : (6U) == 13U ? __x86_r13.ptr : (6U) == 14U ? __x86_r14.ptr : (6U) == 15U ? __x86_r15.ptr : (void *)0), (__u64)({ __u8 __x86_rd_reg = ((2U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }));
     do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((4U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((__kfunc_result)); union x86_sim_gpr __x86_wr_cell = { .ptr = (((0U)) == 0U ? __x86_rax.ptr : ((0U)) == 1U ? __x86_rcx.ptr : ((0U)) == 2U ? __x86_rdx.ptr : ((0U)) == 3U ? __x86_rbx.ptr : ((0U)) == 4U ? __x86_rsp.ptr : ((0U)) == 5U ? __x86_rbp.ptr : ((0U)) == 6U ? __x86_rsi.ptr : ((0U)) == 7U ? __x86_rdi.ptr : ((0U)) == 8U ? __x86_r8.ptr : ((0U)) == 9U ? __x86_r9.ptr : ((0U)) == 10U ? __x86_r10.ptr : ((0U)) == 11U ? __x86_r11.ptr : ((0U)) == 12U ? __x86_r12.ptr : ((0U)) == 13U ? __x86_r13.ptr : ((0U)) == 14U ? __x86_r14.ptr : ((0U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((0U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((0U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((0U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((0U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((0U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((0U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 50 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 50 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
     for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0);
     do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0);
     do { do { __s64 __x86_release_old=(-(__s64)8U), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 52 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 52 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
     for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); __x86_rcx.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_rcx_tag = 0U; __x86_rdx.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_rdx_tag = 0U; __x86_rsi.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_rsi_tag = 0U; __x86_rdi.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_rdi_tag = 0U; __x86_r8.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_r8_tag = 0U; __x86_r9.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_r9_tag = 0U; __x86_r10.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_r10_tag = 0U; __x86_r11.ptr = (void *)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_r11_tag = 0U; __x86_cf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_zf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_sf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_of = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_pf = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_af = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1; __x86_xmm0_lo = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); __x86_xmm0_hi = ({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } while (0);
 } while (0);
x86_l_1b:

 do { __u8 __x86_l_width = x86_width_effective((4U)); if (((((__u8)((__x86_l_width))) == 8U) ? ((((__u8)((((0U))))) == 4U) ? 0U : 1U) : 2U) == 0U) { do { if ((((3U)))==4U && (4U)==4U) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)((void *)(long)({ __u64 __x86_alias_delta=(__u64)(long)(((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)(((__s64)(long)(((0U)) == 0U ? __x86_rax.ptr : ((0U)) == 1U ? __x86_rcx.ptr : ((0U)) == 2U ? __x86_rdx.ptr : ((0U)) == 3U ? __x86_rbx.ptr : ((0U)) == 4U ? __x86_rsp.ptr : ((0U)) == 5U ? __x86_rbp.ptr : ((0U)) == 6U ? __x86_rsi.ptr : ((0U)) == 7U ? __x86_rdi.ptr : ((0U)) == 8U ? __x86_r8.ptr : ((0U)) == 9U ? __x86_r9.ptr : ((0U)) == 10U ? __x86_r10.ptr : ((0U)) == 11U ? __x86_r11.ptr : ((0U)) == 12U ? __x86_r12.ptr : ((0U)) == 13U ? __x86_r13.ptr : ((0U)) == 14U ? __x86_r14.ptr : ((0U)) == 15U ? __x86_r15.ptr : (void *)0))) + (__u64)(8U)))))))-(__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_alias_delta)); (__s64)__x86_alias_delta; })); __u8 __x86_wr_next_tag = (0U); switch ((((3U)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((3U))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (((((__u8)((8U))) == 8U) ? ((((__u8)(((((3U)))))) == 4U) ? 0U : 1U) : 2U) == 0U) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((({ __u8 __x86_rd_reg = ((((0U)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }))); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((((3U))))) == 0U ? __x86_rax.ptr : (((((3U))))) == 1U ? __x86_rcx.ptr : (((((3U))))) == 2U ? __x86_rdx.ptr : (((((3U))))) == 3U ? __x86_rbx.ptr : (((((3U))))) == 4U ? __x86_rsp.ptr : (((((3U))))) == 5U ? __x86_rbp.ptr : (((((3U))))) == 6U ? __x86_rsi.ptr : (((((3U))))) == 7U ? __x86_rdi.ptr : (((((3U))))) == 8U ? __x86_r8.ptr : (((((3U))))) == 9U ? __x86_r9.ptr : (((((3U))))) == 10U ? __x86_r10.ptr : (((((3U))))) == 11U ? __x86_r11.ptr : (((((3U))))) == 12U ? __x86_r12.ptr : (((((3U))))) == 13U ? __x86_r13.ptr : (((((3U))))) == 14U ? __x86_r14.ptr : (((((3U))))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((((3U))))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((((3U))))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((((3U)))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)((((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)(((__s64)(long)(((0U)) == 0U ? __x86_rax.ptr : ((0U)) == 1U ? __x86_rcx.ptr : ((0U)) == 2U ? __x86_rdx.ptr : ((0U)) == 3U ? __x86_rbx.ptr : ((0U)) == 4U ? __x86_rsp.ptr : ((0U)) == 5U ? __x86_rbp.ptr : ((0U)) == 6U ? __x86_rsi.ptr : ((0U)) == 7U ? __x86_rdi.ptr : ((0U)) == 8U ? __x86_r8.ptr : ((0U)) == 9U ? __x86_r9.ptr : ((0U)) == 10U ? __x86_r10.ptr : ((0U)) == 11U ? __x86_r11.ptr : ((0U)) == 12U ? __x86_r12.ptr : ((0U)) == 13U ? __x86_r13.ptr : ((0U)) == 14U ? __x86_r14.ptr : ((0U)) == 15U ? __x86_r15.ptr : (void *)0))) + (__u64)(8U)))))))); __u8 __x86_wr_next_tag = ((4U)); switch ((((3U)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((3U))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } while (0); } else if (((((__u8)((__x86_l_width))) == 8U) ? ((((__u8)((((0U))))) == 4U) ? 0U : 1U) : 2U) == 1U) { do { if ((((3U)))==4U && (({ __u8 __x86_l_tag = 0U; switch ((0U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==4U) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)((void *)(long)({ __u64 __x86_alias_delta=(__u64)(long)((((0U)) == 0U ? __x86_rax.ptr : ((0U)) == 1U ? __x86_rcx.ptr : ((0U)) == 2U ? __x86_rdx.ptr : ((0U)) == 3U ? __x86_rbx.ptr : ((0U)) == 4U ? __x86_rsp.ptr : ((0U)) == 5U ? __x86_rbp.ptr : ((0U)) == 6U ? __x86_rsi.ptr : ((0U)) == 7U ? __x86_rdi.ptr : ((0U)) == 8U ? __x86_r8.ptr : ((0U)) == 9U ? __x86_r9.ptr : ((0U)) == 10U ? __x86_r10.ptr : ((0U)) == 11U ? __x86_r11.ptr : ((0U)) == 12U ? __x86_r12.ptr : ((0U)) == 13U ? __x86_r13.ptr : ((0U)) == 14U ? __x86_r14.ptr : ((0U)) == 15U ? __x86_r15.ptr : (void *)0))-(__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_alias_delta)); (__s64)__x86_alias_delta; })); __u8 __x86_wr_next_tag = (0U); switch ((((3U)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((3U))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (((((__u8)((8U))) == 8U) ? ((((__u8)(((((3U)))))) == 4U) ? 0U : 1U) : 2U) == 0U) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((({ __u8 __x86_rd_reg = ((((0U)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }))); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((((3U))))) == 0U ? __x86_rax.ptr : (((((3U))))) == 1U ? __x86_rcx.ptr : (((((3U))))) == 2U ? __x86_rdx.ptr : (((((3U))))) == 3U ? __x86_rbx.ptr : (((((3U))))) == 4U ? __x86_rsp.ptr : (((((3U))))) == 5U ? __x86_rbp.ptr : (((((3U))))) == 6U ? __x86_rsi.ptr : (((((3U))))) == 7U ? __x86_rdi.ptr : (((((3U))))) == 8U ? __x86_r8.ptr : (((((3U))))) == 9U ? __x86_r9.ptr : (((((3U))))) == 10U ? __x86_r10.ptr : (((((3U))))) == 11U ? __x86_r11.ptr : (((((3U))))) == 12U ? __x86_r12.ptr : (((((3U))))) == 13U ? __x86_r13.ptr : (((((3U))))) == 14U ? __x86_r14.ptr : (((((3U))))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((((3U))))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((((3U))))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((((3U)))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((((0U)) == 0U ? __x86_rax.ptr : ((0U)) == 1U ? __x86_rcx.ptr : ((0U)) == 2U ? __x86_rdx.ptr : ((0U)) == 3U ? __x86_rbx.ptr : ((0U)) == 4U ? __x86_rsp.ptr : ((0U)) == 5U ? __x86_rbp.ptr : ((0U)) == 6U ? __x86_rsi.ptr : ((0U)) == 7U ? __x86_rdi.ptr : ((0U)) == 8U ? __x86_r8.ptr : ((0U)) == 9U ? __x86_r9.ptr : ((0U)) == 10U ? __x86_r10.ptr : ((0U)) == 11U ? __x86_r11.ptr : ((0U)) == 12U ? __x86_r12.ptr : ((0U)) == 13U ? __x86_r13.ptr : ((0U)) == 14U ? __x86_r14.ptr : ((0U)) == 15U ? __x86_r15.ptr : (void *)0))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch ((0U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((((3U)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((3U))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } while (0); } else if (((((__u8)((__x86_l_width))) == 8U) ? ((((__u8)((((0U))))) == 4U) ? 0U : 1U) : 2U) == 2U) { __u64 __x86_l_value = ({ __u8 __x86_rd_reg = (((0U))); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (((__u8)(((0U) >> 16) & 0xffU))); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (((__u8)(((0U) >> 8) & 0xffU))); __u64 __x86_wr_next = (__x86_l_value); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((3U))) == 0U ? __x86_rax.ptr : (((3U))) == 1U ? __x86_rcx.ptr : (((3U))) == 2U ? __x86_rdx.ptr : (((3U))) == 3U ? __x86_rbx.ptr : (((3U))) == 4U ? __x86_rsp.ptr : (((3U))) == 5U ? __x86_rbp.ptr : (((3U))) == 6U ? __x86_rsi.ptr : (((3U))) == 7U ? __x86_rdi.ptr : (((3U))) == 8U ? __x86_r8.ptr : (((3U))) == 9U ? __x86_r9.ptr : (((3U))) == 10U ? __x86_r10.ptr : (((3U))) == 11U ? __x86_r11.ptr : (((3U))) == 12U ? __x86_r12.ptr : (((3U))) == 13U ? __x86_r13.ptr : (((3U))) == 14U ? __x86_r14.ptr : (((3U))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((3U))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((3U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((3U))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((3U)))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 56 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_1d:
 do {
     __u64 __kf_left = (__u64)(long)&kprog_missing_function;
     __u64 __kf_right = 0ULL;
     __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, 8U);
     do { __u8 __x86_sub_width = x86_width_effective(8U); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (__kf_left) & __x86_sub_mask; __u64 __x86_sub_b = (__kf_right) & __x86_sub_mask; __u64 __x86_sub_r = (__kf_value) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0);
 } while (0);
x86_l_25:

 do { if (((__u8)(((((0x30))) <= (((0x25)))) ? 1 : 0))) { do { if (!(((((4U)))) == 10U ? (__x86_pf) : ((((4U)))) == 11U ? !(__x86_pf) : ((((((4U))))) == 0U ? ((__x86_of)) : (((((4U))))) == 1U ? (!((__x86_of))) : (((((4U))))) == 2U ? ((__x86_cf)) : (((((4U))))) == 3U ? (!((__x86_cf))) : (((((4U))))) == 4U ? ((__x86_zf)) : (((((4U))))) == 5U ? (!((__x86_zf))) : (((((4U))))) == 6U ? (((__x86_cf)) || ((__x86_zf))) : (((((4U))))) == 7U ? ((!((__x86_cf))) && (!((__x86_zf)))) : (((((4U))))) == 8U ? ((__x86_sf)) : (((((4U))))) == 9U ? (!((__x86_sf))) : (((((4U))))) == 12U ? (((__x86_sf)) != ((__x86_of))) : (((((4U))))) == 13U ? (((__x86_sf)) == ((__x86_of))) : (((((4U))))) == 14U ? (((__x86_zf)) || (((__x86_sf)) != ((__x86_of)))) : (((((4U))))) == 15U ? ((!((__x86_zf))) && (((__x86_sf)) == ((__x86_of)))) : 0))) { goto __x86_sim_jcc_fallthrough_66; } goto x86_l_30; __x86_sim_jcc_fallthrough_66: ; } while (0); } else if (((((4U))) == 10U ? (__x86_pf) : (((4U))) == 11U ? !(__x86_pf) : (((((4U)))) == 0U ? ((__x86_of)) : ((((4U)))) == 1U ? (!((__x86_of))) : ((((4U)))) == 2U ? ((__x86_cf)) : ((((4U)))) == 3U ? (!((__x86_cf))) : ((((4U)))) == 4U ? ((__x86_zf)) : ((((4U)))) == 5U ? (!((__x86_zf))) : ((((4U)))) == 6U ? (((__x86_cf)) || ((__x86_zf))) : ((((4U)))) == 7U ? ((!((__x86_cf))) && (!((__x86_zf)))) : ((((4U)))) == 8U ? ((__x86_sf)) : ((((4U)))) == 9U ? (!((__x86_sf))) : ((((4U)))) == 12U ? (((__x86_sf)) != ((__x86_of))) : ((((4U)))) == 13U ? (((__x86_sf)) == ((__x86_of))) : ((((4U)))) == 14U ? (((__x86_zf)) || (((__x86_sf)) != ((__x86_of)))) : ((((4U)))) == 15U ? ((!((__x86_zf))) && (((__x86_sf)) == ((__x86_of)))) : 0))) { do { (void)(((0x25))); (void)(((0x30))); goto x86_l_30; } while (0); } asm volatile("" ::: "memory"); } while (0);
x86_l_27:

 do { __u8 __x86_l_width = x86_width_effective(4U); __u32 __x86_l_aux = (2U); __u8 __x86_l_alu = ((__u8)((__x86_l_aux) & 0xffU)); __u8 __x86_l_dst_shift = ((__u8)(((__x86_l_aux) >> 8) & 0xffU)); __u8 __x86_l_src_shift = ((__u8)(((__x86_l_aux) >> 16) & 0xffU)); __u64 __x86_l_lhs = 0, __x86_l_rhs = 0; if (!(__x86_l_alu == 2U && (7U) == (7U) && __x86_l_dst_shift == __x86_l_src_shift)) { __x86_l_lhs = ({ __u8 __x86_rd_reg = ((7U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_dst_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_l_rhs = ({ __u8 __x86_rd_reg = ((7U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_src_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } __u64 __x86_l_result; if (((__x86_l_alu) == 12U)) { __u8 __x86_l_borrow = __x86_cf; __x86_l_result = (((__x86_l_lhs) - (__x86_l_rhs)) - (!!(__x86_l_borrow))); do { __u8 __x86_sbb_width = x86_width_effective(__x86_l_width); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = (__x86_l_lhs) & __x86_sbb_mask; __u64 __x86_sbb_b = (__x86_l_rhs) & __x86_sbb_mask; __u64 __x86_sbb_r = (__x86_l_result) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((__x86_l_borrow))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else if (((__x86_l_alu) == 15U)) { __u8 __x86_l_carry = __x86_cf; __x86_l_result = (((__x86_l_lhs) + (__x86_l_rhs)) + (!!(__x86_l_carry))); do { __u8 __x86_adc_width = x86_width_effective(__x86_l_width); __u64 __x86_adc_mask = x86_width_mask(__x86_adc_width); __u64 __x86_adc_a = (__x86_l_lhs) & __x86_adc_mask; __u64 __x86_adc_b = (__x86_l_rhs) & __x86_adc_mask; __u64 __x86_adc_r = (__x86_l_result) & __x86_adc_mask; __u64 __x86_adc_sign = x86_width_sign_mask(__x86_adc_width); do { (__x86_cf) = (((__x86_adc_r) < (__x86_adc_a)) || ((!!((__x86_l_carry))) && ((__x86_adc_r) == (__x86_adc_a)))); (__x86_zf) = ((__x86_adc_r) == 0); (__x86_sf) = (((__x86_adc_r) & (__x86_adc_sign)) != 0); (__x86_of) = (((~((__x86_adc_a) ^ (__x86_adc_b))) & (((__x86_adc_a) ^ (__x86_adc_r)) & (__x86_adc_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_adc_r) ^ ((__x86_adc_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_adc_a) ^ (__x86_adc_b) ^ (__x86_adc_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else { __x86_l_result = x86_alu_result(__x86_l_lhs, __x86_l_rhs, __x86_l_alu, __x86_l_width); do { __u8 __x86_l_old_cf = __x86_cf; switch (( (((__u8)(((__x86_l_alu)))) == 0U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 15U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 10U) ? 1U : ( (((__u8)(((__x86_l_alu)))) == 13U) ? 2U : ( (((__u8)(((__x86_l_alu)))) == 1U) ? 3U : ( (((__u8)(((__x86_l_alu)))) == 12U) ? 4U : ( (((__u8)(((__x86_l_alu)))) == 14U) ? 5U : ( (((__u8)(((__x86_l_alu)))) == 11U) ? 6U : ( (((__u8)(((__x86_l_alu)))) == 5U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 6U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 7U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 8U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 9U) ? 8U : 9U)))))))))))))) { case 0U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = ((__x86_l_rhs)) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); break; case 1U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = (1) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 2U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = (1) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 3U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_rhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 4U: do { __u8 __x86_sbb_width = x86_width_effective((__x86_l_width)); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = ((__x86_l_lhs)) & __x86_sbb_mask; __u64 __x86_sbb_b = ((__x86_l_rhs)) & __x86_sbb_mask; __u64 __x86_sbb_r = ((__x86_l_result)) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((0))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); break; case 5U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (0) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 6U: do { (void)0; } while (0); break; case 7U: do { __u8 __x86_sh_raw_width = ((__x86_l_width)); __u8 __x86_sh_width = x86_width_effective(__x86_sh_raw_width); __u32 __x86_sh_bits = x86_width_bits(__x86_sh_width); __u64 __x86_sh_mask = x86_width_mask(__x86_sh_width); __u64 __x86_sh_a = ((__x86_l_lhs)) & __x86_sh_mask; __u64 __x86_sh_r = ((__x86_l_result)) & __x86_sh_mask; __u8 __x86_sh_count = x86_shift_count(((__x86_l_rhs)), __x86_sh_width); __u64 __x86_sh_sign = 1ULL << (__x86_sh_bits - 1); __u8 __x86_sh_alu = ((__x86_l_alu)); do { if ((__x86_sh_count) != 0) { if ((__x86_sh_alu) == 8U) { (__x86_cf) = (__x86_sh_r) & 1; if ((__x86_sh_count) == 1) (__x86_of) = (((__x86_sh_r) & (__x86_sh_sign)) != 0) ^ (__x86_cf); } else { (__x86_zf) = (__x86_sh_r) == 0; (__x86_sf) = ((__x86_sh_r) & (__x86_sh_sign)) != 0; if ((__x86_sh_alu) == 5U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_bits) - (__x86_sh_count))) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = (__x86_sf) ^ (__x86_cf); } else if ((__x86_sh_alu) == 6U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = ((__x86_sh_a) & (__x86_sh_sign)) != 0; } else { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : ((__x86_sh_a) & (__x86_sh_sign)) != 0; if ((__x86_sh_count) == 1) (__x86_of) = 0; } } } } while (0); if (__x86_sh_count != 0 && (__x86_sh_alu == 5U || __x86_sh_alu == 6U || __x86_sh_alu == 7U)) __x86_pf = ((38505U >> (((__x86_sh_r) ^ ((__x86_sh_r) >> 4U)) & 15U)) & 1U); } while (0); break; case 8U: do { __u8 __x86_imul_width = x86_width_effective((__x86_l_width)); __u64 __x86_imul_a_abs = x86_signed_abs_width(((__x86_l_lhs)), __x86_imul_width); __u64 __x86_imul_b_abs = x86_signed_abs_width(((__x86_l_rhs)), __x86_imul_width); __u64 __x86_imul_sign = 1ULL << (x86_width_bits(__x86_imul_width) - 1); __u64 __x86_imul_limit = ((((__x86_l_lhs)) ^ ((__x86_l_rhs))) & __x86_imul_sign) ? __x86_imul_sign : __x86_imul_sign - 1; do { __u8 __kprog_imul_overflow = ((__x86_imul_a_abs) != 0 && (__x86_imul_b_abs) > (__x86_imul_limit) / (__x86_imul_a_abs)); (__x86_cf) = __kprog_imul_overflow; (__x86_of) = __kprog_imul_overflow; } while (0); } while (0); break; default: do { __u8 __x86_fl_width = x86_width_effective((__x86_l_width)); __u64 __x86_fl_value = x86_apply_width(((__x86_l_result)), __x86_fl_width); __u32 __x86_fl_bits = x86_width_bits(__x86_fl_width); do { (__x86_cf) = 0; (__x86_zf) = __x86_fl_value == 0; (__x86_sf) = (__x86_fl_value >> (__x86_fl_bits - 1)) & 1; (__x86_of) = 0; } while (0); __x86_pf = ((38505U >> (((__x86_fl_value) ^ ((__x86_fl_value) >> 4U)) & 15U)) & 1U); } while (0); break; } } while (0); if ((7U)==4U && __x86_l_width==8U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = (0U); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && (((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U) && ({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((7U) == 0U ? __x86_rax.ptr : (7U) == 1U ? __x86_rcx.ptr : (7U) == 2U ? __x86_rdx.ptr : (7U) == 3U ? __x86_rbx.ptr : (7U) == 4U ? __x86_rsp.ptr : (7U) == 5U ? __x86_rbp.ptr : (7U) == 6U ? __x86_rsi.ptr : (7U) == 7U ? __x86_rdi.ptr : (7U) == 8U ? __x86_r8.ptr : (7U) == 9U ? __x86_r9.ptr : (7U) == 10U ? __x86_r10.ptr : (7U) == 11U ? __x86_r11.ptr : (7U) == 12U ? __x86_r12.ptr : (7U) == 13U ? __x86_r13.ptr : (7U) == 14U ? __x86_r14.ptr : (7U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && __x86_l_alu==0U && ({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((7U) == 0U ? __x86_rax.ptr : (7U) == 1U ? __x86_rcx.ptr : (7U) == 2U ? __x86_rdx.ptr : (7U) == 3U ? __x86_rbx.ptr : (7U) == 4U ? __x86_rsp.ptr : (7U) == 5U ? __x86_rbp.ptr : (7U) == 6U ? __x86_rsi.ptr : (7U) == 7U ? __x86_rdi.ptr : (7U) == 8U ? __x86_r8.ptr : (7U) == 9U ? __x86_r9.ptr : (7U) == 10U ? __x86_r10.ptr : (7U) == 11U ? __x86_r11.ptr : (7U) == 12U ? __x86_r12.ptr : (7U) == 13U ? __x86_r13.ptr : (7U) == 14U ? __x86_r14.ptr : (7U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_lhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (7U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((7U)) == 0U ? __x86_rax.ptr : ((7U)) == 1U ? __x86_rcx.ptr : ((7U)) == 2U ? __x86_rdx.ptr : ((7U)) == 3U ? __x86_rbx.ptr : ((7U)) == 4U ? __x86_rsp.ptr : ((7U)) == 5U ? __x86_rbp.ptr : ((7U)) == 6U ? __x86_rsi.ptr : ((7U)) == 7U ? __x86_rdi.ptr : ((7U)) == 8U ? __x86_r8.ptr : ((7U)) == 9U ? __x86_r9.ptr : ((7U)) == 10U ? __x86_r10.ptr : ((7U)) == 11U ? __x86_r11.ptr : ((7U)) == 12U ? __x86_r12.ptr : ((7U)) == 13U ? __x86_r13.ptr : ((7U)) == 14U ? __x86_r14.ptr : ((7U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((7U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((7U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((7U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((7U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 69 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_29:
 __x86_sim_unresolved_indirect_target();
x86_l_2e:

 do { __u8 __x86_l_width = x86_width_effective(4U); __u32 __x86_l_aux = (0U); __u8 __x86_l_alu = ((__u8)((__x86_l_aux) & 0xffU)); __u8 __x86_l_dst_shift = ((__u8)(((__x86_l_aux) >> 8) & 0xffU)); __u8 __x86_l_src_shift = ((__u8)(((__x86_l_aux) >> 16) & 0xffU)); __u64 __x86_l_lhs = 0, __x86_l_rhs = 0; if (!(__x86_l_alu == 2U && (3U) == (0U) && __x86_l_dst_shift == __x86_l_src_shift)) { __x86_l_lhs = ({ __u8 __x86_rd_reg = ((3U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_dst_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_l_rhs = ({ __u8 __x86_rd_reg = ((0U)); __u8 __x86_rd_raw_width = (__x86_l_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (__x86_l_src_shift); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } __u64 __x86_l_result; if (((__x86_l_alu) == 12U)) { __u8 __x86_l_borrow = __x86_cf; __x86_l_result = (((__x86_l_lhs) - (__x86_l_rhs)) - (!!(__x86_l_borrow))); do { __u8 __x86_sbb_width = x86_width_effective(__x86_l_width); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = (__x86_l_lhs) & __x86_sbb_mask; __u64 __x86_sbb_b = (__x86_l_rhs) & __x86_sbb_mask; __u64 __x86_sbb_r = (__x86_l_result) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((__x86_l_borrow))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((3U)) == 0U ? __x86_rax.ptr : ((3U)) == 1U ? __x86_rcx.ptr : ((3U)) == 2U ? __x86_rdx.ptr : ((3U)) == 3U ? __x86_rbx.ptr : ((3U)) == 4U ? __x86_rsp.ptr : ((3U)) == 5U ? __x86_rbp.ptr : ((3U)) == 6U ? __x86_rsi.ptr : ((3U)) == 7U ? __x86_rdi.ptr : ((3U)) == 8U ? __x86_r8.ptr : ((3U)) == 9U ? __x86_r9.ptr : ((3U)) == 10U ? __x86_r10.ptr : ((3U)) == 11U ? __x86_r11.ptr : ((3U)) == 12U ? __x86_r12.ptr : ((3U)) == 13U ? __x86_r13.ptr : ((3U)) == 14U ? __x86_r14.ptr : ((3U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else if (((__x86_l_alu) == 15U)) { __u8 __x86_l_carry = __x86_cf; __x86_l_result = (((__x86_l_lhs) + (__x86_l_rhs)) + (!!(__x86_l_carry))); do { __u8 __x86_adc_width = x86_width_effective(__x86_l_width); __u64 __x86_adc_mask = x86_width_mask(__x86_adc_width); __u64 __x86_adc_a = (__x86_l_lhs) & __x86_adc_mask; __u64 __x86_adc_b = (__x86_l_rhs) & __x86_adc_mask; __u64 __x86_adc_r = (__x86_l_result) & __x86_adc_mask; __u64 __x86_adc_sign = x86_width_sign_mask(__x86_adc_width); do { (__x86_cf) = (((__x86_adc_r) < (__x86_adc_a)) || ((!!((__x86_l_carry))) && ((__x86_adc_r) == (__x86_adc_a)))); (__x86_zf) = ((__x86_adc_r) == 0); (__x86_sf) = (((__x86_adc_r) & (__x86_adc_sign)) != 0); (__x86_of) = (((~((__x86_adc_a) ^ (__x86_adc_b))) & (((__x86_adc_a) ^ (__x86_adc_r)) & (__x86_adc_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_adc_r) ^ ((__x86_adc_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_adc_a) ^ (__x86_adc_b) ^ (__x86_adc_r)) & 16U) != 0); } while (0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((3U)) == 0U ? __x86_rax.ptr : ((3U)) == 1U ? __x86_rcx.ptr : ((3U)) == 2U ? __x86_rdx.ptr : ((3U)) == 3U ? __x86_rbx.ptr : ((3U)) == 4U ? __x86_rsp.ptr : ((3U)) == 5U ? __x86_rbp.ptr : ((3U)) == 6U ? __x86_rsi.ptr : ((3U)) == 7U ? __x86_rdi.ptr : ((3U)) == 8U ? __x86_r8.ptr : ((3U)) == 9U ? __x86_r9.ptr : ((3U)) == 10U ? __x86_r10.ptr : ((3U)) == 11U ? __x86_r11.ptr : ((3U)) == 12U ? __x86_r12.ptr : ((3U)) == 13U ? __x86_r13.ptr : ((3U)) == 14U ? __x86_r14.ptr : ((3U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } else { __x86_l_result = x86_alu_result(__x86_l_lhs, __x86_l_rhs, __x86_l_alu, __x86_l_width); do { __u8 __x86_l_old_cf = __x86_cf; switch (( (((__u8)(((__x86_l_alu)))) == 0U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 15U) ? 0U : ( (((__u8)(((__x86_l_alu)))) == 10U) ? 1U : ( (((__u8)(((__x86_l_alu)))) == 13U) ? 2U : ( (((__u8)(((__x86_l_alu)))) == 1U) ? 3U : ( (((__u8)(((__x86_l_alu)))) == 12U) ? 4U : ( (((__u8)(((__x86_l_alu)))) == 14U) ? 5U : ( (((__u8)(((__x86_l_alu)))) == 11U) ? 6U : ( (((__u8)(((__x86_l_alu)))) == 5U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 6U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 7U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 8U) ? 7U : ( (((__u8)(((__x86_l_alu)))) == 9U) ? 8U : 9U)))))))))))))) { case 0U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = ((__x86_l_rhs)) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); break; case 1U: do { __u8 __x86_add_width = x86_width_effective((__x86_l_width)); __u64 __x86_add_mask = x86_width_mask(__x86_add_width); __u64 __x86_add_a = ((__x86_l_lhs)) & __x86_add_mask; __u64 __x86_add_b = (1) & __x86_add_mask; __u64 __x86_add_r = ((__x86_l_result)) & __x86_add_mask; __u64 __x86_add_sign = x86_width_sign_mask(__x86_add_width); do { (__x86_cf) = ((__x86_add_r) < (__x86_add_a)); (__x86_zf) = ((__x86_add_r) == 0); (__x86_sf) = (((__x86_add_r) & (__x86_add_sign)) != 0); (__x86_of) = (((~((__x86_add_a) ^ (__x86_add_b))) & (((__x86_add_a) ^ (__x86_add_r)) & (__x86_add_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_add_r) ^ ((__x86_add_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_add_a) ^ (__x86_add_b) ^ (__x86_add_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 2U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = (1) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); __x86_cf = __x86_l_old_cf; break; case 3U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_rhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 4U: do { __u8 __x86_sbb_width = x86_width_effective((__x86_l_width)); __u64 __x86_sbb_mask = x86_width_mask(__x86_sbb_width); __u64 __x86_sbb_a = ((__x86_l_lhs)) & __x86_sbb_mask; __u64 __x86_sbb_b = ((__x86_l_rhs)) & __x86_sbb_mask; __u64 __x86_sbb_r = ((__x86_l_result)) & __x86_sbb_mask; __u64 __x86_sbb_sign = x86_width_sign_mask(__x86_sbb_width); do { (__x86_cf) = (((__x86_sbb_a) < (__x86_sbb_b)) || ((!!((0))) && ((__x86_sbb_a) == (__x86_sbb_b)))); (__x86_zf) = ((__x86_sbb_r) == 0); (__x86_sf) = (((__x86_sbb_r) & (__x86_sbb_sign)) != 0); (__x86_of) = ((((__x86_sbb_a) ^ (__x86_sbb_b)) & (((__x86_sbb_a) ^ (__x86_sbb_r)) & (__x86_sbb_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sbb_r) ^ ((__x86_sbb_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sbb_a) ^ (__x86_sbb_b) ^ (__x86_sbb_r)) & 16U) != 0); } while (0); break; case 5U: do { __u8 __x86_sub_width = x86_width_effective((__x86_l_width)); __u64 __x86_sub_mask = x86_width_mask(__x86_sub_width); __u64 __x86_sub_a = (0) & __x86_sub_mask; __u64 __x86_sub_b = ((__x86_l_lhs)) & __x86_sub_mask; __u64 __x86_sub_r = ((__x86_l_result)) & __x86_sub_mask; __u64 __x86_sub_sign = x86_width_sign_mask(__x86_sub_width); do { (__x86_cf) = ((__x86_sub_a) < (__x86_sub_b)); (__x86_zf) = ((__x86_sub_a) == (__x86_sub_b)); (__x86_sf) = (((__x86_sub_r) & (__x86_sub_sign)) != 0); (__x86_of) = ((((__x86_sub_a) ^ (__x86_sub_b)) & (((__x86_sub_a) ^ (__x86_sub_r)) & (__x86_sub_sign))) != 0); } while (0); __x86_pf = ((38505U >> (((__x86_sub_r) ^ ((__x86_sub_r) >> 4U)) & 15U)) & 1U); __x86_af = ((((__x86_sub_a) ^ (__x86_sub_b) ^ (__x86_sub_r)) & 16U) != 0); } while (0); break; case 6U: do { (void)0; } while (0); break; case 7U: do { __u8 __x86_sh_raw_width = ((__x86_l_width)); __u8 __x86_sh_width = x86_width_effective(__x86_sh_raw_width); __u32 __x86_sh_bits = x86_width_bits(__x86_sh_width); __u64 __x86_sh_mask = x86_width_mask(__x86_sh_width); __u64 __x86_sh_a = ((__x86_l_lhs)) & __x86_sh_mask; __u64 __x86_sh_r = ((__x86_l_result)) & __x86_sh_mask; __u8 __x86_sh_count = x86_shift_count(((__x86_l_rhs)), __x86_sh_width); __u64 __x86_sh_sign = 1ULL << (__x86_sh_bits - 1); __u8 __x86_sh_alu = ((__x86_l_alu)); do { if ((__x86_sh_count) != 0) { if ((__x86_sh_alu) == 8U) { (__x86_cf) = (__x86_sh_r) & 1; if ((__x86_sh_count) == 1) (__x86_of) = (((__x86_sh_r) & (__x86_sh_sign)) != 0) ^ (__x86_cf); } else { (__x86_zf) = (__x86_sh_r) == 0; (__x86_sf) = ((__x86_sh_r) & (__x86_sh_sign)) != 0; if ((__x86_sh_alu) == 5U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_bits) - (__x86_sh_count))) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = (__x86_sf) ^ (__x86_cf); } else if ((__x86_sh_alu) == 6U) { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : 0; if ((__x86_sh_count) == 1) (__x86_of) = ((__x86_sh_a) & (__x86_sh_sign)) != 0; } else { (__x86_cf) = (__x86_sh_count) <= (__x86_sh_bits) ? ((__x86_sh_a) >> ((__x86_sh_count) - 1)) & 1 : ((__x86_sh_a) & (__x86_sh_sign)) != 0; if ((__x86_sh_count) == 1) (__x86_of) = 0; } } } } while (0); if (__x86_sh_count != 0 && (__x86_sh_alu == 5U || __x86_sh_alu == 6U || __x86_sh_alu == 7U)) __x86_pf = ((38505U >> (((__x86_sh_r) ^ ((__x86_sh_r) >> 4U)) & 15U)) & 1U); } while (0); break; case 8U: do { __u8 __x86_imul_width = x86_width_effective((__x86_l_width)); __u64 __x86_imul_a_abs = x86_signed_abs_width(((__x86_l_lhs)), __x86_imul_width); __u64 __x86_imul_b_abs = x86_signed_abs_width(((__x86_l_rhs)), __x86_imul_width); __u64 __x86_imul_sign = 1ULL << (x86_width_bits(__x86_imul_width) - 1); __u64 __x86_imul_limit = ((((__x86_l_lhs)) ^ ((__x86_l_rhs))) & __x86_imul_sign) ? __x86_imul_sign : __x86_imul_sign - 1; do { __u8 __kprog_imul_overflow = ((__x86_imul_a_abs) != 0 && (__x86_imul_b_abs) > (__x86_imul_limit) / (__x86_imul_a_abs)); (__x86_cf) = __kprog_imul_overflow; (__x86_of) = __kprog_imul_overflow; } while (0); } while (0); break; default: do { __u8 __x86_fl_width = x86_width_effective((__x86_l_width)); __u64 __x86_fl_value = x86_apply_width(((__x86_l_result)), __x86_fl_width); __u32 __x86_fl_bits = x86_width_bits(__x86_fl_width); do { (__x86_cf) = 0; (__x86_zf) = __x86_fl_value == 0; (__x86_sf) = (__x86_fl_value >> (__x86_fl_bits - 1)) & 1; (__x86_of) = 0; } while (0); __x86_pf = ((38505U >> (((__x86_fl_value) ^ ((__x86_fl_value) >> 4U)) & 15U)) & 1U); } while (0); break; } } while (0); if ((3U)==4U && __x86_l_width==8U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = (0U); switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && (((({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U) && ({ __u8 __x86_l_tag = 0U; switch (0U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (__x86_l_alu==0U || __x86_l_alu==1U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((3U) == 0U ? __x86_rax.ptr : (3U) == 1U ? __x86_rcx.ptr : (3U) == 2U ? __x86_rdx.ptr : (3U) == 3U ? __x86_rbx.ptr : (3U) == 4U ? __x86_rsp.ptr : (3U) == 5U ? __x86_rbp.ptr : (3U) == 6U ? __x86_rsi.ptr : (3U) == 7U ? __x86_rdi.ptr : (3U) == 8U ? __x86_r8.ptr : (3U) == 9U ? __x86_r9.ptr : (3U) == 10U ? __x86_r10.ptr : (3U) == 11U ? __x86_r11.ptr : (3U) == 12U ? __x86_r12.ptr : (3U) == 13U ? __x86_r13.ptr : (3U) == 14U ? __x86_r14.ptr : (3U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_alu==0U ? __x86_l_rhs : -__x86_l_rhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else if (__x86_l_width==8U && __x86_l_dst_shift==0 && __x86_l_src_shift==0 && __x86_l_alu==0U && ({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })==0U && (((({ __u8 __x86_l_tag = 0U; switch (0U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))>=1U && (({ __u8 __x86_l_tag = 0U; switch (0U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))<=4U) || (({ __u8 __x86_l_tag = 0U; switch (0U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))==6U)) do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; void *__x86_wr_next_ptr = (void *)(((__u8 *)(unsigned long)((__u64)(unsigned long)(((0U) == 0U ? __x86_rax.ptr : (0U) == 1U ? __x86_rcx.ptr : (0U) == 2U ? __x86_rdx.ptr : (0U) == 3U ? __x86_rbx.ptr : (0U) == 4U ? __x86_rsp.ptr : (0U) == 5U ? __x86_rbp.ptr : (0U) == 6U ? __x86_rsi.ptr : (0U) == 7U ? __x86_rdi.ptr : (0U) == 8U ? __x86_r8.ptr : (0U) == 9U ? __x86_r9.ptr : (0U) == 10U ? __x86_r10.ptr : (0U) == 11U ? __x86_r11.ptr : (0U) == 12U ? __x86_r12.ptr : (0U) == 13U ? __x86_r13.ptr : (0U) == 14U ? __x86_r14.ptr : (0U) == 15U ? __x86_r15.ptr : (void *)0)) + (__u64)(__x86_l_lhs)))); __u8 __x86_wr_next_tag = ((({ __u8 __x86_l_tag = 0U; switch (0U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }))); switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = (__x86_l_width); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (__x86_l_dst_shift); __u64 __x86_wr_next = (__x86_l_result); union x86_sim_gpr __x86_wr_cell = { .ptr = (((3U)) == 0U ? __x86_rax.ptr : ((3U)) == 1U ? __x86_rcx.ptr : ((3U)) == 2U ? __x86_rdx.ptr : ((3U)) == 3U ? __x86_rbx.ptr : ((3U)) == 4U ? __x86_rsp.ptr : ((3U)) == 5U ? __x86_rbp.ptr : ((3U)) == 6U ? __x86_rsi.ptr : ((3U)) == 7U ? __x86_rdi.ptr : ((3U)) == 8U ? __x86_r8.ptr : ((3U)) == 9U ? __x86_r9.ptr : ((3U)) == 10U ? __x86_r10.ptr : ((3U)) == 11U ? __x86_r11.ptr : ((3U)) == 12U ? __x86_r12.ptr : ((3U)) == 13U ? __x86_r13.ptr : ((3U)) == 14U ? __x86_r14.ptr : ((3U)) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((3U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((3U)) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((3U)) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((3U))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 74 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0);
x86_l_30:

 do { __u8 __x86_l_width = x86_width_effective(8U); __u8 __x86_l_src_width = (((__u8)(((4U)))) == 0U ? (__u8)((__x86_l_width)) : (__u8)(((4U)))); __u8 __x86_l_shape = (((__u8)(((0x21U)))) == 0x21U ? 0U : 1U); __u64 __x86_l_value = ({ __u8 __x86_rd_reg = ((((__u8)(3U) >= 128U && (__u8)(3U) < 132U) ? (__u8)(3U) - 128U : (__u8)(3U))); __u8 __x86_rd_raw_width = (__x86_l_src_width); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = ((((__u8)(3U) >= 128U && (__u8)(3U) < 132U) ? 8U : 0U)); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); if (__x86_l_shape == 0U) { __x86_l_value = x86_sign_extend(__x86_l_value, __x86_l_src_width); } else { __x86_l_value = x86_apply_width(__x86_l_value, __x86_l_src_width); } if (__x86_l_width == 4U) { __u32 __x86_l_lane32 = (__u32)__x86_l_value; __asm__("" : "+r"(__x86_l_lane32)); __x86_l_value = __x86_l_lane32; } else __asm__("" : "+r"(__x86_l_value)); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((__x86_l_width)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((__x86_l_value)); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((0U))) == 0U ? __x86_rax.ptr : (((0U))) == 1U ? __x86_rcx.ptr : (((0U))) == 2U ? __x86_rdx.ptr : (((0U))) == 3U ? __x86_rbx.ptr : (((0U))) == 4U ? __x86_rsp.ptr : (((0U))) == 5U ? __x86_rbp.ptr : (((0U))) == 6U ? __x86_rsi.ptr : (((0U))) == 7U ? __x86_rdi.ptr : (((0U))) == 8U ? __x86_r8.ptr : (((0U))) == 9U ? __x86_r9.ptr : (((0U))) == 10U ? __x86_r10.ptr : (((0U))) == 11U ? __x86_r11.ptr : (((0U))) == 12U ? __x86_r12.ptr : (((0U))) == 13U ? __x86_r13.ptr : (((0U))) == 14U ? __x86_r14.ptr : (((0U))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((0U))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((0U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((0U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((0U))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((0U))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((0U)))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 77 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 77 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } while (0);
x86_l_33:

 do { if ((((__u32)(0) >> 24) & 0xffU) == 2U && ({ int __x86_read_recovered = 0; if (((__u8)((((4U)) != 0xffU) ? 1 : 0)) && ((4U)) != 4U && ({ __u8 __x86_l_tag = 0U; switch ((4U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 0U && ((__u64)(({ __u8 __x86_rd_reg = ((4U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); })) < 4096U || (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1U))) { if (((0xffU))==4U) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((0)); union x86_sim_gpr __x86_wr_cell = { .ptr = (((((0xffU)))) == 0U ? __x86_rax.ptr : ((((0xffU)))) == 1U ? __x86_rcx.ptr : ((((0xffU)))) == 2U ? __x86_rdx.ptr : ((((0xffU)))) == 3U ? __x86_rbx.ptr : ((((0xffU)))) == 4U ? __x86_rsp.ptr : ((((0xffU)))) == 5U ? __x86_rbp.ptr : ((((0xffU)))) == 6U ? __x86_rsi.ptr : ((((0xffU)))) == 7U ? __x86_rdi.ptr : ((((0xffU)))) == 8U ? __x86_r8.ptr : ((((0xffU)))) == 9U ? __x86_r9.ptr : ((((0xffU)))) == 10U ? __x86_r10.ptr : ((((0xffU)))) == 11U ? __x86_r11.ptr : ((((0xffU)))) == 12U ? __x86_r12.ptr : ((((0xffU)))) == 13U ? __x86_r13.ptr : ((((0xffU)))) == 14U ? __x86_r14.ptr : ((((0xffU)))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((((0xffU)))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((((0xffU)))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((((0xffU)))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((0xffU))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); __x86_read_recovered = 1; } __x86_read_recovered; })) break; if ((((__u32)(0) >> 24) & 0xffU) != 2U) { do { if ((1U) && ({ int __x86_read_recovered = 0; if (((__u8)((((4U)) != 0xffU) ? 1 : 0)) && ((4U)) != 4U && ({ __u8 __x86_l_tag = 0U; switch ((4U)) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 0U && ((__u64)(({ __u8 __x86_rd_reg = ((4U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); })) < 4096U || (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }) & 1U))) { if (((((3U))))==4U) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); else do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((8U)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((0)); union x86_sim_gpr __x86_wr_cell = { .ptr = (((((((3U)))))) == 0U ? __x86_rax.ptr : ((((((3U)))))) == 1U ? __x86_rcx.ptr : ((((((3U)))))) == 2U ? __x86_rdx.ptr : ((((((3U)))))) == 3U ? __x86_rbx.ptr : ((((((3U)))))) == 4U ? __x86_rsp.ptr : ((((((3U)))))) == 5U ? __x86_rbp.ptr : ((((((3U)))))) == 6U ? __x86_rsi.ptr : ((((((3U)))))) == 7U ? __x86_rdi.ptr : ((((((3U)))))) == 8U ? __x86_r8.ptr : ((((((3U)))))) == 9U ? __x86_r9.ptr : ((((((3U)))))) == 10U ? __x86_r10.ptr : ((((((3U)))))) == 11U ? __x86_r11.ptr : ((((((3U)))))) == 12U ? __x86_r12.ptr : ((((((3U)))))) == 13U ? __x86_r13.ptr : ((((((3U)))))) == 14U ? __x86_r14.ptr : ((((((3U)))))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch ((((((3U)))))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if (((((((3U)))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if (((((((3U)))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if (((((((3U)))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch ((((((3U)))))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if (((((((3U))))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); __x86_read_recovered = 1; } __x86_read_recovered; })) break; __u8 __x86_l_pp_dir = ((1U) ? 1U : 0U); __u8 __x86_l_pp_flags_width = (((((8U))) == 0U) ? 1U : 0U); __u8 __x86_l_pp_width = (__x86_l_pp_flags_width == 1U) ? 8U : (((8U))); __u64 __x86_l_pp_step = (__u64)((__x86_l_pp_width) == 1U ? 1U : (__x86_l_pp_width) == 2U ? 2U : (__x86_l_pp_width) == 4U ? 4U : 8U); if (__x86_l_pp_dir == 0U) { __u64 __x86_l_pp_value = ({ __u8 __x86_rd_reg = ((0xffU)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(-__x86_l_pp_step))); do { do { __u64 __x86_sv_index=(((__u64)((__s64)(long)__x86_rsp.ptr) + (__u64)(8U))),__x86_sv_width=x86_width_effective((__x86_l_pp_width)); do { __u64 __x86_sv_start=(__u64)(0)*8U; if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); do { __s64 __x86_loss_off=(((__s64)(long)__x86_rsp.ptr)); __u8 __x86_loss_width=x86_width_effective((__x86_l_pp_width)); __u64 __x86_loss_value=((__x86_l_pp_value)); do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off) + (__u64)(8U)); if (((__u8)((((x86_width_effective(__x86_loss_width)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (__x86_loss_value); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((__x86_loss_width)); __u64 __x86_stw_narrowed = ((__x86_loss_value)) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); if (__x86_loss_off<((__s64)(long)__x86_rsp.ptr)) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_loss_i=0; __x86_loss_i<8U; ++__x86_loss_i) if (__x86_loss_i<__x86_loss_width && __x86_loss_off+__x86_loss_i<((__s64)(long)__x86_rsp.ptr)) do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off+__x86_loss_i) + (__u64)(8U)); if (((__u8)((((x86_width_effective(1U)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((1U)); __u64 __x86_stw_narrowed = ((({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }))) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); } } while(0); } while(0); } else { __u64 __x86_l_pp_value = ({ __u64 __x86_observed=({ __u64 __x86_str_index = ((__u64)(((__s64)(long)__x86_rsp.ptr)) + (__u64)(8U)); __u64 __x86_str_value; if (((__u8)((((x86_width_effective((__x86_l_pp_width))) == 8U) && (((((__u64)(__x86_str_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_str_value = __x86_stack_mem.q [((__u64)(__x86_str_index) >> 3)]; } else if (x86_width_effective((__x86_l_pp_width)) == 4U && (__x86_str_index & 3U) == 0) { __x86_str_value = __x86_stack_mem.d[__x86_str_index / 4U]; } else if (x86_width_effective((__x86_l_pp_width)) == 2U && (__x86_str_index & 1U) == 0) { __x86_str_value = __x86_stack_mem.w[__x86_str_index / 2U]; } else { volatile __u8 *__x86_str_bytes = __x86_stack_mem.b; __u8 __x86_str_width = x86_width_effective((__x86_l_pp_width)); __x86_str_value = __x86_str_bytes[__x86_str_index]; if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 1]))) << (8U * (__u32)(1))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 2]))) << (8U * (__u32)(2))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 3]))) << (8U * (__u32)(3))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 4]))) << (8U * (__u32)(4))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 5]))) << (8U * (__u32)(5))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 6]))) << (8U * (__u32)(6))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 7]))) << (8U * (__u32)(7))); } __x86_str_value; }); if ((__s64)((__s64)(long)__x86_rsp.ptr)<((__s64)(long)__x86_rsp.ptr)) __x86_observed=x86_apply_width(({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }),x86_width_effective(__x86_l_pp_width)); __x86_observed; }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)(__x86_l_pp_step))); do { __s64 __x86_release_old=((__s64)(long)__x86_rsp.ptr - __x86_l_pp_step), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); do { __s64 __x86_write_old_sp=(__s64)(long)__x86_rsp.ptr; __u8 __x86_wr_raw_width = ((__x86_l_pp_width)); __u8 __x86_wr_width = x86_width_effective(__x86_wr_raw_width); __u8 __x86_wr_shift = (0U); __u64 __x86_wr_next = ((__x86_l_pp_value)); union x86_sim_gpr __x86_wr_cell = { .ptr = ((((((3U))))) == 0U ? __x86_rax.ptr : (((((3U))))) == 1U ? __x86_rcx.ptr : (((((3U))))) == 2U ? __x86_rdx.ptr : (((((3U))))) == 3U ? __x86_rbx.ptr : (((((3U))))) == 4U ? __x86_rsp.ptr : (((((3U))))) == 5U ? __x86_rbp.ptr : (((((3U))))) == 6U ? __x86_rsi.ptr : (((((3U))))) == 7U ? __x86_rdi.ptr : (((((3U))))) == 8U ? __x86_r8.ptr : (((((3U))))) == 9U ? __x86_r9.ptr : (((((3U))))) == 10U ? __x86_r10.ptr : (((((3U))))) == 11U ? __x86_r11.ptr : (((((3U))))) == 12U ? __x86_r12.ptr : (((((3U))))) == 13U ? __x86_r13.ptr : (((((3U))))) == 14U ? __x86_r14.ptr : (((((3U))))) == 15U ? __x86_r15.ptr : (void *)0) }; __u8 __x86_wr_cell_tag = ({ __u8 __x86_l_tag = 0U; switch (((((3U))))) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }); if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 0U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u8 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { if ((__x86_wr_shift) == 8U) (__x86_wr_cell).b[1] = __kprog_x86_lane; else (__x86_wr_cell).b[0] = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; if ((__x86_wr_shift) == 8U) __kprog_x86_partial.b[1] = __kprog_x86_lane; else __kprog_x86_partial.b[0] = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); if ((__x86_wr_shift) == 8U) __kprog_x86_bits = (__kprog_x86_bits & ~0xff00ULL) | ((__u64)__kprog_x86_lane << 8); else __kprog_x86_bits = (__kprog_x86_bits & ~0xffULL) | __kprog_x86_lane; (__x86_wr_cell).ptr = (void *)(long)__kprog_x86_bits; } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 1U) { if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr + __x86_native_stack_base); else if (__x86_wr_cell_tag == 4U) __x86_wr_cell.ptr = (void *)(long)({ __u64 __x86_stack_delta = (__u64)(long)(__x86_wr_cell.ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); do { __u16 __kprog_x86_lane = (__x86_wr_next); if ((__x86_wr_cell_tag) == (0U)) { (__x86_wr_cell).w = __kprog_x86_lane; } else { volatile union { void *ptr; __u16 w; __u8 b[8]; } __kprog_x86_partial = { .ptr = (__x86_wr_cell).ptr }; __kprog_x86_partial.w = __kprog_x86_lane; __u64 __kprog_x86_bits = (__u64)(long)__kprog_x86_partial.ptr; __asm__ volatile("" : "+r"(__kprog_x86_bits)); (__x86_wr_cell).ptr = (void *)(long)((__kprog_x86_bits & ~0xffffULL) | __kprog_x86_lane); } (__x86_wr_cell_tag) = (0U); } while (0); } else if (( (((__u8)((__x86_wr_width))) == 1U) ? 0U : ( (((__u8)((__x86_wr_width))) == 2U) ? 1U : ( (((__u8)((__x86_wr_width))) == 4U) ? 2U : 3U))) == 2U) { __x86_wr_next=({ __u32 __x86_word=(__x86_wr_next); asm volatile("%0 = %0" : "+w"(__x86_word)); (__u64)__x86_word; }); do { (__x86_wr_cell).ptr = (void *)(long)(__u32)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } else { do { (__x86_wr_cell).ptr = (void *)(long)(__u64)(__x86_wr_next); (__x86_wr_cell_tag) = (0U); } while (0); } if ((((((3U))))) == 4U) __x86_wr_cell.ptr = (void *)(long)((__u64)(long)__x86_wr_cell.ptr - __x86_native_stack_base); void *__x86_wr_next_ptr = __x86_wr_cell.ptr; __u8 __x86_wr_next_tag = __x86_wr_cell_tag; switch (((((3U))))) { case 0U: __x86_rax.ptr = __x86_wr_next_ptr; __x86_rax_tag = __x86_wr_next_tag; break; case 1U: __x86_rcx.ptr = __x86_wr_next_ptr; __x86_rcx_tag = __x86_wr_next_tag; break; case 2U: __x86_rdx.ptr = __x86_wr_next_ptr; __x86_rdx_tag = __x86_wr_next_tag; break; case 3U: __x86_rbx.ptr = __x86_wr_next_ptr; __x86_rbx_tag = __x86_wr_next_tag; break; case 4U: __x86_rsp.ptr = __x86_wr_next_ptr; __x86_rsp_tag = __x86_wr_next_tag; break; case 5U: __x86_rbp.ptr = __x86_wr_next_ptr; __x86_rbp_tag = __x86_wr_next_tag; break; case 6U: __x86_rsi.ptr = __x86_wr_next_ptr; __x86_rsi_tag = __x86_wr_next_tag; break; case 7U: __x86_rdi.ptr = __x86_wr_next_ptr; __x86_rdi_tag = __x86_wr_next_tag; break; case 8U: __x86_r8.ptr = __x86_wr_next_ptr; __x86_r8_tag = __x86_wr_next_tag; break; case 9U: __x86_r9.ptr = __x86_wr_next_ptr; __x86_r9_tag = __x86_wr_next_tag; break; case 10U: __x86_r10.ptr = __x86_wr_next_ptr; __x86_r10_tag = __x86_wr_next_tag; break; case 11U: __x86_r11.ptr = __x86_wr_next_ptr; __x86_r11_tag = __x86_wr_next_tag; break; case 12U: __x86_r12.ptr = __x86_wr_next_ptr; __x86_r12_tag = __x86_wr_next_tag; break; case 13U: __x86_r13.ptr = __x86_wr_next_ptr; __x86_r13_tag = __x86_wr_next_tag; break; case 14U: __x86_r14.ptr = __x86_wr_next_ptr; __x86_r14_tag = __x86_wr_next_tag; break; case 15U: __x86_r15.ptr = __x86_wr_next_ptr; __x86_r15_tag = __x86_wr_next_tag; break; default: break; } if ((((((3U)))))==4U) do { __s64 __x86_release_old=(__x86_write_old_sp), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); } while (0); } } while (0); } else { __u8 __x86_pp_width = (8U) ? (8U) : 8U; __u64 __x86_pp_value = ({ __u64 __x86_observed=({ __u64 __x86_str_index = ((__u64)(((__s64)(long)__x86_rsp.ptr)) + (__u64)(8U)); __u64 __x86_str_value; if (((__u8)((((x86_width_effective((__x86_pp_width))) == 8U) && (((((__u64)(__x86_str_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_str_value = __x86_stack_mem.q [((__u64)(__x86_str_index) >> 3)]; } else if (x86_width_effective((__x86_pp_width)) == 4U && (__x86_str_index & 3U) == 0) { __x86_str_value = __x86_stack_mem.d[__x86_str_index / 4U]; } else if (x86_width_effective((__x86_pp_width)) == 2U && (__x86_str_index & 1U) == 0) { __x86_str_value = __x86_stack_mem.w[__x86_str_index / 2U]; } else { volatile __u8 *__x86_str_bytes = __x86_stack_mem.b; __u8 __x86_str_width = x86_width_effective((__x86_pp_width)); __x86_str_value = __x86_str_bytes[__x86_str_index]; if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 1]))) << (8U * (__u32)(1))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 2]))) << (8U * (__u32)(2))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 3]))) << (8U * (__u32)(3))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 4]))) << (8U * (__u32)(4))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 5]))) << (8U * (__u32)(5))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 6]))) << (8U * (__u32)(6))); if (((__u8)((((__x86_str_width) == 1U ? 0x01U : ((__x86_str_width) == 2U ? 0x03U : ((__x86_str_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_str_value |= (((__u64)((__u8)(__x86_str_bytes[__x86_str_index + 7]))) << (8U * (__u32)(7))); } __x86_str_value; }); if ((__s64)((__s64)(long)__x86_rsp.ptr)<((__s64)(long)__x86_rsp.ptr)) __x86_observed=x86_apply_width(({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }),x86_width_effective(__x86_pp_width)); __x86_observed; }); __x86_rsp.ptr = ((__u8 *)(unsigned long)((__u64)(unsigned long)(__x86_rsp.ptr) + (__u64)((__u64)((__x86_pp_width) == 1U ? 1U : (__x86_pp_width) == 2U ? 2U : (__x86_pp_width) == 4U ? 4U : 8U)))); do { __s64 __x86_release_old=((__s64)(long)__x86_rsp.ptr - ((__x86_pp_width) == 1U ? 1U : (__x86_pp_width) == 2U ? 2U : (__x86_pp_width) == 4U ? 4U : 8U)), __x86_release_new=((__s64)(long)__x86_rsp.ptr); if (__x86_release_new>__x86_release_old) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_release_i=0; __x86_release_i<8U; ++__x86_release_i) { __s64 __x86_release_off=(__s64)__x86_release_i-(__s64)8U; if (__x86_release_off>=__x86_release_old && __x86_release_off<__x86_release_new) __x86_stack_mem.b[__x86_release_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } do { __s64 __x86_sv_sp=(__s64)(long)__x86_rsp.ptr; do { if ((__s64)((__u64)(0)*8U)-(__s64)8U<__x86_sv_sp) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); } } while(0); __s64 __x86_pp_disp = ((__s64)({ __s64 __kprog_x86_mo_disp = (((x86_simm(0)))); int __kprog_x86_mo_has_index = ((((__u8)(((((__u8)(((0)) & 0xffU))) != 0xffU) ? 1 : 0)))) ? 1 : 0; __u64 __kprog_x86_mo_result = (__u64)__kprog_x86_mo_disp; if (__kprog_x86_mo_has_index) { __u8 __kprog_x86_mo_scale = ((__u8)((((((0)))) >> 8) & 0xffU)); __u64 __kprog_x86_mo_index = (((((__u8)(((((__u8)(((0)) & 0xffU))) != 0xffU) ? 1 : 0)) ? ({ __u8 __x86_rd_reg = ((((__u8)(((0)) & 0xffU)))); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }) : 0))); __kprog_x86_mo_result += (__kprog_x86_mo_scale < 64U ? (__kprog_x86_mo_index << __kprog_x86_mo_scale) : 0); } (__s64)__kprog_x86_mo_result; })); if ((3U) == 4U) do { do { __u64 __x86_sv_index=(((__u64)((__s64)(long)__x86_rsp.ptr + __x86_pp_disp) + (__u64)(8U))),__x86_sv_width=x86_width_effective((__x86_pp_width)); do { __u64 __x86_sv_start=(__u64)(0)*8U; if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); do { __s64 __x86_loss_off=(((__s64)(long)__x86_rsp.ptr + __x86_pp_disp)); __u8 __x86_loss_width=x86_width_effective((__x86_pp_width)); __u64 __x86_loss_value=((__x86_pp_value)); do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off) + (__u64)(8U)); if (((__u8)((((x86_width_effective(__x86_loss_width)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (__x86_loss_value); } else if (x86_width_effective(__x86_loss_width) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (__x86_loss_value); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((__x86_loss_width)); __u64 __x86_stw_narrowed = ((__x86_loss_value)) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); if (__x86_loss_off<((__s64)(long)__x86_rsp.ptr)) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_loss_i=0; __x86_loss_i<8U; ++__x86_loss_i) if (__x86_loss_i<__x86_loss_width && __x86_loss_off+__x86_loss_i<((__s64)(long)__x86_rsp.ptr)) do { __u64 __x86_stw_index = ((__u64)(__x86_loss_off+__x86_loss_i) + (__u64)(8U)); if (((__u8)((((x86_width_effective(1U)) == 8U) && (((((__u64)(__x86_stw_index) & 7U) == 0U) ? 1 : 0))) ? 1 : 0))) { __x86_stack_mem.q [((__u64)(__x86_stw_index) >> 3)] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 4U && (__x86_stw_index & 3U) == 0) { __x86_stack_mem.d[__x86_stw_index / 4U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else if (x86_width_effective(1U) == 2U && (__x86_stw_index & 1U) == 0) { __x86_stack_mem.w[__x86_stw_index / 2U] = (({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); })); } else { do { volatile __u8 *__x86_stw_bytes = (&__x86_stack_mem.b[__x86_stw_index]); __u8 __x86_stw_width = x86_width_effective((1U)); __u64 __x86_stw_narrowed = ((({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }))) & x86_width_mask(__x86_stw_width); __x86_stw_bytes[0] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(0)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (1)) & 1U))) __x86_stw_bytes[1] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(1)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (2)) & 1U))) __x86_stw_bytes[2] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(2)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (3)) & 1U))) __x86_stw_bytes[3] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(3)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (4)) & 1U))) __x86_stw_bytes[4] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(4)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (5)) & 1U))) __x86_stw_bytes[5] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(5)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (6)) & 1U))) __x86_stw_bytes[6] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(6)))); if (((__u8)((((__x86_stw_width) == 1U ? 0x01U : ((__x86_stw_width) == 2U ? 0x03U : ((__x86_stw_width) == 4U ? 0x0fU : 0xffU))) >> (7)) & 1U))) __x86_stw_bytes[7] = ((__u8)(((__u64)(__x86_stw_narrowed)) >> (8U * (__u32)(7)))); } while (0); } } while (0); } } while(0); } while(0); else do { void *__x86_st_addr=((__u8 *)((3U) == 0U ? __x86_rax.ptr : (3U) == 1U ? __x86_rcx.ptr : (3U) == 2U ? __x86_rdx.ptr : (3U) == 3U ? __x86_rbx.ptr : (3U) == 4U ? __x86_rsp.ptr : (3U) == 5U ? __x86_rbp.ptr : (3U) == 6U ? __x86_rsi.ptr : (3U) == 7U ? __x86_rdi.ptr : (3U) == 8U ? __x86_r8.ptr : (3U) == 9U ? __x86_r9.ptr : (3U) == 10U ? __x86_r10.ptr : (3U) == 11U ? __x86_r11.ptr : (3U) == 12U ? __x86_r12.ptr : (3U) == 13U ? __x86_r13.ptr : (3U) == 14U ? __x86_r14.ptr : (3U) == 15U ? __x86_r15.ptr : (void *)0) + __x86_pp_disp); __u8 __x86_st_width=(__x86_pp_width),__x86_st_tag=(({ __u8 __x86_l_tag = 0U; switch (3U) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; })); __u64 __x86_st_value=(__x86_pp_value); if (__x86_st_tag==4U) do { __u64 __x86_sv_index=((__u64)(long)__x86_st_addr-(__u64)(long)&__x86_stack_mem.b[0]),__x86_sv_width=x86_width_effective(__x86_st_width); do { __u64 __x86_sv_start=(__u64)(0)*8U; if (__x86_sv_index-__x86_sv_start<8U || __x86_sv_start-__x86_sv_index<__x86_sv_width) do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); } while(0); else if (__x86_st_tag==0U) do { do { __x86_stack_value_tag_0=0U; __x86_stack_value_ptr_0=0; } while(0); } while(0); kprog_x86_mem_store((__x86_st_addr), (__x86_st_width), (__x86_st_value)); if (__x86_st_tag==4U) { __s64 __x86_st_off=({ __u64 __x86_alias_delta=(__u64)(long)(__x86_st_addr)-(__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_alias_delta)); (__s64)__x86_alias_delta; }); if (__x86_st_off<((__s64)(long)__x86_rsp.ptr)) {
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma unroll
# 80 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 for (__u32 __x86_st_i=0; __x86_st_i<8U; ++__x86_st_i) if (__x86_st_i<x86_width_effective(__x86_st_width) && __x86_st_off+__x86_st_i<((__s64)(long)__x86_rsp.ptr)) ((volatile __u8 *)__x86_st_addr)[__x86_st_i]=(__u8)({ (void)(6); (unsigned long)(*(volatile unsigned long long *)&kprog_unspecified_input[0]); }); } } } while (0); } } while (0);
x86_l_34:

 do { if (__x86_rsp.ptr != (void *)0) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); return (__u32)({ __u8 __x86_rd_reg = ((0U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } while (0);
x86_l_39:

 do { if (__x86_rsp.ptr != (void *)0) do { __asm__ volatile("r0 = 0; *(u64 *)(r0 + 0) = r0; exit;" ::: "r0", "memory"); __builtin_unreachable(); } while (0); return (__u32)({ __u8 __x86_rd_reg = ((0U)); __u8 __x86_rd_raw_width = (8U); __u8 __x86_rd_width = x86_width_effective(__x86_rd_raw_width); __u8 __x86_rd_shift = (0U); void *__x86_rd_ptr = ((__x86_rd_reg) == 0U ? __x86_rax.ptr : (__x86_rd_reg) == 1U ? __x86_rcx.ptr : (__x86_rd_reg) == 2U ? __x86_rdx.ptr : (__x86_rd_reg) == 3U ? __x86_rbx.ptr : (__x86_rd_reg) == 4U ? __x86_rsp.ptr : (__x86_rd_reg) == 5U ? __x86_rbp.ptr : (__x86_rd_reg) == 6U ? __x86_rsi.ptr : (__x86_rd_reg) == 7U ? __x86_rdi.ptr : (__x86_rd_reg) == 8U ? __x86_r8.ptr : (__x86_rd_reg) == 9U ? __x86_r9.ptr : (__x86_rd_reg) == 10U ? __x86_r10.ptr : (__x86_rd_reg) == 11U ? __x86_r11.ptr : (__x86_rd_reg) == 12U ? __x86_r12.ptr : (__x86_rd_reg) == 13U ? __x86_r13.ptr : (__x86_rd_reg) == 14U ? __x86_r14.ptr : (__x86_rd_reg) == 15U ? __x86_r15.ptr : (void *)0); __u64 __x86_rd_value = (__u64)(long)__x86_rd_ptr; if (__x86_rd_reg == 4U) __x86_rd_value += __x86_native_stack_base; else if (({ __u8 __x86_l_tag = 0U; switch (__x86_rd_reg) { case 0U: __x86_l_tag = __x86_rax_tag; break; case 1U: __x86_l_tag = __x86_rcx_tag; break; case 2U: __x86_l_tag = __x86_rdx_tag; break; case 3U: __x86_l_tag = __x86_rbx_tag; break; case 4U: __x86_l_tag = __x86_rsp_tag; break; case 5U: __x86_l_tag = __x86_rbp_tag; break; case 6U: __x86_l_tag = __x86_rsi_tag; break; case 7U: __x86_l_tag = __x86_rdi_tag; break; case 8U: __x86_l_tag = __x86_r8_tag; break; case 9U: __x86_l_tag = __x86_r9_tag; break; case 10U: __x86_l_tag = __x86_r10_tag; break; case 11U: __x86_l_tag = __x86_r11_tag; break; case 12U: __x86_l_tag = __x86_r12_tag; break; case 13U: __x86_l_tag = __x86_r13_tag; break; case 14U: __x86_l_tag = __x86_r14_tag; break; case 15U: __x86_l_tag = __x86_r15_tag; break; default: break; } __x86_l_tag; }) == 4U) __x86_rd_value = ({ __u64 __x86_stack_delta = (__u64)(long)(__x86_rd_ptr) - (__u64)(long)((void *)((__u8 *)(unsigned long)((__u64)(unsigned long)(&__x86_stack_mem.b[0]) + (__u64)(((__u64)((0)) + (__u64)(8U)))))); asm volatile("" : "+r"(__x86_stack_delta)); __x86_stack_delta + __x86_native_stack_base; }); (((__x86_rd_value) >> ((__x86_rd_width) == 1U ? (__x86_rd_shift) : 0U)) & (((__x86_rd_width)) == 1U ? 0xffULL : (((__x86_rd_width)) == 2U ? 0xffffULL : (((__x86_rd_width)) == 4U ? 0xffffffffULL : 0xffffffffffffffffULL)))); }); } while (0);
}

char LICENSE[]
# 89 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma GCC diagnostic push
# 89 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma GCC diagnostic ignored "-Wignored-attributes"
# 89 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 __attribute__((section("license"), used))
# 89 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
#pragma GCC diagnostic pop
# 89 "/workspaces/kprog-raw/verified/20261113-kfunc/model-retry3/generated/trusted_x86.bpf.c"
 = "GPL";
