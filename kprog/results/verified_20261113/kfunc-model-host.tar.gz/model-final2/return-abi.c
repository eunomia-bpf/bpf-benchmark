#include <stdint.h>
#include <assert.h>
#include <linux/types.h>
#define X86_RAX 0
#define X86_RDI 1
#define X86_RSI 2
#define X86_RDX 3
#define X86_WIDTH_32 32
#define X86_WIDTH_64 64
#define X86_SIM_L_HELPER_ARG_PTR(R) ((void *)(uintptr_t)registers[R])
#define X86_SIM_L_HELPER_CTX_PTR(R) X86_SIM_L_HELPER_ARG_PTR(R)
#define X86_SIM_L_READ_REG(R) registers[R]
#define X86_SIM_L_WRITE_REG_WIDTH(R,V,W) (registers[R]=(W)==32 ? (uint32_t)(V):(uint64_t)(V))
#define X86_SIM_L_STACK_VALUES_CALL_FRAME() ((void)0)
#define X86_SIM_L_HELPER_REGISTER_CLOBBERS() (++clobbers)
static uint64_t registers[4]; static unsigned clobbers; static int result;
__s32 bpf_strnstr(const __u8 * a, const __u8 * b, __u64 length) {
    assert(a==(void *)11 && b==(void *)23 && length==37); return result;
}
int main(void) {
    const int cases[]={-1,-34,0,1,2147483647,(-2147483647-1)};
    registers[1]=11;registers[2]=23;registers[3]=37;
    for(unsigned i=0;i<sizeof(cases)/sizeof(cases[0]);++i) {
        result=cases[i];
        do {
            __u64 __kfunc_result = (__u64)bpf_strnstr((const __u8 *)(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)), (const __u8 *)(X86_SIM_L_HELPER_CTX_PTR(X86_RSI)), (__u64)((__u64)(X86_SIM_L_READ_REG(X86_RDX))));
            X86_SIM_L_WRITE_REG_WIDTH(X86_RAX, __kfunc_result, X86_WIDTH_32);
            X86_SIM_L_STACK_VALUES_CALL_FRAME();
            X86_SIM_L_HELPER_REGISTER_CLOBBERS();
        } while (0);
assert(registers[0]==(uint32_t)result);assert(clobbers==i+1);}}
