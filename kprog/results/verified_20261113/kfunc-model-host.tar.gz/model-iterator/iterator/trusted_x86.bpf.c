#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 24U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

struct bpf_iter_num;
extern __s32 bpf_strnstr(const __u8 *, const __u8 *, __u64) __ksym __weak;
extern void kprog_missing_function(void) __ksym __weak;
extern __s32 bpf_iter_num_new(struct bpf_iter_num *, __s32, __s32) __ksym __weak;
extern __s32 * bpf_iter_num_next(struct bpf_iter_num *) __ksym __weak;
extern void bpf_iter_num_destroy(struct bpf_iter_num *) __ksym __weak;
SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2:
	/* 0x2: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   rax */
	X86_SIM_L_EXEC_PUSH_OP(X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4:
	do {
	    __u64 __kf_left = (__u64)(long)&bpf_iter_num_new;
	    __u64 __kf_right = 0ULL;
	    __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, X86_WIDTH_64);
	    X86_SIM_L_SET_SUB_FLAGS(__kf_left, __kf_right, __kf_value, X86_WIDTH_64);
	} while (0);
x86_l_c:
	/* 0xc: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_11:
	/* 0x11: je     53 <iterator+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11, 0x53, x86_l_53);
x86_l_13:
	do {
	    __u64 __kf_left = (__u64)(long)&bpf_iter_num_next;
	    __u64 __kf_right = 0ULL;
	    __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, X86_WIDTH_64);
	    X86_SIM_L_SET_SUB_FLAGS(__kf_left, __kf_right, __kf_value, X86_WIDTH_64);
	} while (0);
x86_l_1b:
	/* 0x1b: je     53 <iterator+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b, 0x53, x86_l_53);
x86_l_1d:
	do {
	    __u64 __kf_left = (__u64)(long)&bpf_iter_num_destroy;
	    __u64 __kf_right = 0ULL;
	    __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, X86_WIDTH_64);
	    X86_SIM_L_SET_SUB_FLAGS(__kf_left, __kf_right, __kf_value, X86_WIDTH_64);
	} while (0);
x86_l_25:
	/* 0x25: je     53 <iterator+0x53> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25, 0x53, x86_l_53);
x86_l_27:
	/* 0x27: mov    r14,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSP, X86_WIDTH_64);
x86_l_2a:
	/* 0x2a: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2c:
	/* 0x2c: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_2f:
	/* 0x2f: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_31:
	/* 0x31: mov    edx,0x3 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 3ULL);
x86_l_36:
	do {
	    __u64 __kfunc_result = (__u64)bpf_iter_num_new((struct bpf_iter_num *)(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)), (__s32)((__u32)(X86_SIM_L_READ_REG(X86_RSI))), (__s32)((__u32)(X86_SIM_L_READ_REG(X86_RDX))));
	    X86_SIM_L_WRITE_REG_WIDTH(X86_RAX, __kfunc_result, X86_WIDTH_32);
	    if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_STACK)
	        X86_SIM_L_STACK_VALUES_ERASE_BYTES((__u64)(long)X86_SIM_L_HELPER_ARG_PTR(X86_RDI) - (__u64)(long)&__x86_stack_mem.b[0], 8ULL);
	    else if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR) X86_SIM_L_STACK_VALUES_CLEAR();
	    X86_SIM_L_STACK_VALUES_CALL_FRAME();
	    X86_SIM_L_HELPER_REGISTER_CLOBBERS();
	} while (0);
x86_l_3b:
	/* 0x3b: mov    rdi,r14 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R14, X86_WIDTH_64);
x86_l_3e:
	do {
	    void *__kfunc_result = (void *)bpf_iter_num_next((struct bpf_iter_num *)(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)));
	    X86_SIM_L_WRITE_REG_PTR_TAG(X86_RAX, __kfunc_result, X86_SIM_TAG_MAP_VALUE);
	    if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_STACK)
	        X86_SIM_L_STACK_VALUES_ERASE_BYTES((__u64)(long)X86_SIM_L_HELPER_ARG_PTR(X86_RDI) - (__u64)(long)&__x86_stack_mem.b[0], 8ULL);
	    else if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR) X86_SIM_L_STACK_VALUES_CLEAR();
	    X86_SIM_L_STACK_VALUES_CALL_FRAME();
	    X86_SIM_L_HELPER_REGISTER_CLOBBERS();
	} while (0);
x86_l_43:
	/* 0x43: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_46:
	/* 0x46: je     4b <iterator+0x4b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x46, 0x4b, x86_l_4b);
x86_l_48:
	/* 0x48: movsxd rbx,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RBX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_4b:
	/* 0x4b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_4e:
	do {
	    bpf_iter_num_destroy((struct bpf_iter_num *)(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)));
	    X86_SIM_L_WRITE_REG_WIDTH(X86_RAX, X86_SIM_L_UNSPECIFIED(), X86_WIDTH_64);
	    if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_STACK)
	        X86_SIM_L_STACK_VALUES_ERASE_BYTES((__u64)(long)X86_SIM_L_HELPER_ARG_PTR(X86_RDI) - (__u64)(long)&__x86_stack_mem.b[0], 8ULL);
	    else if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR) X86_SIM_L_STACK_VALUES_CLEAR();
	    X86_SIM_L_STACK_VALUES_CALL_FRAME();
	    X86_SIM_L_HELPER_REGISTER_CLOBBERS();
	} while (0);
x86_l_53:
	/* 0x53: mov    rax,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RBX, X86_WIDTH_64);
x86_l_56:
	/* 0x56: add    rsp,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_5a:
	/* 0x5a: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5b:
	/* 0x5b: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5d:
	/* 0x5d: jmp    62 <iterator+0x62> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_62:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
