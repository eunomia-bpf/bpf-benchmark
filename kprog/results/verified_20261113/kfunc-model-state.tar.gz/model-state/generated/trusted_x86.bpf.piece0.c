#line 1 "/workspaces/kprog-raw/verified/20261113-kfunc/model-state/generated/trusted_x86.bpf.c"
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

struct bpf_iter_num;
extern __s32 bpf_strnstr(const __u8 *, const __u8 *, __u64) __ksym __weak;
extern void kprog_missing_function(void) __ksym __weak;
extern __s32 bpf_iter_num_new(struct bpf_iter_num *, __s32, __s32) __ksym __weak;
extern __s32 * bpf_iter_num_next(struct bpf_iter_num *) __ksym __weak;
extern void bpf_iter_num_destroy(struct bpf_iter_num *) __ksym __weak;
SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
#pragma kprog_preprocessed_piece
#line 26 "/workspaces/kprog-raw/verified/20261113-kfunc/model-state/generated/trusted_x86.bpf.c"
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: mov    ebx,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_32, 7ULL);
x86_l_6:
	do {
	    __u64 __kf_left = (__u64)(long)&bpf_strnstr;
	    __u64 __kf_right = 0ULL;
	    __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, X86_WIDTH_64);
	    X86_SIM_L_SET_SUB_FLAGS(__kf_left, __kf_right, __kf_value, X86_WIDTH_64);
	} while (0);
x86_l_e:
	/* 0xe: je     1d <entry+0x1d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe, 0x1d, x86_l_1d);
x86_l_10:
	/* 0x10: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_12:
	/* 0x12: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14:
	/* 0x14: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_16:
	do {
	    __u64 __kfunc_result = (__u64)bpf_strnstr((const __u8 *)(X86_SIM_L_HELPER_CTX_PTR(X86_RDI)), (const __u8 *)(X86_SIM_L_HELPER_CTX_PTR(X86_RSI)), (__u64)((__u64)(X86_SIM_L_READ_REG(X86_RDX))));
	    X86_SIM_L_WRITE_REG_WIDTH(X86_RAX, __kfunc_result, X86_WIDTH_32);
	    if (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_STACK || (X86_SIM_L_REG_TAG(X86_RDI) == X86_SIM_TAG_SCALAR && X86_SIM_L_READ_REG(X86_RDI) != 0)) X86_SIM_L_STACK_VALUES_CLEAR();
	    if (X86_SIM_L_REG_TAG(X86_RSI) == X86_SIM_TAG_STACK || (X86_SIM_L_REG_TAG(X86_RSI) == X86_SIM_TAG_SCALAR && X86_SIM_L_READ_REG(X86_RSI) != 0)) X86_SIM_L_STACK_VALUES_CLEAR();
	    X86_SIM_L_STACK_VALUES_CALL_FRAME();
	    X86_SIM_L_HELPER_REGISTER_CLOBBERS();
	} while (0);
x86_l_1b:
	/* 0x1b: mov    ebx,eax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_32);
x86_l_1d:
	do {
	    __u64 __kf_left = (__u64)(long)&kprog_missing_function;
	    __u64 __kf_right = 0ULL;
	    __u64 __kf_value = x86_apply_width(__kf_left - __kf_right, X86_WIDTH_64);
	    X86_SIM_L_SET_SUB_FLAGS(__kf_left, __kf_right, __kf_value, X86_WIDTH_64);
	} while (0);
x86_l_25:
	/* 0x25: je     30 <entry+0x30> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25, 0x30, x86_l_30);
x86_l_27:
	/* 0x27: xor    edi,edi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RDI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_29:
	__x86_sim_unresolved_indirect_target();
x86_l_2e:
	/* 0x2e: add    ebx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_32, X86_ALU_ADD);
x86_l_30:
	/* 0x30: movsxd rax,ebx */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVSX_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_WIDTH_32);
x86_l_33:
	/* 0x33: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_34:
	/* 0x34: jmp    39 <entry+0x39> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_39:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();

