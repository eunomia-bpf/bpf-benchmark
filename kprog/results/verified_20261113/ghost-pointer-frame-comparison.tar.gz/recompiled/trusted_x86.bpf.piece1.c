#line 1 "/workspaces/kprog-raw/verified/20261113-ghost-pointer-lifetime/recompiled/trusted_x86.bpf.c"
#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 248U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26) M(27) M(28) M(29) M(30)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 addr4lpm_maps[] __ksym;
extern __u8 addr6lpm_maps[] __ksym;
extern __u8 argfilter_maps[] __ksym;
extern __u8 filter_map[] __ksym;
extern __u8 heap_ro_zero[] __ksym;
extern __u8 kprobe_calls[] __ksym;
extern __u8 process_call_heap[] __ksym;
extern __u8 retprobe_map[] __ksym;
extern __u8 string_maps_0[] __ksym;
extern __u8 string_maps_1[] __ksym;
extern __u8 string_maps_10[] __ksym;
extern __u8 string_maps_2[] __ksym;
extern __u8 string_maps_3[] __ksym;
extern __u8 string_maps_4[] __ksym;
extern __u8 string_maps_5[] __ksym;
extern __u8 string_maps_6[] __ksym;
extern __u8 string_maps_7[] __ksym;
extern __u8 string_maps_8[] __ksym;
extern __u8 string_maps_9[] __ksym;
extern __u8 string_maps_heap[] __ksym;
extern __u8 string_postfix_maps[] __ksym;
extern __u8 string_postfix_maps_heap[] __ksym;
extern __u8 string_prefix_maps[] __ksym;
extern __u8 string_prefix_maps_heap[] __ksym;
extern __u8 substring_map[] __ksym;
SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
#pragma kprog_preprocessed_piece
#line 6676 "/workspaces/kprog-raw/verified/20261113-ghost-pointer-lifetime/recompiled/trusted_x86.bpf.c"
x86_l_1ca2:
	/* 0x1ca2: jg     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1ca2, 0x1bb3, x86_l_1bb3);
x86_l_1ca8:
	/* 0x1ca8: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cab:
	/* 0x1cab: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1cae:
	/* 0x1cae: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cae, 0x1da6, x86_l_1da6);
x86_l_1cb4:
	/* 0x1cb4: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1cb7:
	/* 0x1cb7: jg     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1cb7, 0x1bb3, x86_l_1bb3);
x86_l_1cbd:
	/* 0x1cbd: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1cc0:
	/* 0x1cc0: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cc0, 0x1da6, x86_l_1da6);
x86_l_1cc6:
	/* 0x1cc6: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1cc9:
	/* 0x1cc9: jg     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1cc9, 0x1bb3, x86_l_1bb3);
x86_l_1ccf:
	/* 0x1ccf: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1cd2:
	/* 0x1cd2: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cd2, 0x1da6, x86_l_1da6);
x86_l_1cd8:
	/* 0x1cd8: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1cdb:
	/* 0x1cdb: jg     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1cdb, 0x1bb3, x86_l_1bb3);
x86_l_1ce1:
	/* 0x1ce1: jmp    1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1ce1, 0x1da6, x86_l_1da6);
x86_l_1ce6:
	/* 0x1ce6: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ce9:
	/* 0x1ce9: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_1cec:
	/* 0x1cec: jb     1d13 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cec, 0x1d13, x86_l_1d13);
x86_l_1cee:
	/* 0x1cee: cmp    edx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1cf1:
	/* 0x1cf1: je     1bca <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1cf1, 0x1bca, x86_l_1bca);
x86_l_1cf7:
	/* 0x1cf7: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_1cfa:
	/* 0x1cfa: jb     1d13 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1cfa, 0x1d13, x86_l_1d13);
x86_l_1cfc:
	/* 0x1cfc: cmp    edx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1cff:
	/* 0x1cff: je     1bca <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1cff, 0x1bca, x86_l_1bca);
x86_l_1d05:
	/* 0x1d05: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_1d08:
	/* 0x1d08: jb     1d13 <filter_32ty_selector_val+0x17e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d08, 0x1d13, x86_l_1d13);
x86_l_1d0a:
	/* 0x1d0a: cmp    edx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1d0d:
	/* 0x1d0d: je     1bca <filter_32ty_selector_val+0x35> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1d0d, 0x1bca, x86_l_1bca);
x86_l_1d13:
	/* 0x1d13: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_1d16:
	/* 0x1d16: ja     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d16, 0x1da6, x86_l_1da6);
x86_l_1d1c:
	/* 0x1d1c: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_1d1e:
	/* 0x1d1e: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_1d28:
	/* 0x1d28: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_1d2c:
	/* 0x1d2c: jb     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d2c, 0x1bb3, x86_l_1bb3);
x86_l_1d32:
	/* 0x1d32: jmp    1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1d32, 0x1da6, x86_l_1da6);
x86_l_1d34:
	/* 0x1d34: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d36:
	/* 0x1d36: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d39:
	/* 0x1d39: ja     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d39, 0x1bb3, x86_l_1bb3);
x86_l_1d3f:
	/* 0x1d3f: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d42:
	/* 0x1d42: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1d45:
	/* 0x1d45: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d45, 0x1da6, x86_l_1da6);
x86_l_1d47:
	/* 0x1d47: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1d4a:
	/* 0x1d4a: ja     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d4a, 0x1bb3, x86_l_1bb3);
x86_l_1d50:
	/* 0x1d50: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1d53:
	/* 0x1d53: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d53, 0x1da6, x86_l_1da6);
x86_l_1d55:
	/* 0x1d55: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1d58:
	/* 0x1d58: ja     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d58, 0x1bb3, x86_l_1bb3);
x86_l_1d5e:
	/* 0x1d5e: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1d61:
	/* 0x1d61: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d61, 0x1da6, x86_l_1da6);
x86_l_1d63:
	/* 0x1d63: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1d66:
	/* 0x1d66: ja     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1d66, 0x1bb3, x86_l_1bb3);
x86_l_1d6c:
	/* 0x1d6c: jmp    1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JMP(0x1d6c, 0x1da6, x86_l_1da6);
x86_l_1d6e:
	/* 0x1d6e: mov    ecx,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d70:
	/* 0x1d70: cmp    ecx,DWORD PTR [rdi+0x10] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 16ULL);
x86_l_1d73:
	/* 0x1d73: jb     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d73, 0x1bb3, x86_l_1bb3);
x86_l_1d79:
	/* 0x1d79: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d7c:
	/* 0x1d7c: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_1d7f:
	/* 0x1d7f: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d7f, 0x1da6, x86_l_1da6);
x86_l_1d81:
	/* 0x1d81: cmp    ecx,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1d84:
	/* 0x1d84: jb     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d84, 0x1bb3, x86_l_1bb3);
x86_l_1d8a:
	/* 0x1d8a: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1d8d:
	/* 0x1d8d: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d8d, 0x1da6, x86_l_1da6);
x86_l_1d8f:
	/* 0x1d8f: cmp    ecx,DWORD PTR [rdi+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 24ULL);
x86_l_1d92:
	/* 0x1d92: jb     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d92, 0x1bb3, x86_l_1bb3);
x86_l_1d98:
	/* 0x1d98: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_1d9b:
	/* 0x1d9b: jb     1da6 <filter_32ty_selector_val+0x211> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1d9b, 0x1da6, x86_l_1da6);
x86_l_1d9d:
	/* 0x1d9d: cmp    ecx,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1da0:
	/* 0x1da0: jb     1bb3 <filter_32ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1da0, 0x1bb3, x86_l_1bb3);
x86_l_1da6:
	/* 0x1da6: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1da8:
	/* 0x1da8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1da9 */
x86_l_1da9:
	/* 0x1da9: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1dac:
	/* 0x1dac: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1daf:
	/* 0x1daf: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_1db2:
	/* 0x1db2: ja     1e98 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1db2, 0x1e98, x86_l_1e98);
x86_l_1db8:
	/* 0x1db8: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_1dbd:
	/* 0x1dbd: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_1dc0:
	/* 0x1dc0: jae    1e98 <filter_32ty_range+0xef> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1dc0, 0x1e98, x86_l_1e98);
x86_l_1dc6:
	/* 0x1dc6: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1dc8:
	/* 0x1dc8: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1dcb:
	/* 0x1dcb: jne    1e33 <filter_32ty_range+0x8a> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1dcb, 0x1e33, x86_l_1e33);
x86_l_1dcd:
	/* 0x1dcd: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1dd2:
	/* 0x1dd2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1dd5:
	/* 0x1dd5: jg     1de0 <filter_32ty_range+0x37> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1dd5, 0x1de0, x86_l_1de0);
x86_l_1dd7:
	/* 0x1dd7: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1dda:
	/* 0x1dda: jle    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1dda, 0x1eae, x86_l_1eae);
x86_l_1de0:
	/* 0x1de0: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1de3:
	/* 0x1de3: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1de6:
	/* 0x1de6: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1de6, 0x1f4e, x86_l_1f4e);
x86_l_1dec:
	/* 0x1dec: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1def:
	/* 0x1def: jg     1dfa <filter_32ty_range+0x51> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1def, 0x1dfa, x86_l_1dfa);
x86_l_1df1:
	/* 0x1df1: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1df4:
	/* 0x1df4: jle    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1df4, 0x1eae, x86_l_1eae);
x86_l_1dfa:
	/* 0x1dfa: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1dfd:
	/* 0x1dfd: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1dfd, 0x1f4e, x86_l_1f4e);
x86_l_1e03:
	/* 0x1e03: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e06:
	/* 0x1e06: jg     1e11 <filter_32ty_range+0x68> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e06, 0x1e11, x86_l_1e11);
x86_l_1e08:
	/* 0x1e08: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1e0b:
	/* 0x1e0b: jle    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1e0b, 0x1eae, x86_l_1eae);
x86_l_1e11:
	/* 0x1e11: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1e14:
	/* 0x1e14: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e14, 0x1f4e, x86_l_1f4e);
x86_l_1e1a:
	/* 0x1e1a: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1e1c:
	/* 0x1e1c: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e1f:
	/* 0x1e1f: jg     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x1e1f, 0x1f50, x86_l_1f50);
x86_l_1e25:
	/* 0x1e25: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1e28:
	/* 0x1e28: jle    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_LE, 0x1e28, 0x1eae, x86_l_1eae);
x86_l_1e2e:
	/* 0x1e2e: jmp    1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x1e2e, 0x1f50, x86_l_1f50);
x86_l_1e33:
	/* 0x1e33: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e36:
	/* 0x1e36: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e39:
	/* 0x1e39: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1e3d:
	/* 0x1e3d: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1e40:
	/* 0x1e40: setle  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_LE);
x86_l_1e43:
	/* 0x1e43: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1e46:
	/* 0x1e46: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1e49:
	/* 0x1e49: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e49, 0x1f50, x86_l_1f50);
x86_l_1e4f:
	/* 0x1e4f: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e52:
	/* 0x1e52: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1e56:
	/* 0x1e56: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1e59:
	/* 0x1e59: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1e5d:
	/* 0x1e5d: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1e60:
	/* 0x1e60: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1e63:
	/* 0x1e63: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1e66:
	/* 0x1e66: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e66, 0x1f50, x86_l_1f50);
x86_l_1e6c:
	/* 0x1e6c: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e6f:
	/* 0x1e6f: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_1e73:
	/* 0x1e73: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1e76:
	/* 0x1e76: setle  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_LE);
x86_l_1e7a:
	/* 0x1e7a: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1e7d:
	/* 0x1e7d: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1e80:
	/* 0x1e80: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1e83:
	/* 0x1e83: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1e83, 0x1f50, x86_l_1f50);
x86_l_1e89:
	/* 0x1e89: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1e8c:
	/* 0x1e8c: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_1e8f:
	/* 0x1e8f: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1e92:
	/* 0x1e92: setle  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_LE);
x86_l_1e96:
	/* 0x1e96: jmp    1f0a <filter_32ty_range+0x161> */
	X86_SIM_X86_SUB_JMP(0x1e96, 0x1f0a, x86_l_1f0a);
x86_l_1e98:
	/* 0x1e98: mov    esi,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e9a:
	/* 0x1e9a: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_1e9d:
	/* 0x1e9d: jne    1eaf <filter_32ty_range+0x106> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x1e9d, 0x1eaf, x86_l_1eaf);
x86_l_1e9f:
	/* 0x1e9f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1ea4:
	/* 0x1ea4: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ea7:
	/* 0x1ea7: ja     1f12 <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ea7, 0x1f12, x86_l_1f12);
x86_l_1ea9:
	/* 0x1ea9: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1eac:
	/* 0x1eac: ja     1f12 <filter_32ty_range+0x169> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1eac, 0x1f12, x86_l_1f12);
x86_l_1eae:
	/* 0x1eae: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1eaf:
	/* 0x1eaf: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1eb2:
	/* 0x1eb2: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1eb5:
	/* 0x1eb5: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1eb9:
	/* 0x1eb9: cmp    esi,DWORD PTR [rdi+0x14] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1ebc:
	/* 0x1ebc: setbe  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_BE);
x86_l_1ebf:
	/* 0x1ebf: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1ec2:
	/* 0x1ec2: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_1ec5:
	/* 0x1ec5: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ec5, 0x1f50, x86_l_1f50);
x86_l_1ecb:
	/* 0x1ecb: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ece:
	/* 0x1ece: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1ed2:
	/* 0x1ed2: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1ed5:
	/* 0x1ed5: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_1ed9:
	/* 0x1ed9: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1edc:
	/* 0x1edc: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1edf:
	/* 0x1edf: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_1ee2:
	/* 0x1ee2: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1ee2, 0x1f50, x86_l_1f50);
x86_l_1ee4:
	/* 0x1ee4: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1ee7:
	/* 0x1ee7: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_1eeb:
	/* 0x1eeb: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1eee:
	/* 0x1eee: setbe  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_BE);
x86_l_1ef2:
	/* 0x1ef2: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_1ef5:
	/* 0x1ef5: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_1ef8:
	/* 0x1ef8: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_1efb:
	/* 0x1efb: jb     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1efb, 0x1f50, x86_l_1f50);
x86_l_1efd:
	/* 0x1efd: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f00:
	/* 0x1f00: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_1f03:
	/* 0x1f03: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1f06:
	/* 0x1f06: setbe  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_BE);
x86_l_1f0a:
	/* 0x1f0a: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f0d:
	/* 0x1f0d: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_1f10:
	/* 0x1f10: jmp    1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x1f10, 0x1f50, x86_l_1f50);
x86_l_1f12:
	/* 0x1f12: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f15:
	/* 0x1f15: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_1f18:
	/* 0x1f18: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f18, 0x1f4e, x86_l_1f4e);
x86_l_1f1a:
	/* 0x1f1a: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1f1d:
	/* 0x1f1d: ja     1f24 <filter_32ty_range+0x17b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f1d, 0x1f24, x86_l_1f24);
x86_l_1f1f:
	/* 0x1f1f: cmp    esi,DWORD PTR [rdi+0x1c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 28ULL);
x86_l_1f22:
	/* 0x1f22: jbe    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1f22, 0x1eae, x86_l_1eae);
x86_l_1f24:
	/* 0x1f24: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_1f27:
	/* 0x1f27: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f27, 0x1f4e, x86_l_1f4e);
x86_l_1f29:
	/* 0x1f29: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f2c:
	/* 0x1f2c: ja     1f37 <filter_32ty_range+0x18e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f2c, 0x1f37, x86_l_1f37);
x86_l_1f2e:
	/* 0x1f2e: cmp    esi,DWORD PTR [rdi+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_1f31:
	/* 0x1f31: jbe    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1f31, 0x1eae, x86_l_1eae);
x86_l_1f37:
	/* 0x1f37: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_1f3a:
	/* 0x1f3a: jb     1f4e <filter_32ty_range+0x1a5> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x1f3a, 0x1f4e, x86_l_1f4e);
x86_l_1f3c:
	/* 0x1f3c: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f3e:
	/* 0x1f3e: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1f41:
	/* 0x1f41: ja     1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1f41, 0x1f50, x86_l_1f50);
x86_l_1f43:
	/* 0x1f43: cmp    esi,DWORD PTR [rdi+0x2c] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 44ULL);
x86_l_1f46:
	/* 0x1f46: jbe    1eae <filter_32ty_range+0x105> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x1f46, 0x1eae, x86_l_1eae);
x86_l_1f4c:
	/* 0x1f4c: jmp    1f50 <filter_32ty_range+0x1a7> */
	X86_SIM_X86_SUB_JMP(0x1f4c, 0x1f50, x86_l_1f50);
x86_l_1f4e:
	/* 0x1f4e: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1f50:
	/* 0x1f50: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_1f53:
	/* 0x1f53: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_1f56:
	/* 0x1f56: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_1f59:
	/* 0x1f59: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_1f5b:
	/* 0x1f5b: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1f5e:
	/* 0x1f5e: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1f5f */
x86_l_1f5f:
	/* 0x1f5f: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1f61:
	/* 0x1f61: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1f62:
	/* 0x1f62: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_1f66:
	/* 0x1f66: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_1f69:
	/* 0x1f69: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_1f6c:
	/* 0x1f6c: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_1f70:
	/* 0x1f70: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1f74:
	/* 0x1f74: mov    rdi,QWORD PTR [rip+0xf60] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_1f7b:
	/* 0x1f7b: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_1f80:
	/* 0x1f80: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1f85:
	/* 0x1f85: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f87:
	/* 0x1f87: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1f8a:
	/* 0x1f8a: je     1fbf <filter_32ty_map+0x60> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x1f8a, 0x1fbf, x86_l_1fbf);
x86_l_1f8c:
	/* 0x1f8c: mov    ecx,DWORD PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f8f:
	/* 0x1f8f: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f94:
	/* 0x1f94: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f99:
	/* 0x1f99: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1f9e:
	/* 0x1f9e: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1fa1:
	/* 0x1fa1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fa3:
	/* 0x1fa3: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fa6:
	/* 0x1fa6: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fa8:
	/* 0x1fa8: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_1fab:
	/* 0x1fab: ja     1fd9 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1fab, 0x1fd9, x86_l_1fd9);
x86_l_1fad:
	/* 0x1fad: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_1fb2:
	/* 0x1fb2: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1fb5:
	/* 0x1fb5: jae    1fc9 <filter_32ty_map+0x6a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1fb5, 0x1fc9, x86_l_1fc9);
x86_l_1fb7:
	/* 0x1fb7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1fba:
	/* 0x1fba: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_1fbd:
	/* 0x1fbd: jmp    1fd9 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JMP(0x1fbd, 0x1fd9, x86_l_1fd9);
x86_l_1fbf:
	/* 0x1fbf: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fc1:
	/* 0x1fc1: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1fc5:
	/* 0x1fc5: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1fc6:
	/* 0x1fc6: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1fc8:
	/* 0x1fc8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_1fc9:
	/* 0x1fc9: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_1fce:
	/* 0x1fce: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_1fd1:
	/* 0x1fd1: jae    1fd9 <filter_32ty_map+0x7a> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x1fd1, 0x1fd9, x86_l_1fd9);
x86_l_1fd3:
	/* 0x1fd3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1fd6:
	/* 0x1fd6: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_1fd9:
	/* 0x1fd9: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_1fdc:
	/* 0x1fdc: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1fe0:
	/* 0x1fe0: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1fe1:
	/* 0x1fe1: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1fe3:
	/* 0x1fe3: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_1fe4 */
x86_l_1fe4:
	/* 0x1fe4: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fe7:
	/* 0x1fe7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1fec:
	/* 0x1fec: cmp    rcx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 37ULL);
x86_l_1ff0:
	/* 0x1ff0: ja     2063 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x1ff0, 0x2063, x86_l_2063);
x86_l_1ff2:
	/* 0x1ff2: movabs rdx,0x200c000040 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280128ULL);
x86_l_1ffc:
	/* 0x1ffc: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_2000:
	/* 0x2000: jae    2003 <filter_8ty_selector_val+0x1f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2000, 0x2003, x86_l_2003);
x86_l_2002:
	/* 0x2002: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2003:
	/* 0x2003: mov    edx,0x18 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 24ULL);
x86_l_2008:
	/* 0x2008: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_200c:
	/* 0x200c: jae    2023 <filter_8ty_selector_val+0x3f> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x200c, 0x2023, x86_l_2023);
x86_l_200e:
	/* 0x200e: movzx  edx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_2011:
	/* 0x2011: cmp    DWORD PTR [rdi+0x10],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2014:
	/* 0x2014: jne    2139 <filter_8ty_selector_val+0x155> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2014, 0x2139, x86_l_2139);
x86_l_201a:
	/* 0x201a: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_201c:
	/* 0x201c: cmp    ecx,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 3ULL);
x86_l_201f:
	/* 0x201f: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_2022:
	/* 0x2022: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2023:
	/* 0x2023: cmp    rcx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 12ULL);
x86_l_2027:
	/* 0x2027: jne    2063 <filter_8ty_selector_val+0x7f> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2027, 0x2063, x86_l_2063);
x86_l_2029:
	/* 0x2029: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_202c:
	/* 0x202c: test   DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_202f:
	/* 0x202f: jne    2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x202f, 0x2002, x86_l_2002);
x86_l_2031:
	/* 0x2031: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2034:
	/* 0x2034: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2037:
	/* 0x2037: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2037, 0x21fb, x86_l_21fb);
x86_l_203d:
	/* 0x203d: test   DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 85899345920ULL);
x86_l_2040:
	/* 0x2040: jne    2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2040, 0x2002, x86_l_2002);
x86_l_2042:
	/* 0x2042: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2045:
	/* 0x2045: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2045, 0x21fb, x86_l_21fb);
x86_l_204b:
	/* 0x204b: test   DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_204e:
	/* 0x204e: jne    2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x204e, 0x2002, x86_l_2002);
x86_l_2050:
	/* 0x2050: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2053:
	/* 0x2053: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2053, 0x21fb, x86_l_21fb);
x86_l_2059:
	/* 0x2059: test   DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 120259084288ULL);
x86_l_205c:
	/* 0x205c: jne    2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x205c, 0x2002, x86_l_2002);
x86_l_205e:
	/* 0x205e: jmp    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x205e, 0x21fb, x86_l_21fb);
x86_l_2063:
	/* 0x2063: cmp    ecx,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_2066:
	/* 0x2066: je     20d5 <filter_8ty_selector_val+0xf1> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2066, 0x20d5, x86_l_20d5);
x86_l_2068:
	/* 0x2068: cmp    ecx,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_206b:
	/* 0x206b: jne    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x206b, 0x21fb, x86_l_21fb);
x86_l_2071:
	/* 0x2071: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2074:
	/* 0x2074: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_2077:
	/* 0x2077: ja     21c2 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2077, 0x21c2, x86_l_21c2);
x86_l_207d:
	/* 0x207d: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_2082:
	/* 0x2082: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_2085:
	/* 0x2085: jae    21c2 <filter_8ty_selector_val+0x1de> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2085, 0x21c2, x86_l_21c2);
x86_l_208b:
	/* 0x208b: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_208e:
	/* 0x208e: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2091:
	/* 0x2091: jg     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2091, 0x2002, x86_l_2002);
x86_l_2097:
	/* 0x2097: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_209a:
	/* 0x209a: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_209d:
	/* 0x209d: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x209d, 0x21fb, x86_l_21fb);
x86_l_20a3:
	/* 0x20a3: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_20a6:
	/* 0x20a6: jg     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x20a6, 0x2002, x86_l_2002);
x86_l_20ac:
	/* 0x20ac: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_20af:
	/* 0x20af: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20af, 0x21fb, x86_l_21fb);
x86_l_20b5:
	/* 0x20b5: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20b8:
	/* 0x20b8: jg     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x20b8, 0x2002, x86_l_2002);
x86_l_20be:
	/* 0x20be: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_20c1:
	/* 0x20c1: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x20c1, 0x21fb, x86_l_21fb);
x86_l_20c7:
	/* 0x20c7: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_20ca:
	/* 0x20ca: jg     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x20ca, 0x2002, x86_l_2002);
x86_l_20d0:
	/* 0x20d0: jmp    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x20d0, 0x21fb, x86_l_21fb);
x86_l_20d5:
	/* 0x20d5: mov    ecx,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_20d8:
	/* 0x20d8: cmp    ecx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_20db:
	/* 0x20db: ja     2187 <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x20db, 0x2187, x86_l_2187);
x86_l_20e1:
	/* 0x20e1: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_20e6:
	/* 0x20e6: bt     edx,ecx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_20e9:
	/* 0x20e9: jae    2187 <filter_8ty_selector_val+0x1a3> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x20e9, 0x2187, x86_l_2187);
x86_l_20ef:
	/* 0x20ef: movsx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_20f2:
	/* 0x20f2: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20f5:
	/* 0x20f5: jl     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x20f5, 0x2002, x86_l_2002);
x86_l_20fb:
	/* 0x20fb: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20fe:
	/* 0x20fe: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2101:
	/* 0x2101: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2101, 0x21fb, x86_l_21fb);
x86_l_2107:
	/* 0x2107: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_210a:
	/* 0x210a: jl     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x210a, 0x2002, x86_l_2002);
x86_l_2110:
	/* 0x2110: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_2113:
	/* 0x2113: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2113, 0x21fb, x86_l_21fb);
x86_l_2119:
	/* 0x2119: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_211c:
	/* 0x211c: jl     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x211c, 0x2002, x86_l_2002);
x86_l_2122:
	/* 0x2122: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_2125:
	/* 0x2125: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2125, 0x21fb, x86_l_21fb);
x86_l_212b:
	/* 0x212b: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_212e:
	/* 0x212e: jl     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_L, 0x212e, 0x2002, x86_l_2002);
x86_l_2134:
	/* 0x2134: jmp    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2134, 0x21fb, x86_l_21fb);
x86_l_2139:
	/* 0x2139: mov    esi,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_213c:
	/* 0x213c: cmp    esi,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 13ULL);
x86_l_213f:
	/* 0x213f: jb     2166 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x213f, 0x2166, x86_l_2166);
x86_l_2141:
	/* 0x2141: cmp    DWORD PTR [rdi+0x14],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2144:
	/* 0x2144: je     201a <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2144, 0x201a, x86_l_201a);
x86_l_214a:
	/* 0x214a: cmp    esi,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 17ULL);
x86_l_214d:
	/* 0x214d: jb     2166 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x214d, 0x2166, x86_l_2166);
x86_l_214f:
	/* 0x214f: cmp    DWORD PTR [rdi+0x18],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2152:
	/* 0x2152: je     201a <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2152, 0x201a, x86_l_201a);
x86_l_2158:
	/* 0x2158: cmp    esi,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RSI, X86_WIDTH_32, 21ULL);
x86_l_215b:
	/* 0x215b: jb     2166 <filter_8ty_selector_val+0x182> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x215b, 0x2166, x86_l_2166);
x86_l_215d:
	/* 0x215d: cmp    DWORD PTR [rdi+0x1c],edx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2160:
	/* 0x2160: je     201a <filter_8ty_selector_val+0x36> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2160, 0x201a, x86_l_201a);
x86_l_2166:
	/* 0x2166: cmp    ecx,0x25 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 37ULL);
x86_l_2169:
	/* 0x2169: ja     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2169, 0x21fb, x86_l_21fb);
x86_l_216f:
	/* 0x216f: mov    ecx,ecx */
	X86_SIM_L_EXEC_MOV_REG(X86_RCX, X86_RCX, X86_WIDTH_32);
x86_l_2171:
	/* 0x2171: movabs rdx,0x200c000050 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_64, 137640280144ULL);
x86_l_217b:
	/* 0x217b: bt     rdx,rcx */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RCX, X86_WIDTH_64);
x86_l_217f:
	/* 0x217f: jb     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x217f, 0x2002, x86_l_2002);
x86_l_2185:
	/* 0x2185: jmp    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x2185, 0x21fb, x86_l_21fb);
x86_l_2187:
	/* 0x2187: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_218a:
	/* 0x218a: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_218d:
	/* 0x218d: jb     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x218d, 0x2002, x86_l_2002);
x86_l_2193:
	/* 0x2193: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2196:
	/* 0x2196: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_2199:
	/* 0x2199: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2199, 0x21fb, x86_l_21fb);
x86_l_219b:
	/* 0x219b: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_219e:
	/* 0x219e: jb     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x219e, 0x2002, x86_l_2002);
x86_l_21a4:
	/* 0x21a4: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_21a7:
	/* 0x21a7: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21a7, 0x21fb, x86_l_21fb);
x86_l_21a9:
	/* 0x21a9: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21ac:
	/* 0x21ac: jb     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21ac, 0x2002, x86_l_2002);
x86_l_21b2:
	/* 0x21b2: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_21b5:
	/* 0x21b5: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21b5, 0x21fb, x86_l_21fb);
x86_l_21b7:
	/* 0x21b7: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_21ba:
	/* 0x21ba: jb     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21ba, 0x2002, x86_l_2002);
x86_l_21c0:
	/* 0x21c0: jmp    21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JMP(0x21c0, 0x21fb, x86_l_21fb);
x86_l_21c2:
	/* 0x21c2: movzx  ecx,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_21c5:
	/* 0x21c5: cmp    DWORD PTR [rdi+0x10],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21c8:
	/* 0x21c8: ja     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21c8, 0x2002, x86_l_2002);
x86_l_21ce:
	/* 0x21ce: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21d1:
	/* 0x21d1: cmp    edx,0xd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 13ULL);
x86_l_21d4:
	/* 0x21d4: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21d4, 0x21fb, x86_l_21fb);
x86_l_21d6:
	/* 0x21d6: cmp    DWORD PTR [rdi+0x14],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_21d9:
	/* 0x21d9: ja     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21d9, 0x2002, x86_l_2002);
x86_l_21df:
	/* 0x21df: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_21e2:
	/* 0x21e2: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21e2, 0x21fb, x86_l_21fb);
x86_l_21e4:
	/* 0x21e4: cmp    DWORD PTR [rdi+0x18],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_21e7:
	/* 0x21e7: ja     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21e7, 0x2002, x86_l_2002);
x86_l_21ed:
	/* 0x21ed: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_21f0:
	/* 0x21f0: jb     21fb <filter_8ty_selector_val+0x217> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x21f0, 0x21fb, x86_l_21fb);
x86_l_21f2:
	/* 0x21f2: cmp    DWORD PTR [rdi+0x1c],ecx */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_21f5:
	/* 0x21f5: ja     2002 <filter_8ty_selector_val+0x1e> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x21f5, 0x2002, x86_l_2002);
x86_l_21fb:
	/* 0x21fb: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_21fd:
	/* 0x21fd: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_21fe */
x86_l_21fe:
	/* 0x21fe: mov    ecx,DWORD PTR [rdi+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2201:
	/* 0x2201: mov    eax,DWORD PTR [rdi+0xc] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_2204:
	/* 0x2204: cmp    eax,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 12ULL);
x86_l_2207:
	/* 0x2207: ja     22ee <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2207, 0x22ee, x86_l_22ee);
x86_l_220d:
	/* 0x220d: mov    edx,0x1402 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 5122ULL);
x86_l_2212:
	/* 0x2212: bt     edx,eax */
	X86_SIM_L_EXEC_BT(X86_RDX, X86_RAX, X86_WIDTH_32);
x86_l_2215:
	/* 0x2215: jae    22ee <filter_8ty_range+0xf0> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2215, 0x22ee, x86_l_22ee);
x86_l_221b:
	/* 0x221b: movsx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_221e:
	/* 0x221e: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_2221:
	/* 0x2221: jne    2289 <filter_8ty_range+0x8b> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x2221, 0x2289, x86_l_2289);
x86_l_2223:
	/* 0x2223: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2228:
	/* 0x2228: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_222b:
	/* 0x222b: jg     2236 <filter_8ty_range+0x38> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x222b, 0x2236, x86_l_2236);
x86_l_222d:
	/* 0x222d: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2230:
	/* 0x2230: jge    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2230, 0x2305, x86_l_2305);
x86_l_2236:
	/* 0x2236: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2239:
	/* 0x2239: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_223c:
	/* 0x223c: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x223c, 0x23a5, x86_l_23a5);
x86_l_2242:
	/* 0x2242: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2245:
	/* 0x2245: jg     2250 <filter_8ty_range+0x52> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2245, 0x2250, x86_l_2250);
x86_l_2247:
	/* 0x2247: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_224a:
	/* 0x224a: jge    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x224a, 0x2305, x86_l_2305);
x86_l_2250:
	/* 0x2250: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_2253:
	/* 0x2253: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2253, 0x23a5, x86_l_23a5);
x86_l_2259:
	/* 0x2259: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_225c:
	/* 0x225c: jg     2267 <filter_8ty_range+0x69> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x225c, 0x2267, x86_l_2267);
x86_l_225e:
	/* 0x225e: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2261:
	/* 0x2261: jge    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x2261, 0x2305, x86_l_2305);
x86_l_2267:
	/* 0x2267: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_226a:
	/* 0x226a: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x226a, 0x23a5, x86_l_23a5);
x86_l_2270:
	/* 0x2270: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2272:
	/* 0x2272: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2275:
	/* 0x2275: jg     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_G, 0x2275, 0x23a7, x86_l_23a7);
x86_l_227b:
	/* 0x227b: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_227e:
	/* 0x227e: jge    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_GE, 0x227e, 0x2305, x86_l_2305);
x86_l_2284:
	/* 0x2284: jmp    23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x2284, 0x23a7, x86_l_23a7);
x86_l_2289:
	/* 0x2289: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_228c:
	/* 0x228c: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_228f:
	/* 0x228f: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_2293:
	/* 0x2293: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2296:
	/* 0x2296: setge  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_GE);
x86_l_2299:
	/* 0x2299: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_229c:
	/* 0x229c: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_229f:
	/* 0x229f: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x229f, 0x23a7, x86_l_23a7);
x86_l_22a5:
	/* 0x22a5: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22a8:
	/* 0x22a8: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_22ac:
	/* 0x22ac: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_22af:
	/* 0x22af: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_22b3:
	/* 0x22b3: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_22b6:
	/* 0x22b6: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_22b9:
	/* 0x22b9: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_22bc:
	/* 0x22bc: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22bc, 0x23a7, x86_l_23a7);
x86_l_22c2:
	/* 0x22c2: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22c5:
	/* 0x22c5: setle  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_LE);
x86_l_22c9:
	/* 0x22c9: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_22cc:
	/* 0x22cc: setge  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_GE);
x86_l_22d0:
	/* 0x22d0: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_22d3:
	/* 0x22d3: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_22d6:
	/* 0x22d6: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_22d9:
	/* 0x22d9: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x22d9, 0x23a7, x86_l_23a7);
x86_l_22df:
	/* 0x22df: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_22e2:
	/* 0x22e2: setle  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_LE);
x86_l_22e5:
	/* 0x22e5: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_22e8:
	/* 0x22e8: setge  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_GE);
x86_l_22ec:
	/* 0x22ec: jmp    2361 <filter_8ty_range+0x163> */
	X86_SIM_X86_SUB_JMP(0x22ec, 0x2361, x86_l_2361);
x86_l_22ee:
	/* 0x22ee: movzx  esi,BYTE PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_22f1:
	/* 0x22f1: cmp    ecx,0x1f */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 31ULL);
x86_l_22f4:
	/* 0x22f4: jne    2306 <filter_8ty_range+0x108> */
	X86_SIM_X86_SUB_JCC(X86_CC_NE, 0x22f4, 0x2306, x86_l_2306);
x86_l_22f6:
	/* 0x22f6: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_22fb:
	/* 0x22fb: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22fe:
	/* 0x22fe: ja     2369 <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x22fe, 0x2369, x86_l_2369);
x86_l_2300:
	/* 0x2300: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2303:
	/* 0x2303: jb     2369 <filter_8ty_range+0x16b> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2303, 0x2369, x86_l_2369);
x86_l_2305:
	/* 0x2305: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2306:
	/* 0x2306: mov    eax,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2309:
	/* 0x2309: cmp    DWORD PTR [rdi+0x10],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_230c:
	/* 0x230c: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2310:
	/* 0x2310: cmp    DWORD PTR [rdi+0x14],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_2313:
	/* 0x2313: setae  dl */
	X86_SIM_L_EXEC_SETCC(X86_RDX, X86_CC_AE);
x86_l_2316:
	/* 0x2316: and    dl,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2319:
	/* 0x2319: cmp    eax,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 17ULL);
x86_l_231c:
	/* 0x231c: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x231c, 0x23a7, x86_l_23a7);
x86_l_2322:
	/* 0x2322: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2325:
	/* 0x2325: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2329:
	/* 0x2329: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_232c:
	/* 0x232c: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_2330:
	/* 0x2330: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_2333:
	/* 0x2333: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_2336:
	/* 0x2336: cmp    eax,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 25ULL);
x86_l_2339:
	/* 0x2339: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2339, 0x23a7, x86_l_23a7);
x86_l_233b:
	/* 0x233b: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_233e:
	/* 0x233e: setbe  r8b */
	X86_SIM_L_EXEC_SETCC(X86_R8, X86_CC_BE);
x86_l_2342:
	/* 0x2342: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2345:
	/* 0x2345: setae  r9b */
	X86_SIM_L_EXEC_SETCC(X86_R9, X86_CC_AE);
x86_l_2349:
	/* 0x2349: and    r9b,r8b */
	X86_SIM_L_EXEC_ALU_REG(X86_R9, X86_R8, X86_WIDTH_8, X86_ALU_AND);
x86_l_234c:
	/* 0x234c: or     dl,r9b */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_R9, X86_WIDTH_8, X86_ALU_OR);
x86_l_234f:
	/* 0x234f: cmp    eax,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 33ULL);
x86_l_2352:
	/* 0x2352: jb     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2352, 0x23a7, x86_l_23a7);
x86_l_2354:
	/* 0x2354: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2357:
	/* 0x2357: setbe  al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_BE);
x86_l_235a:
	/* 0x235a: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_235d:
	/* 0x235d: setae  sil */
	X86_SIM_L_EXEC_SETCC(X86_RSI, X86_CC_AE);
x86_l_2361:
	/* 0x2361: and    sil,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_2364:
	/* 0x2364: or     dl,sil */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RSI, X86_WIDTH_8, X86_ALU_OR);
x86_l_2367:
	/* 0x2367: jmp    23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x2367, 0x23a7, x86_l_23a7);
x86_l_2369:
	/* 0x2369: mov    edx,DWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_236c:
	/* 0x236c: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_236f:
	/* 0x236f: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x236f, 0x23a5, x86_l_23a5);
x86_l_2371:
	/* 0x2371: cmp    DWORD PTR [rdi+0x18],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2374:
	/* 0x2374: ja     237b <filter_8ty_range+0x17d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2374, 0x237b, x86_l_237b);
x86_l_2376:
	/* 0x2376: cmp    DWORD PTR [rdi+0x1c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_2379:
	/* 0x2379: jae    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2379, 0x2305, x86_l_2305);
x86_l_237b:
	/* 0x237b: cmp    edx,0x19 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 25ULL);
x86_l_237e:
	/* 0x237e: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x237e, 0x23a5, x86_l_23a5);
x86_l_2380:
	/* 0x2380: cmp    DWORD PTR [rdi+0x20],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2383:
	/* 0x2383: ja     238e <filter_8ty_range+0x190> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2383, 0x238e, x86_l_238e);
x86_l_2385:
	/* 0x2385: cmp    DWORD PTR [rdi+0x24],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_2388:
	/* 0x2388: jae    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2388, 0x2305, x86_l_2305);
x86_l_238e:
	/* 0x238e: cmp    edx,0x21 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 33ULL);
x86_l_2391:
	/* 0x2391: jb     23a5 <filter_8ty_range+0x1a7> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x2391, 0x23a5, x86_l_23a5);
x86_l_2393:
	/* 0x2393: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2395:
	/* 0x2395: cmp    DWORD PTR [rdi+0x28],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2398:
	/* 0x2398: ja     23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2398, 0x23a7, x86_l_23a7);
x86_l_239a:
	/* 0x239a: cmp    DWORD PTR [rdi+0x2c],esi */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_239d:
	/* 0x239d: jae    2305 <filter_8ty_range+0x107> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x239d, 0x2305, x86_l_2305);
x86_l_23a3:
	/* 0x23a3: jmp    23a7 <filter_8ty_range+0x1a9> */
	X86_SIM_X86_SUB_JMP(0x23a3, 0x23a7, x86_l_23a7);
x86_l_23a5:
	/* 0x23a5: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_23a7:
	/* 0x23a7: cmp    ecx,0x20 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_32, 32ULL);
x86_l_23aa:
	/* 0x23aa: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_23ad:
	/* 0x23ad: xor    dl,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_8, X86_ALU_XOR, 1ULL);
x86_l_23b0:
	/* 0x23b0: and    dl,al */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_8, X86_ALU_AND);
x86_l_23b2:
	/* 0x23b2: movzx  eax,dl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RDX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_23b5:
	/* 0x23b5: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_23b6 */
x86_l_23b6:
	/* 0x23b6: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_23b8:
	/* 0x23b8: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_23b9:
	/* 0x23b9: sub    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 24ULL);
x86_l_23bd:
	/* 0x23bd: mov    r14,rsi */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RSI, X86_WIDTH_64);
x86_l_23c0:
	/* 0x23c0: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_23c3:
	/* 0x23c3: movzx  eax,BYTE PTR [rdi+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
x86_l_23c7:
	/* 0x23c7: mov    DWORD PTR [rsp+0xc],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_23cb:
	/* 0x23cb: mov    rdi,QWORD PTR [rip+0x1840] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)argfilter_maps));
x86_l_23d2:
	/* 0x23d2: lea    rsi,[rsp+0xc] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 12ULL);
x86_l_23d7:
	/* 0x23d7: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_23dc:
	/* 0x23dc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23de:
	/* 0x23de: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_23e1:
	/* 0x23e1: je     2417 <filter_8ty_map+0x61> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x23e1, 0x2417, x86_l_2417);
x86_l_23e3:
	/* 0x23e3: movzx  ecx,BYTE PTR [r14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_23e7:
	/* 0x23e7: mov    QWORD PTR [rsp+0x10],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23ec:
	/* 0x23ec: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23f1:
	/* 0x23f1: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_23f6:
	/* 0x23f6: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_23f9:
	/* 0x23f9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_23fb:
	/* 0x23fb: mov    edx,DWORD PTR [rbx+0x4] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23fe:
	/* 0x23fe: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2400:
	/* 0x2400: cmp    edx,0x1d */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 29ULL);
x86_l_2403:
	/* 0x2403: ja     2431 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2403, 0x2431, x86_l_2431);
x86_l_2405:
	/* 0x2405: mov    esi,0x30038400 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 805536768ULL);
x86_l_240a:
	/* 0x240a: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_240d:
	/* 0x240d: jae    2421 <filter_8ty_map+0x6b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x240d, 0x2421, x86_l_2421);
x86_l_240f:
	/* 0x240f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2412:
	/* 0x2412: setne  cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_NE);
x86_l_2415:
	/* 0x2415: jmp    2431 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JMP(0x2415, 0x2431, x86_l_2431);
x86_l_2417:
	/* 0x2417: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2419:
	/* 0x2419: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_241d:
	/* 0x241d: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_241e:
	/* 0x241e: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2420:
	/* 0x2420: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_2421:
	/* 0x2421: mov    esi,0xc0800 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 788480ULL);
x86_l_2426:
	/* 0x2426: bt     esi,edx */
	X86_SIM_L_EXEC_BT(X86_RSI, X86_RDX, X86_WIDTH_32);
x86_l_2429:
	/* 0x2429: jae    2431 <filter_8ty_map+0x7b> */
	X86_SIM_X86_SUB_JCC(X86_CC_AE, 0x2429, 0x2431, x86_l_2431);
x86_l_242b:
	/* 0x242b: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_242e:
	/* 0x242e: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_2431:
	/* 0x2431: movzx  eax,cl */
	X86_SIM_L_EXEC_MOVX_REG(X86_OP_MOVZX_REG, X86_RAX, X86_RCX, X86_WIDTH_32, X86_WIDTH_8);
x86_l_2434:
	/* 0x2434: add    rsp,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2438:
	/* 0x2438: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_2439:
	/* 0x2439: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_243b:
	/* 0x243b: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

	/* native subroutine native_link_sub_243c */
x86_l_243c:
	/* 0x243c: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_243d:
	/* 0x243d: sub    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 16ULL);
x86_l_2441:
	/* 0x2441: mov    WORD PTR [rsp+0xe],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 60129542144ULL);
x86_l_2448:
	/* 0x2448: mov    eax,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_244a:
	/* 0x244a: cmp    rax,0x1000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 4096ULL);
x86_l_2450:
	/* 0x2450: ja     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_A, 0x2450, 0x24d9, x86_l_24d9);
x86_l_2456:
	/* 0x2456: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_2459:
	/* 0x2459: add    rax,rsi */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD);
x86_l_245c:
	/* 0x245c: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2460:
	/* 0x2460: lea    rdi,[rsp+0xe] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 14ULL);
x86_l_2465:
	/* 0x2465: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_246a:
	/* 0x246a: mov    r8d,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 4ULL);
x86_l_2470:
	/* 0x2470: mov    eax,DWORD PTR [rsi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2472:
	/* 0x2472: lea    rdx,[rsi+rax*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2476:
	/* 0x2476: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_247a:
	/* 0x247a: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_247f:
	/* 0x247f: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2482:
	/* 0x2482: mov    edx,DWORD PTR [rbx+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2485:
	/* 0x2485: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_2487:
	/* 0x2487: je     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x2487, 0x24d9, x86_l_24d9);
x86_l_2489:
	/* 0x2489: movzx  ecx,WORD PTR [rsp+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_248e:
	/* 0x248e: and    ecx,0xf000 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 61440ULL);
x86_l_2494:
	/* 0x2494: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2499:
	/* 0x2499: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_249b:
	/* 0x249b: je     24db <filter_file_type+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x249b, 0x24db, x86_l_24db);
x86_l_249d:
	/* 0x249d: mov    edx,DWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24a0:
	/* 0x24a0: cmp    edx,0xc */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 12ULL);
x86_l_24a3:
	/* 0x24a3: jbe    24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_BE, 0x24a3, 0x24d9, x86_l_24d9);
x86_l_24a5:
	/* 0x24a5: mov    esi,DWORD PTR [rbx+0x14] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_24a8:
	/* 0x24a8: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_24aa:
	/* 0x24aa: je     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24aa, 0x24d9, x86_l_24d9);
x86_l_24ac:
	/* 0x24ac: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_24ae:
	/* 0x24ae: je     24db <filter_file_type+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24ae, 0x24db, x86_l_24db);
x86_l_24b0:
	/* 0x24b0: cmp    edx,0x11 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 17ULL);
x86_l_24b3:
	/* 0x24b3: jb     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24b3, 0x24d9, x86_l_24d9);
x86_l_24b5:
	/* 0x24b5: mov    esi,DWORD PTR [rbx+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_24b8:
	/* 0x24b8: test   esi,esi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_32);
x86_l_24ba:
	/* 0x24ba: je     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24ba, 0x24d9, x86_l_24d9);
x86_l_24bc:
	/* 0x24bc: cmp    esi,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_32);
x86_l_24be:
	/* 0x24be: je     24db <filter_file_type+0x9f> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24be, 0x24db, x86_l_24db);
x86_l_24c0:
	/* 0x24c0: cmp    edx,0x15 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_32, 21ULL);
x86_l_24c3:
	/* 0x24c3: jb     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_B, 0x24c3, 0x24d9, x86_l_24d9);
x86_l_24c5:
	/* 0x24c5: mov    edx,DWORD PTR [rbx+0x1c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 28ULL);
x86_l_24c8:
	/* 0x24c8: test   edx,edx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32);
x86_l_24ca:
	/* 0x24ca: je     24d9 <filter_file_type+0x9d> */
	X86_SIM_X86_SUB_JCC(X86_CC_E, 0x24ca, 0x24d9, x86_l_24d9);
x86_l_24cc:
	/* 0x24cc: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24ce:
	/* 0x24ce: cmp    edx,ecx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RCX, X86_WIDTH_32);
x86_l_24d0:
	/* 0x24d0: sete   al */
	X86_SIM_L_EXEC_SETCC(X86_RAX, X86_CC_E);
x86_l_24d3:
	/* 0x24d3: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_24d7:
	/* 0x24d7: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24d8:
	/* 0x24d8: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);
x86_l_24d9:
	/* 0x24d9: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_24db:
	/* 0x24db: add    rsp,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_24df:
	/* 0x24df: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_24e0:
	/* 0x24e0: ret */
	X86_SIM_X86_SUB_RET(x86_sim_ret_dispatch);

x86_sim_ret_dispatch:
	switch (__x86_sim_ret_addr) {
	case 0x226ULL: goto x86_l_226;
	case 0x2b9ULL: goto x86_l_2b9;
	case 0x2f9ULL: goto x86_l_2f9;
	case 0x352ULL: goto x86_l_352;
	case 0x359ULL: goto x86_l_359;
	case 0x368ULL: goto x86_l_368;
	case 0x36fULL: goto x86_l_36f;
	case 0x37bULL: goto x86_l_37b;
	case 0x387ULL: goto x86_l_387;
	case 0x510ULL: goto x86_l_510;
	case 0x52eULL: goto x86_l_52e;
	case 0x544ULL: goto x86_l_544;
	case 0x55aULL: goto x86_l_55a;
	case 0x59fULL: goto x86_l_59f;
	case 0x5c1ULL: goto x86_l_5c1;
	case 0x5c8ULL: goto x86_l_5c8;
	case 0x8c4ULL: goto x86_l_8c4;
	case 0x935ULL: goto x86_l_935;
	case 0x979ULL: goto x86_l_979;
	case 0x9adULL: goto x86_l_9ad;
	case 0x9cfULL: goto x86_l_9cf;
	case 0x9f1ULL: goto x86_l_9f1;
	case 0x9f8ULL: goto x86_l_9f8;
	case 0xa16ULL: goto x86_l_a16;
	case 0xa38ULL: goto x86_l_a38;
	case 0xa3fULL: goto x86_l_a3f;
	case 0xa89ULL: goto x86_l_a89;
	case 0xaa7ULL: goto x86_l_aa7;
	case 0xab1ULL: goto x86_l_ab1;
	case 0xabdULL: goto x86_l_abd;
	case 0xb00ULL: goto x86_l_b00;
	case 0xb22ULL: goto x86_l_b22;
	case 0xb29ULL: goto x86_l_b29;
	default: __x86_sim_unresolved_indirect_target();
	}

}

X86_SIM_LICENSE();

