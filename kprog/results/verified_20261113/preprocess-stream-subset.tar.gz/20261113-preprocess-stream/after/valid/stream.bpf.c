#include <linux/bpf.h>
#include <bpf_helpers.h>
#define STEP(N) total += input[N] + __LINE__ + __FILE__[0]
SEC("kprobe/stream") int stream(void *ctx) {
volatile __u64 *input = ctx;
__u64 total = 0;
x86_l_0:
STEP(0); STEP(1); STEP(2); STEP(3); STEP(4); STEP(5); STEP(6); STEP(7);
x86_l_1:
STEP(0); STEP(1); STEP(2); STEP(3); STEP(4); STEP(5); STEP(6); STEP(7);
x86_l_2:
STEP(0); STEP(1); STEP(2); STEP(3); STEP(4); STEP(5); STEP(6); STEP(7);
x86_l_3:
return total;
}
char LICENSE[] SEC("license") = "GPL";
