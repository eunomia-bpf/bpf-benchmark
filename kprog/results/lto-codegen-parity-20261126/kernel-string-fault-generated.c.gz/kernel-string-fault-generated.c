#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: mov    rax,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7:
	/* 0x7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: jns    3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa, 0x3f, x86_l_3f);
x86_l_c:
	/* 0xc: movzx  ecx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_f:
	/* 0xf: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_11:
	/* 0x11: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11, 0x3f, x86_l_3f);
x86_l_13:
	/* 0x13: movzx  ecx,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_17:
	/* 0x17: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_19:
	/* 0x19: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19, 0x3f, x86_l_3f);
x86_l_1b:
	/* 0x1b: movzx  ecx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1f:
	/* 0x1f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_21:
	/* 0x21: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21, 0x3f, x86_l_3f);
x86_l_23:
	/* 0x23: movzx  ecx,BYTE PTR [rax+0x3] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3ULL);
x86_l_27:
	/* 0x27: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_29:
	/* 0x29: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x29, 0x3f, x86_l_3f);
x86_l_2b:
	/* 0x2b: movzx  ecx,BYTE PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4ULL);
x86_l_2f:
	/* 0x2f: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_31:
	/* 0x31: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31, 0x3f, x86_l_3f);
x86_l_33:
	/* 0x33: movzx  ecx,BYTE PTR [rax+0x5] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 5ULL);
x86_l_37:
	/* 0x37: test   cl,cl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_8, 0, 0);
x86_l_39:
	/* 0x39: je     3f <trusted_entry+0x3f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39, 0x3f, x86_l_3f);
x86_l_3b:
	/* 0x3b: movzx  eax,BYTE PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 6ULL);
x86_l_3f:
	/* 0x3f: mov    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_44:
	/* 0x44: jmp    49 <trusted_entry+0x49> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_49:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
