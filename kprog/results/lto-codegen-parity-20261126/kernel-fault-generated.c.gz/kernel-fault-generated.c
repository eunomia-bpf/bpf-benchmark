#define X86_SIM_STACK_VALUE_WORDS(M) 
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("xdp")
int trusted_x86_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: mov    rax,0xffffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709551615ULL);
x86_l_7:
	/* 0x7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: jns    f <trusted_entry+0xf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa, 0xf, x86_l_f);
x86_l_c:
	/* 0xc: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f:
	/* 0xf: mov    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_14:
	/* 0x14: jmp    19 <trusted_entry+0x19> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_19:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
