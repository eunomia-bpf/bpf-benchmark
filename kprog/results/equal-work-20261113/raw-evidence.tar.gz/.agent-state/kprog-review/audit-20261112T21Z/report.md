The report is at `/c/Users/10678/kprog-control/audits/detour-20261112T21.md`; on Windows that is `C:/Users/10678/kprog-control/audits/detour-20261112T21.md`. I changed nothing else and stopped no process. I couldn't reach the lane directory, the paper or `duties.yaml` from here, so I read `kprog-lanes/`, `corpus/results/` and `kprog-raw/` instead.

Findings, highest cost first:

1. **The equal-work check was misread.** The counters show the two arms take different code paths, yet lane C reported "native does 1.139x the work per call, so the speedup stands" (07e5ba95f, 770b861e4, 0188ec1d1). I checked this against the raw metrics dumps (`otel-eq13` and `otel-eq14`):
   - **Interpreter unwinding:** the eBPF arm entered the interpreter unwinders 323 times in about 60 s. The native arm added about 67 million in about 80 s, roughly 4.3 million for each language.
   - **Unwind attempts:** they run about 250x faster in the native arm, while entry counts are nearly the same (419.8M vs 432.0M).
   - **Kernel register reads:** they fail 34% of the time in the eBPF arm and 0.4% in the native arm. Lane C presented this as a bonus; in a system meant to reproduce the program faithfully it is a sign the two diverge.
   - **Tetragon's "weak form":** it rests on run 152929. That run lists 171 programs in the eBPF phase and 106 in the native phase. The eBPF phase's most expensive program (18.4 µs per call, about 36% of its BPF time) has no counterpart in the native phase.
   - **Flat native cost:** hot Tetragon programs cost 223–6245 ns per call in eBPF but all cost 55–68 ns natively. A real speedup would not flatten them to one constant.
   - **The May explanation can't cover the gap:** `kprog/docs/evaluation.md:267` credits OTel's gain to a memset. That saves at most tens of ns out of a 3000 ns gap.

   **Cost:** the 1.228x geomean, the floor check and the paper's headline performance result all hang on these two apps. Either the native path has a correctness bug, or the eBPF baseline is broken. Without them the geomean is about 1.08x (15Z's figure).

   **Instead:** withdraw "settled". Run eBPF and native side by side on the same captured inputs, using the project's existing differential test. Check the tail-call counter, the `ctx` read and the `bpf_probe_read_kernel` return value. Compare the trace counts each arm sends to the collector.

2. **The verified census is serial and mostly repeats itself.** By 21:18 there were 52 outcomes in about 4.7 hours (about 11 per hour), covering only about 14 distinct programs; one program was submitted 8 times. The 549 instances reduce to about 232 distinct programs, and Tetragon's 287 to about 25. At this rate the rest takes about 45 hours. Fixes for the four failure classes already found must wait until it finishes, and the same rejection is committed again and again ("third/fourth … rejection").

   **Instead:** deduplicate, run in parallel, and start fixing the known classes now.

3. **Coordination has lapsed.**
   - **Hourly check stopped:** the last report is 18:13Z and the coordinator's last post is 19:04Z, against the "每小时监控提醒不能停" rule. Finding 1 went into the commit history without review.
   - **CPUs 0–7:** lane C is holding them for about 1.5 hours on a Tracee pair it predicts will show no difference.
   - **Lost turns:** a conflicting "8-CPU guest" instruction and a missing `-i` on `docker exec` cost about 4 turns. Lane C's timestamps are still about 12 hours off.

Confidence: the counter split, 106/171 and 55–68 ns are checked (high). Which arm is correct, and why, is inferred (medium).
