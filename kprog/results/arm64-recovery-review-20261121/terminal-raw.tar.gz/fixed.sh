ulimit -c 0
export PYTHONDONTWRITEBYTECODE=1 TMPDIR=/var/tmp/kprog-tmp/S2/review-20261121
cd /workspaces/repository
taskset -c 8-23 make -k -f kprog/results/arm64-recovery-review-20261121/Makefile host sites > /var/tmp/kprog-tmp/S2/review-20261121/fixed.log 2>&1
echo $? > /var/tmp/kprog-tmp/S2/review-20261121/fixed.exit
