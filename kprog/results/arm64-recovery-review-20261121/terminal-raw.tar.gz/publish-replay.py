import json,os,subprocess
from pathlib import Path
S=Path('/var/tmp/kprog-tmp/S2/review-20261121');os.chdir('/workspaces/repository')
env=dict(os.environ,GIT_INDEX_FILE=str(S/'replay.index'))
paths=['kprog/arm64/micro-prog/test_read_recovery.py','kprog/docs/freeze-open.tsv']+['kprog/results/arm64-recovery-review-20261121/'+x for x in ['Makefile','README.md','guest.py','safety.py','safety_probe.cpp','replay_hosts.py','generator_inventory.py']]
while True:
    subprocess.run(['git','read-tree','HEAD'],env=env,check=True)
    subprocess.run(['git','add','--']+paths,env=env,check=True)
    p=subprocess.run(['git','commit','-m','Replay ARM recovery forms with current scalar production and loader'],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(p.stdout,flush=True)
    if p.returncode==0:break
    if "cannot lock ref 'HEAD'" not in p.stdout:raise SystemExit(p.returncode)
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
subprocess.run(['git','push','origin','master'],check=True)
subprocess.run(['git','merge-base','--is-ancestor',commit,'origin/master'],check=True)
(S/'replay-publication.json').write_text(json.dumps(dict(commit=commit,paths=paths,pushed=True),indent=2)+'\n')
