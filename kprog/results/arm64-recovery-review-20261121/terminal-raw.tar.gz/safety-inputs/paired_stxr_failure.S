.text
.global entry
.type entry,%function
entry:
sub sp, sp, #16
mov x1, #2
str x1, [sp]
mov x2, sp
ldxr x1, [x2]
stxr w0, x1, [x2]
cbz w0, 1f
mov x3, #0
ldr w0, [x3]
1: add sp, sp, #16
mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
