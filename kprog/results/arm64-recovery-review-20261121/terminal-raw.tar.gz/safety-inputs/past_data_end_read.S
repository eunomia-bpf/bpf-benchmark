.text
.global entry
.type entry,%function
entry:
ldr x1, [x0, #8]
ldrb w0, [x1]
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
