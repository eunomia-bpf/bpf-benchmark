.text
.global entry
.type entry,%function
entry:
mov x30, #0
mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
