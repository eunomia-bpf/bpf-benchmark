.text
.global entry
.type entry,%function
entry:
ldr x1, [x0]
br x1
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
