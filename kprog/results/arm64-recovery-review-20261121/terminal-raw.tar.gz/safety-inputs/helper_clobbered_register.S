.text
.global entry
.type entry,%function
entry:
stp x19, x30, [sp, #-16]!
mov x19, x0
mov x1, #0
bl bpf_get_current_uid_gid
cbz x1, 1f
ldr x1, [x19, #8]
ldrb w0, [x1]
b 2f
1: mov w0, #2
2: ldp x19, x30, [sp], #16
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
