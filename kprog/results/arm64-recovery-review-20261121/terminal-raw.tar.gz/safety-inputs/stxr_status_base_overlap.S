.text
.global entry
.type entry,%function
entry:
sub sp, sp, #16
mov x1, #2
str x1, [sp]
mov x2, sp
stxr w2, x1, [x2]
add sp, sp, #16
mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
