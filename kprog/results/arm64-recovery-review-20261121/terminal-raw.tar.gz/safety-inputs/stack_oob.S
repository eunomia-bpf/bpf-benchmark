.text
.global entry
.type entry,%function
entry:
ldr x0, [sp, #1024]
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
