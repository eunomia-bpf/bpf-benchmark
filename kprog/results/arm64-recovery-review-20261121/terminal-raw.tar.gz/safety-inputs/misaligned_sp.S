.text
.global entry
.type entry,%function
entry:
sub sp, sp, #16
mov w1, #0x2222
str x1, [sp]
add sp, sp, #1
ldrb w0, [sp]
sub sp, sp, #1
add sp, sp, #16
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
