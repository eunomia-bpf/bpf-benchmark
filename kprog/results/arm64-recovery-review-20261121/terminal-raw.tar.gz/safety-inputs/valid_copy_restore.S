.text
.global entry
.type entry,%function
entry:
mov x1,sp
mov sp,x1
mov w0,#2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
