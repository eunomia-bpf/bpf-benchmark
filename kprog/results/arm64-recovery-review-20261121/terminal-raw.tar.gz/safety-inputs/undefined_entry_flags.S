.text
.global entry
.type entry,%function
entry:
b.cc 1f
ldr x1, [x0, #8]
ldrb w0, [x1]
ret
1: mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
