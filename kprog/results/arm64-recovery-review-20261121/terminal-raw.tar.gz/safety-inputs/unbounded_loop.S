.text
.global entry
.type entry,%function
entry:
1: b 1b
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
