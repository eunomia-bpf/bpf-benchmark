.text
.global entry
.type entry,%function
entry:
sub sp,sp,#32
add x1,sp,#16
str x1,[sp]
ldr x1,[sp]
mov sp,x1
add sp,sp,#16
mov w0,#2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
