.text
.global entry
.type entry,%function
entry:
brk #0
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
