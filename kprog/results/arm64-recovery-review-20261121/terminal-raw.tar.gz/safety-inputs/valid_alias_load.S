.text
.global entry
.type entry,%function
entry:
sub sp,sp,#16
mov x1,#37
str x1,[sp]
mov x2,sp
ldr x3,[x2]
add sp,sp,#16
cmp x3,#37
b.ne 1f
mov w0,#2
ret
1: mov w0,#0
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
