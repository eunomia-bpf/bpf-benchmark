#include <linux/bpf.h>
#include <bpf_helpers.h>
struct { __uint(type,BPF_MAP_TYPE_HASH); __uint(max_entries,1); __type(key,__u32); __type(value,__u64); } neg_map SEC(".maps");
SEC("xdp") int neg_source(struct xdp_md *ctx) { (void)ctx; __u32 key=0; bpf_map_lookup_elem(&neg_map,&key); return 2; }
char LICENSE[] SEC("license")="GPL";
