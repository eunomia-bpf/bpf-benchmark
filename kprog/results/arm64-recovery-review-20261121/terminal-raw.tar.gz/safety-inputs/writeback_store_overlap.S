.text
.global entry
.type entry,%function
entry:
sub sp, sp, #16
mov x2, #2
stp x2, x2, [sp]
mov x1, sp
str x1, [x1], #8
add sp, sp, #16
mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
