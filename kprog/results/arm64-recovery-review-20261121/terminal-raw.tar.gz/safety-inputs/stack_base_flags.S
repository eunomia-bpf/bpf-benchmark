.text
.global entry
.type entry,%function
entry:
mov w0, #2
sub sp, sp, #16
add sp, sp, #16
cmp sp, #0
b.eq 1f
mov x1, #0
ldr w0, [x1]
1: ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
