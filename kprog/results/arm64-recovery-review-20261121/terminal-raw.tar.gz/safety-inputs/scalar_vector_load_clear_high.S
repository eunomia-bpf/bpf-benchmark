.text
.global entry
.type entry,%function
entry:
sub sp, sp, #32
mov x1, #1
str xzr, [sp]
str x1, [sp, #8]
ldr q0, [sp]
ldr d0, [sp]
str q0, [sp, #16]
ldr x1, [sp, #24]
cbnz x1, 1f
mov x0, #0
ldr x0, [x0]
1: add sp, sp, #32
mov w0, #2
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
