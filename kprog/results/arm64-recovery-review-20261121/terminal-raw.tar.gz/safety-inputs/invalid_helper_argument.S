.text
.global entry
.type entry,%function
entry:
str x30, [sp, #-16]!
mov x0, #1
mov x1, #0
bl bpf_map_lookup_elem
ldr x30, [sp], #16
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
