.text
.global entry
.type entry,%function
entry:
mov w0, #2
cmp x30, #0
b.eq 1f
mov x1, #0
ldr w0, [x1]
1: ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
