.text
.global entry
.type entry,%function
entry:
ldur x0, [sp, #-8]
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
