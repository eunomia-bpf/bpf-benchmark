.text
.global entry
.type entry,%function
entry:
sub sp, sp, #16
mov x1, #2
stp x1, x1, [sp]
ldp x1, x1, [sp]
add sp, sp, #16
mov w0, w1
ret
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
