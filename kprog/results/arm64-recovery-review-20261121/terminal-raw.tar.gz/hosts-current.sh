ulimit -c 0
export PYTHONDONTWRITEBYTECODE=1 TMPDIR=/var/tmp/kprog-tmp/S2/review-20261121
cd /workspaces/repository
taskset -c 8-23 python3 kprog/results/arm64-recovery-review-20261121/replay_hosts.py /var/tmp/kprog-tmp/S2/review-20261121 > /var/tmp/kprog-tmp/S2/review-20261121/hosts-current-driver.log 2>&1
echo $? > /var/tmp/kprog-tmp/S2/review-20261121/hosts-current.exit
