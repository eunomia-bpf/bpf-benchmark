
/var/tmp/kprog-tmp/perf/checked-toolchain/regressions/probe/native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <user8>:
       0: 53                           	pushq	%rbx
       1: 48 89 fb                     	movq	%rdi, %rbx
       4: ba 08 00 00 00               	movl	$0x8, %edx
       9: e8 00 00 00 00               	callq	0xe <user8+0xe>
		000000000000000a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
       e: 85 c0                        	testl	%eax, %eax
      10: 79 07                        	jns	0x19 <user8+0x19>
      12: 48 c7 03 00 00 00 00         	movq	$0x0, (%rbx)
      19: 48 98                        	cltq
      1b: 5b                           	popq	%rbx
      1c: c3                           	retq
      1d: 0f 1f 00                     	nopl	(%rax)

0000000000000020 <kernel8>:
      20: 53                           	pushq	%rbx
      21: 48 89 fb                     	movq	%rdi, %rbx
      24: ba 08 00 00 00               	movl	$0x8, %edx
      29: e8 00 00 00 00               	callq	0x2e <kernel8+0xe>
		000000000000002a:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
      2e: 85 c0                        	testl	%eax, %eax
      30: 79 07                        	jns	0x39 <kernel8+0x19>
      32: 48 c7 03 00 00 00 00         	movq	$0x0, (%rbx)
      39: 48 98                        	cltq
      3b: 5b                           	popq	%rbx
      3c: c3                           	retq
      3d: 0f 1f 00                     	nopl	(%rax)

0000000000000040 <user_dynamic>:
      40: 41 57                        	pushq	%r15
      42: 41 56                        	pushq	%r14
      44: 53                           	pushq	%rbx
      45: 49 89 fe                     	movq	%rdi, %r14
      48: 89 f3                        	movl	%esi, %ebx
      4a: 48 89 d6                     	movq	%rdx, %rsi
      4d: 48 89 da                     	movq	%rbx, %rdx
      50: e8 00 00 00 00               	callq	0x55 <user_dynamic+0x15>
		0000000000000051:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      55: 49 89 c7                     	movq	%rax, %r15
      58: 45 85 ff                     	testl	%r15d, %r15d
      5b: 79 0d                        	jns	0x6a <user_dynamic+0x2a>
      5d: 4c 89 f7                     	movq	%r14, %rdi
      60: 31 f6                        	xorl	%esi, %esi
      62: 48 89 da                     	movq	%rbx, %rdx
      65: e8 00 00 00 00               	callq	0x6a <user_dynamic+0x2a>
		0000000000000066:  R_X86_64_PLT32	memset-0x4
      6a: 49 63 c7                     	movslq	%r15d, %rax
      6d: 5b                           	popq	%rbx
      6e: 41 5e                        	popq	%r14
      70: 41 5f                        	popq	%r15
      72: c3                           	retq
      73: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000080 <kernel_dynamic>:
      80: 41 57                        	pushq	%r15
      82: 41 56                        	pushq	%r14
      84: 53                           	pushq	%rbx
      85: 49 89 fe                     	movq	%rdi, %r14
      88: 89 f3                        	movl	%esi, %ebx
      8a: 48 89 d6                     	movq	%rdx, %rsi
      8d: 48 89 da                     	movq	%rbx, %rdx
      90: e8 00 00 00 00               	callq	0x95 <kernel_dynamic+0x15>
		0000000000000091:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
      95: 49 89 c7                     	movq	%rax, %r15
      98: 45 85 ff                     	testl	%r15d, %r15d
      9b: 79 0d                        	jns	0xaa <kernel_dynamic+0x2a>
      9d: 4c 89 f7                     	movq	%r14, %rdi
      a0: 31 f6                        	xorl	%esi, %esi
      a2: 48 89 da                     	movq	%rbx, %rdx
      a5: e8 00 00 00 00               	callq	0xaa <kernel_dynamic+0x2a>
		00000000000000a6:  R_X86_64_PLT32	memset-0x4
      aa: 49 63 c7                     	movslq	%r15d, %rax
      ad: 5b                           	popq	%rbx
      ae: 41 5e                        	popq	%r14
      b0: 41 5f                        	popq	%r15
      b2: c3                           	retq
      b3: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

00000000000000c0 <compat>:
      c0: e9 00 00 00 00               	jmp	0xc5 <compat+0x5>
		00000000000000c1:  R_X86_64_PLT32	bpf_probe_read-0x4
      c5: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

00000000000000d0 <__kprog_probe_read_user>:
      d0: 41 57                        	pushq	%r15
      d2: 41 56                        	pushq	%r14
      d4: 53                           	pushq	%rbx
      d5: 49 89 fe                     	movq	%rdi, %r14
      d8: 89 f3                        	movl	%esi, %ebx
      da: 48 89 d6                     	movq	%rdx, %rsi
      dd: 48 89 da                     	movq	%rbx, %rdx
      e0: e8 00 00 00 00               	callq	0xe5 <__kprog_probe_read_user+0x15>
		00000000000000e1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
      e5: 49 89 c7                     	movq	%rax, %r15
      e8: 45 85 ff                     	testl	%r15d, %r15d
      eb: 79 0d                        	jns	0xfa <__kprog_probe_read_user+0x2a>
      ed: 4c 89 f7                     	movq	%r14, %rdi
      f0: 31 f6                        	xorl	%esi, %esi
      f2: 48 89 da                     	movq	%rbx, %rdx
      f5: e8 00 00 00 00               	callq	0xfa <__kprog_probe_read_user+0x2a>
		00000000000000f6:  R_X86_64_PLT32	memset-0x4
      fa: 49 63 c7                     	movslq	%r15d, %rax
      fd: 5b                           	popq	%rbx
      fe: 41 5e                        	popq	%r14
     100: 41 5f                        	popq	%r15
     102: c3                           	retq
     103: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000110 <__kprog_probe_read_kernel>:
     110: 41 57                        	pushq	%r15
     112: 41 56                        	pushq	%r14
     114: 53                           	pushq	%rbx
     115: 49 89 fe                     	movq	%rdi, %r14
     118: 89 f3                        	movl	%esi, %ebx
     11a: 48 89 d6                     	movq	%rdx, %rsi
     11d: 48 89 da                     	movq	%rbx, %rdx
     120: e8 00 00 00 00               	callq	0x125 <__kprog_probe_read_kernel+0x15>
		0000000000000121:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
     125: 49 89 c7                     	movq	%rax, %r15
     128: 45 85 ff                     	testl	%r15d, %r15d
     12b: 79 0d                        	jns	0x13a <__kprog_probe_read_kernel+0x2a>
     12d: 4c 89 f7                     	movq	%r14, %rdi
     130: 31 f6                        	xorl	%esi, %esi
     132: 48 89 da                     	movq	%rbx, %rdx
     135: e8 00 00 00 00               	callq	0x13a <__kprog_probe_read_kernel+0x2a>
		0000000000000136:  R_X86_64_PLT32	memset-0x4
     13a: 49 63 c7                     	movslq	%r15d, %rax
     13d: 5b                           	popq	%rbx
     13e: 41 5e                        	popq	%r14
     140: 41 5f                        	popq	%r15
     142: c3                           	retq
