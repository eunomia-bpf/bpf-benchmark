; ModuleID = '/var/tmp/kprog-tmp/perf/checked-toolchain/regressions/private/native.bc'
source_filename = "/workspaces/repository/kprog/results/native-private-stack-20261119/fixture.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%union.x86_sim_stack_mem = type { [4 x i64] }

@global_state = global %union.x86_sim_stack_mem zeroinitializer, align 8, !dbg !0

; Function Attrs: nofree norecurse nounwind memory(inaccessiblemem: readwrite)
define i64 @private_sum(i64 noundef %0, i32 noundef %1) local_unnamed_addr #0 !dbg !29 {
  %3 = alloca %union.x86_sim_stack_mem, align 8, !DIAssignID !37
  call void @llvm.dbg.assign(metadata i1 undef, metadata !36, metadata !DIExpression(), metadata !37, metadata ptr %3, metadata !DIExpression()), !dbg !38
  call void @llvm.dbg.value(metadata i64 %0, metadata !34, metadata !DIExpression()), !dbg !38
  call void @llvm.dbg.value(metadata i32 %1, metadata !35, metadata !DIExpression()), !dbg !38
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %3) #6, !dbg !39
  store i64 %0, ptr %3, align 8, !dbg !40, !tbaa !41, !DIAssignID !44
  call void @llvm.dbg.assign(metadata i64 %0, metadata !36, metadata !DIExpression(DW_OP_LLVM_fragment, 0, 64), metadata !44, metadata ptr %3, metadata !DIExpression()), !dbg !38
  %4 = add i64 %0, 1, !dbg !45
  %5 = getelementptr inbounds [4 x i64], ptr %3, i64 0, i64 1, !dbg !46
  store i64 %4, ptr %5, align 8, !dbg !47, !tbaa !41, !DIAssignID !48
  call void @llvm.dbg.assign(metadata i64 %4, metadata !36, metadata !DIExpression(DW_OP_LLVM_fragment, 64, 64), metadata !48, metadata ptr %5, metadata !DIExpression()), !dbg !38
  %6 = add i64 %0, 2, !dbg !49
  %7 = getelementptr inbounds [4 x i64], ptr %3, i64 0, i64 2, !dbg !50
  store i64 %6, ptr %7, align 8, !dbg !51, !tbaa !41, !DIAssignID !52
  call void @llvm.dbg.assign(metadata i64 %6, metadata !36, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !52, metadata ptr %7, metadata !DIExpression()), !dbg !38
  %8 = add i64 %0, 3, !dbg !53
  %9 = getelementptr inbounds [4 x i64], ptr %3, i64 0, i64 3, !dbg !54
  store i64 %8, ptr %9, align 8, !dbg !55, !tbaa !41, !DIAssignID !56
  call void @llvm.dbg.assign(metadata i64 %8, metadata !36, metadata !DIExpression(DW_OP_LLVM_fragment, 192, 64), metadata !56, metadata ptr %9, metadata !DIExpression()), !dbg !38
  %10 = and i32 %1, 3, !dbg !57
  %11 = zext nneg i32 %10 to i64, !dbg !58
  %12 = getelementptr inbounds [4 x i64], ptr %3, i64 0, i64 %11, !dbg !58
  %13 = load i64, ptr %12, align 8, !dbg !58, !tbaa !41
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %3) #6, !dbg !59
  ret i64 %13, !dbg !60
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nofree norecurse nounwind memory(readwrite, argmem: none)
define i64 @global_access(i64 noundef %0) local_unnamed_addr #2 !dbg !61 {
  call void @llvm.dbg.value(metadata i64 %0, metadata !65, metadata !DIExpression()), !dbg !66
  store volatile i64 %0, ptr @global_state, align 8, !dbg !67, !tbaa !41
  %2 = load volatile i64, ptr @global_state, align 8, !dbg !68, !tbaa !41
  ret i64 %2, !dbg !69
}

; Function Attrs: nofree norecurse nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
define i64 @pointer_access(i64 noundef %0, ptr noundef %1) local_unnamed_addr #3 !dbg !70 {
  call void @llvm.dbg.value(metadata i64 %0, metadata !76, metadata !DIExpression()), !dbg !78
  call void @llvm.dbg.value(metadata ptr %1, metadata !77, metadata !DIExpression()), !dbg !78
  store volatile i64 %0, ptr %1, align 8, !dbg !79, !tbaa !80
  %3 = load volatile i64, ptr %1, align 8, !dbg !82, !tbaa !80
  ret i64 %3, !dbg !83
}

; Function Attrs: nofree norecurse nounwind
define i64 @mixed(i64 noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef %3) local_unnamed_addr #4 !dbg !84 {
  %5 = alloca %union.x86_sim_stack_mem, align 8, !DIAssignID !95
  call void @llvm.dbg.assign(metadata i1 undef, metadata !93, metadata !DIExpression(), metadata !95, metadata ptr %5, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata i64 %0, metadata !89, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata i32 %1, metadata !90, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata i32 %2, metadata !91, metadata !DIExpression()), !dbg !96
  call void @llvm.dbg.value(metadata ptr %3, metadata !92, metadata !DIExpression()), !dbg !96
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %5) #6, !dbg !97
  %6 = icmp eq i32 %2, 0, !dbg !98
  %7 = and i32 %1, 3, !dbg !98
  %8 = zext nneg i32 %7 to i64, !dbg !98
  %9 = getelementptr inbounds [4 x i64], ptr %5, i64 0, i64 %8, !dbg !98
  %10 = select i1 %6, ptr %3, ptr %9, !dbg !98
  call void @llvm.dbg.value(metadata ptr %10, metadata !94, metadata !DIExpression()), !dbg !96
  store volatile i64 %0, ptr %10, align 8, !dbg !99, !tbaa !80
  %11 = load volatile i64, ptr %10, align 8, !dbg !100, !tbaa !80
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %5) #6, !dbg !101
  ret i64 %11, !dbg !102
}

; Function Attrs: nofree norecurse nounwind memory(inaccessiblemem: readwrite)
define i64 @other_local(i64 noundef %0) local_unnamed_addr #0 !dbg !103 {
  %2 = alloca i64, align 8, !DIAssignID !107
  call void @llvm.dbg.assign(metadata i1 undef, metadata !106, metadata !DIExpression(), metadata !107, metadata ptr %2, metadata !DIExpression()), !dbg !108
  call void @llvm.dbg.value(metadata i64 %0, metadata !105, metadata !DIExpression()), !dbg !108
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %2), !dbg !109
  store volatile i64 %0, ptr %2, align 8, !dbg !110, !tbaa !80, !DIAssignID !111
  call void @llvm.dbg.assign(metadata i64 %0, metadata !106, metadata !DIExpression(), metadata !111, metadata ptr %2, metadata !DIExpression()), !dbg !108
  %3 = load volatile i64, ptr %2, align 8, !dbg !112, !tbaa !80
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %2), !dbg !113
  ret i64 %3, !dbg !114
}

; Function Attrs: nofree norecurse nounwind memory(inaccessiblemem: readwrite)
define i64 @atomic_local(i64 noundef %0, i32 noundef %1) local_unnamed_addr #0 !dbg !115 {
  %3 = alloca %union.x86_sim_stack_mem, align 8, !DIAssignID !121
  call void @llvm.dbg.assign(metadata i1 undef, metadata !119, metadata !DIExpression(), metadata !121, metadata ptr %3, metadata !DIExpression()), !dbg !122
  call void @llvm.dbg.value(metadata i64 %0, metadata !117, metadata !DIExpression()), !dbg !122
  call void @llvm.dbg.value(metadata i32 %1, metadata !118, metadata !DIExpression()), !dbg !122
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %3) #6, !dbg !123
  %4 = and i32 %1, 3, !dbg !124
  %5 = zext nneg i32 %4 to i64, !dbg !125
  %6 = getelementptr inbounds [4 x i64], ptr %3, i64 0, i64 %5, !dbg !125
  call void @llvm.dbg.value(metadata ptr %6, metadata !120, metadata !DIExpression()), !dbg !122
  store atomic volatile i64 %0, ptr %6 monotonic, align 8, !dbg !126
  %7 = load atomic volatile i64, ptr %6 monotonic, align 8, !dbg !127
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %3) #6, !dbg !128
  ret i64 %7, !dbg !129
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #5

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #5

attributes #0 = { nofree norecurse nounwind memory(inaccessiblemem: readwrite) "frame-pointer"="none" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nofree norecurse nounwind memory(readwrite, argmem: none) "frame-pointer"="none" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #3 = { nofree norecurse nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) "frame-pointer"="none" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #4 = { nofree norecurse nounwind "frame-pointer"="none" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { nounwind }

!llvm.dbg.cu = !{!2}
!llvm.module.flags = !{!23, !24, !25, !26, !27}
!llvm.ident = !{!28}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "global_state", scope: !2, file: !10, line: 2, type: !11, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !9, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/workspaces/repository/kprog/results/native-private-stack-20261119/fixture.c", directory: "/workspaces/repository/kprog/results/checked-toolchain-20261126", checksumkind: CSK_MD5, checksum: "80f73a9258df658282db8337b8c4b5e9")
!4 = !{!5}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!6 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !7)
!7 = !DIDerivedType(tag: DW_TAG_atomic_type, baseType: !8)
!8 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!9 = !{!0}
!10 = !DIFile(filename: "native-private-stack-20261119/fixture.c", directory: "/workspaces/repository/kprog/results", checksumkind: CSK_MD5, checksum: "80f73a9258df658282db8337b8c4b5e9")
!11 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !12)
!12 = distinct !DICompositeType(tag: DW_TAG_union_type, name: "x86_sim_stack_mem", file: !10, line: 1, size: 256, elements: !13)
!13 = !{!14, !19}
!14 = !DIDerivedType(tag: DW_TAG_member, name: "b", scope: !12, file: !10, line: 1, baseType: !15, size: 256)
!15 = !DICompositeType(tag: DW_TAG_array_type, baseType: !16, size: 256, elements: !17)
!16 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!17 = !{!18}
!18 = !DISubrange(count: 32)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "q", scope: !12, file: !10, line: 1, baseType: !20, size: 256)
!20 = !DICompositeType(tag: DW_TAG_array_type, baseType: !8, size: 256, elements: !21)
!21 = !{!22}
!22 = !DISubrange(count: 4)
!23 = !{i32 7, !"Dwarf Version", i32 5}
!24 = !{i32 2, !"Debug Info Version", i32 3}
!25 = !{i32 1, !"wchar_size", i32 4}
!26 = !{i32 7, !"frame-pointer", i32 2}
!27 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!28 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!29 = distinct !DISubprogram(name: "private_sum", scope: !10, file: !10, line: 3, type: !30, scopeLine: 3, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !33)
!30 = !DISubroutineType(types: !31)
!31 = !{!8, !8, !32}
!32 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!33 = !{!34, !35, !36}
!34 = !DILocalVariable(name: "seed", arg: 1, scope: !29, file: !10, line: 3, type: !8)
!35 = !DILocalVariable(name: "index", arg: 2, scope: !29, file: !10, line: 3, type: !32)
!36 = !DILocalVariable(name: "state", scope: !29, file: !10, line: 4, type: !11)
!37 = distinct !DIAssignID()
!38 = !DILocation(line: 0, scope: !29)
!39 = !DILocation(line: 4, column: 5, scope: !29)
!40 = !DILocation(line: 5, column: 15, scope: !29)
!41 = !{!42, !42, i64 0}
!42 = !{!"omnipotent char", !43, i64 0}
!43 = !{!"Simple C/C++ TBAA"}
!44 = distinct !DIAssignID()
!45 = !DILocation(line: 5, column: 36, scope: !29)
!46 = !DILocation(line: 5, column: 21, scope: !29)
!47 = !DILocation(line: 5, column: 31, scope: !29)
!48 = distinct !DIAssignID()
!49 = !DILocation(line: 5, column: 54, scope: !29)
!50 = !DILocation(line: 5, column: 39, scope: !29)
!51 = !DILocation(line: 5, column: 49, scope: !29)
!52 = distinct !DIAssignID()
!53 = !DILocation(line: 5, column: 72, scope: !29)
!54 = !DILocation(line: 5, column: 57, scope: !29)
!55 = !DILocation(line: 5, column: 67, scope: !29)
!56 = distinct !DIAssignID()
!57 = !DILocation(line: 6, column: 25, scope: !29)
!58 = !DILocation(line: 6, column: 12, scope: !29)
!59 = !DILocation(line: 7, column: 1, scope: !29)
!60 = !DILocation(line: 6, column: 5, scope: !29)
!61 = distinct !DISubprogram(name: "global_access", scope: !10, file: !10, line: 8, type: !62, scopeLine: 8, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !64)
!62 = !DISubroutineType(types: !63)
!63 = !{!8, !8}
!64 = !{!65}
!65 = !DILocalVariable(name: "seed", arg: 1, scope: !61, file: !10, line: 8, type: !8)
!66 = !DILocation(line: 0, scope: !61)
!67 = !DILocation(line: 8, column: 68, scope: !61)
!68 = !DILocation(line: 8, column: 81, scope: !61)
!69 = !DILocation(line: 8, column: 74, scope: !61)
!70 = distinct !DISubprogram(name: "pointer_access", scope: !10, file: !10, line: 9, type: !71, scopeLine: 9, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !75)
!71 = !DISubroutineType(types: !72)
!72 = !{!8, !8, !73}
!73 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !74, size: 64)
!74 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !8)
!75 = !{!76, !77}
!76 = !DILocalVariable(name: "seed", arg: 1, scope: !70, file: !10, line: 9, type: !8)
!77 = !DILocalVariable(name: "p", arg: 2, scope: !70, file: !10, line: 9, type: !73)
!78 = !DILocation(line: 0, scope: !70)
!79 = !DILocation(line: 9, column: 80, scope: !70)
!80 = !{!81, !81, i64 0}
!81 = !{!"long", !42, i64 0}
!82 = !DILocation(line: 9, column: 93, scope: !70)
!83 = !DILocation(line: 9, column: 86, scope: !70)
!84 = distinct !DISubprogram(name: "mixed", scope: !10, file: !10, line: 10, type: !85, scopeLine: 10, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !88)
!85 = !DISubroutineType(types: !86)
!86 = !{!8, !8, !32, !87, !73}
!87 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!88 = !{!89, !90, !91, !92, !93, !94}
!89 = !DILocalVariable(name: "seed", arg: 1, scope: !84, file: !10, line: 10, type: !8)
!90 = !DILocalVariable(name: "index", arg: 2, scope: !84, file: !10, line: 10, type: !32)
!91 = !DILocalVariable(name: "choose", arg: 3, scope: !84, file: !10, line: 10, type: !87)
!92 = !DILocalVariable(name: "external", arg: 4, scope: !84, file: !10, line: 10, type: !73)
!93 = !DILocalVariable(name: "state", scope: !84, file: !10, line: 11, type: !11)
!94 = !DILocalVariable(name: "p", scope: !84, file: !10, line: 12, type: !73)
!95 = distinct !DIAssignID()
!96 = !DILocation(line: 0, scope: !84)
!97 = !DILocation(line: 11, column: 5, scope: !84)
!98 = !DILocation(line: 12, column: 31, scope: !84)
!99 = !DILocation(line: 13, column: 7, scope: !84)
!100 = !DILocation(line: 13, column: 20, scope: !84)
!101 = !DILocation(line: 14, column: 1, scope: !84)
!102 = !DILocation(line: 13, column: 13, scope: !84)
!103 = distinct !DISubprogram(name: "other_local", scope: !10, file: !10, line: 15, type: !62, scopeLine: 15, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !104)
!104 = !{!105, !106}
!105 = !DILocalVariable(name: "seed", arg: 1, scope: !103, file: !10, line: 15, type: !8)
!106 = !DILocalVariable(name: "value", scope: !103, file: !10, line: 15, type: !74)
!107 = distinct !DIAssignID()
!108 = !DILocation(line: 0, scope: !103)
!109 = !DILocation(line: 15, column: 49, scope: !103)
!110 = !DILocation(line: 15, column: 72, scope: !103)
!111 = distinct !DIAssignID()
!112 = !DILocation(line: 15, column: 90, scope: !103)
!113 = !DILocation(line: 15, column: 97, scope: !103)
!114 = !DILocation(line: 15, column: 83, scope: !103)
!115 = distinct !DISubprogram(name: "atomic_local", scope: !10, file: !10, line: 16, type: !30, scopeLine: 16, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !116)
!116 = !{!117, !118, !119, !120}
!117 = !DILocalVariable(name: "seed", arg: 1, scope: !115, file: !10, line: 16, type: !8)
!118 = !DILocalVariable(name: "index", arg: 2, scope: !115, file: !10, line: 16, type: !32)
!119 = !DILocalVariable(name: "state", scope: !115, file: !10, line: 17, type: !12)
!120 = !DILocalVariable(name: "p", scope: !115, file: !10, line: 18, type: !5)
!121 = distinct !DIAssignID()
!122 = !DILocation(line: 0, scope: !115)
!123 = !DILocation(line: 17, column: 5, scope: !115)
!124 = !DILocation(line: 18, column: 87, scope: !115)
!125 = !DILocation(line: 18, column: 74, scope: !115)
!126 = !DILocation(line: 19, column: 5, scope: !115)
!127 = !DILocation(line: 19, column: 41, scope: !115)
!128 = !DILocation(line: 20, column: 1, scope: !115)
!129 = !DILocation(line: 19, column: 34, scope: !115)
