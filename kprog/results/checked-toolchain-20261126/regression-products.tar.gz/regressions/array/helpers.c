typedef unsigned __kprog_array_u32 __attribute__((aligned(1),may_alias));
static __attribute__((always_inline)) inline void *
__kprog_native_array_lookup(void *map, const void *key) {
    unsigned index = *(const __kprog_array_u32 *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    return __kprog_native_array_lookup(map,key);
}
