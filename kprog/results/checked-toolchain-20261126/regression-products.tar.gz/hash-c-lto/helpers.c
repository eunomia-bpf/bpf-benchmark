#include "/workspaces/repository/kprog/x86/micro-prog/native_hash.h"
__KPROG_HASH_CODE
static __attribute__((noinline)) void *__kprog_hash_key_8(void *map,const void *key) { return __kprog_hash_lookup(map,key,8,448,824,832,16,0,0,0,40,48); }
static __attribute__((noinline)) void *__kprog_hash_key_16(void *map,const void *key) { return __kprog_hash_lookup(map,key,16,448,824,832,16,0,0,0,40,48); }
extern unsigned char __kprog_hash_map_0[] __asm__("map_a");
extern unsigned char __kprog_hash_map_1[] __asm__("map_same");
extern unsigned char __kprog_hash_map_2[] __asm__("map_b");
typedef unsigned __kprog_array_u32 __attribute__((aligned(1),may_alias));
static __attribute__((always_inline)) inline void *
__kprog_native_array_lookup(void *map, const void *key) {
    unsigned index = *(const __kprog_array_u32 *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_hash_map_0 || map == __kprog_hash_map_1) return __kprog_hash_key_8(map,key);
    if (map == __kprog_hash_map_2) return __kprog_hash_key_16(map,key);
    return __kprog_native_array_lookup(map,key);
}
