#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 312U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(21) M(22) M(23) M(24) M(25) M(30) M(31)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 hotspot_procs[] __ksym;
extern __u8 interpreter_offsets[] __ksym;
extern __u8 metrics[] __ksym;
extern __u8 per_cpu_records[] __ksym;
extern __u8 perf_progs[] __ksym;
extern __u8 pid_page_to_mapping_info[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_REG, X86_OP_ALU_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BZHI_MEM, X86_OP_BZHI_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_STORE, X86_OP_MOVBE_STORE)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX, X86_OP_SHIFTX)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SHIFTX_MEM, X86_OP_SHIFTX_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("perf_event")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 264ULL);
x86_l_11:
	/* 0x11: mov    rbx,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_1c:
	/* 0x1c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_23:
	/* 0x23: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_28:
	/* 0x28: call   2d <perf_unwind_hotspot+0x2d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d:
	/* 0x2d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30:
	/* 0x30: je     23a <perf_unwind_hotspot+0x23a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30, 0x23a, x86_l_23a);
x86_l_36:
	/* 0x36: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39:
	/* 0x39: mov    eax,DWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b:
	/* 0x3b: mov    DWORD PTR [rsp+0x104],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 260ULL);
x86_l_42:
	/* 0x42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)hotspot_procs));
x86_l_49:
	/* 0x49: lea    rsi,[rsp+0x104] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 260ULL);
x86_l_51:
	/* 0x51: call   56 <perf_unwind_hotspot+0x56> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_56:
	/* 0x56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_59:
	/* 0x59: je     195 <perf_unwind_hotspot+0x195> */
	X86_SIM_X86_JCC(X86_CC_E, 0x59, 0x195, x86_l_195);
x86_l_5f:
	/* 0x5f: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_62:
	/* 0x62: mov    QWORD PTR [rsp+0xf0],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_6a:
	/* 0x6a: mov    DWORD PTR [rsp+0x40],0x29 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906985ULL);
x86_l_72:
	/* 0x72: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_79:
	/* 0x79: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7e:
	/* 0x7e: call   83 <perf_unwind_hotspot+0x83> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_83:
	/* 0x83: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86:
	/* 0x86: je     8b <perf_unwind_hotspot+0x8b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x86, 0x8b, x86_l_8b);
x86_l_88:
	/* 0x88: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_8b:
	/* 0x8b: mov    rbp,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_92:
	/* 0x92: mov    rbx,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_99:
	/* 0x99: mov    rax,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_a0:
	/* 0xa0: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a5:
	/* 0xa5: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_aa:
	/* 0xaa: shrx   r13,QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_R13, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((3864ULL << 32) | X86_ALU_SHR));
x86_l_b3:
	/* 0xb3: mov    al,0x38 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 56ULL);
x86_l_b5:
	/* 0xb5: bzhi   r12,QWORD PTR [r14+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_R12, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), 3856ULL);
x86_l_be:
	/* 0xbe: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_c2:
	/* 0xc2: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_c7:
	/* 0xc7: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_cc:
	/* 0xcc: call   d1 <perf_unwind_hotspot+0xd1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_d1:
	/* 0xd1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d4:
	/* 0xd4: je     19c <perf_unwind_hotspot+0x19c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd4, 0x19c, x86_l_19c);
x86_l_da:
	/* 0xda: mov    QWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_e6:
	/* 0xe6: mov    DWORD PTR [rsp+0x40],0x2b */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906987ULL);
x86_l_ee:
	/* 0xee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_f5:
	/* 0xf5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_fa:
	/* 0xfa: call   ff <perf_unwind_hotspot+0xff> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ff:
	/* 0xff: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_102:
	/* 0x102: je     107 <perf_unwind_hotspot+0x107> */
	X86_SIM_X86_JCC(X86_CC_E, 0x102, 0x107, x86_l_107);
x86_l_104:
	/* 0x104: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_107:
	/* 0x107: mov    eax,0x3e8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1000ULL);
x86_l_10c:
	/* 0x10c: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_10e:
	/* 0x10e: mov    r13d,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_111:
	/* 0x111: mov    r15,QWORD PTR [rsp+0xf0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240ULL);
x86_l_119:
	/* 0x119: mov    DWORD PTR [r14+0xf2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3884ULL);
x86_l_120:
	/* 0x120: mov    DWORD PTR [rsp+0x40],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_128:
	/* 0x128: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_12f:
	/* 0x12f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_134:
	/* 0x134: call   139 <perf_unwind_hotspot+0x139> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_139:
	/* 0x139: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13c:
	/* 0x13c: je     227 <perf_unwind_hotspot+0x227> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c, 0x227, x86_l_227);
x86_l_142:
	/* 0x142: movzx  ecx,BYTE PTR [rax+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_149:
	/* 0x149: cmp    cl,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 29ULL);
x86_l_14c:
	/* 0x14c: jb     188 <perf_unwind_hotspot+0x188> */
	X86_SIM_X86_JCC(X86_CC_B, 0x14c, 0x188, x86_l_188);
x86_l_14e:
	/* 0x14e: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_151:
	/* 0x151: mov    DWORD PTR [rax+0xf2c],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16681652977669ULL);
x86_l_15b:
	/* 0x15b: mov    DWORD PTR [rsp+0x40],0x44 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907012ULL);
x86_l_163:
	/* 0x163: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_16a:
	/* 0x16a: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_16f:
	/* 0x16f: call   174 <perf_unwind_hotspot+0x174> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_174:
	/* 0x174: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_177:
	/* 0x177: je     17c <perf_unwind_hotspot+0x17c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x177, 0x17c, x86_l_17c);
x86_l_179:
	/* 0x179: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_17c:
	/* 0x17c: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: movzx  ecx,BYTE PTR [rbx+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_186:
	/* 0x186: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_188:
	/* 0x188: inc    cl */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_18a:
	/* 0x18a: mov    BYTE PTR [rax+0x1384],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4996ULL);
x86_l_190:
	/* 0x190: jmp    229 <perf_unwind_hotspot+0x229> */
	X86_SIM_X86_JMP(0x190, 0x229, x86_l_229);
x86_l_195:
	/* 0x195: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_197:
	/* 0x197: jmp    23f <perf_unwind_hotspot+0x23f> */
	X86_SIM_X86_JMP(0x197, 0x23f, x86_l_23f);
x86_l_19c:
	/* 0x19c: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1a1:
	/* 0x1a1: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a4:
	/* 0x1a4: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1a7:
	/* 0x1a7: jae    255 <perf_unwind_hotspot+0x255> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a7, 0x255, x86_l_255);
x86_l_1ad:
	/* 0x1ad: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1af:
	/* 0x1af: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1af, 0xda, x86_l_da);
x86_l_1b5:
	/* 0x1b5: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_1ba:
	/* 0x1ba: shlx   rax,r13,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_R13, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_1bf:
	/* 0x1bf: add    rax,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 3872ULL);
x86_l_1c6:
	/* 0x1c6: movzx  edx,BYTE PTR [r15+0x1b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 27ULL);
x86_l_1cb:
	/* 0x1cb: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1ce:
	/* 0x1ce: mov    QWORD PTR [rsp+0xb0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1d6:
	/* 0x1d6: je     e6 <perf_unwind_hotspot+0xe6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d6, 0xe6, x86_l_e6);
x86_l_1dc:
	/* 0x1dc: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1df:
	/* 0x1df: add    r12,0xf80 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3968ULL);
x86_l_1e6:
	/* 0x1e6: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e9:
	/* 0x1e9: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_1ee:
	/* 0x1ee: call   1f3 <perf_unwind_hotspot+0x1f3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f3:
	/* 0x1f3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f6:
	/* 0x1f6: je     48d <perf_unwind_hotspot+0x48d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1f6, 0x48d, x86_l_48d);
x86_l_1fc:
	/* 0x1fc: mov    DWORD PTR [rsp+0x40],0x2c */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906988ULL);
x86_l_204:
	/* 0x204: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_20b:
	/* 0x20b: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_210:
	/* 0x210: call   215 <perf_unwind_hotspot+0x215> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_215:
	/* 0x215: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_218:
	/* 0x218: je     21d <perf_unwind_hotspot+0x21d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x218, 0x21d, x86_l_21d);
x86_l_21a:
	/* 0x21a: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_21d:
	/* 0x21d: mov    eax,0x3eb */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1003ULL);
x86_l_222:
	/* 0x222: jmp    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JMP(0x222, 0x10c, x86_l_10c);
x86_l_227:
	/* 0x227: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_229:
	/* 0x229: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)perf_progs));
x86_l_230:
	/* 0x230: mov    rdi,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_233:
	/* 0x233: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_235:
	/* 0x235: call   23a <perf_unwind_hotspot+0x23a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_23a:
	/* 0x23a: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_23f:
	/* 0x23f: add    rsp,0x108 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 264ULL);
x86_l_246:
	/* 0x246: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_247:
	/* 0x247: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_249:
	/* 0x249: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_24b:
	/* 0x24b: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_24d:
	/* 0x24d: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_24f:
	/* 0x24f: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_250:
	/* 0x250: jmp    32db <section:SectionIndex(15):.rodata:table_54+0x327b> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_255:
	/* 0x255: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_258:
	/* 0x258: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_25b:
	/* 0x25b: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_25f:
	/* 0x25f: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_264:
	/* 0x264: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_269:
	/* 0x269: call   26e <perf_unwind_hotspot+0x26e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_26e:
	/* 0x26e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_271:
	/* 0x271: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x271, 0xda, x86_l_da);
x86_l_277:
	/* 0x277: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_27c:
	/* 0x27c: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_27f:
	/* 0x27f: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_282:
	/* 0x282: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x282, 0x1ad, x86_l_1ad);
x86_l_288:
	/* 0x288: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_28b:
	/* 0x28b: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_28e:
	/* 0x28e: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_292:
	/* 0x292: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_297:
	/* 0x297: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_29c:
	/* 0x29c: call   2a1 <perf_unwind_hotspot+0x2a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a1:
	/* 0x2a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a4:
	/* 0x2a4: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a4, 0xda, x86_l_da);
x86_l_2aa:
	/* 0x2aa: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2af:
	/* 0x2af: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b2:
	/* 0x2b2: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2b5:
	/* 0x2b5: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b5, 0x1ad, x86_l_1ad);
x86_l_2bb:
	/* 0x2bb: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2be:
	/* 0x2be: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2c1:
	/* 0x2c1: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2c5:
	/* 0x2c5: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ca:
	/* 0x2ca: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2cf:
	/* 0x2cf: call   2d4 <perf_unwind_hotspot+0x2d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2d4:
	/* 0x2d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d7:
	/* 0x2d7: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d7, 0xda, x86_l_da);
x86_l_2dd:
	/* 0x2dd: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2e2:
	/* 0x2e2: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2e5:
	/* 0x2e5: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2e8:
	/* 0x2e8: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e8, 0x1ad, x86_l_1ad);
x86_l_2ee:
	/* 0x2ee: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2f1:
	/* 0x2f1: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2f4:
	/* 0x2f4: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2f8:
	/* 0x2f8: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2fd:
	/* 0x2fd: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_302:
	/* 0x302: call   307 <perf_unwind_hotspot+0x307> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_307:
	/* 0x307: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_30a:
	/* 0x30a: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x30a, 0xda, x86_l_da);
x86_l_310:
	/* 0x310: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_315:
	/* 0x315: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_318:
	/* 0x318: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_31b:
	/* 0x31b: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x31b, 0x1ad, x86_l_1ad);
x86_l_321:
	/* 0x321: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_324:
	/* 0x324: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_327:
	/* 0x327: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_32b:
	/* 0x32b: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_330:
	/* 0x330: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_335:
	/* 0x335: call   33a <perf_unwind_hotspot+0x33a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_33a:
	/* 0x33a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_33d:
	/* 0x33d: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x33d, 0xda, x86_l_da);
x86_l_343:
	/* 0x343: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_348:
	/* 0x348: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_34b:
	/* 0x34b: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_34e:
	/* 0x34e: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x34e, 0x1ad, x86_l_1ad);
x86_l_354:
	/* 0x354: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_357:
	/* 0x357: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_35a:
	/* 0x35a: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_35e:
	/* 0x35e: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_363:
	/* 0x363: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_368:
	/* 0x368: call   36d <perf_unwind_hotspot+0x36d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_36d:
	/* 0x36d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_370:
	/* 0x370: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x370, 0xda, x86_l_da);
x86_l_376:
	/* 0x376: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_37b:
	/* 0x37b: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_37e:
	/* 0x37e: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_381:
	/* 0x381: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x381, 0x1ad, x86_l_1ad);
x86_l_387:
	/* 0x387: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_38a:
	/* 0x38a: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_38d:
	/* 0x38d: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_391:
	/* 0x391: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_396:
	/* 0x396: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_39b:
	/* 0x39b: call   3a0 <perf_unwind_hotspot+0x3a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3a0:
	/* 0x3a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3a3:
	/* 0x3a3: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3a3, 0xda, x86_l_da);
x86_l_3a9:
	/* 0x3a9: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_3ae:
	/* 0x3ae: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3b1:
	/* 0x3b1: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3b4:
	/* 0x3b4: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3b4, 0x1ad, x86_l_1ad);
x86_l_3ba:
	/* 0x3ba: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_3bd:
	/* 0x3bd: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_3c0:
	/* 0x3c0: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3c4:
	/* 0x3c4: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3c9:
	/* 0x3c9: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_3ce:
	/* 0x3ce: call   3d3 <perf_unwind_hotspot+0x3d3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3d3:
	/* 0x3d3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3d6:
	/* 0x3d6: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3d6, 0xda, x86_l_da);
x86_l_3dc:
	/* 0x3dc: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_3e1:
	/* 0x3e1: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3e4:
	/* 0x3e4: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_3e7:
	/* 0x3e7: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3e7, 0x1ad, x86_l_1ad);
x86_l_3ed:
	/* 0x3ed: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_3f0:
	/* 0x3f0: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_3f3:
	/* 0x3f3: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3f7:
	/* 0x3f7: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3fc:
	/* 0x3fc: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_401:
	/* 0x401: call   406 <perf_unwind_hotspot+0x406> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_406:
	/* 0x406: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_409:
	/* 0x409: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x409, 0xda, x86_l_da);
x86_l_40f:
	/* 0x40f: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_414:
	/* 0x414: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_417:
	/* 0x417: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_41a:
	/* 0x41a: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x41a, 0x1ad, x86_l_1ad);
x86_l_420:
	/* 0x420: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_423:
	/* 0x423: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_426:
	/* 0x426: lea    rdx,[r12+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_42a:
	/* 0x42a: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_42f:
	/* 0x42f: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_434:
	/* 0x434: call   439 <perf_unwind_hotspot+0x439> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_439:
	/* 0x439: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_43c:
	/* 0x43c: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x43c, 0xda, x86_l_da);
x86_l_442:
	/* 0x442: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_447:
	/* 0x447: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_44a:
	/* 0x44a: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_44d:
	/* 0x44d: jb     1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JCC(X86_CC_B, 0x44d, 0x1ad, x86_l_1ad);
x86_l_453:
	/* 0x453: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_456:
	/* 0x456: sub    r13,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_459:
	/* 0x459: add    r12,r13 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R13, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_45c:
	/* 0x45c: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_461:
	/* 0x461: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_466:
	/* 0x466: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_469:
	/* 0x469: call   46e <perf_unwind_hotspot+0x46e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_46e:
	/* 0x46e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_471:
	/* 0x471: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x471, 0xda, x86_l_da);
x86_l_477:
	/* 0x477: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_47c:
	/* 0x47c: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_47f:
	/* 0x47f: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_482:
	/* 0x482: ja     da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_A, 0x482, 0xda, x86_l_da);
x86_l_488:
	/* 0x488: jmp    1ad <perf_unwind_hotspot+0x1ad> */
	X86_SIM_X86_JMP(0x488, 0x1ad, x86_l_1ad);
x86_l_48d:
	/* 0x48d: movzx  ecx,WORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_492:
	/* 0x492: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_497:
	/* 0x497: cmp    rcx,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_49e:
	/* 0x49e: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x49e, 0x10c, x86_l_10c);
x86_l_4a4:
	/* 0x4a4: movzx  edx,WORD PTR [r15+0x12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18ULL);
x86_l_4a9:
	/* 0x4a9: cmp    rdx,0x1fc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 508ULL);
x86_l_4b0:
	/* 0x4b0: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4b0, 0x10c, x86_l_10c);
x86_l_4b6:
	/* 0x4b6: movzx  esi,WORD PTR [r15+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_4bb:
	/* 0x4bb: cmp    rsi,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_4c2:
	/* 0x4c2: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x4c2, 0x10c, x86_l_10c);
x86_l_4c8:
	/* 0x4c8: movzx  eax,BYTE PTR [r15+0x17] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_4cd:
	/* 0x4cd: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4d1:
	/* 0x4d1: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_4d9:
	/* 0x4d9: movzx  eax,BYTE PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 24ULL);
x86_l_4de:
	/* 0x4de: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4e2:
	/* 0x4e2: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_4ea:
	/* 0x4ea: movzx  eax,BYTE PTR [r15+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 26ULL);
x86_l_4ef:
	/* 0x4ef: mov    eax,DWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_4f3:
	/* 0x4f3: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_4f6:
	/* 0x4f6: mov    DWORD PTR [rsp+0xd8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_4fd:
	/* 0x4fd: movzx  eax,BYTE PTR [r15+0x19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 25ULL);
x86_l_502:
	/* 0x502: movzx  eax,WORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_16), 0ULL);
x86_l_507:
	/* 0x507: mov    WORD PTR [rsp+0xe0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_50f:
	/* 0x50f: mov    eax,DWORD PTR [r12+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_513:
	/* 0x513: mov    DWORD PTR [rsp+0xdc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_51a:
	/* 0x51a: mov    eax,DWORD PTR [r12+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_51e:
	/* 0x51e: mov    DWORD PTR [rsp+0xd4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_525:
	/* 0x525: lea    rdi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_52d:
	/* 0x52d: mov    rax,QWORD PTR [r12+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_531:
	/* 0x531: mov    QWORD PTR [rsp+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_539:
	/* 0x539: movzx  eax,BYTE PTR [r15+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_53e:
	/* 0x53e: mov    rdx,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_542:
	/* 0x542: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_547:
	/* 0x547: call   54c <perf_unwind_hotspot+0x54c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_54c:
	/* 0x54c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_54f:
	/* 0x54f: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x54f, 0x1fc, x86_l_1fc);
x86_l_555:
	/* 0x555: movzx  eax,BYTE PTR [r15+0x21] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 33ULL);
x86_l_55a:
	/* 0x55a: mov    rsi,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_562:
	/* 0x562: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_56a:
	/* 0x56a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_56c:
	/* 0x56c: mov    QWORD PTR [rsp+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_571:
	/* 0x571: je     592 <perf_unwind_hotspot+0x592> */
	X86_SIM_X86_JCC(X86_CC_E, 0x571, 0x592, x86_l_592);
x86_l_573:
	/* 0x573: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_575:
	/* 0x575: add    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_578:
	/* 0x578: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_580:
	/* 0x580: mov    edx,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_587:
	/* 0x587: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_58a:
	/* 0x58a: mov    QWORD PTR [rsp+0xc0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_592:
	/* 0x592: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_597:
	/* 0x597: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_59a:
	/* 0x59a: mov    esi,DWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_5a1:
	/* 0x5a1: mov    edx,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_5a3:
	/* 0x5a3: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_5a5:
	/* 0x5a5: cmp    esi,0x6974616d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1769234797ULL);
x86_l_5ab:
	/* 0x5ab: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_5b3:
	/* 0x5b3: jg     62a <perf_unwind_hotspot+0x62a> */
	X86_SIM_X86_JCC(X86_CC_G, 0x5b3, 0x62a, x86_l_62a);
x86_l_5b5:
	/* 0x5b5: cmp    esi,0x62617476 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1650553974ULL);
x86_l_5bb:
	/* 0x5bb: je     779 <perf_unwind_hotspot+0x779> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5bb, 0x779, x86_l_779);
x86_l_5c1:
	/* 0x5c1: cmp    esi,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_5c7:
	/* 0x5c7: jne    6ed <perf_unwind_hotspot+0x6ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x5c7, 0x6ed, x86_l_6ed);
x86_l_5cd:
	/* 0x5cd: cmp    r13,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_5d0:
	/* 0x5d0: jb     be6 <perf_unwind_hotspot+0xbe6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x5d0, 0xbe6, x86_l_be6);
x86_l_5d6:
	/* 0x5d6: lea    rax,[rbx+0x1000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4096ULL);
x86_l_5dd:
	/* 0x5dd: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5e0:
	/* 0x5e0: jae    be6 <perf_unwind_hotspot+0xbe6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5e0, 0xbe6, x86_l_be6);
x86_l_5e6:
	/* 0x5e6: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_5eb:
	/* 0x5eb: lea    rdx,[rax-0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551536ULL);
x86_l_5ef:
	/* 0x5ef: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_5f4:
	/* 0x5f4: mov    esi,0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 96ULL);
x86_l_5f9:
	/* 0x5f9: call   5fe <perf_unwind_hotspot+0x5fe> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_5fe:
	/* 0x5fe: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_601:
	/* 0x601: jne    be6 <perf_unwind_hotspot+0xbe6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x601, 0xbe6, x86_l_be6);
x86_l_607:
	/* 0x607: cmp    DWORD PTR [r14+0x2c0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3023656976384ULL);
x86_l_60f:
	/* 0x60f: je     aee <perf_unwind_hotspot+0xaee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x60f, 0xaee, x86_l_aee);
x86_l_615:
	/* 0x615: cmp    BYTE PTR [r15+0x1f],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986176ULL);
x86_l_61a:
	/* 0x61a: je     b9a <perf_unwind_hotspot+0xb9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61a, 0xb9a, x86_l_b9a);
x86_l_620:
	/* 0x620: mov    r13,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_625:
	/* 0x625: jmp    b9f <perf_unwind_hotspot+0xb9f> */
	X86_SIM_X86_JMP(0x625, 0xb9f, x86_l_b9f);
x86_l_62a:
	/* 0x62a: cmp    esi,0x74656d6e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1952804206ULL);
x86_l_630:
	/* 0x630: je     63e <perf_unwind_hotspot+0x63e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x630, 0x63e, x86_l_63e);
x86_l_632:
	/* 0x632: cmp    esi,0x6974616e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1769234798ULL);
x86_l_638:
	/* 0x638: jne    6ed <perf_unwind_hotspot+0x6ed> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x638, 0x6ed, x86_l_6ed);
x86_l_63e:
	/* 0x63e: mov    rdx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_646:
	/* 0x646: mov    esi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_648:
	/* 0x648: add    rsi,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_64d:
	/* 0x64d: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_64f:
	/* 0x64f: movzx  r13d,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_657:
	/* 0x657: mov    eax,DWORD PTR [rsp+0xdc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_65e:
	/* 0x65e: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_663:
	/* 0x663: cmove  rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RDX, X86_WIDTH_64, X86_CC_E, 0);
x86_l_667:
	/* 0x667: cmp    rdi,rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RSI, X86_WIDTH_64, 0, 0);
x86_l_66a:
	/* 0x66a: jne    6b8 <perf_unwind_hotspot+0x6b8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x66a, 0x6b8, x86_l_6b8);
x86_l_66c:
	/* 0x66c: mov    edx,DWORD PTR [rsp+0xd4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_673:
	/* 0x673: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_676:
	/* 0x676: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_67b:
	/* 0x67b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_680:
	/* 0x680: call   685 <perf_unwind_hotspot+0x685> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_685:
	/* 0x685: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_68d:
	/* 0x68d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_690:
	/* 0x690: jne    6b5 <perf_unwind_hotspot+0x6b5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x690, 0x6b5, x86_l_6b5);
x86_l_692:
	/* 0x692: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_697:
	/* 0x697: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_69a:
	/* 0x69a: jb     6b5 <perf_unwind_hotspot+0x6b5> */
	X86_SIM_X86_JCC(X86_CC_B, 0x69a, 0x6b5, x86_l_6b5);
x86_l_69c:
	/* 0x69c: cmp    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 192ULL);
x86_l_6a4:
	/* 0x6a4: jae    6b5 <perf_unwind_hotspot+0x6b5> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6a4, 0x6b5, x86_l_6b5);
x86_l_6a6:
	/* 0x6a6: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_6a8:
	/* 0x6a8: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_6aa:
	/* 0x6aa: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_6b2:
	/* 0x6b2: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6b5:
	/* 0x6b5: mov    rdi,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_6b8:
	/* 0x6b8: movzx  eax,WORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 224ULL);
x86_l_6c0:
	/* 0x6c0: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_6c3:
	/* 0x6c3: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6c6:
	/* 0x6c6: jae    709 <perf_unwind_hotspot+0x709> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6c6, 0x709, x86_l_709);
x86_l_6c8:
	/* 0x6c8: add    rax,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_6cc:
	/* 0x6cc: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_6ce:
	/* 0x6ce: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6d2:
	/* 0x6d2: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_6d5:
	/* 0x6d5: cmp    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6d8:
	/* 0x6d8: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_6dd:
	/* 0x6dd: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_6e2:
	/* 0x6e2: jae    764 <perf_unwind_hotspot+0x764> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x6e2, 0x764, x86_l_764);
x86_l_6e8:
	/* 0x6e8: jmp    77f <perf_unwind_hotspot+0x77f> */
	X86_SIM_X86_JMP(0x6e8, 0x77f, x86_l_77f);
x86_l_6ed:
	/* 0x6ed: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_6f4:
	/* 0x6f4: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_6fc:
	/* 0x6fc: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_6ff:
	/* 0x6ff: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_701:
	/* 0x701: jne    78f <perf_unwind_hotspot+0x78f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x701, 0x78f, x86_l_78f);
x86_l_707:
	/* 0x707: jmp    764 <perf_unwind_hotspot+0x764> */
	X86_SIM_X86_JMP(0x707, 0x764, x86_l_764);
x86_l_709:
	/* 0x709: mov    rbp,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_70c:
	/* 0x70c: test   r13b,r13b */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_8, 0, 0);
x86_l_70f:
	/* 0x70f: jne    72d <perf_unwind_hotspot+0x72d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x70f, 0x72d, x86_l_72d);
x86_l_711:
	/* 0x711: lea    rdx,[rbp-0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_715:
	/* 0x715: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_71a:
	/* 0x71a: mov    esi,0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 14ULL);
x86_l_71f:
	/* 0x71f: call   724 <perf_unwind_hotspot+0x724> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_724:
	/* 0x724: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_727:
	/* 0x727: je     9a8 <perf_unwind_hotspot+0x9a8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x727, 0x9a8, x86_l_9a8);
x86_l_72d:
	/* 0x72d: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_734:
	/* 0x734: lea    r13,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_738:
	/* 0x738: add    r13,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_73c:
	/* 0x73c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_741:
	/* 0x741: cmp    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_744:
	/* 0x744: jb     801 <perf_unwind_hotspot+0x801> */
	X86_SIM_X86_JCC(X86_CC_B, 0x744, 0x801, x86_l_801);
x86_l_74a:
	/* 0x74a: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_74c:
	/* 0x74c: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_750:
	/* 0x750: cmp    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_753:
	/* 0x753: jae    801 <perf_unwind_hotspot+0x801> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x753, 0x801, x86_l_801);
x86_l_759:
	/* 0x759: mov    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_75c:
	/* 0x75c: mov    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_75f:
	/* 0x75f: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_764:
	/* 0x764: mov    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_76f:
	/* 0x76f: mov    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_774:
	/* 0x774: mov    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_777:
	/* 0x777: jmp    78f <perf_unwind_hotspot+0x78f> */
	X86_SIM_X86_JMP(0x777, 0x78f, x86_l_78f);
x86_l_779:
	/* 0x779: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_77b:
	/* 0x77b: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_77f:
	/* 0x77f: mov    DWORD PTR [rsp+0xd8],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935944ULL);
x86_l_78a:
	/* 0x78a: mov    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_78f:
	/* 0x78f: mov    QWORD PTR [rsp+0x28],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_794:
	/* 0x794: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_796:
	/* 0x796: add    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_799:
	/* 0x799: lea    rdx,[rbx-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_79d:
	/* 0x79d: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7a2:
	/* 0x7a2: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_7a7:
	/* 0x7a7: call   7ac <perf_unwind_hotspot+0x7ac> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_7ac:
	/* 0x7ac: cmp    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_7b4:
	/* 0x7b4: jb     7bb <perf_unwind_hotspot+0x7bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7b4, 0x7bb, x86_l_7bb);
x86_l_7b6:
	/* 0x7b6: mov    r13,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7bb:
	/* 0x7bb: mov    rbp,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_7c0:
	/* 0x7c0: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7c5:
	/* 0x7c5: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_7cc:
	/* 0x7cc: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_7d0:
	/* 0x7d0: jb     cb0 <perf_unwind_hotspot+0xcb0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x7d0, 0xcb0, x86_l_cb0);
x86_l_7d6:
	/* 0x7d6: mov    DWORD PTR [rsp+0x40],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906946ULL);
x86_l_7de:
	/* 0x7de: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_7e5:
	/* 0x7e5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_7ea:
	/* 0x7ea: call   7ef <perf_unwind_hotspot+0x7ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7ef:
	/* 0x7ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7f2:
	/* 0x7f2: je     7f7 <perf_unwind_hotspot+0x7f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7f2, 0x7f7, x86_l_7f7);
x86_l_7f4:
	/* 0x7f4: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_7f7:
	/* 0x7f7: mov    eax,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_7fc:
	/* 0x7fc: jmp    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JMP(0x7fc, 0x10c, x86_l_10c);
x86_l_801:
	/* 0x801: lea    rcx,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_805:
	/* 0x805: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_80a:
	/* 0x80a: lea    rdx,[rbx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_80e:
	/* 0x80e: add    rdx,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_812:
	/* 0x812: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_817:
	/* 0x817: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_81c:
	/* 0x81c: call   821 <perf_unwind_hotspot+0x821> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_821:
	/* 0x821: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_824:
	/* 0x824: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_82c:
	/* 0x82c: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_832:
	/* 0x832: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_837:
	/* 0x837: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_83e:
	/* 0x83e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_845:
	/* 0x845: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_84a:
	/* 0x84a: call   84f <perf_unwind_hotspot+0x84f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_84f:
	/* 0x84f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_852:
	/* 0x852: je     885 <perf_unwind_hotspot+0x885> */
	X86_SIM_X86_JCC(X86_CC_E, 0x852, 0x885, x86_l_885);
x86_l_854:
	/* 0x854: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_858:
	/* 0x858: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_862:
	/* 0x862: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_865:
	/* 0x865: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_86f:
	/* 0x86f: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_872:
	/* 0x872: jne    885 <perf_unwind_hotspot+0x885> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x872, 0x885, x86_l_885);
x86_l_874:
	/* 0x874: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_876:
	/* 0x876: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_87b:
	/* 0x87b: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_880:
	/* 0x880: jmp    b5a <perf_unwind_hotspot+0xb5a> */
	X86_SIM_X86_JMP(0x880, 0xb5a, x86_l_b5a);
x86_l_885:
	/* 0x885: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_888:
	/* 0x888: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_890:
	/* 0x890: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_896:
	/* 0x896: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_89b:
	/* 0x89b: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_8a2:
	/* 0x8a2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_8a9:
	/* 0x8a9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_8ae:
	/* 0x8ae: call   8b3 <perf_unwind_hotspot+0x8b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_8b3:
	/* 0x8b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8b6:
	/* 0x8b6: je     8e6 <perf_unwind_hotspot+0x8e6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8b6, 0x8e6, x86_l_8e6);
x86_l_8b8:
	/* 0x8b8: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_8bc:
	/* 0x8bc: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_8c6:
	/* 0x8c6: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_8c9:
	/* 0x8c9: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_8d3:
	/* 0x8d3: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8d6:
	/* 0x8d6: jne    8e6 <perf_unwind_hotspot+0x8e6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8d6, 0x8e6, x86_l_8e6);
x86_l_8d8:
	/* 0x8d8: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_8dd:
	/* 0x8dd: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_8e1:
	/* 0x8e1: jmp    b53 <perf_unwind_hotspot+0xb53> */
	X86_SIM_X86_JMP(0x8e1, 0xb53, x86_l_b53);
x86_l_8e6:
	/* 0x8e6: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8e9:
	/* 0x8e9: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_8f1:
	/* 0x8f1: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_8f7:
	/* 0x8f7: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8fc:
	/* 0x8fc: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_903:
	/* 0x903: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_90a:
	/* 0x90a: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_90f:
	/* 0x90f: call   914 <perf_unwind_hotspot+0x914> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_914:
	/* 0x914: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_917:
	/* 0x917: je     947 <perf_unwind_hotspot+0x947> */
	X86_SIM_X86_JCC(X86_CC_E, 0x917, 0x947, x86_l_947);
x86_l_919:
	/* 0x919: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_91d:
	/* 0x91d: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_927:
	/* 0x927: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_92a:
	/* 0x92a: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_934:
	/* 0x934: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_937:
	/* 0x937: jne    947 <perf_unwind_hotspot+0x947> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x937, 0x947, x86_l_947);
x86_l_939:
	/* 0x939: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_93e:
	/* 0x93e: add    r13,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_942:
	/* 0x942: jmp    b53 <perf_unwind_hotspot+0xb53> */
	X86_SIM_X86_JMP(0x942, 0xb53, x86_l_b53);
x86_l_947:
	/* 0x947: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_94a:
	/* 0x94a: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_952:
	/* 0x952: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_958:
	/* 0x958: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_95d:
	/* 0x95d: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_964:
	/* 0x964: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_96b:
	/* 0x96b: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_970:
	/* 0x970: call   975 <perf_unwind_hotspot+0x975> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_975:
	/* 0x975: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_978:
	/* 0x978: je     9c1 <perf_unwind_hotspot+0x9c1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x978, 0x9c1, x86_l_9c1);
x86_l_97a:
	/* 0x97a: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_97e:
	/* 0x97e: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_988:
	/* 0x988: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_98b:
	/* 0x98b: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_995:
	/* 0x995: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_998:
	/* 0x998: jne    9c1 <perf_unwind_hotspot+0x9c1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x998, 0x9c1, x86_l_9c1);
x86_l_99a:
	/* 0x99a: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_99f:
	/* 0x99f: add    r13,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_9a3:
	/* 0x9a3: jmp    b53 <perf_unwind_hotspot+0xb53> */
	X86_SIM_X86_JMP(0x9a3, 0xb53, x86_l_b53);
x86_l_9a8:
	/* 0x9a8: movzx  eax,BYTE PTR [rsp+0x41] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 65ULL);
x86_l_9ad:
	/* 0x9ad: cmp    al,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_9af:
	/* 0x9af: jne    a2a <perf_unwind_hotspot+0xa2a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9af, 0xa2a, x86_l_a2a);
x86_l_9b1:
	/* 0x9b1: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_9b6:
	/* 0x9b6: mov    al,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_9b8:
	/* 0x9b8: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9bc:
	/* 0x9bc: jmp    c2c <perf_unwind_hotspot+0xc2c> */
	X86_SIM_X86_JMP(0x9bc, 0xc2c, x86_l_c2c);
x86_l_9c1:
	/* 0x9c1: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9c4:
	/* 0x9c4: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_9cc:
	/* 0x9cc: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_9d2:
	/* 0x9d2: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_9d7:
	/* 0x9d7: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_9de:
	/* 0x9de: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_9e5:
	/* 0x9e5: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9ea:
	/* 0x9ea: call   9ef <perf_unwind_hotspot+0x9ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_9ef:
	/* 0x9ef: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_9f2:
	/* 0x9f2: je     afa <perf_unwind_hotspot+0xafa> */
	X86_SIM_X86_JCC(X86_CC_E, 0x9f2, 0xafa, x86_l_afa);
x86_l_9f8:
	/* 0x9f8: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9fc:
	/* 0x9fc: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_a06:
	/* 0xa06: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_a09:
	/* 0xa09: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_a13:
	/* 0xa13: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a16:
	/* 0xa16: jne    afa <perf_unwind_hotspot+0xafa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa16, 0xafa, x86_l_afa);
x86_l_a1c:
	/* 0xa1c: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_a21:
	/* 0xa21: add    r13,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_a25:
	/* 0xa25: jmp    b53 <perf_unwind_hotspot+0xb53> */
	X86_SIM_X86_JMP(0xa25, 0xb53, x86_l_b53);
x86_l_a2a:
	/* 0xa2a: movzx  edx,BYTE PTR [rsp+0x42] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 66ULL);
x86_l_a2f:
	/* 0xa2f: movzx  r8d,BYTE PTR [rsp+0x43] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 67ULL);
x86_l_a35:
	/* 0xa35: movzx  edi,BYTE PTR [rsp+0x44] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 68ULL);
x86_l_a3a:
	/* 0xa3a: movzx  esi,BYTE PTR [rsp+0x47] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 71ULL);
x86_l_a3f:
	/* 0xa3f: cmp    dl,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_a42:
	/* 0xa42: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa42, 0xa92, x86_l_a92);
x86_l_a44:
	/* 0xa44: cmp    r8b,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_a48:
	/* 0xa48: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa48, 0xa92, x86_l_a92);
x86_l_a4a:
	/* 0xa4a: cmp    dil,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_a4e:
	/* 0xa4e: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa4e, 0xa92, x86_l_a92);
x86_l_a50:
	/* 0xa50: cmp    BYTE PTR [rsp+0x45],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 296352743619ULL);
x86_l_a55:
	/* 0xa55: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa55, 0xa92, x86_l_a92);
x86_l_a57:
	/* 0xa57: cmp    BYTE PTR [rsp+0x46],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 300647710915ULL);
x86_l_a5c:
	/* 0xa5c: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa5c, 0xa92, x86_l_a92);
x86_l_a5e:
	/* 0xa5e: cmp    sil,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_a62:
	/* 0xa62: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa62, 0xa92, x86_l_a92);
x86_l_a64:
	/* 0xa64: cmp    BYTE PTR [rsp+0x48],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 309237645507ULL);
x86_l_a69:
	/* 0xa69: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa69, 0xa92, x86_l_a92);
x86_l_a6b:
	/* 0xa6b: cmp    BYTE PTR [rsp+0x49],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 313532612803ULL);
x86_l_a70:
	/* 0xa70: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa70, 0xa92, x86_l_a92);
x86_l_a72:
	/* 0xa72: cmp    BYTE PTR [rsp+0x4a],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 317827580099ULL);
x86_l_a77:
	/* 0xa77: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa77, 0xa92, x86_l_a92);
x86_l_a79:
	/* 0xa79: cmp    BYTE PTR [rsp+0x4b],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 322122547395ULL);
x86_l_a7e:
	/* 0xa7e: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa7e, 0xa92, x86_l_a92);
x86_l_a80:
	/* 0xa80: cmp    BYTE PTR [rsp+0x4c],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 326417514691ULL);
x86_l_a85:
	/* 0xa85: je     a92 <perf_unwind_hotspot+0xa92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa85, 0xa92, x86_l_a92);
x86_l_a87:
	/* 0xa87: cmp    BYTE PTR [rsp+0x4d],0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 330712481987ULL);
x86_l_a8c:
	/* 0xa8c: jne    72d <perf_unwind_hotspot+0x72d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa8c, 0x72d, x86_l_72d);
x86_l_a92:
	/* 0xa92: mov    ecx,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_a97:
	/* 0xa97: cmp    al,0x5d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 93ULL);
x86_l_a99:
	/* 0xa99: je     9b6 <perf_unwind_hotspot+0x9b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa99, 0x9b6, x86_l_9b6);
x86_l_a9f:
	/* 0xa9f: cmp    al,0x41 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 65ULL);
x86_l_aa1:
	/* 0xaa1: jne    ab8 <perf_unwind_hotspot+0xab8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaa1, 0xab8, x86_l_ab8);
x86_l_aa3:
	/* 0xaa3: cmp    dl,0x85 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 133ULL);
x86_l_aa6:
	/* 0xaa6: jne    ab8 <perf_unwind_hotspot+0xab8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaa6, 0xab8, x86_l_ab8);
x86_l_aa8:
	/* 0xaa8: cmp    r8b,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R8, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_aac:
	/* 0xaac: jne    ab8 <perf_unwind_hotspot+0xab8> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaac, 0xab8, x86_l_ab8);
x86_l_aae:
	/* 0xaae: cmp    dil,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_ab2:
	/* 0xab2: je     9b1 <perf_unwind_hotspot+0x9b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xab2, 0x9b1, x86_l_9b1);
x86_l_ab8:
	/* 0xab8: cmp    al,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 15ULL);
x86_l_aba:
	/* 0xaba: jne    acb <perf_unwind_hotspot+0xacb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xaba, 0xacb, x86_l_acb);
x86_l_abc:
	/* 0xabc: cmp    dl,0x85 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 133ULL);
x86_l_abf:
	/* 0xabf: jne    acb <perf_unwind_hotspot+0xacb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xabf, 0xacb, x86_l_acb);
x86_l_ac1:
	/* 0xac1: cmp    sil,0xc3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, 0, 195ULL);
x86_l_ac5:
	/* 0xac5: je     9b1 <perf_unwind_hotspot+0x9b1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac5, 0x9b1, x86_l_9b1);
x86_l_acb:
	/* 0xacb: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_ad0:
	/* 0xad0: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_ad5:
	/* 0xad5: cmp    eax,0x5d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 93ULL);
x86_l_ad8:
	/* 0xad8: je     9b6 <perf_unwind_hotspot+0x9b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xad8, 0x9b6, x86_l_9b6);
x86_l_ade:
	/* 0xade: cmp    eax,0xc9 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 201ULL);
x86_l_ae3:
	/* 0xae3: je     9b6 <perf_unwind_hotspot+0x9b6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xae3, 0x9b6, x86_l_9b6);
x86_l_ae9:
	/* 0xae9: jmp    72d <perf_unwind_hotspot+0x72d> */
	X86_SIM_X86_JMP(0xae9, 0x72d, x86_l_72d);
x86_l_aee:
	/* 0xaee: mov    r13,QWORD PTR [r14+0xf00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_af5:
	/* 0xaf5: jmp    b9f <perf_unwind_hotspot+0xb9f> */
	X86_SIM_X86_JMP(0xaf5, 0xb9f, x86_l_b9f);
x86_l_afa:
	/* 0xafa: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_afd:
	/* 0xafd: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_b05:
	/* 0xb05: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_b0b:
	/* 0xb0b: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_b10:
	/* 0xb10: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_b17:
	/* 0xb17: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_b1e:
	/* 0xb1e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b23:
	/* 0xb23: call   b28 <perf_unwind_hotspot+0xb28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b28:
	/* 0xb28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b2b:
	/* 0xb2b: je     b70 <perf_unwind_hotspot+0xb70> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb2b, 0xb70, x86_l_b70);
x86_l_b2d:
	/* 0xb2d: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_b37:
	/* 0xb37: and    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_b3b:
	/* 0xb3b: movabs rax,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_b45:
	/* 0xb45: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b48:
	/* 0xb48: jne    b70 <perf_unwind_hotspot+0xb70> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb48, 0xb70, x86_l_b70);
x86_l_b4a:
	/* 0xb4a: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b4f:
	/* 0xb4f: add    r13,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_b53:
	/* 0xb53: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b55:
	/* 0xb55: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_b5a:
	/* 0xb5a: mov    dl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_b5c:
	/* 0xb5c: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b60:
	/* 0xb60: mov    rbx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b63:
	/* 0xb63: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_b65:
	/* 0xb65: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb65, 0x10c, x86_l_10c);
x86_l_b6b:
	/* 0xb6b: jmp    c2c <perf_unwind_hotspot+0xc2c> */
	X86_SIM_X86_JMP(0xb6b, 0xc2c, x86_l_c2c);
x86_l_b70:
	/* 0xb70: mov    DWORD PTR [rsp+0x10],0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476782ULL);
x86_l_b78:
	/* 0xb78: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_b7f:
	/* 0xb7f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b84:
	/* 0xb84: call   b89 <perf_unwind_hotspot+0xb89> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b89:
	/* 0xb89: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b8c:
	/* 0xb8c: je     b91 <perf_unwind_hotspot+0xb91> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb8c, 0xb91, x86_l_b91);
x86_l_b8e:
	/* 0xb8e: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_b91:
	/* 0xb91: mov    eax,0x3ea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1002ULL);
x86_l_b96:
	/* 0xb96: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_b98:
	/* 0xb98: jmp    b5a <perf_unwind_hotspot+0xb5a> */
	X86_SIM_X86_JMP(0xb98, 0xb5a, x86_l_b5a);
x86_l_b9a:
	/* 0xb9a: mov    r13,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_b9f:
	/* 0xb9f: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_ba4:
	/* 0xba4: mov    rbx,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_bac:
	/* 0xbac: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_bb4:
	/* 0xbb4: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bb9:
	/* 0xbb9: mov    rbp,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_bc1:
	/* 0xbc1: movzx  edx,BYTE PTR [r15+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_bc6:
	/* 0xbc6: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_bcb:
	/* 0xbcb: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_bce:
	/* 0xbce: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_bd3:
	/* 0xbd3: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_bd8:
	/* 0xbd8: call   bdd <perf_unwind_hotspot+0xbdd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_bdd:
	/* 0xbdd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_be0:
	/* 0xbe0: je     1123 <perf_unwind_hotspot+0x1123> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbe0, 0x1123, x86_l_1123);
x86_l_be6:
	/* 0xbe6: mov    DWORD PTR [rsp+0xec],0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281901ULL);
x86_l_bf1:
	/* 0xbf1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_bf8:
	/* 0xbf8: lea    rsi,[rsp+0xec] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236ULL);
x86_l_c00:
	/* 0xc00: call   c05 <perf_unwind_hotspot+0xc05> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c05:
	/* 0xc05: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c08:
	/* 0xc08: je     c0d <perf_unwind_hotspot+0xc0d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc08, 0xc0d, x86_l_c0d);
x86_l_c0a:
	/* 0xc0a: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_c0d:
	/* 0xc0d: mov    eax,0x3e9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1001ULL);
x86_l_c12:
	/* 0xc12: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_c14:
	/* 0xc14: mov    edx,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_c19:
	/* 0xc19: mov    QWORD PTR [rsp+0x28],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c1e:
	/* 0xc1e: mov    dl,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_c20:
	/* 0xc20: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c24:
	/* 0xc24: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_c26:
	/* 0xc26: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc26, 0x10c, x86_l_10c);
x86_l_c2c:
	/* 0xc2c: cmp    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_c2f:
	/* 0xc2f: ja     d5e <perf_unwind_hotspot+0xd5e> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc2f, 0xd5e, x86_l_d5e);
x86_l_c35:
	/* 0xc35: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_c37:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10cULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc4cULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc71ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc7eULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc5bULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc8bULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xc95ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_c45:
	/* 0xc45: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_c4a:
	/* 0xc4a: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10cULL: goto x86_l_10c;
			case 0xc4cULL: goto x86_l_c4c;
			case 0xc5bULL: goto x86_l_c5b;
			case 0xc71ULL: goto x86_l_c71;
			case 0xc7eULL: goto x86_l_c7e;
			case 0xc8bULL: goto x86_l_c8b;
			case 0xc95ULL: goto x86_l_c95;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c4c:
	/* 0xc4c: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c51:
	/* 0xc51: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c56:
	/* 0xc56: jmp    77f <perf_unwind_hotspot+0x77f> */
	X86_SIM_X86_JMP(0xc56, 0x77f, x86_l_77f);
x86_l_c5b:
	/* 0xc5b: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_c62:
	/* 0xc62: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c67:
	/* 0xc67: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c6c:
	/* 0xc6c: jmp    78f <perf_unwind_hotspot+0x78f> */
	X86_SIM_X86_JMP(0xc6c, 0x78f, x86_l_78f);
x86_l_c71:
	/* 0xc71: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c76:
	/* 0xc76: mov    rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_c79:
	/* 0xc79: jmp    75f <perf_unwind_hotspot+0x75f> */
	X86_SIM_X86_JMP(0xc79, 0x75f, x86_l_75f);
x86_l_c7e:
	/* 0xc7e: mov    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_c81:
	/* 0xc81: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c86:
	/* 0xc86: jmp    75f <perf_unwind_hotspot+0x75f> */
	X86_SIM_X86_JMP(0xc86, 0x75f, x86_l_75f);
x86_l_c8b:
	/* 0xc8b: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c90:
	/* 0xc90: jmp    799 <perf_unwind_hotspot+0x799> */
	X86_SIM_X86_JMP(0xc90, 0x799, x86_l_799);
x86_l_c95:
	/* 0xc95: mov    r13,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c9a:
	/* 0xc9a: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_c9f:
	/* 0xc9f: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_ca6:
	/* 0xca6: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_caa:
	/* 0xcaa: jae    7d6 <perf_unwind_hotspot+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xcaa, 0x7d6, x86_l_7d6);
x86_l_cb0:
	/* 0xcb0: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_cb8:
	/* 0xcb8: movzx  edx,BYTE PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_cbd:
	/* 0xcbd: shl    rdx,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 60ULL);
x86_l_cc1:
	/* 0xcc1: mov    rdi,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_cc9:
	/* 0xcc9: shl    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_ccd:
	/* 0xccd: mov    esi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_ccf:
	/* 0xccf: or     rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cd2:
	/* 0xcd2: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_cd5:
	/* 0xcd5: mov    DWORD PTR [r14+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_cdc:
	/* 0xcdc: or     rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_cdf:
	/* 0xcdf: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_ce3:
	/* 0xce3: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ce8:
	/* 0xce8: mov    QWORD PTR [r14+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_cf0:
	/* 0xcf0: mov    QWORD PTR [r14+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_cf8:
	/* 0xcf8: mov    BYTE PTR [r14+rax*8+0x2e0],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929861ULL);
x86_l_d01:
	/* 0xd01: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_d09:
	/* 0xd09: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_d15:
	/* 0xd15: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_d20:
	/* 0xd20: mov    QWORD PTR [r14+0xed0],rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_d27:
	/* 0xd27: mov    QWORD PTR [r14+0xed8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_d2e:
	/* 0xd2e: mov    QWORD PTR [r14+0xee0],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_d35:
	/* 0xd35: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_d3d:
	/* 0xd3d: mov    DWORD PTR [rsp+0x40],0x2a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906986ULL);
x86_l_d45:
	/* 0xd45: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_d4c:
	/* 0xd4c: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_d51:
	/* 0xd51: call   d56 <perf_unwind_hotspot+0xd56> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d56:
	/* 0xd56: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d59:
	/* 0xd59: je     d5e <perf_unwind_hotspot+0xd5e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd59, 0xd5e, x86_l_d5e);
x86_l_d5b:
	/* 0xd5b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_d5e:
	/* 0xd5e: mov    rbx,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_d65:
	/* 0xd65: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_d68:
	/* 0xd68: je     32ab <perf_unwind_hotspot+0x32ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd68, 0x32ab, x86_l_32ab);
x86_l_d6e:
	/* 0xd6e: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_d78:
	/* 0xd78: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d7b:
	/* 0xd7b: jbe    d95 <perf_unwind_hotspot+0xd95> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xd7b, 0xd95, x86_l_d95);
x86_l_d7d:
	/* 0xd7d: mov    DWORD PTR [r14+0xf28],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108491ULL);
x86_l_d88:
	/* 0xd88: mov    r13d,0xfab */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4011ULL);
x86_l_d8e:
	/* 0xd8e: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_d90:
	/* 0xd90: jmp    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JMP(0xd90, 0x111, x86_l_111);
x86_l_d95:
	/* 0xd95: cmp    rbx,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_d9c:
	/* 0xd9c: ja     db6 <perf_unwind_hotspot+0xdb6> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd9c, 0xdb6, x86_l_db6);
x86_l_d9e:
	/* 0xd9e: mov    DWORD PTR [r14+0xf28],0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108529ULL);
x86_l_da9:
	/* 0xda9: mov    r13d,0xfae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4014ULL);
x86_l_daf:
	/* 0xdaf: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_db1:
	/* 0xdb1: jmp    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JMP(0xdb1, 0x111, x86_l_111);
x86_l_db6:
	/* 0xdb6: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_db9:
	/* 0xdb9: mov    DWORD PTR [rsp+0x40],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907040ULL);
x86_l_dc1:
	/* 0xdc1: movbe  DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68ULL);
x86_l_dc7:
	/* 0xdc7: movbe  QWORD PTR [rsp+0x48],rbx */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_dce:
	/* 0xdce: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_dd5:
	/* 0xdd5: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_dda:
	/* 0xdda: call   ddf <perf_unwind_hotspot+0xddf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ddf:
	/* 0xddf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_de2:
	/* 0xde2: je     32c3 <perf_unwind_hotspot+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xde2, 0x32c3, x86_l_32c3);
x86_l_de8:
	/* 0xde8: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_dec:
	/* 0xdec: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_def:
	/* 0xdef: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_df9:
	/* 0xdf9: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_dfc:
	/* 0xdfc: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_e03:
	/* 0xe03: shr    rbp,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_e07:
	/* 0xe07: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e0a:
	/* 0xe0a: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_e11:
	/* 0xe11: sub    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_e14:
	/* 0xe14: mov    QWORD PTR [r14+0xf18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_e1b:
	/* 0xe1b: cmp    rbp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_e1f:
	/* 0xe1f: jne    e97 <perf_unwind_hotspot+0xe97> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe1f, 0xe97, x86_l_e97);
x86_l_e21:
	/* 0xe21: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e26:
	/* 0xe26: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_e2d:
	/* 0xe2d: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_e32:
	/* 0xe32: call   e37 <perf_unwind_hotspot+0xe37> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e37:
	/* 0xe37: mov    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_e3c:
	/* 0xe3c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e3f:
	/* 0xe3f: je     e97 <perf_unwind_hotspot+0xe97> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe3f, 0xe97, x86_l_e97);
x86_l_e41:
	/* 0xe41: mov    r13,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e44:
	/* 0xe44: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e47:
	/* 0xe47: ja     e4f <perf_unwind_hotspot+0xe4f> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe47, 0xe4f, x86_l_e4f);
x86_l_e49:
	/* 0xe49: cmp    QWORD PTR [r13+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e4d:
	/* 0xe4d: jae    e5b <perf_unwind_hotspot+0xe5b> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xe4d, 0xe5b, x86_l_e5b);
x86_l_e4f:
	/* 0xe4f: cmp    QWORD PTR [r13+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e53:
	/* 0xe53: ja     e97 <perf_unwind_hotspot+0xe97> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe53, 0xe97, x86_l_e97);
x86_l_e55:
	/* 0xe55: cmp    QWORD PTR [r13+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R13, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_e59:
	/* 0xe59: jb     e97 <perf_unwind_hotspot+0xe97> */
	X86_SIM_X86_JCC(X86_CC_B, 0xe59, 0xe97, x86_l_e97);
x86_l_e5b:
	/* 0xe5b: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_e62:
	/* 0xe62: mov    ecx,DWORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_e66:
	/* 0xe66: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_e69:
	/* 0xe69: jb     e97 <perf_unwind_hotspot+0xe97> */
	X86_SIM_X86_JCC(X86_CC_B, 0xe69, 0xe97, x86_l_e97);
x86_l_e6b:
	/* 0xe6b: mov    DWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_e76:
	/* 0xe76: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_e7d:
	/* 0xe7d: lea    rsi,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_e85:
	/* 0xe85: call   e8a <perf_unwind_hotspot+0xe8a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e8a:
	/* 0xe8a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e8d:
	/* 0xe8d: je     e92 <perf_unwind_hotspot+0xe92> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8d, 0xe92, x86_l_e92);
x86_l_e8f:
	/* 0xe8f: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_e92:
	/* 0xe92: movzx  ebp,WORD PTR [r13+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_e97:
	/* 0xe97: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_e9a:
	/* 0xe9a: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_e9d:
	/* 0xe9d: jne    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xe9d, 0x111, x86_l_111);
x86_l_ea3:
	/* 0xea3: mov    DWORD PTR [rsp+0x40],0x29 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906985ULL);
x86_l_eab:
	/* 0xeab: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_eb2:
	/* 0xeb2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_eb7:
	/* 0xeb7: call   ebc <perf_unwind_hotspot+0xebc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ebc:
	/* 0xebc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ebf:
	/* 0xebf: je     ec4 <perf_unwind_hotspot+0xec4> */
	X86_SIM_X86_JCC(X86_CC_E, 0xebf, 0xec4, x86_l_ec4);
x86_l_ec1:
	/* 0xec1: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_ec4:
	/* 0xec4: mov    rax,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_ecb:
	/* 0xecb: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ed0:
	/* 0xed0: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_ed7:
	/* 0xed7: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_edc:
	/* 0xedc: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_ee1:
	/* 0xee1: mov    rcx,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_ee8:
	/* 0xee8: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_eed:
	/* 0xeed: shrx   rbx,QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((3864ULL << 32) | X86_ALU_SHR));
x86_l_ef6:
	/* 0xef6: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_efd:
	/* 0xefd: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_f07:
	/* 0xf07: and    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_f0a:
	/* 0xf0a: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_f0e:
	/* 0xf0e: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_f13:
	/* 0xf13: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f18:
	/* 0xf18: call   f1d <perf_unwind_hotspot+0xf1d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f1d:
	/* 0xf1d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f20:
	/* 0xf20: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf20, 0xda, x86_l_da);
x86_l_f26:
	/* 0xf26: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_f2b:
	/* 0xf2b: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_f2e:
	/* 0xf2e: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_f31:
	/* 0xf31: jae    1184 <perf_unwind_hotspot+0x1184> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf31, 0x1184, x86_l_1184);
x86_l_f37:
	/* 0xf37: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_f39:
	/* 0xf39: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf39, 0xda, x86_l_da);
x86_l_f3f:
	/* 0xf3f: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_f44:
	/* 0xf44: shlx   rax,rbx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_RBX, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_f49:
	/* 0xf49: add    rax,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 3872ULL);
x86_l_f50:
	/* 0xf50: movzx  edx,BYTE PTR [r15+0x1b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 27ULL);
x86_l_f55:
	/* 0xf55: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_f58:
	/* 0xf58: mov    QWORD PTR [rsp+0xb0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_f60:
	/* 0xf60: je     e6 <perf_unwind_hotspot+0xe6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf60, 0xe6, x86_l_e6);
x86_l_f66:
	/* 0xf66: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_f69:
	/* 0xf69: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_f6e:
	/* 0xf6e: call   f73 <perf_unwind_hotspot+0xf73> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_f73:
	/* 0xf73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f76:
	/* 0xf76: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xf76, 0x1fc, x86_l_1fc);
x86_l_f7c:
	/* 0xf7c: movzx  ecx,WORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_f81:
	/* 0xf81: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_f86:
	/* 0xf86: cmp    rcx,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_f8d:
	/* 0xf8d: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf8d, 0x10c, x86_l_10c);
x86_l_f93:
	/* 0xf93: movzx  edx,WORD PTR [r15+0x12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18ULL);
x86_l_f98:
	/* 0xf98: cmp    rdx,0x1fc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 508ULL);
x86_l_f9f:
	/* 0xf9f: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xf9f, 0x10c, x86_l_10c);
x86_l_fa5:
	/* 0xfa5: movzx  esi,WORD PTR [r15+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_faa:
	/* 0xfaa: cmp    rsi,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_fb1:
	/* 0xfb1: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0xfb1, 0x10c, x86_l_10c);
x86_l_fb7:
	/* 0xfb7: movzx  eax,BYTE PTR [r15+0x17] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_fbc:
	/* 0xfbc: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_fc0:
	/* 0xfc0: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_fc8:
	/* 0xfc8: movzx  eax,BYTE PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 24ULL);
x86_l_fcd:
	/* 0xfcd: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_fd1:
	/* 0xfd1: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_fd9:
	/* 0xfd9: movzx  eax,BYTE PTR [r15+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 26ULL);
x86_l_fde:
	/* 0xfde: mov    eax,DWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_fe2:
	/* 0xfe2: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_fe5:
	/* 0xfe5: mov    DWORD PTR [rsp+0xd8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_fec:
	/* 0xfec: movzx  eax,BYTE PTR [r15+0x19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 25ULL);
x86_l_ff1:
	/* 0xff1: movzx  eax,WORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_16), 0ULL);
x86_l_ff6:
	/* 0xff6: mov    WORD PTR [rsp+0xe0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_ffe:
	/* 0xffe: mov    eax,DWORD PTR [r12+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_1002:
	/* 0x1002: mov    DWORD PTR [rsp+0xdc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_1009:
	/* 0x1009: mov    eax,DWORD PTR [r12+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_100d:
	/* 0x100d: mov    DWORD PTR [rsp+0xd4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_1014:
	/* 0x1014: mov    rax,QWORD PTR [r12+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_1018:
	/* 0x1018: mov    QWORD PTR [rsp+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1020:
	/* 0x1020: movzx  eax,BYTE PTR [r15+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_1025:
	/* 0x1025: mov    rdx,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_1029:
	/* 0x1029: lea    rdi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1031:
	/* 0x1031: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1036:
	/* 0x1036: call   103b <perf_unwind_hotspot+0x103b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_103b:
	/* 0x103b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_103e:
	/* 0x103e: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x103e, 0x1fc, x86_l_1fc);
x86_l_1044:
	/* 0x1044: movzx  eax,BYTE PTR [r15+0x21] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 33ULL);
x86_l_1049:
	/* 0x1049: mov    rbx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1051:
	/* 0x1051: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1059:
	/* 0x1059: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_105b:
	/* 0x105b: je     107f <perf_unwind_hotspot+0x107f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x105b, 0x107f, x86_l_107f);
x86_l_105d:
	/* 0x105d: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_105f:
	/* 0x105f: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1062:
	/* 0x1062: add    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1065:
	/* 0x1065: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_106d:
	/* 0x106d: mov    edx,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1074:
	/* 0x1074: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1077:
	/* 0x1077: mov    QWORD PTR [rsp+0xc0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_107f:
	/* 0x107f: mov    ebp,DWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1086:
	/* 0x1086: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_108b:
	/* 0x108b: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_108d:
	/* 0x108d: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1095:
	/* 0x1095: cmp    ebp,0x6974616d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1769234797ULL);
x86_l_109b:
	/* 0x109b: jg     13bc <perf_unwind_hotspot+0x13bc> */
	X86_SIM_X86_JCC(X86_CC_G, 0x109b, 0x13bc, x86_l_13bc);
x86_l_10a1:
	/* 0x10a1: cmp    ebp,0x62617476 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1650553974ULL);
x86_l_10a7:
	/* 0x10a7: je     1468 <perf_unwind_hotspot+0x1468> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10a7, 0x1468, x86_l_1468);
x86_l_10ad:
	/* 0x10ad: cmp    ebp,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_10b3:
	/* 0x10b3: jne    1480 <perf_unwind_hotspot+0x1480> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10b3, 0x1480, x86_l_1480);
x86_l_10b9:
	/* 0x10b9: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10be:
	/* 0x10be: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10c3:
	/* 0x10c3: jb     1cc9 <perf_unwind_hotspot+0x1cc9> */
	X86_SIM_X86_JCC(X86_CC_B, 0x10c3, 0x1cc9, x86_l_1cc9);
x86_l_10c9:
	/* 0x10c9: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10ce:
	/* 0x10ce: add    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4096ULL);
x86_l_10d4:
	/* 0x10d4: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10d9:
	/* 0x10d9: jae    1cc9 <perf_unwind_hotspot+0x1cc9> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10d9, 0x1cc9, x86_l_1cc9);
x86_l_10df:
	/* 0x10df: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10e4:
	/* 0x10e4: lea    rdx,[rax-0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551536ULL);
x86_l_10e8:
	/* 0x10e8: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_10ed:
	/* 0x10ed: mov    esi,0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 96ULL);
x86_l_10f2:
	/* 0x10f2: call   10f7 <perf_unwind_hotspot+0x10f7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_10f7:
	/* 0x10f7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10fa:
	/* 0x10fa: jne    1cc9 <perf_unwind_hotspot+0x1cc9> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x10fa, 0x1cc9, x86_l_1cc9);
x86_l_1100:
	/* 0x1100: cmp    DWORD PTR [r14+0x2c0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3023656976384ULL);
x86_l_1108:
	/* 0x1108: je     1c3c <perf_unwind_hotspot+0x1c3c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1108, 0x1c3c, x86_l_1c3c);
x86_l_110e:
	/* 0x110e: cmp    BYTE PTR [r15+0x1f],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986176ULL);
x86_l_1113:
	/* 0x1113: je     1c6f <perf_unwind_hotspot+0x1c6f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1113, 0x1c6f, x86_l_1c6f);
x86_l_1119:
	/* 0x1119: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_111e:
	/* 0x111e: jmp    1c74 <perf_unwind_hotspot+0x1c74> */
	X86_SIM_X86_JMP(0x111e, 0x1c74, x86_l_1c74);
x86_l_1123:
	/* 0x1123: mov    rsi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1128:
	/* 0x1128: movzx  ecx,BYTE PTR [r15+0x1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 29ULL);
x86_l_112d:
	/* 0x112d: add    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1130:
	/* 0x1130: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1132:
	/* 0x1132: cmp    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1135:
	/* 0x1135: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_113a:
	/* 0x113a: cmovae rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RCX, X86_WIDTH_64, X86_CC_AE, 0);
x86_l_113e:
	/* 0x113e: sub    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1141:
	/* 0x1141: cmp    r13,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 65535ULL);
x86_l_1148:
	/* 0x1148: mov    ecx,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_114d:
	/* 0x114d: cmovb  rcx,r13 */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R13, X86_WIDTH_64, X86_CC_B, 0);
x86_l_1151:
	/* 0x1151: mov    QWORD PTR [rsp+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1159:
	/* 0x1159: shr    rsi,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_115d:
	/* 0x115d: mov    QWORD PTR [rsp+0x28],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1162:
	/* 0x1162: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1167:
	/* 0x1167: mov    dl,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1169:
	/* 0x1169: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_116d:
	/* 0x116d: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1172:
	/* 0x1172: mov    QWORD PTR [rsp+0x30],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1177:
	/* 0x1177: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1179:
	/* 0x1179: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1179, 0x10c, x86_l_10c);
x86_l_117f:
	/* 0x117f: jmp    c2c <perf_unwind_hotspot+0xc2c> */
	X86_SIM_X86_JMP(0x117f, 0xc2c, x86_l_c2c);
x86_l_1184:
	/* 0x1184: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1187:
	/* 0x1187: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_118a:
	/* 0x118a: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_118e:
	/* 0x118e: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1193:
	/* 0x1193: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1198:
	/* 0x1198: call   119d <perf_unwind_hotspot+0x119d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_119d:
	/* 0x119d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11a0:
	/* 0x11a0: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11a0, 0xda, x86_l_da);
x86_l_11a6:
	/* 0x11a6: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_11ab:
	/* 0x11ab: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_11ae:
	/* 0x11ae: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11b1:
	/* 0x11b1: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x11b1, 0xf37, x86_l_f37);
x86_l_11b7:
	/* 0x11b7: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11ba:
	/* 0x11ba: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_11bd:
	/* 0x11bd: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_11c1:
	/* 0x11c1: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11c6:
	/* 0x11c6: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_11cb:
	/* 0x11cb: call   11d0 <perf_unwind_hotspot+0x11d0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_11d0:
	/* 0x11d0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11d3:
	/* 0x11d3: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x11d3, 0xda, x86_l_da);
x86_l_11d9:
	/* 0x11d9: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_11de:
	/* 0x11de: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_11e1:
	/* 0x11e1: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_11e4:
	/* 0x11e4: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x11e4, 0xf37, x86_l_f37);
x86_l_11ea:
	/* 0x11ea: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_11ed:
	/* 0x11ed: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_11f0:
	/* 0x11f0: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_11f4:
	/* 0x11f4: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_11f9:
	/* 0x11f9: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_11fe:
	/* 0x11fe: call   1203 <perf_unwind_hotspot+0x1203> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1203:
	/* 0x1203: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1206:
	/* 0x1206: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1206, 0xda, x86_l_da);
x86_l_120c:
	/* 0x120c: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1211:
	/* 0x1211: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1214:
	/* 0x1214: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1217:
	/* 0x1217: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1217, 0xf37, x86_l_f37);
x86_l_121d:
	/* 0x121d: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1220:
	/* 0x1220: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1223:
	/* 0x1223: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1227:
	/* 0x1227: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_122c:
	/* 0x122c: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1231:
	/* 0x1231: call   1236 <perf_unwind_hotspot+0x1236> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1236:
	/* 0x1236: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1239:
	/* 0x1239: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1239, 0xda, x86_l_da);
x86_l_123f:
	/* 0x123f: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1244:
	/* 0x1244: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1247:
	/* 0x1247: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_124a:
	/* 0x124a: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x124a, 0xf37, x86_l_f37);
x86_l_1250:
	/* 0x1250: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1253:
	/* 0x1253: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1256:
	/* 0x1256: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_125a:
	/* 0x125a: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_125f:
	/* 0x125f: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1264:
	/* 0x1264: call   1269 <perf_unwind_hotspot+0x1269> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1269:
	/* 0x1269: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_126c:
	/* 0x126c: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x126c, 0xda, x86_l_da);
x86_l_1272:
	/* 0x1272: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1277:
	/* 0x1277: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_127a:
	/* 0x127a: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_127d:
	/* 0x127d: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x127d, 0xf37, x86_l_f37);
x86_l_1283:
	/* 0x1283: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1286:
	/* 0x1286: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1289:
	/* 0x1289: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_128d:
	/* 0x128d: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1292:
	/* 0x1292: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1297:
	/* 0x1297: call   129c <perf_unwind_hotspot+0x129c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_129c:
	/* 0x129c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_129f:
	/* 0x129f: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x129f, 0xda, x86_l_da);
x86_l_12a5:
	/* 0x12a5: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_12aa:
	/* 0x12aa: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12ad:
	/* 0x12ad: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_12b0:
	/* 0x12b0: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x12b0, 0xf37, x86_l_f37);
x86_l_12b6:
	/* 0x12b6: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_12b9:
	/* 0x12b9: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_12bc:
	/* 0x12bc: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_12c0:
	/* 0x12c0: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_12c5:
	/* 0x12c5: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12ca:
	/* 0x12ca: call   12cf <perf_unwind_hotspot+0x12cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_12cf:
	/* 0x12cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d2:
	/* 0x12d2: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12d2, 0xda, x86_l_da);
x86_l_12d8:
	/* 0x12d8: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_12dd:
	/* 0x12dd: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_12e0:
	/* 0x12e0: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_12e3:
	/* 0x12e3: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x12e3, 0xf37, x86_l_f37);
x86_l_12e9:
	/* 0x12e9: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_12ec:
	/* 0x12ec: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_12ef:
	/* 0x12ef: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_12f3:
	/* 0x12f3: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_12f8:
	/* 0x12f8: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_12fd:
	/* 0x12fd: call   1302 <perf_unwind_hotspot+0x1302> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1302:
	/* 0x1302: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1305:
	/* 0x1305: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1305, 0xda, x86_l_da);
x86_l_130b:
	/* 0x130b: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1310:
	/* 0x1310: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1313:
	/* 0x1313: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1316:
	/* 0x1316: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1316, 0xf37, x86_l_f37);
x86_l_131c:
	/* 0x131c: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_131f:
	/* 0x131f: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1322:
	/* 0x1322: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1326:
	/* 0x1326: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_132b:
	/* 0x132b: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1330:
	/* 0x1330: call   1335 <perf_unwind_hotspot+0x1335> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1335:
	/* 0x1335: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1338:
	/* 0x1338: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1338, 0xda, x86_l_da);
x86_l_133e:
	/* 0x133e: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1343:
	/* 0x1343: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1346:
	/* 0x1346: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1349:
	/* 0x1349: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1349, 0xf37, x86_l_f37);
x86_l_134f:
	/* 0x134f: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1352:
	/* 0x1352: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1355:
	/* 0x1355: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1359:
	/* 0x1359: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_135e:
	/* 0x135e: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1363:
	/* 0x1363: call   1368 <perf_unwind_hotspot+0x1368> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1368:
	/* 0x1368: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_136b:
	/* 0x136b: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x136b, 0xda, x86_l_da);
x86_l_1371:
	/* 0x1371: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1376:
	/* 0x1376: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1379:
	/* 0x1379: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_137c:
	/* 0x137c: jb     f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JCC(X86_CC_B, 0x137c, 0xf37, x86_l_f37);
x86_l_1382:
	/* 0x1382: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1385:
	/* 0x1385: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1388:
	/* 0x1388: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_138b:
	/* 0x138b: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1390:
	/* 0x1390: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1395:
	/* 0x1395: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1398:
	/* 0x1398: call   139d <perf_unwind_hotspot+0x139d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_139d:
	/* 0x139d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_13a0:
	/* 0x13a0: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13a0, 0xda, x86_l_da);
x86_l_13a6:
	/* 0x13a6: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_13ab:
	/* 0x13ab: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_13ae:
	/* 0x13ae: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_13b1:
	/* 0x13b1: ja     da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_A, 0x13b1, 0xda, x86_l_da);
x86_l_13b7:
	/* 0x13b7: jmp    f37 <perf_unwind_hotspot+0xf37> */
	X86_SIM_X86_JMP(0x13b7, 0xf37, x86_l_f37);
x86_l_13bc:
	/* 0x13bc: cmp    ebp,0x6974616e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1769234798ULL);
x86_l_13c2:
	/* 0x13c2: je     13d0 <perf_unwind_hotspot+0x13d0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x13c2, 0x13d0, x86_l_13d0);
x86_l_13c4:
	/* 0x13c4: cmp    ebp,0x74656d6e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1952804206ULL);
x86_l_13ca:
	/* 0x13ca: jne    1480 <perf_unwind_hotspot+0x1480> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13ca, 0x1480, x86_l_1480);
x86_l_13d0:
	/* 0x13d0: mov    rdx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_13d8:
	/* 0x13d8: mov    esi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_13da:
	/* 0x13da: add    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_13dd:
	/* 0x13dd: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_13df:
	/* 0x13df: mov    ebp,DWORD PTR [rsp+0xdc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_13e6:
	/* 0x13e6: cmove  rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RDX, X86_WIDTH_64, X86_CC_E, 0);
x86_l_13ea:
	/* 0x13ea: cmp    QWORD PTR [rsp+0x28],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_13ef:
	/* 0x13ef: jne    143e <perf_unwind_hotspot+0x143e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13ef, 0x143e, x86_l_143e);
x86_l_13f1:
	/* 0x13f1: mov    edx,DWORD PTR [rsp+0xd4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_13f8:
	/* 0x13f8: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_13fd:
	/* 0x13fd: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1402:
	/* 0x1402: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1407:
	/* 0x1407: call   140c <perf_unwind_hotspot+0x140c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_140c:
	/* 0x140c: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1414:
	/* 0x1414: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1417:
	/* 0x1417: jne    143e <perf_unwind_hotspot+0x143e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1417, 0x143e, x86_l_143e);
x86_l_1419:
	/* 0x1419: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_141e:
	/* 0x141e: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1421:
	/* 0x1421: jb     143e <perf_unwind_hotspot+0x143e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1421, 0x143e, x86_l_143e);
x86_l_1423:
	/* 0x1423: cmp    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 192ULL);
x86_l_142b:
	/* 0x142b: jae    143e <perf_unwind_hotspot+0x143e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x142b, 0x143e, x86_l_143e);
x86_l_142d:
	/* 0x142d: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_142f:
	/* 0x142f: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1431:
	/* 0x1431: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1439:
	/* 0x1439: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_143e:
	/* 0x143e: movzx  eax,WORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 224ULL);
x86_l_1446:
	/* 0x1446: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1449:
	/* 0x1449: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_144e:
	/* 0x144e: jae    149a <perf_unwind_hotspot+0x149a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x144e, 0x149a, x86_l_149a);
x86_l_1450:
	/* 0x1450: add    rax,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_1454:
	/* 0x1454: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_1456:
	/* 0x1456: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_145a:
	/* 0x145a: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_145f:
	/* 0x145f: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1464:
	/* 0x1464: jb     146e <perf_unwind_hotspot+0x146e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1464, 0x146e, x86_l_146e);
x86_l_1466:
	/* 0x1466: jmp    14d9 <perf_unwind_hotspot+0x14d9> */
	X86_SIM_X86_JMP(0x1466, 0x14d9, x86_l_14d9);
x86_l_1468:
	/* 0x1468: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_146a:
	/* 0x146a: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_146e:
	/* 0x146e: mov    DWORD PTR [rsp+0xd8],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935944ULL);
x86_l_1479:
	/* 0x1479: mov    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_147e:
	/* 0x147e: jmp    14ee <perf_unwind_hotspot+0x14ee> */
	X86_SIM_X86_JMP(0x147e, 0x14ee, x86_l_14ee);
x86_l_1480:
	/* 0x1480: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1487:
	/* 0x1487: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_148f:
	/* 0x148f: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1494:
	/* 0x1494: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1496:
	/* 0x1496: jne    14ee <perf_unwind_hotspot+0x14ee> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1496, 0x14ee, x86_l_14ee);
x86_l_1498:
	/* 0x1498: jmp    14d9 <perf_unwind_hotspot+0x14d9> */
	X86_SIM_X86_JMP(0x1498, 0x14d9, x86_l_14d9);
x86_l_149a:
	/* 0x149a: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_14a1:
	/* 0x14a1: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14a6:
	/* 0x14a6: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_14aa:
	/* 0x14aa: add    rdx,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_14ae:
	/* 0x14ae: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_14b3:
	/* 0x14b3: cmp    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14b8:
	/* 0x14b8: jb     19b0 <perf_unwind_hotspot+0x19b0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x14b8, 0x19b0, x86_l_19b0);
x86_l_14be:
	/* 0x14be: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_14c0:
	/* 0x14c0: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_14c4:
	/* 0x14c4: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_14c9:
	/* 0x14c9: cmp    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14ce:
	/* 0x14ce: jae    19b0 <perf_unwind_hotspot+0x19b0> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x14ce, 0x19b0, x86_l_19b0);
x86_l_14d4:
	/* 0x14d4: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14d9:
	/* 0x14d9: mov    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_14e4:
	/* 0x14e4: mov    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_14e9:
	/* 0x14e9: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14ee:
	/* 0x14ee: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_14f0:
	/* 0x14f0: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_14f5:
	/* 0x14f5: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14fa:
	/* 0x14fa: lea    rdx,[rax-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_14fe:
	/* 0x14fe: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1503:
	/* 0x1503: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1508:
	/* 0x1508: call   150d <perf_unwind_hotspot+0x150d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_150d:
	/* 0x150d: cmp    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_1515:
	/* 0x1515: jb     1521 <perf_unwind_hotspot+0x1521> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1515, 0x1521, x86_l_1521);
x86_l_1517:
	/* 0x1517: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_151c:
	/* 0x151c: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1521:
	/* 0x1521: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1526:
	/* 0x1526: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_152b:
	/* 0x152b: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1532:
	/* 0x1532: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_1536:
	/* 0x1536: ja     7d6 <perf_unwind_hotspot+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1536, 0x7d6, x86_l_7d6);
x86_l_153c:
	/* 0x153c: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_1544:
	/* 0x1544: movzx  edx,BYTE PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_1549:
	/* 0x1549: shl    rdx,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 60ULL);
x86_l_154d:
	/* 0x154d: mov    rdi,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1555:
	/* 0x1555: shl    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_1559:
	/* 0x1559: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_155b:
	/* 0x155b: or     rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_155e:
	/* 0x155e: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1561:
	/* 0x1561: mov    DWORD PTR [r14+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_1568:
	/* 0x1568: or     rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_156b:
	/* 0x156b: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_156f:
	/* 0x156f: mov    QWORD PTR [r14+rax*8+0x2d0],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_1577:
	/* 0x1577: mov    QWORD PTR [r14+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_157f:
	/* 0x157f: mov    BYTE PTR [r14+rax*8+0x2e0],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929861ULL);
x86_l_1588:
	/* 0x1588: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_1590:
	/* 0x1590: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_159c:
	/* 0x159c: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_15a7:
	/* 0x15a7: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_15ac:
	/* 0x15ac: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_15b3:
	/* 0x15b3: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15b8:
	/* 0x15b8: mov    QWORD PTR [r14+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_15bf:
	/* 0x15bf: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15c4:
	/* 0x15c4: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_15cb:
	/* 0x15cb: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_15d3:
	/* 0x15d3: mov    DWORD PTR [rsp+0x40],0x2a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906986ULL);
x86_l_15db:
	/* 0x15db: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_15e2:
	/* 0x15e2: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_15e7:
	/* 0x15e7: call   15ec <perf_unwind_hotspot+0x15ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_15ec:
	/* 0x15ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_15ef:
	/* 0x15ef: je     15f4 <perf_unwind_hotspot+0x15f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15ef, 0x15f4, x86_l_15f4);
x86_l_15f1:
	/* 0x15f1: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_15f4:
	/* 0x15f4: mov    rbx,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_15fb:
	/* 0x15fb: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_15fe:
	/* 0x15fe: je     32ab <perf_unwind_hotspot+0x32ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15fe, 0x32ab, x86_l_32ab);
x86_l_1604:
	/* 0x1604: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_160e:
	/* 0x160e: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1611:
	/* 0x1611: ja     d7d <perf_unwind_hotspot+0xd7d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1611, 0xd7d, x86_l_d7d);
x86_l_1617:
	/* 0x1617: cmp    rbx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_161e:
	/* 0x161e: jb     d9e <perf_unwind_hotspot+0xd9e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x161e, 0xd9e, x86_l_d9e);
x86_l_1624:
	/* 0x1624: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1627:
	/* 0x1627: mov    DWORD PTR [rsp+0x40],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907040ULL);
x86_l_162f:
	/* 0x162f: movbe  DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68ULL);
x86_l_1635:
	/* 0x1635: movbe  QWORD PTR [rsp+0x48],rbx */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_163c:
	/* 0x163c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1643:
	/* 0x1643: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1648:
	/* 0x1648: call   164d <perf_unwind_hotspot+0x164d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_164d:
	/* 0x164d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1650:
	/* 0x1650: je     32c3 <perf_unwind_hotspot+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1650, 0x32c3, x86_l_32c3);
x86_l_1656:
	/* 0x1656: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_165a:
	/* 0x165a: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_165d:
	/* 0x165d: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_1667:
	/* 0x1667: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_166a:
	/* 0x166a: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_1671:
	/* 0x1671: shr    rbp,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_1675:
	/* 0x1675: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1678:
	/* 0x1678: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_167f:
	/* 0x167f: sub    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1682:
	/* 0x1682: mov    QWORD PTR [r14+0xf18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1689:
	/* 0x1689: cmp    rbp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_168d:
	/* 0x168d: jne    1727 <perf_unwind_hotspot+0x1727> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x168d, 0x1727, x86_l_1727);
x86_l_1693:
	/* 0x1693: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1698:
	/* 0x1698: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_169f:
	/* 0x169f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_16a4:
	/* 0x16a4: call   16a9 <perf_unwind_hotspot+0x16a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16a9:
	/* 0x16a9: mov    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_16ae:
	/* 0x16ae: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16b3:
	/* 0x16b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16b6:
	/* 0x16b6: je     1727 <perf_unwind_hotspot+0x1727> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16b6, 0x1727, x86_l_1727);
x86_l_16b8:
	/* 0x16b8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16bd:
	/* 0x16bd: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16c0:
	/* 0x16c0: ja     16cd <perf_unwind_hotspot+0x16cd> */
	X86_SIM_X86_JCC(X86_CC_A, 0x16c0, 0x16cd, x86_l_16cd);
x86_l_16c2:
	/* 0x16c2: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16c7:
	/* 0x16c7: cmp    QWORD PTR [rax+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16cb:
	/* 0x16cb: jae    16e3 <perf_unwind_hotspot+0x16e3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x16cb, 0x16e3, x86_l_16e3);
x86_l_16cd:
	/* 0x16cd: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16d2:
	/* 0x16d2: cmp    QWORD PTR [rax+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16d6:
	/* 0x16d6: ja     1727 <perf_unwind_hotspot+0x1727> */
	X86_SIM_X86_JCC(X86_CC_A, 0x16d6, 0x1727, x86_l_1727);
x86_l_16d8:
	/* 0x16d8: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16dd:
	/* 0x16dd: cmp    QWORD PTR [rax+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_16e1:
	/* 0x16e1: jb     1727 <perf_unwind_hotspot+0x1727> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16e1, 0x1727, x86_l_1727);
x86_l_16e3:
	/* 0x16e3: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_16ea:
	/* 0x16ea: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16ef:
	/* 0x16ef: mov    ecx,DWORD PTR [rcx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_16f2:
	/* 0x16f2: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_16f5:
	/* 0x16f5: jb     1727 <perf_unwind_hotspot+0x1727> */
	X86_SIM_X86_JCC(X86_CC_B, 0x16f5, 0x1727, x86_l_1727);
x86_l_16f7:
	/* 0x16f7: mov    DWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_1702:
	/* 0x1702: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1709:
	/* 0x1709: lea    rsi,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_1711:
	/* 0x1711: call   1716 <perf_unwind_hotspot+0x1716> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1716:
	/* 0x1716: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1719:
	/* 0x1719: je     171e <perf_unwind_hotspot+0x171e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1719, 0x171e, x86_l_171e);
x86_l_171b:
	/* 0x171b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_171e:
	/* 0x171e: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1723:
	/* 0x1723: movzx  ebp,WORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_1727:
	/* 0x1727: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_172a:
	/* 0x172a: jne    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x172a, 0x111, x86_l_111);
x86_l_1730:
	/* 0x1730: mov    DWORD PTR [rsp+0x40],0x29 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906985ULL);
x86_l_1738:
	/* 0x1738: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_173f:
	/* 0x173f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1744:
	/* 0x1744: call   1749 <perf_unwind_hotspot+0x1749> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1749:
	/* 0x1749: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_174c:
	/* 0x174c: je     1751 <perf_unwind_hotspot+0x1751> */
	X86_SIM_X86_JCC(X86_CC_E, 0x174c, 0x1751, x86_l_1751);
x86_l_174e:
	/* 0x174e: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1751:
	/* 0x1751: mov    rax,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1758:
	/* 0x1758: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_175d:
	/* 0x175d: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1764:
	/* 0x1764: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1769:
	/* 0x1769: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_176e:
	/* 0x176e: mov    rcx,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1775:
	/* 0x1775: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_177a:
	/* 0x177a: shrx   rbx,QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((3864ULL << 32) | X86_ALU_SHR));
x86_l_1783:
	/* 0x1783: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_178a:
	/* 0x178a: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_1794:
	/* 0x1794: and    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1797:
	/* 0x1797: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_179b:
	/* 0x179b: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_17a0:
	/* 0x17a0: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_17a5:
	/* 0x17a5: call   17aa <perf_unwind_hotspot+0x17aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_17aa:
	/* 0x17aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17ad:
	/* 0x17ad: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17ad, 0xda, x86_l_da);
x86_l_17b3:
	/* 0x17b3: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_17b8:
	/* 0x17b8: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17bb:
	/* 0x17bb: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_17be:
	/* 0x17be: jae    1d90 <perf_unwind_hotspot+0x1d90> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x17be, 0x1d90, x86_l_1d90);
x86_l_17c4:
	/* 0x17c4: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_17c6:
	/* 0x17c6: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x17c6, 0xda, x86_l_da);
x86_l_17cc:
	/* 0x17cc: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_17d1:
	/* 0x17d1: shlx   rax,rbx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_RBX, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_17d6:
	/* 0x17d6: add    rax,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 3872ULL);
x86_l_17dd:
	/* 0x17dd: movzx  edx,BYTE PTR [r15+0x1b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 27ULL);
x86_l_17e2:
	/* 0x17e2: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_17e5:
	/* 0x17e5: mov    QWORD PTR [rsp+0xb0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_17ed:
	/* 0x17ed: je     e6 <perf_unwind_hotspot+0xe6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17ed, 0xe6, x86_l_e6);
x86_l_17f3:
	/* 0x17f3: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_17f6:
	/* 0x17f6: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_17fb:
	/* 0x17fb: call   1800 <perf_unwind_hotspot+0x1800> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1800:
	/* 0x1800: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1803:
	/* 0x1803: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1803, 0x1fc, x86_l_1fc);
x86_l_1809:
	/* 0x1809: movzx  ecx,WORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_180e:
	/* 0x180e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1813:
	/* 0x1813: cmp    rcx,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_181a:
	/* 0x181a: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x181a, 0x10c, x86_l_10c);
x86_l_1820:
	/* 0x1820: movzx  edx,WORD PTR [r15+0x12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18ULL);
x86_l_1825:
	/* 0x1825: cmp    rdx,0x1fc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 508ULL);
x86_l_182c:
	/* 0x182c: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x182c, 0x10c, x86_l_10c);
x86_l_1832:
	/* 0x1832: movzx  esi,WORD PTR [r15+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_1837:
	/* 0x1837: cmp    rsi,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_183e:
	/* 0x183e: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x183e, 0x10c, x86_l_10c);
x86_l_1844:
	/* 0x1844: movzx  eax,BYTE PTR [r15+0x17] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_1849:
	/* 0x1849: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_184d:
	/* 0x184d: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1855:
	/* 0x1855: movzx  eax,BYTE PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 24ULL);
x86_l_185a:
	/* 0x185a: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_185e:
	/* 0x185e: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1866:
	/* 0x1866: movzx  eax,BYTE PTR [r15+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 26ULL);
x86_l_186b:
	/* 0x186b: mov    eax,DWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_186f:
	/* 0x186f: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1872:
	/* 0x1872: mov    DWORD PTR [rsp+0xd8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1879:
	/* 0x1879: movzx  eax,BYTE PTR [r15+0x19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 25ULL);
x86_l_187e:
	/* 0x187e: movzx  eax,WORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_16), 0ULL);
x86_l_1883:
	/* 0x1883: mov    WORD PTR [rsp+0xe0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_188b:
	/* 0x188b: mov    eax,DWORD PTR [r12+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_188f:
	/* 0x188f: mov    DWORD PTR [rsp+0xdc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_1896:
	/* 0x1896: mov    eax,DWORD PTR [r12+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_189a:
	/* 0x189a: mov    DWORD PTR [rsp+0xd4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_18a1:
	/* 0x18a1: mov    rax,QWORD PTR [r12+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_18a5:
	/* 0x18a5: mov    QWORD PTR [rsp+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_18ad:
	/* 0x18ad: movzx  eax,BYTE PTR [r15+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_18b2:
	/* 0x18b2: mov    rdx,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_18b6:
	/* 0x18b6: lea    rdi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_18be:
	/* 0x18be: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_18c3:
	/* 0x18c3: call   18c8 <perf_unwind_hotspot+0x18c8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_18c8:
	/* 0x18c8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18cb:
	/* 0x18cb: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x18cb, 0x1fc, x86_l_1fc);
x86_l_18d1:
	/* 0x18d1: movzx  eax,BYTE PTR [r15+0x21] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 33ULL);
x86_l_18d6:
	/* 0x18d6: mov    rbx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_18de:
	/* 0x18de: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_18e6:
	/* 0x18e6: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_18e8:
	/* 0x18e8: je     190c <perf_unwind_hotspot+0x190c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18e8, 0x190c, x86_l_190c);
x86_l_18ea:
	/* 0x18ea: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_18ec:
	/* 0x18ec: mov    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_18ef:
	/* 0x18ef: add    rcx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_18f2:
	/* 0x18f2: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_18fa:
	/* 0x18fa: mov    edx,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_1901:
	/* 0x1901: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1904:
	/* 0x1904: mov    QWORD PTR [rsp+0xc0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_190c:
	/* 0x190c: mov    ebp,DWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1913:
	/* 0x1913: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1918:
	/* 0x1918: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_191a:
	/* 0x191a: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1922:
	/* 0x1922: cmp    ebp,0x6974616d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1769234797ULL);
x86_l_1928:
	/* 0x1928: jg     1fc8 <perf_unwind_hotspot+0x1fc8> */
	X86_SIM_X86_JCC(X86_CC_G, 0x1928, 0x1fc8, x86_l_1fc8);
x86_l_192e:
	/* 0x192e: cmp    ebp,0x62617476 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1650553974ULL);
x86_l_1934:
	/* 0x1934: je     2074 <perf_unwind_hotspot+0x2074> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1934, 0x2074, x86_l_2074);
x86_l_193a:
	/* 0x193a: cmp    ebp,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_1940:
	/* 0x1940: jne    208c <perf_unwind_hotspot+0x208c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1940, 0x208c, x86_l_208c);
x86_l_1946:
	/* 0x1946: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_194b:
	/* 0x194b: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1950:
	/* 0x1950: jb     28e3 <perf_unwind_hotspot+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1950, 0x28e3, x86_l_28e3);
x86_l_1956:
	/* 0x1956: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_195b:
	/* 0x195b: add    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4096ULL);
x86_l_1961:
	/* 0x1961: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1966:
	/* 0x1966: jae    28e3 <perf_unwind_hotspot+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1966, 0x28e3, x86_l_28e3);
x86_l_196c:
	/* 0x196c: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1971:
	/* 0x1971: lea    rdx,[rax-0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551536ULL);
x86_l_1975:
	/* 0x1975: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_197a:
	/* 0x197a: mov    esi,0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 96ULL);
x86_l_197f:
	/* 0x197f: call   1984 <perf_unwind_hotspot+0x1984> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1984:
	/* 0x1984: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1987:
	/* 0x1987: jne    28e3 <perf_unwind_hotspot+0x28e3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1987, 0x28e3, x86_l_28e3);
x86_l_198d:
	/* 0x198d: cmp    DWORD PTR [r14+0x2c0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3023656976384ULL);
x86_l_1995:
	/* 0x1995: je     2856 <perf_unwind_hotspot+0x2856> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1995, 0x2856, x86_l_2856);
x86_l_199b:
	/* 0x199b: cmp    BYTE PTR [r15+0x1f],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986176ULL);
x86_l_19a0:
	/* 0x19a0: je     2889 <perf_unwind_hotspot+0x2889> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a0, 0x2889, x86_l_2889);
x86_l_19a6:
	/* 0x19a6: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_19ab:
	/* 0x19ab: jmp    288e <perf_unwind_hotspot+0x288e> */
	X86_SIM_X86_JMP(0x19ab, 0x288e, x86_l_288e);
x86_l_19b0:
	/* 0x19b0: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b5:
	/* 0x19b5: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_19b9:
	/* 0x19b9: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_19be:
	/* 0x19be: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_19c2:
	/* 0x19c2: add    rdx,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_19c6:
	/* 0x19c6: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_19cb:
	/* 0x19cb: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_19d0:
	/* 0x19d0: call   19d5 <perf_unwind_hotspot+0x19d5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_19d5:
	/* 0x19d5: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19d8:
	/* 0x19d8: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_19e0:
	/* 0x19e0: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_19e6:
	/* 0x19e6: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_19eb:
	/* 0x19eb: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_19f2:
	/* 0x19f2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_19f9:
	/* 0x19f9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19fe:
	/* 0x19fe: call   1a03 <perf_unwind_hotspot+0x1a03> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a03:
	/* 0x1a03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a06:
	/* 0x1a06: je     1a39 <perf_unwind_hotspot+0x1a39> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a06, 0x1a39, x86_l_1a39);
x86_l_1a08:
	/* 0x1a08: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a0c:
	/* 0x1a0c: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1a16:
	/* 0x1a16: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1a19:
	/* 0x1a19: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1a23:
	/* 0x1a23: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a26:
	/* 0x1a26: jne    1a39 <perf_unwind_hotspot+0x1a39> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a26, 0x1a39, x86_l_1a39);
x86_l_1a28:
	/* 0x1a28: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1a2a:
	/* 0x1a2a: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_1a2f:
	/* 0x1a2f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a34:
	/* 0x1a34: jmp    1c1a <perf_unwind_hotspot+0x1c1a> */
	X86_SIM_X86_JMP(0x1a34, 0x1c1a, x86_l_1c1a);
x86_l_1a39:
	/* 0x1a39: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a3c:
	/* 0x1a3c: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_1a44:
	/* 0x1a44: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1a4a:
	/* 0x1a4a: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1a4f:
	/* 0x1a4f: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1a56:
	/* 0x1a56: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1a5d:
	/* 0x1a5d: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a62:
	/* 0x1a62: call   1a67 <perf_unwind_hotspot+0x1a67> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a67:
	/* 0x1a67: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a6a:
	/* 0x1a6a: je     1a9a <perf_unwind_hotspot+0x1a9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a6a, 0x1a9a, x86_l_1a9a);
x86_l_1a6c:
	/* 0x1a6c: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a70:
	/* 0x1a70: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1a7a:
	/* 0x1a7a: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1a7d:
	/* 0x1a7d: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1a87:
	/* 0x1a87: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1a8a:
	/* 0x1a8a: jne    1a9a <perf_unwind_hotspot+0x1a9a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a8a, 0x1a9a, x86_l_1a9a);
x86_l_1a8c:
	/* 0x1a8c: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a91:
	/* 0x1a91: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1a95:
	/* 0x1a95: jmp    1c13 <perf_unwind_hotspot+0x1c13> */
	X86_SIM_X86_JMP(0x1a95, 0x1c13, x86_l_1c13);
x86_l_1a9a:
	/* 0x1a9a: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a9d:
	/* 0x1a9d: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_1aa5:
	/* 0x1aa5: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1aab:
	/* 0x1aab: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ab0:
	/* 0x1ab0: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1ab7:
	/* 0x1ab7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1abe:
	/* 0x1abe: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ac3:
	/* 0x1ac3: call   1ac8 <perf_unwind_hotspot+0x1ac8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ac8:
	/* 0x1ac8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1acb:
	/* 0x1acb: je     1afb <perf_unwind_hotspot+0x1afb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1acb, 0x1afb, x86_l_1afb);
x86_l_1acd:
	/* 0x1acd: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ad1:
	/* 0x1ad1: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1adb:
	/* 0x1adb: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1ade:
	/* 0x1ade: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1ae8:
	/* 0x1ae8: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1aeb:
	/* 0x1aeb: jne    1afb <perf_unwind_hotspot+0x1afb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1aeb, 0x1afb, x86_l_1afb);
x86_l_1aed:
	/* 0x1aed: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1af2:
	/* 0x1af2: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1af6:
	/* 0x1af6: jmp    1c13 <perf_unwind_hotspot+0x1c13> */
	X86_SIM_X86_JMP(0x1af6, 0x1c13, x86_l_1c13);
x86_l_1afb:
	/* 0x1afb: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1afe:
	/* 0x1afe: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_1b06:
	/* 0x1b06: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1b0c:
	/* 0x1b0c: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1b11:
	/* 0x1b11: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1b18:
	/* 0x1b18: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1b1f:
	/* 0x1b1f: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b24:
	/* 0x1b24: call   1b29 <perf_unwind_hotspot+0x1b29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1b29:
	/* 0x1b29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b2c:
	/* 0x1b2c: je     1b5c <perf_unwind_hotspot+0x1b5c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b2c, 0x1b5c, x86_l_1b5c);
x86_l_1b2e:
	/* 0x1b2e: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b32:
	/* 0x1b32: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1b3c:
	/* 0x1b3c: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1b3f:
	/* 0x1b3f: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1b49:
	/* 0x1b49: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1b4c:
	/* 0x1b4c: jne    1b5c <perf_unwind_hotspot+0x1b5c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b4c, 0x1b5c, x86_l_1b5c);
x86_l_1b4e:
	/* 0x1b4e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1b53:
	/* 0x1b53: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1b57:
	/* 0x1b57: jmp    1c13 <perf_unwind_hotspot+0x1c13> */
	X86_SIM_X86_JMP(0x1b57, 0x1c13, x86_l_1c13);
x86_l_1b5c:
	/* 0x1b5c: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b5f:
	/* 0x1b5f: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_1b67:
	/* 0x1b67: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1b6d:
	/* 0x1b6d: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_1b72:
	/* 0x1b72: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1b79:
	/* 0x1b79: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1b80:
	/* 0x1b80: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b85:
	/* 0x1b85: call   1b8a <perf_unwind_hotspot+0x1b8a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1b8a:
	/* 0x1b8a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b8d:
	/* 0x1b8d: je     1bba <perf_unwind_hotspot+0x1bba> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b8d, 0x1bba, x86_l_1bba);
x86_l_1b8f:
	/* 0x1b8f: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b93:
	/* 0x1b93: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1b9d:
	/* 0x1b9d: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_1ba0:
	/* 0x1ba0: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1baa:
	/* 0x1baa: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1bad:
	/* 0x1bad: jne    1bba <perf_unwind_hotspot+0x1bba> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1bad, 0x1bba, x86_l_1bba);
x86_l_1baf:
	/* 0x1baf: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1bb4:
	/* 0x1bb4: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1bb8:
	/* 0x1bb8: jmp    1c13 <perf_unwind_hotspot+0x1c13> */
	X86_SIM_X86_JMP(0x1bb8, 0x1c13, x86_l_1c13);
x86_l_1bba:
	/* 0x1bba: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bbd:
	/* 0x1bbd: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_1bc5:
	/* 0x1bc5: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_1bcb:
	/* 0x1bcb: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1bd0:
	/* 0x1bd0: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1bd7:
	/* 0x1bd7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_1bde:
	/* 0x1bde: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1be3:
	/* 0x1be3: call   1be8 <perf_unwind_hotspot+0x1be8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1be8:
	/* 0x1be8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1beb:
	/* 0x1beb: je     1c45 <perf_unwind_hotspot+0x1c45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1beb, 0x1c45, x86_l_1c45);
x86_l_1bed:
	/* 0x1bed: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_1bf7:
	/* 0x1bf7: and    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_1bfb:
	/* 0x1bfb: movabs rax,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_1c05:
	/* 0x1c05: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c08:
	/* 0x1c08: jne    1c45 <perf_unwind_hotspot+0x1c45> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c08, 0x1c45, x86_l_1c45);
x86_l_1c0a:
	/* 0x1c0a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c0f:
	/* 0x1c0f: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1c13:
	/* 0x1c13: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c15:
	/* 0x1c15: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_1c1a:
	/* 0x1c1a: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1c1f:
	/* 0x1c1f: mov    dl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_1c21:
	/* 0x1c21: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1c25:
	/* 0x1c25: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1c2a:
	/* 0x1c2a: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c2f:
	/* 0x1c2f: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1c31:
	/* 0x1c31: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c31, 0x10c, x86_l_10c);
x86_l_1c37:
	/* 0x1c37: jmp    1d04 <perf_unwind_hotspot+0x1d04> */
	X86_SIM_X86_JMP(0x1c37, 0x1d04, x86_l_1d04);
x86_l_1c3c:
	/* 0x1c3c: mov    rax,QWORD PTR [r14+0xf00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_1c43:
	/* 0x1c43: jmp    1c74 <perf_unwind_hotspot+0x1c74> */
	X86_SIM_X86_JMP(0x1c43, 0x1c74, x86_l_1c74);
x86_l_1c45:
	/* 0x1c45: mov    DWORD PTR [rsp+0x10],0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476782ULL);
x86_l_1c4d:
	/* 0x1c4d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1c54:
	/* 0x1c54: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c59:
	/* 0x1c59: call   1c5e <perf_unwind_hotspot+0x1c5e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c5e:
	/* 0x1c5e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c61:
	/* 0x1c61: je     1c66 <perf_unwind_hotspot+0x1c66> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c61, 0x1c66, x86_l_1c66);
x86_l_1c63:
	/* 0x1c63: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1c66:
	/* 0x1c66: mov    eax,0x3ea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1002ULL);
x86_l_1c6b:
	/* 0x1c6b: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1c6d:
	/* 0x1c6d: jmp    1c1f <perf_unwind_hotspot+0x1c1f> */
	X86_SIM_X86_JMP(0x1c6d, 0x1c1f, x86_l_1c1f);
x86_l_1c6f:
	/* 0x1c6f: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1c74:
	/* 0x1c74: mov    QWORD PTR [rsp+0xf8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1c7c:
	/* 0x1c7c: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1c81:
	/* 0x1c81: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1c89:
	/* 0x1c89: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c8e:
	/* 0x1c8e: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_1c96:
	/* 0x1c96: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1c9b:
	/* 0x1c9b: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1ca3:
	/* 0x1ca3: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ca8:
	/* 0x1ca8: movzx  edx,BYTE PTR [r15+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_1cad:
	/* 0x1cad: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1cb2:
	/* 0x1cb2: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1cb5:
	/* 0x1cb5: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cba:
	/* 0x1cba: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1cbf:
	/* 0x1cbf: call   1cc4 <perf_unwind_hotspot+0x1cc4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1cc4:
	/* 0x1cc4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cc7:
	/* 0x1cc7: je     1d31 <perf_unwind_hotspot+0x1d31> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cc7, 0x1d31, x86_l_1d31);
x86_l_1cc9:
	/* 0x1cc9: mov    DWORD PTR [rsp+0xec],0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281901ULL);
x86_l_1cd4:
	/* 0x1cd4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1cdb:
	/* 0x1cdb: lea    rsi,[rsp+0xec] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236ULL);
x86_l_1ce3:
	/* 0x1ce3: call   1ce8 <perf_unwind_hotspot+0x1ce8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ce8:
	/* 0x1ce8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ceb:
	/* 0x1ceb: je     1cf0 <perf_unwind_hotspot+0x1cf0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ceb, 0x1cf0, x86_l_1cf0);
x86_l_1ced:
	/* 0x1ced: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1cf0:
	/* 0x1cf0: mov    eax,0x3e9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1001ULL);
x86_l_1cf5:
	/* 0x1cf5: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1cf7:
	/* 0x1cf7: mov    ebp,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_1cfc:
	/* 0x1cfc: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1cfe:
	/* 0x1cfe: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1cfe, 0x10c, x86_l_10c);
x86_l_1d04:
	/* 0x1d04: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1d06:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10cULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x146eULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x14d4ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1d1bULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1d25ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x14f5ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x152bULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1d14:
	/* 0x1d14: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1d19:
	/* 0x1d19: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10cULL: goto x86_l_10c;
			case 0x146eULL: goto x86_l_146e;
			case 0x14d4ULL: goto x86_l_14d4;
			case 0x14f5ULL: goto x86_l_14f5;
			case 0x152bULL: goto x86_l_152b;
			case 0x1d1bULL: goto x86_l_1d1b;
			case 0x1d25ULL: goto x86_l_1d25;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d1b:
	/* 0x1d1b: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d20:
	/* 0x1d20: jmp    14d9 <perf_unwind_hotspot+0x14d9> */
	X86_SIM_X86_JMP(0x1d20, 0x14d9, x86_l_14d9);
x86_l_1d25:
	/* 0x1d25: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_1d2c:
	/* 0x1d2c: jmp    14ee <perf_unwind_hotspot+0x14ee> */
	X86_SIM_X86_JMP(0x1d2c, 0x14ee, x86_l_14ee);
x86_l_1d31:
	/* 0x1d31: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d36:
	/* 0x1d36: movzx  ecx,BYTE PTR [r15+0x1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 29ULL);
x86_l_1d3b:
	/* 0x1d3b: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1d3e:
	/* 0x1d3e: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1d40:
	/* 0x1d40: mov    rsi,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1d48:
	/* 0x1d48: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_1d4b:
	/* 0x1d4b: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_1d50:
	/* 0x1d50: cmovae rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RCX, X86_WIDTH_64, X86_CC_AE, 0);
x86_l_1d54:
	/* 0x1d54: sub    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1d57:
	/* 0x1d57: cmp    rsi,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 65535ULL);
x86_l_1d5e:
	/* 0x1d5e: mov    ecx,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_1d63:
	/* 0x1d63: cmovb  rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_1d67:
	/* 0x1d67: mov    QWORD PTR [rsp+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1d6f:
	/* 0x1d6f: shr    rbp,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_1d73:
	/* 0x1d73: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_1d78:
	/* 0x1d78: mov    dl,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1d7a:
	/* 0x1d7a: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d7e:
	/* 0x1d7e: mov    rbx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1d83:
	/* 0x1d83: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d85:
	/* 0x1d85: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d85, 0x10c, x86_l_10c);
x86_l_1d8b:
	/* 0x1d8b: jmp    1d04 <perf_unwind_hotspot+0x1d04> */
	X86_SIM_X86_JMP(0x1d8b, 0x1d04, x86_l_1d04);
x86_l_1d90:
	/* 0x1d90: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1d93:
	/* 0x1d93: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1d96:
	/* 0x1d96: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1d9a:
	/* 0x1d9a: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1d9f:
	/* 0x1d9f: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1da4:
	/* 0x1da4: call   1da9 <perf_unwind_hotspot+0x1da9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1da9:
	/* 0x1da9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1dac:
	/* 0x1dac: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1dac, 0xda, x86_l_da);
x86_l_1db2:
	/* 0x1db2: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1db7:
	/* 0x1db7: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1dba:
	/* 0x1dba: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1dbd:
	/* 0x1dbd: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dbd, 0x17c4, x86_l_17c4);
x86_l_1dc3:
	/* 0x1dc3: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1dc6:
	/* 0x1dc6: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1dc9:
	/* 0x1dc9: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1dcd:
	/* 0x1dcd: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1dd2:
	/* 0x1dd2: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1dd7:
	/* 0x1dd7: call   1ddc <perf_unwind_hotspot+0x1ddc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1ddc:
	/* 0x1ddc: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ddf:
	/* 0x1ddf: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ddf, 0xda, x86_l_da);
x86_l_1de5:
	/* 0x1de5: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1dea:
	/* 0x1dea: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ded:
	/* 0x1ded: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1df0:
	/* 0x1df0: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1df0, 0x17c4, x86_l_17c4);
x86_l_1df6:
	/* 0x1df6: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1df9:
	/* 0x1df9: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1dfc:
	/* 0x1dfc: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1e00:
	/* 0x1e00: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e05:
	/* 0x1e05: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1e0a:
	/* 0x1e0a: call   1e0f <perf_unwind_hotspot+0x1e0f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1e0f:
	/* 0x1e0f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e12:
	/* 0x1e12: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e12, 0xda, x86_l_da);
x86_l_1e18:
	/* 0x1e18: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1e1d:
	/* 0x1e1d: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e20:
	/* 0x1e20: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1e23:
	/* 0x1e23: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e23, 0x17c4, x86_l_17c4);
x86_l_1e29:
	/* 0x1e29: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1e2c:
	/* 0x1e2c: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1e2f:
	/* 0x1e2f: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1e33:
	/* 0x1e33: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e38:
	/* 0x1e38: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1e3d:
	/* 0x1e3d: call   1e42 <perf_unwind_hotspot+0x1e42> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1e42:
	/* 0x1e42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e45:
	/* 0x1e45: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e45, 0xda, x86_l_da);
x86_l_1e4b:
	/* 0x1e4b: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1e50:
	/* 0x1e50: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e53:
	/* 0x1e53: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1e56:
	/* 0x1e56: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e56, 0x17c4, x86_l_17c4);
x86_l_1e5c:
	/* 0x1e5c: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1e5f:
	/* 0x1e5f: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1e62:
	/* 0x1e62: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1e66:
	/* 0x1e66: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e6b:
	/* 0x1e6b: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1e70:
	/* 0x1e70: call   1e75 <perf_unwind_hotspot+0x1e75> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1e75:
	/* 0x1e75: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e78:
	/* 0x1e78: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e78, 0xda, x86_l_da);
x86_l_1e7e:
	/* 0x1e7e: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1e83:
	/* 0x1e83: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e86:
	/* 0x1e86: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1e89:
	/* 0x1e89: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1e89, 0x17c4, x86_l_17c4);
x86_l_1e8f:
	/* 0x1e8f: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1e92:
	/* 0x1e92: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1e95:
	/* 0x1e95: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1e99:
	/* 0x1e99: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1e9e:
	/* 0x1e9e: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ea3:
	/* 0x1ea3: call   1ea8 <perf_unwind_hotspot+0x1ea8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1ea8:
	/* 0x1ea8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1eab:
	/* 0x1eab: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eab, 0xda, x86_l_da);
x86_l_1eb1:
	/* 0x1eb1: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1eb6:
	/* 0x1eb6: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1eb9:
	/* 0x1eb9: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1ebc:
	/* 0x1ebc: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1ebc, 0x17c4, x86_l_17c4);
x86_l_1ec2:
	/* 0x1ec2: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1ec5:
	/* 0x1ec5: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1ec8:
	/* 0x1ec8: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1ecc:
	/* 0x1ecc: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1ed1:
	/* 0x1ed1: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1ed6:
	/* 0x1ed6: call   1edb <perf_unwind_hotspot+0x1edb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1edb:
	/* 0x1edb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1ede:
	/* 0x1ede: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ede, 0xda, x86_l_da);
x86_l_1ee4:
	/* 0x1ee4: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1ee9:
	/* 0x1ee9: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1eec:
	/* 0x1eec: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1eef:
	/* 0x1eef: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1eef, 0x17c4, x86_l_17c4);
x86_l_1ef5:
	/* 0x1ef5: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1ef8:
	/* 0x1ef8: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1efb:
	/* 0x1efb: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1eff:
	/* 0x1eff: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f04:
	/* 0x1f04: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f09:
	/* 0x1f09: call   1f0e <perf_unwind_hotspot+0x1f0e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f0e:
	/* 0x1f0e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f11:
	/* 0x1f11: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f11, 0xda, x86_l_da);
x86_l_1f17:
	/* 0x1f17: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1f1c:
	/* 0x1f1c: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f1f:
	/* 0x1f1f: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1f22:
	/* 0x1f22: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f22, 0x17c4, x86_l_17c4);
x86_l_1f28:
	/* 0x1f28: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1f2b:
	/* 0x1f2b: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1f2e:
	/* 0x1f2e: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1f32:
	/* 0x1f32: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f37:
	/* 0x1f37: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f3c:
	/* 0x1f3c: call   1f41 <perf_unwind_hotspot+0x1f41> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f41:
	/* 0x1f41: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f44:
	/* 0x1f44: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f44, 0xda, x86_l_da);
x86_l_1f4a:
	/* 0x1f4a: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1f4f:
	/* 0x1f4f: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f52:
	/* 0x1f52: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1f55:
	/* 0x1f55: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f55, 0x17c4, x86_l_17c4);
x86_l_1f5b:
	/* 0x1f5b: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1f5e:
	/* 0x1f5e: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1f61:
	/* 0x1f61: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_1f65:
	/* 0x1f65: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f6a:
	/* 0x1f6a: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1f6f:
	/* 0x1f6f: call   1f74 <perf_unwind_hotspot+0x1f74> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f74:
	/* 0x1f74: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f77:
	/* 0x1f77: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f77, 0xda, x86_l_da);
x86_l_1f7d:
	/* 0x1f7d: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1f82:
	/* 0x1f82: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1f85:
	/* 0x1f85: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_1f88:
	/* 0x1f88: jb     17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f88, 0x17c4, x86_l_17c4);
x86_l_1f8e:
	/* 0x1f8e: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_1f91:
	/* 0x1f91: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_1f94:
	/* 0x1f94: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1f97:
	/* 0x1f97: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_1f9c:
	/* 0x1f9c: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1fa1:
	/* 0x1fa1: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1fa4:
	/* 0x1fa4: call   1fa9 <perf_unwind_hotspot+0x1fa9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1fa9:
	/* 0x1fa9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1fac:
	/* 0x1fac: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fac, 0xda, x86_l_da);
x86_l_1fb2:
	/* 0x1fb2: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_1fb7:
	/* 0x1fb7: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1fba:
	/* 0x1fba: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_1fbd:
	/* 0x1fbd: ja     da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1fbd, 0xda, x86_l_da);
x86_l_1fc3:
	/* 0x1fc3: jmp    17c4 <perf_unwind_hotspot+0x17c4> */
	X86_SIM_X86_JMP(0x1fc3, 0x17c4, x86_l_17c4);
x86_l_1fc8:
	/* 0x1fc8: cmp    ebp,0x6974616e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1769234798ULL);
x86_l_1fce:
	/* 0x1fce: je     1fdc <perf_unwind_hotspot+0x1fdc> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fce, 0x1fdc, x86_l_1fdc);
x86_l_1fd0:
	/* 0x1fd0: cmp    ebp,0x74656d6e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1952804206ULL);
x86_l_1fd6:
	/* 0x1fd6: jne    208c <perf_unwind_hotspot+0x208c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fd6, 0x208c, x86_l_208c);
x86_l_1fdc:
	/* 0x1fdc: mov    rdx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_1fe4:
	/* 0x1fe4: mov    esi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_1fe6:
	/* 0x1fe6: add    rsi,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1fe9:
	/* 0x1fe9: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1feb:
	/* 0x1feb: mov    ebp,DWORD PTR [rsp+0xdc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_1ff2:
	/* 0x1ff2: cmove  rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RDX, X86_WIDTH_64, X86_CC_E, 0);
x86_l_1ff6:
	/* 0x1ff6: cmp    QWORD PTR [rsp+0x28],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1ffb:
	/* 0x1ffb: jne    204a <perf_unwind_hotspot+0x204a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1ffb, 0x204a, x86_l_204a);
x86_l_1ffd:
	/* 0x1ffd: mov    edx,DWORD PTR [rsp+0xd4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_2004:
	/* 0x2004: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2009:
	/* 0x2009: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_200e:
	/* 0x200e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2013:
	/* 0x2013: call   2018 <perf_unwind_hotspot+0x2018> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2018:
	/* 0x2018: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2020:
	/* 0x2020: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2023:
	/* 0x2023: jne    204a <perf_unwind_hotspot+0x204a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2023, 0x204a, x86_l_204a);
x86_l_2025:
	/* 0x2025: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_202a:
	/* 0x202a: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_202d:
	/* 0x202d: jb     204a <perf_unwind_hotspot+0x204a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x202d, 0x204a, x86_l_204a);
x86_l_202f:
	/* 0x202f: cmp    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 192ULL);
x86_l_2037:
	/* 0x2037: jae    204a <perf_unwind_hotspot+0x204a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2037, 0x204a, x86_l_204a);
x86_l_2039:
	/* 0x2039: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_203b:
	/* 0x203b: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_203d:
	/* 0x203d: mov    QWORD PTR [rsp+0xa8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2045:
	/* 0x2045: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_204a:
	/* 0x204a: movzx  eax,WORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 224ULL);
x86_l_2052:
	/* 0x2052: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2055:
	/* 0x2055: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_205a:
	/* 0x205a: jae    20a6 <perf_unwind_hotspot+0x20a6> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x205a, 0x20a6, x86_l_20a6);
x86_l_205c:
	/* 0x205c: add    rax,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_2060:
	/* 0x2060: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_2062:
	/* 0x2062: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2066:
	/* 0x2066: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_206b:
	/* 0x206b: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2070:
	/* 0x2070: jb     207a <perf_unwind_hotspot+0x207a> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2070, 0x207a, x86_l_207a);
x86_l_2072:
	/* 0x2072: jmp    20e5 <perf_unwind_hotspot+0x20e5> */
	X86_SIM_X86_JMP(0x2072, 0x20e5, x86_l_20e5);
x86_l_2074:
	/* 0x2074: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2076:
	/* 0x2076: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_207a:
	/* 0x207a: mov    DWORD PTR [rsp+0xd8],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935944ULL);
x86_l_2085:
	/* 0x2085: mov    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_208a:
	/* 0x208a: jmp    20fa <perf_unwind_hotspot+0x20fa> */
	X86_SIM_X86_JMP(0x208a, 0x20fa, x86_l_20fa);
x86_l_208c:
	/* 0x208c: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2093:
	/* 0x2093: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_209b:
	/* 0x209b: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20a0:
	/* 0x20a0: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_20a2:
	/* 0x20a2: jne    20fa <perf_unwind_hotspot+0x20fa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20a2, 0x20fa, x86_l_20fa);
x86_l_20a4:
	/* 0x20a4: jmp    20e5 <perf_unwind_hotspot+0x20e5> */
	X86_SIM_X86_JMP(0x20a4, 0x20e5, x86_l_20e5);
x86_l_20a6:
	/* 0x20a6: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_20ad:
	/* 0x20ad: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b2:
	/* 0x20b2: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_20b6:
	/* 0x20b6: add    rdx,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_20ba:
	/* 0x20ba: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_20bf:
	/* 0x20bf: cmp    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20c4:
	/* 0x20c4: jb     25ca <perf_unwind_hotspot+0x25ca> */
	X86_SIM_X86_JCC(X86_CC_B, 0x20c4, 0x25ca, x86_l_25ca);
x86_l_20ca:
	/* 0x20ca: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_20cc:
	/* 0x20cc: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20d0:
	/* 0x20d0: mov    rcx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_20d5:
	/* 0x20d5: cmp    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20da:
	/* 0x20da: jae    25ca <perf_unwind_hotspot+0x25ca> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x20da, 0x25ca, x86_l_25ca);
x86_l_20e0:
	/* 0x20e0: mov    rcx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_20e5:
	/* 0x20e5: mov    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_20f0:
	/* 0x20f0: mov    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_20f5:
	/* 0x20f5: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20fa:
	/* 0x20fa: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_20fc:
	/* 0x20fc: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2101:
	/* 0x2101: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2106:
	/* 0x2106: lea    rdx,[rax-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_210a:
	/* 0x210a: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_210f:
	/* 0x210f: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2114:
	/* 0x2114: call   2119 <perf_unwind_hotspot+0x2119> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2119:
	/* 0x2119: cmp    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_2121:
	/* 0x2121: jb     212d <perf_unwind_hotspot+0x212d> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2121, 0x212d, x86_l_212d);
x86_l_2123:
	/* 0x2123: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2128:
	/* 0x2128: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_212d:
	/* 0x212d: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2132:
	/* 0x2132: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2137:
	/* 0x2137: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_213e:
	/* 0x213e: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_2142:
	/* 0x2142: ja     7d6 <perf_unwind_hotspot+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2142, 0x7d6, x86_l_7d6);
x86_l_2148:
	/* 0x2148: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_2150:
	/* 0x2150: movzx  edx,BYTE PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_2155:
	/* 0x2155: shl    rdx,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 60ULL);
x86_l_2159:
	/* 0x2159: mov    rdi,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2161:
	/* 0x2161: shl    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_2165:
	/* 0x2165: mov    esi,ebp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RBP, X86_WIDTH_32, 0, 0);
x86_l_2167:
	/* 0x2167: or     rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_216a:
	/* 0x216a: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_216d:
	/* 0x216d: mov    DWORD PTR [r14+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_2174:
	/* 0x2174: or     rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_2177:
	/* 0x2177: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_217b:
	/* 0x217b: mov    QWORD PTR [r14+rax*8+0x2d0],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_2183:
	/* 0x2183: mov    QWORD PTR [r14+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_218b:
	/* 0x218b: mov    BYTE PTR [r14+rax*8+0x2e0],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929861ULL);
x86_l_2194:
	/* 0x2194: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_219c:
	/* 0x219c: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_21a8:
	/* 0x21a8: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_21b3:
	/* 0x21b3: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_21b8:
	/* 0x21b8: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_21bf:
	/* 0x21bf: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21c4:
	/* 0x21c4: mov    QWORD PTR [r14+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_21cb:
	/* 0x21cb: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21d0:
	/* 0x21d0: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_21d7:
	/* 0x21d7: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_21df:
	/* 0x21df: mov    DWORD PTR [rsp+0x40],0x2a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906986ULL);
x86_l_21e7:
	/* 0x21e7: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_21ee:
	/* 0x21ee: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_21f3:
	/* 0x21f3: call   21f8 <perf_unwind_hotspot+0x21f8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_21f8:
	/* 0x21f8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21fb:
	/* 0x21fb: je     2200 <perf_unwind_hotspot+0x2200> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21fb, 0x2200, x86_l_2200);
x86_l_21fd:
	/* 0x21fd: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2200:
	/* 0x2200: mov    rbx,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2207:
	/* 0x2207: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_220a:
	/* 0x220a: je     32ab <perf_unwind_hotspot+0x32ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x220a, 0x32ab, x86_l_32ab);
x86_l_2210:
	/* 0x2210: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_221a:
	/* 0x221a: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_221d:
	/* 0x221d: ja     d7d <perf_unwind_hotspot+0xd7d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x221d, 0xd7d, x86_l_d7d);
x86_l_2223:
	/* 0x2223: cmp    rbx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_222a:
	/* 0x222a: jb     d9e <perf_unwind_hotspot+0xd9e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x222a, 0xd9e, x86_l_d9e);
x86_l_2230:
	/* 0x2230: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2233:
	/* 0x2233: mov    DWORD PTR [rsp+0x40],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907040ULL);
x86_l_223b:
	/* 0x223b: movbe  DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68ULL);
x86_l_2241:
	/* 0x2241: movbe  QWORD PTR [rsp+0x48],rbx */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_2248:
	/* 0x2248: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_224f:
	/* 0x224f: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2254:
	/* 0x2254: call   2259 <perf_unwind_hotspot+0x2259> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2259:
	/* 0x2259: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_225c:
	/* 0x225c: je     32c3 <perf_unwind_hotspot+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x225c, 0x32c3, x86_l_32c3);
x86_l_2262:
	/* 0x2262: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2266:
	/* 0x2266: mov    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2269:
	/* 0x2269: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2273:
	/* 0x2273: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2276:
	/* 0x2276: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_227d:
	/* 0x227d: shr    rbp,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_2281:
	/* 0x2281: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2284:
	/* 0x2284: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_228b:
	/* 0x228b: sub    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_228e:
	/* 0x228e: mov    QWORD PTR [r14+0xf18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_2295:
	/* 0x2295: cmp    rbp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_2299:
	/* 0x2299: jne    2333 <perf_unwind_hotspot+0x2333> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2299, 0x2333, x86_l_2333);
x86_l_229f:
	/* 0x229f: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22a4:
	/* 0x22a4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_22ab:
	/* 0x22ab: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_22b0:
	/* 0x22b0: call   22b5 <perf_unwind_hotspot+0x22b5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_22b5:
	/* 0x22b5: mov    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_22ba:
	/* 0x22ba: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22bf:
	/* 0x22bf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_22c2:
	/* 0x22c2: je     2333 <perf_unwind_hotspot+0x2333> */
	X86_SIM_X86_JCC(X86_CC_E, 0x22c2, 0x2333, x86_l_2333);
x86_l_22c4:
	/* 0x22c4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22c9:
	/* 0x22c9: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22cc:
	/* 0x22cc: ja     22d9 <perf_unwind_hotspot+0x22d9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22cc, 0x22d9, x86_l_22d9);
x86_l_22ce:
	/* 0x22ce: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d3:
	/* 0x22d3: cmp    QWORD PTR [rax+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22d7:
	/* 0x22d7: jae    22ef <perf_unwind_hotspot+0x22ef> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x22d7, 0x22ef, x86_l_22ef);
x86_l_22d9:
	/* 0x22d9: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22de:
	/* 0x22de: cmp    QWORD PTR [rax+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_22e2:
	/* 0x22e2: ja     2333 <perf_unwind_hotspot+0x2333> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22e2, 0x2333, x86_l_2333);
x86_l_22e4:
	/* 0x22e4: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22e9:
	/* 0x22e9: cmp    QWORD PTR [rax+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22ed:
	/* 0x22ed: jb     2333 <perf_unwind_hotspot+0x2333> */
	X86_SIM_X86_JCC(X86_CC_B, 0x22ed, 0x2333, x86_l_2333);
x86_l_22ef:
	/* 0x22ef: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_22f6:
	/* 0x22f6: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_22fb:
	/* 0x22fb: mov    ecx,DWORD PTR [rcx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22fe:
	/* 0x22fe: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2301:
	/* 0x2301: jb     2333 <perf_unwind_hotspot+0x2333> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2301, 0x2333, x86_l_2333);
x86_l_2303:
	/* 0x2303: mov    DWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_230e:
	/* 0x230e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2315:
	/* 0x2315: lea    rsi,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_231d:
	/* 0x231d: call   2322 <perf_unwind_hotspot+0x2322> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2322:
	/* 0x2322: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2325:
	/* 0x2325: je     232a <perf_unwind_hotspot+0x232a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2325, 0x232a, x86_l_232a);
x86_l_2327:
	/* 0x2327: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_232a:
	/* 0x232a: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_232f:
	/* 0x232f: movzx  ebp,WORD PTR [rax+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_2333:
	/* 0x2333: cmp    ebp,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_2336:
	/* 0x2336: jne    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2336, 0x111, x86_l_111);
x86_l_233c:
	/* 0x233c: mov    DWORD PTR [rsp+0x40],0x29 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906985ULL);
x86_l_2344:
	/* 0x2344: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_234b:
	/* 0x234b: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2350:
	/* 0x2350: call   2355 <perf_unwind_hotspot+0x2355> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2355:
	/* 0x2355: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2358:
	/* 0x2358: je     235d <perf_unwind_hotspot+0x235d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2358, 0x235d, x86_l_235d);
x86_l_235a:
	/* 0x235a: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_235d:
	/* 0x235d: mov    rax,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2364:
	/* 0x2364: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2369:
	/* 0x2369: mov    rax,QWORD PTR [r14+0xed8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2370:
	/* 0x2370: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2375:
	/* 0x2375: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_237a:
	/* 0x237a: mov    rcx,QWORD PTR [r14+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2381:
	/* 0x2381: mov    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2386:
	/* 0x2386: shrx   rbx,QWORD PTR [r14+0xf18],rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_REG_AUX_SRC_SHIFT(X86_RAX)), ((3864ULL << 32) | X86_ALU_SHR));
x86_l_238f:
	/* 0x238f: mov    rbp,QWORD PTR [r14+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2396:
	/* 0x2396: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_23a0:
	/* 0x23a0: and    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_23a3:
	/* 0x23a3: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_23a7:
	/* 0x23a7: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_23ac:
	/* 0x23ac: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_23b1:
	/* 0x23b1: call   23b6 <perf_unwind_hotspot+0x23b6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_23b6:
	/* 0x23b6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23b9:
	/* 0x23b9: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23b9, 0xda, x86_l_da);
x86_l_23bf:
	/* 0x23bf: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_23c4:
	/* 0x23c4: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_23c7:
	/* 0x23c7: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_23ca:
	/* 0x23ca: jae    29aa <perf_unwind_hotspot+0x29aa> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x23ca, 0x29aa, x86_l_29aa);
x86_l_23d0:
	/* 0x23d0: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_23d2:
	/* 0x23d2: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23d2, 0xda, x86_l_da);
x86_l_23d8:
	/* 0x23d8: movzx  eax,BYTE PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_23dd:
	/* 0x23dd: shlx   rax,rbx,rax */
	X86_SIM_RUN_OP(X86_OP_SHIFTX, X86_RAX, X86_RBX, X86_WIDTH_64, X86_RAX, X86_ALU_SHL);
x86_l_23e2:
	/* 0x23e2: add    rax,QWORD PTR [r14+0xf20] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 3872ULL);
x86_l_23e9:
	/* 0x23e9: movzx  edx,BYTE PTR [r15+0x1b] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 27ULL);
x86_l_23ee:
	/* 0x23ee: add    rdx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_23f1:
	/* 0x23f1: mov    QWORD PTR [rsp+0xb0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_23f9:
	/* 0x23f9: je     e6 <perf_unwind_hotspot+0xe6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23f9, 0xe6, x86_l_e6);
x86_l_23ff:
	/* 0x23ff: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2402:
	/* 0x2402: mov    esi,0x200 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 512ULL);
x86_l_2407:
	/* 0x2407: call   240c <perf_unwind_hotspot+0x240c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_240c:
	/* 0x240c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_240f:
	/* 0x240f: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x240f, 0x1fc, x86_l_1fc);
x86_l_2415:
	/* 0x2415: movzx  ecx,WORD PTR [r15+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 16ULL);
x86_l_241a:
	/* 0x241a: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_241f:
	/* 0x241f: cmp    rcx,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_2426:
	/* 0x2426: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2426, 0x10c, x86_l_10c);
x86_l_242c:
	/* 0x242c: movzx  edx,WORD PTR [r15+0x12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 18ULL);
x86_l_2431:
	/* 0x2431: cmp    rdx,0x1fc */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 508ULL);
x86_l_2438:
	/* 0x2438: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2438, 0x10c, x86_l_10c);
x86_l_243e:
	/* 0x243e: movzx  esi,WORD PTR [r15+0x14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 20ULL);
x86_l_2443:
	/* 0x2443: cmp    rsi,0x1f8 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 504ULL);
x86_l_244a:
	/* 0x244a: ja     10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x244a, 0x10c, x86_l_10c);
x86_l_2450:
	/* 0x2450: movzx  eax,BYTE PTR [r15+0x17] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 23ULL);
x86_l_2455:
	/* 0x2455: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2459:
	/* 0x2459: mov    QWORD PTR [rsp+0xb8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2461:
	/* 0x2461: movzx  eax,BYTE PTR [r15+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 24ULL);
x86_l_2466:
	/* 0x2466: mov    rax,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_246a:
	/* 0x246a: mov    QWORD PTR [rsp+0xc0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2472:
	/* 0x2472: movzx  eax,BYTE PTR [r15+0x1a] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 26ULL);
x86_l_2477:
	/* 0x2477: mov    eax,DWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_247b:
	/* 0x247b: shl    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_247e:
	/* 0x247e: mov    DWORD PTR [rsp+0xd8],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2485:
	/* 0x2485: movzx  eax,BYTE PTR [r15+0x19] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 25ULL);
x86_l_248a:
	/* 0x248a: movzx  eax,WORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_RAX, 0, X86_WIDTH_16), 0ULL);
x86_l_248f:
	/* 0x248f: mov    WORD PTR [rsp+0xe0],ax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 224ULL);
x86_l_2497:
	/* 0x2497: mov    eax,DWORD PTR [r12+rdx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RDX, 0), 0ULL);
x86_l_249b:
	/* 0x249b: mov    DWORD PTR [rsp+0xdc],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_24a2:
	/* 0x24a2: mov    eax,DWORD PTR [r12+rsi*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_RSI, 0), 0ULL);
x86_l_24a6:
	/* 0x24a6: mov    DWORD PTR [rsp+0xd4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_24ad:
	/* 0x24ad: mov    rax,QWORD PTR [r12+rcx*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RCX, 0), 0ULL);
x86_l_24b1:
	/* 0x24b1: mov    QWORD PTR [rsp+0xc8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_24b9:
	/* 0x24b9: movzx  eax,BYTE PTR [r15+0x16] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 22ULL);
x86_l_24be:
	/* 0x24be: mov    rdx,QWORD PTR [r12+rax*1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_24c2:
	/* 0x24c2: lea    rdi,[rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_24ca:
	/* 0x24ca: mov    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_24cf:
	/* 0x24cf: call   24d4 <perf_unwind_hotspot+0x24d4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_24d4:
	/* 0x24d4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24d7:
	/* 0x24d7: jne    1fc <perf_unwind_hotspot+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x24d7, 0x1fc, x86_l_1fc);
x86_l_24dd:
	/* 0x24dd: movzx  eax,BYTE PTR [r15+0x21] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 33ULL);
x86_l_24e2:
	/* 0x24e2: mov    rcx,QWORD PTR [rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_24ea:
	/* 0x24ea: mov    QWORD PTR [rsp+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_24f2:
	/* 0x24f2: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_24fa:
	/* 0x24fa: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_24fc:
	/* 0x24fc: je     2525 <perf_unwind_hotspot+0x2525> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24fc, 0x2525, x86_l_2525);
x86_l_24fe:
	/* 0x24fe: mov    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2500:
	/* 0x2500: mov    rsi,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2508:
	/* 0x2508: add    rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_250b:
	/* 0x250b: mov    QWORD PTR [rsp+0xb8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2513:
	/* 0x2513: mov    edx,DWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_251a:
	/* 0x251a: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_251d:
	/* 0x251d: mov    QWORD PTR [rsp+0xc0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 192ULL);
x86_l_2525:
	/* 0x2525: mov    r12d,DWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_252d:
	/* 0x252d: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2532:
	/* 0x2532: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2534:
	/* 0x2534: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2539:
	/* 0x2539: cmp    r12d,0x6974616d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1769234797ULL);
x86_l_2540:
	/* 0x2540: jg     2be2 <perf_unwind_hotspot+0x2be2> */
	X86_SIM_X86_JCC(X86_CC_G, 0x2540, 0x2be2, x86_l_2be2);
x86_l_2546:
	/* 0x2546: cmp    r12d,0x62617476 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1650553974ULL);
x86_l_254d:
	/* 0x254d: je     2c9e <perf_unwind_hotspot+0x2c9e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x254d, 0x2c9e, x86_l_2c9e);
x86_l_2553:
	/* 0x2553: cmp    r12d,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_255a:
	/* 0x255a: jne    2d3c <perf_unwind_hotspot+0x2d3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x255a, 0x2d3c, x86_l_2d3c);
x86_l_2560:
	/* 0x2560: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2565:
	/* 0x2565: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_256a:
	/* 0x256a: jb     2d03 <perf_unwind_hotspot+0x2d03> */
	X86_SIM_X86_JCC(X86_CC_B, 0x256a, 0x2d03, x86_l_2d03);
x86_l_2570:
	/* 0x2570: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2575:
	/* 0x2575: add    rax,0x1000 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 4096ULL);
x86_l_257b:
	/* 0x257b: cmp    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2580:
	/* 0x2580: jae    2d03 <perf_unwind_hotspot+0x2d03> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2580, 0x2d03, x86_l_2d03);
x86_l_2586:
	/* 0x2586: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_258b:
	/* 0x258b: lea    rdx,[rax-0x50] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551536ULL);
x86_l_258f:
	/* 0x258f: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2594:
	/* 0x2594: mov    esi,0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 96ULL);
x86_l_2599:
	/* 0x2599: call   259e <perf_unwind_hotspot+0x259e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_259e:
	/* 0x259e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25a1:
	/* 0x25a1: jne    2d03 <perf_unwind_hotspot+0x2d03> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x25a1, 0x2d03, x86_l_2d03);
x86_l_25a7:
	/* 0x25a7: cmp    DWORD PTR [r14+0x2c0],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3023656976384ULL);
x86_l_25af:
	/* 0x25af: je     2ca9 <perf_unwind_hotspot+0x2ca9> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25af, 0x2ca9, x86_l_2ca9);
x86_l_25b5:
	/* 0x25b5: cmp    BYTE PTR [r15+0x1f],0x0 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 133143986176ULL);
x86_l_25ba:
	/* 0x25ba: je     2cb2 <perf_unwind_hotspot+0x2cb2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25ba, 0x2cb2, x86_l_2cb2);
x86_l_25c0:
	/* 0x25c0: mov    rbp,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_25c5:
	/* 0x25c5: jmp    2cb7 <perf_unwind_hotspot+0x2cb7> */
	X86_SIM_X86_JMP(0x25c5, 0x2cb7, x86_l_2cb7);
x86_l_25ca:
	/* 0x25ca: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25cf:
	/* 0x25cf: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_25d3:
	/* 0x25d3: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25d8:
	/* 0x25d8: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_25dc:
	/* 0x25dc: add    rdx,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_25e0:
	/* 0x25e0: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_25e5:
	/* 0x25e5: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_25ea:
	/* 0x25ea: call   25ef <perf_unwind_hotspot+0x25ef> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_25ef:
	/* 0x25ef: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25f2:
	/* 0x25f2: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_25fa:
	/* 0x25fa: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2600:
	/* 0x2600: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2605:
	/* 0x2605: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_260c:
	/* 0x260c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2613:
	/* 0x2613: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2618:
	/* 0x2618: call   261d <perf_unwind_hotspot+0x261d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_261d:
	/* 0x261d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2620:
	/* 0x2620: je     2653 <perf_unwind_hotspot+0x2653> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2620, 0x2653, x86_l_2653);
x86_l_2622:
	/* 0x2622: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2626:
	/* 0x2626: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_2630:
	/* 0x2630: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2633:
	/* 0x2633: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_263d:
	/* 0x263d: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2640:
	/* 0x2640: jne    2653 <perf_unwind_hotspot+0x2653> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2640, 0x2653, x86_l_2653);
x86_l_2642:
	/* 0x2642: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2644:
	/* 0x2644: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2649:
	/* 0x2649: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_264e:
	/* 0x264e: jmp    2834 <perf_unwind_hotspot+0x2834> */
	X86_SIM_X86_JMP(0x264e, 0x2834, x86_l_2834);
x86_l_2653:
	/* 0x2653: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2656:
	/* 0x2656: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_265e:
	/* 0x265e: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2664:
	/* 0x2664: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2669:
	/* 0x2669: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2670:
	/* 0x2670: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2677:
	/* 0x2677: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_267c:
	/* 0x267c: call   2681 <perf_unwind_hotspot+0x2681> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2681:
	/* 0x2681: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2684:
	/* 0x2684: je     26b4 <perf_unwind_hotspot+0x26b4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2684, 0x26b4, x86_l_26b4);
x86_l_2686:
	/* 0x2686: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_268a:
	/* 0x268a: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_2694:
	/* 0x2694: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2697:
	/* 0x2697: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_26a1:
	/* 0x26a1: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_26a4:
	/* 0x26a4: jne    26b4 <perf_unwind_hotspot+0x26b4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x26a4, 0x26b4, x86_l_26b4);
x86_l_26a6:
	/* 0x26a6: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_26ab:
	/* 0x26ab: add    rdx,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_26af:
	/* 0x26af: jmp    282d <perf_unwind_hotspot+0x282d> */
	X86_SIM_X86_JMP(0x26af, 0x282d, x86_l_282d);
x86_l_26b4:
	/* 0x26b4: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b7:
	/* 0x26b7: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_26bf:
	/* 0x26bf: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_26c5:
	/* 0x26c5: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_26ca:
	/* 0x26ca: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_26d1:
	/* 0x26d1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_26d8:
	/* 0x26d8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26dd:
	/* 0x26dd: call   26e2 <perf_unwind_hotspot+0x26e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26e2:
	/* 0x26e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26e5:
	/* 0x26e5: je     2715 <perf_unwind_hotspot+0x2715> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26e5, 0x2715, x86_l_2715);
x86_l_26e7:
	/* 0x26e7: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26eb:
	/* 0x26eb: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_26f5:
	/* 0x26f5: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_26f8:
	/* 0x26f8: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2702:
	/* 0x2702: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2705:
	/* 0x2705: jne    2715 <perf_unwind_hotspot+0x2715> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2705, 0x2715, x86_l_2715);
x86_l_2707:
	/* 0x2707: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_270c:
	/* 0x270c: add    rdx,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2710:
	/* 0x2710: jmp    282d <perf_unwind_hotspot+0x282d> */
	X86_SIM_X86_JMP(0x2710, 0x282d, x86_l_282d);
x86_l_2715:
	/* 0x2715: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2718:
	/* 0x2718: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2720:
	/* 0x2720: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2726:
	/* 0x2726: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_272b:
	/* 0x272b: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2732:
	/* 0x2732: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2739:
	/* 0x2739: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_273e:
	/* 0x273e: call   2743 <perf_unwind_hotspot+0x2743> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2743:
	/* 0x2743: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2746:
	/* 0x2746: je     2776 <perf_unwind_hotspot+0x2776> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2746, 0x2776, x86_l_2776);
x86_l_2748:
	/* 0x2748: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_274c:
	/* 0x274c: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_2756:
	/* 0x2756: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2759:
	/* 0x2759: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2763:
	/* 0x2763: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2766:
	/* 0x2766: jne    2776 <perf_unwind_hotspot+0x2776> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2766, 0x2776, x86_l_2776);
x86_l_2768:
	/* 0x2768: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_276d:
	/* 0x276d: add    rdx,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2771:
	/* 0x2771: jmp    282d <perf_unwind_hotspot+0x282d> */
	X86_SIM_X86_JMP(0x2771, 0x282d, x86_l_282d);
x86_l_2776:
	/* 0x2776: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2779:
	/* 0x2779: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2781:
	/* 0x2781: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2787:
	/* 0x2787: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_278c:
	/* 0x278c: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2793:
	/* 0x2793: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_279a:
	/* 0x279a: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_279f:
	/* 0x279f: call   27a4 <perf_unwind_hotspot+0x27a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27a4:
	/* 0x27a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27a7:
	/* 0x27a7: je     27d4 <perf_unwind_hotspot+0x27d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27a7, 0x27d4, x86_l_27d4);
x86_l_27a9:
	/* 0x27a9: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27ad:
	/* 0x27ad: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_27b7:
	/* 0x27b7: and    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_27ba:
	/* 0x27ba: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_27c4:
	/* 0x27c4: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_27c7:
	/* 0x27c7: jne    27d4 <perf_unwind_hotspot+0x27d4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27c7, 0x27d4, x86_l_27d4);
x86_l_27c9:
	/* 0x27c9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_27ce:
	/* 0x27ce: add    rdx,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_27d2:
	/* 0x27d2: jmp    282d <perf_unwind_hotspot+0x282d> */
	X86_SIM_X86_JMP(0x27d2, 0x282d, x86_l_282d);
x86_l_27d4:
	/* 0x27d4: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27d7:
	/* 0x27d7: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_27df:
	/* 0x27df: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_27e5:
	/* 0x27e5: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_27ea:
	/* 0x27ea: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_27f1:
	/* 0x27f1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_27f8:
	/* 0x27f8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27fd:
	/* 0x27fd: call   2802 <perf_unwind_hotspot+0x2802> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2802:
	/* 0x2802: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2805:
	/* 0x2805: je     285f <perf_unwind_hotspot+0x285f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2805, 0x285f, x86_l_285f);
x86_l_2807:
	/* 0x2807: movabs rcx,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_2811:
	/* 0x2811: and    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RCX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_2815:
	/* 0x2815: movabs rax,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_281f:
	/* 0x281f: cmp    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2822:
	/* 0x2822: jne    285f <perf_unwind_hotspot+0x285f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2822, 0x285f, x86_l_285f);
x86_l_2824:
	/* 0x2824: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2829:
	/* 0x2829: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_282d:
	/* 0x282d: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_282f:
	/* 0x282f: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2834:
	/* 0x2834: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2839:
	/* 0x2839: mov    dl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_283b:
	/* 0x283b: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_283f:
	/* 0x283f: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2844:
	/* 0x2844: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2849:
	/* 0x2849: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_284b:
	/* 0x284b: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x284b, 0x10c, x86_l_10c);
x86_l_2851:
	/* 0x2851: jmp    291e <perf_unwind_hotspot+0x291e> */
	X86_SIM_X86_JMP(0x2851, 0x291e, x86_l_291e);
x86_l_2856:
	/* 0x2856: mov    rax,QWORD PTR [r14+0xf00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_285d:
	/* 0x285d: jmp    288e <perf_unwind_hotspot+0x288e> */
	X86_SIM_X86_JMP(0x285d, 0x288e, x86_l_288e);
x86_l_285f:
	/* 0x285f: mov    DWORD PTR [rsp+0x10],0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476782ULL);
x86_l_2867:
	/* 0x2867: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_286e:
	/* 0x286e: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2873:
	/* 0x2873: call   2878 <perf_unwind_hotspot+0x2878> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2878:
	/* 0x2878: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_287b:
	/* 0x287b: je     2880 <perf_unwind_hotspot+0x2880> */
	X86_SIM_X86_JCC(X86_CC_E, 0x287b, 0x2880, x86_l_2880);
x86_l_287d:
	/* 0x287d: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2880:
	/* 0x2880: mov    eax,0x3ea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1002ULL);
x86_l_2885:
	/* 0x2885: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2887:
	/* 0x2887: jmp    2839 <perf_unwind_hotspot+0x2839> */
	X86_SIM_X86_JMP(0x2887, 0x2839, x86_l_2839);
x86_l_2889:
	/* 0x2889: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_288e:
	/* 0x288e: mov    QWORD PTR [rsp+0xf8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2896:
	/* 0x2896: mov    rcx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_289b:
	/* 0x289b: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_28a3:
	/* 0x28a3: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28a8:
	/* 0x28a8: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_28b0:
	/* 0x28b0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28b5:
	/* 0x28b5: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_28bd:
	/* 0x28bd: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_28c2:
	/* 0x28c2: movzx  edx,BYTE PTR [r15+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_28c7:
	/* 0x28c7: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_28cc:
	/* 0x28cc: add    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_28cf:
	/* 0x28cf: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28d4:
	/* 0x28d4: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_28d9:
	/* 0x28d9: call   28de <perf_unwind_hotspot+0x28de> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_28de:
	/* 0x28de: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28e1:
	/* 0x28e1: je     294b <perf_unwind_hotspot+0x294b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28e1, 0x294b, x86_l_294b);
x86_l_28e3:
	/* 0x28e3: mov    DWORD PTR [rsp+0xec],0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281901ULL);
x86_l_28ee:
	/* 0x28ee: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_28f5:
	/* 0x28f5: lea    rsi,[rsp+0xec] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236ULL);
x86_l_28fd:
	/* 0x28fd: call   2902 <perf_unwind_hotspot+0x2902> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2902:
	/* 0x2902: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2905:
	/* 0x2905: je     290a <perf_unwind_hotspot+0x290a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2905, 0x290a, x86_l_290a);
x86_l_2907:
	/* 0x2907: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_290a:
	/* 0x290a: mov    eax,0x3e9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1001ULL);
x86_l_290f:
	/* 0x290f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2911:
	/* 0x2911: mov    ebp,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_2916:
	/* 0x2916: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2918:
	/* 0x2918: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2918, 0x10c, x86_l_10c);
x86_l_291e:
	/* 0x291e: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2920:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10cULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x207aULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e0ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2935ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x293fULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2101ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2137ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_292e:
	/* 0x292e: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2933:
	/* 0x2933: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10cULL: goto x86_l_10c;
			case 0x207aULL: goto x86_l_207a;
			case 0x20e0ULL: goto x86_l_20e0;
			case 0x2101ULL: goto x86_l_2101;
			case 0x2137ULL: goto x86_l_2137;
			case 0x2935ULL: goto x86_l_2935;
			case 0x293fULL: goto x86_l_293f;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2935:
	/* 0x2935: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_293a:
	/* 0x293a: jmp    20e5 <perf_unwind_hotspot+0x20e5> */
	X86_SIM_X86_JMP(0x293a, 0x20e5, x86_l_20e5);
x86_l_293f:
	/* 0x293f: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2946:
	/* 0x2946: jmp    20fa <perf_unwind_hotspot+0x20fa> */
	X86_SIM_X86_JMP(0x2946, 0x20fa, x86_l_20fa);
x86_l_294b:
	/* 0x294b: mov    rbp,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2950:
	/* 0x2950: movzx  ecx,BYTE PTR [r15+0x1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 29ULL);
x86_l_2955:
	/* 0x2955: add    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2958:
	/* 0x2958: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_295a:
	/* 0x295a: mov    rsi,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2962:
	/* 0x2962: cmp    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2965:
	/* 0x2965: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_296a:
	/* 0x296a: cmovae rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RCX, X86_WIDTH_64, X86_CC_AE, 0);
x86_l_296e:
	/* 0x296e: sub    rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2971:
	/* 0x2971: cmp    rsi,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, 65535ULL);
x86_l_2978:
	/* 0x2978: mov    ecx,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_297d:
	/* 0x297d: cmovb  rcx,rsi */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RSI, X86_WIDTH_64, X86_CC_B, 0);
x86_l_2981:
	/* 0x2981: mov    QWORD PTR [rsp+0xa8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2989:
	/* 0x2989: shr    rbp,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_298d:
	/* 0x298d: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_2992:
	/* 0x2992: mov    dl,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2994:
	/* 0x2994: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2998:
	/* 0x2998: mov    rbx,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_299d:
	/* 0x299d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_299f:
	/* 0x299f: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x299f, 0x10c, x86_l_10c);
x86_l_29a5:
	/* 0x29a5: jmp    291e <perf_unwind_hotspot+0x291e> */
	X86_SIM_X86_JMP(0x29a5, 0x291e, x86_l_291e);
x86_l_29aa:
	/* 0x29aa: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_29ad:
	/* 0x29ad: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_29b0:
	/* 0x29b0: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_29b4:
	/* 0x29b4: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_29b9:
	/* 0x29b9: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_29be:
	/* 0x29be: call   29c3 <perf_unwind_hotspot+0x29c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_29c3:
	/* 0x29c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29c6:
	/* 0x29c6: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29c6, 0xda, x86_l_da);
x86_l_29cc:
	/* 0x29cc: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_29d1:
	/* 0x29d1: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_29d4:
	/* 0x29d4: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_29d7:
	/* 0x29d7: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x29d7, 0x23d0, x86_l_23d0);
x86_l_29dd:
	/* 0x29dd: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_29e0:
	/* 0x29e0: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_29e3:
	/* 0x29e3: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_29e7:
	/* 0x29e7: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_29ec:
	/* 0x29ec: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_29f1:
	/* 0x29f1: call   29f6 <perf_unwind_hotspot+0x29f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_29f6:
	/* 0x29f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_29f9:
	/* 0x29f9: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x29f9, 0xda, x86_l_da);
x86_l_29ff:
	/* 0x29ff: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2a04:
	/* 0x2a04: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a07:
	/* 0x2a07: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2a0a:
	/* 0x2a0a: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a0a, 0x23d0, x86_l_23d0);
x86_l_2a10:
	/* 0x2a10: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2a13:
	/* 0x2a13: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2a16:
	/* 0x2a16: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2a1a:
	/* 0x2a1a: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2a1f:
	/* 0x2a1f: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2a24:
	/* 0x2a24: call   2a29 <perf_unwind_hotspot+0x2a29> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a29:
	/* 0x2a29: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a2c:
	/* 0x2a2c: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a2c, 0xda, x86_l_da);
x86_l_2a32:
	/* 0x2a32: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2a37:
	/* 0x2a37: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a3a:
	/* 0x2a3a: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2a3d:
	/* 0x2a3d: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a3d, 0x23d0, x86_l_23d0);
x86_l_2a43:
	/* 0x2a43: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2a46:
	/* 0x2a46: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2a49:
	/* 0x2a49: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2a4d:
	/* 0x2a4d: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2a52:
	/* 0x2a52: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2a57:
	/* 0x2a57: call   2a5c <perf_unwind_hotspot+0x2a5c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a5c:
	/* 0x2a5c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a5f:
	/* 0x2a5f: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a5f, 0xda, x86_l_da);
x86_l_2a65:
	/* 0x2a65: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2a6a:
	/* 0x2a6a: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a6d:
	/* 0x2a6d: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2a70:
	/* 0x2a70: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a70, 0x23d0, x86_l_23d0);
x86_l_2a76:
	/* 0x2a76: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2a79:
	/* 0x2a79: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2a7c:
	/* 0x2a7c: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2a80:
	/* 0x2a80: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2a85:
	/* 0x2a85: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2a8a:
	/* 0x2a8a: call   2a8f <perf_unwind_hotspot+0x2a8f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a8f:
	/* 0x2a8f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a92:
	/* 0x2a92: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a92, 0xda, x86_l_da);
x86_l_2a98:
	/* 0x2a98: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2a9d:
	/* 0x2a9d: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2aa0:
	/* 0x2aa0: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2aa3:
	/* 0x2aa3: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2aa3, 0x23d0, x86_l_23d0);
x86_l_2aa9:
	/* 0x2aa9: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2aac:
	/* 0x2aac: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2aaf:
	/* 0x2aaf: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2ab3:
	/* 0x2ab3: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2ab8:
	/* 0x2ab8: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2abd:
	/* 0x2abd: call   2ac2 <perf_unwind_hotspot+0x2ac2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2ac2:
	/* 0x2ac2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ac5:
	/* 0x2ac5: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ac5, 0xda, x86_l_da);
x86_l_2acb:
	/* 0x2acb: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2ad0:
	/* 0x2ad0: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2ad3:
	/* 0x2ad3: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2ad6:
	/* 0x2ad6: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2ad6, 0x23d0, x86_l_23d0);
x86_l_2adc:
	/* 0x2adc: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2adf:
	/* 0x2adf: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2ae2:
	/* 0x2ae2: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2ae6:
	/* 0x2ae6: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2aeb:
	/* 0x2aeb: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2af0:
	/* 0x2af0: call   2af5 <perf_unwind_hotspot+0x2af5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2af5:
	/* 0x2af5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2af8:
	/* 0x2af8: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2af8, 0xda, x86_l_da);
x86_l_2afe:
	/* 0x2afe: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2b03:
	/* 0x2b03: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b06:
	/* 0x2b06: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2b09:
	/* 0x2b09: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b09, 0x23d0, x86_l_23d0);
x86_l_2b0f:
	/* 0x2b0f: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2b12:
	/* 0x2b12: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2b15:
	/* 0x2b15: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2b19:
	/* 0x2b19: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b1e:
	/* 0x2b1e: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2b23:
	/* 0x2b23: call   2b28 <perf_unwind_hotspot+0x2b28> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b28:
	/* 0x2b28: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b2b:
	/* 0x2b2b: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b2b, 0xda, x86_l_da);
x86_l_2b31:
	/* 0x2b31: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2b36:
	/* 0x2b36: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b39:
	/* 0x2b39: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2b3c:
	/* 0x2b3c: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b3c, 0x23d0, x86_l_23d0);
x86_l_2b42:
	/* 0x2b42: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2b45:
	/* 0x2b45: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2b48:
	/* 0x2b48: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2b4c:
	/* 0x2b4c: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b51:
	/* 0x2b51: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2b56:
	/* 0x2b56: call   2b5b <perf_unwind_hotspot+0x2b5b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b5b:
	/* 0x2b5b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b5e:
	/* 0x2b5e: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b5e, 0xda, x86_l_da);
x86_l_2b64:
	/* 0x2b64: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2b69:
	/* 0x2b69: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b6c:
	/* 0x2b6c: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2b6f:
	/* 0x2b6f: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2b6f, 0x23d0, x86_l_23d0);
x86_l_2b75:
	/* 0x2b75: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2b78:
	/* 0x2b78: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2b7b:
	/* 0x2b7b: lea    rdx,[rbx+rbp*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_2b7f:
	/* 0x2b7f: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2b84:
	/* 0x2b84: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2b89:
	/* 0x2b89: call   2b8e <perf_unwind_hotspot+0x2b8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b8e:
	/* 0x2b8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b91:
	/* 0x2b91: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b91, 0xda, x86_l_da);
x86_l_2b97:
	/* 0x2b97: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2b9c:
	/* 0x2b9c: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2b9f:
	/* 0x2b9f: cmp    cl,0x2 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2ba2:
	/* 0x2ba2: jb     23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2ba2, 0x23d0, x86_l_23d0);
x86_l_2ba8:
	/* 0x2ba8: movzx  eax,al */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_8, 0);
x86_l_2bab:
	/* 0x2bab: sub    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2bae:
	/* 0x2bae: add    rbp,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2bb1:
	/* 0x2bb1: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2bb6:
	/* 0x2bb6: mov    esi,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2bbb:
	/* 0x2bbb: mov    rdx,rbp */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_2bbe:
	/* 0x2bbe: call   2bc3 <perf_unwind_hotspot+0x2bc3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2bc3:
	/* 0x2bc3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2bc6:
	/* 0x2bc6: jne    da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bc6, 0xda, x86_l_da);
x86_l_2bcc:
	/* 0x2bcc: movzx  eax,BYTE PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 64ULL);
x86_l_2bd1:
	/* 0x2bd1: lea    ecx,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2bd4:
	/* 0x2bd4: cmp    cl,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2bd7:
	/* 0x2bd7: ja     da <perf_unwind_hotspot+0xda> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2bd7, 0xda, x86_l_da);
x86_l_2bdd:
	/* 0x2bdd: jmp    23d0 <perf_unwind_hotspot+0x23d0> */
	X86_SIM_X86_JMP(0x2bdd, 0x23d0, x86_l_23d0);
x86_l_2be2:
	/* 0x2be2: cmp    r12d,0x6974616e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1769234798ULL);
x86_l_2be9:
	/* 0x2be9: je     2bf8 <perf_unwind_hotspot+0x2bf8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2be9, 0x2bf8, x86_l_2bf8);
x86_l_2beb:
	/* 0x2beb: cmp    r12d,0x74656d6e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1952804206ULL);
x86_l_2bf2:
	/* 0x2bf2: jne    2d3c <perf_unwind_hotspot+0x2d3c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2bf2, 0x2d3c, x86_l_2d3c);
x86_l_2bf8:
	/* 0x2bf8: mov    rdx,QWORD PTR [rsp+0xc8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 200ULL);
x86_l_2c00:
	/* 0x2c00: mov    esi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_2c02:
	/* 0x2c02: add    rsi,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RSI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 168ULL);
x86_l_2c0a:
	/* 0x2c0a: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2c0c:
	/* 0x2c0c: mov    r12d,DWORD PTR [rsp+0xdc] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 220ULL);
x86_l_2c14:
	/* 0x2c14: cmove  rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_RDX, X86_WIDTH_64, X86_CC_E, 0);
x86_l_2c18:
	/* 0x2c18: cmp    QWORD PTR [rsp+0x30],rsi */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c1d:
	/* 0x2c1d: jne    2c69 <perf_unwind_hotspot+0x2c69> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c1d, 0x2c69, x86_l_2c69);
x86_l_2c1f:
	/* 0x2c1f: mov    edx,DWORD PTR [rsp+0xd4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 212ULL);
x86_l_2c26:
	/* 0x2c26: add    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_2c2b:
	/* 0x2c2b: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2c30:
	/* 0x2c30: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2c35:
	/* 0x2c35: call   2c3a <perf_unwind_hotspot+0x2c3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c3a:
	/* 0x2c3a: mov    rcx,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2c42:
	/* 0x2c42: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c45:
	/* 0x2c45: jne    2c69 <perf_unwind_hotspot+0x2c69> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c45, 0x2c69, x86_l_2c69);
x86_l_2c47:
	/* 0x2c47: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2c4c:
	/* 0x2c4c: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2c4f:
	/* 0x2c4f: jb     2c69 <perf_unwind_hotspot+0x2c69> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c4f, 0x2c69, x86_l_2c69);
x86_l_2c51:
	/* 0x2c51: cmp    rax,QWORD PTR [rsp+0xc0] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 192ULL);
x86_l_2c59:
	/* 0x2c59: jae    2c69 <perf_unwind_hotspot+0x2c69> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2c59, 0x2c69, x86_l_2c69);
x86_l_2c5b:
	/* 0x2c5b: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2c5d:
	/* 0x2c5d: sub    edx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RCX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_2c5f:
	/* 0x2c5f: mov    QWORD PTR [rsp+0x38],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2c64:
	/* 0x2c64: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c69:
	/* 0x2c69: movzx  eax,WORD PTR [rsp+0xe0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 224ULL);
x86_l_2c71:
	/* 0x2c71: add    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RCX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2c74:
	/* 0x2c74: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c79:
	/* 0x2c79: jae    2d5d <perf_unwind_hotspot+0x2d5d> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2c79, 0x2d5d, x86_l_2d5d);
x86_l_2c7f:
	/* 0x2c7f: add    rax,0xfffffffffffffffc */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551612ULL);
x86_l_2c83:
	/* 0x2c83: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_2c85:
	/* 0x2c85: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c89:
	/* 0x2c89: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2c8e:
	/* 0x2c8e: cmp    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c93:
	/* 0x2c93: jb     303c <perf_unwind_hotspot+0x303c> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c93, 0x303c, x86_l_303c);
x86_l_2c99:
	/* 0x2c99: jmp    305a <perf_unwind_hotspot+0x305a> */
	X86_SIM_X86_JMP(0x2c99, 0x305a, x86_l_305a);
x86_l_2c9e:
	/* 0x2c9e: mov    al,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, 0, 1ULL);
x86_l_2ca0:
	/* 0x2ca0: mov    DWORD PTR [rsp+0x20],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2ca4:
	/* 0x2ca4: jmp    303c <perf_unwind_hotspot+0x303c> */
	X86_SIM_X86_JMP(0x2ca4, 0x303c, x86_l_303c);
x86_l_2ca9:
	/* 0x2ca9: mov    rbp,QWORD PTR [r14+0xf00] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_2cb0:
	/* 0x2cb0: jmp    2cb7 <perf_unwind_hotspot+0x2cb7> */
	X86_SIM_X86_JMP(0x2cb0, 0x2cb7, x86_l_2cb7);
x86_l_2cb2:
	/* 0x2cb2: mov    rbp,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2cb7:
	/* 0x2cb7: mov    rbx,QWORD PTR [rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2cbc:
	/* 0x2cbc: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2cc4:
	/* 0x2cc4: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2cc9:
	/* 0x2cc9: mov    rax,QWORD PTR [rsp+0x90] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_2cd1:
	/* 0x2cd1: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2cd6:
	/* 0x2cd6: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2cde:
	/* 0x2cde: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ce3:
	/* 0x2ce3: movzx  edx,BYTE PTR [r15+0x1c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 28ULL);
x86_l_2ce8:
	/* 0x2ce8: add    rdx,rbx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2ceb:
	/* 0x2ceb: lea    rdi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2cf0:
	/* 0x2cf0: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2cf5:
	/* 0x2cf5: call   2cfa <perf_unwind_hotspot+0x2cfa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2cfa:
	/* 0x2cfa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cfd:
	/* 0x2cfd: je     2e52 <perf_unwind_hotspot+0x2e52> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cfd, 0x2e52, x86_l_2e52);
x86_l_2d03:
	/* 0x2d03: mov    DWORD PTR [rsp+0xec],0x2d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1013612281901ULL);
x86_l_2d0e:
	/* 0x2d0e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2d15:
	/* 0x2d15: lea    rsi,[rsp+0xec] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 236ULL);
x86_l_2d1d:
	/* 0x2d1d: call   2d22 <perf_unwind_hotspot+0x2d22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d22:
	/* 0x2d22: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d25:
	/* 0x2d25: je     2d2a <perf_unwind_hotspot+0x2d2a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d25, 0x2d2a, x86_l_2d2a);
x86_l_2d27:
	/* 0x2d27: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2d2a:
	/* 0x2d2a: mov    eax,0x3e9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1001ULL);
x86_l_2d2f:
	/* 0x2d2f: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2d31:
	/* 0x2d31: mov    r12d,0x65746e49 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1702129225ULL);
x86_l_2d37:
	/* 0x2d37: jmp    301d <perf_unwind_hotspot+0x301d> */
	X86_SIM_X86_JMP(0x2d37, 0x301d, x86_l_301d);
x86_l_2d3c:
	/* 0x2d3c: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2d43:
	/* 0x2d43: mov    DWORD PTR [rsp+0x20],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_2d4b:
	/* 0x2d4b: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d50:
	/* 0x2d50: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2d52:
	/* 0x2d52: jne    3078 <perf_unwind_hotspot+0x3078> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d52, 0x3078, x86_l_3078);
x86_l_2d58:
	/* 0x2d58: jmp    305a <perf_unwind_hotspot+0x305a> */
	X86_SIM_X86_JMP(0x2d58, 0x305a, x86_l_305a);
x86_l_2d5d:
	/* 0x2d5d: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_2d64:
	/* 0x2d64: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d69:
	/* 0x2d69: lea    rbx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2d6d:
	/* 0x2d6d: add    rbx,0x30 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 48ULL);
x86_l_2d71:
	/* 0x2d71: cmp    QWORD PTR [rsp+0x28],rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d76:
	/* 0x2d76: jb     2d89 <perf_unwind_hotspot+0x2d89> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d76, 0x2d89, x86_l_2d89);
x86_l_2d78:
	/* 0x2d78: mov    cl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_2d7a:
	/* 0x2d7a: mov    DWORD PTR [rsp+0x20],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d7e:
	/* 0x2d7e: cmp    QWORD PTR [rsp+0x28],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d83:
	/* 0x2d83: jb     304e <perf_unwind_hotspot+0x304e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d83, 0x304e, x86_l_304e);
x86_l_2d89:
	/* 0x2d89: movabs rbp,0xff00000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 18374686479671623680ULL);
x86_l_2d93:
	/* 0x2d93: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d98:
	/* 0x2d98: lea    r15,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2d9c:
	/* 0x2d9c: lea    rdx,[rcx+rax*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 0), 0ULL);
x86_l_2da0:
	/* 0x2da0: add    rdx,0xfffffffffffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 18446744073709551608ULL);
x86_l_2da4:
	/* 0x2da4: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2da9:
	/* 0x2da9: mov    esi,0x30 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 48ULL);
x86_l_2dae:
	/* 0x2dae: call   2db3 <perf_unwind_hotspot+0x2db3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2db3:
	/* 0x2db3: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db6:
	/* 0x2db6: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2dbe:
	/* 0x2dbe: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2dc4:
	/* 0x2dc4: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_2dc9:
	/* 0x2dc9: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2dd0:
	/* 0x2dd0: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2dd7:
	/* 0x2dd7: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ddc:
	/* 0x2ddc: call   2de1 <perf_unwind_hotspot+0x2de1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2de1:
	/* 0x2de1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2de4:
	/* 0x2de4: je     2e00 <perf_unwind_hotspot+0x2e00> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2de4, 0x2e00, x86_l_2e00);
x86_l_2de6:
	/* 0x2de6: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2dea:
	/* 0x2dea: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2ded:
	/* 0x2ded: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2df7:
	/* 0x2df7: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2dfa:
	/* 0x2dfa: je     2fde <perf_unwind_hotspot+0x2fde> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2dfa, 0x2fde, x86_l_2fde);
x86_l_2e00:
	/* 0x2e00: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2e03:
	/* 0x2e03: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2e0b:
	/* 0x2e0b: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2e11:
	/* 0x2e11: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2e16:
	/* 0x2e16: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2e1d:
	/* 0x2e1d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2e24:
	/* 0x2e24: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e29:
	/* 0x2e29: call   2e2e <perf_unwind_hotspot+0x2e2e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2e2e:
	/* 0x2e2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2e31:
	/* 0x2e31: je     2ea1 <perf_unwind_hotspot+0x2ea1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e31, 0x2ea1, x86_l_2ea1);
x86_l_2e33:
	/* 0x2e33: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e37:
	/* 0x2e37: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2e3a:
	/* 0x2e3a: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2e44:
	/* 0x2e44: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e47:
	/* 0x2e47: jne    2ea1 <perf_unwind_hotspot+0x2ea1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2e47, 0x2ea1, x86_l_2ea1);
x86_l_2e49:
	/* 0x2e49: add    r15,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2e4d:
	/* 0x2e4d: jmp    2fde <perf_unwind_hotspot+0x2fde> */
	X86_SIM_X86_JMP(0x2e4d, 0x2fde, x86_l_2fde);
x86_l_2e52:
	/* 0x2e52: mov    r12,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e57:
	/* 0x2e57: movzx  ecx,BYTE PTR [r15+0x1d] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 29ULL);
x86_l_2e5c:
	/* 0x2e5c: add    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2e5f:
	/* 0x2e5f: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2e61:
	/* 0x2e61: cmp    rbp,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2e64:
	/* 0x2e64: mov    edx,0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 0ULL);
x86_l_2e69:
	/* 0x2e69: cmovae rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RCX, X86_WIDTH_64, X86_CC_AE, 0);
x86_l_2e6d:
	/* 0x2e6d: sub    rbp,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2e70:
	/* 0x2e70: cmp    rbp,0xffff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 65535ULL);
x86_l_2e77:
	/* 0x2e77: mov    ecx,0xffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 65535ULL);
x86_l_2e7c:
	/* 0x2e7c: cmovb  rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_RBP, X86_WIDTH_64, X86_CC_B, 0);
x86_l_2e80:
	/* 0x2e80: mov    QWORD PTR [rsp+0x38],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2e85:
	/* 0x2e85: shr    r12,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 3ULL);
x86_l_2e89:
	/* 0x2e89: mov    ecx,0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 6ULL);
x86_l_2e8e:
	/* 0x2e8e: mov    dl,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 2ULL);
x86_l_2e90:
	/* 0x2e90: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e94:
	/* 0x2e94: mov    QWORD PTR [rsp+0xa8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2e9c:
	/* 0x2e9c: jmp    301d <perf_unwind_hotspot+0x301d> */
	X86_SIM_X86_JMP(0x2e9c, 0x301d, x86_l_301d);
x86_l_2ea1:
	/* 0x2ea1: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ea4:
	/* 0x2ea4: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2eac:
	/* 0x2eac: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2eb2:
	/* 0x2eb2: mov    rax,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2eb7:
	/* 0x2eb7: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2ebe:
	/* 0x2ebe: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2ec5:
	/* 0x2ec5: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2eca:
	/* 0x2eca: call   2ecf <perf_unwind_hotspot+0x2ecf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2ecf:
	/* 0x2ecf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2ed2:
	/* 0x2ed2: je     2ef3 <perf_unwind_hotspot+0x2ef3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ed2, 0x2ef3, x86_l_2ef3);
x86_l_2ed4:
	/* 0x2ed4: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ed8:
	/* 0x2ed8: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2edb:
	/* 0x2edb: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2ee5:
	/* 0x2ee5: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2ee8:
	/* 0x2ee8: jne    2ef3 <perf_unwind_hotspot+0x2ef3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ee8, 0x2ef3, x86_l_2ef3);
x86_l_2eea:
	/* 0x2eea: add    r15,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2eee:
	/* 0x2eee: jmp    2fde <perf_unwind_hotspot+0x2fde> */
	X86_SIM_X86_JMP(0x2eee, 0x2fde, x86_l_2fde);
x86_l_2ef3:
	/* 0x2ef3: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef6:
	/* 0x2ef6: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2efe:
	/* 0x2efe: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2f04:
	/* 0x2f04: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2f09:
	/* 0x2f09: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2f10:
	/* 0x2f10: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2f17:
	/* 0x2f17: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f1c:
	/* 0x2f1c: call   2f21 <perf_unwind_hotspot+0x2f21> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f21:
	/* 0x2f21: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f24:
	/* 0x2f24: je     2f45 <perf_unwind_hotspot+0x2f45> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f24, 0x2f45, x86_l_2f45);
x86_l_2f26:
	/* 0x2f26: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f2a:
	/* 0x2f2a: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2f2d:
	/* 0x2f2d: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2f37:
	/* 0x2f37: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f3a:
	/* 0x2f3a: jne    2f45 <perf_unwind_hotspot+0x2f45> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f3a, 0x2f45, x86_l_2f45);
x86_l_2f3c:
	/* 0x2f3c: add    r15,0x18 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_2f40:
	/* 0x2f40: jmp    2fde <perf_unwind_hotspot+0x2fde> */
	X86_SIM_X86_JMP(0x2f40, 0x2fde, x86_l_2fde);
x86_l_2f45:
	/* 0x2f45: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f48:
	/* 0x2f48: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2f50:
	/* 0x2f50: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2f56:
	/* 0x2f56: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2f5b:
	/* 0x2f5b: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2f62:
	/* 0x2f62: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2f69:
	/* 0x2f69: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f6e:
	/* 0x2f6e: call   2f73 <perf_unwind_hotspot+0x2f73> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2f73:
	/* 0x2f73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2f76:
	/* 0x2f76: je     2f94 <perf_unwind_hotspot+0x2f94> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f76, 0x2f94, x86_l_2f94);
x86_l_2f78:
	/* 0x2f78: mov    rax,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2f7c:
	/* 0x2f7c: and    rax,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2f7f:
	/* 0x2f7f: movabs rcx,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2f89:
	/* 0x2f89: cmp    rax,rcx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RAX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_2f8c:
	/* 0x2f8c: jne    2f94 <perf_unwind_hotspot+0x2f94> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2f8c, 0x2f94, x86_l_2f94);
x86_l_2f8e:
	/* 0x2f8e: add    r15,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_2f92:
	/* 0x2f92: jmp    2fde <perf_unwind_hotspot+0x2fde> */
	X86_SIM_X86_JMP(0x2f92, 0x2fde, x86_l_2fde);
x86_l_2f94:
	/* 0x2f94: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f97:
	/* 0x2f97: mov    DWORD PTR [rsp+0x10],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476832ULL);
x86_l_2f9f:
	/* 0x2f9f: movbe  DWORD PTR [rsp+0x14],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 20ULL);
x86_l_2fa5:
	/* 0x2fa5: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2faa:
	/* 0x2faa: movbe  QWORD PTR [rsp+0x18],rax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2fb1:
	/* 0x2fb1: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2fb8:
	/* 0x2fb8: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2fbd:
	/* 0x2fbd: call   2fc2 <perf_unwind_hotspot+0x2fc2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2fc2:
	/* 0x2fc2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fc5:
	/* 0x2fc5: je     2fea <perf_unwind_hotspot+0x2fea> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2fc5, 0x2fea, x86_l_2fea);
x86_l_2fc7:
	/* 0x2fc7: and    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RBP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_2fcb:
	/* 0x2fcb: movabs rax,0x200000000000000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 144115188075855872ULL);
x86_l_2fd5:
	/* 0x2fd5: cmp    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2fd8:
	/* 0x2fd8: jne    2fea <perf_unwind_hotspot+0x2fea> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2fd8, 0x2fea, x86_l_2fea);
x86_l_2fda:
	/* 0x2fda: add    r15,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_2fde:
	/* 0x2fde: xor    eax,eax */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2fe0:
	/* 0x2fe0: mov    ecx,0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 5ULL);
x86_l_2fe5:
	/* 0x2fe5: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_2fe8:
	/* 0x2fe8: jmp    3012 <perf_unwind_hotspot+0x3012> */
	X86_SIM_X86_JMP(0x2fe8, 0x3012, x86_l_3012);
x86_l_2fea:
	/* 0x2fea: mov    DWORD PTR [rsp+0x10],0x2e */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 68719476782ULL);
x86_l_2ff2:
	/* 0x2ff2: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2ff9:
	/* 0x2ff9: lea    rsi,[rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ffe:
	/* 0x2ffe: call   3003 <perf_unwind_hotspot+0x3003> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3003:
	/* 0x3003: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3006:
	/* 0x3006: je     300b <perf_unwind_hotspot+0x300b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3006, 0x300b, x86_l_300b);
x86_l_3008:
	/* 0x3008: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_300b:
	/* 0x300b: mov    eax,0x3ea */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1002ULL);
x86_l_3010:
	/* 0x3010: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_3012:
	/* 0x3012: mov    dl,0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, 0, 3ULL);
x86_l_3014:
	/* 0x3014: mov    DWORD PTR [rsp+0x20],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3018:
	/* 0x3018: mov    QWORD PTR [rsp+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_301d:
	/* 0x301d: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_301f:
	/* 0x301f: jne    10c <perf_unwind_hotspot+0x10c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x301f, 0x10c, x86_l_10c);
x86_l_3025:
	/* 0x3025: mov    eax,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3027:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x10cULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x303cULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x304eULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x3055ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x3071ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x307fULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x30b5ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_3035:
	/* 0x3035: mov    eax,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_303a:
	/* 0x303a: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x10cULL: goto x86_l_10c;
			case 0x303cULL: goto x86_l_303c;
			case 0x304eULL: goto x86_l_304e;
			case 0x3055ULL: goto x86_l_3055;
			case 0x3071ULL: goto x86_l_3071;
			case 0x307fULL: goto x86_l_307f;
			case 0x30b5ULL: goto x86_l_30b5;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_303c:
	/* 0x303c: mov    DWORD PTR [rsp+0xd8],0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935944ULL);
x86_l_3047:
	/* 0x3047: mov    eax,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_304c:
	/* 0x304c: jmp    3078 <perf_unwind_hotspot+0x3078> */
	X86_SIM_X86_JMP(0x304c, 0x3078, x86_l_3078);
x86_l_304e:
	/* 0x304e: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3053:
	/* 0x3053: jmp    305a <perf_unwind_hotspot+0x305a> */
	X86_SIM_X86_JMP(0x3053, 0x305a, x86_l_305a);
x86_l_3055:
	/* 0x3055: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_305a:
	/* 0x305a: mov    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_3065:
	/* 0x3065: mov    eax,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_306a:
	/* 0x306a: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_306f:
	/* 0x306f: jmp    3078 <perf_unwind_hotspot+0x3078> */
	X86_SIM_X86_JMP(0x306f, 0x3078, x86_l_3078);
x86_l_3071:
	/* 0x3071: mov    eax,DWORD PTR [rsp+0xd8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 216ULL);
x86_l_3078:
	/* 0x3078: mov    eax,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_307a:
	/* 0x307a: add    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_REG, X86_RSP, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 8ULL);
x86_l_307f:
	/* 0x307f: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3084:
	/* 0x3084: lea    rdx,[rax-0x10] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_3088:
	/* 0x3088: lea    rdi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_308d:
	/* 0x308d: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_3092:
	/* 0x3092: call   3097 <perf_unwind_hotspot+0x3097> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_3097:
	/* 0x3097: cmp    DWORD PTR [rsp+0xd8],0x10 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 927712935952ULL);
x86_l_309f:
	/* 0x309f: jb     30ab <perf_unwind_hotspot+0x30ab> */
	X86_SIM_X86_JCC(X86_CC_B, 0x309f, 0x30ab, x86_l_30ab);
x86_l_30a1:
	/* 0x30a1: mov    rax,QWORD PTR [rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_30a6:
	/* 0x30a6: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_30ab:
	/* 0x30ab: mov    rax,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_30b0:
	/* 0x30b0: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30b5:
	/* 0x30b5: mov    eax,DWORD PTR [r14+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_30bc:
	/* 0x30bc: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_30c0:
	/* 0x30c0: ja     7d6 <perf_unwind_hotspot+0x7d6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x30c0, 0x7d6, x86_l_7d6);
x86_l_30c6:
	/* 0x30c6: movzx  ecx,BYTE PTR [r14+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_30ce:
	/* 0x30ce: movzx  edx,BYTE PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 32ULL);
x86_l_30d3:
	/* 0x30d3: shl    rdx,0x3c */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 60ULL);
x86_l_30d7:
	/* 0x30d7: mov    rdi,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_30dc:
	/* 0x30dc: shl    rdi,0x20 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHL, 32ULL);
x86_l_30e0:
	/* 0x30e0: mov    esi,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_30e3:
	/* 0x30e3: or     rsi,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDI, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_30e6:
	/* 0x30e6: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_30e9:
	/* 0x30e9: mov    DWORD PTR [r14+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_30f0:
	/* 0x30f0: or     rsi,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RDX, X86_WIDTH_64, X86_ALU_OR, 0);
x86_l_30f3:
	/* 0x30f3: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_30f7:
	/* 0x30f7: mov    rdx,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_30ff:
	/* 0x30ff: mov    QWORD PTR [r14+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_3107:
	/* 0x3107: mov    QWORD PTR [r14+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_310f:
	/* 0x310f: mov    BYTE PTR [r14+rax*8+0x2e0],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929861ULL);
x86_l_3118:
	/* 0x3118: mov    BYTE PTR [r14+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_3120:
	/* 0x3120: mov    DWORD PTR [r14+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_312c:
	/* 0x312c: mov    WORD PTR [r14+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_3137:
	/* 0x3137: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_313c:
	/* 0x313c: mov    QWORD PTR [r14+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_3143:
	/* 0x3143: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3148:
	/* 0x3148: mov    QWORD PTR [r14+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_314f:
	/* 0x314f: mov    rax,QWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3154:
	/* 0x3154: mov    QWORD PTR [r14+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_315b:
	/* 0x315b: mov    BYTE PTR [r14+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_3163:
	/* 0x3163: mov    DWORD PTR [rsp+0x40],0x2a */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877906986ULL);
x86_l_316b:
	/* 0x316b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_3172:
	/* 0x3172: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3177:
	/* 0x3177: call   317c <perf_unwind_hotspot+0x317c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_317c:
	/* 0x317c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_317f:
	/* 0x317f: je     3184 <perf_unwind_hotspot+0x3184> */
	X86_SIM_X86_JCC(X86_CC_E, 0x317f, 0x3184, x86_l_3184);
x86_l_3181:
	/* 0x3181: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_3184:
	/* 0x3184: mov    rbx,QWORD PTR [r14+0xed0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_318b:
	/* 0x318b: test   rbx,rbx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_318e:
	/* 0x318e: je     32ab <perf_unwind_hotspot+0x32ab> */
	X86_SIM_X86_JCC(X86_CC_E, 0x318e, 0x32ab, x86_l_32ab);
x86_l_3194:
	/* 0x3194: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_319e:
	/* 0x319e: cmp    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31a1:
	/* 0x31a1: ja     d7d <perf_unwind_hotspot+0xd7d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x31a1, 0xd7d, x86_l_d7d);
x86_l_31a7:
	/* 0x31a7: cmp    rbx,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_31ae:
	/* 0x31ae: jb     d9e <perf_unwind_hotspot+0xd9e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x31ae, 0xd9e, x86_l_d9e);
x86_l_31b4:
	/* 0x31b4: mov    eax,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31b7:
	/* 0x31b7: mov    DWORD PTR [rsp+0x40],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 274877907040ULL);
x86_l_31bf:
	/* 0x31bf: movbe  DWORD PTR [rsp+0x44],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68ULL);
x86_l_31c5:
	/* 0x31c5: movbe  QWORD PTR [rsp+0x48],rbx */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 72ULL);
x86_l_31cc:
	/* 0x31cc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_31d3:
	/* 0x31d3: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_31d8:
	/* 0x31d8: call   31dd <perf_unwind_hotspot+0x31dd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_31dd:
	/* 0x31dd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_31e0:
	/* 0x31e0: je     32c3 <perf_unwind_hotspot+0x32c3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x31e0, 0x32c3, x86_l_32c3);
x86_l_31e6:
	/* 0x31e6: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_31ea:
	/* 0x31ea: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_31f4:
	/* 0x31f4: and    rcx,rbp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RBP, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_31f7:
	/* 0x31f7: mov    QWORD PTR [r14+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_31fe:
	/* 0x31fe: shr    rbp,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_3202:
	/* 0x3202: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3205:
	/* 0x3205: mov    QWORD PTR [r14+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_320c:
	/* 0x320c: sub    rbx,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_320f:
	/* 0x320f: mov    QWORD PTR [r14+0xf18],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_3216:
	/* 0x3216: cmp    rbp,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_321a:
	/* 0x321a: jne    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x321a, 0x111, x86_l_111);
x86_l_3220:
	/* 0x3220: mov    QWORD PTR [rsp+0x40],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3225:
	/* 0x3225: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_322c:
	/* 0x322c: lea    rsi,[rsp+0x40] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 64ULL);
x86_l_3231:
	/* 0x3231: call   3236 <perf_unwind_hotspot+0x3236> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3236:
	/* 0x3236: mov    ebp,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_323b:
	/* 0x323b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_323e:
	/* 0x323e: je     111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_E, 0x323e, 0x111, x86_l_111);
x86_l_3244:
	/* 0x3244: mov    r15,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3247:
	/* 0x3247: cmp    QWORD PTR [rax],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_324a:
	/* 0x324a: ja     3252 <perf_unwind_hotspot+0x3252> */
	X86_SIM_X86_JCC(X86_CC_A, 0x324a, 0x3252, x86_l_3252);
x86_l_324c:
	/* 0x324c: cmp    QWORD PTR [r15+0x8],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3250:
	/* 0x3250: jae    3266 <perf_unwind_hotspot+0x3266> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3250, 0x3266, x86_l_3266);
x86_l_3252:
	/* 0x3252: cmp    QWORD PTR [r15+0x10],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3256:
	/* 0x3256: ja     111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_A, 0x3256, 0x111, x86_l_111);
x86_l_325c:
	/* 0x325c: cmp    QWORD PTR [r15+0x18],rbx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3260:
	/* 0x3260: jb     111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3260, 0x111, x86_l_111);
x86_l_3266:
	/* 0x3266: mov    eax,DWORD PTR [r14+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_326d:
	/* 0x326d: mov    ecx,DWORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3271:
	/* 0x3271: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_3274:
	/* 0x3274: jb     111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3274, 0x111, x86_l_111);
x86_l_327a:
	/* 0x327a: mov    DWORD PTR [rsp+0xb0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 755914244096ULL);
x86_l_3285:
	/* 0x3285: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_328c:
	/* 0x328c: lea    rsi,[rsp+0xb0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 176ULL);
x86_l_3294:
	/* 0x3294: call   3299 <perf_unwind_hotspot+0x3299> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3299:
	/* 0x3299: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_329c:
	/* 0x329c: je     32a1 <perf_unwind_hotspot+0x32a1> */
	X86_SIM_X86_JCC(X86_CC_E, 0x329c, 0x32a1, x86_l_32a1);
x86_l_329e:
	/* 0x329e: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_32a1:
	/* 0x32a1: movzx  ebp,WORD PTR [r15+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_32a6:
	/* 0x32a6: jmp    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JMP(0x32a6, 0x111, x86_l_111);
x86_l_32ab:
	/* 0x32ab: mov    DWORD PTR [r14+0xf28],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108481ULL);
x86_l_32b6:
	/* 0x32b6: mov    r13d,0xfad */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4013ULL);
x86_l_32bc:
	/* 0x32bc: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32be:
	/* 0x32be: jmp    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JMP(0x32be, 0x111, x86_l_111);
x86_l_32c3:
	/* 0x32c3: mov    DWORD PTR [r14+0xf28],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108492ULL);
x86_l_32ce:
	/* 0x32ce: mov    r13d,0xfac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, 0, 4012ULL);
x86_l_32d4:
	/* 0x32d4: xor    ebp,ebp */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBP, X86_RBP, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_32d6:
	/* 0x32d6: jmp    111 <perf_unwind_hotspot+0x111> */
	X86_SIM_X86_JMP(0x32d6, 0x111, x86_l_111);
x86_l_32db:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
