#include "/workspaces/repository/kprog/x86/micro-prog/native_lpm.h"
__KPROG_LPM_CODE
static __attribute__((noinline)) void *__kprog_lpm_key_16(void *map,const void *key) { return __kprog_lpm_lookup(map,key,12,96,288,0,16,20,24); }
extern unsigned char __kprog_lpm_map_0[] __asm__("pid_page_to_mapping_info");
#include "/workspaces/repository/kprog/x86/micro-prog/native_hash.h"
__KPROG_HASH_CODE
static __attribute__((noinline)) void *__kprog_hash_key_4(void *map,const void *key) { return __kprog_hash_lookup(map,key,4,448,824,832,16,0,0,0,40,48); }
static __attribute__((noinline)) void *__kprog_hash_key_8(void *map,const void *key) { return __kprog_hash_lookup(map,key,8,448,824,832,16,0,0,0,40,48); }
extern unsigned char __kprog_hash_map_0[] __asm__("interpreter_offsets");
extern unsigned char __kprog_hash_map_1[] __asm__("hotspot_procs");

extern void *bpf_this_cpu_ptr(const void *);
typedef unsigned __kprog_percpu_u32 __attribute__((aligned(1),may_alias));
static __attribute__((always_inline)) inline void *
__kprog_percpu_array_lookup(void *map,const void *key) {
    unsigned index=*(const __kprog_percpu_u32 *)key;
    if (index>=*(const unsigned *)((const char *)map+68)) return (void *)0;
    unsigned mask=*(const unsigned *)((const char *)map+292);
    const void *base=*(void *const *)((const char *)map+304+
        (unsigned long)(index&mask)*sizeof(void *));
    return bpf_this_cpu_ptr(base);
}
extern unsigned char __kprog_percpu_map_0[] __asm__("metrics");
extern unsigned char __kprog_percpu_map_1[] __asm__("per_cpu_records");
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_percpu_map_0 || map == __kprog_percpu_map_1) return __kprog_percpu_array_lookup(map,key);
    if (map == __kprog_lpm_map_0) return __kprog_lpm_key_16(map,key);
    if (map == __kprog_hash_map_0) return __kprog_hash_key_8(map,key);
    if (map == __kprog_hash_map_1) return __kprog_hash_key_4(map,key);

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
#include "/workspaces/repository/kprog/x86/micro-prog/inline_probe.c"
