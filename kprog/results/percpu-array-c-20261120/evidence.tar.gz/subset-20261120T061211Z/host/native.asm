
/var/tmp/kprog-tmp/perf/percpu-array-c/native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <selected>:
       0: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x7 <selected+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	counts-0x4
       7: 8b 0f                        	movl	(%rdi), %ecx
       9: 3b 48 44                     	cmpl	0x44(%rax), %ecx
       c: 73 13                        	jae	0x21 <selected+0x21>
       e: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
      14: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
      1c: e9 00 00 00 00               	jmp	0x21 <selected+0x21>
		000000000000001d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      21: 31 c0                        	xorl	%eax, %eax
      23: c3                           	retq
      24: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

0000000000000030 <selected_alias>:
      30: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x37 <selected_alias+0x7>
		0000000000000033:  R_X86_64_REX_GOTPCRELX	same-0x4
      37: 8b 0f                        	movl	(%rdi), %ecx
      39: 3b 48 44                     	cmpl	0x44(%rax), %ecx
      3c: 73 13                        	jae	0x51 <selected_alias+0x21>
      3e: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
      44: 48 8b bc c8 30 01 00 00      	movq	0x130(%rax,%rcx,8), %rdi
      4c: e9 00 00 00 00               	jmp	0x51 <selected_alias+0x21>
		000000000000004d:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      51: 31 c0                        	xorl	%eax, %eax
      53: c3                           	retq
      54: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

0000000000000060 <unselected>:
      60: 48 89 fe                     	movq	%rdi, %rsi
      63: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x6a <unselected+0xa>
		0000000000000066:  R_X86_64_REX_GOTPCRELX	other-0x4
      6a: e9 00 00 00 00               	jmp	0x6f <unselected+0xf>
		000000000000006b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      6f: 90                           	nop

0000000000000070 <dynamic>:
      70: e9 00 00 00 00               	jmp	0x75 <dynamic+0x5>
		0000000000000071:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      75: 66 66 2e 0f 1f 84 00 00 00 00 00     	nopw	%cs:(%rax,%rax)

0000000000000080 <__kprog_array_lookup>:
      80: 8b 47 44                     	movl	0x44(%rdi), %eax
      83: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x8a <__kprog_array_lookup+0xa>
		0000000000000086:  R_X86_64_REX_GOTPCRELX	counts-0x4
      8a: 74 2a                        	je	0xb6 <__kprog_array_lookup+0x36>
      8c: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x93 <__kprog_array_lookup+0x13>
		000000000000008f:  R_X86_64_REX_GOTPCRELX	same-0x4
      93: 74 21                        	je	0xb6 <__kprog_array_lookup+0x36>
      95: 8b 0e                        	movl	(%rsi), %ecx
      97: 39 c1                        	cmpl	%eax, %ecx
      99: 73 34                        	jae	0xcf <__kprog_array_lookup+0x4f>
      9b: 8b 87 20 01 00 00            	movl	0x120(%rdi), %eax
      a1: 23 8f 24 01 00 00            	andl	0x124(%rdi), %ecx
      a7: 48 0f af c8                  	imulq	%rax, %rcx
      ab: 48 8d 04 0f                  	leaq	(%rdi,%rcx), %rax
      af: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      b5: c3                           	retq
      b6: 8b 0e                        	movl	(%rsi), %ecx
      b8: 39 c1                        	cmpl	%eax, %ecx
      ba: 73 13                        	jae	0xcf <__kprog_array_lookup+0x4f>
      bc: 23 8f 24 01 00 00            	andl	0x124(%rdi), %ecx
      c2: 48 8b bc cf 30 01 00 00      	movq	0x130(%rdi,%rcx,8), %rdi
      ca: e9 00 00 00 00               	jmp	0xcf <__kprog_array_lookup+0x4f>
		00000000000000cb:  R_X86_64_PLT32	bpf_this_cpu_ptr-0x4
      cf: 31 c0                        	xorl	%eax, %eax
      d1: c3                           	retq
