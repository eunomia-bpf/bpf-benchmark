#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 328U
#define X86_SIM_STACK_VALUE_WORDS(M) M(1) M(2) M(3) M(4) M(6) M(7) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 exe_id_to_10_stack_deltas[] __ksym;
extern __u8 exe_id_to_11_stack_deltas[] __ksym;
extern __u8 exe_id_to_12_stack_deltas[] __ksym;
extern __u8 exe_id_to_13_stack_deltas[] __ksym;
extern __u8 exe_id_to_14_stack_deltas[] __ksym;
extern __u8 exe_id_to_15_stack_deltas[] __ksym;
extern __u8 exe_id_to_16_stack_deltas[] __ksym;
extern __u8 exe_id_to_17_stack_deltas[] __ksym;
extern __u8 exe_id_to_18_stack_deltas[] __ksym;
extern __u8 exe_id_to_19_stack_deltas[] __ksym;
extern __u8 exe_id_to_20_stack_deltas[] __ksym;
extern __u8 exe_id_to_21_stack_deltas[] __ksym;
extern __u8 exe_id_to_22_stack_deltas[] __ksym;
extern __u8 exe_id_to_23_stack_deltas[] __ksym;
extern __u8 exe_id_to_8_stack_deltas[] __ksym;
extern __u8 exe_id_to_9_stack_deltas[] __ksym;
extern __u8 interpreter_offsets[] __ksym;
extern __u8 metrics[] __ksym;
extern __u8 per_cpu_records[] __ksym;
extern __u8 perf_progs[] __ksym;
extern __u8 pid_page_to_mapping_info[] __ksym;
extern __u8 stack_delta_page_to_info[] __ksym;
extern __u8 unwind_info_array[] __ksym;
#include "/workspaces/repository/kprog/x86/x86_sim_inline.h"

X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_IMM, X86_OP_ALU_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM, X86_OP_ALU_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_MEM_UNARY, X86_OP_ALU_MEM_UNARY)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_ALU_REG, X86_OP_ALU_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_BT, X86_OP_BT)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CALL_HELPER, X86_OP_CALL_HELPER)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMOV, X86_OP_CMOV)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_IMM, X86_OP_CMP_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_IMM, X86_OP_CMP_MEM_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_MEM_REG, X86_OP_CMP_MEM_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG, X86_OP_CMP_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_CMP_REG_MEM, X86_OP_CMP_REG_MEM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_LEA, X86_OP_LEA)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVBE_STORE, X86_OP_MOVBE_STORE)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVSX_REG, X86_OP_MOVSX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOVZX_REG, X86_OP_MOVZX_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_IMM, X86_OP_MOV_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD, X86_OP_MOV_LOAD)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_LOAD_MAP_PTR, X86_OP_MOV_LOAD_MAP_PTR)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_REG, X86_OP_MOV_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_IMM, X86_OP_MOV_STORE_IMM)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_MOV_STORE_REG, X86_OP_MOV_STORE_REG)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_POP, X86_OP_POP)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_PUSH, X86_OP_PUSH)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_SETCC, X86_OP_SETCC)
X86_SIM_DECLARE_INSTRUCTION(__x86_instruction_X86_OP_TEST_REG, X86_OP_TEST_REG)

SEC("perf_event")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
	X86_SIM_BIND_INLINE();
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_RUN_OP(X86_OP_PUSH, X86_REG_NONE, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0x118 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SUB, 280ULL);
x86_l_11:
	/* 0x11: mov    r13,rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RDI, X86_WIDTH_64, 0, 0);
x86_l_14:
	/* 0x14: mov    DWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_1f:
	/* 0x1f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_26:
	/* 0x26: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2e:
	/* 0x2e: call   33 <perf_unwind_native+0x33> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_33:
	/* 0x33: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_36:
	/* 0x36: je     694 <perf_unwind_native+0x694> */
	X86_SIM_X86_JCC(X86_CC_E, 0x36, 0x694, x86_l_694);
x86_l_3c:
	/* 0x3c: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3f:
	/* 0x3f: mov    rbp,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBP, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_42:
	/* 0x42: mov    DWORD PTR [rsp+0x80],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813893ULL);
x86_l_4d:
	/* 0x4d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_54:
	/* 0x54: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_5c:
	/* 0x5c: call   61 <perf_unwind_native+0x61> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_61:
	/* 0x61: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_64:
	/* 0x64: je     69 <perf_unwind_native+0x69> */
	X86_SIM_X86_JCC(X86_CC_E, 0x64, 0x69, x86_l_69);
x86_l_66:
	/* 0x66: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_69:
	/* 0x69: mov    eax,DWORD PTR [rbp+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_6f:
	/* 0x6f: cmp    rax,0x7f */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 127ULL);
x86_l_73:
	/* 0x73: jb     aa <perf_unwind_native+0xaa> */
	X86_SIM_X86_JCC(X86_CC_B, 0x73, 0xaa, x86_l_aa);
x86_l_75:
	/* 0x75: mov    DWORD PTR [rsp+0x80],0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813890ULL);
x86_l_80:
	/* 0x80: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_87:
	/* 0x87: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8f:
	/* 0x8f: call   94 <perf_unwind_native+0x94> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_94:
	/* 0x94: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_97:
	/* 0x97: je     9c <perf_unwind_native+0x9c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x97, 0x9c, x86_l_9c);
x86_l_99:
	/* 0x99: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_9c:
	/* 0x9c: mov    r15d,0x2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 2ULL);
x86_l_a2:
	/* 0xa2: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_a5:
	/* 0xa5: jmp    5fd <perf_unwind_native+0x5fd> */
	X86_SIM_X86_JMP(0xa5, 0x5fd, x86_l_5fd);
x86_l_aa:
	/* 0xaa: movzx  ecx,BYTE PTR [rbp+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_b1:
	/* 0xb1: mov    rdx,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_b8:
	/* 0xb8: mov    rsi,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_bf:
	/* 0xbf: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_c2:
	/* 0xc2: mov    DWORD PTR [rbp+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_c8:
	/* 0xc8: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_cc:
	/* 0xcc: mov    QWORD PTR [rbp+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_d4:
	/* 0xd4: mov    QWORD PTR [rbp+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_dc:
	/* 0xdc: mov    BYTE PTR [rbp+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_e4:
	/* 0xe4: mov    BYTE PTR [rbp+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_eb:
	/* 0xeb: mov    DWORD PTR [rbp+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_f6:
	/* 0xf6: mov    WORD PTR [rbp+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_100:
	/* 0x100: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_108:
	/* 0x108: mov    rax,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_10f:
	/* 0x10f: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_114:
	/* 0x114: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_119:
	/* 0x119: mov    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709486080ULL);
x86_l_120:
	/* 0x120: and    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 3864ULL);
x86_l_127:
	/* 0x127: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_12c:
	/* 0x12c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_133:
	/* 0x133: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_138:
	/* 0x138: call   13d <perf_unwind_native+0x13d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_13d:
	/* 0x13d: mov    edx,0xfa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4000ULL);
x86_l_142:
	/* 0x142: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_147:
	/* 0x147: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a:
	/* 0x14a: je     5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14a, 0x5ef, x86_l_5ef);
x86_l_150:
	/* 0x150: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_153:
	/* 0x153: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_157:
	/* 0x157: add    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_15a:
	/* 0x15a: cmp    ax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 15ULL);
x86_l_15e:
	/* 0x15e: ja     5d9 <perf_unwind_native+0x5d9> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15e, 0x5d9, x86_l_5d9);
x86_l_164:
	/* 0x164: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_167:
	/* Image-bound immutable capability table; private base is dead. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 3) {
	case 0ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas)); break;
	case 8ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas)); break;
	case 16ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas)); break;
	case 24ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas)); break;
	case 32ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas)); break;
	case 40ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas)); break;
	case 48ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas)); break;
	case 56ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas)); break;
	case 64ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas)); break;
	case 72ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas)); break;
	case 80ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas)); break;
	case 88ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas)); break;
	case 96ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas)); break;
	case 104ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas)); break;
	case 112ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas)); break;
	case 120ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas)); break;
	default: X86_SIM_L_ARCHITECTURAL_FAULT();
	}
x86_l_172:
	/* 0x172: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_177:
	/* 0x177: call   17c <perf_unwind_native+0x17c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17c:
	/* 0x17c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17f:
	/* 0x17f: je     5e5 <perf_unwind_native+0x5e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17f, 0x5e5, x86_l_5e5);
x86_l_185:
	/* 0x185: mov    rdi,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_188:
	/* 0x188: mov    QWORD PTR [rsp+0x48],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_18d:
	/* 0x18d: mov    r13d,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_190:
	/* 0x190: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_195:
	/* 0x195: mov    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_19c:
	/* 0x19c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1a1:
	/* 0x1a1: movzx  ebx,WORD PTR [r14+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_1a6:
	/* 0x1a6: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1a8:
	/* 0x1a8: je     6bf <perf_unwind_native+0x6bf> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a8, 0x6bf, x86_l_6bf);
x86_l_1ae:
	/* 0x1ae: add    ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RBX, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1b1:
	/* 0x1b1: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1b5:
	/* 0x1b5: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1b7:
	/* 0x1b7: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bb:
	/* 0x1bb: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c0:
	/* 0x1c0: mov    QWORD PTR [rsp+0x18],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1c5:
	/* 0x1c5: call   1ca <perf_unwind_native+0x1ca> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1ca:
	/* 0x1ca: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cd:
	/* 0x1cd: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cd, 0x2949, x86_l_2949);
x86_l_1d3:
	/* 0x1d3: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d7:
	/* 0x1d7: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1db:
	/* 0x1db: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e0:
	/* 0x1e0: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e3:
	/* 0x1e3: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1e7:
	/* 0x1e7: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1ea:
	/* 0x1ea: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_1ed:
	/* 0x1ed: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ed, 0x6af, x86_l_6af);
x86_l_1f3:
	/* 0x1f3: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_1f7:
	/* 0x1f7: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1f9:
	/* 0x1f9: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1fd:
	/* 0x1fd: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_202:
	/* 0x202: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_207:
	/* 0x207: call   20c <perf_unwind_native+0x20c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_20c:
	/* 0x20c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_20f:
	/* 0x20f: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20f, 0x2949, x86_l_2949);
x86_l_215:
	/* 0x215: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_219:
	/* 0x219: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_21d:
	/* 0x21d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_222:
	/* 0x222: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_225:
	/* 0x225: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_229:
	/* 0x229: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_22c:
	/* 0x22c: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_22f:
	/* 0x22f: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x22f, 0x6af, x86_l_6af);
x86_l_235:
	/* 0x235: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_239:
	/* 0x239: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_23b:
	/* 0x23b: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23f:
	/* 0x23f: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_244:
	/* 0x244: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_249:
	/* 0x249: call   24e <perf_unwind_native+0x24e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24e:
	/* 0x24e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_251:
	/* 0x251: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x251, 0x2949, x86_l_2949);
x86_l_257:
	/* 0x257: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25b:
	/* 0x25b: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25f:
	/* 0x25f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_264:
	/* 0x264: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_267:
	/* 0x267: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_26b:
	/* 0x26b: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_26e:
	/* 0x26e: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_271:
	/* 0x271: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x271, 0x6af, x86_l_6af);
x86_l_277:
	/* 0x277: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_27b:
	/* 0x27b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_27d:
	/* 0x27d: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_281:
	/* 0x281: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_286:
	/* 0x286: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_28b:
	/* 0x28b: call   290 <perf_unwind_native+0x290> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_290:
	/* 0x290: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_293:
	/* 0x293: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x293, 0x2949, x86_l_2949);
x86_l_299:
	/* 0x299: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_29d:
	/* 0x29d: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2a1:
	/* 0x2a1: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a6:
	/* 0x2a6: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a9:
	/* 0x2a9: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2ad:
	/* 0x2ad: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2b0:
	/* 0x2b0: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2b3:
	/* 0x2b3: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2b3, 0x6af, x86_l_6af);
x86_l_2b9:
	/* 0x2b9: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2bd:
	/* 0x2bd: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2bf:
	/* 0x2bf: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c3:
	/* 0x2c3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2c8:
	/* 0x2c8: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2cd:
	/* 0x2cd: call   2d2 <perf_unwind_native+0x2d2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d2:
	/* 0x2d2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d5:
	/* 0x2d5: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d5, 0x2949, x86_l_2949);
x86_l_2db:
	/* 0x2db: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2df:
	/* 0x2df: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2e3:
	/* 0x2e3: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2e8:
	/* 0x2e8: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2eb:
	/* 0x2eb: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2ef:
	/* 0x2ef: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2f2:
	/* 0x2f2: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_2f5:
	/* 0x2f5: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2f5, 0x6af, x86_l_6af);
x86_l_2fb:
	/* 0x2fb: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_2ff:
	/* 0x2ff: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_301:
	/* 0x301: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_305:
	/* 0x305: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_30a:
	/* 0x30a: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_30f:
	/* 0x30f: call   314 <perf_unwind_native+0x314> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_314:
	/* 0x314: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_317:
	/* 0x317: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x317, 0x2949, x86_l_2949);
x86_l_31d:
	/* 0x31d: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_321:
	/* 0x321: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_325:
	/* 0x325: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_32a:
	/* 0x32a: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32d:
	/* 0x32d: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_331:
	/* 0x331: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_334:
	/* 0x334: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_337:
	/* 0x337: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x337, 0x6af, x86_l_6af);
x86_l_33d:
	/* 0x33d: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_341:
	/* 0x341: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_343:
	/* 0x343: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_347:
	/* 0x347: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_34c:
	/* 0x34c: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_351:
	/* 0x351: call   356 <perf_unwind_native+0x356> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_356:
	/* 0x356: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_359:
	/* 0x359: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x359, 0x2949, x86_l_2949);
x86_l_35f:
	/* 0x35f: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_363:
	/* 0x363: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_367:
	/* 0x367: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_36c:
	/* 0x36c: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_36f:
	/* 0x36f: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_373:
	/* 0x373: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_376:
	/* 0x376: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_379:
	/* 0x379: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x379, 0x6af, x86_l_6af);
x86_l_37f:
	/* 0x37f: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_383:
	/* 0x383: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_385:
	/* 0x385: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_389:
	/* 0x389: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_38e:
	/* 0x38e: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_393:
	/* 0x393: call   398 <perf_unwind_native+0x398> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_398:
	/* 0x398: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_39b:
	/* 0x39b: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39b, 0x2949, x86_l_2949);
x86_l_3a1:
	/* 0x3a1: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3a5:
	/* 0x3a5: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3a9:
	/* 0x3a9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3ae:
	/* 0x3ae: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3b1:
	/* 0x3b1: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_3b5:
	/* 0x3b5: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_3b8:
	/* 0x3b8: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_3bb:
	/* 0x3bb: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3bb, 0x6af, x86_l_6af);
x86_l_3c1:
	/* 0x3c1: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_3c5:
	/* 0x3c5: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_3c7:
	/* 0x3c7: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3cb:
	/* 0x3cb: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3d0:
	/* 0x3d0: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3d5:
	/* 0x3d5: call   3da <perf_unwind_native+0x3da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_3da:
	/* 0x3da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_3dd:
	/* 0x3dd: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3dd, 0x2949, x86_l_2949);
x86_l_3e3:
	/* 0x3e3: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_3e7:
	/* 0x3e7: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_3eb:
	/* 0x3eb: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3f0:
	/* 0x3f0: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3f3:
	/* 0x3f3: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_3f7:
	/* 0x3f7: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_3fa:
	/* 0x3fa: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_3fd:
	/* 0x3fd: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x3fd, 0x6af, x86_l_6af);
x86_l_403:
	/* 0x403: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_407:
	/* 0x407: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_409:
	/* 0x409: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_40d:
	/* 0x40d: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_412:
	/* 0x412: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_417:
	/* 0x417: call   41c <perf_unwind_native+0x41c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_41c:
	/* 0x41c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_41f:
	/* 0x41f: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x41f, 0x2949, x86_l_2949);
x86_l_425:
	/* 0x425: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_429:
	/* 0x429: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_42d:
	/* 0x42d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_432:
	/* 0x432: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_435:
	/* 0x435: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_439:
	/* 0x439: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_43c:
	/* 0x43c: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_43f:
	/* 0x43f: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x43f, 0x6af, x86_l_6af);
x86_l_445:
	/* 0x445: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_449:
	/* 0x449: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_44b:
	/* 0x44b: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_44f:
	/* 0x44f: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_454:
	/* 0x454: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_459:
	/* 0x459: call   45e <perf_unwind_native+0x45e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_45e:
	/* 0x45e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_461:
	/* 0x461: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x461, 0x2949, x86_l_2949);
x86_l_467:
	/* 0x467: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_46b:
	/* 0x46b: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_46f:
	/* 0x46f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_474:
	/* 0x474: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_477:
	/* 0x477: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_47b:
	/* 0x47b: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_47e:
	/* 0x47e: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_481:
	/* 0x481: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x481, 0x6af, x86_l_6af);
x86_l_487:
	/* 0x487: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_48b:
	/* 0x48b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_48d:
	/* 0x48d: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_491:
	/* 0x491: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_496:
	/* 0x496: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_49b:
	/* 0x49b: call   4a0 <perf_unwind_native+0x4a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4a0:
	/* 0x4a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4a3:
	/* 0x4a3: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4a3, 0x2949, x86_l_2949);
x86_l_4a9:
	/* 0x4a9: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4ad:
	/* 0x4ad: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4b1:
	/* 0x4b1: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4b6:
	/* 0x4b6: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4b9:
	/* 0x4b9: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_4bd:
	/* 0x4bd: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_4c0:
	/* 0x4c0: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_4c3:
	/* 0x4c3: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x4c3, 0x6af, x86_l_6af);
x86_l_4c9:
	/* 0x4c9: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_4cd:
	/* 0x4cd: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_4cf:
	/* 0x4cf: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4d3:
	/* 0x4d3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4d8:
	/* 0x4d8: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_4dd:
	/* 0x4dd: call   4e2 <perf_unwind_native+0x4e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_4e2:
	/* 0x4e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_4e5:
	/* 0x4e5: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x4e5, 0x2949, x86_l_2949);
x86_l_4eb:
	/* 0x4eb: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_4ef:
	/* 0x4ef: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_4f3:
	/* 0x4f3: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_4f8:
	/* 0x4f8: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_4fb:
	/* 0x4fb: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_4ff:
	/* 0x4ff: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_502:
	/* 0x502: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_505:
	/* 0x505: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x505, 0x6af, x86_l_6af);
x86_l_50b:
	/* 0x50b: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_50f:
	/* 0x50f: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_511:
	/* 0x511: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_515:
	/* 0x515: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_51a:
	/* 0x51a: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_51f:
	/* 0x51f: call   524 <perf_unwind_native+0x524> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_524:
	/* 0x524: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_527:
	/* 0x527: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x527, 0x2949, x86_l_2949);
x86_l_52d:
	/* 0x52d: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_531:
	/* 0x531: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_535:
	/* 0x535: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_53a:
	/* 0x53a: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_53d:
	/* 0x53d: cmova  r13d,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_541:
	/* 0x541: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_544:
	/* 0x544: cmp    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_547:
	/* 0x547: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x547, 0x6af, x86_l_6af);
x86_l_54d:
	/* 0x54d: lea    eax,[rbx+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_551:
	/* 0x551: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_553:
	/* 0x553: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_557:
	/* 0x557: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_55c:
	/* 0x55c: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_561:
	/* 0x561: call   566 <perf_unwind_native+0x566> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_566:
	/* 0x566: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_569:
	/* 0x569: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x569, 0x2949, x86_l_2949);
x86_l_56f:
	/* 0x56f: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_573:
	/* 0x573: lea    r15d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_577:
	/* 0x577: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_57c:
	/* 0x57c: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_57f:
	/* 0x57f: cmova  r15d,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_583:
	/* 0x583: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_586:
	/* 0x586: cmp    r15d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_589:
	/* 0x589: jae    6af <perf_unwind_native+0x6af> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x589, 0x6af, x86_l_6af);
x86_l_58f:
	/* 0x58f: lea    eax,[r15+rbx*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_RBX, 0), 0ULL);
x86_l_593:
	/* 0x593: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_595:
	/* 0x595: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_599:
	/* 0x599: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_59e:
	/* 0x59e: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5a3:
	/* 0x5a3: call   5a8 <perf_unwind_native+0x5a8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_5a8:
	/* 0x5a8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_5ab:
	/* 0x5ab: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x5ab, 0x2949, x86_l_2949);
x86_l_5b1:
	/* 0x5b1: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_5b5:
	/* 0x5b5: lea    edx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_5b8:
	/* 0x5b8: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_5bd:
	/* 0x5bd: cmp    WORD PTR [rax],si */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_5c0:
	/* 0x5c0: cmova  edx,r15d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_R15, X86_WIDTH_32, X86_CC_A, 0);
x86_l_5c4:
	/* 0x5c4: cmova  ebx,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_5c7:
	/* 0x5c7: cmp    edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_5c9:
	/* 0x5c9: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_5ce:
	/* 0x5ce: jae    6b4 <perf_unwind_native+0x6b4> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x5ce, 0x6b4, x86_l_6b4);
x86_l_5d4:
	/* 0x5d4: jmp    2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JMP(0x5d4, 0x2949, x86_l_2949);
x86_l_5d9:
	/* 0x5d9: mov    ecx,0x33 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_5de:
	/* 0x5de: mov    edx,0xfa1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4001ULL);
x86_l_5e3:
	/* 0x5e3: jmp    5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JMP(0x5e3, 0x5ef, x86_l_5ef);
x86_l_5e5:
	/* 0x5e5: mov    ecx,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_5ea:
	/* 0x5ea: mov    edx,0xfa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4002ULL);
x86_l_5ef:
	/* 0x5ef: mov    DWORD PTR [rbp+0xf28],ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3880ULL);
x86_l_5f5:
	/* 0x5f5: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_5f7:
	/* 0x5f7: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_5fa:
	/* 0x5fa: mov    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_5fd:
	/* 0x5fd: mov    DWORD PTR [rbp+0xf2c],r15d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3884ULL);
x86_l_604:
	/* 0x604: mov    DWORD PTR [rsp+0x80],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813888ULL);
x86_l_60f:
	/* 0x60f: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)per_cpu_records));
x86_l_616:
	/* 0x616: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_61e:
	/* 0x61e: call   623 <perf_unwind_native+0x623> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_623:
	/* 0x623: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_626:
	/* 0x626: je     67f <perf_unwind_native+0x67f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x626, 0x67f, x86_l_67f);
x86_l_628:
	/* 0x628: movzx  ecx,BYTE PTR [rax+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_62f:
	/* 0x62f: cmp    cl,0x1d */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, 0, 29ULL);
x86_l_632:
	/* 0x632: jb     675 <perf_unwind_native+0x675> */
	X86_SIM_X86_JCC(X86_CC_B, 0x632, 0x675, x86_l_675);
x86_l_634:
	/* 0x634: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_637:
	/* 0x637: mov    DWORD PTR [rax+0xf2c],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16681652977669ULL);
x86_l_641:
	/* 0x641: mov    DWORD PTR [rsp+0x80],0x44 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813956ULL);
x86_l_64c:
	/* 0x64c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_653:
	/* 0x653: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_65b:
	/* 0x65b: call   660 <perf_unwind_native+0x660> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_660:
	/* 0x660: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_663:
	/* 0x663: je     668 <perf_unwind_native+0x668> */
	X86_SIM_X86_JCC(X86_CC_E, 0x663, 0x668, x86_l_668);
x86_l_665:
	/* 0x665: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_668:
	/* 0x668: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_66b:
	/* 0x66b: movzx  ecx,BYTE PTR [rbx+0x1384] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 4996ULL);
x86_l_672:
	/* 0x672: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_675:
	/* 0x675: inc    cl */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_ALU_INC, 1);
x86_l_677:
	/* 0x677: mov    BYTE PTR [rax+0x1384],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RAX, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 4996ULL);
x86_l_67d:
	/* 0x67d: jmp    682 <perf_unwind_native+0x682> */
	X86_SIM_X86_JMP(0x67d, 0x682, x86_l_682);
x86_l_67f:
	/* 0x67f: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_682:
	/* 0x682: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)perf_progs));
x86_l_689:
	/* 0x689: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_68c:
	/* 0x68c: mov    edx,r12d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_32, 0, 0);
x86_l_68f:
	/* 0x68f: call   694 <perf_unwind_native+0x694> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_tail_call);
x86_l_694:
	/* 0x694: mov    eax,0xffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 4294967295ULL);
x86_l_699:
	/* 0x699: add    rsp,0x118 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 280ULL);
x86_l_6a0:
	/* 0x6a0: pop    rbx */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBX, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6a1:
	/* 0x6a1: pop    r12 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6a3:
	/* 0x6a3: pop    r13 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6a5:
	/* 0x6a5: pop    r14 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6a7:
	/* 0x6a7: pop    r15 */
	X86_SIM_RUN_OP(X86_OP_POP, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6a9:
	/* 0x6a9: pop    rbp */
	X86_SIM_RUN_OP(X86_OP_POP, X86_RBP, X86_REG_NONE, X86_WIDTH_64, 0, 0);
x86_l_6aa:
	/* 0x6aa: jmp    2dc2 <section:SectionIndex(15):.rodata:table_380+0x2a42> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_6af:
	/* 0x6af: mov    rdi,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6b4:
	/* 0x6b4: mov    r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_6b7:
	/* 0x6b7: test   ebx,ebx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_32, 0, 0);
x86_l_6b9:
	/* 0x6b9: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6b9, 0x2949, x86_l_2949);
x86_l_6bf:
	/* 0x6bf: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_6c2:
	/* 0x6c2: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_6c7:
	/* 0x6c7: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_6cc:
	/* 0x6cc: call   6d1 <perf_unwind_native+0x6d1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_6d1:
	/* 0x6d1: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_6d6:
	/* 0x6d6: mov    edx,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_6db:
	/* 0x6db: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_6de:
	/* 0x6de: je     2953 <perf_unwind_native+0x2953> */
	X86_SIM_X86_JCC(X86_CC_E, 0x6de, 0x2953, x86_l_2953);
x86_l_6e4:
	/* 0x6e4: movzx  ecx,WORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_6e9:
	/* 0x6e9: movzx  edx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_6ec:
	/* 0x6ec: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_6ee:
	/* 0x6ee: mov    edx,DWORD PTR [rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_6f2:
	/* 0x6f2: cmp    edx,DWORD PTR [r14] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_6f5:
	/* 0x6f5: lea    r15d,[rcx+0x10000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R15, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 65536ULL);
x86_l_6fc:
	/* 0x6fc: cmovae r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R15, X86_RCX, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_700:
	/* 0x700: movzx  eax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_704:
	/* 0x704: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_708:
	/* 0x708: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_70d:
	/* 0x70d: je     1e2b <perf_unwind_native+0x1e2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x70d, 0x1e2b, x86_l_1e2b);
x86_l_713:
	/* 0x713: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_718:
	/* 0x718: jne    73f <perf_unwind_native+0x73f> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x718, 0x73f, x86_l_73f);
x86_l_71a:
	/* 0x71a: mov    DWORD PTR [rsp+0x4],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869191ULL);
x86_l_722:
	/* 0x722: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_729:
	/* 0x729: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_72e:
	/* 0x72e: call   733 <perf_unwind_native+0x733> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_733:
	/* 0x733: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_736:
	/* 0x736: je     73b <perf_unwind_native+0x73b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x736, 0x73b, x86_l_73b);
x86_l_738:
	/* 0x738: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_73b:
	/* 0x73b: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_73f:
	/* 0x73f: lea    rbx,[r12+0xed0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_747:
	/* 0x747: lea    rcx,[r12+0xee0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RCX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_74f:
	/* 0x74f: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_754:
	/* 0x754: lea    rdx,[r12+0xed8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_75c:
	/* 0x75c: lea    r14,[r12+0xee8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R14, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_764:
	/* 0x764: lea    rsi,[r12+0xef0] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_76c:
	/* 0x76c: lea    rdi,[r12+0xef8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_774:
	/* 0x774: add    r12,0xf08 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 3848ULL);
x86_l_77b:
	/* 0x77b: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_77e:
	/* 0x77e: js     7e2 <perf_unwind_native+0x7e2> */
	X86_SIM_X86_JCC(X86_CC_S, 0x77e, 0x7e2, x86_l_7e2);
x86_l_780:
	/* 0x780: mov    QWORD PTR [rsp+0x60],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_785:
	/* 0x785: mov    QWORD PTR [rsp+0x68],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_78a:
	/* 0x78a: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_78f:
	/* 0x78f: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_794:
	/* 0x794: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_79b:
	/* 0x79b: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_7a0:
	/* 0x7a0: call   7a5 <perf_unwind_native+0x7a5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_7a5:
	/* 0x7a5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_7a8:
	/* 0x7a8: je     2963 <perf_unwind_native+0x2963> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7a8, 0x2963, x86_l_2963);
x86_l_7ae:
	/* 0x7ae: mov    QWORD PTR [rsp+0x58],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_7b3:
	/* 0x7b3: mov    r14d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_7b7:
	/* 0x7b7: movzx  edx,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_7bb:
	/* 0x7bb: test   edx,edx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_7bd:
	/* 0x7bd: je     80e <perf_unwind_native+0x80e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7bd, 0x80e, x86_l_80e);
x86_l_7bf:
	/* 0x7bf: mov    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_7c1:
	/* 0x7c1: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_7c4:
	/* 0x7c4: cmp    r15d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R15, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_7c7:
	/* 0x7c7: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_7cc:
	/* 0x7cc: jl     813 <perf_unwind_native+0x813> */
	X86_SIM_X86_JCC(X86_CC_L, 0x7cc, 0x813, x86_l_813);
x86_l_7ce:
	/* 0x7ce: xor    esi,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_7d0:
	/* 0x7d0: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_7d2:
	/* 0x7d2: setns  sil */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_7d6:
	/* 0x7d6: shl    esi,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_7d9:
	/* 0x7d9: add    r14d,esi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RSI, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_7dc:
	/* 0x7dc: add    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_7e0:
	/* 0x7e0: jmp    813 <perf_unwind_native+0x813> */
	X86_SIM_X86_JMP(0x7e0, 0x813, x86_l_813);
x86_l_7e2:
	/* 0x7e2: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_7e7:
	/* 0x7e7: dec    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_7e9:
	/* 0x7e9: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_7ec:
	/* 0x7ec: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_7f1:
	/* 0x7f1: ja     9de <perf_unwind_native+0x9de> */
	X86_SIM_X86_JCC(X86_CC_A, 0x7f1, 0x9de, x86_l_9de);
x86_l_7f7:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x807ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x9adULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x890ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x94aULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_805:
	/* 0x805: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x807ULL: goto x86_l_807;
			case 0x890ULL: goto x86_l_890;
			case 0x94aULL: goto x86_l_94a;
			case 0x9adULL: goto x86_l_9ad;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_807:
	/* 0x807: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_809:
	/* 0x809: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0x809, 0x5f7, x86_l_5f7);
x86_l_80e:
	/* 0x80e: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_813:
	/* 0x813: mov    r13,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_818:
	/* 0x818: movzx  edx,BYTE PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_81b:
	/* 0x81b: mov    esi,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_81e:
	/* 0x81e: and    esi,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_821:
	/* 0x821: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_823:
	/* 0x823: cmovns esi,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RSI, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_827:
	/* 0x827: mov    edi,edx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RDX, X86_WIDTH_32, 0, 0);
x86_l_829:
	/* 0x829: and    edi,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_82c:
	/* 0x82c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_82f:
	/* 0x82f: dec    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_831:
	/* 0x831: cmp    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_834:
	/* 0x834: ja     a46 <perf_unwind_native+0xa46> */
	X86_SIM_X86_JCC(X86_CC_A, 0x834, 0xa46, x86_l_a46);
x86_l_83a:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDI) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x856ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x84eULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x853ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xa46ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0x9e8ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_848:
	/* 0x848: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_84b:
	/* 0x84b: jmp    r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x84eULL: goto x86_l_84e;
			case 0x853ULL: goto x86_l_853;
			case 0x856ULL: goto x86_l_856;
			case 0x9e8ULL: goto x86_l_9e8;
			case 0xa46ULL: goto x86_l_a46;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_84e:
	/* 0x84e: mov    rdi,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_853:
	/* 0x853: mov    r12,QWORD PTR [rdi] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_856:
	/* 0x856: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_859:
	/* 0x859: movsxd r12,esi */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RSI, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_85c:
	/* 0x85c: add    r12,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_85f:
	/* 0x85f: test   dl,dl */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_8, 0, 0);
x86_l_861:
	/* 0x861: jns    a46 <perf_unwind_native+0xa46> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x861, 0xa46, x86_l_a46);
x86_l_867:
	/* 0x867: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_86a:
	/* 0x86a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_86d:
	/* 0x86d: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_872:
	/* 0x872: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_877:
	/* 0x877: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_87a:
	/* 0x87a: call   87f <perf_unwind_native+0x87f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_87f:
	/* 0x87f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_882:
	/* 0x882: je     a12 <perf_unwind_native+0xa12> */
	X86_SIM_X86_JCC(X86_CC_E, 0x882, 0xa12, x86_l_a12);
x86_l_888:
	/* 0x888: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_88b:
	/* 0x88b: jmp    a22 <perf_unwind_native+0xa22> */
	X86_SIM_X86_JMP(0x88b, 0xa22, x86_l_a22);
x86_l_890:
	/* 0x890: mov    QWORD PTR [rsp+0x60],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_895:
	/* 0x895: mov    QWORD PTR [rsp+0x68],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_89a:
	/* 0x89a: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_89f:
	/* 0x89f: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_8a4:
	/* 0x8a4: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_8a7:
	/* 0x8a7: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_8ab:
	/* 0x8ab: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_8b3:
	/* 0x8b3: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_8b8:
	/* 0x8b8: call   8bd <perf_unwind_native+0x8bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_8bd:
	/* 0x8bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_8c0:
	/* 0x8c0: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x8c0, 0xb4d, x86_l_b4d);
x86_l_8c6:
	/* 0x8c6: mov    rax,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_8ce:
	/* 0x8ce: mov    QWORD PTR [rbp+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_8d5:
	/* 0x8d5: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_8dd:
	/* 0x8dd: mov    QWORD PTR [rbp+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_8e4:
	/* 0x8e4: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_8ec:
	/* 0x8ec: mov    QWORD PTR [rbp+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_8f3:
	/* 0x8f3: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_8fb:
	/* 0x8fb: mov    QWORD PTR [rbp+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_902:
	/* 0x902: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_90a:
	/* 0x90a: mov    QWORD PTR [rbp+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_911:
	/* 0x911: mov    rax,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_919:
	/* 0x919: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_920:
	/* 0x920: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_928:
	/* 0x928: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_92f:
	/* 0x92f: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_937:
	/* 0x937: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_93e:
	/* 0x93e: mov    BYTE PTR [rbp+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_945:
	/* 0x945: jmp    b8b <perf_unwind_native+0xb8b> */
	X86_SIM_X86_JMP(0x945, 0xb8b, x86_l_b8b);
x86_l_94a:
	/* 0x94a: mov    QWORD PTR [rsp+0x60],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_94f:
	/* 0x94f: mov    QWORD PTR [rsp+0x68],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_954:
	/* 0x954: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_959:
	/* 0x959: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_95e:
	/* 0x95e: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_963:
	/* 0x963: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_966:
	/* 0x966: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_96b:
	/* 0x96b: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_970:
	/* 0x970: call   975 <perf_unwind_native+0x975> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_975:
	/* 0x975: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_978:
	/* 0x978: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x978, 0xb4d, x86_l_b4d);
x86_l_97e:
	/* 0x97e: mov    rax,QWORD PTR [rbp+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_985:
	/* 0x985: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_989:
	/* 0x989: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_990:
	/* 0x990: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_995:
	/* 0x995: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_99c:
	/* 0x99c: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_9a1:
	/* 0x9a1: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_9a8:
	/* 0x9a8: jmp    b84 <perf_unwind_native+0xb84> */
	X86_SIM_X86_JMP(0x9a8, 0xb84, x86_l_b84);
x86_l_9ad:
	/* 0x9ad: mov    QWORD PTR [rsp+0x60],rdi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_9b2:
	/* 0x9b2: mov    QWORD PTR [rsp+0x68],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_9b7:
	/* 0x9b7: mov    QWORD PTR [rsp+0x18],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_9bc:
	/* 0x9bc: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_9c1:
	/* 0x9c1: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9c4:
	/* 0x9c4: mov    ecx,DWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9c6:
	/* 0x9c6: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_9c9:
	/* 0x9c9: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9cb:
	/* 0x9cb: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_9ce:
	/* 0x9ce: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_9d1:
	/* 0x9d1: lea    r12,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_9d5:
	/* 0x9d5: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_9d9:
	/* 0x9d9: jmp    b31 <perf_unwind_native+0xb31> */
	X86_SIM_X86_JMP(0x9d9, 0xb31, x86_l_b31);
x86_l_9de:
	/* 0x9de: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_9e3:
	/* 0x9e3: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0x9e3, 0x5f7, x86_l_5f7);
x86_l_9e8:
	/* 0x9e8: mov    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_9eb:
	/* 0x9eb: and    edx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_9ee:
	/* 0x9ee: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_9f1:
	/* 0x9f1: cmp    edx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_9f4:
	/* 0x9f4: ja     a46 <perf_unwind_native+0xa46> */
	X86_SIM_X86_JCC(X86_CC_A, 0x9f4, 0xa46, x86_l_a46);
x86_l_9f6:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa39ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa0bULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa2fULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa46ULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0xa36ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_a04:
	/* 0xa04: mov    rdx,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_a09:
	/* 0xa09: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0xa0bULL: goto x86_l_a0b;
			case 0xa2fULL: goto x86_l_a2f;
			case 0xa36ULL: goto x86_l_a36;
			case 0xa39ULL: goto x86_l_a39;
			case 0xa46ULL: goto x86_l_a46;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a0b:
	/* 0xa0b: mov    rdx,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_a10:
	/* 0xa10: jmp    a39 <perf_unwind_native+0xa39> */
	X86_SIM_X86_JMP(0xa10, 0xa39, x86_l_a39);
x86_l_a12:
	/* 0xa12: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_a16:
	/* 0xa16: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_a1a:
	/* 0xa1a: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_a1f:
	/* 0xa1f: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_a22:
	/* 0xa22: mov    rcx,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_a27:
	/* 0xa27: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a2a:
	/* 0xa2a: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_a2d:
	/* 0xa2d: jmp    a46 <perf_unwind_native+0xa46> */
	X86_SIM_X86_JMP(0xa2d, 0xa46, x86_l_a46);
x86_l_a2f:
	/* 0xa2f: mov    rdx,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_a34:
	/* 0xa34: jmp    a39 <perf_unwind_native+0xa39> */
	X86_SIM_X86_JMP(0xa34, 0xa39, x86_l_a39);
x86_l_a36:
	/* 0xa36: mov    rdx,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_a39:
	/* 0xa39: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_a3c:
	/* 0xa3c: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_a40:
	/* 0xa40: movsxd r12,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_a43:
	/* 0xa43: add    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RDX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_a46:
	/* 0xa46: movzx  esi,BYTE PTR [rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_a4a:
	/* 0xa4a: mov    r14d,DWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_a4e:
	/* 0xa4e: mov    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_a51:
	/* 0xa51: and    edx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_a54:
	/* 0xa54: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_a57:
	/* 0xa57: cmovns edx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_a5b:
	/* 0xa5b: mov    edi,esi */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RSI, X86_WIDTH_32, 0, 0);
x86_l_a5d:
	/* 0xa5d: and    edi,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_a60:
	/* 0xa60: dec    edi */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_a62:
	/* 0xa62: cmp    edi,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_a65:
	/* 0xa65: ja     ab4 <perf_unwind_native+0xab4> */
	X86_SIM_X86_JCC(X86_CC_A, 0xa65, 0xab4, x86_l_ab4);
x86_l_a67:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDI) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xa86ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xa7eULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xa83ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xab4ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_R9, 0xabbULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_a75:
	/* 0xa75: mov    r8,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R8, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_a78:
	/* 0xa78: mov    rdi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_a7b:
	/* 0xa7b: jmp    r9 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R9);
		switch (X86_SIM_L_REG_TAG(X86_R9)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0xa7eULL: goto x86_l_a7e;
			case 0xa83ULL: goto x86_l_a83;
			case 0xa86ULL: goto x86_l_a86;
			case 0xab4ULL: goto x86_l_ab4;
			case 0xabbULL: goto x86_l_abb;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_a7e:
	/* 0xa7e: mov    r8,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R8, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_a83:
	/* 0xa83: mov    rdi,QWORD PTR [r8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a86:
	/* 0xa86: movsxd rdx,edx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RDX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_a89:
	/* 0xa89: add    rdx,rdi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_a8c:
	/* 0xa8c: test   sil,sil */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_8, 0, 0);
x86_l_a8f:
	/* 0xa8f: jns    b0b <perf_unwind_native+0xb0b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0xa8f, 0xb0b, x86_l_b0b);
x86_l_a91:
	/* 0xa91: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_a96:
	/* 0xa96: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_a9b:
	/* 0xa9b: mov    r15,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R15, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a9e:
	/* 0xa9e: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aa1:
	/* 0xaa1: call   aa6 <perf_unwind_native+0xaa6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_aa6:
	/* 0xaa6: mov    rcx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_aa9:
	/* 0xaa9: mov    rax,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_aac:
	/* 0xaac: mov    rbx,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_aaf:
	/* 0xaaf: test   rcx,rcx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_ab2:
	/* 0xab2: je     ae2 <perf_unwind_native+0xae2> */
	X86_SIM_X86_JCC(X86_CC_E, 0xab2, 0xae2, x86_l_ae2);
x86_l_ab4:
	/* 0xab4: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ab9:
	/* 0xab9: jmp    b24 <perf_unwind_native+0xb24> */
	X86_SIM_X86_JMP(0xab9, 0xb24, x86_l_b24);
x86_l_abb:
	/* 0xabb: mov    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_abe:
	/* 0xabe: and    edx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_ac1:
	/* 0xac1: cmp    edx,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_ac4:
	/* 0xac4: ja     ab4 <perf_unwind_native+0xab4> */
	X86_SIM_X86_JCC(X86_CC_A, 0xac4, 0xab4, x86_l_ab4);
x86_l_ac6:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xafeULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xadbULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xaf4ULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xab4ULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0xafbULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_ad4:
	/* 0xad4: mov    rsi,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_ad9:
	/* 0xad9: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0xab4ULL: goto x86_l_ab4;
			case 0xadbULL: goto x86_l_adb;
			case 0xaf4ULL: goto x86_l_af4;
			case 0xafbULL: goto x86_l_afb;
			case 0xafeULL: goto x86_l_afe;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_adb:
	/* 0xadb: mov    rsi,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_ae0:
	/* 0xae0: jmp    afe <perf_unwind_native+0xafe> */
	X86_SIM_X86_JMP(0xae0, 0xafe, x86_l_afe);
x86_l_ae2:
	/* 0xae2: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_ae6:
	/* 0xae6: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_aea:
	/* 0xaea: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_aef:
	/* 0xaef: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_af2:
	/* 0xaf2: jmp    b0b <perf_unwind_native+0xb0b> */
	X86_SIM_X86_JMP(0xaf2, 0xb0b, x86_l_b0b);
x86_l_af4:
	/* 0xaf4: mov    rsi,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_af9:
	/* 0xaf9: jmp    afe <perf_unwind_native+0xafe> */
	X86_SIM_X86_JMP(0xaf9, 0xafe, x86_l_afe);
x86_l_afb:
	/* 0xafb: mov    rsi,rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_afe:
	/* 0xafe: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_b01:
	/* 0xb01: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_b05:
	/* 0xb05: movsxd rdx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_b08:
	/* 0xb08: add    rdx,QWORD PTR [rsi] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RSI, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_b0b:
	/* 0xb0b: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_b0e:
	/* 0xb0e: mov    r14,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_b13:
	/* 0xb13: je     b24 <perf_unwind_native+0xb24> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb13, 0xb24, x86_l_b24);
x86_l_b15:
	/* 0xb15: mov    rdi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_b18:
	/* 0xb18: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b1d:
	/* 0xb1d: call   b22 <perf_unwind_native+0xb22> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b22:
	/* 0xb22: jmp    b31 <perf_unwind_native+0xb31> */
	X86_SIM_X86_JMP(0xb22, 0xb31, x86_l_b31);
x86_l_b24:
	/* 0xb24: cmp    BYTE PTR [rax],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_b27:
	/* 0xb27: jne    b31 <perf_unwind_native+0xb31> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xb27, 0xb31, x86_l_b31);
x86_l_b29:
	/* 0xb29: mov    QWORD PTR [r13+0x0],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b31:
	/* 0xb31: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_b34:
	/* 0xb34: je     b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb34, 0xb4d, x86_l_b4d);
x86_l_b36:
	/* 0xb36: lea    rdx,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_b3b:
	/* 0xb3b: mov    rdi,rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDI, X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_b3e:
	/* 0xb3e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_b43:
	/* 0xb43: call   b48 <perf_unwind_native+0xb48> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_b48:
	/* 0xb48: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b4b:
	/* 0xb4b: je     b7d <perf_unwind_native+0xb7d> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb4b, 0xb7d, x86_l_b7d);
x86_l_b4d:
	/* 0xb4d: mov    DWORD PTR [rsp+0x30],0xe */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430222ULL);
x86_l_b55:
	/* 0xb55: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_b5c:
	/* 0xb5c: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b61:
	/* 0xb61: call   b66 <perf_unwind_native+0xb66> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_b66:
	/* 0xb66: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_b69:
	/* 0xb69: je     b6e <perf_unwind_native+0xb6e> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb69, 0xb6e, x86_l_b6e);
x86_l_b6b:
	/* 0xb6b: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_b6e:
	/* 0xb6e: mov    ecx,0xfa7 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4007ULL);
x86_l_b73:
	/* 0xb73: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_b78:
	/* 0xb78: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0xb78, 0x5f7, x86_l_5f7);
x86_l_b7d:
	/* 0xb7d: mov    QWORD PTR [rbp+0xed8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_b84:
	/* 0xb84: mov    BYTE PTR [rbp+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_b8b:
	/* 0xb8b: mov    QWORD PTR [rsp+0x58],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_b90:
	/* 0xb90: mov    DWORD PTR [rsp+0x30],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430214ULL);
x86_l_b98:
	/* 0xb98: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_b9f:
	/* 0xb9f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ba4:
	/* 0xba4: call   ba9 <perf_unwind_native+0xba9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ba9:
	/* 0xba9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_bac:
	/* 0xbac: je     bb1 <perf_unwind_native+0xbb1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbac, 0xbb1, x86_l_bb1);
x86_l_bae:
	/* 0xbae: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_bb1:
	/* 0xbb1: mov    r15,QWORD PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R15, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bb4:
	/* 0xbb4: test   r15,r15 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bb7:
	/* 0xbb7: je     2d93 <perf_unwind_native+0x2d93> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb7, 0x2d93, x86_l_2d93);
x86_l_bbd:
	/* 0xbbd: mov    rax,r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R15, X86_WIDTH_64, 0, 0);
x86_l_bc0:
	/* 0xbc0: shr    rax,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_bc4:
	/* 0xbc4: je     bdb <perf_unwind_native+0xbdb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbc4, 0xbdb, x86_l_bdb);
x86_l_bc6:
	/* 0xbc6: mov    DWORD PTR [rbp+0xf28],0xb */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108491ULL);
x86_l_bd0:
	/* 0xbd0: mov    r15d,0xfab */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4011ULL);
x86_l_bd6:
	/* 0xbd6: jmp    2da3 <perf_unwind_native+0x2da3> */
	X86_SIM_X86_JMP(0xbd6, 0x2da3, x86_l_2da3);
x86_l_bdb:
	/* 0xbdb: cmp    r15,0xfff */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_64, 0, 4095ULL);
x86_l_be2:
	/* 0xbe2: ja     bf9 <perf_unwind_native+0xbf9> */
	X86_SIM_X86_JCC(X86_CC_A, 0xbe2, 0xbf9, x86_l_bf9);
x86_l_be4:
	/* 0xbe4: mov    DWORD PTR [rbp+0xf28],0x31 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108529ULL);
x86_l_bee:
	/* 0xbee: mov    r15d,0xfae */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4014ULL);
x86_l_bf4:
	/* 0xbf4: jmp    2da3 <perf_unwind_native+0x2da3> */
	X86_SIM_X86_JMP(0xbf4, 0x2da3, x86_l_2da3);
x86_l_bf9:
	/* 0xbf9: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bfc:
	/* 0xbfc: mov    DWORD PTR [rsp+0x80],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813984ULL);
x86_l_c07:
	/* 0xc07: movbe  DWORD PTR [rsp+0x84],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 132ULL);
x86_l_c10:
	/* 0xc10: movbe  QWORD PTR [rsp+0x88],r15 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 136ULL);
x86_l_c1a:
	/* 0xc1a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_c21:
	/* 0xc21: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c29:
	/* 0xc29: call   c2e <perf_unwind_native+0xc2e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c2e:
	/* 0xc2e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c31:
	/* 0xc31: je     2db0 <perf_unwind_native+0x2db0> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc31, 0x2db0, x86_l_2db0);
x86_l_c37:
	/* 0xc37: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_c41:
	/* 0xc41: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_c45:
	/* 0xc45: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_c48:
	/* 0xc48: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_c4b:
	/* 0xc4b: mov    QWORD PTR [rbp+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_c52:
	/* 0xc52: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_c56:
	/* 0xc56: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c59:
	/* 0xc59: mov    QWORD PTR [rbp+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_c60:
	/* 0xc60: sub    r15,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_c63:
	/* 0xc63: mov    QWORD PTR [rbp+0xf18],r15 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_c6a:
	/* 0xc6a: cmp    r12,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_c6e:
	/* 0xc6e: jne    ce6 <perf_unwind_native+0xce6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xc6e, 0xce6, x86_l_ce6);
x86_l_c70:
	/* 0xc70: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c78:
	/* 0xc78: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_c7f:
	/* 0xc7f: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_c87:
	/* 0xc87: call   c8c <perf_unwind_native+0xc8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_c8c:
	/* 0xc8c: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_c92:
	/* 0xc92: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c95:
	/* 0xc95: je     ce6 <perf_unwind_native+0xce6> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc95, 0xce6, x86_l_ce6);
x86_l_c97:
	/* 0xc97: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_c9a:
	/* 0xc9a: cmp    QWORD PTR [rax],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_c9d:
	/* 0xc9d: ja     ca5 <perf_unwind_native+0xca5> */
	X86_SIM_X86_JCC(X86_CC_A, 0xc9d, 0xca5, x86_l_ca5);
x86_l_c9f:
	/* 0xc9f: cmp    QWORD PTR [r14+0x8],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ca3:
	/* 0xca3: jae    cb1 <perf_unwind_native+0xcb1> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xca3, 0xcb1, x86_l_cb1);
x86_l_ca5:
	/* 0xca5: cmp    QWORD PTR [r14+0x10],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_ca9:
	/* 0xca9: ja     ce6 <perf_unwind_native+0xce6> */
	X86_SIM_X86_JCC(X86_CC_A, 0xca9, 0xce6, x86_l_ce6);
x86_l_cab:
	/* 0xcab: cmp    QWORD PTR [r14+0x18],r15 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_caf:
	/* 0xcaf: jb     ce6 <perf_unwind_native+0xce6> */
	X86_SIM_X86_JCC(X86_CC_B, 0xcaf, 0xce6, x86_l_ce6);
x86_l_cb1:
	/* 0xcb1: mov    eax,DWORD PTR [rbp+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_cb7:
	/* 0xcb7: mov    ecx,DWORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_cbb:
	/* 0xcbb: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_cbe:
	/* 0xcbe: jb     ce6 <perf_unwind_native+0xce6> */
	X86_SIM_X86_JCC(X86_CC_B, 0xcbe, 0xce6, x86_l_ce6);
x86_l_cc0:
	/* 0xcc0: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_cc8:
	/* 0xcc8: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_ccf:
	/* 0xccf: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cd4:
	/* 0xcd4: call   cd9 <perf_unwind_native+0xcd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_cd9:
	/* 0xcd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_cdc:
	/* 0xcdc: je     ce1 <perf_unwind_native+0xce1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcdc, 0xce1, x86_l_ce1);
x86_l_cde:
	/* 0xcde: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_ce1:
	/* 0xce1: movzx  r12d,WORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_ce6:
	/* 0xce6: xor    r15d,r15d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_ce9:
	/* 0xce9: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_ced:
	/* 0xced: jne    2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xced, 0x2da6, x86_l_2da6);
x86_l_cf3:
	/* 0xcf3: mov    QWORD PTR [rsp+0x70],rbx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_cf8:
	/* 0xcf8: mov    DWORD PTR [rsp+0x80],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813893ULL);
x86_l_d03:
	/* 0xd03: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_d0a:
	/* 0xd0a: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_d12:
	/* 0xd12: call   d17 <perf_unwind_native+0xd17> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_d17:
	/* 0xd17: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_d1a:
	/* 0xd1a: je     d1f <perf_unwind_native+0xd1f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd1a, 0xd1f, x86_l_d1f);
x86_l_d1c:
	/* 0xd1c: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_d1f:
	/* 0xd1f: mov    eax,DWORD PTR [rbp+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_d25:
	/* 0xd25: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_d29:
	/* 0xd29: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_d2e:
	/* 0xd2e: ja     75 <perf_unwind_native+0x75> */
	X86_SIM_X86_JCC(X86_CC_A, 0xd2e, 0x75, x86_l_75);
x86_l_d34:
	/* 0xd34: movzx  ecx,BYTE PTR [rbp+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_d3b:
	/* 0xd3b: mov    rdx,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_d42:
	/* 0xd42: mov    rsi,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_d49:
	/* 0xd49: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_d4c:
	/* 0xd4c: mov    DWORD PTR [rbp+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_d52:
	/* 0xd52: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_d56:
	/* 0xd56: mov    QWORD PTR [rbp+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_d5e:
	/* 0xd5e: mov    QWORD PTR [rbp+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_d66:
	/* 0xd66: mov    BYTE PTR [rbp+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_d6e:
	/* 0xd6e: mov    BYTE PTR [rbp+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_d75:
	/* 0xd75: mov    DWORD PTR [rbp+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_d80:
	/* 0xd80: mov    WORD PTR [rbp+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_d8a:
	/* 0xd8a: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_d92:
	/* 0xd92: mov    rax,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_d99:
	/* 0xd99: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_d9e:
	/* 0xd9e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_da3:
	/* 0xda3: mov    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709486080ULL);
x86_l_daa:
	/* 0xdaa: and    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 3864ULL);
x86_l_db1:
	/* 0xdb1: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_db6:
	/* 0xdb6: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_dbd:
	/* 0xdbd: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_dc2:
	/* 0xdc2: call   dc7 <perf_unwind_native+0xdc7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_dc7:
	/* 0xdc7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dca:
	/* 0xdca: je     1e3a <perf_unwind_native+0x1e3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdca, 0x1e3a, x86_l_1e3a);
x86_l_dd0:
	/* 0xdd0: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_dd3:
	/* 0xdd3: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_dd7:
	/* 0xdd7: add    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_dda:
	/* 0xdda: cmp    ax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 15ULL);
x86_l_dde:
	/* 0xdde: ja     1e4e <perf_unwind_native+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0xdde, 0x1e4e, x86_l_1e4e);
x86_l_de4:
	/* 0xde4: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_de7:
	/* Image-bound immutable capability table; private base is dead. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 3) {
	case 0ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas)); break;
	case 8ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas)); break;
	case 16ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas)); break;
	case 24ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas)); break;
	case 32ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas)); break;
	case 40ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas)); break;
	case 48ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas)); break;
	case 56ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas)); break;
	case 64ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas)); break;
	case 72ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas)); break;
	case 80ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas)); break;
	case 88ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas)); break;
	case 96ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas)); break;
	case 104ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas)); break;
	case 112ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas)); break;
	case 120ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas)); break;
	default: X86_SIM_L_ARCHITECTURAL_FAULT();
	}
x86_l_df2:
	/* 0xdf2: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_df7:
	/* 0xdf7: call   dfc <perf_unwind_native+0xdfc> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_dfc:
	/* 0xdfc: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e01:
	/* 0xe01: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e04:
	/* 0xe04: je     1e62 <perf_unwind_native+0x1e62> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe04, 0x1e62, x86_l_1e62);
x86_l_e0a:
	/* 0xe0a: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e0e:
	/* 0xe0e: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_e13:
	/* 0xe13: mov    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_e1a:
	/* 0xe1a: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e1f:
	/* 0xe1f: movzx  r14d,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_e25:
	/* 0xe25: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_e28:
	/* 0xe28: je     125f <perf_unwind_native+0x125f> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe28, 0x125f, x86_l_125f);
x86_l_e2e:
	/* 0xe2e: add    r14d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_e31:
	/* 0xe31: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_e35:
	/* 0xe35: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_e37:
	/* 0xe37: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e3b:
	/* 0xe3b: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e40:
	/* 0xe40: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e45:
	/* 0xe45: call   e4a <perf_unwind_native+0xe4a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e4a:
	/* 0xe4a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e4d:
	/* 0xe4d: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe4d, 0x2949, x86_l_2949);
x86_l_e53:
	/* 0xe53: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e57:
	/* 0xe57: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_e5a:
	/* 0xe5a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_e5f:
	/* 0xe5f: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_e62:
	/* 0xe62: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_e66:
	/* 0xe66: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_e6a:
	/* 0xe6a: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_e6d:
	/* 0xe6d: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xe6d, 0x1253, x86_l_1253);
x86_l_e73:
	/* 0xe73: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_e77:
	/* 0xe77: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_e79:
	/* 0xe79: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e7d:
	/* 0xe7d: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e82:
	/* 0xe82: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_e87:
	/* 0xe87: call   e8c <perf_unwind_native+0xe8c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_e8c:
	/* 0xe8c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_e8f:
	/* 0xe8f: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe8f, 0x2949, x86_l_2949);
x86_l_e95:
	/* 0xe95: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_e99:
	/* 0xe99: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_e9d:
	/* 0xe9d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ea2:
	/* 0xea2: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ea5:
	/* 0xea5: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_ea9:
	/* 0xea9: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_ead:
	/* 0xead: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_eb0:
	/* 0xeb0: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xeb0, 0x1253, x86_l_1253);
x86_l_eb6:
	/* 0xeb6: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_eba:
	/* 0xeba: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_ebc:
	/* 0xebc: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ec0:
	/* 0xec0: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_ec5:
	/* 0xec5: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_eca:
	/* 0xeca: call   ecf <perf_unwind_native+0xecf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_ecf:
	/* 0xecf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_ed2:
	/* 0xed2: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed2, 0x2949, x86_l_2949);
x86_l_ed8:
	/* 0xed8: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_edc:
	/* 0xedc: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_edf:
	/* 0xedf: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee4:
	/* 0xee4: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ee7:
	/* 0xee7: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_eeb:
	/* 0xeeb: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_eef:
	/* 0xeef: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_ef2:
	/* 0xef2: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xef2, 0x1253, x86_l_1253);
x86_l_ef8:
	/* 0xef8: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_efc:
	/* 0xefc: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_efe:
	/* 0xefe: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f02:
	/* 0xf02: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f07:
	/* 0xf07: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f0c:
	/* 0xf0c: call   f11 <perf_unwind_native+0xf11> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f11:
	/* 0xf11: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f14:
	/* 0xf14: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf14, 0x2949, x86_l_2949);
x86_l_f1a:
	/* 0xf1a: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f1e:
	/* 0xf1e: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_f22:
	/* 0xf22: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f27:
	/* 0xf27: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f2a:
	/* 0xf2a: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_f2e:
	/* 0xf2e: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_f32:
	/* 0xf32: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_f35:
	/* 0xf35: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf35, 0x1253, x86_l_1253);
x86_l_f3b:
	/* 0xf3b: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_f3f:
	/* 0xf3f: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_f41:
	/* 0xf41: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f45:
	/* 0xf45: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f4a:
	/* 0xf4a: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f4f:
	/* 0xf4f: call   f54 <perf_unwind_native+0xf54> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f54:
	/* 0xf54: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f57:
	/* 0xf57: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf57, 0x2949, x86_l_2949);
x86_l_f5d:
	/* 0xf5d: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f61:
	/* 0xf61: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_f64:
	/* 0xf64: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_f69:
	/* 0xf69: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_f6c:
	/* 0xf6c: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_f70:
	/* 0xf70: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_f74:
	/* 0xf74: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_f77:
	/* 0xf77: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xf77, 0x1253, x86_l_1253);
x86_l_f7d:
	/* 0xf7d: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_f81:
	/* 0xf81: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_f83:
	/* 0xf83: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f87:
	/* 0xf87: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_f8c:
	/* 0xf8c: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_f91:
	/* 0xf91: call   f96 <perf_unwind_native+0xf96> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_f96:
	/* 0xf96: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_f99:
	/* 0xf99: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xf99, 0x2949, x86_l_2949);
x86_l_f9f:
	/* 0xf9f: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fa3:
	/* 0xfa3: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_fa7:
	/* 0xfa7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fac:
	/* 0xfac: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_faf:
	/* 0xfaf: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_fb3:
	/* 0xfb3: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_fb7:
	/* 0xfb7: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_fba:
	/* 0xfba: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xfba, 0x1253, x86_l_1253);
x86_l_fc0:
	/* 0xfc0: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_fc4:
	/* 0xfc4: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_fc6:
	/* 0xfc6: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fca:
	/* 0xfca: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fcf:
	/* 0xfcf: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_fd4:
	/* 0xfd4: call   fd9 <perf_unwind_native+0xfd9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_fd9:
	/* 0xfd9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_fdc:
	/* 0xfdc: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfdc, 0x2949, x86_l_2949);
x86_l_fe2:
	/* 0xfe2: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_fe6:
	/* 0xfe6: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_fe9:
	/* 0xfe9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fee:
	/* 0xfee: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ff1:
	/* 0xff1: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_ff5:
	/* 0xff5: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_ff9:
	/* 0xff9: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_ffc:
	/* 0xffc: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xffc, 0x1253, x86_l_1253);
x86_l_1002:
	/* 0x1002: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1006:
	/* 0x1006: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1008:
	/* 0x1008: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_100c:
	/* 0x100c: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1011:
	/* 0x1011: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1016:
	/* 0x1016: call   101b <perf_unwind_native+0x101b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_101b:
	/* 0x101b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_101e:
	/* 0x101e: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x101e, 0x2949, x86_l_2949);
x86_l_1024:
	/* 0x1024: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1028:
	/* 0x1028: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_102c:
	/* 0x102c: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1031:
	/* 0x1031: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1034:
	/* 0x1034: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1038:
	/* 0x1038: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_103c:
	/* 0x103c: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_103f:
	/* 0x103f: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x103f, 0x1253, x86_l_1253);
x86_l_1045:
	/* 0x1045: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1049:
	/* 0x1049: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_104b:
	/* 0x104b: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_104f:
	/* 0x104f: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1054:
	/* 0x1054: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1059:
	/* 0x1059: call   105e <perf_unwind_native+0x105e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_105e:
	/* 0x105e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1061:
	/* 0x1061: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1061, 0x2949, x86_l_2949);
x86_l_1067:
	/* 0x1067: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_106b:
	/* 0x106b: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_106e:
	/* 0x106e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1073:
	/* 0x1073: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1076:
	/* 0x1076: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_107a:
	/* 0x107a: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_107e:
	/* 0x107e: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1081:
	/* 0x1081: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1081, 0x1253, x86_l_1253);
x86_l_1087:
	/* 0x1087: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_108b:
	/* 0x108b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_108d:
	/* 0x108d: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1091:
	/* 0x1091: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1096:
	/* 0x1096: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_109b:
	/* 0x109b: call   10a0 <perf_unwind_native+0x10a0> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10a0:
	/* 0x10a0: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10a3:
	/* 0x10a3: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10a3, 0x2949, x86_l_2949);
x86_l_10a9:
	/* 0x10a9: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10ad:
	/* 0x10ad: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_10b1:
	/* 0x10b1: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10b6:
	/* 0x10b6: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10b9:
	/* 0x10b9: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_10bd:
	/* 0x10bd: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_10c1:
	/* 0x10c1: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_10c4:
	/* 0x10c4: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x10c4, 0x1253, x86_l_1253);
x86_l_10ca:
	/* 0x10ca: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_10ce:
	/* 0x10ce: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_10d0:
	/* 0x10d0: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10d4:
	/* 0x10d4: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10d9:
	/* 0x10d9: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_10de:
	/* 0x10de: call   10e3 <perf_unwind_native+0x10e3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_10e3:
	/* 0x10e3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_10e6:
	/* 0x10e6: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10e6, 0x2949, x86_l_2949);
x86_l_10ec:
	/* 0x10ec: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_10f0:
	/* 0x10f0: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_10f3:
	/* 0x10f3: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10f8:
	/* 0x10f8: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10fb:
	/* 0x10fb: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_10ff:
	/* 0x10ff: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1103:
	/* 0x1103: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1106:
	/* 0x1106: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1106, 0x1253, x86_l_1253);
x86_l_110c:
	/* 0x110c: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1110:
	/* 0x1110: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1112:
	/* 0x1112: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1116:
	/* 0x1116: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_111b:
	/* 0x111b: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1120:
	/* 0x1120: call   1125 <perf_unwind_native+0x1125> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1125:
	/* 0x1125: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1128:
	/* 0x1128: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1128, 0x2949, x86_l_2949);
x86_l_112e:
	/* 0x112e: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1132:
	/* 0x1132: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1136:
	/* 0x1136: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_113b:
	/* 0x113b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_113e:
	/* 0x113e: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1142:
	/* 0x1142: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1146:
	/* 0x1146: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1149:
	/* 0x1149: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1149, 0x1253, x86_l_1253);
x86_l_114f:
	/* 0x114f: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1153:
	/* 0x1153: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1155:
	/* 0x1155: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1159:
	/* 0x1159: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_115e:
	/* 0x115e: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1163:
	/* 0x1163: call   1168 <perf_unwind_native+0x1168> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1168:
	/* 0x1168: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_116b:
	/* 0x116b: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x116b, 0x2949, x86_l_2949);
x86_l_1171:
	/* 0x1171: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1175:
	/* 0x1175: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1178:
	/* 0x1178: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_117d:
	/* 0x117d: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1180:
	/* 0x1180: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1184:
	/* 0x1184: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1188:
	/* 0x1188: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_118b:
	/* 0x118b: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x118b, 0x1253, x86_l_1253);
x86_l_1191:
	/* 0x1191: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1195:
	/* 0x1195: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1197:
	/* 0x1197: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_119b:
	/* 0x119b: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11a0:
	/* 0x11a0: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11a5:
	/* 0x11a5: call   11aa <perf_unwind_native+0x11aa> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11aa:
	/* 0x11aa: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11ad:
	/* 0x11ad: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11ad, 0x2949, x86_l_2949);
x86_l_11b3:
	/* 0x11b3: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11b7:
	/* 0x11b7: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_11bb:
	/* 0x11bb: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11c0:
	/* 0x11c0: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11c3:
	/* 0x11c3: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_11c7:
	/* 0x11c7: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_11cb:
	/* 0x11cb: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_11ce:
	/* 0x11ce: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x11ce, 0x1253, x86_l_1253);
x86_l_11d4:
	/* 0x11d4: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_11d8:
	/* 0x11d8: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_11da:
	/* 0x11da: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11de:
	/* 0x11de: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11e3:
	/* 0x11e3: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11e8:
	/* 0x11e8: call   11ed <perf_unwind_native+0x11ed> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_11ed:
	/* 0x11ed: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_11f0:
	/* 0x11f0: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11f0, 0x2949, x86_l_2949);
x86_l_11f6:
	/* 0x11f6: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_11fa:
	/* 0x11fa: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_11fd:
	/* 0x11fd: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1202:
	/* 0x1202: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1205:
	/* 0x1205: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1209:
	/* 0x1209: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_120d:
	/* 0x120d: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1210:
	/* 0x1210: jae    1253 <perf_unwind_native+0x1253> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1210, 0x1253, x86_l_1253);
x86_l_1212:
	/* 0x1212: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1216:
	/* 0x1216: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1218:
	/* 0x1218: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_121c:
	/* 0x121c: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1221:
	/* 0x1221: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1226:
	/* 0x1226: call   122b <perf_unwind_native+0x122b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_122b:
	/* 0x122b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_122e:
	/* 0x122e: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x122e, 0x2949, x86_l_2949);
x86_l_1234:
	/* 0x1234: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1238:
	/* 0x1238: lea    edx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_123b:
	/* 0x123b: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1240:
	/* 0x1240: cmp    WORD PTR [rax],si */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1243:
	/* 0x1243: cmova  edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1246:
	/* 0x1246: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_124a:
	/* 0x124a: cmp    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_124d:
	/* 0x124d: jb     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_B, 0x124d, 0x2949, x86_l_2949);
x86_l_1253:
	/* 0x1253: mov    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1256:
	/* 0x1256: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1259:
	/* 0x1259: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1259, 0x2949, x86_l_2949);
x86_l_125f:
	/* 0x125f: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1262:
	/* 0x1262: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1267:
	/* 0x1267: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_126c:
	/* 0x126c: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1271:
	/* 0x1271: call   1276 <perf_unwind_native+0x1276> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1276:
	/* 0x1276: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1279:
	/* 0x1279: je     1e76 <perf_unwind_native+0x1e76> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1279, 0x1e76, x86_l_1e76);
x86_l_127f:
	/* 0x127f: movzx  ecx,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_1284:
	/* 0x1284: movzx  edx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1287:
	/* 0x1287: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1289:
	/* 0x1289: mov    edx,DWORD PTR [rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_128d:
	/* 0x128d: cmp    edx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_1291:
	/* 0x1291: lea    r12d,[rcx+0x10000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 65536ULL);
x86_l_1298:
	/* 0x1298: cmovae r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R12, X86_RCX, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_129c:
	/* 0x129c: movzx  eax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_12a0:
	/* 0x12a0: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12a4:
	/* 0x12a4: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_12a9:
	/* 0x12a9: je     1e2b <perf_unwind_native+0x1e2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12a9, 0x1e2b, x86_l_1e2b);
x86_l_12af:
	/* 0x12af: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_12b4:
	/* 0x12b4: jne    12db <perf_unwind_native+0x12db> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x12b4, 0x12db, x86_l_12db);
x86_l_12b6:
	/* 0x12b6: mov    DWORD PTR [rsp+0x4],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869191ULL);
x86_l_12be:
	/* 0x12be: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_12c5:
	/* 0x12c5: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_12ca:
	/* 0x12ca: call   12cf <perf_unwind_native+0x12cf> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12cf:
	/* 0x12cf: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12d2:
	/* 0x12d2: je     12d7 <perf_unwind_native+0x12d7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12d2, 0x12d7, x86_l_12d7);
x86_l_12d4:
	/* 0x12d4: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_12d7:
	/* 0x12d7: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12db:
	/* 0x12db: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_12de:
	/* 0x12de: js     139b <perf_unwind_native+0x139b> */
	X86_SIM_X86_JCC(X86_CC_S, 0x12de, 0x139b, x86_l_139b);
x86_l_12e4:
	/* 0x12e4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_12eb:
	/* 0x12eb: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_12f0:
	/* 0x12f0: call   12f5 <perf_unwind_native+0x12f5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_12f5:
	/* 0x12f5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_12f8:
	/* 0x12f8: je     2963 <perf_unwind_native+0x2963> */
	X86_SIM_X86_JCC(X86_CC_E, 0x12f8, 0x2963, x86_l_2963);
x86_l_12fe:
	/* 0x12fe: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1301:
	/* 0x1301: mov    r14d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1305:
	/* 0x1305: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1309:
	/* 0x1309: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_130b:
	/* 0x130b: je     1328 <perf_unwind_native+0x1328> */
	X86_SIM_X86_JCC(X86_CC_E, 0x130b, 0x1328, x86_l_1328);
x86_l_130d:
	/* 0x130d: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_130f:
	/* 0x130f: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1312:
	/* 0x1312: cmp    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1315:
	/* 0x1315: jl     1328 <perf_unwind_native+0x1328> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1315, 0x1328, x86_l_1328);
x86_l_1317:
	/* 0x1317: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1319:
	/* 0x1319: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_131b:
	/* 0x131b: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_131e:
	/* 0x131e: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_1321:
	/* 0x1321: add    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1324:
	/* 0x1324: add    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_1328:
	/* 0x1328: movzx  eax,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_132b:
	/* 0x132b: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_132e:
	/* 0x132e: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1331:
	/* 0x1331: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1333:
	/* 0x1333: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_1337:
	/* 0x1337: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1339:
	/* 0x1339: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_133c:
	/* 0x133c: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_133f:
	/* 0x133f: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1341:
	/* 0x1341: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1344:
	/* 0x1344: ja     1531 <perf_unwind_native+0x1531> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1344, 0x1531, x86_l_1531);
x86_l_134a:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1367ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1364ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x135fULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1531ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x14dcULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1358:
	/* 0x1358: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_135d:
	/* 0x135d: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x135fULL: goto x86_l_135f;
			case 0x1364ULL: goto x86_l_1364;
			case 0x1367ULL: goto x86_l_1367;
			case 0x14dcULL: goto x86_l_14dc;
			case 0x1531ULL: goto x86_l_1531;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_135f:
	/* 0x135f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1364:
	/* 0x1364: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1367:
	/* 0x1367: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_136a:
	/* 0x136a: movsxd r12,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_136d:
	/* 0x136d: add    r12,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1370:
	/* 0x1370: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1372:
	/* 0x1372: jns    1531 <perf_unwind_native+0x1531> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1372, 0x1531, x86_l_1531);
x86_l_1378:
	/* 0x1378: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_137d:
	/* 0x137d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1382:
	/* 0x1382: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1385:
	/* 0x1385: call   138a <perf_unwind_native+0x138a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_138a:
	/* 0x138a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_138d:
	/* 0x138d: je     1506 <perf_unwind_native+0x1506> */
	X86_SIM_X86_JCC(X86_CC_E, 0x138d, 0x1506, x86_l_1506);
x86_l_1393:
	/* 0x1393: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1396:
	/* 0x1396: jmp    1531 <perf_unwind_native+0x1531> */
	X86_SIM_X86_JMP(0x1396, 0x1531, x86_l_1531);
x86_l_139b:
	/* 0x139b: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_13a0:
	/* 0x13a0: dec    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_13a2:
	/* 0x13a2: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_13a5:
	/* 0x13a5: ja     29db <perf_unwind_native+0x29db> */
	X86_SIM_X86_JCC(X86_CC_A, 0x13a5, 0x29db, x86_l_29db);
x86_l_13ab:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x807ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x13caULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x13e7ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x148dULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_13b9:
	/* 0x13b9: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_13be:
	/* 0x13be: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_13c3:
	/* 0x13c3: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_13c8:
	/* 0x13c8: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x807ULL: goto x86_l_807;
			case 0x13caULL: goto x86_l_13ca;
			case 0x13e7ULL: goto x86_l_13e7;
			case 0x148dULL: goto x86_l_148d;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13ca:
	/* 0x13ca: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13cd:
	/* 0x13cd: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13cf:
	/* 0x13cf: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_13d2:
	/* 0x13d2: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_13d4:
	/* 0x13d4: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_13d7:
	/* 0x13d7: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_13da:
	/* 0x13da: lea    r12,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_13de:
	/* 0x13de: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_13e2:
	/* 0x13e2: jmp    160c <perf_unwind_native+0x160c> */
	X86_SIM_X86_JMP(0x13e2, 0x160c, x86_l_160c);
x86_l_13e7:
	/* 0x13e7: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13ea:
	/* 0x13ea: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_13ee:
	/* 0x13ee: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_13f6:
	/* 0x13f6: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_13fb:
	/* 0x13fb: call   1400 <perf_unwind_native+0x1400> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1400:
	/* 0x1400: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1403:
	/* 0x1403: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1403, 0xb4d, x86_l_b4d);
x86_l_1409:
	/* 0x1409: mov    rax,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1411:
	/* 0x1411: mov    QWORD PTR [rbp+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_1418:
	/* 0x1418: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1420:
	/* 0x1420: mov    QWORD PTR [rbp+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_1427:
	/* 0x1427: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_142f:
	/* 0x142f: mov    QWORD PTR [rbp+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_1436:
	/* 0x1436: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_143e:
	/* 0x143e: mov    QWORD PTR [rbp+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_1445:
	/* 0x1445: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_144d:
	/* 0x144d: mov    QWORD PTR [rbp+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_1454:
	/* 0x1454: mov    rax,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_145c:
	/* 0x145c: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1463:
	/* 0x1463: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_146b:
	/* 0x146b: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1472:
	/* 0x1472: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_147a:
	/* 0x147a: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1481:
	/* 0x1481: mov    BYTE PTR [rbp+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_1488:
	/* 0x1488: jmp    1640 <perf_unwind_native+0x1640> */
	X86_SIM_X86_JMP(0x1488, 0x1640, x86_l_1640);
x86_l_148d:
	/* 0x148d: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1492:
	/* 0x1492: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1495:
	/* 0x1495: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_149a:
	/* 0x149a: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_149f:
	/* 0x149f: call   14a4 <perf_unwind_native+0x14a4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_14a4:
	/* 0x14a4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_14a7:
	/* 0x14a7: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14a7, 0xb4d, x86_l_b4d);
x86_l_14ad:
	/* 0x14ad: mov    rax,QWORD PTR [rbp+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_14b4:
	/* 0x14b4: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_14b8:
	/* 0x14b8: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_14bf:
	/* 0x14bf: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_14c4:
	/* 0x14c4: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_14cb:
	/* 0x14cb: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_14d0:
	/* 0x14d0: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_14d7:
	/* 0x14d7: jmp    1639 <perf_unwind_native+0x1639> */
	X86_SIM_X86_JMP(0x14d7, 0x1639, x86_l_1639);
x86_l_14dc:
	/* 0x14dc: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_14df:
	/* 0x14df: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_14e2:
	/* 0x14e2: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_14e5:
	/* 0x14e5: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_14e8:
	/* 0x14e8: ja     1531 <perf_unwind_native+0x1531> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14e8, 0x1531, x86_l_1531);
x86_l_14ea:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1524ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x14ffULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1518ULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1531ULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x151fULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_14f8:
	/* 0x14f8: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_14fd:
	/* 0x14fd: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x14ffULL: goto x86_l_14ff;
			case 0x1518ULL: goto x86_l_1518;
			case 0x151fULL: goto x86_l_151f;
			case 0x1524ULL: goto x86_l_1524;
			case 0x1531ULL: goto x86_l_1531;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14ff:
	/* 0x14ff: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1504:
	/* 0x1504: jmp    1524 <perf_unwind_native+0x1524> */
	X86_SIM_X86_JMP(0x1504, 0x1524, x86_l_1524);
x86_l_1506:
	/* 0x1506: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_150a:
	/* 0x150a: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_150e:
	/* 0x150e: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_1513:
	/* 0x1513: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1516:
	/* 0x1516: jmp    1531 <perf_unwind_native+0x1531> */
	X86_SIM_X86_JMP(0x1516, 0x1531, x86_l_1531);
x86_l_1518:
	/* 0x1518: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_151d:
	/* 0x151d: jmp    1524 <perf_unwind_native+0x1524> */
	X86_SIM_X86_JMP(0x151d, 0x1524, x86_l_1524);
x86_l_151f:
	/* 0x151f: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1524:
	/* 0x1524: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_1527:
	/* 0x1527: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_152b:
	/* 0x152b: movsxd r12,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_152e:
	/* 0x152e: add    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_1531:
	/* 0x1531: movzx  eax,BYTE PTR [rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_1535:
	/* 0x1535: mov    r14d,DWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1539:
	/* 0x1539: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_153c:
	/* 0x153c: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_153f:
	/* 0x153f: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1541:
	/* 0x1541: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_1545:
	/* 0x1545: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1547:
	/* 0x1547: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_154a:
	/* 0x154a: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_154c:
	/* 0x154c: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_154f:
	/* 0x154f: ja     15fb <perf_unwind_native+0x15fb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x154f, 0x15fb, x86_l_15fb);
x86_l_1555:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1575ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1572ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x156dULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x15fbULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x15a5ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1563:
	/* 0x1563: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1568:
	/* 0x1568: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_156b:
	/* 0x156b: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x156dULL: goto x86_l_156d;
			case 0x1572ULL: goto x86_l_1572;
			case 0x1575ULL: goto x86_l_1575;
			case 0x15a5ULL: goto x86_l_15a5;
			case 0x15fbULL: goto x86_l_15fb;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_156d:
	/* 0x156d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1572:
	/* 0x1572: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1575:
	/* 0x1575: movsxd rdx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_1578:
	/* 0x1578: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_157b:
	/* 0x157b: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_157d:
	/* 0x157d: jns    15e5 <perf_unwind_native+0x15e5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x157d, 0x15e5, x86_l_15e5);
x86_l_157f:
	/* 0x157f: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1584:
	/* 0x1584: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1589:
	/* 0x1589: call   158e <perf_unwind_native+0x158e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_158e:
	/* 0x158e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1591:
	/* 0x1591: jne    15fb <perf_unwind_native+0x15fb> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1591, 0x15fb, x86_l_15fb);
x86_l_1593:
	/* 0x1593: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1597:
	/* 0x1597: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_159b:
	/* 0x159b: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_15a0:
	/* 0x15a0: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_15a3:
	/* 0x15a3: jmp    15e5 <perf_unwind_native+0x15e5> */
	X86_SIM_X86_JMP(0x15a3, 0x15e5, x86_l_15e5);
x86_l_15a5:
	/* 0x15a5: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_15a8:
	/* 0x15a8: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_15ab:
	/* 0x15ab: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_15ae:
	/* 0x15ae: ja     15fb <perf_unwind_native+0x15fb> */
	X86_SIM_X86_JCC(X86_CC_A, 0x15ae, 0x15fb, x86_l_15fb);
x86_l_15b0:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15d8ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15c5ULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15ccULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15fbULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x15d3ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_15be:
	/* 0x15be: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_15c3:
	/* 0x15c3: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x15c5ULL: goto x86_l_15c5;
			case 0x15ccULL: goto x86_l_15cc;
			case 0x15d3ULL: goto x86_l_15d3;
			case 0x15d8ULL: goto x86_l_15d8;
			case 0x15fbULL: goto x86_l_15fb;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15c5:
	/* 0x15c5: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_15ca:
	/* 0x15ca: jmp    15d8 <perf_unwind_native+0x15d8> */
	X86_SIM_X86_JMP(0x15ca, 0x15d8, x86_l_15d8);
x86_l_15cc:
	/* 0x15cc: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_15d1:
	/* 0x15d1: jmp    15d8 <perf_unwind_native+0x15d8> */
	X86_SIM_X86_JMP(0x15d1, 0x15d8, x86_l_15d8);
x86_l_15d3:
	/* 0x15d3: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_15d8:
	/* 0x15d8: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_15db:
	/* 0x15db: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_15df:
	/* 0x15df: movsxd rdx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_15e2:
	/* 0x15e2: add    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_15e5:
	/* 0x15e5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_15e8:
	/* 0x15e8: je     15fb <perf_unwind_native+0x15fb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15e8, 0x15fb, x86_l_15fb);
x86_l_15ea:
	/* 0x15ea: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_15ef:
	/* 0x15ef: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_15f4:
	/* 0x15f4: call   15f9 <perf_unwind_native+0x15f9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_15f9:
	/* 0x15f9: jmp    160c <perf_unwind_native+0x160c> */
	X86_SIM_X86_JMP(0x15f9, 0x160c, x86_l_160c);
x86_l_15fb:
	/* 0x15fb: cmp    BYTE PTR [rbx],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_15fe:
	/* 0x15fe: jne    160c <perf_unwind_native+0x160c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x15fe, 0x160c, x86_l_160c);
x86_l_1600:
	/* 0x1600: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1605:
	/* 0x1605: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_160c:
	/* 0x160c: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_160f:
	/* 0x160f: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1614:
	/* 0x1614: je     b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1614, 0xb4d, x86_l_b4d);
x86_l_161a:
	/* 0x161a: lea    rdx,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_161f:
	/* 0x161f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1624:
	/* 0x1624: call   1629 <perf_unwind_native+0x1629> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1629:
	/* 0x1629: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_162c:
	/* 0x162c: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x162c, 0xb4d, x86_l_b4d);
x86_l_1632:
	/* 0x1632: mov    QWORD PTR [rbp+0xed8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1639:
	/* 0x1639: mov    BYTE PTR [rbp+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_1640:
	/* 0x1640: mov    DWORD PTR [rsp+0x30],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430214ULL);
x86_l_1648:
	/* 0x1648: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_164f:
	/* 0x164f: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1654:
	/* 0x1654: call   1659 <perf_unwind_native+0x1659> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1659:
	/* 0x1659: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_165c:
	/* 0x165c: je     1661 <perf_unwind_native+0x1661> */
	X86_SIM_X86_JCC(X86_CC_E, 0x165c, 0x1661, x86_l_1661);
x86_l_165e:
	/* 0x165e: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1661:
	/* 0x1661: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1666:
	/* 0x1666: mov    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1669:
	/* 0x1669: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_166c:
	/* 0x166c: je     2d93 <perf_unwind_native+0x2d93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x166c, 0x2d93, x86_l_2d93);
x86_l_1672:
	/* 0x1672: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_167c:
	/* 0x167c: cmp    r14,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_167f:
	/* 0x167f: ja     bc6 <perf_unwind_native+0xbc6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x167f, 0xbc6, x86_l_bc6);
x86_l_1685:
	/* 0x1685: cmp    r14,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_168c:
	/* 0x168c: jb     be4 <perf_unwind_native+0xbe4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x168c, 0xbe4, x86_l_be4);
x86_l_1692:
	/* 0x1692: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1695:
	/* 0x1695: mov    DWORD PTR [rsp+0x80],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813984ULL);
x86_l_16a0:
	/* 0x16a0: movbe  DWORD PTR [rsp+0x84],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 132ULL);
x86_l_16a9:
	/* 0x16a9: movbe  QWORD PTR [rsp+0x88],r14 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 136ULL);
x86_l_16b3:
	/* 0x16b3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_16ba:
	/* 0x16ba: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_16c2:
	/* 0x16c2: call   16c7 <perf_unwind_native+0x16c7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_16c7:
	/* 0x16c7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_16ca:
	/* 0x16ca: je     2db0 <perf_unwind_native+0x2db0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16ca, 0x2db0, x86_l_2db0);
x86_l_16d0:
	/* 0x16d0: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_16d4:
	/* 0x16d4: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_16d7:
	/* 0x16d7: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_16e1:
	/* 0x16e1: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_16e4:
	/* 0x16e4: mov    QWORD PTR [rbp+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_16eb:
	/* 0x16eb: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_16ef:
	/* 0x16ef: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16f2:
	/* 0x16f2: mov    QWORD PTR [rbp+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_16f9:
	/* 0x16f9: sub    r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_16fc:
	/* 0x16fc: mov    QWORD PTR [rbp+0xf18],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_1703:
	/* 0x1703: cmp    r12,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_1707:
	/* 0x1707: jne    177e <perf_unwind_native+0x177e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1707, 0x177e, x86_l_177e);
x86_l_1709:
	/* 0x1709: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1711:
	/* 0x1711: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_1718:
	/* 0x1718: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1720:
	/* 0x1720: call   1725 <perf_unwind_native+0x1725> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1725:
	/* 0x1725: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_172b:
	/* 0x172b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_172e:
	/* 0x172e: je     177e <perf_unwind_native+0x177e> */
	X86_SIM_X86_JCC(X86_CC_E, 0x172e, 0x177e, x86_l_177e);
x86_l_1730:
	/* 0x1730: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1733:
	/* 0x1733: cmp    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1736:
	/* 0x1736: ja     173e <perf_unwind_native+0x173e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1736, 0x173e, x86_l_173e);
x86_l_1738:
	/* 0x1738: cmp    QWORD PTR [rbx+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_173c:
	/* 0x173c: jae    174a <perf_unwind_native+0x174a> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x173c, 0x174a, x86_l_174a);
x86_l_173e:
	/* 0x173e: cmp    QWORD PTR [rbx+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1742:
	/* 0x1742: ja     177e <perf_unwind_native+0x177e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1742, 0x177e, x86_l_177e);
x86_l_1744:
	/* 0x1744: cmp    QWORD PTR [rbx+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1748:
	/* 0x1748: jb     177e <perf_unwind_native+0x177e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1748, 0x177e, x86_l_177e);
x86_l_174a:
	/* 0x174a: mov    eax,DWORD PTR [rbp+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_1750:
	/* 0x1750: mov    ecx,DWORD PTR [rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1753:
	/* 0x1753: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1756:
	/* 0x1756: jb     177e <perf_unwind_native+0x177e> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1756, 0x177e, x86_l_177e);
x86_l_1758:
	/* 0x1758: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_1760:
	/* 0x1760: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1767:
	/* 0x1767: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_176c:
	/* 0x176c: call   1771 <perf_unwind_native+0x1771> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1771:
	/* 0x1771: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1774:
	/* 0x1774: je     1779 <perf_unwind_native+0x1779> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1774, 0x1779, x86_l_1779);
x86_l_1776:
	/* 0x1776: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1779:
	/* 0x1779: movzx  r12d,WORD PTR [rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_177e:
	/* 0x177e: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_1782:
	/* 0x1782: jne    2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1782, 0x2da6, x86_l_2da6);
x86_l_1788:
	/* 0x1788: mov    DWORD PTR [rsp+0x80],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813893ULL);
x86_l_1793:
	/* 0x1793: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_179a:
	/* 0x179a: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_17a2:
	/* 0x17a2: call   17a7 <perf_unwind_native+0x17a7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_17a7:
	/* 0x17a7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_17aa:
	/* 0x17aa: je     17af <perf_unwind_native+0x17af> */
	X86_SIM_X86_JCC(X86_CC_E, 0x17aa, 0x17af, x86_l_17af);
x86_l_17ac:
	/* 0x17ac: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_17af:
	/* 0x17af: mov    eax,DWORD PTR [rbp+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_17b5:
	/* 0x17b5: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_17b9:
	/* 0x17b9: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_17be:
	/* 0x17be: ja     75 <perf_unwind_native+0x75> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17be, 0x75, x86_l_75);
x86_l_17c4:
	/* 0x17c4: movzx  ecx,BYTE PTR [rbp+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_17cb:
	/* 0x17cb: mov    rdx,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_17d2:
	/* 0x17d2: mov    rsi,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_17d9:
	/* 0x17d9: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_17dc:
	/* 0x17dc: mov    DWORD PTR [rbp+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_17e2:
	/* 0x17e2: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_17e6:
	/* 0x17e6: mov    QWORD PTR [rbp+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_17ee:
	/* 0x17ee: mov    QWORD PTR [rbp+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_17f6:
	/* 0x17f6: mov    BYTE PTR [rbp+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_17fe:
	/* 0x17fe: mov    BYTE PTR [rbp+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_1805:
	/* 0x1805: mov    DWORD PTR [rbp+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_1810:
	/* 0x1810: mov    WORD PTR [rbp+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_181a:
	/* 0x181a: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_1822:
	/* 0x1822: mov    rax,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_1829:
	/* 0x1829: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_182e:
	/* 0x182e: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1833:
	/* 0x1833: mov    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709486080ULL);
x86_l_183a:
	/* 0x183a: and    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 3864ULL);
x86_l_1841:
	/* 0x1841: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1846:
	/* 0x1846: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_184d:
	/* 0x184d: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1852:
	/* 0x1852: call   1857 <perf_unwind_native+0x1857> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1857:
	/* 0x1857: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_185a:
	/* 0x185a: je     1e3a <perf_unwind_native+0x1e3a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x185a, 0x1e3a, x86_l_1e3a);
x86_l_1860:
	/* 0x1860: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1863:
	/* 0x1863: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_1867:
	/* 0x1867: add    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_186a:
	/* 0x186a: cmp    ax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 15ULL);
x86_l_186e:
	/* 0x186e: ja     1e4e <perf_unwind_native+0x1e4e> */
	X86_SIM_X86_JCC(X86_CC_A, 0x186e, 0x1e4e, x86_l_1e4e);
x86_l_1874:
	/* 0x1874: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_1877:
	/* Image-bound immutable capability table; private base is dead. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 3) {
	case 0ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas)); break;
	case 8ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas)); break;
	case 16ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas)); break;
	case 24ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas)); break;
	case 32ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas)); break;
	case 40ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas)); break;
	case 48ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas)); break;
	case 56ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas)); break;
	case 64ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas)); break;
	case 72ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas)); break;
	case 80ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas)); break;
	case 88ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas)); break;
	case 96ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas)); break;
	case 104ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas)); break;
	case 112ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas)); break;
	case 120ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas)); break;
	default: X86_SIM_L_ARCHITECTURAL_FAULT();
	}
x86_l_1882:
	/* 0x1882: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1887:
	/* 0x1887: call   188c <perf_unwind_native+0x188c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_188c:
	/* 0x188c: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1891:
	/* 0x1891: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1894:
	/* 0x1894: je     1e62 <perf_unwind_native+0x1e62> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1894, 0x1e62, x86_l_1e62);
x86_l_189a:
	/* 0x189a: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_189e:
	/* 0x189e: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_18a3:
	/* 0x18a3: mov    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_18aa:
	/* 0x18aa: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18af:
	/* 0x18af: movzx  r14d,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_18b5:
	/* 0x18b5: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_18b8:
	/* 0x18b8: je     1cef <perf_unwind_native+0x1cef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18b8, 0x1cef, x86_l_1cef);
x86_l_18be:
	/* 0x18be: add    r14d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_18c1:
	/* 0x18c1: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_18c5:
	/* 0x18c5: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_18c7:
	/* 0x18c7: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18cb:
	/* 0x18cb: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18d0:
	/* 0x18d0: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18d5:
	/* 0x18d5: call   18da <perf_unwind_native+0x18da> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_18da:
	/* 0x18da: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_18dd:
	/* 0x18dd: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x18dd, 0x2949, x86_l_2949);
x86_l_18e3:
	/* 0x18e3: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_18e7:
	/* 0x18e7: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_18ea:
	/* 0x18ea: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_18ef:
	/* 0x18ef: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18f2:
	/* 0x18f2: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_18f6:
	/* 0x18f6: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_18fa:
	/* 0x18fa: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_18fd:
	/* 0x18fd: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x18fd, 0x1ce3, x86_l_1ce3);
x86_l_1903:
	/* 0x1903: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1907:
	/* 0x1907: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1909:
	/* 0x1909: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_190d:
	/* 0x190d: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1912:
	/* 0x1912: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1917:
	/* 0x1917: call   191c <perf_unwind_native+0x191c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_191c:
	/* 0x191c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_191f:
	/* 0x191f: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x191f, 0x2949, x86_l_2949);
x86_l_1925:
	/* 0x1925: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1929:
	/* 0x1929: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_192d:
	/* 0x192d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1932:
	/* 0x1932: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1935:
	/* 0x1935: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1939:
	/* 0x1939: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_193d:
	/* 0x193d: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1940:
	/* 0x1940: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1940, 0x1ce3, x86_l_1ce3);
x86_l_1946:
	/* 0x1946: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_194a:
	/* 0x194a: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_194c:
	/* 0x194c: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1950:
	/* 0x1950: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1955:
	/* 0x1955: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_195a:
	/* 0x195a: call   195f <perf_unwind_native+0x195f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_195f:
	/* 0x195f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1962:
	/* 0x1962: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1962, 0x2949, x86_l_2949);
x86_l_1968:
	/* 0x1968: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_196c:
	/* 0x196c: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_196f:
	/* 0x196f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1974:
	/* 0x1974: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1977:
	/* 0x1977: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_197b:
	/* 0x197b: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_197f:
	/* 0x197f: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1982:
	/* 0x1982: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1982, 0x1ce3, x86_l_1ce3);
x86_l_1988:
	/* 0x1988: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_198c:
	/* 0x198c: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_198e:
	/* 0x198e: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1992:
	/* 0x1992: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1997:
	/* 0x1997: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_199c:
	/* 0x199c: call   19a1 <perf_unwind_native+0x19a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_19a1:
	/* 0x19a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19a4:
	/* 0x19a4: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19a4, 0x2949, x86_l_2949);
x86_l_19aa:
	/* 0x19aa: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19ae:
	/* 0x19ae: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_19b2:
	/* 0x19b2: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19b7:
	/* 0x19b7: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19ba:
	/* 0x19ba: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_19be:
	/* 0x19be: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_19c2:
	/* 0x19c2: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_19c5:
	/* 0x19c5: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x19c5, 0x1ce3, x86_l_1ce3);
x86_l_19cb:
	/* 0x19cb: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_19cf:
	/* 0x19cf: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_19d1:
	/* 0x19d1: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19d5:
	/* 0x19d5: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19da:
	/* 0x19da: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_19df:
	/* 0x19df: call   19e4 <perf_unwind_native+0x19e4> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_19e4:
	/* 0x19e4: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_19e7:
	/* 0x19e7: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x19e7, 0x2949, x86_l_2949);
x86_l_19ed:
	/* 0x19ed: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_19f1:
	/* 0x19f1: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_19f4:
	/* 0x19f4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_19f9:
	/* 0x19f9: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_19fc:
	/* 0x19fc: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a00:
	/* 0x1a00: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a04:
	/* 0x1a04: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1a07:
	/* 0x1a07: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a07, 0x1ce3, x86_l_1ce3);
x86_l_1a0d:
	/* 0x1a0d: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1a11:
	/* 0x1a11: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1a13:
	/* 0x1a13: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a17:
	/* 0x1a17: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a1c:
	/* 0x1a1c: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a21:
	/* 0x1a21: call   1a26 <perf_unwind_native+0x1a26> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a26:
	/* 0x1a26: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a29:
	/* 0x1a29: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a29, 0x2949, x86_l_2949);
x86_l_1a2f:
	/* 0x1a2f: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a33:
	/* 0x1a33: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a37:
	/* 0x1a37: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a3c:
	/* 0x1a3c: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a3f:
	/* 0x1a3f: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a43:
	/* 0x1a43: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a47:
	/* 0x1a47: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1a4a:
	/* 0x1a4a: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a4a, 0x1ce3, x86_l_1ce3);
x86_l_1a50:
	/* 0x1a50: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1a54:
	/* 0x1a54: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1a56:
	/* 0x1a56: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a5a:
	/* 0x1a5a: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a5f:
	/* 0x1a5f: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a64:
	/* 0x1a64: call   1a69 <perf_unwind_native+0x1a69> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1a69:
	/* 0x1a69: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1a6c:
	/* 0x1a6c: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1a6c, 0x2949, x86_l_2949);
x86_l_1a72:
	/* 0x1a72: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a76:
	/* 0x1a76: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1a79:
	/* 0x1a79: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1a7e:
	/* 0x1a7e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1a81:
	/* 0x1a81: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a85:
	/* 0x1a85: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1a89:
	/* 0x1a89: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1a8c:
	/* 0x1a8c: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1a8c, 0x1ce3, x86_l_1ce3);
x86_l_1a92:
	/* 0x1a92: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1a96:
	/* 0x1a96: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1a98:
	/* 0x1a98: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1a9c:
	/* 0x1a9c: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1aa1:
	/* 0x1aa1: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1aa6:
	/* 0x1aa6: call   1aab <perf_unwind_native+0x1aab> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1aab:
	/* 0x1aab: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1aae:
	/* 0x1aae: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1aae, 0x2949, x86_l_2949);
x86_l_1ab4:
	/* 0x1ab4: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ab8:
	/* 0x1ab8: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1abc:
	/* 0x1abc: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1ac1:
	/* 0x1ac1: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ac4:
	/* 0x1ac4: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1ac8:
	/* 0x1ac8: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1acc:
	/* 0x1acc: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1acf:
	/* 0x1acf: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1acf, 0x1ce3, x86_l_1ce3);
x86_l_1ad5:
	/* 0x1ad5: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1ad9:
	/* 0x1ad9: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1adb:
	/* 0x1adb: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1adf:
	/* 0x1adf: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ae4:
	/* 0x1ae4: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ae9:
	/* 0x1ae9: call   1aee <perf_unwind_native+0x1aee> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1aee:
	/* 0x1aee: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1af1:
	/* 0x1af1: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1af1, 0x2949, x86_l_2949);
x86_l_1af7:
	/* 0x1af7: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1afb:
	/* 0x1afb: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1afe:
	/* 0x1afe: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b03:
	/* 0x1b03: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b06:
	/* 0x1b06: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b0a:
	/* 0x1b0a: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b0e:
	/* 0x1b0e: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b11:
	/* 0x1b11: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1b11, 0x1ce3, x86_l_1ce3);
x86_l_1b17:
	/* 0x1b17: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1b1b:
	/* 0x1b1b: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1b1d:
	/* 0x1b1d: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b21:
	/* 0x1b21: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b26:
	/* 0x1b26: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b2b:
	/* 0x1b2b: call   1b30 <perf_unwind_native+0x1b30> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1b30:
	/* 0x1b30: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b33:
	/* 0x1b33: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b33, 0x2949, x86_l_2949);
x86_l_1b39:
	/* 0x1b39: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b3d:
	/* 0x1b3d: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b41:
	/* 0x1b41: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b46:
	/* 0x1b46: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b49:
	/* 0x1b49: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b4d:
	/* 0x1b4d: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b51:
	/* 0x1b51: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b54:
	/* 0x1b54: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1b54, 0x1ce3, x86_l_1ce3);
x86_l_1b5a:
	/* 0x1b5a: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1b5e:
	/* 0x1b5e: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1b60:
	/* 0x1b60: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b64:
	/* 0x1b64: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b69:
	/* 0x1b69: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1b6e:
	/* 0x1b6e: call   1b73 <perf_unwind_native+0x1b73> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1b73:
	/* 0x1b73: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1b76:
	/* 0x1b76: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1b76, 0x2949, x86_l_2949);
x86_l_1b7c:
	/* 0x1b7c: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1b80:
	/* 0x1b80: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1b83:
	/* 0x1b83: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1b88:
	/* 0x1b88: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1b8b:
	/* 0x1b8b: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b8f:
	/* 0x1b8f: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1b93:
	/* 0x1b93: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1b96:
	/* 0x1b96: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1b96, 0x1ce3, x86_l_1ce3);
x86_l_1b9c:
	/* 0x1b9c: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1ba0:
	/* 0x1ba0: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1ba2:
	/* 0x1ba2: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1ba6:
	/* 0x1ba6: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bab:
	/* 0x1bab: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bb0:
	/* 0x1bb0: call   1bb5 <perf_unwind_native+0x1bb5> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1bb5:
	/* 0x1bb5: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bb8:
	/* 0x1bb8: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bb8, 0x2949, x86_l_2949);
x86_l_1bbe:
	/* 0x1bbe: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bc2:
	/* 0x1bc2: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1bc6:
	/* 0x1bc6: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1bcb:
	/* 0x1bcb: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1bce:
	/* 0x1bce: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1bd2:
	/* 0x1bd2: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1bd6:
	/* 0x1bd6: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1bd9:
	/* 0x1bd9: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1bd9, 0x1ce3, x86_l_1ce3);
x86_l_1bdf:
	/* 0x1bdf: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1be3:
	/* 0x1be3: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1be5:
	/* 0x1be5: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1be9:
	/* 0x1be9: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1bee:
	/* 0x1bee: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1bf3:
	/* 0x1bf3: call   1bf8 <perf_unwind_native+0x1bf8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1bf8:
	/* 0x1bf8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1bfb:
	/* 0x1bfb: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1bfb, 0x2949, x86_l_2949);
x86_l_1c01:
	/* 0x1c01: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c05:
	/* 0x1c05: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c08:
	/* 0x1c08: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c0d:
	/* 0x1c0d: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c10:
	/* 0x1c10: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c14:
	/* 0x1c14: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c18:
	/* 0x1c18: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1c1b:
	/* 0x1c1b: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1c1b, 0x1ce3, x86_l_1ce3);
x86_l_1c21:
	/* 0x1c21: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1c25:
	/* 0x1c25: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1c27:
	/* 0x1c27: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c2b:
	/* 0x1c2b: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c30:
	/* 0x1c30: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c35:
	/* 0x1c35: call   1c3a <perf_unwind_native+0x1c3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c3a:
	/* 0x1c3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c3d:
	/* 0x1c3d: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c3d, 0x2949, x86_l_2949);
x86_l_1c43:
	/* 0x1c43: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c47:
	/* 0x1c47: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c4b:
	/* 0x1c4b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c50:
	/* 0x1c50: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c53:
	/* 0x1c53: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c57:
	/* 0x1c57: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c5b:
	/* 0x1c5b: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1c5e:
	/* 0x1c5e: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1c5e, 0x1ce3, x86_l_1ce3);
x86_l_1c64:
	/* 0x1c64: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_1c68:
	/* 0x1c68: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1c6a:
	/* 0x1c6a: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c6e:
	/* 0x1c6e: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c73:
	/* 0x1c73: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1c78:
	/* 0x1c78: call   1c7d <perf_unwind_native+0x1c7d> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1c7d:
	/* 0x1c7d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1c80:
	/* 0x1c80: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c80, 0x2949, x86_l_2949);
x86_l_1c86:
	/* 0x1c86: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1c8a:
	/* 0x1c8a: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1c8d:
	/* 0x1c8d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1c92:
	/* 0x1c92: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c95:
	/* 0x1c95: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c99:
	/* 0x1c99: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1c9d:
	/* 0x1c9d: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ca0:
	/* 0x1ca0: jae    1ce3 <perf_unwind_native+0x1ce3> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x1ca0, 0x1ce3, x86_l_1ce3);
x86_l_1ca2:
	/* 0x1ca2: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1ca6:
	/* 0x1ca6: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_1ca8:
	/* 0x1ca8: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cac:
	/* 0x1cac: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cb1:
	/* 0x1cb1: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1cb6:
	/* 0x1cb6: call   1cbb <perf_unwind_native+0x1cbb> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1cbb:
	/* 0x1cbb: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1cbe:
	/* 0x1cbe: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1cbe, 0x2949, x86_l_2949);
x86_l_1cc4:
	/* 0x1cc4: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1cc8:
	/* 0x1cc8: lea    edx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1ccb:
	/* 0x1ccb: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1cd0:
	/* 0x1cd0: cmp    WORD PTR [rax],si */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd3:
	/* 0x1cd3: cmova  edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1cd6:
	/* 0x1cd6: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_1cda:
	/* 0x1cda: cmp    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1cdd:
	/* 0x1cdd: jb     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1cdd, 0x2949, x86_l_2949);
x86_l_1ce3:
	/* 0x1ce3: mov    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ce6:
	/* 0x1ce6: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1ce9:
	/* 0x1ce9: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ce9, 0x2949, x86_l_2949);
x86_l_1cef:
	/* 0x1cef: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1cf2:
	/* 0x1cf2: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1cf7:
	/* 0x1cf7: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1cfc:
	/* 0x1cfc: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d01:
	/* 0x1d01: call   1d06 <perf_unwind_native+0x1d06> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1d06:
	/* 0x1d06: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d09:
	/* 0x1d09: je     1e76 <perf_unwind_native+0x1e76> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d09, 0x1e76, x86_l_1e76);
x86_l_1d0f:
	/* 0x1d0f: movzx  ecx,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_1d14:
	/* 0x1d14: movzx  edx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_1d17:
	/* 0x1d17: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_1d19:
	/* 0x1d19: mov    edx,DWORD PTR [rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_1d1d:
	/* 0x1d1d: cmp    edx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_1d21:
	/* 0x1d21: lea    r12d,[rcx+0x10000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 65536ULL);
x86_l_1d28:
	/* 0x1d28: cmovae r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R12, X86_RCX, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_1d2c:
	/* 0x1d2c: movzx  eax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_1d30:
	/* 0x1d30: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d34:
	/* 0x1d34: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_1d39:
	/* 0x1d39: je     1e2b <perf_unwind_native+0x1e2b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d39, 0x1e2b, x86_l_1e2b);
x86_l_1d3f:
	/* 0x1d3f: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_1d44:
	/* 0x1d44: jne    1d6b <perf_unwind_native+0x1d6b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1d44, 0x1d6b, x86_l_1d6b);
x86_l_1d46:
	/* 0x1d46: mov    DWORD PTR [rsp+0x4],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869191ULL);
x86_l_1d4e:
	/* 0x1d4e: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_1d55:
	/* 0x1d55: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d5a:
	/* 0x1d5a: call   1d5f <perf_unwind_native+0x1d5f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1d5f:
	/* 0x1d5f: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d62:
	/* 0x1d62: je     1d67 <perf_unwind_native+0x1d67> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d62, 0x1d67, x86_l_1d67);
x86_l_1d64:
	/* 0x1d64: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_1d67:
	/* 0x1d67: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d6b:
	/* 0x1d6b: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_1d6e:
	/* 0x1d6e: js     1e85 <perf_unwind_native+0x1e85> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1d6e, 0x1e85, x86_l_1e85);
x86_l_1d74:
	/* 0x1d74: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_1d7b:
	/* 0x1d7b: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1d80:
	/* 0x1d80: call   1d85 <perf_unwind_native+0x1d85> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_1d85:
	/* 0x1d85: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d88:
	/* 0x1d88: je     2963 <perf_unwind_native+0x2963> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d88, 0x2963, x86_l_2963);
x86_l_1d8e:
	/* 0x1d8e: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1d91:
	/* 0x1d91: mov    r14d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_1d95:
	/* 0x1d95: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_1d99:
	/* 0x1d99: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d9b:
	/* 0x1d9b: je     1db8 <perf_unwind_native+0x1db8> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d9b, 0x1db8, x86_l_1db8);
x86_l_1d9d:
	/* 0x1d9d: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1d9f:
	/* 0x1d9f: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1da2:
	/* 0x1da2: cmp    r12d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R12, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_1da5:
	/* 0x1da5: jl     1db8 <perf_unwind_native+0x1db8> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1da5, 0x1db8, x86_l_1db8);
x86_l_1da7:
	/* 0x1da7: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1da9:
	/* 0x1da9: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1dab:
	/* 0x1dab: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_1dae:
	/* 0x1dae: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_1db1:
	/* 0x1db1: add    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_1db4:
	/* 0x1db4: add    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_1db8:
	/* 0x1db8: movzx  eax,BYTE PTR [rbx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_1dbb:
	/* 0x1dbb: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1dbe:
	/* 0x1dbe: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_1dc1:
	/* 0x1dc1: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1dc3:
	/* 0x1dc3: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_1dc7:
	/* 0x1dc7: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_1dc9:
	/* 0x1dc9: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_1dcc:
	/* 0x1dcc: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1dcf:
	/* 0x1dcf: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1dd1:
	/* 0x1dd1: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_1dd4:
	/* 0x1dd4: ja     201b <perf_unwind_native+0x201b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1dd4, 0x201b, x86_l_201b);
x86_l_1dda:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1df7ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1df4ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1defULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x201bULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x1fc6ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1de8:
	/* 0x1de8: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1ded:
	/* 0x1ded: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x1defULL: goto x86_l_1def;
			case 0x1df4ULL: goto x86_l_1df4;
			case 0x1df7ULL: goto x86_l_1df7;
			case 0x1fc6ULL: goto x86_l_1fc6;
			case 0x201bULL: goto x86_l_201b;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1def:
	/* 0x1def: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1df4:
	/* 0x1df4: mov    r12,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1df7:
	/* 0x1df7: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1dfa:
	/* 0x1dfa: movsxd r12,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_1dfd:
	/* 0x1dfd: add    r12,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_1e00:
	/* 0x1e00: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_1e02:
	/* 0x1e02: jns    201b <perf_unwind_native+0x201b> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x1e02, 0x201b, x86_l_201b);
x86_l_1e08:
	/* 0x1e08: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1e0d:
	/* 0x1e0d: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1e12:
	/* 0x1e12: mov    rdx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1e15:
	/* 0x1e15: call   1e1a <perf_unwind_native+0x1e1a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1e1a:
	/* 0x1e1a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1e1d:
	/* 0x1e1d: je     1ff0 <perf_unwind_native+0x1ff0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e1d, 0x1ff0, x86_l_1ff0);
x86_l_1e23:
	/* 0x1e23: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1e26:
	/* 0x1e26: jmp    201b <perf_unwind_native+0x201b> */
	X86_SIM_X86_JMP(0x1e26, 0x201b, x86_l_201b);
x86_l_1e2b:
	/* 0x1e2b: mov    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_1e30:
	/* 0x1e30: mov    ecx,0xfa5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4005ULL);
x86_l_1e35:
	/* 0x1e35: jmp    2953 <perf_unwind_native+0x2953> */
	X86_SIM_X86_JMP(0x1e35, 0x2953, x86_l_2953);
x86_l_1e3a:
	/* 0x1e3a: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1e3f:
	/* 0x1e3f: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_1e44:
	/* 0x1e44: mov    edx,0xfa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4000ULL);
x86_l_1e49:
	/* 0x1e49: jmp    5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JMP(0x1e49, 0x5ef, x86_l_5ef);
x86_l_1e4e:
	/* 0x1e4e: mov    ecx,0x33 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_1e53:
	/* 0x1e53: mov    edx,0xfa1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4001ULL);
x86_l_1e58:
	/* 0x1e58: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1e5d:
	/* 0x1e5d: jmp    5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JMP(0x1e5d, 0x5ef, x86_l_5ef);
x86_l_1e62:
	/* 0x1e62: mov    ecx,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_1e67:
	/* 0x1e67: mov    edx,0xfa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4002ULL);
x86_l_1e6c:
	/* 0x1e6c: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1e71:
	/* 0x1e71: jmp    5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JMP(0x1e71, 0x5ef, x86_l_5ef);
x86_l_1e76:
	/* 0x1e76: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_1e7b:
	/* 0x1e7b: mov    edx,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_1e80:
	/* 0x1e80: jmp    2953 <perf_unwind_native+0x2953> */
	X86_SIM_X86_JMP(0x1e80, 0x2953, x86_l_2953);
x86_l_1e85:
	/* 0x1e85: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_1e8a:
	/* 0x1e8a: dec    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_1e8c:
	/* 0x1e8c: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_1e8f:
	/* 0x1e8f: ja     29db <perf_unwind_native+0x29db> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1e8f, 0x29db, x86_l_29db);
x86_l_1e95:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x807ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x1eb4ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x1ed1ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x1f77ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1ea3:
	/* 0x1ea3: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_1ea8:
	/* 0x1ea8: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1ead:
	/* 0x1ead: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_1eb2:
	/* 0x1eb2: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x807ULL: goto x86_l_807;
			case 0x1eb4ULL: goto x86_l_1eb4;
			case 0x1ed1ULL: goto x86_l_1ed1;
			case 0x1f77ULL: goto x86_l_1f77;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1eb4:
	/* 0x1eb4: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb7:
	/* 0x1eb7: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1eb9:
	/* 0x1eb9: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1ebc:
	/* 0x1ebc: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1ebe:
	/* 0x1ebe: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_1ec1:
	/* 0x1ec1: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_1ec4:
	/* 0x1ec4: lea    r12,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_1ec8:
	/* 0x1ec8: add    r12,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1ecc:
	/* 0x1ecc: jmp    20f6 <perf_unwind_native+0x20f6> */
	X86_SIM_X86_JMP(0x1ecc, 0x20f6, x86_l_20f6);
x86_l_1ed1:
	/* 0x1ed1: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ed4:
	/* 0x1ed4: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_1ed8:
	/* 0x1ed8: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1ee0:
	/* 0x1ee0: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_1ee5:
	/* 0x1ee5: call   1eea <perf_unwind_native+0x1eea> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1eea:
	/* 0x1eea: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1eed:
	/* 0x1eed: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1eed, 0xb4d, x86_l_b4d);
x86_l_1ef3:
	/* 0x1ef3: mov    rax,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_1efb:
	/* 0x1efb: mov    QWORD PTR [rbp+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_1f02:
	/* 0x1f02: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1f0a:
	/* 0x1f0a: mov    QWORD PTR [rbp+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_1f11:
	/* 0x1f11: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_1f19:
	/* 0x1f19: mov    QWORD PTR [rbp+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_1f20:
	/* 0x1f20: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_1f28:
	/* 0x1f28: mov    QWORD PTR [rbp+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_1f2f:
	/* 0x1f2f: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_1f37:
	/* 0x1f37: mov    QWORD PTR [rbp+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_1f3e:
	/* 0x1f3e: mov    rax,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_1f46:
	/* 0x1f46: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1f4d:
	/* 0x1f4d: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_1f55:
	/* 0x1f55: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1f5c:
	/* 0x1f5c: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_1f64:
	/* 0x1f64: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1f6b:
	/* 0x1f6b: mov    BYTE PTR [rbp+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_1f72:
	/* 0x1f72: jmp    212a <perf_unwind_native+0x212a> */
	X86_SIM_X86_JMP(0x1f72, 0x212a, x86_l_212a);
x86_l_1f77:
	/* 0x1f77: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f7c:
	/* 0x1f7c: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1f7f:
	/* 0x1f7f: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f84:
	/* 0x1f84: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_1f89:
	/* 0x1f89: call   1f8e <perf_unwind_native+0x1f8e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_1f8e:
	/* 0x1f8e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_1f91:
	/* 0x1f91: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f91, 0xb4d, x86_l_b4d);
x86_l_1f97:
	/* 0x1f97: mov    rax,QWORD PTR [rbp+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1f9e:
	/* 0x1f9e: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1fa2:
	/* 0x1fa2: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_1fa9:
	/* 0x1fa9: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1fae:
	/* 0x1fae: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_1fb5:
	/* 0x1fb5: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1fba:
	/* 0x1fba: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_1fc1:
	/* 0x1fc1: jmp    2123 <perf_unwind_native+0x2123> */
	X86_SIM_X86_JMP(0x1fc1, 0x2123, x86_l_2123);
x86_l_1fc6:
	/* 0x1fc6: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_1fc9:
	/* 0x1fc9: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_1fcc:
	/* 0x1fcc: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_1fcf:
	/* 0x1fcf: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_1fd2:
	/* 0x1fd2: ja     201b <perf_unwind_native+0x201b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1fd2, 0x201b, x86_l_201b);
x86_l_1fd4:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x200eULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x1fe9ULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2002ULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x201bULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2009ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_1fe2:
	/* 0x1fe2: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_1fe7:
	/* 0x1fe7: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x1fe9ULL: goto x86_l_1fe9;
			case 0x2002ULL: goto x86_l_2002;
			case 0x2009ULL: goto x86_l_2009;
			case 0x200eULL: goto x86_l_200e;
			case 0x201bULL: goto x86_l_201b;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fe9:
	/* 0x1fe9: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_1fee:
	/* 0x1fee: jmp    200e <perf_unwind_native+0x200e> */
	X86_SIM_X86_JMP(0x1fee, 0x200e, x86_l_200e);
x86_l_1ff0:
	/* 0x1ff0: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_1ff4:
	/* 0x1ff4: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_1ff8:
	/* 0x1ff8: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_1ffd:
	/* 0x1ffd: mov    r12,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2000:
	/* 0x2000: jmp    201b <perf_unwind_native+0x201b> */
	X86_SIM_X86_JMP(0x2000, 0x201b, x86_l_201b);
x86_l_2002:
	/* 0x2002: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2007:
	/* 0x2007: jmp    200e <perf_unwind_native+0x200e> */
	X86_SIM_X86_JMP(0x2007, 0x200e, x86_l_200e);
x86_l_2009:
	/* 0x2009: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_200e:
	/* 0x200e: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_2011:
	/* 0x2011: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2015:
	/* 0x2015: movsxd r12,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R12, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2018:
	/* 0x2018: add    r12,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R12, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_201b:
	/* 0x201b: movzx  eax,BYTE PTR [rbx+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_201f:
	/* 0x201f: mov    r14d,DWORD PTR [rbx+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2023:
	/* 0x2023: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2026:
	/* 0x2026: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2029:
	/* 0x2029: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_202b:
	/* 0x202b: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_202f:
	/* 0x202f: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2031:
	/* 0x2031: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_2034:
	/* 0x2034: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2036:
	/* 0x2036: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2039:
	/* 0x2039: ja     20e5 <perf_unwind_native+0x20e5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2039, 0x20e5, x86_l_20e5);
x86_l_203f:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x205fULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x205cULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x2057ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x20e5ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x208fULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_204d:
	/* 0x204d: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2052:
	/* 0x2052: mov    rsi,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_2055:
	/* 0x2055: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x2057ULL: goto x86_l_2057;
			case 0x205cULL: goto x86_l_205c;
			case 0x205fULL: goto x86_l_205f;
			case 0x208fULL: goto x86_l_208f;
			case 0x20e5ULL: goto x86_l_20e5;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2057:
	/* 0x2057: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_205c:
	/* 0x205c: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_205f:
	/* 0x205f: movsxd rdx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2062:
	/* 0x2062: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2065:
	/* 0x2065: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2067:
	/* 0x2067: jns    20cf <perf_unwind_native+0x20cf> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2067, 0x20cf, x86_l_20cf);
x86_l_2069:
	/* 0x2069: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_206e:
	/* 0x206e: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2073:
	/* 0x2073: call   2078 <perf_unwind_native+0x2078> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2078:
	/* 0x2078: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_207b:
	/* 0x207b: jne    20e5 <perf_unwind_native+0x20e5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x207b, 0x20e5, x86_l_20e5);
x86_l_207d:
	/* 0x207d: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_2081:
	/* 0x2081: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_2085:
	/* 0x2085: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_208a:
	/* 0x208a: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_208d:
	/* 0x208d: jmp    20cf <perf_unwind_native+0x20cf> */
	X86_SIM_X86_JMP(0x208d, 0x20cf, x86_l_20cf);
x86_l_208f:
	/* 0x208f: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2092:
	/* 0x2092: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2095:
	/* 0x2095: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2098:
	/* 0x2098: ja     20e5 <perf_unwind_native+0x20e5> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2098, 0x20e5, x86_l_20e5);
x86_l_209a:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20c2ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20afULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20b6ULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20e5ULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x20bdULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_20a8:
	/* 0x20a8: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_20ad:
	/* 0x20ad: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x20afULL: goto x86_l_20af;
			case 0x20b6ULL: goto x86_l_20b6;
			case 0x20bdULL: goto x86_l_20bd;
			case 0x20c2ULL: goto x86_l_20c2;
			case 0x20e5ULL: goto x86_l_20e5;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20af:
	/* 0x20af: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_20b4:
	/* 0x20b4: jmp    20c2 <perf_unwind_native+0x20c2> */
	X86_SIM_X86_JMP(0x20b4, 0x20c2, x86_l_20c2);
x86_l_20b6:
	/* 0x20b6: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_20bb:
	/* 0x20bb: jmp    20c2 <perf_unwind_native+0x20c2> */
	X86_SIM_X86_JMP(0x20bb, 0x20c2, x86_l_20c2);
x86_l_20bd:
	/* 0x20bd: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_20c2:
	/* 0x20c2: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_20c5:
	/* 0x20c5: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_20c9:
	/* 0x20c9: movsxd rdx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_20cc:
	/* 0x20cc: add    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_20cf:
	/* 0x20cf: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_20d2:
	/* 0x20d2: je     20e5 <perf_unwind_native+0x20e5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20d2, 0x20e5, x86_l_20e5);
x86_l_20d4:
	/* 0x20d4: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20d9:
	/* 0x20d9: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_20de:
	/* 0x20de: call   20e3 <perf_unwind_native+0x20e3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_20e3:
	/* 0x20e3: jmp    20f6 <perf_unwind_native+0x20f6> */
	X86_SIM_X86_JMP(0x20e3, 0x20f6, x86_l_20f6);
x86_l_20e5:
	/* 0x20e5: cmp    BYTE PTR [rbx],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_20e8:
	/* 0x20e8: jne    20f6 <perf_unwind_native+0x20f6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20e8, 0x20f6, x86_l_20f6);
x86_l_20ea:
	/* 0x20ea: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_20ef:
	/* 0x20ef: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20f6:
	/* 0x20f6: test   r12,r12 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_20f9:
	/* 0x20f9: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_20fe:
	/* 0x20fe: je     b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20fe, 0xb4d, x86_l_b4d);
x86_l_2104:
	/* 0x2104: lea    rdx,[r12-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_2109:
	/* 0x2109: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_210e:
	/* 0x210e: call   2113 <perf_unwind_native+0x2113> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2113:
	/* 0x2113: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2116:
	/* 0x2116: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2116, 0xb4d, x86_l_b4d);
x86_l_211c:
	/* 0x211c: mov    QWORD PTR [rbp+0xed8],r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2123:
	/* 0x2123: mov    BYTE PTR [rbp+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_212a:
	/* 0x212a: mov    DWORD PTR [rsp+0x30],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430214ULL);
x86_l_2132:
	/* 0x2132: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2139:
	/* 0x2139: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_213e:
	/* 0x213e: call   2143 <perf_unwind_native+0x2143> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2143:
	/* 0x2143: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2146:
	/* 0x2146: je     214b <perf_unwind_native+0x214b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2146, 0x214b, x86_l_214b);
x86_l_2148:
	/* 0x2148: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_214b:
	/* 0x214b: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2150:
	/* 0x2150: mov    r14,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2153:
	/* 0x2153: test   r14,r14 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2156:
	/* 0x2156: je     2d93 <perf_unwind_native+0x2d93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2156, 0x2d93, x86_l_2d93);
x86_l_215c:
	/* 0x215c: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2166:
	/* 0x2166: cmp    r14,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2169:
	/* 0x2169: ja     bc6 <perf_unwind_native+0xbc6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2169, 0xbc6, x86_l_bc6);
x86_l_216f:
	/* 0x216f: cmp    r14,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2176:
	/* 0x2176: jb     be4 <perf_unwind_native+0xbe4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2176, 0xbe4, x86_l_be4);
x86_l_217c:
	/* 0x217c: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_217f:
	/* 0x217f: mov    DWORD PTR [rsp+0x80],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813984ULL);
x86_l_218a:
	/* 0x218a: movbe  DWORD PTR [rsp+0x84],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 132ULL);
x86_l_2193:
	/* 0x2193: movbe  QWORD PTR [rsp+0x88],r14 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R14, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 136ULL);
x86_l_219d:
	/* 0x219d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_21a4:
	/* 0x21a4: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_21ac:
	/* 0x21ac: call   21b1 <perf_unwind_native+0x21b1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_21b1:
	/* 0x21b1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_21b4:
	/* 0x21b4: je     2db0 <perf_unwind_native+0x2db0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21b4, 0x2db0, x86_l_2db0);
x86_l_21ba:
	/* 0x21ba: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_21be:
	/* 0x21be: mov    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R12, X86_WIDTH_64, 0, 0);
x86_l_21c1:
	/* 0x21c1: movabs rdx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_21cb:
	/* 0x21cb: and    rcx,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_21ce:
	/* 0x21ce: mov    QWORD PTR [rbp+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_21d5:
	/* 0x21d5: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_21d9:
	/* 0x21d9: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_21dc:
	/* 0x21dc: mov    QWORD PTR [rbp+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_21e3:
	/* 0x21e3: sub    r14,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_21e6:
	/* 0x21e6: mov    QWORD PTR [rbp+0xf18],r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_21ed:
	/* 0x21ed: cmp    r12,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_21f1:
	/* 0x21f1: jne    2268 <perf_unwind_native+0x2268> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x21f1, 0x2268, x86_l_2268);
x86_l_21f3:
	/* 0x21f3: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_21fb:
	/* 0x21fb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_2202:
	/* 0x2202: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_220a:
	/* 0x220a: call   220f <perf_unwind_native+0x220f> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_220f:
	/* 0x220f: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2215:
	/* 0x2215: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2218:
	/* 0x2218: je     2268 <perf_unwind_native+0x2268> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2218, 0x2268, x86_l_2268);
x86_l_221a:
	/* 0x221a: mov    rbx,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RBX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_221d:
	/* 0x221d: cmp    QWORD PTR [rax],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2220:
	/* 0x2220: ja     2228 <perf_unwind_native+0x2228> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2220, 0x2228, x86_l_2228);
x86_l_2222:
	/* 0x2222: cmp    QWORD PTR [rbx+0x8],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2226:
	/* 0x2226: jae    2234 <perf_unwind_native+0x2234> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2226, 0x2234, x86_l_2234);
x86_l_2228:
	/* 0x2228: cmp    QWORD PTR [rbx+0x10],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_222c:
	/* 0x222c: ja     2268 <perf_unwind_native+0x2268> */
	X86_SIM_X86_JCC(X86_CC_A, 0x222c, 0x2268, x86_l_2268);
x86_l_222e:
	/* 0x222e: cmp    QWORD PTR [rbx+0x18],r14 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2232:
	/* 0x2232: jb     2268 <perf_unwind_native+0x2268> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2232, 0x2268, x86_l_2268);
x86_l_2234:
	/* 0x2234: mov    eax,DWORD PTR [rbp+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_223a:
	/* 0x223a: mov    ecx,DWORD PTR [rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_223d:
	/* 0x223d: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2240:
	/* 0x2240: jb     2268 <perf_unwind_native+0x2268> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2240, 0x2268, x86_l_2268);
x86_l_2242:
	/* 0x2242: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_224a:
	/* 0x224a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2251:
	/* 0x2251: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2256:
	/* 0x2256: call   225b <perf_unwind_native+0x225b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_225b:
	/* 0x225b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_225e:
	/* 0x225e: je     2263 <perf_unwind_native+0x2263> */
	X86_SIM_X86_JCC(X86_CC_E, 0x225e, 0x2263, x86_l_2263);
x86_l_2260:
	/* 0x2260: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2263:
	/* 0x2263: movzx  r12d,WORD PTR [rbx+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RBX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_2268:
	/* 0x2268: cmp    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_226c:
	/* 0x226c: jne    2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x226c, 0x2da6, x86_l_2da6);
x86_l_2272:
	/* 0x2272: mov    DWORD PTR [rsp+0x80],0x5 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813893ULL);
x86_l_227d:
	/* 0x227d: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2284:
	/* 0x2284: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_228c:
	/* 0x228c: call   2291 <perf_unwind_native+0x2291> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2291:
	/* 0x2291: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2294:
	/* 0x2294: je     2299 <perf_unwind_native+0x2299> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2294, 0x2299, x86_l_2299);
x86_l_2296:
	/* 0x2296: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2299:
	/* 0x2299: mov    eax,DWORD PTR [rbp+0x2c0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_229f:
	/* 0x229f: cmp    rax,0x7e */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 126ULL);
x86_l_22a3:
	/* 0x22a3: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_22a8:
	/* 0x22a8: ja     75 <perf_unwind_native+0x75> */
	X86_SIM_X86_JCC(X86_CC_A, 0x22a8, 0x75, x86_l_75);
x86_l_22ae:
	/* 0x22ae: movzx  ecx,BYTE PTR [rbp+0xf30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 3888ULL);
x86_l_22b5:
	/* 0x22b5: mov    rdx,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_22bc:
	/* 0x22bc: mov    rsi,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_22c3:
	/* 0x22c3: lea    edi,[rax+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_22c6:
	/* 0x22c6: mov    DWORD PTR [rbp+0x2c0],edi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 704ULL);
x86_l_22cc:
	/* 0x22cc: lea    rax,[rax+rax*2] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 1), 0ULL);
x86_l_22d0:
	/* 0x22d0: mov    QWORD PTR [rbp+rax*8+0x2d0],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 720ULL);
x86_l_22d8:
	/* 0x22d8: mov    QWORD PTR [rbp+rax*8+0x2d8],rsi */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_RAX, 3), 728ULL);
x86_l_22e0:
	/* 0x22e0: mov    BYTE PTR [rbp+rax*8+0x2e0],0x3 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 3161095929859ULL);
x86_l_22e8:
	/* 0x22e8: mov    BYTE PTR [rbp+rax*8+0x2e1],cl */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 3), 737ULL);
x86_l_22ef:
	/* 0x22ef: mov    DWORD PTR [rbp+rax*8+0x2e2],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_RAX, 3), 3169685864448ULL);
x86_l_22fa:
	/* 0x22fa: mov    WORD PTR [rbp+rax*8+0x2e6],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_RAX, 3), 3186865733632ULL);
x86_l_2304:
	/* 0x2304: mov    DWORD PTR [rsp+0x28],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_230c:
	/* 0x230c: mov    rax,QWORD PTR [rbp+0xf10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2313:
	/* 0x2313: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2318:
	/* 0x2318: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_231d:
	/* 0x231d: mov    rax,0xffffffffffff0000 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 18446744073709486080ULL);
x86_l_2324:
	/* 0x2324: and    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RAX, X86_RBP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 3864ULL);
x86_l_232b:
	/* 0x232b: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2330:
	/* 0x2330: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)stack_delta_page_to_info));
x86_l_2337:
	/* 0x2337: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_233c:
	/* 0x233c: call   2341 <perf_unwind_native+0x2341> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2341:
	/* 0x2341: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2344:
	/* 0x2344: mov    ecx,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2349:
	/* 0x2349: mov    edx,0xfa0 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4000ULL);
x86_l_234e:
	/* 0x234e: je     5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x234e, 0x5ef, x86_l_5ef);
x86_l_2354:
	/* 0x2354: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2357:
	/* 0x2357: movzx  eax,WORD PTR [rax+0x6] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 6ULL);
x86_l_235b:
	/* 0x235b: add    eax,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_235e:
	/* 0x235e: mov    ecx,0x33 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 51ULL);
x86_l_2363:
	/* 0x2363: mov    edx,0xfa1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4001ULL);
x86_l_2368:
	/* 0x2368: cmp    ax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_16, 0, 15ULL);
x86_l_236c:
	/* 0x236c: ja     5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JCC(X86_CC_A, 0x236c, 0x5ef, x86_l_5ef);
x86_l_2372:
	/* 0x2372: movzx  eax,ax */
	X86_SIM_RUN_OP(X86_OP_MOVZX_REG, X86_RAX, X86_RAX, X86_WIDTH_32, X86_WIDTH_16, 0);
x86_l_2375:
	/* Image-bound immutable capability table; private base is dead. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 3) {
	case 0ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_8_stack_deltas)); break;
	case 8ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_9_stack_deltas)); break;
	case 16ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_10_stack_deltas)); break;
	case 24ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_11_stack_deltas)); break;
	case 32ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_12_stack_deltas)); break;
	case 40ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_13_stack_deltas)); break;
	case 48ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_14_stack_deltas)); break;
	case 56ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_15_stack_deltas)); break;
	case 64ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_16_stack_deltas)); break;
	case 72ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_17_stack_deltas)); break;
	case 80ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_18_stack_deltas)); break;
	case 88ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_19_stack_deltas)); break;
	case 96ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_20_stack_deltas)); break;
	case 104ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_21_stack_deltas)); break;
	case 112ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_22_stack_deltas)); break;
	case 120ULL: X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)exe_id_to_23_stack_deltas)); break;
	default: X86_SIM_L_ARCHITECTURAL_FAULT();
	}
x86_l_2380:
	/* 0x2380: lea    rsi,[rsp+0x78] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_2385:
	/* 0x2385: call   238a <perf_unwind_native+0x238a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_238a:
	/* 0x238a: mov    ecx,0x32 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 50ULL);
x86_l_238f:
	/* 0x238f: mov    edx,0xfa2 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4002ULL);
x86_l_2394:
	/* 0x2394: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2399:
	/* 0x2399: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_239c:
	/* 0x239c: je     5ef <perf_unwind_native+0x5ef> */
	X86_SIM_X86_JCC(X86_CC_E, 0x239c, 0x5ef, x86_l_5ef);
x86_l_23a2:
	/* 0x23a2: mov    r13d,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23a6:
	/* 0x23a6: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_23ab:
	/* 0x23ab: mov    rax,QWORD PTR [rbp+0xf18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_23b2:
	/* 0x23b2: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23b7:
	/* 0x23b7: movzx  r14d,WORD PTR [r12+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 4ULL);
x86_l_23bd:
	/* 0x23bd: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_23c0:
	/* 0x23c0: je     27f7 <perf_unwind_native+0x27f7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23c0, 0x27f7, x86_l_27f7);
x86_l_23c6:
	/* 0x23c6: add    r14d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_R13, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_23c9:
	/* 0x23c9: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_23cd:
	/* 0x23cd: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_23cf:
	/* 0x23cf: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23d3:
	/* 0x23d3: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23d8:
	/* 0x23d8: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23dd:
	/* 0x23dd: call   23e2 <perf_unwind_native+0x23e2> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_23e2:
	/* 0x23e2: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_23e5:
	/* 0x23e5: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23e5, 0x2949, x86_l_2949);
x86_l_23eb:
	/* 0x23eb: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_23ef:
	/* 0x23ef: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_23f2:
	/* 0x23f2: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23f7:
	/* 0x23f7: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fa:
	/* 0x23fa: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_23fe:
	/* 0x23fe: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2402:
	/* 0x2402: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2405:
	/* 0x2405: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2405, 0x27eb, x86_l_27eb);
x86_l_240b:
	/* 0x240b: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_240f:
	/* 0x240f: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2411:
	/* 0x2411: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2415:
	/* 0x2415: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_241a:
	/* 0x241a: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_241f:
	/* 0x241f: call   2424 <perf_unwind_native+0x2424> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2424:
	/* 0x2424: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2427:
	/* 0x2427: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2427, 0x2949, x86_l_2949);
x86_l_242d:
	/* 0x242d: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2431:
	/* 0x2431: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2435:
	/* 0x2435: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_243a:
	/* 0x243a: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_243d:
	/* 0x243d: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2441:
	/* 0x2441: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2445:
	/* 0x2445: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2448:
	/* 0x2448: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2448, 0x27eb, x86_l_27eb);
x86_l_244e:
	/* 0x244e: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2452:
	/* 0x2452: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2454:
	/* 0x2454: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2458:
	/* 0x2458: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_245d:
	/* 0x245d: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2462:
	/* 0x2462: call   2467 <perf_unwind_native+0x2467> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2467:
	/* 0x2467: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_246a:
	/* 0x246a: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x246a, 0x2949, x86_l_2949);
x86_l_2470:
	/* 0x2470: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2474:
	/* 0x2474: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2477:
	/* 0x2477: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_247c:
	/* 0x247c: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_247f:
	/* 0x247f: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2483:
	/* 0x2483: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2487:
	/* 0x2487: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_248a:
	/* 0x248a: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x248a, 0x27eb, x86_l_27eb);
x86_l_2490:
	/* 0x2490: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2494:
	/* 0x2494: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2496:
	/* 0x2496: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_249a:
	/* 0x249a: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_249f:
	/* 0x249f: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24a4:
	/* 0x24a4: call   24a9 <perf_unwind_native+0x24a9> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24a9:
	/* 0x24a9: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24ac:
	/* 0x24ac: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24ac, 0x2949, x86_l_2949);
x86_l_24b2:
	/* 0x24b2: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24b6:
	/* 0x24b6: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_24ba:
	/* 0x24ba: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24bf:
	/* 0x24bf: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_24c2:
	/* 0x24c2: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_24c6:
	/* 0x24c6: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_24ca:
	/* 0x24ca: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_24cd:
	/* 0x24cd: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x24cd, 0x27eb, x86_l_27eb);
x86_l_24d3:
	/* 0x24d3: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_24d7:
	/* 0x24d7: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_24d9:
	/* 0x24d9: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24dd:
	/* 0x24dd: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24e2:
	/* 0x24e2: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_24e7:
	/* 0x24e7: call   24ec <perf_unwind_native+0x24ec> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_24ec:
	/* 0x24ec: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_24ef:
	/* 0x24ef: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24ef, 0x2949, x86_l_2949);
x86_l_24f5:
	/* 0x24f5: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_24f9:
	/* 0x24f9: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_24fc:
	/* 0x24fc: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2501:
	/* 0x2501: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2504:
	/* 0x2504: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2508:
	/* 0x2508: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_250c:
	/* 0x250c: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_250f:
	/* 0x250f: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x250f, 0x27eb, x86_l_27eb);
x86_l_2515:
	/* 0x2515: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2519:
	/* 0x2519: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_251b:
	/* 0x251b: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_251f:
	/* 0x251f: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2524:
	/* 0x2524: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2529:
	/* 0x2529: call   252e <perf_unwind_native+0x252e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_252e:
	/* 0x252e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2531:
	/* 0x2531: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2531, 0x2949, x86_l_2949);
x86_l_2537:
	/* 0x2537: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_253b:
	/* 0x253b: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_253f:
	/* 0x253f: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2544:
	/* 0x2544: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2547:
	/* 0x2547: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_254b:
	/* 0x254b: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_254f:
	/* 0x254f: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2552:
	/* 0x2552: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2552, 0x27eb, x86_l_27eb);
x86_l_2558:
	/* 0x2558: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_255c:
	/* 0x255c: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_255e:
	/* 0x255e: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2562:
	/* 0x2562: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2567:
	/* 0x2567: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_256c:
	/* 0x256c: call   2571 <perf_unwind_native+0x2571> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2571:
	/* 0x2571: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2574:
	/* 0x2574: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2574, 0x2949, x86_l_2949);
x86_l_257a:
	/* 0x257a: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_257e:
	/* 0x257e: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2581:
	/* 0x2581: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2586:
	/* 0x2586: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2589:
	/* 0x2589: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_258d:
	/* 0x258d: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2591:
	/* 0x2591: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2594:
	/* 0x2594: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2594, 0x27eb, x86_l_27eb);
x86_l_259a:
	/* 0x259a: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_259e:
	/* 0x259e: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_25a0:
	/* 0x25a0: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25a4:
	/* 0x25a4: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25a9:
	/* 0x25a9: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25ae:
	/* 0x25ae: call   25b3 <perf_unwind_native+0x25b3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25b3:
	/* 0x25b3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25b6:
	/* 0x25b6: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25b6, 0x2949, x86_l_2949);
x86_l_25bc:
	/* 0x25bc: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25c0:
	/* 0x25c0: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_25c4:
	/* 0x25c4: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_25c9:
	/* 0x25c9: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25cc:
	/* 0x25cc: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_25d0:
	/* 0x25d0: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_25d4:
	/* 0x25d4: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_25d7:
	/* 0x25d7: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x25d7, 0x27eb, x86_l_27eb);
x86_l_25dd:
	/* 0x25dd: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_25e1:
	/* 0x25e1: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_25e3:
	/* 0x25e3: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25e7:
	/* 0x25e7: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_25ec:
	/* 0x25ec: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25f1:
	/* 0x25f1: call   25f6 <perf_unwind_native+0x25f6> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_25f6:
	/* 0x25f6: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_25f9:
	/* 0x25f9: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f9, 0x2949, x86_l_2949);
x86_l_25ff:
	/* 0x25ff: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2603:
	/* 0x2603: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2606:
	/* 0x2606: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_260b:
	/* 0x260b: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_260e:
	/* 0x260e: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2612:
	/* 0x2612: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2616:
	/* 0x2616: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2619:
	/* 0x2619: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2619, 0x27eb, x86_l_27eb);
x86_l_261f:
	/* 0x261f: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_2623:
	/* 0x2623: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2625:
	/* 0x2625: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2629:
	/* 0x2629: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_262e:
	/* 0x262e: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2633:
	/* 0x2633: call   2638 <perf_unwind_native+0x2638> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2638:
	/* 0x2638: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_263b:
	/* 0x263b: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x263b, 0x2949, x86_l_2949);
x86_l_2641:
	/* 0x2641: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2645:
	/* 0x2645: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2649:
	/* 0x2649: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_264e:
	/* 0x264e: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2651:
	/* 0x2651: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2655:
	/* 0x2655: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2659:
	/* 0x2659: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_265c:
	/* 0x265c: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x265c, 0x27eb, x86_l_27eb);
x86_l_2662:
	/* 0x2662: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2666:
	/* 0x2666: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2668:
	/* 0x2668: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_266c:
	/* 0x266c: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2671:
	/* 0x2671: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2676:
	/* 0x2676: call   267b <perf_unwind_native+0x267b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_267b:
	/* 0x267b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_267e:
	/* 0x267e: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x267e, 0x2949, x86_l_2949);
x86_l_2684:
	/* 0x2684: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2688:
	/* 0x2688: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_268b:
	/* 0x268b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2690:
	/* 0x2690: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2693:
	/* 0x2693: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2697:
	/* 0x2697: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_269b:
	/* 0x269b: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_269e:
	/* 0x269e: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x269e, 0x27eb, x86_l_27eb);
x86_l_26a4:
	/* 0x26a4: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_26a8:
	/* 0x26a8: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_26aa:
	/* 0x26aa: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26ae:
	/* 0x26ae: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26b3:
	/* 0x26b3: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26b8:
	/* 0x26b8: call   26bd <perf_unwind_native+0x26bd> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_26bd:
	/* 0x26bd: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_26c0:
	/* 0x26c0: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x26c0, 0x2949, x86_l_2949);
x86_l_26c6:
	/* 0x26c6: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26ca:
	/* 0x26ca: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_26ce:
	/* 0x26ce: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_26d3:
	/* 0x26d3: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26d6:
	/* 0x26d6: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_26da:
	/* 0x26da: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_26de:
	/* 0x26de: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_26e1:
	/* 0x26e1: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x26e1, 0x27eb, x86_l_27eb);
x86_l_26e7:
	/* 0x26e7: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_26eb:
	/* 0x26eb: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_26ed:
	/* 0x26ed: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26f1:
	/* 0x26f1: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_26f6:
	/* 0x26f6: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26fb:
	/* 0x26fb: call   2700 <perf_unwind_native+0x2700> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2700:
	/* 0x2700: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2703:
	/* 0x2703: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2703, 0x2949, x86_l_2949);
x86_l_2709:
	/* 0x2709: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_270d:
	/* 0x270d: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2710:
	/* 0x2710: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2715:
	/* 0x2715: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2718:
	/* 0x2718: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_271c:
	/* 0x271c: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2720:
	/* 0x2720: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2723:
	/* 0x2723: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2723, 0x27eb, x86_l_27eb);
x86_l_2729:
	/* 0x2729: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_272d:
	/* 0x272d: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_272f:
	/* 0x272f: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2733:
	/* 0x2733: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2738:
	/* 0x2738: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_273d:
	/* 0x273d: call   2742 <perf_unwind_native+0x2742> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2742:
	/* 0x2742: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2745:
	/* 0x2745: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2745, 0x2949, x86_l_2949);
x86_l_274b:
	/* 0x274b: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_274f:
	/* 0x274f: lea    r13d,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2753:
	/* 0x2753: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2758:
	/* 0x2758: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_275b:
	/* 0x275b: cmova  r13d,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_275f:
	/* 0x275f: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_2763:
	/* 0x2763: cmp    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2766:
	/* 0x2766: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2766, 0x27eb, x86_l_27eb);
x86_l_276c:
	/* 0x276c: lea    eax,[r14+r13*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_2770:
	/* 0x2770: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_2772:
	/* 0x2772: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2776:
	/* 0x2776: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_277b:
	/* 0x277b: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2780:
	/* 0x2780: call   2785 <perf_unwind_native+0x2785> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2785:
	/* 0x2785: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2788:
	/* 0x2788: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2788, 0x2949, x86_l_2949);
x86_l_278e:
	/* 0x278e: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2792:
	/* 0x2792: lea    ebx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RBX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_2795:
	/* 0x2795: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_279a:
	/* 0x279a: cmp    WORD PTR [rax],dx */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RDX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_279d:
	/* 0x279d: cmova  ebx,r13d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RBX, X86_R13, X86_WIDTH_32, X86_CC_A, 0);
x86_l_27a1:
	/* 0x27a1: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_27a5:
	/* 0x27a5: cmp    ebx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RBX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_27a8:
	/* 0x27a8: jae    27eb <perf_unwind_native+0x27eb> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x27a8, 0x27eb, x86_l_27eb);
x86_l_27aa:
	/* 0x27aa: lea    eax,[rbx+r14*1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RAX, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_27ae:
	/* 0x27ae: shr    eax,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHR, 1ULL);
x86_l_27b0:
	/* 0x27b0: mov    DWORD PTR [rsp+0x4],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_27b4:
	/* 0x27b4: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_27b9:
	/* 0x27b9: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27be:
	/* 0x27be: call   27c3 <perf_unwind_native+0x27c3> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_27c3:
	/* 0x27c3: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_27c6:
	/* 0x27c6: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27c6, 0x2949, x86_l_2949);
x86_l_27cc:
	/* 0x27cc: mov    ecx,DWORD PTR [rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_27d0:
	/* 0x27d0: lea    edx,[rcx+0x1] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_27d3:
	/* 0x27d3: mov    rsi,QWORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27d8:
	/* 0x27d8: cmp    WORD PTR [rax],si */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_RSI, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27db:
	/* 0x27db: cmova  edx,ebx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RDX, X86_RBX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_27de:
	/* 0x27de: cmova  r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R14, X86_RCX, X86_WIDTH_32, X86_CC_A, 0);
x86_l_27e2:
	/* 0x27e2: cmp    edx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_RDX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_27e5:
	/* 0x27e5: jb     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_B, 0x27e5, 0x2949, x86_l_2949);
x86_l_27eb:
	/* 0x27eb: mov    r13d,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_27ee:
	/* 0x27ee: test   r14d,r14d */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R14, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_27f1:
	/* 0x27f1: je     2949 <perf_unwind_native+0x2949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f1, 0x2949, x86_l_2949);
x86_l_27f7:
	/* 0x27f7: dec    r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_27fa:
	/* 0x27fa: mov    DWORD PTR [rsp+0x2c],r13d */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_R13, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_27ff:
	/* 0x27ff: lea    rsi,[rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_2804:
	/* 0x2804: mov    rdi,QWORD PTR [rsp+0x10] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2809:
	/* 0x2809: call   280e <perf_unwind_native+0x280e> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_280e:
	/* 0x280e: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2811:
	/* 0x2811: mov    ecx,0xfa4 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4004ULL);
x86_l_2816:
	/* 0x2816: mov    edx,0xa */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 10ULL);
x86_l_281b:
	/* 0x281b: je     2953 <perf_unwind_native+0x2953> */
	X86_SIM_X86_JCC(X86_CC_E, 0x281b, 0x2953, x86_l_2953);
x86_l_2821:
	/* 0x2821: movzx  ecx,WORD PTR [rsp+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 8ULL);
x86_l_2826:
	/* 0x2826: movzx  edx,WORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 0ULL);
x86_l_2829:
	/* 0x2829: sub    ecx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RDX, X86_WIDTH_32, X86_ALU_SUB, 0);
x86_l_282b:
	/* 0x282b: mov    edx,DWORD PTR [rsp+0x2c] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_282f:
	/* 0x282f: lea    r13d,[rcx+0x10000] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 65536ULL);
x86_l_2836:
	/* 0x2836: cmp    edx,DWORD PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_CMP_REG_MEM, X86_RDX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 0ULL);
x86_l_283a:
	/* 0x283a: cmovae r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_R13, X86_RCX, X86_WIDTH_32, X86_CC_AE, 0);
x86_l_283e:
	/* 0x283e: movzx  eax,WORD PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 2ULL);
x86_l_2842:
	/* 0x2842: mov    DWORD PTR [rsp+0x28],eax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2846:
	/* 0x2846: mov    edx,0xd */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 13ULL);
x86_l_284b:
	/* 0x284b: mov    ecx,0xfa5 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4005ULL);
x86_l_2850:
	/* 0x2850: cmp    eax,0x8000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32768ULL);
x86_l_2855:
	/* 0x2855: je     2953 <perf_unwind_native+0x2953> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2855, 0x2953, x86_l_2953);
x86_l_285b:
	/* 0x285b: cmp    eax,0x8001 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 32769ULL);
x86_l_2860:
	/* 0x2860: jne    2887 <perf_unwind_native+0x2887> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2860, 0x2887, x86_l_2887);
x86_l_2862:
	/* 0x2862: mov    DWORD PTR [rsp+0x4],0x7 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 17179869191ULL);
x86_l_286a:
	/* 0x286a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2871:
	/* 0x2871: lea    rsi,[rsp+0x4] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_2876:
	/* 0x2876: call   287b <perf_unwind_native+0x287b> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_287b:
	/* 0x287b: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_287e:
	/* 0x287e: je     2883 <perf_unwind_native+0x2883> */
	X86_SIM_X86_JCC(X86_CC_E, 0x287e, 0x2883, x86_l_2883);
x86_l_2880:
	/* 0x2880: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2883:
	/* 0x2883: mov    eax,DWORD PTR [rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2887:
	/* 0x2887: test   ax,ax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_16, 0, 0);
x86_l_288a:
	/* 0x288a: js     2993 <perf_unwind_native+0x2993> */
	X86_SIM_X86_JCC(X86_CC_S, 0x288a, 0x2993, x86_l_2993);
x86_l_2890:
	/* 0x2890: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)unwind_info_array));
x86_l_2897:
	/* 0x2897: lea    rsi,[rsp+0x28] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_289c:
	/* 0x289c: call   28a1 <perf_unwind_native+0x28a1> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_28a1:
	/* 0x28a1: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28a4:
	/* 0x28a4: je     2963 <perf_unwind_native+0x2963> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28a4, 0x2963, x86_l_2963);
x86_l_28aa:
	/* 0x28aa: mov    r12,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R12, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_28ad:
	/* 0x28ad: mov    r14d,DWORD PTR [rax+0x4] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_28b1:
	/* 0x28b1: movzx  eax,BYTE PTR [rax+0x2] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 2ULL);
x86_l_28b5:
	/* 0x28b5: test   eax,eax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28b7:
	/* 0x28b7: je     28d4 <perf_unwind_native+0x28d4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28b7, 0x28d4, x86_l_28d4);
x86_l_28b9:
	/* 0x28b9: mov    ecx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28bb:
	/* 0x28bb: and    ecx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_28be:
	/* 0x28be: cmp    r13d,ecx */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_28c1:
	/* 0x28c1: jl     28d4 <perf_unwind_native+0x28d4> */
	X86_SIM_X86_JCC(X86_CC_L, 0x28c1, 0x28d4, x86_l_28d4);
x86_l_28c3:
	/* 0x28c3: xor    ecx,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28c5:
	/* 0x28c5: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_28c7:
	/* 0x28c7: setns  cl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_CC_NS, 0);
x86_l_28ca:
	/* 0x28ca: shl    ecx,0x4 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 4ULL);
x86_l_28cd:
	/* 0x28cd: add    r14d,ecx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R14, X86_RCX, X86_WIDTH_32, X86_ALU_ADD, 0);
x86_l_28d0:
	/* 0x28d0: add    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_ADD, 4294967288ULL);
x86_l_28d4:
	/* 0x28d4: movzx  eax,BYTE PTR [r12] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_28d9:
	/* 0x28d9: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_28dc:
	/* 0x28dc: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_28df:
	/* 0x28df: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_28e1:
	/* 0x28e1: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_28e5:
	/* 0x28e5: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_28e7:
	/* 0x28e7: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_28ea:
	/* 0x28ea: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_28ed:
	/* 0x28ed: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_28ef:
	/* 0x28ef: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_28f2:
	/* 0x28f2: ja     2b34 <perf_unwind_native+0x2b34> */
	X86_SIM_X86_JCC(X86_CC_A, 0x28f2, 0x2b34, x86_l_2b34);
x86_l_28f8:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x2915ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x2912ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x290dULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x2b34ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDI, 0x2adfULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_2906:
	/* 0x2906: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_290b:
	/* 0x290b: jmp    rdi */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDI);
		switch (X86_SIM_L_REG_TAG(X86_RDI)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x290dULL: goto x86_l_290d;
			case 0x2912ULL: goto x86_l_2912;
			case 0x2915ULL: goto x86_l_2915;
			case 0x2adfULL: goto x86_l_2adf;
			case 0x2b34ULL: goto x86_l_2b34;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_290d:
	/* 0x290d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2912:
	/* 0x2912: mov    r13,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2915:
	/* 0x2915: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2918:
	/* 0x2918: movsxd r13,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_291b:
	/* 0x291b: add    r13,rdx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_291e:
	/* 0x291e: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2920:
	/* 0x2920: jns    2b34 <perf_unwind_native+0x2b34> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2920, 0x2b34, x86_l_2b34);
x86_l_2926:
	/* 0x2926: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_292b:
	/* 0x292b: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2930:
	/* 0x2930: mov    rdx,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2933:
	/* 0x2933: call   2938 <perf_unwind_native+0x2938> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2938:
	/* 0x2938: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_293b:
	/* 0x293b: je     2b09 <perf_unwind_native+0x2b09> */
	X86_SIM_X86_JCC(X86_CC_E, 0x293b, 0x2b09, x86_l_2b09);
x86_l_2941:
	/* 0x2941: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2944:
	/* 0x2944: jmp    2b34 <perf_unwind_native+0x2b34> */
	X86_SIM_X86_JMP(0x2944, 0x2b34, x86_l_2b34);
x86_l_2949:
	/* 0x2949: mov    ecx,0xfa3 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4003ULL);
x86_l_294e:
	/* 0x294e: mov    edx,0x9 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 9ULL);
x86_l_2953:
	/* 0x2953: mov    DWORD PTR [rbp+0xf28],edx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 3880ULL);
x86_l_2959:
	/* 0x2959: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_295e:
	/* 0x295e: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0x295e, 0x5f7, x86_l_5f7);
x86_l_2963:
	/* 0x2963: mov    DWORD PTR [rsp+0x30],0x55 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430293ULL);
x86_l_296b:
	/* 0x296b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2972:
	/* 0x2972: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2977:
	/* 0x2977: call   297c <perf_unwind_native+0x297c> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_297c:
	/* 0x297c: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_297f:
	/* 0x297f: je     2984 <perf_unwind_native+0x2984> */
	X86_SIM_X86_JCC(X86_CC_E, 0x297f, 0x2984, x86_l_2984);
x86_l_2981:
	/* 0x2981: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2984:
	/* 0x2984: mov    ecx,0xfaf */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 4015ULL);
x86_l_2989:
	/* 0x2989: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_298e:
	/* 0x298e: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0x298e, 0x5f7, x86_l_5f7);
x86_l_2993:
	/* 0x2993: and    eax,0xffff7fff */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294934527ULL);
x86_l_2998:
	/* 0x2998: dec    eax */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_299a:
	/* 0x299a: cmp    eax,0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 3ULL);
x86_l_299d:
	/* 0x299d: ja     29db <perf_unwind_native+0x29db> */
	X86_SIM_X86_JCC(X86_CC_A, 0x299d, 0x29db, x86_l_29db);
x86_l_299f:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x807ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x29beULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x29eaULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2a90ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_29ad:
	/* 0x29ad: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_29b2:
	/* 0x29b2: mov    rcx,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_29b7:
	/* 0x29b7: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_29bc:
	/* 0x29bc: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x807ULL: goto x86_l_807;
			case 0x29beULL: goto x86_l_29be;
			case 0x29eaULL: goto x86_l_29ea;
			case 0x2a90ULL: goto x86_l_2a90;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29be:
	/* 0x29be: mov    rax,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c1:
	/* 0x29c1: mov    ecx,DWORD PTR [rcx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_RCX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c3:
	/* 0x29c3: and    ecx,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_29c6:
	/* 0x29c6: xor    edx,edx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_29c8:
	/* 0x29c8: cmp    ecx,0xb */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 11ULL);
x86_l_29cb:
	/* 0x29cb: setae  dl */
	X86_SIM_RUN_OP(X86_OP_SETCC, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_CC_AE, 0);
x86_l_29ce:
	/* 0x29ce: lea    r13,[rax+rdx*8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RDX, 3), 0ULL);
x86_l_29d2:
	/* 0x29d2: add    r13,0x8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29d6:
	/* 0x29d6: jmp    2c1e <perf_unwind_native+0x2c1e> */
	X86_SIM_X86_JMP(0x29d6, 0x2c1e, x86_l_2c1e);
x86_l_29db:
	/* 0x29db: mov    ecx,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_29e0:
	/* 0x29e0: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_29e5:
	/* 0x29e5: jmp    5f7 <perf_unwind_native+0x5f7> */
	X86_SIM_X86_JMP(0x29e5, 0x5f7, x86_l_5f7);
x86_l_29ea:
	/* 0x29ea: mov    rdx,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29ed:
	/* 0x29ed: add    rdx,0x28 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_29f1:
	/* 0x29f1: lea    rdi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_29f9:
	/* 0x29f9: mov    esi,0x90 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 144ULL);
x86_l_29fe:
	/* 0x29fe: call   2a03 <perf_unwind_native+0x2a03> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2a03:
	/* 0x2a03: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2a06:
	/* 0x2a06: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2a06, 0xb4d, x86_l_b4d);
x86_l_2a0c:
	/* 0x2a0c: mov    rax,QWORD PTR [rsp+0xe8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 232ULL);
x86_l_2a14:
	/* 0x2a14: mov    QWORD PTR [rbp+0xee8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3816ULL);
x86_l_2a1b:
	/* 0x2a1b: mov    rax,QWORD PTR [rsp+0x88] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_2a23:
	/* 0x2a23: mov    QWORD PTR [rbp+0xef0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3824ULL);
x86_l_2a2a:
	/* 0x2a2a: mov    rax,QWORD PTR [rsp+0x98] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 152ULL);
x86_l_2a32:
	/* 0x2a32: mov    QWORD PTR [rbp+0xef8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3832ULL);
x86_l_2a39:
	/* 0x2a39: mov    rax,QWORD PTR [rsp+0xa8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 168ULL);
x86_l_2a41:
	/* 0x2a41: mov    QWORD PTR [rbp+0xf00],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3840ULL);
x86_l_2a48:
	/* 0x2a48: mov    rax,QWORD PTR [rsp+0xb8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 184ULL);
x86_l_2a50:
	/* 0x2a50: mov    QWORD PTR [rbp+0xf08],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3848ULL);
x86_l_2a57:
	/* 0x2a57: mov    rax,QWORD PTR [rsp+0xd0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 208ULL);
x86_l_2a5f:
	/* 0x2a5f: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2a66:
	/* 0x2a66: mov    rax,QWORD PTR [rsp+0xf8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 248ULL);
x86_l_2a6e:
	/* 0x2a6e: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2a75:
	/* 0x2a75: mov    rax,QWORD PTR [rsp+0x100] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 256ULL);
x86_l_2a7d:
	/* 0x2a7d: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2a84:
	/* 0x2a84: mov    BYTE PTR [rbp+0xf30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846848ULL);
x86_l_2a8b:
	/* 0x2a8b: jmp    2c51 <perf_unwind_native+0x2c51> */
	X86_SIM_X86_JMP(0x2a8b, 0x2c51, x86_l_2c51);
x86_l_2a90:
	/* 0x2a90: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2a95:
	/* 0x2a95: mov    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2a98:
	/* 0x2a98: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a9d:
	/* 0x2a9d: mov    esi,0x10 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 16ULL);
x86_l_2aa2:
	/* 0x2aa2: call   2aa7 <perf_unwind_native+0x2aa7> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2aa7:
	/* 0x2aa7: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2aaa:
	/* 0x2aaa: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aaa, 0xb4d, x86_l_b4d);
x86_l_2ab0:
	/* 0x2ab0: mov    rax,QWORD PTR [rbp+0xee0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2ab7:
	/* 0x2ab7: add    rax,0x10 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2abb:
	/* 0x2abb: mov    QWORD PTR [rbp+0xed8],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2ac2:
	/* 0x2ac2: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ac7:
	/* 0x2ac7: mov    QWORD PTR [rbp+0xee0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3808ULL);
x86_l_2ace:
	/* 0x2ace: mov    rax,QWORD PTR [rsp+0x38] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2ad3:
	/* 0x2ad3: mov    QWORD PTR [rbp+0xed0],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3792ULL);
x86_l_2ada:
	/* 0x2ada: jmp    2c4a <perf_unwind_native+0x2c4a> */
	X86_SIM_X86_JMP(0x2ada, 0x2c4a, x86_l_2c4a);
x86_l_2adf:
	/* 0x2adf: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2ae2:
	/* 0x2ae2: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2ae5:
	/* 0x2ae5: xor    r13d,r13d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_R13, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2ae8:
	/* 0x2ae8: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2aeb:
	/* 0x2aeb: ja     2b34 <perf_unwind_native+0x2b34> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2aeb, 0x2b34, x86_l_2b34);
x86_l_2aed:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b27ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b02ULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b1bULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b34ULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b22ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_2afb:
	/* 0x2afb: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2b00:
	/* 0x2b00: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x2b02ULL: goto x86_l_2b02;
			case 0x2b1bULL: goto x86_l_2b1b;
			case 0x2b22ULL: goto x86_l_2b22;
			case 0x2b27ULL: goto x86_l_2b27;
			case 0x2b34ULL: goto x86_l_2b34;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b02:
	/* 0x2b02: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2b07:
	/* 0x2b07: jmp    2b27 <perf_unwind_native+0x2b27> */
	X86_SIM_X86_JMP(0x2b07, 0x2b27, x86_l_2b27);
x86_l_2b09:
	/* 0x2b09: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_2b0d:
	/* 0x2b0d: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_2b11:
	/* 0x2b11: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_2b16:
	/* 0x2b16: mov    r13,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R13, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2b19:
	/* 0x2b19: jmp    2b34 <perf_unwind_native+0x2b34> */
	X86_SIM_X86_JMP(0x2b19, 0x2b34, x86_l_2b34);
x86_l_2b1b:
	/* 0x2b1b: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2b20:
	/* 0x2b20: jmp    2b27 <perf_unwind_native+0x2b27> */
	X86_SIM_X86_JMP(0x2b20, 0x2b27, x86_l_2b27);
x86_l_2b22:
	/* 0x2b22: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b27:
	/* 0x2b27: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_2b2a:
	/* 0x2b2a: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2b2e:
	/* 0x2b2e: movsxd r13,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_R13, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2b31:
	/* 0x2b31: add    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R13, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2b34:
	/* 0x2b34: movzx  eax,BYTE PTR [r12+0x1] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_R12, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 1ULL);
x86_l_2b3a:
	/* 0x2b3a: mov    r14d,DWORD PTR [r12+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R14, X86_R12, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2b3f:
	/* 0x2b3f: mov    ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RCX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2b42:
	/* 0x2b42: and    ecx,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2b45:
	/* 0x2b45: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2b47:
	/* 0x2b47: cmovns ecx,r14d */
	X86_SIM_RUN_OP(X86_OP_CMOV, X86_RCX, X86_R14, X86_WIDTH_32, X86_CC_NS, 0);
x86_l_2b4b:
	/* 0x2b4b: mov    edx,eax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_RAX, X86_WIDTH_32, 0, 0);
x86_l_2b4d:
	/* 0x2b4d: and    edx,0x7f */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 127ULL);
x86_l_2b50:
	/* 0x2b50: dec    edx */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_2b52:
	/* 0x2b52: cmp    edx,0x4 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_32, 0, 4ULL);
x86_l_2b55:
	/* 0x2b55: ja     2c0b <perf_unwind_native+0x2c0b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2b55, 0x2c0b, x86_l_2c0b);
x86_l_2b5b:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RDX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b80ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b78ULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2b6eULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2c0bULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RDX, 0x2bb0ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_2b69:
	/* 0x2b69: mov    rsi,r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RSI, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2b6c:
	/* 0x2b6c: jmp    rdx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RDX);
		switch (X86_SIM_L_REG_TAG(X86_RDX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x2b6eULL: goto x86_l_2b6e;
			case 0x2b78ULL: goto x86_l_2b78;
			case 0x2b80ULL: goto x86_l_2b80;
			case 0x2bb0ULL: goto x86_l_2bb0;
			case 0x2c0bULL: goto x86_l_2c0b;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b6e:
	/* 0x2b6e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b73:
	/* 0x2b73: mov    QWORD PTR [rsp+0x50],rdx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b78:
	/* 0x2b78: mov    rdx,QWORD PTR [rsp+0x50] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_2b7d:
	/* 0x2b7d: mov    rsi,QWORD PTR [rdx] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RSI, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b80:
	/* 0x2b80: movsxd rdx,ecx */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_RCX, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2b83:
	/* 0x2b83: add    rdx,rsi */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RDX, X86_RSI, X86_WIDTH_64, X86_ALU_ADD, 0);
x86_l_2b86:
	/* 0x2b86: test   al,al */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_8, 0, 0);
x86_l_2b88:
	/* 0x2b88: jns    2bf5 <perf_unwind_native+0x2bf5> */
	X86_SIM_X86_JCC(X86_CC_NS, 0x2b88, 0x2bf5, x86_l_2bf5);
x86_l_2b8a:
	/* 0x2b8a: lea    rdi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b8f:
	/* 0x2b8f: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2b94:
	/* 0x2b94: call   2b99 <perf_unwind_native+0x2b99> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2b99:
	/* 0x2b99: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2b9c:
	/* 0x2b9c: jne    2c0b <perf_unwind_native+0x2c0b> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2b9c, 0x2c0b, x86_l_2c0b);
x86_l_2b9e:
	/* 0x2b9e: shl    r14d,0x3 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SHL, 3ULL);
x86_l_2ba2:
	/* 0x2ba2: and    r14d,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 56ULL);
x86_l_2ba6:
	/* 0x2ba6: add    r14,QWORD PTR [rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_R14, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 48ULL);
x86_l_2bab:
	/* 0x2bab: mov    rdx,r14 */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RDX, X86_R14, X86_WIDTH_64, 0, 0);
x86_l_2bae:
	/* 0x2bae: jmp    2bf5 <perf_unwind_native+0x2bf5> */
	X86_SIM_X86_JMP(0x2bae, 0x2bf5, x86_l_2bf5);
x86_l_2bb0:
	/* 0x2bb0: mov    eax,r14d */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_RAX, X86_R14, X86_WIDTH_32, 0, 0);
x86_l_2bb3:
	/* 0x2bb3: and    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 15ULL);
x86_l_2bb6:
	/* 0x2bb6: cmp    eax,0xf */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_32, 0, 15ULL);
x86_l_2bb9:
	/* 0x2bb9: ja     2c0b <perf_unwind_native+0x2c0b> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2bb9, 0x2c0b, x86_l_2c0b);
x86_l_2bbb:
	/* Capture image-bound code identity before scheduled instructions. */
	switch (X86_SIM_L_READ_REG(X86_RAX) << 2) {
	case 0ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2be3ULL); break;
	case 4ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 8ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 12ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 16ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 20ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 24ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 28ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 32ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 36ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2bcbULL); break;
	case 40ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 44ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2bd2ULL); break;
	case 48ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 52ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 56ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2c0bULL); break;
	case 60ULL: X86_SIM_X86_CODE_ADDRESS(X86_RAX, 0x2bd9ULL); break;
	default: __x86_sim_unresolved_indirect_target();
	}
x86_l_2bc9:
	/* 0x2bc9: jmp    rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x2bcbULL: goto x86_l_2bcb;
			case 0x2bd2ULL: goto x86_l_2bd2;
			case 0x2bd9ULL: goto x86_l_2bd9;
			case 0x2be3ULL: goto x86_l_2be3;
			case 0x2c0bULL: goto x86_l_2c0b;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2bcb:
	/* 0x2bcb: mov    rax,QWORD PTR [rsp+0x68] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 104ULL);
x86_l_2bd0:
	/* 0x2bd0: jmp    2bde <perf_unwind_native+0x2bde> */
	X86_SIM_X86_JMP(0x2bd0, 0x2bde, x86_l_2bde);
x86_l_2bd2:
	/* 0x2bd2: mov    rax,QWORD PTR [rsp+0x60] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_2bd7:
	/* 0x2bd7: jmp    2bde <perf_unwind_native+0x2bde> */
	X86_SIM_X86_JMP(0x2bd7, 0x2bde, x86_l_2bde);
x86_l_2bd9:
	/* 0x2bd9: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2bde:
	/* 0x2bde: mov    QWORD PTR [rsp+0x58],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2be3:
	/* 0x2be3: sar    r14d,1 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_SAR, 1ULL);
x86_l_2be6:
	/* 0x2be6: and    r14d,0xfffffff8 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_ALU_AND, 4294967288ULL);
x86_l_2bea:
	/* 0x2bea: movsxd rdx,r14d */
	X86_SIM_RUN_OP(X86_OP_MOVSX_REG, X86_RDX, X86_R14, X86_WIDTH_64, X86_WIDTH_32, 0);
x86_l_2bed:
	/* 0x2bed: mov    rax,QWORD PTR [rsp+0x58] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_2bf2:
	/* 0x2bf2: add    rdx,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM, X86_RDX, X86_RAX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 0ULL);
x86_l_2bf5:
	/* 0x2bf5: test   rdx,rdx */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64, 0, 0);
x86_l_2bf8:
	/* 0x2bf8: je     2c0b <perf_unwind_native+0x2c0b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2bf8, 0x2c0b, x86_l_2c0b);
x86_l_2bfa:
	/* 0x2bfa: mov    rdi,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2bff:
	/* 0x2bff: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2c04:
	/* 0x2c04: call   2c09 <perf_unwind_native+0x2c09> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c09:
	/* 0x2c09: jmp    2c1e <perf_unwind_native+0x2c1e> */
	X86_SIM_X86_JMP(0x2c09, 0x2c1e, x86_l_2c1e);
x86_l_2c0b:
	/* 0x2c0b: cmp    BYTE PTR [r12],0x3 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 3ULL);
x86_l_2c10:
	/* 0x2c10: jne    2c1e <perf_unwind_native+0x2c1e> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c10, 0x2c1e, x86_l_2c1e);
x86_l_2c12:
	/* 0x2c12: mov    rax,QWORD PTR [rsp+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c17:
	/* 0x2c17: mov    QWORD PTR [rax],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c1e:
	/* 0x2c1e: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2c21:
	/* 0x2c21: mov    rdi,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2c26:
	/* 0x2c26: je     b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c26, 0xb4d, x86_l_b4d);
x86_l_2c2c:
	/* 0x2c2c: lea    rdx,[r13-0x8] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551608ULL);
x86_l_2c30:
	/* 0x2c30: mov    esi,0x8 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_32, 0, 8ULL);
x86_l_2c35:
	/* 0x2c35: call   2c3a <perf_unwind_native+0x2c3a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_probe_read_user);
x86_l_2c3a:
	/* 0x2c3a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c3d:
	/* 0x2c3d: jne    b4d <perf_unwind_native+0xb4d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c3d, 0xb4d, x86_l_b4d);
x86_l_2c43:
	/* 0x2c43: mov    QWORD PTR [rbp+0xed8],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3800ULL);
x86_l_2c4a:
	/* 0x2c4a: mov    BYTE PTR [rbp+0xf30],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16698832846849ULL);
x86_l_2c51:
	/* 0x2c51: mov    DWORD PTR [rsp+0x30],0x6 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430214ULL);
x86_l_2c59:
	/* 0x2c59: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2c60:
	/* 0x2c60: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c65:
	/* 0x2c65: call   2c6a <perf_unwind_native+0x2c6a> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2c6a:
	/* 0x2c6a: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c6d:
	/* 0x2c6d: je     2c72 <perf_unwind_native+0x2c72> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c6d, 0x2c72, x86_l_2c72);
x86_l_2c6f:
	/* 0x2c6f: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2c72:
	/* 0x2c72: mov    rax,QWORD PTR [rsp+0x70] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_2c77:
	/* 0x2c77: mov    r13,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c7a:
	/* 0x2c7a: test   r13,r13 */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64, 0, 0);
x86_l_2c7d:
	/* 0x2c7d: je     2d93 <perf_unwind_native+0x2d93> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c7d, 0x2d93, x86_l_2d93);
x86_l_2c83:
	/* 0x2c83: movabs rax,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2c8d:
	/* 0x2c8d: cmp    r13,rax */
	X86_SIM_RUN_OP(X86_OP_CMP_REG, X86_R13, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2c90:
	/* 0x2c90: ja     bc6 <perf_unwind_native+0xbc6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2c90, 0xbc6, x86_l_bc6);
x86_l_2c96:
	/* 0x2c96: cmp    r13,0x1000 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, 0, 4096ULL);
x86_l_2c9d:
	/* 0x2c9d: jb     be4 <perf_unwind_native+0xbe4> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2c9d, 0xbe4, x86_l_be4);
x86_l_2ca3:
	/* 0x2ca3: mov    eax,DWORD PTR [rbp+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ca6:
	/* 0x2ca6: mov    DWORD PTR [rsp+0x80],0x60 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 549755813984ULL);
x86_l_2cb1:
	/* 0x2cb1: movbe  DWORD PTR [rsp+0x84],eax */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 132ULL);
x86_l_2cba:
	/* 0x2cba: movbe  QWORD PTR [rsp+0x88],r13 */
	X86_SIM_RUN_OP(X86_OP_MOVBE_STORE, X86_RSP, X86_R13, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 136ULL);
x86_l_2cc4:
	/* 0x2cc4: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)pid_page_to_mapping_info));
x86_l_2ccb:
	/* 0x2ccb: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2cd3:
	/* 0x2cd3: call   2cd8 <perf_unwind_native+0x2cd8> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2cd8:
	/* 0x2cd8: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2cdb:
	/* 0x2cdb: je     2db0 <perf_unwind_native+0x2db0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cdb, 0x2db0, x86_l_2db0);
x86_l_2ce1:
	/* 0x2ce1: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ce5:
	/* 0x2ce5: movabs rcx,0xffffffffffffff */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_64, 0, 72057594037927935ULL);
x86_l_2cef:
	/* 0x2cef: and    rcx,r12 */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_AND, 0);
x86_l_2cf2:
	/* 0x2cf2: mov    QWORD PTR [rbp+0xf20],rcx */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3872ULL);
x86_l_2cf9:
	/* 0x2cf9: shr    r12,0x38 */
	X86_SIM_RUN_OP(X86_OP_ALU_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, X86_ALU_SHR, 56ULL);
x86_l_2cfd:
	/* 0x2cfd: mov    rax,QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d00:
	/* 0x2d00: mov    QWORD PTR [rbp+0xf10],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3856ULL);
x86_l_2d07:
	/* 0x2d07: sub    r13,rcx */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R13, X86_RCX, X86_WIDTH_64, X86_ALU_SUB, 0);
x86_l_2d0a:
	/* 0x2d0a: mov    QWORD PTR [rbp+0xf18],r13 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RBP, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 3864ULL);
x86_l_2d11:
	/* 0x2d11: cmp    r12,0x1 */
	X86_SIM_RUN_OP(X86_OP_CMP_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_64, 0, 1ULL);
x86_l_2d15:
	/* 0x2d15: jne    2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d15, 0x2da6, x86_l_2da6);
x86_l_2d1b:
	/* 0x2d1b: mov    QWORD PTR [rsp+0x80],rax */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2d23:
	/* 0x2d23: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)interpreter_offsets));
x86_l_2d2a:
	/* 0x2d2a: lea    rsi,[rsp+0x80] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_2d32:
	/* 0x2d32: call   2d37 <perf_unwind_native+0x2d37> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d37:
	/* 0x2d37: mov    r12d,0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R12, X86_REG_NONE, X86_WIDTH_32, 0, 1ULL);
x86_l_2d3d:
	/* 0x2d3d: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d40:
	/* 0x2d40: je     2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d40, 0x2da6, x86_l_2da6);
x86_l_2d42:
	/* 0x2d42: mov    r14,rax */
	X86_SIM_RUN_OP(X86_OP_MOV_REG, X86_R14, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d45:
	/* 0x2d45: cmp    QWORD PTR [rax],r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_RAX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d48:
	/* 0x2d48: ja     2d50 <perf_unwind_native+0x2d50> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d48, 0x2d50, x86_l_2d50);
x86_l_2d4a:
	/* 0x2d4a: cmp    QWORD PTR [r14+0x8],r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d4e:
	/* 0x2d4e: jae    2d5c <perf_unwind_native+0x2d5c> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x2d4e, 0x2d5c, x86_l_2d5c);
x86_l_2d50:
	/* 0x2d50: cmp    QWORD PTR [r14+0x10],r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d54:
	/* 0x2d54: ja     2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_A, 0x2d54, 0x2da6, x86_l_2da6);
x86_l_2d56:
	/* 0x2d56: cmp    QWORD PTR [r14+0x18],r13 */
	X86_SIM_RUN_OP(X86_OP_CMP_MEM_REG, X86_R14, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2d5a:
	/* 0x2d5a: jb     2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d5a, 0x2da6, x86_l_2da6);
x86_l_2d5c:
	/* 0x2d5c: mov    eax,DWORD PTR [rbp+0x1380] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RAX, X86_RBP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 4992ULL);
x86_l_2d62:
	/* 0x2d62: mov    ecx,DWORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2d66:
	/* 0x2d66: bt     eax,ecx */
	X86_SIM_RUN_OP(X86_OP_BT, X86_RAX, X86_RCX, X86_WIDTH_32, 0, 0);
x86_l_2d69:
	/* 0x2d69: jb     2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d69, 0x2da6, x86_l_2da6);
x86_l_2d6b:
	/* 0x2d6b: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_2d73:
	/* 0x2d73: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, X86_REG_NONE, X86_WIDTH_64, 0, ((__u64)(long)metrics));
x86_l_2d7a:
	/* 0x2d7a: lea    rsi,[rsp+0x30] */
	X86_SIM_RUN_OP(X86_OP_LEA, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2d7f:
	/* 0x2d7f: call   2d84 <perf_unwind_native+0x2d84> */
	X86_SIM_RUN_OP(X86_OP_CALL_HELPER, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_64, 0, X86_SIM_HELPER_bpf_map_lookup_elem);
x86_l_2d84:
	/* 0x2d84: test   rax,rax */
	X86_SIM_RUN_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64, 0, 0);
x86_l_2d87:
	/* 0x2d87: je     2d8c <perf_unwind_native+0x2d8c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d87, 0x2d8c, x86_l_2d8c);
x86_l_2d89:
	/* 0x2d89: inc    QWORD PTR [rax] */
	X86_SIM_RUN_OP(X86_OP_ALU_MEM_UNARY, X86_RAX, X86_REG_NONE, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 0ULL);
x86_l_2d8c:
	/* 0x2d8c: movzx  r12d,WORD PTR [r14+0x20] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32ULL);
x86_l_2d91:
	/* 0x2d91: jmp    2da6 <perf_unwind_native+0x2da6> */
	X86_SIM_X86_JMP(0x2d91, 0x2da6, x86_l_2da6);
x86_l_2d93:
	/* 0x2d93: mov    DWORD PTR [rbp+0xf28],0x1 */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108481ULL);
x86_l_2d9d:
	/* 0x2d9d: mov    r15d,0xfad */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4013ULL);
x86_l_2da3:
	/* 0x2da3: xor    r12d,r12d */
	X86_SIM_RUN_OP(X86_OP_ALU_REG, X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR, 0);
x86_l_2da6:
	/* 0x2da6: mov    r13,QWORD PTR [rsp+0x48] */
	X86_SIM_RUN_OP(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 72ULL);
x86_l_2dab:
	/* 0x2dab: jmp    5fd <perf_unwind_native+0x5fd> */
	X86_SIM_X86_JMP(0x2dab, 0x5fd, x86_l_5fd);
x86_l_2db0:
	/* 0x2db0: mov    DWORD PTR [rbp+0xf28],0xc */
	X86_SIM_RUN_OP(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16664473108492ULL);
x86_l_2dba:
	/* 0x2dba: mov    r15d,0xfac */
	X86_SIM_RUN_OP(X86_OP_MOV_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_32, 0, 4012ULL);
x86_l_2dc0:
	/* 0x2dc0: jmp    2da3 <perf_unwind_native+0x2da3> */
	X86_SIM_X86_JMP(0x2dc0, 0x2da3, x86_l_2da3);
x86_l_2dc2:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
