
extern void *bpf_this_cpu_ptr(const void *);
typedef unsigned __kprog_percpu_u32 __attribute__((aligned(1),may_alias));
static __attribute__((always_inline)) inline void *
__kprog_percpu_array_lookup(void *map,const void *key) {
    unsigned index=*(const __kprog_percpu_u32 *)key;
    if (index>=*(const unsigned *)((const char *)map+68)) return (void *)0;
    unsigned mask=*(const unsigned *)((const char *)map+292);
    const void *base=*(void *const *)((const char *)map+304+
        (unsigned long)(index&mask)*sizeof(void *));
    return bpf_this_cpu_ptr(base);
}
extern unsigned char __kprog_percpu_map_0[] __asm__("counts");
extern unsigned char __kprog_percpu_map_1[] __asm__("same");
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_percpu_map_0 || map == __kprog_percpu_map_1) return __kprog_percpu_array_lookup(map,key);

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
