; ModuleID = '/var/tmp/kprog-tmp/perf/lpm-c-lto/fixed-entry_select.o.lpm.1.c'
source_filename = "/var/tmp/kprog-tmp/perf/lpm-c-lto/fixed-entry_select.o.lpm.1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse noredzone nounwind
define ptr @__native_link_typed_lpm_lookup_1(ptr noundef %0, ptr nocapture noundef readonly %1) local_unnamed_addr #0 {
  %3 = load i32, ptr %1, align 1, !tbaa !3
  %4 = icmp ugt i32 %3, 96
  br i1 %4, label %70, label %5

5:                                                ; preds = %2
  %6 = getelementptr inbounds i8, ptr %0, i64 288
  %7 = getelementptr i8, ptr %1, i64 4
  %8 = load volatile ptr, ptr %6, align 8, !tbaa !6
  %9 = icmp eq ptr %8, null
  br i1 %9, label %65, label %10

10:                                               ; preds = %5
  %11 = load i64, ptr %7, align 1, !tbaa !3
  %12 = getelementptr i8, ptr %1, i64 12
  br label %13

13:                                               ; preds = %10, %45
  %14 = phi ptr [ %8, %10 ], [ %63, %45 ]
  %15 = phi ptr [ null, %10 ], [ %50, %45 ]
  %16 = getelementptr inbounds i8, ptr %14, i64 16
  %17 = load i32, ptr %16, align 1, !tbaa !3
  %18 = tail call i32 @llvm.umin.i32(i32 %17, i32 %3)
  %19 = getelementptr inbounds i8, ptr %14, i64 24
  %20 = load i64, ptr %19, align 1, !tbaa !3
  %21 = xor i64 %11, %20
  %22 = tail call i64 @llvm.bswap.i64(i64 %21)
  %23 = icmp ne i64 %21, 0
  %24 = tail call i64 @llvm.ctlz.i64(i64 %22, i1 true), !range !8
  %25 = trunc i64 %24 to i32
  %26 = select i1 %23, i32 %25, i32 64
  %27 = icmp uge i32 %26, %18
  %28 = or i1 %23, %27
  %29 = select i1 %27, i32 %18, i32 %25
  br i1 %28, label %42, label %30

30:                                               ; preds = %13
  %31 = getelementptr inbounds i8, ptr %14, i64 32
  %32 = load i32, ptr %31, align 1, !tbaa !3
  %33 = load i32, ptr %12, align 1, !tbaa !3
  %34 = xor i32 %33, %32
  %35 = tail call i32 @llvm.bswap.i32(i32 %34)
  %36 = icmp eq i32 %34, 0
  %37 = tail call i32 @llvm.ctlz.i32(i32 %35, i1 true), !range !9
  %38 = or disjoint i32 %37, 64
  %39 = select i1 %36, i32 96, i32 %38
  %40 = tail call i32 @llvm.umin.i32(i32 %39, i32 %18)
  %41 = icmp eq i32 %40, 96
  br i1 %41, label %65, label %42

42:                                               ; preds = %13, %30
  %43 = phi i32 [ %40, %30 ], [ %29, %13 ]
  %44 = icmp ult i32 %43, %17
  br i1 %44, label %65, label %45

45:                                               ; preds = %42
  %46 = getelementptr inbounds i8, ptr %14, i64 20
  %47 = load i32, ptr %46, align 1, !tbaa !3
  %48 = and i32 %47, 1
  %49 = icmp eq i32 %48, 0
  %50 = select i1 %49, ptr %14, ptr %15
  %51 = lshr i32 %17, 3
  %52 = zext nneg i32 %51 to i64
  %53 = getelementptr i8, ptr %7, i64 %52
  %54 = load i8, ptr %53, align 1, !tbaa !3
  %55 = zext i8 %54 to i32
  %56 = and i32 %17, 7
  %57 = xor i32 %56, 7
  %58 = lshr i32 %55, %57
  %59 = shl nuw nsw i32 %58, 3
  %60 = and i32 %59, 8
  %61 = zext nneg i32 %60 to i64
  %62 = getelementptr inbounds i8, ptr %14, i64 %61
  %63 = load volatile ptr, ptr %62, align 8, !tbaa !6
  %64 = icmp eq ptr %63, null
  br i1 %64, label %65, label %13

65:                                               ; preds = %45, %30, %42, %5
  %66 = phi ptr [ null, %5 ], [ %15, %42 ], [ %14, %30 ], [ %50, %45 ]
  %67 = icmp eq ptr %66, null
  %68 = getelementptr inbounds i8, ptr %66, i64 36
  %69 = select i1 %67, ptr null, ptr %68
  br label %70

70:                                               ; preds = %2, %65
  %71 = phi ptr [ %69, %65 ], [ null, %2 ]
  ret ptr %71
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #2

attributes #0 = { nofree norecurse noredzone nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!3 = !{!4, !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"any pointer", !4, i64 0}
!8 = !{i64 0, i64 65}
!9 = !{i32 0, i32 33}
