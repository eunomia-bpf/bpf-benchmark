; ModuleID = '/var/tmp/kprog-tmp/perf/lpm-c-lto/fixed-entry_select.o.lpm.1.c'
source_filename = "/var/tmp/kprog-tmp/perf/lpm-c-lto/fixed-entry_select.o.lpm.1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse noredzone nounwind
define ptr @__native_link_typed_lpm_lookup_1(ptr noundef %0, ptr nocapture noundef readonly %1) local_unnamed_addr #0 {
  %3 = load i32, ptr %1, align 1, !tbaa !3
  %4 = icmp ugt i32 %3, 96
  br i1 %4, label %108, label %5

5:                                                ; preds = %2
  %6 = getelementptr inbounds i8, ptr %0, i64 288
  %7 = getelementptr i8, ptr %1, i64 4
  %8 = load volatile ptr, ptr %6, align 8, !tbaa !6
  %9 = icmp eq ptr %8, null
  br i1 %9, label %103, label %10

10:                                               ; preds = %5, %83
  %11 = phi ptr [ %101, %83 ], [ %8, %5 ]
  %12 = phi ptr [ %88, %83 ], [ null, %5 ]
  %13 = getelementptr inbounds i8, ptr %11, i64 16
  %14 = load i32, ptr %13, align 1, !tbaa !3
  %15 = icmp ugt i32 %14, %3
  br i1 %15, label %103, label %16

16:                                               ; preds = %10
  %17 = getelementptr inbounds i8, ptr %11, i64 24
  %18 = icmp ugt i32 %14, 63
  br i1 %18, label %19, label %25

19:                                               ; preds = %16
  %20 = load i64, ptr %17, align 1, !tbaa !3
  %21 = load i64, ptr %7, align 1, !tbaa !3
  %22 = icmp eq i64 %20, %21
  br i1 %22, label %23, label %103

23:                                               ; preds = %19
  %24 = add i32 %14, -64
  br label %25

25:                                               ; preds = %23, %16
  %26 = phi i32 [ %24, %23 ], [ %14, %16 ]
  %27 = phi i64 [ 8, %23 ], [ 0, %16 ]
  %28 = icmp ugt i32 %26, 31
  br i1 %28, label %29, label %41

29:                                               ; preds = %25, %37
  %30 = phi i64 [ %39, %37 ], [ %27, %25 ]
  %31 = phi i32 [ %38, %37 ], [ %26, %25 ]
  %32 = getelementptr inbounds i8, ptr %17, i64 %30
  %33 = load i32, ptr %32, align 1, !tbaa !3
  %34 = getelementptr inbounds i8, ptr %7, i64 %30
  %35 = load i32, ptr %34, align 1, !tbaa !3
  %36 = icmp eq i32 %33, %35
  br i1 %36, label %37, label %103

37:                                               ; preds = %29
  %38 = add i32 %31, -32
  %39 = add nuw nsw i64 %30, 4
  %40 = icmp ugt i32 %38, 31
  br i1 %40, label %29, label %41, !llvm.loop !8

41:                                               ; preds = %37, %25
  %42 = phi i32 [ %26, %25 ], [ %38, %37 ]
  %43 = phi i64 [ %27, %25 ], [ %39, %37 ]
  %44 = icmp ugt i32 %42, 15
  br i1 %44, label %45, label %54

45:                                               ; preds = %41
  %46 = getelementptr inbounds i8, ptr %17, i64 %43
  %47 = load i16, ptr %46, align 1, !tbaa !3
  %48 = getelementptr inbounds i8, ptr %7, i64 %43
  %49 = load i16, ptr %48, align 1, !tbaa !3
  %50 = icmp eq i16 %47, %49
  br i1 %50, label %51, label %103

51:                                               ; preds = %45
  %52 = add nsw i32 %42, -16
  %53 = or disjoint i64 %43, 2
  br label %54

54:                                               ; preds = %51, %41
  %55 = phi i32 [ %52, %51 ], [ %42, %41 ]
  %56 = phi i64 [ %53, %51 ], [ %43, %41 ]
  %57 = icmp ugt i32 %55, 7
  br i1 %57, label %58, label %67

58:                                               ; preds = %54
  %59 = getelementptr inbounds i8, ptr %17, i64 %56
  %60 = load i8, ptr %59, align 1, !tbaa !3
  %61 = getelementptr inbounds i8, ptr %7, i64 %56
  %62 = load i8, ptr %61, align 1, !tbaa !3
  %63 = icmp eq i8 %60, %62
  br i1 %63, label %64, label %103

64:                                               ; preds = %58
  %65 = add nsw i32 %55, -8
  %66 = add i64 %56, 1
  br label %67

67:                                               ; preds = %64, %54
  %68 = phi i32 [ %65, %64 ], [ %55, %54 ]
  %69 = phi i64 [ %66, %64 ], [ %56, %54 ]
  %70 = icmp eq i32 %68, 0
  br i1 %70, label %81, label %71

71:                                               ; preds = %67
  %72 = getelementptr inbounds i8, ptr %17, i64 %69
  %73 = load i8, ptr %72, align 1, !tbaa !3
  %74 = getelementptr inbounds i8, ptr %7, i64 %69
  %75 = load i8, ptr %74, align 1, !tbaa !3
  %76 = xor i8 %75, %73
  %77 = zext i8 %76 to i32
  %78 = sub nuw nsw i32 8, %68
  %79 = lshr i32 %77, %78
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %81, label %103

81:                                               ; preds = %67, %71
  %82 = icmp eq i32 %14, 96
  br i1 %82, label %103, label %83

83:                                               ; preds = %81
  %84 = getelementptr inbounds i8, ptr %11, i64 20
  %85 = load i32, ptr %84, align 1, !tbaa !3
  %86 = and i32 %85, 1
  %87 = icmp eq i32 %86, 0
  %88 = select i1 %87, ptr %11, ptr %12
  %89 = lshr i32 %14, 3
  %90 = zext nneg i32 %89 to i64
  %91 = getelementptr i8, ptr %7, i64 %90
  %92 = load i8, ptr %91, align 1, !tbaa !3
  %93 = zext i8 %92 to i32
  %94 = and i32 %14, 7
  %95 = xor i32 %94, 7
  %96 = lshr i32 %93, %95
  %97 = shl nuw nsw i32 %96, 3
  %98 = and i32 %97, 8
  %99 = zext nneg i32 %98 to i64
  %100 = getelementptr inbounds i8, ptr %11, i64 %99
  %101 = load volatile ptr, ptr %100, align 8, !tbaa !6
  %102 = icmp eq ptr %101, null
  br i1 %102, label %103, label %10

103:                                              ; preds = %83, %71, %10, %81, %19, %45, %58, %29, %5
  %104 = phi ptr [ null, %5 ], [ %12, %29 ], [ %88, %83 ], [ %12, %71 ], [ %12, %10 ], [ %11, %81 ], [ %12, %19 ], [ %12, %45 ], [ %12, %58 ]
  %105 = icmp eq ptr %104, null
  %106 = getelementptr inbounds i8, ptr %104, i64 36
  %107 = select i1 %105, ptr null, ptr %106
  br label %108

108:                                              ; preds = %2, %103
  %109 = phi ptr [ %107, %103 ], [ null, %2 ]
  ret ptr %109
}

attributes #0 = { nofree norecurse noredzone nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!3 = !{!4, !4, i64 0}
!4 = !{!"omnipotent char", !5, i64 0}
!5 = !{!"Simple C/C++ TBAA"}
!6 = !{!7, !7, i64 0}
!7 = !{!"any pointer", !4, i64 0}
!8 = distinct !{!8, !9}
!9 = !{!"llvm.loop.mustprogress"}
