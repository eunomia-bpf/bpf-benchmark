; ModuleID = '/var/tmp/kprog-tmp/perf/lpm-c-lto/mixed-entry.o.lpm.1.c'
source_filename = "/var/tmp/kprog-tmp/perf/lpm-c-lto/mixed-entry.o.lpm.1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse noredzone nounwind
define ptr @__native_link_typed_lpm_lookup_1(ptr noundef %0, ptr nocapture noundef readonly %1) local_unnamed_addr #0 {
  %3 = getelementptr inbounds i8, ptr %0, i64 392
  %4 = load i64, ptr %3, align 8, !tbaa !3
  %5 = getelementptr inbounds i8, ptr %0, i64 384
  %6 = load i64, ptr %5, align 8, !tbaa !3
  %7 = load i32, ptr %1, align 1, !tbaa !7
  %8 = zext i32 %7 to i64
  %9 = icmp ult i64 %6, %8
  br i1 %9, label %128, label %10

10:                                               ; preds = %2
  %11 = getelementptr inbounds i8, ptr %0, i64 288
  %12 = getelementptr i8, ptr %1, i64 4
  %13 = load volatile ptr, ptr %11, align 8, !tbaa !8
  %14 = icmp eq ptr %13, null
  br i1 %14, label %122, label %15

15:                                               ; preds = %10
  %16 = icmp ugt i64 %4, 7
  br label %17

17:                                               ; preds = %15, %102
  %18 = phi ptr [ %13, %15 ], [ %120, %102 ]
  %19 = phi ptr [ null, %15 ], [ %107, %102 ]
  %20 = getelementptr inbounds i8, ptr %18, i64 16
  %21 = load i32, ptr %20, align 1, !tbaa !7
  %22 = tail call i32 @llvm.umin.i32(i32 %21, i32 %7)
  %23 = getelementptr inbounds i8, ptr %18, i64 24
  br i1 %16, label %24, label %36

24:                                               ; preds = %17
  %25 = load i64, ptr %23, align 1, !tbaa !7
  %26 = load i64, ptr %12, align 1, !tbaa !7
  %27 = xor i64 %26, %25
  %28 = tail call i64 @llvm.bswap.i64(i64 %27)
  %29 = icmp ne i64 %27, 0
  %30 = tail call i64 @llvm.ctlz.i64(i64 %28, i1 true), !range !10
  %31 = trunc i64 %30 to i32
  %32 = select i1 %29, i32 %31, i32 64
  %33 = icmp uge i32 %32, %22
  %34 = or i1 %29, %33
  %35 = select i1 %33, i32 %22, i32 %31
  br i1 %34, label %96, label %36

36:                                               ; preds = %24, %17
  %37 = phi i64 [ 8, %24 ], [ 0, %17 ]
  %38 = phi i32 [ 64, %24 ], [ 0, %17 ]
  br label %39

39:                                               ; preds = %36, %44
  %40 = phi i64 [ %42, %44 ], [ %37, %36 ]
  %41 = phi i32 [ %54, %44 ], [ %38, %36 ]
  %42 = add i64 %40, 4
  %43 = icmp ugt i64 %42, %4
  br i1 %43, label %57, label %44

44:                                               ; preds = %39
  %45 = getelementptr inbounds i8, ptr %23, i64 %40
  %46 = load i32, ptr %45, align 1, !tbaa !7
  %47 = getelementptr inbounds i8, ptr %12, i64 %40
  %48 = load i32, ptr %47, align 1, !tbaa !7
  %49 = xor i32 %48, %46
  %50 = tail call i32 @llvm.bswap.i32(i32 %49)
  %51 = icmp ne i32 %49, 0
  %52 = tail call i32 @llvm.ctlz.i32(i32 %50, i1 true), !range !11
  %53 = select i1 %51, i32 %52, i32 32
  %54 = add i32 %53, %41
  %55 = icmp uge i32 %54, %22
  %56 = or i1 %51, %55
  br i1 %56, label %94, label %39

57:                                               ; preds = %39
  %58 = or disjoint i64 %40, 2
  %59 = icmp ugt i64 %58, %4
  br i1 %59, label %76, label %60

60:                                               ; preds = %57
  %61 = getelementptr inbounds i8, ptr %23, i64 %40
  %62 = load i16, ptr %61, align 1, !tbaa !7
  %63 = getelementptr inbounds i8, ptr %12, i64 %40
  %64 = load i16, ptr %63, align 1, !tbaa !7
  %65 = xor i16 %64, %62
  %66 = tail call i16 @llvm.bswap.i16(i16 %65)
  %67 = zext i16 %66 to i32
  %68 = icmp ne i16 %65, 0
  %69 = tail call i32 @llvm.ctlz.i32(i32 %67, i1 true), !range !12
  %70 = add nsw i32 %69, -16
  %71 = select i1 %68, i32 %70, i32 16
  %72 = add i32 %71, %41
  %73 = icmp uge i32 %72, %22
  %74 = or i1 %68, %73
  %75 = tail call i32 @llvm.umin.i32(i32 %72, i32 %22)
  br i1 %74, label %96, label %76

76:                                               ; preds = %60, %57
  %77 = phi i64 [ %40, %57 ], [ %58, %60 ]
  %78 = phi i32 [ %41, %57 ], [ %72, %60 ]
  %79 = add i64 %77, 1
  %80 = icmp ugt i64 %79, %4
  br i1 %80, label %96, label %81

81:                                               ; preds = %76
  %82 = getelementptr inbounds i8, ptr %23, i64 %77
  %83 = load i8, ptr %82, align 1, !tbaa !7
  %84 = getelementptr inbounds i8, ptr %12, i64 %77
  %85 = load i8, ptr %84, align 1, !tbaa !7
  %86 = xor i8 %85, %83
  %87 = zext i8 %86 to i32
  %88 = icmp eq i8 %86, 0
  %89 = tail call i32 @llvm.ctlz.i32(i32 %87, i1 true), !range !13
  %90 = add nsw i32 %89, -24
  %91 = select i1 %88, i32 8, i32 %90
  %92 = add i32 %91, %78
  %93 = tail call i32 @llvm.umin.i32(i32 %92, i32 %22)
  br label %96

94:                                               ; preds = %44
  %95 = tail call i32 @llvm.umin.i32(i32 %54, i32 %22)
  br label %96

96:                                               ; preds = %94, %60, %24, %76, %81
  %97 = phi i32 [ %78, %76 ], [ %93, %81 ], [ %35, %24 ], [ %75, %60 ], [ %95, %94 ]
  %98 = zext i32 %97 to i64
  %99 = icmp eq i64 %6, %98
  br i1 %99, label %122, label %100

100:                                              ; preds = %96
  %101 = icmp ult i32 %97, %21
  br i1 %101, label %122, label %102

102:                                              ; preds = %100
  %103 = getelementptr inbounds i8, ptr %18, i64 20
  %104 = load i32, ptr %103, align 1, !tbaa !7
  %105 = and i32 %104, 1
  %106 = icmp eq i32 %105, 0
  %107 = select i1 %106, ptr %18, ptr %19
  %108 = lshr i32 %21, 3
  %109 = zext nneg i32 %108 to i64
  %110 = getelementptr i8, ptr %12, i64 %109
  %111 = load i8, ptr %110, align 1, !tbaa !7
  %112 = zext i8 %111 to i32
  %113 = and i32 %21, 7
  %114 = xor i32 %113, 7
  %115 = lshr i32 %112, %114
  %116 = shl nuw nsw i32 %115, 3
  %117 = and i32 %116, 8
  %118 = zext nneg i32 %117 to i64
  %119 = getelementptr inbounds i8, ptr %18, i64 %118
  %120 = load volatile ptr, ptr %119, align 8, !tbaa !8
  %121 = icmp eq ptr %120, null
  br i1 %121, label %122, label %17

122:                                              ; preds = %102, %96, %100, %10
  %123 = phi ptr [ null, %10 ], [ %19, %100 ], [ %18, %96 ], [ %107, %102 ]
  %124 = icmp eq ptr %123, null
  %125 = getelementptr inbounds i8, ptr %123, i64 24
  %126 = getelementptr inbounds i8, ptr %125, i64 %4
  %127 = select i1 %124, ptr null, ptr %126
  br label %128

128:                                              ; preds = %2, %122
  %129 = phi ptr [ %127, %122 ], [ null, %2 ]
  ret ptr %129
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #2

attributes #0 = { nofree norecurse noredzone nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!3 = !{!4, !4, i64 0}
!4 = !{!"long", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!9, !9, i64 0}
!9 = !{!"any pointer", !5, i64 0}
!10 = !{i64 0, i64 65}
!11 = !{i32 0, i32 33}
!12 = !{i32 16, i32 33}
!13 = !{i32 24, i32 33}
