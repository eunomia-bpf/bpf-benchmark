
/var/tmp/kprog-tmp/perf/helper-sharing/20/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	hists-0x4
       7: 74 2a                        	je	0x33 <__kprog_array_lookup+0x33>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	start-0x4
      10: 74 2a                        	je	0x3c <__kprog_array_lookup+0x3c>
      12: 8b 06                        	movl	(%rsi), %eax
      14: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      17: 73 2c                        	jae	0x45 <__kprog_array_lookup+0x45>
      19: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      1f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      25: 48 0f af c1                  	imulq	%rcx, %rax
      29: 48 01 f8                     	addq	%rdi, %rax
      2c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      32: c3                           	retq
      33: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3a <__kprog_array_lookup+0x3a>
		0000000000000036:  R_X86_64_REX_GOTPCRELX	hists-0x4
      3a: eb 14                        	jmp	0x50 <__kprog_hash_key_4>
      3c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x43 <__kprog_array_lookup+0x43>
		000000000000003f:  R_X86_64_REX_GOTPCRELX	start-0x4
      43: eb 0b                        	jmp	0x50 <__kprog_hash_key_4>
      45: 31 c0                        	xorl	%eax, %eax
      47: c3                           	retq
      48: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)

0000000000000050 <__kprog_hash_key_4>:
      50: b9 f3 be ad de               	movl	$0xdeadbef3, %ecx       # imm = 0xDEADBEF3
      55: 03 8f 40 03 00 00            	addl	0x340(%rdi), %ecx
      5b: 8b 06                        	movl	(%rsi), %eax
      5d: 01 c8                        	addl	%ecx, %eax
      5f: c4 e3 7b f0 d1 12            	rorxl	$0x12, %ecx, %edx
      65: f7 da                        	negl	%edx
      67: 31 d0                        	xorl	%edx, %eax
      69: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
      6f: 44 29 c0                     	subl	%r8d, %eax
      72: 31 c1                        	xorl	%eax, %ecx
      74: c4 63 7b f0 c0 07            	rorxl	$0x7, %eax, %r8d
      7a: 44 29 c1                     	subl	%r8d, %ecx
      7d: 31 ca                        	xorl	%ecx, %edx
      7f: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
      85: 44 29 c2                     	subl	%r8d, %edx
      88: 31 d0                        	xorl	%edx, %eax
      8a: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
      90: 44 29 c0                     	subl	%r8d, %eax
      93: 31 c1                        	xorl	%eax, %ecx
      95: c4 e3 7b f0 c0 12            	rorxl	$0x12, %eax, %eax
      9b: 29 c1                        	subl	%eax, %ecx
      9d: c4 e3 7b f0 c1 08            	rorxl	$0x8, %ecx, %eax
      a3: 31 d1                        	xorl	%edx, %ecx
      a5: 29 c1                        	subl	%eax, %ecx
      a7: 8b 97 38 03 00 00            	movl	0x338(%rdi), %edx
      ad: ff ca                        	decl	%edx
      af: 21 ca                        	andl	%ecx, %edx
      b1: 48 8b bf c0 01 00 00         	movq	0x1c0(%rdi), %rdi
      b8: 49 89 d0                     	movq	%rdx, %r8
      bb: 49 c1 e0 04                  	shlq	$0x4, %r8
      bf: eb 17                        	jmp	0xd8 <__kprog_hash_key_4+0x88>
      c1: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
      d0: 48 d1 e8                     	shrq	%rax
      d3: 48 39 d0                     	cmpq	%rdx, %rax
      d6: 74 22                        	je	0xfa <__kprog_hash_key_4+0xaa>
      d8: 4a 8b 04 07                  	movq	(%rdi,%r8), %rax
      dc: eb 05                        	jmp	0xe3 <__kprog_hash_key_4+0x93>
      de: 66 90                        	nop
      e0: 48 8b 00                     	movq	(%rax), %rax
      e3: a8 01                        	testb	$0x1, %al
      e5: 75 e9                        	jne	0xd0 <__kprog_hash_key_4+0x80>
      e7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
      ea: 75 f4                        	jne	0xe0 <__kprog_hash_key_4+0x90>
      ec: 44 8b 48 30                  	movl	0x30(%rax), %r9d
      f0: 44 3b 0e                     	cmpl	(%rsi), %r9d
      f3: 75 eb                        	jne	0xe0 <__kprog_hash_key_4+0x90>
      f5: 48 83 c0 38                  	addq	$0x38, %rax
      f9: c3                           	retq
      fa: 31 c0                        	xorl	%eax, %eax
      fc: c3                           	retq

Disassembly of section fentry/trusted:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 41 54                        	pushq	%r12
       6: 53                           	pushq	%rbx
       7: 48 83 ec 38                  	subq	$0x38, %rsp
       b: 48 c7 44 24 30 00 00 00 00   	movq	$0x0, 0x30(%rsp)
      14: 48 8b 47 08                  	movq	0x8(%rdi), %rax
      18: 4c 8b 67 10                  	movq	0x10(%rdi), %r12
      1c: 48 c7 44 24 28 11 00 00 00   	movq	$0x11, 0x28(%rsp)
      25: 48 c7 44 24 10 00 00 00 00   	movq	$0x0, 0x10(%rsp)
      2e: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
      37: 48 c7 44 24 20 00 00 00 00   	movq	$0x0, 0x20(%rsp)
      40: 48 85 c0                     	testq	%rax, %rax
      43: 79 10                        	jns	0x55 <trusted_x86_x86_sim_xdp+0x55>
      45: 48 3d 00 10 00 00            	cmpq	$0x1000, %rax           # imm = 0x1000
      4b: 72 08                        	jb	0x55 <trusted_x86_x86_sim_xdp+0x55>
      4d: 48 89 c1                     	movq	%rax, %rcx
      50: 83 39 00                     	cmpl	$0x0, (%rcx)
      53: 75 5e                        	jne	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      55: 48 89 c1                     	movq	%rax, %rcx
      58: 48 81 c1 f4 0a 00 00         	addq	$0xaf4, %rcx            # imm = 0xAF4
      5f: 78 0a                        	js	0x6b <trusted_x86_x86_sim_xdp+0x6b>
      61: 48 05 f0 0a 00 00            	addq	$0xaf0, %rax            # imm = 0xAF0
      67: 78 0c                        	js	0x75 <trusted_x86_x86_sim_xdp+0x75>
      69: eb 48                        	jmp	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      6b: 8b 09                        	movl	(%rcx), %ecx
      6d: 48 05 f0 0a 00 00            	addq	$0xaf0, %rax            # imm = 0xAF0
      73: 79 3e                        	jns	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      75: 48 3d ff 0f 00 00            	cmpq	$0xfff, %rax            # imm = 0xFFF
      7b: 77 0a                        	ja	0x87 <trusted_x86_x86_sim_xdp+0x87>
      7d: c7 44 24 04 00 00 00 00      	movl	$0x0, 0x4(%rsp)
      85: eb 2c                        	jmp	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      87: 8b 00                        	movl	(%rax), %eax
      89: 89 44 24 04                  	movl	%eax, 0x4(%rsp)
      8d: 85 c0                        	testl	%eax, %eax
      8f: 74 22                        	je	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      91: e8 00 00 00 00               	callq	0x96 <trusted_x86_x86_sim_xdp+0x96>
		0000000000000092:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      96: 48 8d 54 24 08               	leaq	0x8(%rsp), %rdx
      9b: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
      a0: 48 8d 74 24 04               	leaq	0x4(%rsp), %rsi
      a5: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xac <trusted_x86_x86_sim_xdp+0xac>
		00000000000000a8:  R_X86_64_REX_GOTPCRELX	start-0x4
      ac: 31 c9                        	xorl	%ecx, %ecx
      ae: e8 00 00 00 00               	callq	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
		00000000000000af:  R_X86_64_PLT32	bpf_map_update_elem-0x4
      b3: 31 c0                        	xorl	%eax, %eax
      b5: 4c 89 e1                     	movq	%r12, %rcx
      b8: 48 81 c1 f0 0a 00 00         	addq	$0xaf0, %rcx            # imm = 0xAF0
      bf: 79 02                        	jns	0xc3 <trusted_x86_x86_sim_xdp+0xc3>
      c1: 8b 01                        	movl	(%rcx), %eax
      c3: 48 8d 5c 24 08               	leaq	0x8(%rsp), %rbx
      c8: 89 44 24 08                  	movl	%eax, 0x8(%rsp)
      cc: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xd3 <trusted_x86_x86_sim_xdp+0xd3>
		00000000000000cf:  R_X86_64_REX_GOTPCRELX	hists-0x4
      d3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xda <trusted_x86_x86_sim_xdp+0xda>
		00000000000000d6:  R_X86_64_REX_GOTPCRELX	start-0x4
      da: 48 39 c7                     	cmpq	%rax, %rdi
      dd: 48 0f 44 f8                  	cmoveq	%rax, %rdi
      e1: 48 89 de                     	movq	%rbx, %rsi
      e4: e8 00 00 00 00               	callq	0xe9 <trusted_x86_x86_sim_xdp+0xe9>
		00000000000000e5:  R_X86_64_PLT32	.text+0x4c
      e9: 48 85 c0                     	testq	%rax, %rax
      ec: 0f 84 6c 04 00 00            	je	0x55e <trusted_x86_x86_sim_xdp+0x55e>
      f2: 49 89 c7                     	movq	%rax, %r15
      f5: e8 00 00 00 00               	callq	0xfa <trusted_x86_x86_sim_xdp+0xfa>
		00000000000000f6:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      fa: 49 89 c6                     	movq	%rax, %r14
      fd: 4d 2b 37                     	subq	(%r15), %r14
     100: 0f 88 49 04 00 00            	js	0x54f <trusted_x86_x86_sim_xdp+0x54f>
     106: c7 44 24 04 ff ff ff ff      	movl	$0xffffffff, 0x4(%rsp)  # imm = 0xFFFFFFFF
     10e: 4c 8d 7c 24 04               	leaq	0x4(%rsp), %r15
     113: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x11a <trusted_x86_x86_sim_xdp+0x11a>
		0000000000000116:  R_X86_64_REX_GOTPCRELX	hists-0x4
     11a: 4c 89 fe                     	movq	%r15, %rsi
     11d: e8 00 00 00 00               	callq	0x122 <trusted_x86_x86_sim_xdp+0x122>
		000000000000011e:  R_X86_64_PLT32	.text+0x4c
     122: 48 85 c0                     	testq	%rax, %rax
     125: 74 02                        	je	0x129 <trusted_x86_x86_sim_xdp+0x129>
     127: eb 3e                        	jmp	0x167 <trusted_x86_x86_sim_xdp+0x167>
     129: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x130 <trusted_x86_x86_sim_xdp+0x130>
		000000000000012c:  R_X86_64_REX_GOTPCRELX	hists-0x4
     130: 48 8b 15 00 00 00 00         	movq	(%rip), %rdx            # 0x137 <trusted_x86_x86_sim_xdp+0x137>
		0000000000000133:  R_X86_64_REX_GOTPCRELX	zero-0x4
     137: b9 01 00 00 00               	movl	$0x1, %ecx
     13c: 4c 89 fe                     	movq	%r15, %rsi
     13f: e8 00 00 00 00               	callq	0x144 <trusted_x86_x86_sim_xdp+0x144>
		0000000000000140:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     144: 48 85 c0                     	testq	%rax, %rax
     147: 74 0a                        	je	0x153 <trusted_x86_x86_sim_xdp+0x153>
     149: 48 83 f8 ef                  	cmpq	$-0x11, %rax
     14d: 0f 85 fc 03 00 00            	jne	0x54f <trusted_x86_x86_sim_xdp+0x54f>
     153: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x15a <trusted_x86_x86_sim_xdp+0x15a>
		0000000000000156:  R_X86_64_REX_GOTPCRELX	hists-0x4
     15a: 4c 89 fe                     	movq	%r15, %rsi
     15d: e8 00 00 00 00               	callq	0x162 <trusted_x86_x86_sim_xdp+0x162>
		000000000000015e:  R_X86_64_PLT32	.text+0x4c
     162: 48 85 c0                     	testq	%rax, %rax
     165: 74 45                        	je	0x1ac <trusted_x86_x86_sim_xdp+0x1ac>
     167: 48 89 c1                     	movq	%rax, %rcx
     16a: 80 79 68 00                  	cmpb	$0x0, 0x68(%rcx)
     16e: 0f 85 c4 02 00 00            	jne	0x438 <trusted_x86_x86_sim_xdp+0x438>
     174: 48 8d 50 68                  	leaq	0x68(%rax), %rdx
     178: 4c 89 e1                     	movq	%r12, %rcx
     17b: 48 81 c1 10 0d 00 00         	addq	$0xd10, %rcx            # imm = 0xD10
     182: 78 17                        	js	0x19b <trusted_x86_x86_sim_xdp+0x19b>
     184: 48 8d 48 70                  	leaq	0x70(%rax), %rcx
     188: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     18f: 48 c7 02 00 00 00 00         	movq	$0x0, (%rdx)
     196: e9 9d 02 00 00               	jmp	0x438 <trusted_x86_x86_sim_xdp+0x438>
     19b: 48 81 f9 ff 0f 00 00         	cmpq	$0xfff, %rcx            # imm = 0xFFF
     1a2: 77 0d                        	ja	0x1b1 <trusted_x86_x86_sim_xdp+0x1b1>
     1a4: c6 02 00                     	movb	$0x0, (%rdx)
     1a7: e9 8c 02 00 00               	jmp	0x438 <trusted_x86_x86_sim_xdp+0x438>
     1ac: e9 9e 03 00 00               	jmp	0x54f <trusted_x86_x86_sim_xdp+0x54f>
     1b1: 48 89 ce                     	movq	%rcx, %rsi
     1b4: 0f b6 36                     	movzbl	(%rsi), %esi
     1b7: 40 88 32                     	movb	%sil, (%rdx)
     1ba: 40 84 f6                     	testb	%sil, %sil
     1bd: 0f 84 75 02 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     1c3: 49 8d 94 24 11 fd ff ff      	leaq	-0x2ef(%r12), %rdx
     1cb: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     1d2: 77 09                        	ja	0x1dd <trusted_x86_x86_sim_xdp+0x1dd>
     1d4: 48 89 ca                     	movq	%rcx, %rdx
     1d7: 0f b6 52 01                  	movzbl	0x1(%rdx), %edx
     1db: eb 02                        	jmp	0x1df <trusted_x86_x86_sim_xdp+0x1df>
     1dd: 31 d2                        	xorl	%edx, %edx
     1df: 48 8d 70 69                  	leaq	0x69(%rax), %rsi
     1e3: 88 16                        	movb	%dl, (%rsi)
     1e5: 48 85 d2                     	testq	%rdx, %rdx
     1e8: 0f 84 4a 02 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     1ee: 49 8d 94 24 12 fd ff ff      	leaq	-0x2ee(%r12), %rdx
     1f6: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     1fd: 77 09                        	ja	0x208 <trusted_x86_x86_sim_xdp+0x208>
     1ff: 48 89 ca                     	movq	%rcx, %rdx
     202: 0f b6 52 02                  	movzbl	0x2(%rdx), %edx
     206: eb 02                        	jmp	0x20a <trusted_x86_x86_sim_xdp+0x20a>
     208: 31 d2                        	xorl	%edx, %edx
     20a: 48 8d 70 6a                  	leaq	0x6a(%rax), %rsi
     20e: 88 16                        	movb	%dl, (%rsi)
     210: 48 85 d2                     	testq	%rdx, %rdx
     213: 0f 84 1f 02 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     219: 49 8d 94 24 13 fd ff ff      	leaq	-0x2ed(%r12), %rdx
     221: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     228: 77 0c                        	ja	0x236 <trusted_x86_x86_sim_xdp+0x236>
     22a: 48 89 ca                     	movq	%rcx, %rdx
     22d: 0f b6 52 03                  	movzbl	0x3(%rdx), %edx
     231: 0f b6 d2                     	movzbl	%dl, %edx
     234: eb 02                        	jmp	0x238 <trusted_x86_x86_sim_xdp+0x238>
     236: 31 d2                        	xorl	%edx, %edx
     238: 48 8d 70 6b                  	leaq	0x6b(%rax), %rsi
     23c: 88 16                        	movb	%dl, (%rsi)
     23e: 48 85 d2                     	testq	%rdx, %rdx
     241: 0f 84 f1 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     247: 49 8d 94 24 14 fd ff ff      	leaq	-0x2ec(%r12), %rdx
     24f: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     256: 77 0c                        	ja	0x264 <trusted_x86_x86_sim_xdp+0x264>
     258: 48 89 ca                     	movq	%rcx, %rdx
     25b: 0f b6 52 04                  	movzbl	0x4(%rdx), %edx
     25f: 0f b6 d2                     	movzbl	%dl, %edx
     262: eb 02                        	jmp	0x266 <trusted_x86_x86_sim_xdp+0x266>
     264: 31 d2                        	xorl	%edx, %edx
     266: 48 8d 70 6c                  	leaq	0x6c(%rax), %rsi
     26a: 88 16                        	movb	%dl, (%rsi)
     26c: 48 85 d2                     	testq	%rdx, %rdx
     26f: 0f 84 c3 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     275: 49 8d 94 24 15 fd ff ff      	leaq	-0x2eb(%r12), %rdx
     27d: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     284: 77 0c                        	ja	0x292 <trusted_x86_x86_sim_xdp+0x292>
     286: 48 89 ca                     	movq	%rcx, %rdx
     289: 0f b6 52 05                  	movzbl	0x5(%rdx), %edx
     28d: 0f b6 d2                     	movzbl	%dl, %edx
     290: eb 02                        	jmp	0x294 <trusted_x86_x86_sim_xdp+0x294>
     292: 31 d2                        	xorl	%edx, %edx
     294: 48 8d 70 6d                  	leaq	0x6d(%rax), %rsi
     298: 88 16                        	movb	%dl, (%rsi)
     29a: 48 85 d2                     	testq	%rdx, %rdx
     29d: 0f 84 95 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     2a3: 49 8d 94 24 16 fd ff ff      	leaq	-0x2ea(%r12), %rdx
     2ab: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     2b2: 77 0c                        	ja	0x2c0 <trusted_x86_x86_sim_xdp+0x2c0>
     2b4: 48 89 ca                     	movq	%rcx, %rdx
     2b7: 0f b6 52 06                  	movzbl	0x6(%rdx), %edx
     2bb: 0f b6 d2                     	movzbl	%dl, %edx
     2be: eb 02                        	jmp	0x2c2 <trusted_x86_x86_sim_xdp+0x2c2>
     2c0: 31 d2                        	xorl	%edx, %edx
     2c2: 48 8d 70 6e                  	leaq	0x6e(%rax), %rsi
     2c6: 88 16                        	movb	%dl, (%rsi)
     2c8: 48 85 d2                     	testq	%rdx, %rdx
     2cb: 0f 84 67 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     2d1: 49 8d 94 24 17 fd ff ff      	leaq	-0x2e9(%r12), %rdx
     2d9: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     2e0: 77 0c                        	ja	0x2ee <trusted_x86_x86_sim_xdp+0x2ee>
     2e2: 48 89 ca                     	movq	%rcx, %rdx
     2e5: 0f b6 52 07                  	movzbl	0x7(%rdx), %edx
     2e9: 0f b6 d2                     	movzbl	%dl, %edx
     2ec: eb 02                        	jmp	0x2f0 <trusted_x86_x86_sim_xdp+0x2f0>
     2ee: 31 d2                        	xorl	%edx, %edx
     2f0: 48 8d 70 6f                  	leaq	0x6f(%rax), %rsi
     2f4: 88 16                        	movb	%dl, (%rsi)
     2f6: 48 85 d2                     	testq	%rdx, %rdx
     2f9: 0f 84 39 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     2ff: 49 8d 94 24 18 fd ff ff      	leaq	-0x2e8(%r12), %rdx
     307: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     30e: 77 0c                        	ja	0x31c <trusted_x86_x86_sim_xdp+0x31c>
     310: 48 89 ca                     	movq	%rcx, %rdx
     313: 0f b6 52 08                  	movzbl	0x8(%rdx), %edx
     317: 0f b6 d2                     	movzbl	%dl, %edx
     31a: eb 02                        	jmp	0x31e <trusted_x86_x86_sim_xdp+0x31e>
     31c: 31 d2                        	xorl	%edx, %edx
     31e: 48 8d 70 70                  	leaq	0x70(%rax), %rsi
     322: 88 16                        	movb	%dl, (%rsi)
     324: 48 85 d2                     	testq	%rdx, %rdx
     327: 0f 84 0b 01 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     32d: 49 8d 94 24 19 fd ff ff      	leaq	-0x2e7(%r12), %rdx
     335: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     33c: 77 0c                        	ja	0x34a <trusted_x86_x86_sim_xdp+0x34a>
     33e: 48 89 ca                     	movq	%rcx, %rdx
     341: 0f b6 52 09                  	movzbl	0x9(%rdx), %edx
     345: 0f b6 d2                     	movzbl	%dl, %edx
     348: eb 02                        	jmp	0x34c <trusted_x86_x86_sim_xdp+0x34c>
     34a: 31 d2                        	xorl	%edx, %edx
     34c: 48 8d 70 71                  	leaq	0x71(%rax), %rsi
     350: 88 16                        	movb	%dl, (%rsi)
     352: 48 85 d2                     	testq	%rdx, %rdx
     355: 0f 84 dd 00 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     35b: 49 8d 94 24 1a fd ff ff      	leaq	-0x2e6(%r12), %rdx
     363: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     36a: 77 0c                        	ja	0x378 <trusted_x86_x86_sim_xdp+0x378>
     36c: 48 89 ca                     	movq	%rcx, %rdx
     36f: 0f b6 52 0a                  	movzbl	0xa(%rdx), %edx
     373: 0f b6 d2                     	movzbl	%dl, %edx
     376: eb 02                        	jmp	0x37a <trusted_x86_x86_sim_xdp+0x37a>
     378: 31 d2                        	xorl	%edx, %edx
     37a: 48 8d 70 72                  	leaq	0x72(%rax), %rsi
     37e: 88 16                        	movb	%dl, (%rsi)
     380: 48 85 d2                     	testq	%rdx, %rdx
     383: 0f 84 af 00 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     389: 49 8d 94 24 1b fd ff ff      	leaq	-0x2e5(%r12), %rdx
     391: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     398: 77 0c                        	ja	0x3a6 <trusted_x86_x86_sim_xdp+0x3a6>
     39a: 48 89 ca                     	movq	%rcx, %rdx
     39d: 0f b6 52 0b                  	movzbl	0xb(%rdx), %edx
     3a1: 0f b6 d2                     	movzbl	%dl, %edx
     3a4: eb 02                        	jmp	0x3a8 <trusted_x86_x86_sim_xdp+0x3a8>
     3a6: 31 d2                        	xorl	%edx, %edx
     3a8: 48 8d 70 73                  	leaq	0x73(%rax), %rsi
     3ac: 88 16                        	movb	%dl, (%rsi)
     3ae: 48 85 d2                     	testq	%rdx, %rdx
     3b1: 0f 84 81 00 00 00            	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     3b7: 49 8d 94 24 1c fd ff ff      	leaq	-0x2e4(%r12), %rdx
     3bf: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     3c6: 77 0c                        	ja	0x3d4 <trusted_x86_x86_sim_xdp+0x3d4>
     3c8: 48 89 ca                     	movq	%rcx, %rdx
     3cb: 0f b6 52 0c                  	movzbl	0xc(%rdx), %edx
     3cf: 0f b6 d2                     	movzbl	%dl, %edx
     3d2: eb 02                        	jmp	0x3d6 <trusted_x86_x86_sim_xdp+0x3d6>
     3d4: 31 d2                        	xorl	%edx, %edx
     3d6: 48 8d 70 74                  	leaq	0x74(%rax), %rsi
     3da: 88 16                        	movb	%dl, (%rsi)
     3dc: 48 85 d2                     	testq	%rdx, %rdx
     3df: 74 57                        	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     3e1: 49 8d 94 24 1d fd ff ff      	leaq	-0x2e3(%r12), %rdx
     3e9: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     3f0: 77 0c                        	ja	0x3fe <trusted_x86_x86_sim_xdp+0x3fe>
     3f2: 48 89 ca                     	movq	%rcx, %rdx
     3f5: 0f b6 52 0d                  	movzbl	0xd(%rdx), %edx
     3f9: 0f b6 d2                     	movzbl	%dl, %edx
     3fc: eb 02                        	jmp	0x400 <trusted_x86_x86_sim_xdp+0x400>
     3fe: 31 d2                        	xorl	%edx, %edx
     400: 48 8d 70 75                  	leaq	0x75(%rax), %rsi
     404: 88 16                        	movb	%dl, (%rsi)
     406: 48 85 d2                     	testq	%rdx, %rdx
     409: 74 2d                        	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     40b: 49 81 c4 1e fd ff ff         	addq	$-0x2e2, %r12           # imm = 0xFD1E
     412: 49 81 fc ff ef ff ff         	cmpq	$-0x1001, %r12          # imm = 0xEFFF
     419: 77 09                        	ja	0x424 <trusted_x86_x86_sim_xdp+0x424>
     41b: 0f b6 49 0e                  	movzbl	0xe(%rcx), %ecx
     41f: 0f b6 c9                     	movzbl	%cl, %ecx
     422: eb 02                        	jmp	0x426 <trusted_x86_x86_sim_xdp+0x426>
     424: 31 c9                        	xorl	%ecx, %ecx
     426: 48 8d 50 76                  	leaq	0x76(%rax), %rdx
     42a: 88 0a                        	movb	%cl, (%rdx)
     42c: 48 85 c9                     	testq	%rcx, %rcx
     42f: 74 07                        	je	0x438 <trusted_x86_x86_sim_xdp+0x438>
     431: 48 8d 48 77                  	leaq	0x77(%rax), %rcx
     435: c6 01 00                     	movb	$0x0, (%rcx)
     438: 4c 89 f1                     	movq	%r14, %rcx
     43b: 48 c1 e9 03                  	shrq	$0x3, %rcx
     43f: 89 ca                        	movl	%ecx, %edx
     441: 49 c1 ee 23                  	shrq	$0x23, %r14
     445: be cf f7 53 e3               	movl	$0xe353f7cf, %esi       # imm = 0xE353F7CF
     44a: 48 69 fa a5 9b c4 20         	imulq	$0x20c49ba5, %rdx, %rdi # imm = 0x20C49BA5
     451: 48 0f af d6                  	imulq	%rsi, %rdx
     455: 49 0f af f6                  	imulq	%r14, %rsi
     459: 4d 69 c6 a5 9b c4 20         	imulq	$0x20c49ba5, %r14, %r8  # imm = 0x20C49BA5
     460: 48 c1 ea 20                  	shrq	$0x20, %rdx
     464: 41 89 f9                     	movl	%edi, %r9d
     467: 89 f1                        	movl	%esi, %ecx
     469: 4c 01 c9                     	addq	%r9, %rcx
     46c: 48 01 d1                     	addq	%rdx, %rcx
     46f: 48 c1 ef 20                  	shrq	$0x20, %rdi
     473: 48 c1 ee 20                  	shrq	$0x20, %rsi
     477: 4c 01 c6                     	addq	%r8, %rsi
     47a: 48 01 fe                     	addq	%rdi, %rsi
     47d: 48 c1 e9 20                  	shrq	$0x20, %rcx
     481: 48 01 f1                     	addq	%rsi, %rcx
     484: 48 89 ce                     	movq	%rcx, %rsi
     487: 48 c1 ee 24                  	shrq	$0x24, %rsi
     48b: 74 57                        	je	0x4e4 <trusted_x86_x86_sim_xdp+0x4e4>
     48d: 31 d2                        	xorl	%edx, %edx
     48f: 48 c1 e9 34                  	shrq	$0x34, %rcx
     493: 0f 95 c2                     	setne	%dl
     496: c1 e2 04                     	shll	$0x4, %edx
     499: c4 e2 eb f7 f6               	shrxq	%rdx, %rsi, %rsi
     49e: 31 c9                        	xorl	%ecx, %ecx
     4a0: 81 fe 00 01 00 00            	cmpl	$0x100, %esi            # imm = 0x100
     4a6: 0f 93 c1                     	setae	%cl
     4a9: c1 e1 03                     	shll	$0x3, %ecx
     4ac: c4 e2 73 f7 f6               	shrxl	%ecx, %esi, %esi
     4b1: 31 ff                        	xorl	%edi, %edi
     4b3: 83 fe 10                     	cmpl	$0x10, %esi
     4b6: 40 0f 93 c7                  	setae	%dil
     4ba: c1 e7 02                     	shll	$0x2, %edi
     4bd: c4 e2 43 f7 f6               	shrxl	%edi, %esi, %esi
     4c2: 45 31 c0                     	xorl	%r8d, %r8d
     4c5: 83 fe 04                     	cmpl	$0x4, %esi
     4c8: 41 0f 93 c0                  	setae	%r8b
     4cc: 45 01 c0                     	addl	%r8d, %r8d
     4cf: c4 e2 3b f7 f6               	shrxl	%r8d, %esi, %esi
     4d4: d1 ee                        	shrl	%esi
     4d6: 09 d1                        	orl	%edx, %ecx
     4d8: 09 f9                        	orl	%edi, %ecx
     4da: 44 09 c1                     	orl	%r8d, %ecx
     4dd: 09 f1                        	orl	%esi, %ecx
     4df: 83 c1 20                     	addl	$0x20, %ecx
     4e2: eb 5c                        	jmp	0x540 <trusted_x86_x86_sim_xdp+0x540>
     4e4: 48 89 ce                     	movq	%rcx, %rsi
     4e7: 48 c1 ee 04                  	shrq	$0x4, %rsi
     4eb: 31 d2                        	xorl	%edx, %edx
     4ed: 48 81 f9 00 00 10 00         	cmpq	$0x100000, %rcx         # imm = 0x100000
     4f4: 0f 93 c2                     	setae	%dl
     4f7: c1 e2 04                     	shll	$0x4, %edx
     4fa: c4 e2 eb f7 f6               	shrxq	%rdx, %rsi, %rsi
     4ff: 31 c9                        	xorl	%ecx, %ecx
     501: 81 fe 00 01 00 00            	cmpl	$0x100, %esi            # imm = 0x100
     507: 0f 93 c1                     	setae	%cl
     50a: c1 e1 03                     	shll	$0x3, %ecx
     50d: c4 e2 73 f7 f6               	shrxl	%ecx, %esi, %esi
     512: 31 ff                        	xorl	%edi, %edi
     514: 83 fe 10                     	cmpl	$0x10, %esi
     517: 40 0f 93 c7                  	setae	%dil
     51b: c1 e7 02                     	shll	$0x2, %edi
     51e: c4 e2 43 f7 f6               	shrxl	%edi, %esi, %esi
     523: 45 31 c0                     	xorl	%r8d, %r8d
     526: 83 fe 04                     	cmpl	$0x4, %esi
     529: 41 0f 93 c0                  	setae	%r8b
     52d: 45 01 c0                     	addl	%r8d, %r8d
     530: c4 e2 3b f7 f6               	shrxl	%r8d, %esi, %esi
     535: d1 ee                        	shrl	%esi
     537: 09 d1                        	orl	%edx, %ecx
     539: 09 f9                        	orl	%edi, %ecx
     53b: 44 09 c1                     	orl	%r8d, %ecx
     53e: 09 f1                        	orl	%esi, %ecx
     540: 83 f9 19                     	cmpl	$0x19, %ecx
     543: ba 19 00 00 00               	movl	$0x19, %edx
     548: 0f 42 d1                     	cmovbl	%ecx, %edx
     54b: f0                           	lock
     54c: ff 04 90                     	incl	(%rax,%rdx,4)
     54f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x556 <trusted_x86_x86_sim_xdp+0x556>
		0000000000000552:  R_X86_64_REX_GOTPCRELX	start-0x4
     556: 48 89 de                     	movq	%rbx, %rsi
     559: e8 00 00 00 00               	callq	0x55e <trusted_x86_x86_sim_xdp+0x55e>
		000000000000055a:  R_X86_64_PLT32	bpf_map_delete_elem-0x4
     55e: 31 c0                        	xorl	%eax, %eax
     560: 48 83 c4 38                  	addq	$0x38, %rsp
     564: 5b                           	popq	%rbx
     565: 41 5c                        	popq	%r12
     567: 41 5e                        	popq	%r14
     569: 41 5f                        	popq	%r15
     56b: c3                           	retq
