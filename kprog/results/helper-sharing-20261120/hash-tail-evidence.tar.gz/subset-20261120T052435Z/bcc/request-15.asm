
/var/tmp/kprog-tmp/perf/helper-sharing/15/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	data-0x4
       7: 74 2a                        	je	0x33 <__kprog_array_lookup+0x33>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	start-0x4
      10: 74 2a                        	je	0x3c <__kprog_array_lookup+0x3c>
      12: 8b 06                        	movl	(%rsi), %eax
      14: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      17: 73 2c                        	jae	0x45 <__kprog_array_lookup+0x45>
      19: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      1f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      25: 48 0f af c1                  	imulq	%rcx, %rax
      29: 48 01 f8                     	addq	%rdi, %rax
      2c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      32: c3                           	retq
      33: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3a <__kprog_array_lookup+0x3a>
		0000000000000036:  R_X86_64_REX_GOTPCRELX	data-0x4
      3a: eb 14                        	jmp	0x50 <__kprog_hash_key_4>
      3c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x43 <__kprog_array_lookup+0x43>
		000000000000003f:  R_X86_64_REX_GOTPCRELX	start-0x4
      43: eb 0b                        	jmp	0x50 <__kprog_hash_key_4>
      45: 31 c0                        	xorl	%eax, %eax
      47: c3                           	retq
      48: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)

0000000000000050 <__kprog_hash_key_4>:
      50: b9 f3 be ad de               	movl	$0xdeadbef3, %ecx       # imm = 0xDEADBEF3
      55: 03 8f 40 03 00 00            	addl	0x340(%rdi), %ecx
      5b: 8b 06                        	movl	(%rsi), %eax
      5d: 01 c8                        	addl	%ecx, %eax
      5f: c4 e3 7b f0 d1 12            	rorxl	$0x12, %ecx, %edx
      65: f7 da                        	negl	%edx
      67: 31 d0                        	xorl	%edx, %eax
      69: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
      6f: 44 29 c0                     	subl	%r8d, %eax
      72: 31 c1                        	xorl	%eax, %ecx
      74: c4 63 7b f0 c0 07            	rorxl	$0x7, %eax, %r8d
      7a: 44 29 c1                     	subl	%r8d, %ecx
      7d: 31 ca                        	xorl	%ecx, %edx
      7f: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
      85: 44 29 c2                     	subl	%r8d, %edx
      88: 31 d0                        	xorl	%edx, %eax
      8a: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
      90: 44 29 c0                     	subl	%r8d, %eax
      93: 31 c1                        	xorl	%eax, %ecx
      95: c4 e3 7b f0 c0 12            	rorxl	$0x12, %eax, %eax
      9b: 29 c1                        	subl	%eax, %ecx
      9d: c4 e3 7b f0 c1 08            	rorxl	$0x8, %ecx, %eax
      a3: 31 d1                        	xorl	%edx, %ecx
      a5: 29 c1                        	subl	%eax, %ecx
      a7: 8b 97 38 03 00 00            	movl	0x338(%rdi), %edx
      ad: ff ca                        	decl	%edx
      af: 21 ca                        	andl	%ecx, %edx
      b1: 48 8b bf c0 01 00 00         	movq	0x1c0(%rdi), %rdi
      b8: 49 89 d0                     	movq	%rdx, %r8
      bb: 49 c1 e0 04                  	shlq	$0x4, %r8
      bf: eb 17                        	jmp	0xd8 <__kprog_hash_key_4+0x88>
      c1: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
      d0: 48 d1 e8                     	shrq	%rax
      d3: 48 39 d0                     	cmpq	%rdx, %rax
      d6: 74 22                        	je	0xfa <__kprog_hash_key_4+0xaa>
      d8: 4a 8b 04 07                  	movq	(%rdi,%r8), %rax
      dc: eb 05                        	jmp	0xe3 <__kprog_hash_key_4+0x93>
      de: 66 90                        	nop
      e0: 48 8b 00                     	movq	(%rax), %rax
      e3: a8 01                        	testb	$0x1, %al
      e5: 75 e9                        	jne	0xd0 <__kprog_hash_key_4+0x80>
      e7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
      ea: 75 f4                        	jne	0xe0 <__kprog_hash_key_4+0x90>
      ec: 44 8b 48 30                  	movl	0x30(%rax), %r9d
      f0: 44 3b 0e                     	cmpl	(%rsi), %r9d
      f3: 75 eb                        	jne	0xe0 <__kprog_hash_key_4+0x90>
      f5: 48 83 c0 38                  	addq	$0x38, %rax
      f9: c3                           	retq
      fa: 31 c0                        	xorl	%eax, %eax
      fc: c3                           	retq

Disassembly of section tracepoint/trusted/trusted:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 53                           	pushq	%rbx
       5: 48 83 ec 30                  	subq	$0x30, %rsp
       9: 49 89 fe                     	movq	%rdi, %r14
       c: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      15: 48 c7 44 24 20 00 00 00 00   	movq	$0x0, 0x20(%rsp)
      1e: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
      27: e8 00 00 00 00               	callq	0x2c <trusted_x86_x86_sim_xdp+0x2c>
		0000000000000028:  R_X86_64_PLT32	bpf_get_current_pid_tgid-0x4
      2c: 89 44 24 14                  	movl	%eax, 0x14(%rsp)
      30: 49 8b 46 08                  	movq	0x8(%r14), %rax
      34: 48 83 f8 ff                  	cmpq	$-0x1, %rax
      38: 0f 84 98 00 00 00            	je	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
      3e: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
      43: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x4a <trusted_x86_x86_sim_xdp+0x4a>
		0000000000000046:  R_X86_64_REX_GOTPCRELX	data-0x4
      4a: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x51 <trusted_x86_x86_sim_xdp+0x51>
		000000000000004d:  R_X86_64_REX_GOTPCRELX	start-0x4
      51: 48 39 c7                     	cmpq	%rax, %rdi
      54: 48 0f 44 f8                  	cmoveq	%rax, %rdi
      58: e8 00 00 00 00               	callq	0x5d <trusted_x86_x86_sim_xdp+0x5d>
		0000000000000059:  R_X86_64_PLT32	.text+0x4c
      5d: 48 85 c0                     	testq	%rax, %rax
      60: 74 74                        	je	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
      62: 49 89 c7                     	movq	%rax, %r15
      65: e8 00 00 00 00               	callq	0x6a <trusted_x86_x86_sim_xdp+0x6a>
		0000000000000066:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      6a: 48 89 c3                     	movq	%rax, %rbx
      6d: 49 2b 1f                     	subq	(%r15), %rbx
      70: 41 8b 46 08                  	movl	0x8(%r14), %eax
      74: 4c 8d 74 24 10               	leaq	0x10(%rsp), %r14
      79: 89 44 24 10                  	movl	%eax, 0x10(%rsp)
      7d: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x84 <trusted_x86_x86_sim_xdp+0x84>
		0000000000000080:  R_X86_64_REX_GOTPCRELX	data-0x4
      84: 4c 89 f6                     	movq	%r14, %rsi
      87: e8 00 00 00 00               	callq	0x8c <trusted_x86_x86_sim_xdp+0x8c>
		0000000000000088:  R_X86_64_PLT32	.text+0x4c
      8c: 48 85 c0                     	testq	%rax, %rax
      8f: 74 02                        	je	0x93 <trusted_x86_x86_sim_xdp+0x93>
      91: eb 3a                        	jmp	0xcd <trusted_x86_x86_sim_xdp+0xcd>
      93: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x9a <trusted_x86_x86_sim_xdp+0x9a>
		0000000000000096:  R_X86_64_REX_GOTPCRELX	data-0x4
      9a: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0xa1 <trusted_x86_x86_sim_xdp+0xa1>
		000000000000009d:  R_X86_64_PC32	.rodata.native.0-0x4
      a1: b9 01 00 00 00               	movl	$0x1, %ecx
      a6: 4c 89 f6                     	movq	%r14, %rsi
      a9: e8 00 00 00 00               	callq	0xae <trusted_x86_x86_sim_xdp+0xae>
		00000000000000aa:  R_X86_64_PLT32	bpf_map_update_elem-0x4
      ae: 48 85 c0                     	testq	%rax, %rax
      b1: 74 06                        	je	0xb9 <trusted_x86_x86_sim_xdp+0xb9>
      b3: 48 83 f8 ef                  	cmpq	$-0x11, %rax
      b7: 75 1d                        	jne	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
      b9: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xc0 <trusted_x86_x86_sim_xdp+0xc0>
		00000000000000bc:  R_X86_64_REX_GOTPCRELX	data-0x4
      c0: 4c 89 f6                     	movq	%r14, %rsi
      c3: e8 00 00 00 00               	callq	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
		00000000000000c4:  R_X86_64_PLT32	.text+0x4c
      c8: 48 85 c0                     	testq	%rax, %rax
      cb: 74 15                        	je	0xe2 <trusted_x86_x86_sim_xdp+0xe2>
      cd: f0                           	lock
      ce: 48 ff 00                     	incq	(%rax)
      d1: f0                           	lock
      d2: 48 01 58 08                  	addq	%rbx, 0x8(%rax)
      d6: 31 c0                        	xorl	%eax, %eax
      d8: 48 83 c4 30                  	addq	$0x30, %rsp
      dc: 5b                           	popq	%rbx
      dd: 41 5e                        	popq	%r14
      df: 41 5f                        	popq	%r15
      e1: c3                           	retq
      e2: eb f2                        	jmp	0xd6 <trusted_x86_x86_sim_xdp+0xd6>
