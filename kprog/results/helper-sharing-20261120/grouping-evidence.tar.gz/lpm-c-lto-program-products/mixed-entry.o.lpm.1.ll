; ModuleID = '/var/tmp/kprog-tmp/perf/lpm-c-lto/mixed-entry.o.lpm.1.c'
source_filename = "/var/tmp/kprog-tmp/perf/lpm-c-lto/mixed-entry.o.lpm.1.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

; Function Attrs: nofree norecurse noredzone nounwind
define ptr @__native_link_typed_lpm_lookup_1(ptr noundef %0, ptr nocapture noundef readonly %1) local_unnamed_addr #0 {
  %3 = getelementptr inbounds i8, ptr %0, i64 392
  %4 = load i64, ptr %3, align 8, !tbaa !3
  %5 = getelementptr inbounds i8, ptr %0, i64 384
  %6 = load i64, ptr %5, align 8, !tbaa !3
  %7 = load i32, ptr %1, align 1, !tbaa !7
  %8 = zext i32 %7 to i64
  %9 = icmp ult i64 %6, %8
  br i1 %9, label %115, label %10

10:                                               ; preds = %2
  %11 = getelementptr inbounds i8, ptr %0, i64 288
  %12 = getelementptr i8, ptr %1, i64 4
  %13 = load volatile ptr, ptr %11, align 8, !tbaa !8
  %14 = icmp eq ptr %13, null
  br i1 %14, label %109, label %15

15:                                               ; preds = %10, %89
  %16 = phi ptr [ %107, %89 ], [ %13, %10 ]
  %17 = phi ptr [ %94, %89 ], [ null, %10 ]
  %18 = getelementptr inbounds i8, ptr %16, i64 16
  %19 = load i32, ptr %18, align 1, !tbaa !7
  %20 = icmp ugt i32 %19, %7
  br i1 %20, label %109, label %21

21:                                               ; preds = %15
  %22 = getelementptr inbounds i8, ptr %16, i64 24
  %23 = icmp ugt i32 %19, 63
  br i1 %23, label %24, label %30

24:                                               ; preds = %21
  %25 = load i64, ptr %22, align 1, !tbaa !7
  %26 = load i64, ptr %12, align 1, !tbaa !7
  %27 = icmp eq i64 %25, %26
  br i1 %27, label %28, label %109

28:                                               ; preds = %24
  %29 = add i32 %19, -64
  br label %30

30:                                               ; preds = %28, %21
  %31 = phi i32 [ %29, %28 ], [ %19, %21 ]
  %32 = phi i64 [ 8, %28 ], [ 0, %21 ]
  %33 = icmp ugt i32 %31, 31
  br i1 %33, label %34, label %46

34:                                               ; preds = %30, %42
  %35 = phi i64 [ %44, %42 ], [ %32, %30 ]
  %36 = phi i32 [ %43, %42 ], [ %31, %30 ]
  %37 = getelementptr inbounds i8, ptr %22, i64 %35
  %38 = load i32, ptr %37, align 1, !tbaa !7
  %39 = getelementptr inbounds i8, ptr %12, i64 %35
  %40 = load i32, ptr %39, align 1, !tbaa !7
  %41 = icmp eq i32 %38, %40
  br i1 %41, label %42, label %109

42:                                               ; preds = %34
  %43 = add i32 %36, -32
  %44 = add nuw nsw i64 %35, 4
  %45 = icmp ugt i32 %43, 31
  br i1 %45, label %34, label %46, !llvm.loop !10

46:                                               ; preds = %42, %30
  %47 = phi i32 [ %31, %30 ], [ %43, %42 ]
  %48 = phi i64 [ %32, %30 ], [ %44, %42 ]
  %49 = icmp ugt i32 %47, 15
  br i1 %49, label %50, label %59

50:                                               ; preds = %46
  %51 = getelementptr inbounds i8, ptr %22, i64 %48
  %52 = load i16, ptr %51, align 1, !tbaa !7
  %53 = getelementptr inbounds i8, ptr %12, i64 %48
  %54 = load i16, ptr %53, align 1, !tbaa !7
  %55 = icmp eq i16 %52, %54
  br i1 %55, label %56, label %109

56:                                               ; preds = %50
  %57 = add nsw i32 %47, -16
  %58 = or disjoint i64 %48, 2
  br label %59

59:                                               ; preds = %56, %46
  %60 = phi i32 [ %57, %56 ], [ %47, %46 ]
  %61 = phi i64 [ %58, %56 ], [ %48, %46 ]
  %62 = icmp ugt i32 %60, 7
  br i1 %62, label %63, label %72

63:                                               ; preds = %59
  %64 = getelementptr inbounds i8, ptr %22, i64 %61
  %65 = load i8, ptr %64, align 1, !tbaa !7
  %66 = getelementptr inbounds i8, ptr %12, i64 %61
  %67 = load i8, ptr %66, align 1, !tbaa !7
  %68 = icmp eq i8 %65, %67
  br i1 %68, label %69, label %109

69:                                               ; preds = %63
  %70 = add nsw i32 %60, -8
  %71 = add i64 %61, 1
  br label %72

72:                                               ; preds = %69, %59
  %73 = phi i32 [ %70, %69 ], [ %60, %59 ]
  %74 = phi i64 [ %71, %69 ], [ %61, %59 ]
  %75 = icmp eq i32 %73, 0
  br i1 %75, label %86, label %76

76:                                               ; preds = %72
  %77 = getelementptr inbounds i8, ptr %22, i64 %74
  %78 = load i8, ptr %77, align 1, !tbaa !7
  %79 = getelementptr inbounds i8, ptr %12, i64 %74
  %80 = load i8, ptr %79, align 1, !tbaa !7
  %81 = xor i8 %80, %78
  %82 = zext i8 %81 to i32
  %83 = sub nuw nsw i32 8, %73
  %84 = lshr i32 %82, %83
  %85 = icmp eq i32 %84, 0
  br i1 %85, label %86, label %109

86:                                               ; preds = %72, %76
  %87 = zext i32 %19 to i64
  %88 = icmp eq i64 %6, %87
  br i1 %88, label %109, label %89

89:                                               ; preds = %86
  %90 = getelementptr inbounds i8, ptr %16, i64 20
  %91 = load i32, ptr %90, align 1, !tbaa !7
  %92 = and i32 %91, 1
  %93 = icmp eq i32 %92, 0
  %94 = select i1 %93, ptr %16, ptr %17
  %95 = lshr i32 %19, 3
  %96 = zext nneg i32 %95 to i64
  %97 = getelementptr i8, ptr %12, i64 %96
  %98 = load i8, ptr %97, align 1, !tbaa !7
  %99 = zext i8 %98 to i32
  %100 = and i32 %19, 7
  %101 = xor i32 %100, 7
  %102 = shl nuw nsw i32 1, %101
  %103 = and i32 %102, %99
  %104 = icmp eq i32 %103, 0
  %105 = select i1 %104, i64 0, i64 8
  %106 = getelementptr inbounds i8, ptr %16, i64 %105
  %107 = load volatile ptr, ptr %106, align 8, !tbaa !8
  %108 = icmp eq ptr %107, null
  br i1 %108, label %109, label %15

109:                                              ; preds = %89, %76, %15, %86, %24, %50, %63, %34, %10
  %110 = phi ptr [ null, %10 ], [ %17, %34 ], [ %94, %89 ], [ %17, %76 ], [ %17, %15 ], [ %16, %86 ], [ %17, %24 ], [ %17, %50 ], [ %17, %63 ]
  %111 = icmp eq ptr %110, null
  %112 = getelementptr inbounds i8, ptr %110, i64 24
  %113 = getelementptr inbounds i8, ptr %112, i64 %4
  %114 = select i1 %111, ptr null, ptr %113
  br label %115

115:                                              ; preds = %2, %109
  %116 = phi ptr [ %114, %109 ], [ null, %2 ]
  ret ptr %116
}

attributes #0 = { nofree norecurse noredzone nounwind "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="arrowlake-s" "target-features"="+64bit,+adx,+bmi,+bmi2,+clflushopt,+clwb,+cmov,+cmpccxadd,+crc32,+cx16,+cx8,+fsgsbase,+fxsr,+hreset,+invpcid,+lzcnt,+movbe,+movdir64b,+movdiri,+pku,+popcnt,+prfchw,+ptwrite,+rdpid,+rdrnd,+rdseed,+sahf,+serialize,+shstk,+uintr,+waitpkg,+wbnoinvd,+xsave,+xsavec,+xsaveopt,+xsaves,-3dnow,-3dnowa,-aes,-amx-bf16,-amx-complex,-amx-fp16,-amx-int8,-amx-tile,-avx,-avx10.1-256,-avx10.1-512,-avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512er,-avx512f,-avx512fp16,-avx512ifma,-avx512pf,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,-avxvnni,-avxvnniint16,-avxvnniint8,-cldemote,-clzero,-enqcmd,-f16c,-fma,-fma4,-gfni,-kl,-lwp,-mmx,-mwaitx,-pclmul,-pconfig,-prefetchi,-prefetchwt1,-raoint,-rdpru,-rtm,-sgx,-sha,-sha512,-sm3,-sm4,-sse,-sse2,-sse3,-sse4.1,-sse4.2,-sse4a,-ssse3,-tbm,-tsxldtrk,-usermsr,-vaes,-vpclmulqdq,-widekl,-x87,-xop" }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!3 = !{!4, !4, i64 0}
!4 = !{!"long", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!9, !9, i64 0}
!9 = !{!"any pointer", !5, i64 0}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
