
/var/tmp/kprog-tmp/perf/helper-sharing/20/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	hists-0x4
       7: 74 37                        	je	0x40 <__kprog_hash_key_4>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	start-0x4
      10: 74 2e                        	je	0x40 <__kprog_hash_key_4>
      12: 8b 06                        	movl	(%rsi), %eax
      14: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      17: 73 1a                        	jae	0x33 <__kprog_array_lookup+0x33>
      19: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      1f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      25: 48 0f af c1                  	imulq	%rcx, %rax
      29: 48 01 f8                     	addq	%rdi, %rax
      2c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      32: c3                           	retq
      33: 31 c0                        	xorl	%eax, %eax
      35: c3                           	retq
      36: 66 2e 0f 1f 84 00 00 00 00 00	nopw	%cs:(%rax,%rax)

0000000000000040 <__kprog_hash_key_4>:
      40: b9 f3 be ad de               	movl	$0xdeadbef3, %ecx       # imm = 0xDEADBEF3
      45: 03 8f 40 03 00 00            	addl	0x340(%rdi), %ecx
      4b: 8b 06                        	movl	(%rsi), %eax
      4d: 01 c8                        	addl	%ecx, %eax
      4f: c4 e3 7b f0 d1 12            	rorxl	$0x12, %ecx, %edx
      55: f7 da                        	negl	%edx
      57: 31 d0                        	xorl	%edx, %eax
      59: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
      5f: 44 29 c0                     	subl	%r8d, %eax
      62: 31 c1                        	xorl	%eax, %ecx
      64: c4 63 7b f0 c0 07            	rorxl	$0x7, %eax, %r8d
      6a: 44 29 c1                     	subl	%r8d, %ecx
      6d: 31 ca                        	xorl	%ecx, %edx
      6f: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
      75: 44 29 c2                     	subl	%r8d, %edx
      78: 31 d0                        	xorl	%edx, %eax
      7a: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
      80: 44 29 c0                     	subl	%r8d, %eax
      83: 31 c1                        	xorl	%eax, %ecx
      85: c4 e3 7b f0 c0 12            	rorxl	$0x12, %eax, %eax
      8b: 29 c1                        	subl	%eax, %ecx
      8d: c4 e3 7b f0 c1 08            	rorxl	$0x8, %ecx, %eax
      93: 31 d1                        	xorl	%edx, %ecx
      95: 29 c1                        	subl	%eax, %ecx
      97: 8b 97 38 03 00 00            	movl	0x338(%rdi), %edx
      9d: ff ca                        	decl	%edx
      9f: 21 ca                        	andl	%ecx, %edx
      a1: 48 8b bf c0 01 00 00         	movq	0x1c0(%rdi), %rdi
      a8: 49 89 d0                     	movq	%rdx, %r8
      ab: 49 c1 e0 04                  	shlq	$0x4, %r8
      af: eb 17                        	jmp	0xc8 <__kprog_hash_key_4+0x88>
      b1: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
      c0: 48 d1 e8                     	shrq	%rax
      c3: 48 39 d0                     	cmpq	%rdx, %rax
      c6: 74 22                        	je	0xea <__kprog_hash_key_4+0xaa>
      c8: 4a 8b 04 07                  	movq	(%rdi,%r8), %rax
      cc: eb 05                        	jmp	0xd3 <__kprog_hash_key_4+0x93>
      ce: 66 90                        	nop
      d0: 48 8b 00                     	movq	(%rax), %rax
      d3: a8 01                        	testb	$0x1, %al
      d5: 75 e9                        	jne	0xc0 <__kprog_hash_key_4+0x80>
      d7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
      da: 75 f4                        	jne	0xd0 <__kprog_hash_key_4+0x90>
      dc: 44 8b 48 30                  	movl	0x30(%rax), %r9d
      e0: 44 3b 0e                     	cmpl	(%rsi), %r9d
      e3: 75 eb                        	jne	0xd0 <__kprog_hash_key_4+0x90>
      e5: 48 83 c0 38                  	addq	$0x38, %rax
      e9: c3                           	retq
      ea: 31 c0                        	xorl	%eax, %eax
      ec: c3                           	retq

Disassembly of section fentry/trusted:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 41 54                        	pushq	%r12
       6: 53                           	pushq	%rbx
       7: 48 83 ec 38                  	subq	$0x38, %rsp
       b: 48 c7 44 24 30 00 00 00 00   	movq	$0x0, 0x30(%rsp)
      14: 48 8b 47 08                  	movq	0x8(%rdi), %rax
      18: 4c 8b 67 10                  	movq	0x10(%rdi), %r12
      1c: 48 c7 44 24 28 11 00 00 00   	movq	$0x11, 0x28(%rsp)
      25: 48 c7 44 24 10 00 00 00 00   	movq	$0x0, 0x10(%rsp)
      2e: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
      37: 48 c7 44 24 20 00 00 00 00   	movq	$0x0, 0x20(%rsp)
      40: 48 85 c0                     	testq	%rax, %rax
      43: 79 10                        	jns	0x55 <trusted_x86_x86_sim_xdp+0x55>
      45: 48 3d 00 10 00 00            	cmpq	$0x1000, %rax           # imm = 0x1000
      4b: 72 08                        	jb	0x55 <trusted_x86_x86_sim_xdp+0x55>
      4d: 48 89 c1                     	movq	%rax, %rcx
      50: 83 39 00                     	cmpl	$0x0, (%rcx)
      53: 75 5e                        	jne	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      55: 48 89 c1                     	movq	%rax, %rcx
      58: 48 81 c1 f4 0a 00 00         	addq	$0xaf4, %rcx            # imm = 0xAF4
      5f: 78 0a                        	js	0x6b <trusted_x86_x86_sim_xdp+0x6b>
      61: 48 05 f0 0a 00 00            	addq	$0xaf0, %rax            # imm = 0xAF0
      67: 78 0c                        	js	0x75 <trusted_x86_x86_sim_xdp+0x75>
      69: eb 48                        	jmp	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      6b: 8b 09                        	movl	(%rcx), %ecx
      6d: 48 05 f0 0a 00 00            	addq	$0xaf0, %rax            # imm = 0xAF0
      73: 79 3e                        	jns	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      75: 48 3d ff 0f 00 00            	cmpq	$0xfff, %rax            # imm = 0xFFF
      7b: 77 0a                        	ja	0x87 <trusted_x86_x86_sim_xdp+0x87>
      7d: c7 44 24 04 00 00 00 00      	movl	$0x0, 0x4(%rsp)
      85: eb 2c                        	jmp	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      87: 8b 00                        	movl	(%rax), %eax
      89: 89 44 24 04                  	movl	%eax, 0x4(%rsp)
      8d: 85 c0                        	testl	%eax, %eax
      8f: 74 22                        	je	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
      91: e8 00 00 00 00               	callq	0x96 <trusted_x86_x86_sim_xdp+0x96>
		0000000000000092:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      96: 48 8d 54 24 08               	leaq	0x8(%rsp), %rdx
      9b: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
      a0: 48 8d 74 24 04               	leaq	0x4(%rsp), %rsi
      a5: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xac <trusted_x86_x86_sim_xdp+0xac>
		00000000000000a8:  R_X86_64_REX_GOTPCRELX	start-0x4
      ac: 31 c9                        	xorl	%ecx, %ecx
      ae: e8 00 00 00 00               	callq	0xb3 <trusted_x86_x86_sim_xdp+0xb3>
		00000000000000af:  R_X86_64_PLT32	bpf_map_update_elem-0x4
      b3: 31 c0                        	xorl	%eax, %eax
      b5: 4c 89 e1                     	movq	%r12, %rcx
      b8: 48 81 c1 f0 0a 00 00         	addq	$0xaf0, %rcx            # imm = 0xAF0
      bf: 79 02                        	jns	0xc3 <trusted_x86_x86_sim_xdp+0xc3>
      c1: 8b 01                        	movl	(%rcx), %eax
      c3: 48 8d 5c 24 08               	leaq	0x8(%rsp), %rbx
      c8: 89 44 24 08                  	movl	%eax, 0x8(%rsp)
      cc: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xd3 <trusted_x86_x86_sim_xdp+0xd3>
		00000000000000cf:  R_X86_64_REX_GOTPCRELX	start-0x4
      d3: 48 89 de                     	movq	%rbx, %rsi
      d6: e8 00 00 00 00               	callq	0xdb <trusted_x86_x86_sim_xdp+0xdb>
		00000000000000d7:  R_X86_64_PLT32	.text+0x3c
      db: 48 85 c0                     	testq	%rax, %rax
      de: 0f 84 6c 04 00 00            	je	0x550 <trusted_x86_x86_sim_xdp+0x550>
      e4: 49 89 c7                     	movq	%rax, %r15
      e7: e8 00 00 00 00               	callq	0xec <trusted_x86_x86_sim_xdp+0xec>
		00000000000000e8:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      ec: 49 89 c6                     	movq	%rax, %r14
      ef: 4d 2b 37                     	subq	(%r15), %r14
      f2: 0f 88 49 04 00 00            	js	0x541 <trusted_x86_x86_sim_xdp+0x541>
      f8: c7 44 24 04 ff ff ff ff      	movl	$0xffffffff, 0x4(%rsp)  # imm = 0xFFFFFFFF
     100: 4c 8d 7c 24 04               	leaq	0x4(%rsp), %r15
     105: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x10c <trusted_x86_x86_sim_xdp+0x10c>
		0000000000000108:  R_X86_64_REX_GOTPCRELX	hists-0x4
     10c: 4c 89 fe                     	movq	%r15, %rsi
     10f: e8 00 00 00 00               	callq	0x114 <trusted_x86_x86_sim_xdp+0x114>
		0000000000000110:  R_X86_64_PLT32	.text+0x3c
     114: 48 85 c0                     	testq	%rax, %rax
     117: 74 02                        	je	0x11b <trusted_x86_x86_sim_xdp+0x11b>
     119: eb 3e                        	jmp	0x159 <trusted_x86_x86_sim_xdp+0x159>
     11b: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x122 <trusted_x86_x86_sim_xdp+0x122>
		000000000000011e:  R_X86_64_REX_GOTPCRELX	hists-0x4
     122: 48 8b 15 00 00 00 00         	movq	(%rip), %rdx            # 0x129 <trusted_x86_x86_sim_xdp+0x129>
		0000000000000125:  R_X86_64_REX_GOTPCRELX	zero-0x4
     129: b9 01 00 00 00               	movl	$0x1, %ecx
     12e: 4c 89 fe                     	movq	%r15, %rsi
     131: e8 00 00 00 00               	callq	0x136 <trusted_x86_x86_sim_xdp+0x136>
		0000000000000132:  R_X86_64_PLT32	bpf_map_update_elem-0x4
     136: 48 85 c0                     	testq	%rax, %rax
     139: 74 0a                        	je	0x145 <trusted_x86_x86_sim_xdp+0x145>
     13b: 48 83 f8 ef                  	cmpq	$-0x11, %rax
     13f: 0f 85 fc 03 00 00            	jne	0x541 <trusted_x86_x86_sim_xdp+0x541>
     145: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x14c <trusted_x86_x86_sim_xdp+0x14c>
		0000000000000148:  R_X86_64_REX_GOTPCRELX	hists-0x4
     14c: 4c 89 fe                     	movq	%r15, %rsi
     14f: e8 00 00 00 00               	callq	0x154 <trusted_x86_x86_sim_xdp+0x154>
		0000000000000150:  R_X86_64_PLT32	.text+0x3c
     154: 48 85 c0                     	testq	%rax, %rax
     157: 74 45                        	je	0x19e <trusted_x86_x86_sim_xdp+0x19e>
     159: 48 89 c1                     	movq	%rax, %rcx
     15c: 80 79 68 00                  	cmpb	$0x0, 0x68(%rcx)
     160: 0f 85 c4 02 00 00            	jne	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     166: 48 8d 50 68                  	leaq	0x68(%rax), %rdx
     16a: 4c 89 e1                     	movq	%r12, %rcx
     16d: 48 81 c1 10 0d 00 00         	addq	$0xd10, %rcx            # imm = 0xD10
     174: 78 17                        	js	0x18d <trusted_x86_x86_sim_xdp+0x18d>
     176: 48 8d 48 70                  	leaq	0x70(%rax), %rcx
     17a: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     181: 48 c7 02 00 00 00 00         	movq	$0x0, (%rdx)
     188: e9 9d 02 00 00               	jmp	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     18d: 48 81 f9 ff 0f 00 00         	cmpq	$0xfff, %rcx            # imm = 0xFFF
     194: 77 0d                        	ja	0x1a3 <trusted_x86_x86_sim_xdp+0x1a3>
     196: c6 02 00                     	movb	$0x0, (%rdx)
     199: e9 8c 02 00 00               	jmp	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     19e: e9 9e 03 00 00               	jmp	0x541 <trusted_x86_x86_sim_xdp+0x541>
     1a3: 48 89 ce                     	movq	%rcx, %rsi
     1a6: 0f b6 36                     	movzbl	(%rsi), %esi
     1a9: 40 88 32                     	movb	%sil, (%rdx)
     1ac: 40 84 f6                     	testb	%sil, %sil
     1af: 0f 84 75 02 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     1b5: 49 8d 94 24 11 fd ff ff      	leaq	-0x2ef(%r12), %rdx
     1bd: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     1c4: 77 09                        	ja	0x1cf <trusted_x86_x86_sim_xdp+0x1cf>
     1c6: 48 89 ca                     	movq	%rcx, %rdx
     1c9: 0f b6 52 01                  	movzbl	0x1(%rdx), %edx
     1cd: eb 02                        	jmp	0x1d1 <trusted_x86_x86_sim_xdp+0x1d1>
     1cf: 31 d2                        	xorl	%edx, %edx
     1d1: 48 8d 70 69                  	leaq	0x69(%rax), %rsi
     1d5: 88 16                        	movb	%dl, (%rsi)
     1d7: 48 85 d2                     	testq	%rdx, %rdx
     1da: 0f 84 4a 02 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     1e0: 49 8d 94 24 12 fd ff ff      	leaq	-0x2ee(%r12), %rdx
     1e8: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     1ef: 77 09                        	ja	0x1fa <trusted_x86_x86_sim_xdp+0x1fa>
     1f1: 48 89 ca                     	movq	%rcx, %rdx
     1f4: 0f b6 52 02                  	movzbl	0x2(%rdx), %edx
     1f8: eb 02                        	jmp	0x1fc <trusted_x86_x86_sim_xdp+0x1fc>
     1fa: 31 d2                        	xorl	%edx, %edx
     1fc: 48 8d 70 6a                  	leaq	0x6a(%rax), %rsi
     200: 88 16                        	movb	%dl, (%rsi)
     202: 48 85 d2                     	testq	%rdx, %rdx
     205: 0f 84 1f 02 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     20b: 49 8d 94 24 13 fd ff ff      	leaq	-0x2ed(%r12), %rdx
     213: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     21a: 77 0c                        	ja	0x228 <trusted_x86_x86_sim_xdp+0x228>
     21c: 48 89 ca                     	movq	%rcx, %rdx
     21f: 0f b6 52 03                  	movzbl	0x3(%rdx), %edx
     223: 0f b6 d2                     	movzbl	%dl, %edx
     226: eb 02                        	jmp	0x22a <trusted_x86_x86_sim_xdp+0x22a>
     228: 31 d2                        	xorl	%edx, %edx
     22a: 48 8d 70 6b                  	leaq	0x6b(%rax), %rsi
     22e: 88 16                        	movb	%dl, (%rsi)
     230: 48 85 d2                     	testq	%rdx, %rdx
     233: 0f 84 f1 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     239: 49 8d 94 24 14 fd ff ff      	leaq	-0x2ec(%r12), %rdx
     241: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     248: 77 0c                        	ja	0x256 <trusted_x86_x86_sim_xdp+0x256>
     24a: 48 89 ca                     	movq	%rcx, %rdx
     24d: 0f b6 52 04                  	movzbl	0x4(%rdx), %edx
     251: 0f b6 d2                     	movzbl	%dl, %edx
     254: eb 02                        	jmp	0x258 <trusted_x86_x86_sim_xdp+0x258>
     256: 31 d2                        	xorl	%edx, %edx
     258: 48 8d 70 6c                  	leaq	0x6c(%rax), %rsi
     25c: 88 16                        	movb	%dl, (%rsi)
     25e: 48 85 d2                     	testq	%rdx, %rdx
     261: 0f 84 c3 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     267: 49 8d 94 24 15 fd ff ff      	leaq	-0x2eb(%r12), %rdx
     26f: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     276: 77 0c                        	ja	0x284 <trusted_x86_x86_sim_xdp+0x284>
     278: 48 89 ca                     	movq	%rcx, %rdx
     27b: 0f b6 52 05                  	movzbl	0x5(%rdx), %edx
     27f: 0f b6 d2                     	movzbl	%dl, %edx
     282: eb 02                        	jmp	0x286 <trusted_x86_x86_sim_xdp+0x286>
     284: 31 d2                        	xorl	%edx, %edx
     286: 48 8d 70 6d                  	leaq	0x6d(%rax), %rsi
     28a: 88 16                        	movb	%dl, (%rsi)
     28c: 48 85 d2                     	testq	%rdx, %rdx
     28f: 0f 84 95 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     295: 49 8d 94 24 16 fd ff ff      	leaq	-0x2ea(%r12), %rdx
     29d: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     2a4: 77 0c                        	ja	0x2b2 <trusted_x86_x86_sim_xdp+0x2b2>
     2a6: 48 89 ca                     	movq	%rcx, %rdx
     2a9: 0f b6 52 06                  	movzbl	0x6(%rdx), %edx
     2ad: 0f b6 d2                     	movzbl	%dl, %edx
     2b0: eb 02                        	jmp	0x2b4 <trusted_x86_x86_sim_xdp+0x2b4>
     2b2: 31 d2                        	xorl	%edx, %edx
     2b4: 48 8d 70 6e                  	leaq	0x6e(%rax), %rsi
     2b8: 88 16                        	movb	%dl, (%rsi)
     2ba: 48 85 d2                     	testq	%rdx, %rdx
     2bd: 0f 84 67 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     2c3: 49 8d 94 24 17 fd ff ff      	leaq	-0x2e9(%r12), %rdx
     2cb: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     2d2: 77 0c                        	ja	0x2e0 <trusted_x86_x86_sim_xdp+0x2e0>
     2d4: 48 89 ca                     	movq	%rcx, %rdx
     2d7: 0f b6 52 07                  	movzbl	0x7(%rdx), %edx
     2db: 0f b6 d2                     	movzbl	%dl, %edx
     2de: eb 02                        	jmp	0x2e2 <trusted_x86_x86_sim_xdp+0x2e2>
     2e0: 31 d2                        	xorl	%edx, %edx
     2e2: 48 8d 70 6f                  	leaq	0x6f(%rax), %rsi
     2e6: 88 16                        	movb	%dl, (%rsi)
     2e8: 48 85 d2                     	testq	%rdx, %rdx
     2eb: 0f 84 39 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     2f1: 49 8d 94 24 18 fd ff ff      	leaq	-0x2e8(%r12), %rdx
     2f9: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     300: 77 0c                        	ja	0x30e <trusted_x86_x86_sim_xdp+0x30e>
     302: 48 89 ca                     	movq	%rcx, %rdx
     305: 0f b6 52 08                  	movzbl	0x8(%rdx), %edx
     309: 0f b6 d2                     	movzbl	%dl, %edx
     30c: eb 02                        	jmp	0x310 <trusted_x86_x86_sim_xdp+0x310>
     30e: 31 d2                        	xorl	%edx, %edx
     310: 48 8d 70 70                  	leaq	0x70(%rax), %rsi
     314: 88 16                        	movb	%dl, (%rsi)
     316: 48 85 d2                     	testq	%rdx, %rdx
     319: 0f 84 0b 01 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     31f: 49 8d 94 24 19 fd ff ff      	leaq	-0x2e7(%r12), %rdx
     327: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     32e: 77 0c                        	ja	0x33c <trusted_x86_x86_sim_xdp+0x33c>
     330: 48 89 ca                     	movq	%rcx, %rdx
     333: 0f b6 52 09                  	movzbl	0x9(%rdx), %edx
     337: 0f b6 d2                     	movzbl	%dl, %edx
     33a: eb 02                        	jmp	0x33e <trusted_x86_x86_sim_xdp+0x33e>
     33c: 31 d2                        	xorl	%edx, %edx
     33e: 48 8d 70 71                  	leaq	0x71(%rax), %rsi
     342: 88 16                        	movb	%dl, (%rsi)
     344: 48 85 d2                     	testq	%rdx, %rdx
     347: 0f 84 dd 00 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     34d: 49 8d 94 24 1a fd ff ff      	leaq	-0x2e6(%r12), %rdx
     355: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     35c: 77 0c                        	ja	0x36a <trusted_x86_x86_sim_xdp+0x36a>
     35e: 48 89 ca                     	movq	%rcx, %rdx
     361: 0f b6 52 0a                  	movzbl	0xa(%rdx), %edx
     365: 0f b6 d2                     	movzbl	%dl, %edx
     368: eb 02                        	jmp	0x36c <trusted_x86_x86_sim_xdp+0x36c>
     36a: 31 d2                        	xorl	%edx, %edx
     36c: 48 8d 70 72                  	leaq	0x72(%rax), %rsi
     370: 88 16                        	movb	%dl, (%rsi)
     372: 48 85 d2                     	testq	%rdx, %rdx
     375: 0f 84 af 00 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     37b: 49 8d 94 24 1b fd ff ff      	leaq	-0x2e5(%r12), %rdx
     383: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     38a: 77 0c                        	ja	0x398 <trusted_x86_x86_sim_xdp+0x398>
     38c: 48 89 ca                     	movq	%rcx, %rdx
     38f: 0f b6 52 0b                  	movzbl	0xb(%rdx), %edx
     393: 0f b6 d2                     	movzbl	%dl, %edx
     396: eb 02                        	jmp	0x39a <trusted_x86_x86_sim_xdp+0x39a>
     398: 31 d2                        	xorl	%edx, %edx
     39a: 48 8d 70 73                  	leaq	0x73(%rax), %rsi
     39e: 88 16                        	movb	%dl, (%rsi)
     3a0: 48 85 d2                     	testq	%rdx, %rdx
     3a3: 0f 84 81 00 00 00            	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     3a9: 49 8d 94 24 1c fd ff ff      	leaq	-0x2e4(%r12), %rdx
     3b1: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     3b8: 77 0c                        	ja	0x3c6 <trusted_x86_x86_sim_xdp+0x3c6>
     3ba: 48 89 ca                     	movq	%rcx, %rdx
     3bd: 0f b6 52 0c                  	movzbl	0xc(%rdx), %edx
     3c1: 0f b6 d2                     	movzbl	%dl, %edx
     3c4: eb 02                        	jmp	0x3c8 <trusted_x86_x86_sim_xdp+0x3c8>
     3c6: 31 d2                        	xorl	%edx, %edx
     3c8: 48 8d 70 74                  	leaq	0x74(%rax), %rsi
     3cc: 88 16                        	movb	%dl, (%rsi)
     3ce: 48 85 d2                     	testq	%rdx, %rdx
     3d1: 74 57                        	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     3d3: 49 8d 94 24 1d fd ff ff      	leaq	-0x2e3(%r12), %rdx
     3db: 48 81 fa ff ef ff ff         	cmpq	$-0x1001, %rdx          # imm = 0xEFFF
     3e2: 77 0c                        	ja	0x3f0 <trusted_x86_x86_sim_xdp+0x3f0>
     3e4: 48 89 ca                     	movq	%rcx, %rdx
     3e7: 0f b6 52 0d                  	movzbl	0xd(%rdx), %edx
     3eb: 0f b6 d2                     	movzbl	%dl, %edx
     3ee: eb 02                        	jmp	0x3f2 <trusted_x86_x86_sim_xdp+0x3f2>
     3f0: 31 d2                        	xorl	%edx, %edx
     3f2: 48 8d 70 75                  	leaq	0x75(%rax), %rsi
     3f6: 88 16                        	movb	%dl, (%rsi)
     3f8: 48 85 d2                     	testq	%rdx, %rdx
     3fb: 74 2d                        	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     3fd: 49 81 c4 1e fd ff ff         	addq	$-0x2e2, %r12           # imm = 0xFD1E
     404: 49 81 fc ff ef ff ff         	cmpq	$-0x1001, %r12          # imm = 0xEFFF
     40b: 77 09                        	ja	0x416 <trusted_x86_x86_sim_xdp+0x416>
     40d: 0f b6 49 0e                  	movzbl	0xe(%rcx), %ecx
     411: 0f b6 c9                     	movzbl	%cl, %ecx
     414: eb 02                        	jmp	0x418 <trusted_x86_x86_sim_xdp+0x418>
     416: 31 c9                        	xorl	%ecx, %ecx
     418: 48 8d 50 76                  	leaq	0x76(%rax), %rdx
     41c: 88 0a                        	movb	%cl, (%rdx)
     41e: 48 85 c9                     	testq	%rcx, %rcx
     421: 74 07                        	je	0x42a <trusted_x86_x86_sim_xdp+0x42a>
     423: 48 8d 48 77                  	leaq	0x77(%rax), %rcx
     427: c6 01 00                     	movb	$0x0, (%rcx)
     42a: 4c 89 f1                     	movq	%r14, %rcx
     42d: 48 c1 e9 03                  	shrq	$0x3, %rcx
     431: 89 ca                        	movl	%ecx, %edx
     433: 49 c1 ee 23                  	shrq	$0x23, %r14
     437: be cf f7 53 e3               	movl	$0xe353f7cf, %esi       # imm = 0xE353F7CF
     43c: 48 69 fa a5 9b c4 20         	imulq	$0x20c49ba5, %rdx, %rdi # imm = 0x20C49BA5
     443: 48 0f af d6                  	imulq	%rsi, %rdx
     447: 49 0f af f6                  	imulq	%r14, %rsi
     44b: 4d 69 c6 a5 9b c4 20         	imulq	$0x20c49ba5, %r14, %r8  # imm = 0x20C49BA5
     452: 48 c1 ea 20                  	shrq	$0x20, %rdx
     456: 41 89 f9                     	movl	%edi, %r9d
     459: 89 f1                        	movl	%esi, %ecx
     45b: 4c 01 c9                     	addq	%r9, %rcx
     45e: 48 01 d1                     	addq	%rdx, %rcx
     461: 48 c1 ef 20                  	shrq	$0x20, %rdi
     465: 48 c1 ee 20                  	shrq	$0x20, %rsi
     469: 4c 01 c6                     	addq	%r8, %rsi
     46c: 48 01 fe                     	addq	%rdi, %rsi
     46f: 48 c1 e9 20                  	shrq	$0x20, %rcx
     473: 48 01 f1                     	addq	%rsi, %rcx
     476: 48 89 ce                     	movq	%rcx, %rsi
     479: 48 c1 ee 24                  	shrq	$0x24, %rsi
     47d: 74 57                        	je	0x4d6 <trusted_x86_x86_sim_xdp+0x4d6>
     47f: 31 d2                        	xorl	%edx, %edx
     481: 48 c1 e9 34                  	shrq	$0x34, %rcx
     485: 0f 95 c2                     	setne	%dl
     488: c1 e2 04                     	shll	$0x4, %edx
     48b: c4 e2 eb f7 f6               	shrxq	%rdx, %rsi, %rsi
     490: 31 c9                        	xorl	%ecx, %ecx
     492: 81 fe 00 01 00 00            	cmpl	$0x100, %esi            # imm = 0x100
     498: 0f 93 c1                     	setae	%cl
     49b: c1 e1 03                     	shll	$0x3, %ecx
     49e: c4 e2 73 f7 f6               	shrxl	%ecx, %esi, %esi
     4a3: 31 ff                        	xorl	%edi, %edi
     4a5: 83 fe 10                     	cmpl	$0x10, %esi
     4a8: 40 0f 93 c7                  	setae	%dil
     4ac: c1 e7 02                     	shll	$0x2, %edi
     4af: c4 e2 43 f7 f6               	shrxl	%edi, %esi, %esi
     4b4: 45 31 c0                     	xorl	%r8d, %r8d
     4b7: 83 fe 04                     	cmpl	$0x4, %esi
     4ba: 41 0f 93 c0                  	setae	%r8b
     4be: 45 01 c0                     	addl	%r8d, %r8d
     4c1: c4 e2 3b f7 f6               	shrxl	%r8d, %esi, %esi
     4c6: d1 ee                        	shrl	%esi
     4c8: 09 d1                        	orl	%edx, %ecx
     4ca: 09 f9                        	orl	%edi, %ecx
     4cc: 44 09 c1                     	orl	%r8d, %ecx
     4cf: 09 f1                        	orl	%esi, %ecx
     4d1: 83 c1 20                     	addl	$0x20, %ecx
     4d4: eb 5c                        	jmp	0x532 <trusted_x86_x86_sim_xdp+0x532>
     4d6: 48 89 ce                     	movq	%rcx, %rsi
     4d9: 48 c1 ee 04                  	shrq	$0x4, %rsi
     4dd: 31 d2                        	xorl	%edx, %edx
     4df: 48 81 f9 00 00 10 00         	cmpq	$0x100000, %rcx         # imm = 0x100000
     4e6: 0f 93 c2                     	setae	%dl
     4e9: c1 e2 04                     	shll	$0x4, %edx
     4ec: c4 e2 eb f7 f6               	shrxq	%rdx, %rsi, %rsi
     4f1: 31 c9                        	xorl	%ecx, %ecx
     4f3: 81 fe 00 01 00 00            	cmpl	$0x100, %esi            # imm = 0x100
     4f9: 0f 93 c1                     	setae	%cl
     4fc: c1 e1 03                     	shll	$0x3, %ecx
     4ff: c4 e2 73 f7 f6               	shrxl	%ecx, %esi, %esi
     504: 31 ff                        	xorl	%edi, %edi
     506: 83 fe 10                     	cmpl	$0x10, %esi
     509: 40 0f 93 c7                  	setae	%dil
     50d: c1 e7 02                     	shll	$0x2, %edi
     510: c4 e2 43 f7 f6               	shrxl	%edi, %esi, %esi
     515: 45 31 c0                     	xorl	%r8d, %r8d
     518: 83 fe 04                     	cmpl	$0x4, %esi
     51b: 41 0f 93 c0                  	setae	%r8b
     51f: 45 01 c0                     	addl	%r8d, %r8d
     522: c4 e2 3b f7 f6               	shrxl	%r8d, %esi, %esi
     527: d1 ee                        	shrl	%esi
     529: 09 d1                        	orl	%edx, %ecx
     52b: 09 f9                        	orl	%edi, %ecx
     52d: 44 09 c1                     	orl	%r8d, %ecx
     530: 09 f1                        	orl	%esi, %ecx
     532: 83 f9 19                     	cmpl	$0x19, %ecx
     535: ba 19 00 00 00               	movl	$0x19, %edx
     53a: 0f 42 d1                     	cmovbl	%ecx, %edx
     53d: f0                           	lock
     53e: ff 04 90                     	incl	(%rax,%rdx,4)
     541: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x548 <trusted_x86_x86_sim_xdp+0x548>
		0000000000000544:  R_X86_64_REX_GOTPCRELX	start-0x4
     548: 48 89 de                     	movq	%rbx, %rsi
     54b: e8 00 00 00 00               	callq	0x550 <trusted_x86_x86_sim_xdp+0x550>
		000000000000054c:  R_X86_64_PLT32	bpf_map_delete_elem-0x4
     550: 31 c0                        	xorl	%eax, %eax
     552: 48 83 c4 38                  	addq	$0x38, %rsp
     556: 5b                           	popq	%rbx
     557: 41 5c                        	popq	%r12
     559: 41 5e                        	popq	%r14
     55b: 41 5f                        	popq	%r15
     55d: c3                           	retq
