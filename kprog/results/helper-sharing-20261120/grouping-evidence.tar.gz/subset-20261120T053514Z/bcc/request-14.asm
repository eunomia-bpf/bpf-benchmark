
/var/tmp/kprog-tmp/perf/helper-sharing/14/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	data-0x4
       7: 74 37                        	je	0x40 <__kprog_hash_key_4>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	start-0x4
      10: 74 2e                        	je	0x40 <__kprog_hash_key_4>
      12: 8b 06                        	movl	(%rsi), %eax
      14: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      17: 73 1a                        	jae	0x33 <__kprog_array_lookup+0x33>
      19: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      1f: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      25: 48 0f af c1                  	imulq	%rcx, %rax
      29: 48 01 f8                     	addq	%rdi, %rax
      2c: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      32: c3                           	retq
      33: 31 c0                        	xorl	%eax, %eax
      35: c3                           	retq
      36: 66 2e 0f 1f 84 00 00 00 00 00	nopw	%cs:(%rax,%rax)

0000000000000040 <__kprog_hash_key_4>:
      40: b9 f3 be ad de               	movl	$0xdeadbef3, %ecx       # imm = 0xDEADBEF3
      45: 03 8f 40 03 00 00            	addl	0x340(%rdi), %ecx
      4b: 8b 06                        	movl	(%rsi), %eax
      4d: 01 c8                        	addl	%ecx, %eax
      4f: c4 e3 7b f0 d1 12            	rorxl	$0x12, %ecx, %edx
      55: f7 da                        	negl	%edx
      57: 31 d0                        	xorl	%edx, %eax
      59: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
      5f: 44 29 c0                     	subl	%r8d, %eax
      62: 31 c1                        	xorl	%eax, %ecx
      64: c4 63 7b f0 c0 07            	rorxl	$0x7, %eax, %r8d
      6a: 44 29 c1                     	subl	%r8d, %ecx
      6d: 31 ca                        	xorl	%ecx, %edx
      6f: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
      75: 44 29 c2                     	subl	%r8d, %edx
      78: 31 d0                        	xorl	%edx, %eax
      7a: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
      80: 44 29 c0                     	subl	%r8d, %eax
      83: 31 c1                        	xorl	%eax, %ecx
      85: c4 e3 7b f0 c0 12            	rorxl	$0x12, %eax, %eax
      8b: 29 c1                        	subl	%eax, %ecx
      8d: c4 e3 7b f0 c1 08            	rorxl	$0x8, %ecx, %eax
      93: 31 d1                        	xorl	%edx, %ecx
      95: 29 c1                        	subl	%eax, %ecx
      97: 8b 97 38 03 00 00            	movl	0x338(%rdi), %edx
      9d: ff ca                        	decl	%edx
      9f: 21 ca                        	andl	%ecx, %edx
      a1: 48 8b bf c0 01 00 00         	movq	0x1c0(%rdi), %rdi
      a8: 49 89 d0                     	movq	%rdx, %r8
      ab: 49 c1 e0 04                  	shlq	$0x4, %r8
      af: eb 17                        	jmp	0xc8 <__kprog_hash_key_4+0x88>
      b1: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
      c0: 48 d1 e8                     	shrq	%rax
      c3: 48 39 d0                     	cmpq	%rdx, %rax
      c6: 74 22                        	je	0xea <__kprog_hash_key_4+0xaa>
      c8: 4a 8b 04 07                  	movq	(%rdi,%r8), %rax
      cc: eb 05                        	jmp	0xd3 <__kprog_hash_key_4+0x93>
      ce: 66 90                        	nop
      d0: 48 8b 00                     	movq	(%rax), %rax
      d3: a8 01                        	testb	$0x1, %al
      d5: 75 e9                        	jne	0xc0 <__kprog_hash_key_4+0x80>
      d7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
      da: 75 f4                        	jne	0xd0 <__kprog_hash_key_4+0x90>
      dc: 44 8b 48 30                  	movl	0x30(%rax), %r9d
      e0: 44 3b 0e                     	cmpl	(%rsi), %r9d
      e3: 75 eb                        	jne	0xd0 <__kprog_hash_key_4+0x90>
      e5: 48 83 c0 38                  	addq	$0x38, %rax
      e9: c3                           	retq
      ea: 31 c0                        	xorl	%eax, %eax
      ec: c3                           	retq

Disassembly of section tracepoint/trusted/trusted:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 41 57                        	pushq	%r15
       2: 41 56                        	pushq	%r14
       4: 53                           	pushq	%rbx
       5: 48 83 ec 30                  	subq	$0x30, %rsp
       9: 49 89 fe                     	movq	%rdi, %r14
       c: 48 c7 44 24 28 00 00 00 00   	movq	$0x0, 0x28(%rsp)
      15: 48 c7 44 24 20 00 00 00 00   	movq	$0x0, 0x20(%rsp)
      1e: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
      27: e8 00 00 00 00               	callq	0x2c <trusted_x86_x86_sim_xdp+0x2c>
		0000000000000028:  R_X86_64_PLT32	bpf_get_current_pid_tgid-0x4
      2c: 89 44 24 14                  	movl	%eax, 0x14(%rsp)
      30: 49 8b 46 08                  	movq	0x8(%r14), %rax
      34: 48 83 f8 ff                  	cmpq	$-0x1, %rax
      38: 0f 84 8a 00 00 00            	je	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
      3e: 48 8d 74 24 14               	leaq	0x14(%rsp), %rsi
      43: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x4a <trusted_x86_x86_sim_xdp+0x4a>
		0000000000000046:  R_X86_64_REX_GOTPCRELX	start-0x4
      4a: e8 00 00 00 00               	callq	0x4f <trusted_x86_x86_sim_xdp+0x4f>
		000000000000004b:  R_X86_64_PLT32	.text+0x3c
      4f: 48 85 c0                     	testq	%rax, %rax
      52: 74 74                        	je	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
      54: 49 89 c7                     	movq	%rax, %r15
      57: e8 00 00 00 00               	callq	0x5c <trusted_x86_x86_sim_xdp+0x5c>
		0000000000000058:  R_X86_64_PLT32	bpf_ktime_get_ns-0x4
      5c: 48 89 c3                     	movq	%rax, %rbx
      5f: 49 2b 1f                     	subq	(%r15), %rbx
      62: 41 8b 46 08                  	movl	0x8(%r14), %eax
      66: 4c 8d 74 24 10               	leaq	0x10(%rsp), %r14
      6b: 89 44 24 10                  	movl	%eax, 0x10(%rsp)
      6f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x76 <trusted_x86_x86_sim_xdp+0x76>
		0000000000000072:  R_X86_64_REX_GOTPCRELX	data-0x4
      76: 4c 89 f6                     	movq	%r14, %rsi
      79: e8 00 00 00 00               	callq	0x7e <trusted_x86_x86_sim_xdp+0x7e>
		000000000000007a:  R_X86_64_PLT32	.text+0x3c
      7e: 48 85 c0                     	testq	%rax, %rax
      81: 74 02                        	je	0x85 <trusted_x86_x86_sim_xdp+0x85>
      83: eb 3a                        	jmp	0xbf <trusted_x86_x86_sim_xdp+0xbf>
      85: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x8c <trusted_x86_x86_sim_xdp+0x8c>
		0000000000000088:  R_X86_64_REX_GOTPCRELX	data-0x4
      8c: 48 8d 15 00 00 00 00         	leaq	(%rip), %rdx            # 0x93 <trusted_x86_x86_sim_xdp+0x93>
		000000000000008f:  R_X86_64_PC32	.rodata.native.0-0x4
      93: b9 01 00 00 00               	movl	$0x1, %ecx
      98: 4c 89 f6                     	movq	%r14, %rsi
      9b: e8 00 00 00 00               	callq	0xa0 <trusted_x86_x86_sim_xdp+0xa0>
		000000000000009c:  R_X86_64_PLT32	bpf_map_update_elem-0x4
      a0: 48 85 c0                     	testq	%rax, %rax
      a3: 74 06                        	je	0xab <trusted_x86_x86_sim_xdp+0xab>
      a5: 48 83 f8 ef                  	cmpq	$-0x11, %rax
      a9: 75 1d                        	jne	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
      ab: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xb2 <trusted_x86_x86_sim_xdp+0xb2>
		00000000000000ae:  R_X86_64_REX_GOTPCRELX	data-0x4
      b2: 4c 89 f6                     	movq	%r14, %rsi
      b5: e8 00 00 00 00               	callq	0xba <trusted_x86_x86_sim_xdp+0xba>
		00000000000000b6:  R_X86_64_PLT32	.text+0x3c
      ba: 48 85 c0                     	testq	%rax, %rax
      bd: 74 15                        	je	0xd4 <trusted_x86_x86_sim_xdp+0xd4>
      bf: f0                           	lock
      c0: 48 ff 00                     	incq	(%rax)
      c3: f0                           	lock
      c4: 48 01 58 08                  	addq	%rbx, 0x8(%rax)
      c8: 31 c0                        	xorl	%eax, %eax
      ca: 48 83 c4 30                  	addq	$0x30, %rsp
      ce: 5b                           	popq	%rbx
      cf: 41 5e                        	popq	%r14
      d1: 41 5f                        	popq	%r15
      d3: c3                           	retq
      d4: eb f2                        	jmp	0xc8 <trusted_x86_x86_sim_xdp+0xc8>
