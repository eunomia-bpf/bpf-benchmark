
/var/tmp/kprog-tmp/perf/helper-sharing/4/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
       7: 74 33                        	je	0x3c <__kprog_array_lookup+0x3c>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
      10: 74 2f                        	je	0x41 <__kprog_array_lookup+0x41>
      12: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x19 <__kprog_array_lookup+0x19>
		0000000000000015:  R_X86_64_REX_GOTPCRELX	hotspot_procs-0x4
      19: 74 2e                        	je	0x49 <__kprog_array_lookup+0x49>
      1b: 8b 06                        	movl	(%rsi), %eax
      1d: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      20: 73 2f                        	jae	0x51 <__kprog_array_lookup+0x51>
      22: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      28: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      2e: 48 0f af c1                  	imulq	%rcx, %rax
      32: 48 01 f8                     	addq	%rdi, %rax
      35: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      3b: c3                           	retq
      3c: 48 89 f7                     	movq	%rsi, %rdi
      3f: eb 1f                        	jmp	0x60 <__kprog_lpm_key_16>
      41: 48 89 f7                     	movq	%rsi, %rdi
      44: e9 c7 00 00 00               	jmp	0x110 <__kprog_hash_key_8>
      49: 48 89 f7                     	movq	%rsi, %rdi
      4c: e9 6f 01 00 00               	jmp	0x1c0 <__kprog_hash_key_4>
      51: 31 c0                        	xorl	%eax, %eax
      53: c3                           	retq
      54: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

0000000000000060 <__kprog_lpm_key_16>:
      60: 8b 07                        	movl	(%rdi), %eax
      62: 83 f8 60                     	cmpl	$0x60, %eax
      65: 76 03                        	jbe	0x6a <__kprog_lpm_key_16+0xa>
      67: 31 c0                        	xorl	%eax, %eax
      69: c3                           	retq
      6a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x71 <__kprog_lpm_key_16+0x11>
		000000000000006d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
      71: 48 8b 91 20 01 00 00         	movq	0x120(%rcx), %rdx
      78: 31 c9                        	xorl	%ecx, %ecx
      7a: eb 3f                        	jmp	0xbb <__kprog_lpm_key_16+0x5b>
      7c: 0f 1f 40 00                  	nopl	(%rax)
      80: 49 0f c8                     	bswapq	%r8
      83: 41 89 f1                     	movl	%esi, %r9d
      86: 41 f6 d9                     	negb	%r9b
      89: c4 42 b3 f7 c0               	shrxq	%r9, %r8, %r8
      8e: 4d 85 c0                     	testq	%r8, %r8
      91: 75 6e                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      93: f6 42 14 01                  	testb	$0x1, 0x14(%rdx)
      97: 48 0f 44 ca                  	cmoveq	%rdx, %rcx
      9b: 41 89 f0                     	movl	%esi, %r8d
      9e: 41 c1 e8 03                  	shrl	$0x3, %r8d
      a2: 46 0f b6 44 07 04            	movzbl	0x4(%rdi,%r8), %r8d
      a8: 40 f6 d6                     	notb	%sil
      ab: 40 80 e6 07                  	andb	$0x7, %sil
      af: c4 c2 4b f7 f0               	shrxl	%esi, %r8d, %esi
      b4: 83 e6 01                     	andl	$0x1, %esi
      b7: 48 8b 14 f2                  	movq	(%rdx,%rsi,8), %rdx
      bb: 48 85 d2                     	testq	%rdx, %rdx
      be: 74 41                        	je	0x101 <__kprog_lpm_key_16+0xa1>
      c0: 8b 72 10                     	movl	0x10(%rdx), %esi
      c3: 39 c6                        	cmpl	%eax, %esi
      c5: 77 3a                        	ja	0x101 <__kprog_lpm_key_16+0xa1>
      c7: 48 85 f6                     	testq	%rsi, %rsi
      ca: 74 c7                        	je	0x93 <__kprog_lpm_key_16+0x33>
      cc: 4c 8b 47 04                  	movq	0x4(%rdi), %r8
      d0: 4c 33 42 18                  	xorq	0x18(%rdx), %r8
      d4: 83 fe 40                     	cmpl	$0x40, %esi
      d7: 76 a7                        	jbe	0x80 <__kprog_lpm_key_16+0x20>
      d9: 4d 85 c0                     	testq	%r8, %r8
      dc: 75 23                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      de: 44 8b 42 20                  	movl	0x20(%rdx), %r8d
      e2: 44 33 47 0c                  	xorl	0xc(%rdi), %r8d
      e6: 41 0f c8                     	bswapl	%r8d
      e9: 41 89 f1                     	movl	%esi, %r9d
      ec: 41 f6 d9                     	negb	%r9b
      ef: c4 42 33 f7 c0               	shrxl	%r9d, %r8d, %r8d
      f4: 45 85 c0                     	testl	%r8d, %r8d
      f7: 75 08                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      f9: 83 fe 60                     	cmpl	$0x60, %esi
      fc: 75 95                        	jne	0x93 <__kprog_lpm_key_16+0x33>
      fe: 48 89 d1                     	movq	%rdx, %rcx
     101: 48 8d 41 24                  	leaq	0x24(%rcx), %rax
     105: 48 85 c9                     	testq	%rcx, %rcx
     108: 48 0f 44 c1                  	cmoveq	%rcx, %rax
     10c: c3                           	retq
     10d: 0f 1f 00                     	nopl	(%rax)

0000000000000110 <__kprog_hash_key_8>:
     110: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x117 <__kprog_hash_key_8+0x7>
		0000000000000113:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     117: ba f7 be ad de               	movl	$0xdeadbef7, %edx       # imm = 0xDEADBEF7
     11c: 03 90 40 03 00 00            	addl	0x340(%rax), %edx
     122: 8b 37                        	movl	(%rdi), %esi
     124: 01 d6                        	addl	%edx, %esi
     126: 8b 4f 04                     	movl	0x4(%rdi), %ecx
     129: 01 d1                        	addl	%edx, %ecx
     12b: 31 ca                        	xorl	%ecx, %edx
     12d: c4 63 7b f0 c1 12            	rorxl	$0x12, %ecx, %r8d
     133: 44 29 c2                     	subl	%r8d, %edx
     136: 31 d6                        	xorl	%edx, %esi
     138: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
     13e: 44 29 c6                     	subl	%r8d, %esi
     141: 31 f1                        	xorl	%esi, %ecx
     143: c4 63 7b f0 c6 07            	rorxl	$0x7, %esi, %r8d
     149: 44 29 c1                     	subl	%r8d, %ecx
     14c: 31 ca                        	xorl	%ecx, %edx
     14e: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
     154: 44 29 c2                     	subl	%r8d, %edx
     157: 31 d6                        	xorl	%edx, %esi
     159: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
     15f: 44 29 c6                     	subl	%r8d, %esi
     162: 31 f1                        	xorl	%esi, %ecx
     164: c4 e3 7b f0 f6 12            	rorxl	$0x12, %esi, %esi
     16a: 29 f1                        	subl	%esi, %ecx
     16c: c4 e3 7b f0 f1 08            	rorxl	$0x8, %ecx, %esi
     172: 31 d1                        	xorl	%edx, %ecx
     174: 29 f1                        	subl	%esi, %ecx
     176: 8b 90 38 03 00 00            	movl	0x338(%rax), %edx
     17c: ff ca                        	decl	%edx
     17e: 21 ca                        	andl	%ecx, %edx
     180: 48 8b b0 c0 01 00 00         	movq	0x1c0(%rax), %rsi
     187: 49 89 d0                     	movq	%rdx, %r8
     18a: 49 c1 e0 04                  	shlq	$0x4, %r8
     18e: eb 08                        	jmp	0x198 <__kprog_hash_key_8+0x88>
     190: 48 d1 e8                     	shrq	%rax
     193: 48 39 d0                     	cmpq	%rdx, %rax
     196: 74 22                        	je	0x1ba <__kprog_hash_key_8+0xaa>
     198: 4a 8b 04 06                  	movq	(%rsi,%r8), %rax
     19c: eb 05                        	jmp	0x1a3 <__kprog_hash_key_8+0x93>
     19e: 66 90                        	nop
     1a0: 48 8b 00                     	movq	(%rax), %rax
     1a3: a8 01                        	testb	$0x1, %al
     1a5: 75 e9                        	jne	0x190 <__kprog_hash_key_8+0x80>
     1a7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
     1aa: 75 f4                        	jne	0x1a0 <__kprog_hash_key_8+0x90>
     1ac: 4c 8b 48 30                  	movq	0x30(%rax), %r9
     1b0: 4c 3b 0f                     	cmpq	(%rdi), %r9
     1b3: 75 eb                        	jne	0x1a0 <__kprog_hash_key_8+0x90>
     1b5: 48 83 c0 38                  	addq	$0x38, %rax
     1b9: c3                           	retq
     1ba: 31 c0                        	xorl	%eax, %eax
     1bc: c3                           	retq
     1bd: 0f 1f 00                     	nopl	(%rax)

00000000000001c0 <__kprog_hash_key_4>:
     1c0: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1c7 <__kprog_hash_key_4+0x7>
		00000000000001c3:  R_X86_64_REX_GOTPCRELX	hotspot_procs-0x4
     1c7: b9 f3 be ad de               	movl	$0xdeadbef3, %ecx       # imm = 0xDEADBEF3
     1cc: 03 88 40 03 00 00            	addl	0x340(%rax), %ecx
     1d2: 8b 17                        	movl	(%rdi), %edx
     1d4: 01 ca                        	addl	%ecx, %edx
     1d6: c4 e3 7b f0 f1 12            	rorxl	$0x12, %ecx, %esi
     1dc: f7 de                        	negl	%esi
     1de: 31 f2                        	xorl	%esi, %edx
     1e0: c4 63 7b f0 c6 15            	rorxl	$0x15, %esi, %r8d
     1e6: 44 29 c2                     	subl	%r8d, %edx
     1e9: 31 d1                        	xorl	%edx, %ecx
     1eb: c4 63 7b f0 c2 07            	rorxl	$0x7, %edx, %r8d
     1f1: 44 29 c1                     	subl	%r8d, %ecx
     1f4: 31 ce                        	xorl	%ecx, %esi
     1f6: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
     1fc: 44 29 c6                     	subl	%r8d, %esi
     1ff: 31 f2                        	xorl	%esi, %edx
     201: c4 63 7b f0 c6 1c            	rorxl	$0x1c, %esi, %r8d
     207: 44 29 c2                     	subl	%r8d, %edx
     20a: 31 d1                        	xorl	%edx, %ecx
     20c: c4 e3 7b f0 d2 12            	rorxl	$0x12, %edx, %edx
     212: 29 d1                        	subl	%edx, %ecx
     214: c4 e3 7b f0 d1 08            	rorxl	$0x8, %ecx, %edx
     21a: 31 f1                        	xorl	%esi, %ecx
     21c: 29 d1                        	subl	%edx, %ecx
     21e: 8b 90 38 03 00 00            	movl	0x338(%rax), %edx
     224: ff ca                        	decl	%edx
     226: 21 ca                        	andl	%ecx, %edx
     228: 48 8b b0 c0 01 00 00         	movq	0x1c0(%rax), %rsi
     22f: 49 89 d0                     	movq	%rdx, %r8
     232: 49 c1 e0 04                  	shlq	$0x4, %r8
     236: eb 10                        	jmp	0x248 <__kprog_hash_key_4+0x88>
     238: 0f 1f 84 00 00 00 00 00      	nopl	(%rax,%rax)
     240: 48 d1 e8                     	shrq	%rax
     243: 48 39 d0                     	cmpq	%rdx, %rax
     246: 74 22                        	je	0x26a <__kprog_hash_key_4+0xaa>
     248: 4a 8b 04 06                  	movq	(%rsi,%r8), %rax
     24c: eb 05                        	jmp	0x253 <__kprog_hash_key_4+0x93>
     24e: 66 90                        	nop
     250: 48 8b 00                     	movq	(%rax), %rax
     253: a8 01                        	testb	$0x1, %al
     255: 75 e9                        	jne	0x240 <__kprog_hash_key_4+0x80>
     257: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
     25a: 75 f4                        	jne	0x250 <__kprog_hash_key_4+0x90>
     25c: 44 8b 48 30                  	movl	0x30(%rax), %r9d
     260: 44 3b 0f                     	cmpl	(%rdi), %r9d
     263: 75 eb                        	jne	0x250 <__kprog_hash_key_4+0x90>
     265: 48 83 c0 38                  	addq	$0x38, %rax
     269: c3                           	retq
     26a: 31 c0                        	xorl	%eax, %eax
     26c: c3                           	retq
     26d: 0f 1f 00                     	nopl	(%rax)

0000000000000270 <__kprog_probe_read_user>:
     270: 41 57                        	pushq	%r15
     272: 41 56                        	pushq	%r14
     274: 53                           	pushq	%rbx
     275: 49 89 fe                     	movq	%rdi, %r14
     278: 89 f3                        	movl	%esi, %ebx
     27a: 48 89 d6                     	movq	%rdx, %rsi
     27d: 48 89 da                     	movq	%rbx, %rdx
     280: e8 00 00 00 00               	callq	0x285 <__kprog_probe_read_user+0x15>
		0000000000000281:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     285: 49 89 c7                     	movq	%rax, %r15
     288: 45 85 ff                     	testl	%r15d, %r15d
     28b: 79 0d                        	jns	0x29a <__kprog_probe_read_user+0x2a>
     28d: 4c 89 f7                     	movq	%r14, %rdi
     290: 31 f6                        	xorl	%esi, %esi
     292: 48 89 da                     	movq	%rbx, %rdx
     295: e8 00 00 00 00               	callq	0x29a <__kprog_probe_read_user+0x2a>
		0000000000000296:  R_X86_64_PLT32	memset-0x4
     29a: 49 63 c7                     	movslq	%r15d, %rax
     29d: 5b                           	popq	%rbx
     29e: 41 5e                        	popq	%r14
     2a0: 41 5f                        	popq	%r15
     2a2: c3                           	retq
     2a3: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

00000000000002b0 <__kprog_probe_read_kernel>:
     2b0: 41 57                        	pushq	%r15
     2b2: 41 56                        	pushq	%r14
     2b4: 53                           	pushq	%rbx
     2b5: 49 89 fe                     	movq	%rdi, %r14
     2b8: 89 f3                        	movl	%esi, %ebx
     2ba: 48 89 d6                     	movq	%rdx, %rsi
     2bd: 48 89 da                     	movq	%rbx, %rdx
     2c0: e8 00 00 00 00               	callq	0x2c5 <__kprog_probe_read_kernel+0x15>
		00000000000002c1:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
     2c5: 49 89 c7                     	movq	%rax, %r15
     2c8: 45 85 ff                     	testl	%r15d, %r15d
     2cb: 79 0d                        	jns	0x2da <__kprog_probe_read_kernel+0x2a>
     2cd: 4c 89 f7                     	movq	%r14, %rdi
     2d0: 31 f6                        	xorl	%esi, %esi
     2d2: 48 89 da                     	movq	%rbx, %rdx
     2d5: e8 00 00 00 00               	callq	0x2da <__kprog_probe_read_kernel+0x2a>
		00000000000002d6:  R_X86_64_PLT32	memset-0x4
     2da: 49 63 c7                     	movslq	%r15d, %rax
     2dd: 5b                           	popq	%rbx
     2de: 41 5e                        	popq	%r14
     2e0: 41 5f                        	popq	%r15
     2e2: c3                           	retq

Disassembly of section perf_event:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec b8 01 00 00         	subq	$0x1b8, %rsp            # imm = 0x1B8
      11: 49 89 fd                     	movq	%rdi, %r13
      14: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
      19: c7 44 24 48 00 00 00 00      	movl	$0x0, 0x48(%rsp)
      21: 48 c7 84 24 10 01 00 00 00 00 00 00  	movq	$0x0, 0x110(%rsp)
      2d: 48 c7 84 24 18 01 00 00 00 00 00 00  	movq	$0x0, 0x118(%rsp)
      39: 48 c7 84 24 20 01 00 00 00 00 00 00  	movq	$0x0, 0x120(%rsp)
      45: 48 c7 84 24 28 01 00 00 00 00 00 00  	movq	$0x0, 0x128(%rsp)
      51: 48 c7 84 24 30 01 00 00 00 00 00 00  	movq	$0x0, 0x130(%rsp)
      5d: 48 c7 84 24 38 01 00 00 00 00 00 00  	movq	$0x0, 0x138(%rsp)
      69: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x70 <trusted_x86_x86_sim_xdp+0x70>
		000000000000006c:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      70: e8 00 00 00 00               	callq	0x75 <trusted_x86_x86_sim_xdp+0x75>
		0000000000000071:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      75: bb ff ff ff ff               	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      7a: 48 85 c0                     	testq	%rax, %rax
      7d: 0f 84 98 04 00 00            	je	0x51b <trusted_x86_x86_sim_xdp+0x51b>
      83: 49 89 c7                     	movq	%rax, %r15
      86: 8b 00                        	movl	(%rax), %eax
      88: 48 8d bc 24 0c 01 00 00      	leaq	0x10c(%rsp), %rdi
      90: 89 84 24 0c 01 00 00         	movl	%eax, 0x10c(%rsp)
      97: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x9e <trusted_x86_x86_sim_xdp+0x9e>
		000000000000009a:  R_X86_64_REX_GOTPCRELX	hotspot_procs-0x4
      9e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xa5 <trusted_x86_x86_sim_xdp+0xa5>
		00000000000000a1:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
      a5: 0f 85 86 01 00 00            	jne	0x231 <trusted_x86_x86_sim_xdp+0x231>
      ab: e8 00 00 00 00               	callq	0xb0 <trusted_x86_x86_sim_xdp+0xb0>
		00000000000000ac:  R_X86_64_PLT32	.text+0x5c
      b0: 48 89 c5                     	movq	%rax, %rbp
      b3: 48 85 c0                     	testq	%rax, %rax
      b6: 0f 84 a2 01 00 00            	je	0x25e <trusted_x86_x86_sim_xdp+0x25e>
      bc: 4c 89 ac 24 f8 00 00 00      	movq	%r13, 0xf8(%rsp)
      c4: c7 44 24 48 29 00 00 00      	movl	$0x29, 0x48(%rsp)
      cc: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xd3 <trusted_x86_x86_sim_xdp+0xd3>
		00000000000000cf:  R_X86_64_REX_GOTPCRELX	metrics-0x4
      d3: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
      d8: e8 00 00 00 00               	callq	0xdd <trusted_x86_x86_sim_xdp+0xdd>
		00000000000000d9:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      dd: 48 85 c0                     	testq	%rax, %rax
      e0: 74 0c                        	je	0xee <trusted_x86_x86_sim_xdp+0xee>
      e2: 48 89 c1                     	movq	%rax, %rcx
      e5: 48 8b 09                     	movq	(%rcx), %rcx
      e8: 48 ff c1                     	incq	%rcx
      eb: 48 89 08                     	movq	%rcx, (%rax)
      ee: 4c 89 f8                     	movq	%r15, %rax
      f1: 4c 8b a0 d0 0e 00 00         	movq	0xed0(%rax), %r12
      f8: 4c 89 f8                     	movq	%r15, %rax
      fb: 4c 8b b0 d8 0e 00 00         	movq	0xed8(%rax), %r14
     102: 4c 89 f8                     	movq	%r15, %rax
     105: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
     10c: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
     111: 48 89 2c 24                  	movq	%rbp, (%rsp)
     115: 0f b6 45 20                  	movzbl	0x20(%rbp), %eax
     119: 4c 89 f9                     	movq	%r15, %rcx
     11c: c4 e2 fb f7 a9 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %rbp
     125: 4c 89 f8                     	movq	%r15, %rax
     128: b1 38                        	movb	$0x38, %cl
     12a: c4 62 f0 f5 a8 10 0f 00 00   	bzhiq	%rcx, 0xf10(%rax), %r13
     133: 4c 89 ee                     	movq	%r13, %rsi
     136: 48 01 ee                     	addq	%rbp, %rsi
     139: ba 01 00 00 00               	movl	$0x1, %edx
     13e: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     143: e8 00 00 00 00               	callq	0x148 <trusted_x86_x86_sim_xdp+0x148>
		0000000000000144:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     148: 85 c0                        	testl	%eax, %eax
     14a: 79 05                        	jns	0x151 <trusted_x86_x86_sim_xdp+0x151>
     14c: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     151: 85 c0                        	testl	%eax, %eax
     153: 0f 84 0c 01 00 00            	je	0x265 <trusted_x86_x86_sim_xdp+0x265>
     159: 48 c7 84 24 b8 00 00 00 00 00 00 00  	movq	$0x0, 0xb8(%rsp)
     165: c7 44 24 48 2b 00 00 00      	movl	$0x2b, 0x48(%rsp)
     16d: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x174 <trusted_x86_x86_sim_xdp+0x174>
		0000000000000170:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     174: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     179: e8 00 00 00 00               	callq	0x17e <trusted_x86_x86_sim_xdp+0x17e>
		000000000000017a:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     17e: 41 be e8 03 00 00            	movl	$0x3e8, %r14d           # imm = 0x3E8
     184: 48 85 c0                     	testq	%rax, %rax
     187: 74 0c                        	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
     189: 48 89 c1                     	movq	%rax, %rcx
     18c: 48 8b 09                     	movq	(%rcx), %rcx
     18f: 48 ff c1                     	incq	%rcx
     192: 48 89 08                     	movq	%rcx, (%rax)
     195: 31 ed                        	xorl	%ebp, %ebp
     197: 4c 8b a4 24 f8 00 00 00      	movq	0xf8(%rsp), %r12
     19f: 49 81 c7 2c 0f 00 00         	addq	$0xf2c, %r15            # imm = 0xF2C
     1a6: 45 89 37                     	movl	%r14d, (%r15)
     1a9: c7 44 24 48 00 00 00 00      	movl	$0x0, 0x48(%rsp)
     1b1: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1b8 <trusted_x86_x86_sim_xdp+0x1b8>
		00000000000001b4:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
     1b8: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     1bd: e8 00 00 00 00               	callq	0x1c2 <trusted_x86_x86_sim_xdp+0x1c2>
		00000000000001be:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     1c2: 48 85 c0                     	testq	%rax, %rax
     1c5: 0f 84 3d 03 00 00            	je	0x508 <trusted_x86_x86_sim_xdp+0x508>
     1cb: 48 89 c1                     	movq	%rax, %rcx
     1ce: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
     1d5: 80 f9 1d                     	cmpb	$0x1d, %cl
     1d8: 72 48                        	jb	0x222 <trusted_x86_x86_sim_xdp+0x222>
     1da: 49 89 c6                     	movq	%rax, %r14
     1dd: 48 05 2c 0f 00 00            	addq	$0xf2c, %rax            # imm = 0xF2C
     1e3: c7 00 05 00 00 00            	movl	$0x5, (%rax)
     1e9: c7 44 24 48 44 00 00 00      	movl	$0x44, 0x48(%rsp)
     1f1: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1f8 <trusted_x86_x86_sim_xdp+0x1f8>
		00000000000001f4:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     1f8: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     1fd: e8 00 00 00 00               	callq	0x202 <trusted_x86_x86_sim_xdp+0x202>
		00000000000001fe:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     202: 48 85 c0                     	testq	%rax, %rax
     205: 74 0c                        	je	0x213 <trusted_x86_x86_sim_xdp+0x213>
     207: 48 89 c1                     	movq	%rax, %rcx
     20a: 48 8b 09                     	movq	(%rcx), %rcx
     20d: 48 ff c1                     	incq	%rcx
     210: 48 89 08                     	movq	%rcx, (%rax)
     213: 4c 89 f0                     	movq	%r14, %rax
     216: 4c 89 f1                     	movq	%r14, %rcx
     219: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
     220: 31 ed                        	xorl	%ebp, %ebp
     222: fe c1                        	incb	%cl
     224: 48 05 84 13 00 00            	addq	$0x1384, %rax           # imm = 0x1384
     22a: 88 08                        	movb	%cl, (%rax)
     22c: e9 d9 02 00 00               	jmp	0x50a <trusted_x86_x86_sim_xdp+0x50a>
     231: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x238 <trusted_x86_x86_sim_xdp+0x238>
		0000000000000234:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     238: 75 13                        	jne	0x24d <trusted_x86_x86_sim_xdp+0x24d>
     23a: e8 00 00 00 00               	callq	0x23f <trusted_x86_x86_sim_xdp+0x23f>
		000000000000023b:  R_X86_64_PLT32	.text+0x10c
     23f: 48 89 c5                     	movq	%rax, %rbp
     242: 48 85 c0                     	testq	%rax, %rax
     245: 0f 85 71 fe ff ff            	jne	0xbc <trusted_x86_x86_sim_xdp+0xbc>
     24b: eb 11                        	jmp	0x25e <trusted_x86_x86_sim_xdp+0x25e>
     24d: e8 00 00 00 00               	callq	0x252 <trusted_x86_x86_sim_xdp+0x252>
		000000000000024e:  R_X86_64_PLT32	.text+0x1bc
     252: 48 89 c5                     	movq	%rax, %rbp
     255: 48 85 c0                     	testq	%rax, %rax
     258: 0f 85 5e fe ff ff            	jne	0xbc <trusted_x86_x86_sim_xdp+0xbc>
     25e: 31 db                        	xorl	%ebx, %ebx
     260: e9 b6 02 00 00               	jmp	0x51b <trusted_x86_x86_sim_xdp+0x51b>
     265: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     26a: 8d 48 01                     	leal	0x1(%rax), %ecx
     26d: f6 c1 fe                     	testb	$-0x2, %cl
     270: 0f 84 b9 02 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     276: 89 c0                        	movl	%eax, %eax
     278: 48 29 c5                     	subq	%rax, %rbp
     27b: 48 89 ee                     	movq	%rbp, %rsi
     27e: 4c 01 ee                     	addq	%r13, %rsi
     281: ba 01 00 00 00               	movl	$0x1, %edx
     286: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     28b: e8 00 00 00 00               	callq	0x290 <trusted_x86_x86_sim_xdp+0x290>
		000000000000028c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     290: 85 c0                        	testl	%eax, %eax
     292: 79 05                        	jns	0x299 <trusted_x86_x86_sim_xdp+0x299>
     294: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     299: 85 c0                        	testl	%eax, %eax
     29b: 0f 85 b8 fe ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     2a1: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     2a6: 8d 48 01                     	leal	0x1(%rax), %ecx
     2a9: f6 c1 fe                     	testb	$-0x2, %cl
     2ac: 0f 84 7d 02 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     2b2: 89 c0                        	movl	%eax, %eax
     2b4: 48 29 c5                     	subq	%rax, %rbp
     2b7: 48 89 ee                     	movq	%rbp, %rsi
     2ba: 4c 01 ee                     	addq	%r13, %rsi
     2bd: ba 01 00 00 00               	movl	$0x1, %edx
     2c2: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     2c7: e8 00 00 00 00               	callq	0x2cc <trusted_x86_x86_sim_xdp+0x2cc>
		00000000000002c8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     2cc: 85 c0                        	testl	%eax, %eax
     2ce: 79 05                        	jns	0x2d5 <trusted_x86_x86_sim_xdp+0x2d5>
     2d0: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     2d5: 85 c0                        	testl	%eax, %eax
     2d7: 0f 85 7c fe ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     2dd: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     2e2: 8d 48 01                     	leal	0x1(%rax), %ecx
     2e5: f6 c1 fe                     	testb	$-0x2, %cl
     2e8: 0f 84 41 02 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     2ee: 89 c0                        	movl	%eax, %eax
     2f0: 48 29 c5                     	subq	%rax, %rbp
     2f3: 48 89 ee                     	movq	%rbp, %rsi
     2f6: 4c 01 ee                     	addq	%r13, %rsi
     2f9: ba 01 00 00 00               	movl	$0x1, %edx
     2fe: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     303: e8 00 00 00 00               	callq	0x308 <trusted_x86_x86_sim_xdp+0x308>
		0000000000000304:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     308: 85 c0                        	testl	%eax, %eax
     30a: 79 05                        	jns	0x311 <trusted_x86_x86_sim_xdp+0x311>
     30c: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     311: 85 c0                        	testl	%eax, %eax
     313: 0f 85 40 fe ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     319: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     31e: 8d 48 01                     	leal	0x1(%rax), %ecx
     321: f6 c1 fe                     	testb	$-0x2, %cl
     324: 0f 84 05 02 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     32a: 89 c0                        	movl	%eax, %eax
     32c: 48 29 c5                     	subq	%rax, %rbp
     32f: 48 89 ee                     	movq	%rbp, %rsi
     332: 4c 01 ee                     	addq	%r13, %rsi
     335: ba 01 00 00 00               	movl	$0x1, %edx
     33a: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     33f: e8 00 00 00 00               	callq	0x344 <trusted_x86_x86_sim_xdp+0x344>
		0000000000000340:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     344: 85 c0                        	testl	%eax, %eax
     346: 79 05                        	jns	0x34d <trusted_x86_x86_sim_xdp+0x34d>
     348: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     34d: 85 c0                        	testl	%eax, %eax
     34f: 0f 85 04 fe ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     355: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     35a: 8d 48 01                     	leal	0x1(%rax), %ecx
     35d: f6 c1 fe                     	testb	$-0x2, %cl
     360: 0f 84 c9 01 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     366: 89 c0                        	movl	%eax, %eax
     368: 48 29 c5                     	subq	%rax, %rbp
     36b: 48 89 ee                     	movq	%rbp, %rsi
     36e: 4c 01 ee                     	addq	%r13, %rsi
     371: ba 01 00 00 00               	movl	$0x1, %edx
     376: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     37b: e8 00 00 00 00               	callq	0x380 <trusted_x86_x86_sim_xdp+0x380>
		000000000000037c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     380: 85 c0                        	testl	%eax, %eax
     382: 79 05                        	jns	0x389 <trusted_x86_x86_sim_xdp+0x389>
     384: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     389: 85 c0                        	testl	%eax, %eax
     38b: 0f 85 c8 fd ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     391: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     396: 8d 48 01                     	leal	0x1(%rax), %ecx
     399: f6 c1 fe                     	testb	$-0x2, %cl
     39c: 0f 84 8d 01 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     3a2: 89 c0                        	movl	%eax, %eax
     3a4: 48 29 c5                     	subq	%rax, %rbp
     3a7: 48 89 ee                     	movq	%rbp, %rsi
     3aa: 4c 01 ee                     	addq	%r13, %rsi
     3ad: ba 01 00 00 00               	movl	$0x1, %edx
     3b2: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     3b7: e8 00 00 00 00               	callq	0x3bc <trusted_x86_x86_sim_xdp+0x3bc>
		00000000000003b8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     3bc: 85 c0                        	testl	%eax, %eax
     3be: 79 05                        	jns	0x3c5 <trusted_x86_x86_sim_xdp+0x3c5>
     3c0: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     3c5: 85 c0                        	testl	%eax, %eax
     3c7: 0f 85 8c fd ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     3cd: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     3d2: 8d 48 01                     	leal	0x1(%rax), %ecx
     3d5: f6 c1 fe                     	testb	$-0x2, %cl
     3d8: 0f 84 51 01 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     3de: 89 c0                        	movl	%eax, %eax
     3e0: 48 29 c5                     	subq	%rax, %rbp
     3e3: 48 89 ee                     	movq	%rbp, %rsi
     3e6: 4c 01 ee                     	addq	%r13, %rsi
     3e9: ba 01 00 00 00               	movl	$0x1, %edx
     3ee: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     3f3: e8 00 00 00 00               	callq	0x3f8 <trusted_x86_x86_sim_xdp+0x3f8>
		00000000000003f4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     3f8: 85 c0                        	testl	%eax, %eax
     3fa: 79 05                        	jns	0x401 <trusted_x86_x86_sim_xdp+0x401>
     3fc: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     401: 85 c0                        	testl	%eax, %eax
     403: 0f 85 50 fd ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     409: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     40e: 8d 48 01                     	leal	0x1(%rax), %ecx
     411: f6 c1 fe                     	testb	$-0x2, %cl
     414: 0f 84 15 01 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     41a: 89 c0                        	movl	%eax, %eax
     41c: 48 29 c5                     	subq	%rax, %rbp
     41f: 48 89 ee                     	movq	%rbp, %rsi
     422: 4c 01 ee                     	addq	%r13, %rsi
     425: ba 01 00 00 00               	movl	$0x1, %edx
     42a: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     42f: e8 00 00 00 00               	callq	0x434 <trusted_x86_x86_sim_xdp+0x434>
		0000000000000430:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     434: 85 c0                        	testl	%eax, %eax
     436: 79 05                        	jns	0x43d <trusted_x86_x86_sim_xdp+0x43d>
     438: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     43d: 85 c0                        	testl	%eax, %eax
     43f: 0f 85 14 fd ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     445: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     44a: 8d 48 01                     	leal	0x1(%rax), %ecx
     44d: f6 c1 fe                     	testb	$-0x2, %cl
     450: 0f 84 d9 00 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     456: 89 c0                        	movl	%eax, %eax
     458: 48 29 c5                     	subq	%rax, %rbp
     45b: 48 89 ee                     	movq	%rbp, %rsi
     45e: 4c 01 ee                     	addq	%r13, %rsi
     461: ba 01 00 00 00               	movl	$0x1, %edx
     466: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     46b: e8 00 00 00 00               	callq	0x470 <trusted_x86_x86_sim_xdp+0x470>
		000000000000046c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     470: 85 c0                        	testl	%eax, %eax
     472: 79 05                        	jns	0x479 <trusted_x86_x86_sim_xdp+0x479>
     474: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     479: 85 c0                        	testl	%eax, %eax
     47b: 0f 85 d8 fc ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     481: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     486: 8d 48 01                     	leal	0x1(%rax), %ecx
     489: f6 c1 fe                     	testb	$-0x2, %cl
     48c: 0f 84 9d 00 00 00            	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     492: 89 c0                        	movl	%eax, %eax
     494: 48 29 c5                     	subq	%rax, %rbp
     497: 48 89 ee                     	movq	%rbp, %rsi
     49a: 4c 01 ee                     	addq	%r13, %rsi
     49d: ba 01 00 00 00               	movl	$0x1, %edx
     4a2: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     4a7: e8 00 00 00 00               	callq	0x4ac <trusted_x86_x86_sim_xdp+0x4ac>
		00000000000004a8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     4ac: 85 c0                        	testl	%eax, %eax
     4ae: 79 05                        	jns	0x4b5 <trusted_x86_x86_sim_xdp+0x4b5>
     4b0: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     4b5: 85 c0                        	testl	%eax, %eax
     4b7: 0f 85 9c fc ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     4bd: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     4c2: 8d 48 01                     	leal	0x1(%rax), %ecx
     4c5: f6 c1 fe                     	testb	$-0x2, %cl
     4c8: 74 65                        	je	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     4ca: 89 c0                        	movl	%eax, %eax
     4cc: 48 29 c5                     	subq	%rax, %rbp
     4cf: 49 01 ed                     	addq	%rbp, %r13
     4d2: ba 01 00 00 00               	movl	$0x1, %edx
     4d7: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     4dc: 4c 89 ee                     	movq	%r13, %rsi
     4df: e8 00 00 00 00               	callq	0x4e4 <trusted_x86_x86_sim_xdp+0x4e4>
		00000000000004e0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     4e4: 85 c0                        	testl	%eax, %eax
     4e6: 79 05                        	jns	0x4ed <trusted_x86_x86_sim_xdp+0x4ed>
     4e8: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
     4ed: 85 c0                        	testl	%eax, %eax
     4ef: 0f 85 64 fc ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     4f5: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
     4fa: 8d 48 01                     	leal	0x1(%rax), %ecx
     4fd: f6 c1 fe                     	testb	$-0x2, %cl
     500: 0f 85 53 fc ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     506: eb 27                        	jmp	0x52f <trusted_x86_x86_sim_xdp+0x52f>
     508: 31 ed                        	xorl	%ebp, %ebp
     50a: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x511 <trusted_x86_x86_sim_xdp+0x511>
		000000000000050d:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
     511: 4c 89 e7                     	movq	%r12, %rdi
     514: 89 ea                        	movl	%ebp, %edx
     516: e8 00 00 00 00               	callq	0x51b <trusted_x86_x86_sim_xdp+0x51b>
		0000000000000517:  R_X86_64_PLT32	bpf_tail_call-0x4
     51b: 89 d8                        	movl	%ebx, %eax
     51d: 48 81 c4 b8 01 00 00         	addq	$0x1b8, %rsp            # imm = 0x1B8
     524: 5b                           	popq	%rbx
     525: 41 5c                        	popq	%r12
     527: 41 5d                        	popq	%r13
     529: 41 5e                        	popq	%r14
     52b: 41 5f                        	popq	%r15
     52d: 5d                           	popq	%rbp
     52e: c3                           	retq
     52f: 85 c0                        	testl	%eax, %eax
     531: 0f 85 22 fc ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
     537: 48 8b 0c 24                  	movq	(%rsp), %rcx
     53b: 48 89 c8                     	movq	%rcx, %rax
     53e: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
     542: c4 e2 f9 f7 c5               	shlxq	%rax, %rbp, %rax
     547: 48 89 ca                     	movq	%rcx, %rdx
     54a: 4c 89 f9                     	movq	%r15, %rcx
     54d: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
     554: 48 89 d1                     	movq	%rdx, %rcx
     557: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
     55b: 48 01 c6                     	addq	%rax, %rsi
     55e: 48 89 b4 24 b8 00 00 00      	movq	%rsi, 0xb8(%rsp)
     566: 0f 84 f9 fb ff ff            	je	0x165 <trusted_x86_x86_sim_xdp+0x165>
     56c: 4d 8d af 80 0f 00 00         	leaq	0xf80(%r15), %r13
     573: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
     578: 4c 89 ef                     	movq	%r13, %rdi
     57b: e8 00 00 00 00               	callq	0x580 <trusted_x86_x86_sim_xdp+0x580>
		000000000000057c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     580: 48 89 c5                     	movq	%rax, %rbp
     583: 85 ed                        	testl	%ebp, %ebp
     585: 79 0f                        	jns	0x596 <trusted_x86_x86_sim_xdp+0x596>
     587: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
     58c: 4c 89 ef                     	movq	%r13, %rdi
     58f: 31 f6                        	xorl	%esi, %esi
     591: e8 00 00 00 00               	callq	0x596 <trusted_x86_x86_sim_xdp+0x596>
		0000000000000592:  R_X86_64_PLT32	memset-0x4
     596: 85 ed                        	testl	%ebp, %ebp
     598: 74 36                        	je	0x5d0 <trusted_x86_x86_sim_xdp+0x5d0>
     59a: c7 44 24 48 2c 00 00 00      	movl	$0x2c, 0x48(%rsp)
     5a2: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x5a9 <trusted_x86_x86_sim_xdp+0x5a9>
		00000000000005a5:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     5a9: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     5ae: e8 00 00 00 00               	callq	0x5b3 <trusted_x86_x86_sim_xdp+0x5b3>
		00000000000005af:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     5b3: 41 be eb 03 00 00            	movl	$0x3eb, %r14d           # imm = 0x3EB
     5b9: 48 85 c0                     	testq	%rax, %rax
     5bc: 0f 84 d3 fb ff ff            	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
     5c2: 48 89 c1                     	movq	%rax, %rcx
     5c5: 48 8b 09                     	movq	(%rcx), %rcx
     5c8: 48 ff c1                     	incq	%rcx
     5cb: e9 c2 fb ff ff               	jmp	0x192 <trusted_x86_x86_sim_xdp+0x192>
     5d0: 48 8b 2c 24                  	movq	(%rsp), %rbp
     5d4: 48 89 e8                     	movq	%rbp, %rax
     5d7: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
     5db: 0f b7 c0                     	movzwl	%ax, %eax
     5de: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
     5e3: 0f 87 9e 2c 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
     5e9: 48 89 e9                     	movq	%rbp, %rcx
     5ec: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
     5f0: 0f b7 c9                     	movzwl	%cx, %ecx
     5f3: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
     5f9: 0f 87 88 2c 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
     5ff: 48 89 ea                     	movq	%rbp, %rdx
     602: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
     606: 0f b7 d2                     	movzwl	%dx, %edx
     609: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
     60f: 0f 87 72 2c 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
     615: 48 89 ee                     	movq	%rbp, %rsi
     618: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
     61c: 40 0f b6 f6                  	movzbl	%sil, %esi
     620: 4c 01 ee                     	addq	%r13, %rsi
     623: 48 8b 36                     	movq	(%rsi), %rsi
     626: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
     62e: 48 89 ee                     	movq	%rbp, %rsi
     631: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
     635: 40 0f b6 f6                  	movzbl	%sil, %esi
     639: 4c 01 ee                     	addq	%r13, %rsi
     63c: 48 8b 36                     	movq	(%rsi), %rsi
     63f: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
     647: 48 89 ee                     	movq	%rbp, %rsi
     64a: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
     64e: 40 0f b6 f6                  	movzbl	%sil, %esi
     652: 4c 01 ee                     	addq	%r13, %rsi
     655: 8b 36                        	movl	(%rsi), %esi
     657: c1 e6 03                     	shll	$0x3, %esi
     65a: 89 b4 24 e0 00 00 00         	movl	%esi, 0xe0(%rsp)
     661: 48 89 ee                     	movq	%rbp, %rsi
     664: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
     668: 40 0f b6 f6                  	movzbl	%sil, %esi
     66c: 4c 01 ee                     	addq	%r13, %rsi
     66f: 0f b7 36                     	movzwl	(%rsi), %esi
     672: 66 89 b4 24 e8 00 00 00      	movw	%si, 0xe8(%rsp)
     67a: 4c 01 e9                     	addq	%r13, %rcx
     67d: 8b 09                        	movl	(%rcx), %ecx
     67f: 89 8c 24 e4 00 00 00         	movl	%ecx, 0xe4(%rsp)
     686: 4c 01 ea                     	addq	%r13, %rdx
     689: 8b 0a                        	movl	(%rdx), %ecx
     68b: 89 8c 24 dc 00 00 00         	movl	%ecx, 0xdc(%rsp)
     692: 48 8d bc 24 d8 00 00 00      	leaq	0xd8(%rsp), %rdi
     69a: 4c 01 e8                     	addq	%r13, %rax
     69d: 48 8b 00                     	movq	(%rax), %rax
     6a0: 48 89 84 24 d0 00 00 00      	movq	%rax, 0xd0(%rsp)
     6a8: 48 89 e8                     	movq	%rbp, %rax
     6ab: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
     6af: 0f b6 c0                     	movzbl	%al, %eax
     6b2: 4c 01 e8                     	addq	%r13, %rax
     6b5: 48 8b 30                     	movq	(%rax), %rsi
     6b8: ba 04 00 00 00               	movl	$0x4, %edx
     6bd: e8 00 00 00 00               	callq	0x6c2 <trusted_x86_x86_sim_xdp+0x6c2>
		00000000000006be:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     6c2: 85 c0                        	testl	%eax, %eax
     6c4: 79 0b                        	jns	0x6d1 <trusted_x86_x86_sim_xdp+0x6d1>
     6c6: c7 84 24 d8 00 00 00 00 00 00 00     	movl	$0x0, 0xd8(%rsp)
     6d1: 85 c0                        	testl	%eax, %eax
     6d3: 0f 85 c1 fe ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
     6d9: 48 89 e8                     	movq	%rbp, %rax
     6dc: 0f b6 50 21                  	movzbl	0x21(%rax), %edx
     6e0: 48 8b 84 24 b8 00 00 00      	movq	0xb8(%rsp), %rax
     6e8: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
     6f0: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
     6f5: 84 d2                        	testb	%dl, %dl
     6f7: 74 1f                        	je	0x718 <trusted_x86_x86_sim_xdp+0x718>
     6f9: 89 c9                        	movl	%ecx, %ecx
     6fb: 48 01 c1                     	addq	%rax, %rcx
     6fe: 48 89 8c 24 c0 00 00 00      	movq	%rcx, 0xc0(%rsp)
     706: 8b b4 24 c8 00 00 00         	movl	0xc8(%rsp), %esi
     70d: 48 01 c6                     	addq	%rax, %rsi
     710: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
     718: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     71d: 8b 84 24 d8 00 00 00         	movl	0xd8(%rsp), %eax
     724: 44 89 e6                     	movl	%r12d, %esi
     727: 29 ce                        	subl	%ecx, %esi
     729: 48 89 b4 24 b0 00 00 00      	movq	%rsi, 0xb0(%rsp)
     731: 3d 6d 61 74 69               	cmpl	$0x6974616d, %eax       # imm = 0x6974616D
     736: 7f 18                        	jg	0x750 <trusted_x86_x86_sim_xdp+0x750>
     738: 3d 76 74 61 62               	cmpl	$0x62617476, %eax       # imm = 0x62617476
     73d: 0f 85 e8 00 00 00            	jne	0x82b <trusted_x86_x86_sim_xdp+0x82b>
     743: c7 44 24 28 01 00 00 00      	movl	$0x1, 0x28(%rsp)
     74b: e9 d1 00 00 00               	jmp	0x821 <trusted_x86_x86_sim_xdp+0x821>
     750: 3d 6e 6d 65 74               	cmpl	$0x74656d6e, %eax       # imm = 0x74656D6E
     755: 74 0b                        	je	0x762 <trusted_x86_x86_sim_xdp+0x762>
     757: 3d 6e 61 74 69               	cmpl	$0x6974616e, %eax       # imm = 0x6974616E
     75c: 0f 85 9d 01 00 00            	jne	0x8ff <trusted_x86_x86_sim_xdp+0x8ff>
     762: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
     76a: 89 c6                        	movl	%eax, %esi
     76c: 48 03 74 24 38               	addq	0x38(%rsp), %rsi
     771: 4c 89 ff                     	movq	%r15, %rdi
     774: 0f b6 af 30 0f 00 00         	movzbl	0xf30(%rdi), %ebp
     77b: 84 d2                        	testb	%dl, %dl
     77d: 8b 94 24 e4 00 00 00         	movl	0xe4(%rsp), %edx
     784: 48 89 54 24 30               	movq	%rdx, 0x30(%rsp)
     789: 48 0f 44 f0                  	cmoveq	%rax, %rsi
     78d: 49 39 f4                     	cmpq	%rsi, %r12
     790: 75 54                        	jne	0x7e6 <trusted_x86_x86_sim_xdp+0x7e6>
     792: 8b b4 24 dc 00 00 00         	movl	0xdc(%rsp), %esi
     799: 4c 01 f6                     	addq	%r14, %rsi
     79c: ba 08 00 00 00               	movl	$0x8, %edx
     7a1: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     7a6: e8 00 00 00 00               	callq	0x7ab <trusted_x86_x86_sim_xdp+0x7ab>
		00000000000007a7:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     7ab: 85 c0                        	testl	%eax, %eax
     7ad: 79 09                        	jns	0x7b8 <trusted_x86_x86_sim_xdp+0x7b8>
     7af: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
     7b8: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
     7c0: 85 c0                        	testl	%eax, %eax
     7c2: 75 22                        	jne	0x7e6 <trusted_x86_x86_sim_xdp+0x7e6>
     7c4: 48 8b 74 24 48               	movq	0x48(%rsp), %rsi
     7c9: 48 39 ce                     	cmpq	%rcx, %rsi
     7cc: 72 18                        	jb	0x7e6 <trusted_x86_x86_sim_xdp+0x7e6>
     7ce: 48 3b b4 24 c8 00 00 00      	cmpq	0xc8(%rsp), %rsi
     7d6: 73 0e                        	jae	0x7e6 <trusted_x86_x86_sim_xdp+0x7e6>
     7d8: 89 f0                        	movl	%esi, %eax
     7da: 29 c8                        	subl	%ecx, %eax
     7dc: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
     7e4: eb 03                        	jmp	0x7e9 <trusted_x86_x86_sim_xdp+0x7e9>
     7e6: 4c 89 e6                     	movq	%r12, %rsi
     7e9: 0f b7 94 24 e8 00 00 00      	movzwl	0xe8(%rsp), %edx
     7f1: 48 01 ca                     	addq	%rcx, %rdx
     7f4: 48 39 f2                     	cmpq	%rsi, %rdx
     7f7: 0f 86 23 01 00 00            	jbe	0x920 <trusted_x86_x86_sim_xdp+0x920>
     7fd: 48 83 c2 fc                  	addq	$-0x4, %rdx
     801: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
     807: 83 c9 03                     	orl	$0x3, %ecx
     80a: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
     80e: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     813: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
     818: 48 39 f2                     	cmpq	%rsi, %rdx
     81b: 0f 86 72 01 00 00            	jbe	0x993 <trusted_x86_x86_sim_xdp+0x993>
     821: b9 08 00 00 00               	movl	$0x8, %ecx
     826: e9 6d 01 00 00               	jmp	0x998 <trusted_x86_x86_sim_xdp+0x998>
     82b: 3d 49 6e 74 65               	cmpl	$0x65746e49, %eax       # imm = 0x65746E49
     830: 0f 85 c9 00 00 00            	jne	0x8ff <trusted_x86_x86_sim_xdp+0x8ff>
     836: 4c 39 f5                     	cmpq	%r14, %rbp
     839: 0f 82 80 05 00 00            	jb	0xdbf <trusted_x86_x86_sim_xdp+0xdbf>
     83f: 49 81 c6 00 10 00 00         	addq	$0x1000, %r14           # imm = 0x1000
     846: 4c 39 f5                     	cmpq	%r14, %rbp
     849: 0f 83 70 05 00 00            	jae	0xdbf <trusted_x86_x86_sim_xdp+0xdbf>
     84f: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
     854: 48 83 c6 b0                  	addq	$-0x50, %rsi
     858: ba 60 00 00 00               	movl	$0x60, %edx
     85d: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     862: e8 00 00 00 00               	callq	0x867 <trusted_x86_x86_sim_xdp+0x867>
		0000000000000863:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     867: 85 c0                        	testl	%eax, %eax
     869: 79 64                        	jns	0x8cf <trusted_x86_x86_sim_xdp+0x8cf>
     86b: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
     870: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
     878: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
     880: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
     888: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
     890: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
     898: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
     8a0: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
     8a8: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
     8b0: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
     8b8: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
     8c0: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
     8c8: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     8cf: 85 c0                        	testl	%eax, %eax
     8d1: 0f 85 e8 04 00 00            	jne	0xdbf <trusted_x86_x86_sim_xdp+0xdbf>
     8d7: 4c 89 f8                     	movq	%r15, %rax
     8da: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
     8e1: 0f 84 72 04 00 00            	je	0xd59 <trusted_x86_x86_sim_xdp+0xd59>
     8e7: 48 8b 04 24                  	movq	(%rsp), %rax
     8eb: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
     8ef: 0f 84 70 04 00 00            	je	0xd65 <trusted_x86_x86_sim_xdp+0xd65>
     8f5: 48 8b 6c 24 58               	movq	0x58(%rsp), %rbp
     8fa: e9 6b 04 00 00               	jmp	0xd6a <trusted_x86_x86_sim_xdp+0xd6a>
     8ff: 8b 8c 24 e0 00 00 00         	movl	0xe0(%rsp), %ecx
     906: c7 44 24 28 00 00 00 00      	movl	$0x0, 0x28(%rsp)
     90e: 85 c9                        	testl	%ecx, %ecx
     910: 0f 85 89 00 00 00            	jne	0x99f <trusted_x86_x86_sim_xdp+0x99f>
     916: b9 10 00 00 00               	movl	$0x10, %ecx
     91b: 49 89 ee                     	movq	%rbp, %r14
     91e: eb 78                        	jmp	0x998 <trusted_x86_x86_sim_xdp+0x998>
     920: 40 84 ed                     	testb	%bpl, %bpl
     923: 75 34                        	jne	0x959 <trusted_x86_x86_sim_xdp+0x959>
     925: 48 ff ce                     	decq	%rsi
     928: ba 0e 00 00 00               	movl	$0xe, %edx
     92d: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     932: e8 00 00 00 00               	callq	0x937 <trusted_x86_x86_sim_xdp+0x937>
		0000000000000933:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     937: 85 c0                        	testl	%eax, %eax
     939: 79 14                        	jns	0x94f <trusted_x86_x86_sim_xdp+0x94f>
     93b: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
     940: 48 c7 41 06 00 00 00 00      	movq	$0x0, 0x6(%rcx)
     948: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
     94f: 85 c0                        	testl	%eax, %eax
     951: 0f 84 9f 02 00 00            	je	0xbf6 <trusted_x86_x86_sim_xdp+0xbf6>
     957: 31 c9                        	xorl	%ecx, %ecx
     959: 8b b4 24 e0 00 00 00         	movl	0xe0(%rsp), %esi
     960: 4c 01 f6                     	addq	%r14, %rsi
     963: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     968: 4c 39 f5                     	cmpq	%r14, %rbp
     96b: 0f 82 c5 00 00 00            	jb	0xa36 <trusted_x86_x86_sim_xdp+0xa36>
     971: 48 8d 46 30                  	leaq	0x30(%rsi), %rax
     975: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
     97b: 83 c9 03                     	orl	$0x3, %ecx
     97e: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
     982: 48 39 c5                     	cmpq	%rax, %rbp
     985: 0f 83 ab 00 00 00            	jae	0xa36 <trusted_x86_x86_sim_xdp+0xa36>
     98b: 49 89 ee                     	movq	%rbp, %r14
     98e: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
     993: b9 10 00 00 00               	movl	$0x10, %ecx
     998: 89 8c 24 e0 00 00 00         	movl	%ecx, 0xe0(%rsp)
     99f: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
     9a4: 41 89 cc                     	movl	%ecx, %r12d
     9a7: 4d 01 f4                     	addq	%r14, %r12
     9aa: 49 8d 74 24 f0               	leaq	-0x10(%r12), %rsi
     9af: ba 10 00 00 00               	movl	$0x10, %edx
     9b4: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     9b9: e8 00 00 00 00               	callq	0x9be <trusted_x86_x86_sim_xdp+0x9be>
		00000000000009ba:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     9be: 85 c0                        	testl	%eax, %eax
     9c0: 79 14                        	jns	0x9d6 <trusted_x86_x86_sim_xdp+0x9d6>
     9c2: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
     9c7: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
     9cf: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
     9d6: 83 bc 24 e0 00 00 00 10      	cmpl	$0x10, 0xe0(%rsp)
     9de: 72 05                        	jb	0x9e5 <trusted_x86_x86_sim_xdp+0x9e5>
     9e0: 48 8b 6c 24 48               	movq	0x48(%rsp), %rbp
     9e5: 4c 8b 74 24 50               	movq	0x50(%rsp), %r14
     9ea: 8b 4c 24 30                  	movl	0x30(%rsp), %ecx
     9ee: 4c 89 f8                     	movq	%r15, %rax
     9f1: 8b 80 c0 02 00 00            	movl	0x2c0(%rax), %eax
     9f7: 83 f8 7f                     	cmpl	$0x7f, %eax
     9fa: 0f 82 7a 04 00 00            	jb	0xe7a <trusted_x86_x86_sim_xdp+0xe7a>
     a00: c7 44 24 48 02 00 00 00      	movl	$0x2, 0x48(%rsp)
     a08: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xa0f <trusted_x86_x86_sim_xdp+0xa0f>
		0000000000000a0b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     a0f: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     a14: e8 00 00 00 00               	callq	0xa19 <trusted_x86_x86_sim_xdp+0xa19>
		0000000000000a15:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     a19: 41 be 02 00 00 00            	movl	$0x2, %r14d
     a1f: 48 85 c0                     	testq	%rax, %rax
     a22: 0f 84 6d f7 ff ff            	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
     a28: 48 89 c1                     	movq	%rax, %rcx
     a2b: 48 8b 09                     	movq	(%rcx), %rcx
     a2e: 48 ff c1                     	incq	%rcx
     a31: e9 5c f7 ff ff               	jmp	0x192 <trusted_x86_x86_sim_xdp+0x192>
     a36: 48 89 74 24 28               	movq	%rsi, 0x28(%rsp)
     a3b: 48 83 c6 f8                  	addq	$-0x8, %rsi
     a3f: ba 30 00 00 00               	movl	$0x30, %edx
     a44: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     a49: e8 00 00 00 00               	callq	0xa4e <trusted_x86_x86_sim_xdp+0xa4e>
		0000000000000a4a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     a4e: 85 c0                        	testl	%eax, %eax
     a50: 79 34                        	jns	0xa86 <trusted_x86_x86_sim_xdp+0xa86>
     a52: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
     a57: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
     a5f: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
     a67: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
     a6f: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
     a77: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
     a7f: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
     a86: 49 be 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %r14 # imm = 0xFF00000000000000
     a90: 49 bc 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %r12 # imm = 0x200000000000000
     a9a: 4c 89 f8                     	movq	%r15, %rax
     a9d: 8b 00                        	movl	(%rax), %eax
     a9f: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     aa7: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     aad: 48 8d 6c 24 18               	leaq	0x18(%rsp), %rbp
     ab2: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
     ab7: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     abe: 48 89 ef                     	movq	%rbp, %rdi
     ac1: e8 00 00 00 00               	callq	0xac6 <trusted_x86_x86_sim_xdp+0xac6>
		0000000000000ac2:  R_X86_64_PLT32	.text+0x5c
     ac6: 48 85 c0                     	testq	%rax, %rax
     ac9: 74 16                        	je	0xae1 <trusted_x86_x86_sim_xdp+0xae1>
     acb: 48 8b 40 08                  	movq	0x8(%rax), %rax
     acf: 4c 21 f0                     	andq	%r14, %rax
     ad2: 4c 39 e0                     	cmpq	%r12, %rax
     ad5: 75 0a                        	jne	0xae1 <trusted_x86_x86_sim_xdp+0xae1>
     ad7: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     adc: e9 7f 01 00 00               	jmp	0xc60 <trusted_x86_x86_sim_xdp+0xc60>
     ae1: 4c 89 f8                     	movq	%r15, %rax
     ae4: 8b 00                        	movl	(%rax), %eax
     ae6: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     aee: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     af4: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
     af9: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     b00: 48 89 ef                     	movq	%rbp, %rdi
     b03: e8 00 00 00 00               	callq	0xb08 <trusted_x86_x86_sim_xdp+0xb08>
		0000000000000b04:  R_X86_64_PLT32	.text+0x5c
     b08: 48 85 c0                     	testq	%rax, %rax
     b0b: 74 1a                        	je	0xb27 <trusted_x86_x86_sim_xdp+0xb27>
     b0d: 48 8b 40 08                  	movq	0x8(%rax), %rax
     b11: 4c 21 f0                     	andq	%r14, %rax
     b14: 4c 39 e0                     	cmpq	%r12, %rax
     b17: 75 0e                        	jne	0xb27 <trusted_x86_x86_sim_xdp+0xb27>
     b19: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     b1e: 49 83 c4 08                  	addq	$0x8, %r12
     b22: e9 39 01 00 00               	jmp	0xc60 <trusted_x86_x86_sim_xdp+0xc60>
     b27: 4c 89 f8                     	movq	%r15, %rax
     b2a: 8b 00                        	movl	(%rax), %eax
     b2c: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     b34: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     b3a: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
     b3f: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     b46: 48 89 ef                     	movq	%rbp, %rdi
     b49: e8 00 00 00 00               	callq	0xb4e <trusted_x86_x86_sim_xdp+0xb4e>
		0000000000000b4a:  R_X86_64_PLT32	.text+0x5c
     b4e: 48 85 c0                     	testq	%rax, %rax
     b51: 74 1a                        	je	0xb6d <trusted_x86_x86_sim_xdp+0xb6d>
     b53: 48 8b 40 08                  	movq	0x8(%rax), %rax
     b57: 4c 21 f0                     	andq	%r14, %rax
     b5a: 4c 39 e0                     	cmpq	%r12, %rax
     b5d: 75 0e                        	jne	0xb6d <trusted_x86_x86_sim_xdp+0xb6d>
     b5f: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     b64: 49 83 c4 10                  	addq	$0x10, %r12
     b68: e9 f3 00 00 00               	jmp	0xc60 <trusted_x86_x86_sim_xdp+0xc60>
     b6d: 4c 89 f8                     	movq	%r15, %rax
     b70: 8b 00                        	movl	(%rax), %eax
     b72: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     b7a: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     b80: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
     b85: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     b8c: 48 89 ef                     	movq	%rbp, %rdi
     b8f: e8 00 00 00 00               	callq	0xb94 <trusted_x86_x86_sim_xdp+0xb94>
		0000000000000b90:  R_X86_64_PLT32	.text+0x5c
     b94: 48 85 c0                     	testq	%rax, %rax
     b97: 74 1a                        	je	0xbb3 <trusted_x86_x86_sim_xdp+0xbb3>
     b99: 48 8b 40 08                  	movq	0x8(%rax), %rax
     b9d: 4c 21 f0                     	andq	%r14, %rax
     ba0: 4c 39 e0                     	cmpq	%r12, %rax
     ba3: 75 0e                        	jne	0xbb3 <trusted_x86_x86_sim_xdp+0xbb3>
     ba5: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     baa: 49 83 c4 18                  	addq	$0x18, %r12
     bae: e9 ad 00 00 00               	jmp	0xc60 <trusted_x86_x86_sim_xdp+0xc60>
     bb3: 4c 89 f8                     	movq	%r15, %rax
     bb6: 8b 00                        	movl	(%rax), %eax
     bb8: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     bc0: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     bc6: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
     bcb: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     bd2: 48 89 ef                     	movq	%rbp, %rdi
     bd5: e8 00 00 00 00               	callq	0xbda <trusted_x86_x86_sim_xdp+0xbda>
		0000000000000bd6:  R_X86_64_PLT32	.text+0x5c
     bda: 48 85 c0                     	testq	%rax, %rax
     bdd: 74 3b                        	je	0xc1a <trusted_x86_x86_sim_xdp+0xc1a>
     bdf: 48 8b 40 08                  	movq	0x8(%rax), %rax
     be3: 4c 21 f0                     	andq	%r14, %rax
     be6: 4c 39 e0                     	cmpq	%r12, %rax
     be9: 75 2f                        	jne	0xc1a <trusted_x86_x86_sim_xdp+0xc1a>
     beb: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     bf0: 49 83 c4 20                  	addq	$0x20, %r12
     bf4: eb 6a                        	jmp	0xc60 <trusted_x86_x86_sim_xdp+0xc60>
     bf6: 0f b6 74 24 49               	movzbl	0x49(%rsp), %esi
     bfb: 81 fe c3 00 00 00            	cmpl	$0xc3, %esi
     c01: 75 6f                        	jne	0xc72 <trusted_x86_x86_sim_xdp+0xc72>
     c03: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
     c0b: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     c10: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
     c15: e9 07 fc ff ff               	jmp	0x821 <trusted_x86_x86_sim_xdp+0x821>
     c1a: 4c 89 f8                     	movq	%r15, %rax
     c1d: 8b 00                        	movl	(%rax), %eax
     c1f: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
     c27: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
     c2d: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
     c32: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
     c39: 48 89 ef                     	movq	%rbp, %rdi
     c3c: e8 00 00 00 00               	callq	0xc41 <trusted_x86_x86_sim_xdp+0xc41>
		0000000000000c3d:  R_X86_64_PLT32	.text+0x5c
     c41: 48 85 c0                     	testq	%rax, %rax
     c44: 0f 84 a3 00 00 00            	je	0xced <trusted_x86_x86_sim_xdp+0xced>
     c4a: 4c 23 70 08                  	andq	0x8(%rax), %r14
     c4e: 4d 39 e6                     	cmpq	%r12, %r14
     c51: 0f 85 96 00 00 00            	jne	0xced <trusted_x86_x86_sim_xdp+0xced>
     c57: 4c 8b 64 24 28               	movq	0x28(%rsp), %r12
     c5c: 49 83 c4 28                  	addq	$0x28, %r12
     c60: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
     c68: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     c6d: e9 38 fd ff ff               	jmp	0x9aa <trusted_x86_x86_sim_xdp+0x9aa>
     c72: 0f b6 54 24 4a               	movzbl	0x4a(%rsp), %edx
     c77: 0f b6 4c 24 4b               	movzbl	0x4b(%rsp), %ecx
     c7c: 0f b6 44 24 4c               	movzbl	0x4c(%rsp), %eax
     c81: 0f b6 7c 24 4f               	movzbl	0x4f(%rsp), %edi
     c86: 80 fa c3                     	cmpb	$-0x3d, %dl
     c89: 74 4b                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     c8b: 80 f9 c3                     	cmpb	$-0x3d, %cl
     c8e: 74 46                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     c90: 3c c3                        	cmpb	$-0x3d, %al
     c92: 74 42                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     c94: 80 7c 24 4d c3               	cmpb	$-0x3d, 0x4d(%rsp)
     c99: 74 3b                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     c9b: 80 7c 24 4e c3               	cmpb	$-0x3d, 0x4e(%rsp)
     ca0: 74 34                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     ca2: 40 80 ff c3                  	cmpb	$-0x3d, %dil
     ca6: 74 2e                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     ca8: 80 7c 24 50 c3               	cmpb	$-0x3d, 0x50(%rsp)
     cad: 74 27                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     caf: 80 7c 24 51 c3               	cmpb	$-0x3d, 0x51(%rsp)
     cb4: 74 20                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     cb6: 80 7c 24 52 c3               	cmpb	$-0x3d, 0x52(%rsp)
     cbb: 74 19                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     cbd: 80 7c 24 53 c3               	cmpb	$-0x3d, 0x53(%rsp)
     cc2: 74 12                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     cc4: 80 7c 24 54 c3               	cmpb	$-0x3d, 0x54(%rsp)
     cc9: 74 0b                        	je	0xcd6 <trusted_x86_x86_sim_xdp+0xcd6>
     ccb: 80 7c 24 55 c3               	cmpb	$-0x3d, 0x55(%rsp)
     cd0: 0f 85 81 fc ff ff            	jne	0x957 <trusted_x86_x86_sim_xdp+0x957>
     cd6: 83 fe 5d                     	cmpl	$0x5d, %esi
     cd9: 75 4d                        	jne	0xd28 <trusted_x86_x86_sim_xdp+0xd28>
     cdb: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
     ce3: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     ce8: e9 a1 fc ff ff               	jmp	0x98e <trusted_x86_x86_sim_xdp+0x98e>
     ced: c7 44 24 18 2e 00 00 00      	movl	$0x2e, 0x18(%rsp)
     cf5: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xcfc <trusted_x86_x86_sim_xdp+0xcfc>
		0000000000000cf8:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     cfc: 48 89 ee                     	movq	%rbp, %rsi
     cff: e8 00 00 00 00               	callq	0xd04 <trusted_x86_x86_sim_xdp+0xd04>
		0000000000000d00:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     d04: 48 85 c0                     	testq	%rax, %rax
     d07: 74 0c                        	je	0xd15 <trusted_x86_x86_sim_xdp+0xd15>
     d09: 48 89 c1                     	movq	%rax, %rcx
     d0c: 48 8b 09                     	movq	(%rcx), %rcx
     d0f: 48 ff c1                     	incq	%rcx
     d12: 48 89 08                     	movq	%rcx, (%rax)
     d15: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
     d1d: 41 be ea 03 00 00            	movl	$0x3ea, %r14d           # imm = 0x3EA
     d23: e9 6d f4 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
     d28: 83 fe 0f                     	cmpl	$0xf, %esi
     d2b: 0f 84 61 07 00 00            	je	0x1492 <trusted_x86_x86_sim_xdp+0x1492>
     d31: 83 fe 41                     	cmpl	$0x41, %esi
     d34: 0f 85 67 07 00 00            	jne	0x14a1 <trusted_x86_x86_sim_xdp+0x14a1>
     d3a: 80 fa 85                     	cmpb	$-0x7b, %dl
     d3d: 0f 85 5e 07 00 00            	jne	0x14a1 <trusted_x86_x86_sim_xdp+0x14a1>
     d43: 80 f9 02                     	cmpb	$0x2, %cl
     d46: 0f 85 55 07 00 00            	jne	0x14a1 <trusted_x86_x86_sim_xdp+0x14a1>
     d4c: 3c c3                        	cmpb	$-0x3d, %al
     d4e: 0f 84 af fe ff ff            	je	0xc03 <trusted_x86_x86_sim_xdp+0xc03>
     d54: e9 48 07 00 00               	jmp	0x14a1 <trusted_x86_x86_sim_xdp+0x14a1>
     d59: 4c 89 f8                     	movq	%r15, %rax
     d5c: 48 8b a8 00 0f 00 00         	movq	0xf00(%rax), %rbp
     d63: eb 05                        	jmp	0xd6a <trusted_x86_x86_sim_xdp+0xd6a>
     d65: 48 8b 6c 24 60               	movq	0x60(%rsp), %rbp
     d6a: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
     d72: 4c 8b a4 24 90 00 00 00      	movq	0x90(%rsp), %r12
     d7a: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
     d82: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
     d87: 4c 8b b4 24 a0 00 00 00      	movq	0xa0(%rsp), %r14
     d8f: 48 8b 0c 24                  	movq	(%rsp), %rcx
     d93: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
     d97: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
     d9c: 48 01 c6                     	addq	%rax, %rsi
     d9f: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
     da4: ba 08 00 00 00               	movl	$0x8, %edx
     da9: e8 00 00 00 00               	callq	0xdae <trusted_x86_x86_sim_xdp+0xdae>
		0000000000000daa:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     dae: 85 c0                        	testl	%eax, %eax
     db0: 79 09                        	jns	0xdbb <trusted_x86_x86_sim_xdp+0xdbb>
     db2: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
     dbb: 85 c0                        	testl	%eax, %eax
     dbd: 74 4c                        	je	0xe0b <trusted_x86_x86_sim_xdp+0xe0b>
     dbf: 48 8d b4 24 f4 00 00 00      	leaq	0xf4(%rsp), %rsi
     dc7: c7 84 24 f4 00 00 00 2d 00 00 00     	movl	$0x2d, 0xf4(%rsp)
     dd2: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xdd9 <trusted_x86_x86_sim_xdp+0xdd9>
		0000000000000dd5:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     dd9: e8 00 00 00 00               	callq	0xdde <trusted_x86_x86_sim_xdp+0xdde>
		0000000000000dda:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     dde: 48 85 c0                     	testq	%rax, %rax
     de1: 74 0c                        	je	0xdef <trusted_x86_x86_sim_xdp+0xdef>
     de3: 48 89 c1                     	movq	%rax, %rcx
     de6: 48 8b 09                     	movq	(%rcx), %rcx
     de9: 48 ff c1                     	incq	%rcx
     dec: 48 89 08                     	movq	%rcx, (%rax)
     def: 48 c7 44 24 30 49 6e 74 65   	movq	$0x65746e49, 0x30(%rsp) # imm = 0x65746E49
     df8: c7 44 24 28 02 6e 74 65      	movl	$0x65746e02, 0x28(%rsp) # imm = 0x65746E02
     e00: 41 be e9 03 00 00            	movl	$0x3e9, %r14d           # imm = 0x3E9
     e06: e9 8a f3 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
     e0b: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
     e10: 48 8b 0c 24                  	movq	(%rsp), %rcx
     e14: 0f b6 49 1d                  	movzbl	0x1d(%rcx), %ecx
     e18: 48 01 c1                     	addq	%rax, %rcx
     e1b: 31 d2                        	xorl	%edx, %edx
     e1d: 48 39 cd                     	cmpq	%rcx, %rbp
     e20: 48 0f 43 d1                  	cmovaeq	%rcx, %rdx
     e24: 48 29 d5                     	subq	%rdx, %rbp
     e27: 48 81 fd ff ff 00 00         	cmpq	$0xffff, %rbp           # imm = 0xFFFF
     e2e: b9 ff ff 00 00               	movl	$0xffff, %ecx           # imm = 0xFFFF
     e33: 48 0f 42 cd                  	cmovbq	%rbp, %rcx
     e37: 48 89 8c 24 b0 00 00 00      	movq	%rcx, 0xb0(%rsp)
     e3f: 48 c1 e8 03                  	shrq	$0x3, %rax
     e43: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
     e48: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
     e4e: 83 ca 02                     	orl	$0x2, %edx
     e51: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
     e55: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     e5a: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
     e5f: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
     e64: 8b 4c 24 30                  	movl	0x30(%rsp), %ecx
     e68: 4c 89 f8                     	movq	%r15, %rax
     e6b: 8b 80 c0 02 00 00            	movl	0x2c0(%rax), %eax
     e71: 83 f8 7e                     	cmpl	$0x7e, %eax
     e74: 0f 87 86 fb ff ff            	ja	0xa00 <trusted_x86_x86_sim_xdp+0xa00>
     e7a: 4c 89 fa                     	movq	%r15, %rdx
     e7d: 0f b6 92 30 0f 00 00         	movzbl	0xf30(%rdx), %edx
     e84: 8b 74 24 28                  	movl	0x28(%rsp), %esi
     e88: 48 c1 e6 3c                  	shlq	$0x3c, %rsi
     e8c: 48 8b bc 24 b0 00 00 00      	movq	0xb0(%rsp), %rdi
     e94: 48 c1 e7 20                  	shlq	$0x20, %rdi
     e98: 48 09 cf                     	orq	%rcx, %rdi
     e9b: 8d 48 01                     	leal	0x1(%rax), %ecx
     e9e: 4d 8d 87 c0 02 00 00         	leaq	0x2c0(%r15), %r8
     ea5: 4c 89 84 24 70 01 00 00      	movq	%r8, 0x170(%rsp)
     ead: 41 89 08                     	movl	%ecx, (%r8)
     eb0: 48 09 f7                     	orq	%rsi, %rdi
     eb3: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
     eb8: c1 e0 03                     	shll	$0x3, %eax
     ebb: 8d 04 40                     	leal	(%rax,%rax,2), %eax
     ebe: 49 8d 34 07                  	leaq	(%r15,%rax), %rsi
     ec2: 48 81 c6 d0 02 00 00         	addq	$0x2d0, %rsi            # imm = 0x2D0
     ec9: 48 89 0e                     	movq	%rcx, (%rsi)
     ecc: 49 8d 8c 07 d8 02 00 00      	leaq	0x2d8(%r15,%rax), %rcx
     ed4: 48 89 39                     	movq	%rdi, (%rcx)
     ed7: 49 8d 8c 07 e0 02 00 00      	leaq	0x2e0(%r15,%rax), %rcx
     edf: c6 01 05                     	movb	$0x5, (%rcx)
     ee2: 49 8d 8c 07 e1 02 00 00      	leaq	0x2e1(%r15,%rax), %rcx
     eea: 88 11                        	movb	%dl, (%rcx)
     eec: 49 8d 8c 07 e2 02 00 00      	leaq	0x2e2(%r15,%rax), %rcx
     ef4: c7 01 00 00 00 00            	movl	$0x0, (%rcx)
     efa: 49 8d 84 07 e6 02 00 00      	leaq	0x2e6(%r15,%rax), %rax
     f02: 66 c7 00 00 00               	movw	$0x0, (%rax)
     f07: 49 8d 87 d0 0e 00 00         	leaq	0xed0(%r15), %rax
     f0e: 48 89 84 24 80 01 00 00      	movq	%rax, 0x180(%rsp)
     f16: 4c 89 30                     	movq	%r14, (%rax)
     f19: 4d 8d b7 d8 0e 00 00         	leaq	0xed8(%r15), %r14
     f20: 4c 89 f0                     	movq	%r14, %rax
     f23: 4c 89 20                     	movq	%r12, (%rax)
     f26: 49 8d 87 e0 0e 00 00         	leaq	0xee0(%r15), %rax
     f2d: 48 89 84 24 78 01 00 00      	movq	%rax, 0x178(%rsp)
     f35: 48 89 28                     	movq	%rbp, (%rax)
     f38: 49 8d af 30 0f 00 00         	leaq	0xf30(%r15), %rbp
     f3f: 48 89 e8                     	movq	%rbp, %rax
     f42: c6 00 01                     	movb	$0x1, (%rax)
     f45: c7 44 24 48 2a 00 00 00      	movl	$0x2a, 0x48(%rsp)
     f4d: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xf54 <trusted_x86_x86_sim_xdp+0xf54>
		0000000000000f50:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     f54: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
     f59: e8 00 00 00 00               	callq	0xf5e <trusted_x86_x86_sim_xdp+0xf5e>
		0000000000000f5a:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     f5e: 48 85 c0                     	testq	%rax, %rax
     f61: 74 0c                        	je	0xf6f <trusted_x86_x86_sim_xdp+0xf6f>
     f63: 48 89 c1                     	movq	%rax, %rcx
     f66: 48 8b 09                     	movq	(%rcx), %rcx
     f69: 48 ff c1                     	incq	%rcx
     f6c: 48 89 08                     	movq	%rcx, (%rax)
     f6f: 4c 89 f8                     	movq	%r15, %rax
     f72: 4c 8b a0 d0 0e 00 00         	movq	0xed0(%rax), %r12
     f79: 4d 85 e4                     	testq	%r12, %r12
     f7c: 0f 84 04 2b 00 00            	je	0x3a86 <trusted_x86_x86_sim_xdp+0x3a86>
     f82: 48 89 ac 24 60 01 00 00      	movq	%rbp, 0x160(%rsp)
     f8a: 4c 89 b4 24 68 01 00 00      	movq	%r14, 0x168(%rsp)
     f92: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
     f9c: 49 39 c4                     	cmpq	%rax, %r12
     f9f: 76 18                        	jbe	0xfb9 <trusted_x86_x86_sim_xdp+0xfb9>
     fa1: 49 8d 87 28 0f 00 00         	leaq	0xf28(%r15), %rax
     fa8: c7 00 0b 00 00 00            	movl	$0xb, (%rax)
     fae: 41 be ab 0f 00 00            	movl	$0xfab, %r14d           # imm = 0xFAB
     fb4: e9 dc f1 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
     fb9: 49 81 fc ff 0f 00 00         	cmpq	$0xfff, %r12            # imm = 0xFFF
     fc0: 77 18                        	ja	0xfda <trusted_x86_x86_sim_xdp+0xfda>
     fc2: 49 8d 87 28 0f 00 00         	leaq	0xf28(%r15), %rax
     fc9: c7 00 31 00 00 00            	movl	$0x31, (%rax)
     fcf: 41 be ae 0f 00 00            	movl	$0xfae, %r14d           # imm = 0xFAE
     fd5: e9 bb f1 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
     fda: 4c 89 f8                     	movq	%r15, %rax
     fdd: 8b 00                        	movl	(%rax), %eax
     fdf: c7 44 24 48 60 00 00 00      	movl	$0x60, 0x48(%rsp)
     fe7: 0f 38 f1 44 24 4c            	movbel	%eax, 0x4c(%rsp)
     fed: 4c 0f 38 f1 64 24 50         	movbeq	%r12, 0x50(%rsp)
     ff4: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
     ff9: e8 00 00 00 00               	callq	0xffe <trusted_x86_x86_sim_xdp+0xffe>
		0000000000000ffa:  R_X86_64_PLT32	.text+0x5c
     ffe: 48 85 c0                     	testq	%rax, %rax
    1001: 0f 84 97 2a 00 00            	je	0x3a9e <trusted_x86_x86_sim_xdp+0x3a9e>
    1007: 48 89 c1                     	movq	%rax, %rcx
    100a: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    100e: 48 89 e9                     	movq	%rbp, %rcx
    1011: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    101b: 48 21 d1                     	andq	%rdx, %rcx
    101e: 49 8d 97 20 0f 00 00         	leaq	0xf20(%r15), %rdx
    1025: 48 89 94 24 58 01 00 00      	movq	%rdx, 0x158(%rsp)
    102d: 48 89 0a                     	movq	%rcx, (%rdx)
    1030: 48 c1 ed 38                  	shrq	$0x38, %rbp
    1034: 48 8b 00                     	movq	(%rax), %rax
    1037: 49 8d 97 10 0f 00 00         	leaq	0xf10(%r15), %rdx
    103e: 48 89 94 24 50 01 00 00      	movq	%rdx, 0x150(%rsp)
    1046: 48 89 02                     	movq	%rax, (%rdx)
    1049: 49 29 cc                     	subq	%rcx, %r12
    104c: 49 8d 8f 18 0f 00 00         	leaq	0xf18(%r15), %rcx
    1053: 48 89 8c 24 48 01 00 00      	movq	%rcx, 0x148(%rsp)
    105b: 4c 89 21                     	movq	%r12, (%rcx)
    105e: 48 83 fd 01                  	cmpq	$0x1, %rbp
    1062: 0f 85 e9 00 00 00            	jne	0x1151 <trusted_x86_x86_sim_xdp+0x1151>
    1068: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    106d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1074 <trusted_x86_x86_sim_xdp+0x1074>
		0000000000001070:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1074: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1079: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1080 <trusted_x86_x86_sim_xdp+0x1080>
		000000000000107c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1080: 75 07                        	jne	0x1089 <trusted_x86_x86_sim_xdp+0x1089>
    1082: e8 00 00 00 00               	callq	0x1087 <trusted_x86_x86_sim_xdp+0x1087>
		0000000000001083:  R_X86_64_PLT32	.text+0x5c
    1087: eb 05                        	jmp	0x108e <trusted_x86_x86_sim_xdp+0x108e>
    1089: e8 00 00 00 00               	callq	0x108e <trusted_x86_x86_sim_xdp+0x108e>
		000000000000108a:  R_X86_64_PLT32	.text+0x10c
    108e: 48 89 84 24 40 01 00 00      	movq	%rax, 0x140(%rsp)
    1096: 45 31 f6                     	xorl	%r14d, %r14d
    1099: bd 01 00 00 00               	movl	$0x1, %ebp
    109e: 48 83 bc 24 40 01 00 00 00   	cmpq	$0x0, 0x140(%rsp)
    10a7: 0f 84 ea f0 ff ff            	je	0x197 <trusted_x86_x86_sim_xdp+0x197>
    10ad: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
    10b5: 48 8b 00                     	movq	(%rax), %rax
    10b8: 4c 39 e0                     	cmpq	%r12, %rax
    10bb: 77 11                        	ja	0x10ce <trusted_x86_x86_sim_xdp+0x10ce>
    10bd: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
    10c5: 48 8b 40 08                  	movq	0x8(%rax), %rax
    10c9: 4c 39 e0                     	cmpq	%r12, %rax
    10cc: 73 2a                        	jae	0x10f8 <trusted_x86_x86_sim_xdp+0x10f8>
    10ce: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
    10d6: 48 8b 40 10                  	movq	0x10(%rax), %rax
    10da: 4c 39 e0                     	cmpq	%r12, %rax
    10dd: 0f 87 b4 f0 ff ff            	ja	0x197 <trusted_x86_x86_sim_xdp+0x197>
    10e3: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
    10eb: 48 8b 40 18                  	movq	0x18(%rax), %rax
    10ef: 4c 39 e0                     	cmpq	%r12, %rax
    10f2: 0f 82 9f f0 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    10f8: 4c 89 f8                     	movq	%r15, %rax
    10fb: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    1101: 48 8b 8c 24 40 01 00 00      	movq	0x140(%rsp), %rcx
    1109: 8b 49 20                     	movl	0x20(%rcx), %ecx
    110c: 0f a3 c8                     	btl	%ecx, %eax
    110f: 0f 82 82 f0 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1115: 48 8d b4 24 b8 00 00 00      	leaq	0xb8(%rsp), %rsi
    111d: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
    1128: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x112f <trusted_x86_x86_sim_xdp+0x112f>
		000000000000112b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    112f: e8 00 00 00 00               	callq	0x1134 <trusted_x86_x86_sim_xdp+0x1134>
		0000000000001130:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1134: 48 85 c0                     	testq	%rax, %rax
    1137: 74 0c                        	je	0x1145 <trusted_x86_x86_sim_xdp+0x1145>
    1139: 48 89 c1                     	movq	%rax, %rcx
    113c: 48 8b 09                     	movq	(%rcx), %rcx
    113f: 48 ff c1                     	incq	%rcx
    1142: 48 89 08                     	movq	%rcx, (%rax)
    1145: 48 8b 84 24 40 01 00 00      	movq	0x140(%rsp), %rax
    114d: 0f b7 68 20                  	movzwl	0x20(%rax), %ebp
    1151: 45 31 f6                     	xorl	%r14d, %r14d
    1154: 83 fd 02                     	cmpl	$0x2, %ebp
    1157: 0f 85 3a f0 ff ff            	jne	0x197 <trusted_x86_x86_sim_xdp+0x197>
    115d: c7 44 24 48 29 00 00 00      	movl	$0x29, 0x48(%rsp)
    1165: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x116c <trusted_x86_x86_sim_xdp+0x116c>
		0000000000001168:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    116c: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    1171: e8 00 00 00 00               	callq	0x1176 <trusted_x86_x86_sim_xdp+0x1176>
		0000000000001172:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1176: 48 85 c0                     	testq	%rax, %rax
    1179: 74 0c                        	je	0x1187 <trusted_x86_x86_sim_xdp+0x1187>
    117b: 48 89 c1                     	movq	%rax, %rcx
    117e: 48 8b 09                     	movq	(%rcx), %rcx
    1181: 48 ff c1                     	incq	%rcx
    1184: 48 89 08                     	movq	%rcx, (%rax)
    1187: 4c 89 f8                     	movq	%r15, %rax
    118a: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    1191: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    1196: 4c 89 f8                     	movq	%r15, %rax
    1199: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    11a0: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    11a5: 48 8b 04 24                  	movq	(%rsp), %rax
    11a9: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    11ad: 4c 89 f9                     	movq	%r15, %rcx
    11b0: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    11b7: 48 89 4c 24 38               	movq	%rcx, 0x38(%rsp)
    11bc: 4c 89 f9                     	movq	%r15, %rcx
    11bf: c4 62 fb f7 b1 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r14
    11c8: 4c 89 f8                     	movq	%r15, %rax
    11cb: 48 8b a8 10 0f 00 00         	movq	0xf10(%rax), %rbp
    11d2: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    11dc: 48 21 c5                     	andq	%rax, %rbp
    11df: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    11e3: ba 01 00 00 00               	movl	$0x1, %edx
    11e8: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    11ed: e8 00 00 00 00               	callq	0x11f2 <trusted_x86_x86_sim_xdp+0x11f2>
		00000000000011ee:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    11f2: 85 c0                        	testl	%eax, %eax
    11f4: 79 05                        	jns	0x11fb <trusted_x86_x86_sim_xdp+0x11fb>
    11f6: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    11fb: 85 c0                        	testl	%eax, %eax
    11fd: 0f 85 56 ef ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1203: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1208: 8d 48 01                     	leal	0x1(%rax), %ecx
    120b: f6 c1 fe                     	testb	$-0x2, %cl
    120e: 0f 84 ac 02 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1214: 89 c0                        	movl	%eax, %eax
    1216: 49 29 c6                     	subq	%rax, %r14
    1219: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    121d: ba 01 00 00 00               	movl	$0x1, %edx
    1222: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1227: e8 00 00 00 00               	callq	0x122c <trusted_x86_x86_sim_xdp+0x122c>
		0000000000001228:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    122c: 85 c0                        	testl	%eax, %eax
    122e: 79 05                        	jns	0x1235 <trusted_x86_x86_sim_xdp+0x1235>
    1230: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1235: 85 c0                        	testl	%eax, %eax
    1237: 0f 85 1c ef ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    123d: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1242: 8d 48 01                     	leal	0x1(%rax), %ecx
    1245: f6 c1 fe                     	testb	$-0x2, %cl
    1248: 0f 84 72 02 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    124e: 89 c0                        	movl	%eax, %eax
    1250: 49 29 c6                     	subq	%rax, %r14
    1253: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1257: ba 01 00 00 00               	movl	$0x1, %edx
    125c: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1261: e8 00 00 00 00               	callq	0x1266 <trusted_x86_x86_sim_xdp+0x1266>
		0000000000001262:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1266: 85 c0                        	testl	%eax, %eax
    1268: 79 05                        	jns	0x126f <trusted_x86_x86_sim_xdp+0x126f>
    126a: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    126f: 85 c0                        	testl	%eax, %eax
    1271: 0f 85 e2 ee ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1277: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    127c: 8d 48 01                     	leal	0x1(%rax), %ecx
    127f: f6 c1 fe                     	testb	$-0x2, %cl
    1282: 0f 84 38 02 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1288: 89 c0                        	movl	%eax, %eax
    128a: 49 29 c6                     	subq	%rax, %r14
    128d: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1291: ba 01 00 00 00               	movl	$0x1, %edx
    1296: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    129b: e8 00 00 00 00               	callq	0x12a0 <trusted_x86_x86_sim_xdp+0x12a0>
		000000000000129c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    12a0: 85 c0                        	testl	%eax, %eax
    12a2: 79 05                        	jns	0x12a9 <trusted_x86_x86_sim_xdp+0x12a9>
    12a4: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    12a9: 85 c0                        	testl	%eax, %eax
    12ab: 0f 85 a8 ee ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    12b1: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    12b6: 8d 48 01                     	leal	0x1(%rax), %ecx
    12b9: f6 c1 fe                     	testb	$-0x2, %cl
    12bc: 0f 84 fe 01 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    12c2: 89 c0                        	movl	%eax, %eax
    12c4: 49 29 c6                     	subq	%rax, %r14
    12c7: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    12cb: ba 01 00 00 00               	movl	$0x1, %edx
    12d0: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    12d5: e8 00 00 00 00               	callq	0x12da <trusted_x86_x86_sim_xdp+0x12da>
		00000000000012d6:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    12da: 85 c0                        	testl	%eax, %eax
    12dc: 79 05                        	jns	0x12e3 <trusted_x86_x86_sim_xdp+0x12e3>
    12de: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    12e3: 85 c0                        	testl	%eax, %eax
    12e5: 0f 85 6e ee ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    12eb: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    12f0: 8d 48 01                     	leal	0x1(%rax), %ecx
    12f3: f6 c1 fe                     	testb	$-0x2, %cl
    12f6: 0f 84 c4 01 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    12fc: 89 c0                        	movl	%eax, %eax
    12fe: 49 29 c6                     	subq	%rax, %r14
    1301: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1305: ba 01 00 00 00               	movl	$0x1, %edx
    130a: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    130f: e8 00 00 00 00               	callq	0x1314 <trusted_x86_x86_sim_xdp+0x1314>
		0000000000001310:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1314: 85 c0                        	testl	%eax, %eax
    1316: 79 05                        	jns	0x131d <trusted_x86_x86_sim_xdp+0x131d>
    1318: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    131d: 85 c0                        	testl	%eax, %eax
    131f: 0f 85 34 ee ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1325: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    132a: 8d 48 01                     	leal	0x1(%rax), %ecx
    132d: f6 c1 fe                     	testb	$-0x2, %cl
    1330: 0f 84 8a 01 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1336: 89 c0                        	movl	%eax, %eax
    1338: 49 29 c6                     	subq	%rax, %r14
    133b: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    133f: ba 01 00 00 00               	movl	$0x1, %edx
    1344: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1349: e8 00 00 00 00               	callq	0x134e <trusted_x86_x86_sim_xdp+0x134e>
		000000000000134a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    134e: 85 c0                        	testl	%eax, %eax
    1350: 79 05                        	jns	0x1357 <trusted_x86_x86_sim_xdp+0x1357>
    1352: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1357: 85 c0                        	testl	%eax, %eax
    1359: 0f 85 fa ed ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    135f: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1364: 8d 48 01                     	leal	0x1(%rax), %ecx
    1367: f6 c1 fe                     	testb	$-0x2, %cl
    136a: 0f 84 50 01 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1370: 89 c0                        	movl	%eax, %eax
    1372: 49 29 c6                     	subq	%rax, %r14
    1375: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1379: ba 01 00 00 00               	movl	$0x1, %edx
    137e: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1383: e8 00 00 00 00               	callq	0x1388 <trusted_x86_x86_sim_xdp+0x1388>
		0000000000001384:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1388: 85 c0                        	testl	%eax, %eax
    138a: 79 05                        	jns	0x1391 <trusted_x86_x86_sim_xdp+0x1391>
    138c: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1391: 85 c0                        	testl	%eax, %eax
    1393: 0f 85 c0 ed ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1399: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    139e: 8d 48 01                     	leal	0x1(%rax), %ecx
    13a1: f6 c1 fe                     	testb	$-0x2, %cl
    13a4: 0f 84 16 01 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    13aa: 89 c0                        	movl	%eax, %eax
    13ac: 49 29 c6                     	subq	%rax, %r14
    13af: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    13b3: ba 01 00 00 00               	movl	$0x1, %edx
    13b8: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    13bd: e8 00 00 00 00               	callq	0x13c2 <trusted_x86_x86_sim_xdp+0x13c2>
		00000000000013be:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    13c2: 85 c0                        	testl	%eax, %eax
    13c4: 79 05                        	jns	0x13cb <trusted_x86_x86_sim_xdp+0x13cb>
    13c6: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    13cb: 85 c0                        	testl	%eax, %eax
    13cd: 0f 85 86 ed ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    13d3: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    13d8: 8d 48 01                     	leal	0x1(%rax), %ecx
    13db: f6 c1 fe                     	testb	$-0x2, %cl
    13de: 0f 84 dc 00 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    13e4: 89 c0                        	movl	%eax, %eax
    13e6: 49 29 c6                     	subq	%rax, %r14
    13e9: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    13ed: ba 01 00 00 00               	movl	$0x1, %edx
    13f2: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    13f7: e8 00 00 00 00               	callq	0x13fc <trusted_x86_x86_sim_xdp+0x13fc>
		00000000000013f8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    13fc: 85 c0                        	testl	%eax, %eax
    13fe: 79 05                        	jns	0x1405 <trusted_x86_x86_sim_xdp+0x1405>
    1400: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1405: 85 c0                        	testl	%eax, %eax
    1407: 0f 85 4c ed ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    140d: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1412: 8d 48 01                     	leal	0x1(%rax), %ecx
    1415: f6 c1 fe                     	testb	$-0x2, %cl
    1418: 0f 84 a2 00 00 00            	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    141e: 89 c0                        	movl	%eax, %eax
    1420: 49 29 c6                     	subq	%rax, %r14
    1423: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1427: ba 01 00 00 00               	movl	$0x1, %edx
    142c: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1431: e8 00 00 00 00               	callq	0x1436 <trusted_x86_x86_sim_xdp+0x1436>
		0000000000001432:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1436: 85 c0                        	testl	%eax, %eax
    1438: 79 05                        	jns	0x143f <trusted_x86_x86_sim_xdp+0x143f>
    143a: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    143f: 85 c0                        	testl	%eax, %eax
    1441: 0f 85 12 ed ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1447: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    144c: 8d 48 01                     	leal	0x1(%rax), %ecx
    144f: f6 c1 fe                     	testb	$-0x2, %cl
    1452: 74 6c                        	je	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1454: 89 c0                        	movl	%eax, %eax
    1456: 49 29 c6                     	subq	%rax, %r14
    1459: 4c 01 f5                     	addq	%r14, %rbp
    145c: ba 01 00 00 00               	movl	$0x1, %edx
    1461: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1466: 48 89 ee                     	movq	%rbp, %rsi
    1469: e8 00 00 00 00               	callq	0x146e <trusted_x86_x86_sim_xdp+0x146e>
		000000000000146a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    146e: 85 c0                        	testl	%eax, %eax
    1470: 79 05                        	jns	0x1477 <trusted_x86_x86_sim_xdp+0x1477>
    1472: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1477: 85 c0                        	testl	%eax, %eax
    1479: 0f 85 da ec ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    147f: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1484: 8d 48 01                     	leal	0x1(%rax), %ecx
    1487: f6 c1 fe                     	testb	$-0x2, %cl
    148a: 0f 85 c9 ec ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1490: eb 2e                        	jmp	0x14c0 <trusted_x86_x86_sim_xdp+0x14c0>
    1492: 80 fa 85                     	cmpb	$-0x7b, %dl
    1495: 75 0a                        	jne	0x14a1 <trusted_x86_x86_sim_xdp+0x14a1>
    1497: 40 80 ff c3                  	cmpb	$-0x3d, %dil
    149b: 0f 84 62 f7 ff ff            	je	0xc03 <trusted_x86_x86_sim_xdp+0xc03>
    14a1: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    14a6: 3c 5d                        	cmpb	$0x5d, %al
    14a8: 0f 84 55 f7 ff ff            	je	0xc03 <trusted_x86_x86_sim_xdp+0xc03>
    14ae: 3c c9                        	cmpb	$-0x37, %al
    14b0: 0f 84 4d f7 ff ff            	je	0xc03 <trusted_x86_x86_sim_xdp+0xc03>
    14b6: b9 01 00 00 00               	movl	$0x1, %ecx
    14bb: e9 99 f4 ff ff               	jmp	0x959 <trusted_x86_x86_sim_xdp+0x959>
    14c0: 85 c0                        	testl	%eax, %eax
    14c2: 0f 85 91 ec ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    14c8: 48 8b 14 24                  	movq	(%rsp), %rdx
    14cc: 48 89 d0                     	movq	%rdx, %rax
    14cf: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    14d3: c4 c2 f9 f7 c6               	shlxq	%rax, %r14, %rax
    14d8: 4c 89 f9                     	movq	%r15, %rcx
    14db: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    14e2: 48 89 d1                     	movq	%rdx, %rcx
    14e5: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    14e9: 48 01 c6                     	addq	%rax, %rsi
    14ec: 48 89 b4 24 b8 00 00 00      	movq	%rsi, 0xb8(%rsp)
    14f4: 0f 84 6b ec ff ff            	je	0x165 <trusted_x86_x86_sim_xdp+0x165>
    14fa: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    14ff: 4c 89 ef                     	movq	%r13, %rdi
    1502: e8 00 00 00 00               	callq	0x1507 <trusted_x86_x86_sim_xdp+0x1507>
		0000000000001503:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1507: 48 89 c5                     	movq	%rax, %rbp
    150a: 85 ed                        	testl	%ebp, %ebp
    150c: 79 0f                        	jns	0x151d <trusted_x86_x86_sim_xdp+0x151d>
    150e: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    1513: 4c 89 ef                     	movq	%r13, %rdi
    1516: 31 f6                        	xorl	%esi, %esi
    1518: e8 00 00 00 00               	callq	0x151d <trusted_x86_x86_sim_xdp+0x151d>
		0000000000001519:  R_X86_64_PLT32	memset-0x4
    151d: 85 ed                        	testl	%ebp, %ebp
    151f: 48 8b 04 24                  	movq	(%rsp), %rax
    1523: 0f 85 71 f0 ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    1529: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    152d: 0f b7 c0                     	movzwl	%ax, %eax
    1530: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    1535: 0f 87 4c 1d 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    153b: 48 8b 0c 24                  	movq	(%rsp), %rcx
    153f: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    1543: 0f b7 c9                     	movzwl	%cx, %ecx
    1546: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    154c: 0f 87 35 1d 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    1552: 48 8b 14 24                  	movq	(%rsp), %rdx
    1556: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    155a: 0f b7 d2                     	movzwl	%dx, %edx
    155d: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    1563: 0f 87 1e 1d 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    1569: 48 8b 3c 24                  	movq	(%rsp), %rdi
    156d: 48 89 fe                     	movq	%rdi, %rsi
    1570: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    1574: 40 0f b6 f6                  	movzbl	%sil, %esi
    1578: 4c 01 ee                     	addq	%r13, %rsi
    157b: 48 8b 36                     	movq	(%rsi), %rsi
    157e: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
    1586: 48 89 fe                     	movq	%rdi, %rsi
    1589: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    158d: 40 0f b6 f6                  	movzbl	%sil, %esi
    1591: 4c 01 ee                     	addq	%r13, %rsi
    1594: 48 8b 36                     	movq	(%rsi), %rsi
    1597: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    159f: 48 89 fe                     	movq	%rdi, %rsi
    15a2: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    15a6: 40 0f b6 f6                  	movzbl	%sil, %esi
    15aa: 4c 01 ee                     	addq	%r13, %rsi
    15ad: 8b 36                        	movl	(%rsi), %esi
    15af: c1 e6 03                     	shll	$0x3, %esi
    15b2: 89 b4 24 e0 00 00 00         	movl	%esi, 0xe0(%rsp)
    15b9: 48 89 fe                     	movq	%rdi, %rsi
    15bc: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    15c0: 40 0f b6 f6                  	movzbl	%sil, %esi
    15c4: 4c 01 ee                     	addq	%r13, %rsi
    15c7: 0f b7 36                     	movzwl	(%rsi), %esi
    15ca: 66 89 b4 24 e8 00 00 00      	movw	%si, 0xe8(%rsp)
    15d2: 4c 01 e9                     	addq	%r13, %rcx
    15d5: 8b 09                        	movl	(%rcx), %ecx
    15d7: 89 8c 24 e4 00 00 00         	movl	%ecx, 0xe4(%rsp)
    15de: 4c 01 ea                     	addq	%r13, %rdx
    15e1: 8b 0a                        	movl	(%rdx), %ecx
    15e3: 89 8c 24 dc 00 00 00         	movl	%ecx, 0xdc(%rsp)
    15ea: 4c 01 e8                     	addq	%r13, %rax
    15ed: 48 8b 00                     	movq	(%rax), %rax
    15f0: 48 89 84 24 d0 00 00 00      	movq	%rax, 0xd0(%rsp)
    15f8: 48 89 f8                     	movq	%rdi, %rax
    15fb: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    15ff: 0f b6 c0                     	movzbl	%al, %eax
    1602: 4c 01 e8                     	addq	%r13, %rax
    1605: 48 8b 30                     	movq	(%rax), %rsi
    1608: ba 04 00 00 00               	movl	$0x4, %edx
    160d: 48 8d bc 24 d8 00 00 00      	leaq	0xd8(%rsp), %rdi
    1615: e8 00 00 00 00               	callq	0x161a <trusted_x86_x86_sim_xdp+0x161a>
		0000000000001616:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    161a: 85 c0                        	testl	%eax, %eax
    161c: 79 0b                        	jns	0x1629 <trusted_x86_x86_sim_xdp+0x1629>
    161e: c7 84 24 d8 00 00 00 00 00 00 00     	movl	$0x0, 0xd8(%rsp)
    1629: 85 c0                        	testl	%eax, %eax
    162b: 48 8b 04 24                  	movq	(%rsp), %rax
    162f: 0f 85 65 ef ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    1635: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    1639: 4c 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %r14
    1641: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    1649: 84 c0                        	testb	%al, %al
    164b: 74 1f                        	je	0x166c <trusted_x86_x86_sim_xdp+0x166c>
    164d: 89 c9                        	movl	%ecx, %ecx
    164f: 4c 01 f1                     	addq	%r14, %rcx
    1652: 48 89 8c 24 c0 00 00 00      	movq	%rcx, 0xc0(%rsp)
    165a: 8b 94 24 c8 00 00 00         	movl	0xc8(%rsp), %edx
    1661: 4c 01 f2                     	addq	%r14, %rdx
    1664: 48 89 94 24 c8 00 00 00      	movq	%rdx, 0xc8(%rsp)
    166c: 44 8b a4 24 d8 00 00 00      	movl	0xd8(%rsp), %r12d
    1674: 48 8b 54 24 30               	movq	0x30(%rsp), %rdx
    1679: 89 d6                        	movl	%edx, %esi
    167b: 29 ce                        	subl	%ecx, %esi
    167d: 48 89 b4 24 b0 00 00 00      	movq	%rsi, 0xb0(%rsp)
    1685: 41 81 fc 6d 61 74 69         	cmpl	$0x6974616d, %r12d      # imm = 0x6974616D
    168c: 7f 1a                        	jg	0x16a8 <trusted_x86_x86_sim_xdp+0x16a8>
    168e: 41 81 fc 76 74 61 62         	cmpl	$0x62617476, %r12d      # imm = 0x62617476
    1695: 0f 85 e8 00 00 00            	jne	0x1783 <trusted_x86_x86_sim_xdp+0x1783>
    169b: c7 44 24 28 01 00 00 00      	movl	$0x1, 0x28(%rsp)
    16a3: e9 c6 00 00 00               	jmp	0x176e <trusted_x86_x86_sim_xdp+0x176e>
    16a8: 41 81 fc 6e 61 74 69         	cmpl	$0x6974616e, %r12d      # imm = 0x6974616E
    16af: 74 12                        	je	0x16c3 <trusted_x86_x86_sim_xdp+0x16c3>
    16b1: 41 81 fc 6e 6d 65 74         	cmpl	$0x74656d6e, %r12d      # imm = 0x74656D6E
    16b8: 0f 85 a7 01 00 00            	jne	0x1865 <trusted_x86_x86_sim_xdp+0x1865>
    16be: 48 8b 54 24 30               	movq	0x30(%rsp), %rdx
    16c3: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
    16cb: 89 f7                        	movl	%esi, %edi
    16cd: 4c 01 f7                     	addq	%r14, %rdi
    16d0: 84 c0                        	testb	%al, %al
    16d2: 44 8b a4 24 e4 00 00 00      	movl	0xe4(%rsp), %r12d
    16da: 48 0f 44 fe                  	cmoveq	%rsi, %rdi
    16de: 48 39 fa                     	cmpq	%rdi, %rdx
    16e1: 75 59                        	jne	0x173c <trusted_x86_x86_sim_xdp+0x173c>
    16e3: 8b b4 24 dc 00 00 00         	movl	0xdc(%rsp), %esi
    16ea: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    16ef: ba 08 00 00 00               	movl	$0x8, %edx
    16f4: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    16f9: e8 00 00 00 00               	callq	0x16fe <trusted_x86_x86_sim_xdp+0x16fe>
		00000000000016fa:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    16fe: 85 c0                        	testl	%eax, %eax
    1700: 79 09                        	jns	0x170b <trusted_x86_x86_sim_xdp+0x170b>
    1702: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
    170b: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    1713: 85 c0                        	testl	%eax, %eax
    1715: 75 25                        	jne	0x173c <trusted_x86_x86_sim_xdp+0x173c>
    1717: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    171c: 48 39 c8                     	cmpq	%rcx, %rax
    171f: 72 1b                        	jb	0x173c <trusted_x86_x86_sim_xdp+0x173c>
    1721: 48 3b 84 24 c8 00 00 00      	cmpq	0xc8(%rsp), %rax
    1729: 73 11                        	jae	0x173c <trusted_x86_x86_sim_xdp+0x173c>
    172b: 89 c2                        	movl	%eax, %edx
    172d: 29 ca                        	subl	%ecx, %edx
    172f: 48 89 94 24 b0 00 00 00      	movq	%rdx, 0xb0(%rsp)
    1737: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    173c: 0f b7 84 24 e8 00 00 00      	movzwl	0xe8(%rsp), %eax
    1744: 48 01 c8                     	addq	%rcx, %rax
    1747: 48 39 44 24 30               	cmpq	%rax, 0x30(%rsp)
    174c: 0f 83 2d 01 00 00            	jae	0x187f <trusted_x86_x86_sim_xdp+0x187f>
    1752: 48 83 c0 fc                  	addq	$-0x4, %rax
    1756: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    175c: 83 c9 03                     	orl	$0x3, %ecx
    175f: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    1763: 48 39 44 24 30               	cmpq	%rax, 0x30(%rsp)
    1768: 0f 83 5c 01 00 00            	jae	0x18ca <trusted_x86_x86_sim_xdp+0x18ca>
    176e: c7 84 24 e0 00 00 00 08 00 00 00     	movl	$0x8, 0xe0(%rsp)
    1779: b8 08 00 00 00               	movl	$0x8, %eax
    177e: e9 61 01 00 00               	jmp	0x18e4 <trusted_x86_x86_sim_xdp+0x18e4>
    1783: 41 81 fc 49 6e 74 65         	cmpl	$0x65746e49, %r12d      # imm = 0x65746E49
    178a: 0f 85 d5 00 00 00            	jne	0x1865 <trusted_x86_x86_sim_xdp+0x1865>
    1790: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    1795: 48 3b 44 24 10               	cmpq	0x10(%rsp), %rax
    179a: 0f 82 cb 0a 00 00            	jb	0x226b <trusted_x86_x86_sim_xdp+0x226b>
    17a0: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    17a5: 48 03 44 24 10               	addq	0x10(%rsp), %rax
    17aa: 48 39 44 24 38               	cmpq	%rax, 0x38(%rsp)
    17af: 0f 83 b6 0a 00 00            	jae	0x226b <trusted_x86_x86_sim_xdp+0x226b>
    17b5: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
    17ba: 48 83 c6 b0                  	addq	$-0x50, %rsi
    17be: ba 60 00 00 00               	movl	$0x60, %edx
    17c3: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    17c8: e8 00 00 00 00               	callq	0x17cd <trusted_x86_x86_sim_xdp+0x17cd>
		00000000000017c9:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    17cd: 85 c0                        	testl	%eax, %eax
    17cf: 79 64                        	jns	0x1835 <trusted_x86_x86_sim_xdp+0x1835>
    17d1: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
    17d6: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    17de: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    17e6: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    17ee: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    17f6: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    17fe: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    1806: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    180e: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    1816: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    181e: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    1826: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    182e: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    1835: 85 c0                        	testl	%eax, %eax
    1837: 0f 85 2e 0a 00 00            	jne	0x226b <trusted_x86_x86_sim_xdp+0x226b>
    183d: 4c 89 f8                     	movq	%r15, %rax
    1840: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    1847: 0f 84 a6 09 00 00            	je	0x21f3 <trusted_x86_x86_sim_xdp+0x21f3>
    184d: 48 8b 04 24                  	movq	(%rsp), %rax
    1851: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    1855: 0f 84 a4 09 00 00            	je	0x21ff <trusted_x86_x86_sim_xdp+0x21ff>
    185b: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1860: e9 9f 09 00 00               	jmp	0x2204 <trusted_x86_x86_sim_xdp+0x2204>
    1865: 8b 84 24 e0 00 00 00         	movl	0xe0(%rsp), %eax
    186c: c7 44 24 28 00 00 00 00      	movl	$0x0, 0x28(%rsp)
    1874: 85 c0                        	testl	%eax, %eax
    1876: 75 6c                        	jne	0x18e4 <trusted_x86_x86_sim_xdp+0x18e4>
    1878: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    187d: eb 50                        	jmp	0x18cf <trusted_x86_x86_sim_xdp+0x18cf>
    187f: 8b 84 24 e0 00 00 00         	movl	0xe0(%rsp), %eax
    1886: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    188b: 48 8b 54 24 38               	movq	0x38(%rsp), %rdx
    1890: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    1894: 48 83 c6 30                  	addq	$0x30, %rsi
    1898: 48 89 74 24 40               	movq	%rsi, 0x40(%rsp)
    189d: 48 39 ca                     	cmpq	%rcx, %rdx
    18a0: 0f 82 af 02 00 00            	jb	0x1b55 <trusted_x86_x86_sim_xdp+0x1b55>
    18a6: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    18ac: 83 c9 03                     	orl	$0x3, %ecx
    18af: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    18b3: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
    18b8: 48 3b 4c 24 40               	cmpq	0x40(%rsp), %rcx
    18bd: 0f 83 8d 02 00 00            	jae	0x1b50 <trusted_x86_x86_sim_xdp+0x1b50>
    18c3: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    18c8: eb 05                        	jmp	0x18cf <trusted_x86_x86_sim_xdp+0x18cf>
    18ca: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    18cf: c7 84 24 e0 00 00 00 10 00 00 00     	movl	$0x10, 0xe0(%rsp)
    18da: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    18df: b8 10 00 00 00               	movl	$0x10, %eax
    18e4: 89 c6                        	movl	%eax, %esi
    18e6: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    18eb: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    18f0: 48 83 c6 f0                  	addq	$-0x10, %rsi
    18f4: ba 10 00 00 00               	movl	$0x10, %edx
    18f9: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    18fe: e8 00 00 00 00               	callq	0x1903 <trusted_x86_x86_sim_xdp+0x1903>
		00000000000018ff:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1903: 85 c0                        	testl	%eax, %eax
    1905: 79 14                        	jns	0x191b <trusted_x86_x86_sim_xdp+0x191b>
    1907: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    190c: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    1914: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    191b: 83 bc 24 e0 00 00 00 10      	cmpl	$0x10, 0xe0(%rsp)
    1923: 72 0a                        	jb	0x192f <trusted_x86_x86_sim_xdp+0x192f>
    1925: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    192a: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    192f: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    1934: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    1939: 4c 89 f8                     	movq	%r15, %rax
    193c: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    1942: 83 f9 7e                     	cmpl	$0x7e, %ecx
    1945: 0f 87 b5 f0 ff ff            	ja	0xa00 <trusted_x86_x86_sim_xdp+0xa00>
    194b: 4c 89 f8                     	movq	%r15, %rax
    194e: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    1955: 8b 54 24 28                  	movl	0x28(%rsp), %edx
    1959: 48 8b b4 24 b0 00 00 00      	movq	0xb0(%rsp), %rsi
    1961: 8d 79 01                     	leal	0x1(%rcx), %edi
    1964: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    196c: 41 89 38                     	movl	%edi, (%r8)
    196f: 49 8d bf d0 02 00 00         	leaq	0x2d0(%r15), %rdi
    1976: c1 e1 03                     	shll	$0x3, %ecx
    1979: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    197c: 48 89 bc 24 a0 01 00 00      	movq	%rdi, 0x1a0(%rsp)
    1984: 48 01 cf                     	addq	%rcx, %rdi
    1987: 4c 89 37                     	movq	%r14, (%rdi)
    198a: 4d 8d 8f d8 02 00 00         	leaq	0x2d8(%r15), %r9
    1991: 4d 8d 87 e0 02 00 00         	leaq	0x2e0(%r15), %r8
    1998: 48 c1 e6 20                  	shlq	$0x20, %rsi
    199c: 44 89 e7                     	movl	%r12d, %edi
    199f: 48 09 f7                     	orq	%rsi, %rdi
    19a2: 49 8d b7 e1 02 00 00         	leaq	0x2e1(%r15), %rsi
    19a9: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    19ad: 48 09 d7                     	orq	%rdx, %rdi
    19b0: 4c 89 8c 24 98 01 00 00      	movq	%r9, 0x198(%rsp)
    19b8: 49 8d 14 09                  	leaq	(%r9,%rcx), %rdx
    19bc: 48 89 3a                     	movq	%rdi, (%rdx)
    19bf: 49 8d bf e2 02 00 00         	leaq	0x2e2(%r15), %rdi
    19c6: 4c 89 84 24 b0 01 00 00      	movq	%r8, 0x1b0(%rsp)
    19ce: 49 8d 14 08                  	leaq	(%r8,%rcx), %rdx
    19d2: c6 02 05                     	movb	$0x5, (%rdx)
    19d5: 48 89 b4 24 40 01 00 00      	movq	%rsi, 0x140(%rsp)
    19dd: 48 8d 14 0e                  	leaq	(%rsi,%rcx), %rdx
    19e1: 88 02                        	movb	%al, (%rdx)
    19e3: 49 8d 97 e6 02 00 00         	leaq	0x2e6(%r15), %rdx
    19ea: 48 89 bc 24 a8 01 00 00      	movq	%rdi, 0x1a8(%rsp)
    19f2: 48 8d 04 0f                  	leaq	(%rdi,%rcx), %rax
    19f6: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    19fc: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
    1a04: 48 01 d1                     	addq	%rdx, %rcx
    1a07: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    1a0c: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    1a11: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    1a19: 48 89 01                     	movq	%rax, (%rcx)
    1a1c: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1a21: 48 8b 8c 24 68 01 00 00      	movq	0x168(%rsp), %rcx
    1a29: 48 89 01                     	movq	%rax, (%rcx)
    1a2c: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    1a31: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    1a39: 48 89 01                     	movq	%rax, (%rcx)
    1a3c: 48 8b 84 24 60 01 00 00      	movq	0x160(%rsp), %rax
    1a44: c6 00 01                     	movb	$0x1, (%rax)
    1a47: c7 44 24 48 2a 00 00 00      	movl	$0x2a, 0x48(%rsp)
    1a4f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1a56 <trusted_x86_x86_sim_xdp+0x1a56>
		0000000000001a52:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1a56: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    1a5b: e8 00 00 00 00               	callq	0x1a60 <trusted_x86_x86_sim_xdp+0x1a60>
		0000000000001a5c:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1a60: 48 85 c0                     	testq	%rax, %rax
    1a63: 74 0c                        	je	0x1a71 <trusted_x86_x86_sim_xdp+0x1a71>
    1a65: 48 89 c1                     	movq	%rax, %rcx
    1a68: 48 8b 09                     	movq	(%rcx), %rcx
    1a6b: 48 ff c1                     	incq	%rcx
    1a6e: 48 89 08                     	movq	%rcx, (%rax)
    1a71: 4c 89 f8                     	movq	%r15, %rax
    1a74: 4c 8b a0 d0 0e 00 00         	movq	0xed0(%rax), %r12
    1a7b: 4d 85 e4                     	testq	%r12, %r12
    1a7e: 0f 84 02 20 00 00            	je	0x3a86 <trusted_x86_x86_sim_xdp+0x3a86>
    1a84: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1a8e: 48 ff c0                     	incq	%rax
    1a91: 48 89 84 24 88 01 00 00      	movq	%rax, 0x188(%rsp)
    1a99: 49 39 c4                     	cmpq	%rax, %r12
    1a9c: 0f 83 ff f4 ff ff            	jae	0xfa1 <trusted_x86_x86_sim_xdp+0xfa1>
    1aa2: 49 81 fc 00 10 00 00         	cmpq	$0x1000, %r12           # imm = 0x1000
    1aa9: 0f 82 13 f5 ff ff            	jb	0xfc2 <trusted_x86_x86_sim_xdp+0xfc2>
    1aaf: 4c 89 f8                     	movq	%r15, %rax
    1ab2: 8b 00                        	movl	(%rax), %eax
    1ab4: c7 44 24 48 60 00 00 00      	movl	$0x60, 0x48(%rsp)
    1abc: 0f 38 f1 44 24 4c            	movbel	%eax, 0x4c(%rsp)
    1ac2: 4c 0f 38 f1 64 24 50         	movbeq	%r12, 0x50(%rsp)
    1ac9: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1ace: e8 00 00 00 00               	callq	0x1ad3 <trusted_x86_x86_sim_xdp+0x1ad3>
		0000000000001acf:  R_X86_64_PLT32	.text+0x5c
    1ad3: 48 85 c0                     	testq	%rax, %rax
    1ad6: 0f 84 c2 1f 00 00            	je	0x3a9e <trusted_x86_x86_sim_xdp+0x3a9e>
    1adc: 48 89 c1                     	movq	%rax, %rcx
    1adf: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    1ae3: 48 89 e9                     	movq	%rbp, %rcx
    1ae6: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    1af0: 48 21 d1                     	andq	%rdx, %rcx
    1af3: 48 8b 94 24 58 01 00 00      	movq	0x158(%rsp), %rdx
    1afb: 48 89 0a                     	movq	%rcx, (%rdx)
    1afe: 48 8b 00                     	movq	(%rax), %rax
    1b01: 48 8b 94 24 50 01 00 00      	movq	0x150(%rsp), %rdx
    1b09: 48 89 02                     	movq	%rax, (%rdx)
    1b0c: 48 c1 ed 38                  	shrq	$0x38, %rbp
    1b10: 49 29 cc                     	subq	%rcx, %r12
    1b13: 48 8b 8c 24 48 01 00 00      	movq	0x148(%rsp), %rcx
    1b1b: 4c 89 21                     	movq	%r12, (%rcx)
    1b1e: 48 83 fd 01                  	cmpq	$0x1, %rbp
    1b22: 0f 85 83 03 00 00            	jne	0x1eab <trusted_x86_x86_sim_xdp+0x1eab>
    1b28: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    1b2d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1b34 <trusted_x86_x86_sim_xdp+0x1b34>
		0000000000001b30:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1b34: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1b39: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1b40 <trusted_x86_x86_sim_xdp+0x1b40>
		0000000000001b3c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1b40: 0f 85 b8 02 00 00            	jne	0x1dfe <trusted_x86_x86_sim_xdp+0x1dfe>
    1b46: e8 00 00 00 00               	callq	0x1b4b <trusted_x86_x86_sim_xdp+0x1b4b>
		0000000000001b47:  R_X86_64_PLT32	.text+0x5c
    1b4b: e9 b3 02 00 00               	jmp	0x1e03 <trusted_x86_x86_sim_xdp+0x1e03>
    1b50: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    1b55: 48 8d 14 01                  	leaq	(%rcx,%rax), %rdx
    1b59: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
    1b5e: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    1b62: 48 83 c6 f8                  	addq	$-0x8, %rsi
    1b66: ba 30 00 00 00               	movl	$0x30, %edx
    1b6b: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1b70: e8 00 00 00 00               	callq	0x1b75 <trusted_x86_x86_sim_xdp+0x1b75>
		0000000000001b71:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1b75: 85 c0                        	testl	%eax, %eax
    1b77: 79 34                        	jns	0x1bad <trusted_x86_x86_sim_xdp+0x1bad>
    1b79: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    1b7e: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    1b86: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    1b8e: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    1b96: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    1b9e: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    1ba6: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    1bad: 48 bd 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %rbp # imm = 0xFF00000000000000
    1bb7: 4c 89 f8                     	movq	%r15, %rax
    1bba: 8b 00                        	movl	(%rax), %eax
    1bbc: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1bc4: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1bca: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1bcf: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1bd4: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1bdb: e8 00 00 00 00               	callq	0x1be0 <trusted_x86_x86_sim_xdp+0x1be0>
		0000000000001bdc:  R_X86_64_PLT32	.text+0x5c
    1be0: 48 85 c0                     	testq	%rax, %rax
    1be3: 74 20                        	je	0x1c05 <trusted_x86_x86_sim_xdp+0x1c05>
    1be5: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1be9: 48 21 e8                     	andq	%rbp, %rax
    1bec: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1bf6: 48 39 c8                     	cmpq	%rcx, %rax
    1bf9: 75 0a                        	jne	0x1c05 <trusted_x86_x86_sim_xdp+0x1c05>
    1bfb: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1c00: e9 8f 01 00 00               	jmp	0x1d94 <trusted_x86_x86_sim_xdp+0x1d94>
    1c05: 4c 89 f8                     	movq	%r15, %rax
    1c08: 8b 00                        	movl	(%rax), %eax
    1c0a: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1c12: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1c18: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    1c1d: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1c24: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1c29: e8 00 00 00 00               	callq	0x1c2e <trusted_x86_x86_sim_xdp+0x1c2e>
		0000000000001c2a:  R_X86_64_PLT32	.text+0x5c
    1c2e: 48 85 c0                     	testq	%rax, %rax
    1c31: 74 24                        	je	0x1c57 <trusted_x86_x86_sim_xdp+0x1c57>
    1c33: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1c37: 48 21 e8                     	andq	%rbp, %rax
    1c3a: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1c44: 48 39 c8                     	cmpq	%rcx, %rax
    1c47: 75 0e                        	jne	0x1c57 <trusted_x86_x86_sim_xdp+0x1c57>
    1c49: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1c4e: 48 83 c0 08                  	addq	$0x8, %rax
    1c52: e9 3d 01 00 00               	jmp	0x1d94 <trusted_x86_x86_sim_xdp+0x1d94>
    1c57: 4c 89 f8                     	movq	%r15, %rax
    1c5a: 8b 00                        	movl	(%rax), %eax
    1c5c: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1c64: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1c6a: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1c6f: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1c76: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1c7b: e8 00 00 00 00               	callq	0x1c80 <trusted_x86_x86_sim_xdp+0x1c80>
		0000000000001c7c:  R_X86_64_PLT32	.text+0x5c
    1c80: 48 85 c0                     	testq	%rax, %rax
    1c83: 74 24                        	je	0x1ca9 <trusted_x86_x86_sim_xdp+0x1ca9>
    1c85: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1c89: 48 21 e8                     	andq	%rbp, %rax
    1c8c: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1c96: 48 39 c8                     	cmpq	%rcx, %rax
    1c99: 75 0e                        	jne	0x1ca9 <trusted_x86_x86_sim_xdp+0x1ca9>
    1c9b: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1ca0: 48 83 c0 10                  	addq	$0x10, %rax
    1ca4: e9 eb 00 00 00               	jmp	0x1d94 <trusted_x86_x86_sim_xdp+0x1d94>
    1ca9: 4c 89 f8                     	movq	%r15, %rax
    1cac: 8b 00                        	movl	(%rax), %eax
    1cae: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1cb6: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1cbc: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    1cc1: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1cc8: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1ccd: e8 00 00 00 00               	callq	0x1cd2 <trusted_x86_x86_sim_xdp+0x1cd2>
		0000000000001cce:  R_X86_64_PLT32	.text+0x5c
    1cd2: 48 85 c0                     	testq	%rax, %rax
    1cd5: 74 24                        	je	0x1cfb <trusted_x86_x86_sim_xdp+0x1cfb>
    1cd7: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1cdb: 48 21 e8                     	andq	%rbp, %rax
    1cde: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1ce8: 48 39 c8                     	cmpq	%rcx, %rax
    1ceb: 75 0e                        	jne	0x1cfb <trusted_x86_x86_sim_xdp+0x1cfb>
    1ced: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1cf2: 48 83 c0 18                  	addq	$0x18, %rax
    1cf6: e9 99 00 00 00               	jmp	0x1d94 <trusted_x86_x86_sim_xdp+0x1d94>
    1cfb: 4c 89 f8                     	movq	%r15, %rax
    1cfe: 8b 00                        	movl	(%rax), %eax
    1d00: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1d08: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1d0e: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    1d13: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1d1a: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1d1f: e8 00 00 00 00               	callq	0x1d24 <trusted_x86_x86_sim_xdp+0x1d24>
		0000000000001d20:  R_X86_64_PLT32	.text+0x5c
    1d24: 48 85 c0                     	testq	%rax, %rax
    1d27: 74 21                        	je	0x1d4a <trusted_x86_x86_sim_xdp+0x1d4a>
    1d29: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1d2d: 48 21 e8                     	andq	%rbp, %rax
    1d30: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1d3a: 48 39 c8                     	cmpq	%rcx, %rax
    1d3d: 75 0b                        	jne	0x1d4a <trusted_x86_x86_sim_xdp+0x1d4a>
    1d3f: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1d44: 48 83 c0 20                  	addq	$0x20, %rax
    1d48: eb 4a                        	jmp	0x1d94 <trusted_x86_x86_sim_xdp+0x1d94>
    1d4a: 4c 89 f8                     	movq	%r15, %rax
    1d4d: 8b 00                        	movl	(%rax), %eax
    1d4f: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    1d57: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    1d5d: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    1d62: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    1d69: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    1d6e: e8 00 00 00 00               	callq	0x1d73 <trusted_x86_x86_sim_xdp+0x1d73>
		0000000000001d6f:  R_X86_64_PLT32	.text+0x5c
    1d73: 48 85 c0                     	testq	%rax, %rax
    1d76: 74 3f                        	je	0x1db7 <trusted_x86_x86_sim_xdp+0x1db7>
    1d78: 48 23 68 08                  	andq	0x8(%rax), %rbp
    1d7c: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    1d86: 48 39 c5                     	cmpq	%rax, %rbp
    1d89: 75 2c                        	jne	0x1db7 <trusted_x86_x86_sim_xdp+0x1db7>
    1d8b: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    1d90: 48 83 c0 28                  	addq	$0x28, %rax
    1d94: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    1d99: 89 c1                        	movl	%eax, %ecx
    1d9b: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    1da1: 83 c9 03                     	orl	$0x3, %ecx
    1da4: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    1da8: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    1dad: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    1db2: e9 39 fb ff ff               	jmp	0x18f0 <trusted_x86_x86_sim_xdp+0x18f0>
    1db7: c7 44 24 18 2e 00 00 00      	movl	$0x2e, 0x18(%rsp)
    1dbf: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1dc6 <trusted_x86_x86_sim_xdp+0x1dc6>
		0000000000001dc2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1dc6: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
    1dcb: e8 00 00 00 00               	callq	0x1dd0 <trusted_x86_x86_sim_xdp+0x1dd0>
		0000000000001dcc:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1dd0: 48 85 c0                     	testq	%rax, %rax
    1dd3: 74 0c                        	je	0x1de1 <trusted_x86_x86_sim_xdp+0x1de1>
    1dd5: 48 89 c1                     	movq	%rax, %rcx
    1dd8: 48 8b 09                     	movq	(%rcx), %rcx
    1ddb: 48 ff c1                     	incq	%rcx
    1dde: 48 89 08                     	movq	%rcx, (%rax)
    1de1: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
    1de9: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    1dee: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    1df3: 41 be ea 03 00 00            	movl	$0x3ea, %r14d           # imm = 0x3EA
    1df9: e9 97 e3 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
    1dfe: e8 00 00 00 00               	callq	0x1e03 <trusted_x86_x86_sim_xdp+0x1e03>
		0000000000001dff:  R_X86_64_PLT32	.text+0x10c
    1e03: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    1e08: 45 31 f6                     	xorl	%r14d, %r14d
    1e0b: bd 01 00 00 00               	movl	$0x1, %ebp
    1e10: 48 85 c0                     	testq	%rax, %rax
    1e13: 0f 84 7e e3 ff ff            	je	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1e19: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1e1e: 48 8b 00                     	movq	(%rax), %rax
    1e21: 4c 39 e0                     	cmpq	%r12, %rax
    1e24: 77 0e                        	ja	0x1e34 <trusted_x86_x86_sim_xdp+0x1e34>
    1e26: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1e2b: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1e2f: 4c 39 e0                     	cmpq	%r12, %rax
    1e32: 73 24                        	jae	0x1e58 <trusted_x86_x86_sim_xdp+0x1e58>
    1e34: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1e39: 48 8b 40 10                  	movq	0x10(%rax), %rax
    1e3d: 4c 39 e0                     	cmpq	%r12, %rax
    1e40: 0f 87 51 e3 ff ff            	ja	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1e46: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1e4b: 48 8b 40 18                  	movq	0x18(%rax), %rax
    1e4f: 4c 39 e0                     	cmpq	%r12, %rax
    1e52: 0f 82 3f e3 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1e58: 4c 89 f8                     	movq	%r15, %rax
    1e5b: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    1e61: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    1e66: 8b 49 20                     	movl	0x20(%rcx), %ecx
    1e69: 0f a3 c8                     	btl	%ecx, %eax
    1e6c: 0f 82 25 e3 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1e72: 48 8d b4 24 b8 00 00 00      	leaq	0xb8(%rsp), %rsi
    1e7a: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
    1e85: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1e8c <trusted_x86_x86_sim_xdp+0x1e8c>
		0000000000001e88:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1e8c: e8 00 00 00 00               	callq	0x1e91 <trusted_x86_x86_sim_xdp+0x1e91>
		0000000000001e8d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1e91: 48 85 c0                     	testq	%rax, %rax
    1e94: 74 0c                        	je	0x1ea2 <trusted_x86_x86_sim_xdp+0x1ea2>
    1e96: 48 89 c1                     	movq	%rax, %rcx
    1e99: 48 8b 09                     	movq	(%rcx), %rcx
    1e9c: 48 ff c1                     	incq	%rcx
    1e9f: 48 89 08                     	movq	%rcx, (%rax)
    1ea2: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1ea7: 0f b7 68 20                  	movzwl	0x20(%rax), %ebp
    1eab: 45 31 f6                     	xorl	%r14d, %r14d
    1eae: 83 fd 02                     	cmpl	$0x2, %ebp
    1eb1: 0f 85 e0 e2 ff ff            	jne	0x197 <trusted_x86_x86_sim_xdp+0x197>
    1eb7: c7 44 24 48 29 00 00 00      	movl	$0x29, 0x48(%rsp)
    1ebf: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1ec6 <trusted_x86_x86_sim_xdp+0x1ec6>
		0000000000001ec2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1ec6: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    1ecb: e8 00 00 00 00               	callq	0x1ed0 <trusted_x86_x86_sim_xdp+0x1ed0>
		0000000000001ecc:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1ed0: 48 85 c0                     	testq	%rax, %rax
    1ed3: 74 0c                        	je	0x1ee1 <trusted_x86_x86_sim_xdp+0x1ee1>
    1ed5: 48 89 c1                     	movq	%rax, %rcx
    1ed8: 48 8b 09                     	movq	(%rcx), %rcx
    1edb: 48 ff c1                     	incq	%rcx
    1ede: 48 89 08                     	movq	%rcx, (%rax)
    1ee1: 4c 89 f8                     	movq	%r15, %rax
    1ee4: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    1eeb: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    1ef0: 4c 89 f8                     	movq	%r15, %rax
    1ef3: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    1efa: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    1eff: 48 8b 04 24                  	movq	(%rsp), %rax
    1f03: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    1f07: 4c 89 f9                     	movq	%r15, %rcx
    1f0a: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    1f11: 48 89 4c 24 38               	movq	%rcx, 0x38(%rsp)
    1f16: 4c 89 f9                     	movq	%r15, %rcx
    1f19: c4 62 fb f7 b1 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r14
    1f22: 4c 89 f8                     	movq	%r15, %rax
    1f25: 48 8b a8 10 0f 00 00         	movq	0xf10(%rax), %rbp
    1f2c: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1f36: 48 21 c5                     	andq	%rax, %rbp
    1f39: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1f3d: ba 01 00 00 00               	movl	$0x1, %edx
    1f42: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1f47: e8 00 00 00 00               	callq	0x1f4c <trusted_x86_x86_sim_xdp+0x1f4c>
		0000000000001f48:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1f4c: 85 c0                        	testl	%eax, %eax
    1f4e: 79 05                        	jns	0x1f55 <trusted_x86_x86_sim_xdp+0x1f55>
    1f50: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1f55: 85 c0                        	testl	%eax, %eax
    1f57: 0f 85 fc e1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1f5d: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1f62: 8d 48 01                     	leal	0x1(%rax), %ecx
    1f65: f6 c1 fe                     	testb	$-0x2, %cl
    1f68: 0f 84 90 03 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    1f6e: 89 c0                        	movl	%eax, %eax
    1f70: 49 29 c6                     	subq	%rax, %r14
    1f73: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1f77: ba 01 00 00 00               	movl	$0x1, %edx
    1f7c: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1f81: e8 00 00 00 00               	callq	0x1f86 <trusted_x86_x86_sim_xdp+0x1f86>
		0000000000001f82:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1f86: 85 c0                        	testl	%eax, %eax
    1f88: 79 05                        	jns	0x1f8f <trusted_x86_x86_sim_xdp+0x1f8f>
    1f8a: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1f8f: 85 c0                        	testl	%eax, %eax
    1f91: 0f 85 c2 e1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1f97: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1f9c: 8d 48 01                     	leal	0x1(%rax), %ecx
    1f9f: f6 c1 fe                     	testb	$-0x2, %cl
    1fa2: 0f 84 56 03 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    1fa8: 89 c0                        	movl	%eax, %eax
    1faa: 49 29 c6                     	subq	%rax, %r14
    1fad: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1fb1: ba 01 00 00 00               	movl	$0x1, %edx
    1fb6: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1fbb: e8 00 00 00 00               	callq	0x1fc0 <trusted_x86_x86_sim_xdp+0x1fc0>
		0000000000001fbc:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1fc0: 85 c0                        	testl	%eax, %eax
    1fc2: 79 05                        	jns	0x1fc9 <trusted_x86_x86_sim_xdp+0x1fc9>
    1fc4: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    1fc9: 85 c0                        	testl	%eax, %eax
    1fcb: 0f 85 88 e1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    1fd1: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    1fd6: 8d 48 01                     	leal	0x1(%rax), %ecx
    1fd9: f6 c1 fe                     	testb	$-0x2, %cl
    1fdc: 0f 84 1c 03 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    1fe2: 89 c0                        	movl	%eax, %eax
    1fe4: 49 29 c6                     	subq	%rax, %r14
    1fe7: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    1feb: ba 01 00 00 00               	movl	$0x1, %edx
    1ff0: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    1ff5: e8 00 00 00 00               	callq	0x1ffa <trusted_x86_x86_sim_xdp+0x1ffa>
		0000000000001ff6:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1ffa: 85 c0                        	testl	%eax, %eax
    1ffc: 79 05                        	jns	0x2003 <trusted_x86_x86_sim_xdp+0x2003>
    1ffe: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2003: 85 c0                        	testl	%eax, %eax
    2005: 0f 85 4e e1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    200b: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2010: 8d 48 01                     	leal	0x1(%rax), %ecx
    2013: f6 c1 fe                     	testb	$-0x2, %cl
    2016: 0f 84 e2 02 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    201c: 89 c0                        	movl	%eax, %eax
    201e: 49 29 c6                     	subq	%rax, %r14
    2021: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2025: ba 01 00 00 00               	movl	$0x1, %edx
    202a: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    202f: e8 00 00 00 00               	callq	0x2034 <trusted_x86_x86_sim_xdp+0x2034>
		0000000000002030:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2034: 85 c0                        	testl	%eax, %eax
    2036: 79 05                        	jns	0x203d <trusted_x86_x86_sim_xdp+0x203d>
    2038: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    203d: 85 c0                        	testl	%eax, %eax
    203f: 0f 85 14 e1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2045: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    204a: 8d 48 01                     	leal	0x1(%rax), %ecx
    204d: f6 c1 fe                     	testb	$-0x2, %cl
    2050: 0f 84 a8 02 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    2056: 89 c0                        	movl	%eax, %eax
    2058: 49 29 c6                     	subq	%rax, %r14
    205b: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    205f: ba 01 00 00 00               	movl	$0x1, %edx
    2064: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2069: e8 00 00 00 00               	callq	0x206e <trusted_x86_x86_sim_xdp+0x206e>
		000000000000206a:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    206e: 85 c0                        	testl	%eax, %eax
    2070: 79 05                        	jns	0x2077 <trusted_x86_x86_sim_xdp+0x2077>
    2072: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2077: 85 c0                        	testl	%eax, %eax
    2079: 0f 85 da e0 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    207f: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2084: 8d 48 01                     	leal	0x1(%rax), %ecx
    2087: f6 c1 fe                     	testb	$-0x2, %cl
    208a: 0f 84 6e 02 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    2090: 89 c0                        	movl	%eax, %eax
    2092: 49 29 c6                     	subq	%rax, %r14
    2095: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2099: ba 01 00 00 00               	movl	$0x1, %edx
    209e: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    20a3: e8 00 00 00 00               	callq	0x20a8 <trusted_x86_x86_sim_xdp+0x20a8>
		00000000000020a4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    20a8: 85 c0                        	testl	%eax, %eax
    20aa: 79 05                        	jns	0x20b1 <trusted_x86_x86_sim_xdp+0x20b1>
    20ac: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    20b1: 85 c0                        	testl	%eax, %eax
    20b3: 0f 85 a0 e0 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    20b9: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    20be: 8d 48 01                     	leal	0x1(%rax), %ecx
    20c1: f6 c1 fe                     	testb	$-0x2, %cl
    20c4: 0f 84 34 02 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    20ca: 89 c0                        	movl	%eax, %eax
    20cc: 49 29 c6                     	subq	%rax, %r14
    20cf: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    20d3: ba 01 00 00 00               	movl	$0x1, %edx
    20d8: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    20dd: e8 00 00 00 00               	callq	0x20e2 <trusted_x86_x86_sim_xdp+0x20e2>
		00000000000020de:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    20e2: 85 c0                        	testl	%eax, %eax
    20e4: 79 05                        	jns	0x20eb <trusted_x86_x86_sim_xdp+0x20eb>
    20e6: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    20eb: 85 c0                        	testl	%eax, %eax
    20ed: 0f 85 66 e0 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    20f3: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    20f8: 8d 48 01                     	leal	0x1(%rax), %ecx
    20fb: f6 c1 fe                     	testb	$-0x2, %cl
    20fe: 0f 84 fa 01 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    2104: 89 c0                        	movl	%eax, %eax
    2106: 49 29 c6                     	subq	%rax, %r14
    2109: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    210d: ba 01 00 00 00               	movl	$0x1, %edx
    2112: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2117: e8 00 00 00 00               	callq	0x211c <trusted_x86_x86_sim_xdp+0x211c>
		0000000000002118:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    211c: 85 c0                        	testl	%eax, %eax
    211e: 79 05                        	jns	0x2125 <trusted_x86_x86_sim_xdp+0x2125>
    2120: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2125: 85 c0                        	testl	%eax, %eax
    2127: 0f 85 2c e0 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    212d: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2132: 8d 48 01                     	leal	0x1(%rax), %ecx
    2135: f6 c1 fe                     	testb	$-0x2, %cl
    2138: 0f 84 c0 01 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    213e: 89 c0                        	movl	%eax, %eax
    2140: 49 29 c6                     	subq	%rax, %r14
    2143: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2147: ba 01 00 00 00               	movl	$0x1, %edx
    214c: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2151: e8 00 00 00 00               	callq	0x2156 <trusted_x86_x86_sim_xdp+0x2156>
		0000000000002152:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2156: 85 c0                        	testl	%eax, %eax
    2158: 79 05                        	jns	0x215f <trusted_x86_x86_sim_xdp+0x215f>
    215a: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    215f: 85 c0                        	testl	%eax, %eax
    2161: 0f 85 f2 df ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2167: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    216c: 8d 48 01                     	leal	0x1(%rax), %ecx
    216f: f6 c1 fe                     	testb	$-0x2, %cl
    2172: 0f 84 86 01 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    2178: 89 c0                        	movl	%eax, %eax
    217a: 49 29 c6                     	subq	%rax, %r14
    217d: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2181: ba 01 00 00 00               	movl	$0x1, %edx
    2186: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    218b: e8 00 00 00 00               	callq	0x2190 <trusted_x86_x86_sim_xdp+0x2190>
		000000000000218c:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2190: 85 c0                        	testl	%eax, %eax
    2192: 79 05                        	jns	0x2199 <trusted_x86_x86_sim_xdp+0x2199>
    2194: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2199: 85 c0                        	testl	%eax, %eax
    219b: 0f 85 b8 df ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    21a1: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    21a6: 8d 48 01                     	leal	0x1(%rax), %ecx
    21a9: f6 c1 fe                     	testb	$-0x2, %cl
    21ac: 0f 84 4c 01 00 00            	je	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    21b2: 89 c0                        	movl	%eax, %eax
    21b4: 49 29 c6                     	subq	%rax, %r14
    21b7: 4c 01 f5                     	addq	%r14, %rbp
    21ba: ba 01 00 00 00               	movl	$0x1, %edx
    21bf: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    21c4: 48 89 ee                     	movq	%rbp, %rsi
    21c7: e8 00 00 00 00               	callq	0x21cc <trusted_x86_x86_sim_xdp+0x21cc>
		00000000000021c8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    21cc: 85 c0                        	testl	%eax, %eax
    21ce: 79 05                        	jns	0x21d5 <trusted_x86_x86_sim_xdp+0x21d5>
    21d0: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    21d5: 85 c0                        	testl	%eax, %eax
    21d7: 0f 85 7c df ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    21dd: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    21e2: 8d 48 01                     	leal	0x1(%rax), %ecx
    21e5: f6 c1 fe                     	testb	$-0x2, %cl
    21e8: 0f 85 6b df ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    21ee: e9 0b 01 00 00               	jmp	0x22fe <trusted_x86_x86_sim_xdp+0x22fe>
    21f3: 4c 89 f8                     	movq	%r15, %rax
    21f6: 48 8b 80 00 0f 00 00         	movq	0xf00(%rax), %rax
    21fd: eb 05                        	jmp	0x2204 <trusted_x86_x86_sim_xdp+0x2204>
    21ff: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    2204: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
    220c: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    2214: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
    221c: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
    2221: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    2229: 48 89 4c 24 38               	movq	%rcx, 0x38(%rsp)
    222e: 48 8b 8c 24 a0 00 00 00      	movq	0xa0(%rsp), %rcx
    2236: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    223b: 48 8b 0c 24                  	movq	(%rsp), %rcx
    223f: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
    2243: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2248: 48 01 c6                     	addq	%rax, %rsi
    224b: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2250: ba 08 00 00 00               	movl	$0x8, %edx
    2255: e8 00 00 00 00               	callq	0x225a <trusted_x86_x86_sim_xdp+0x225a>
		0000000000002256:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    225a: 85 c0                        	testl	%eax, %eax
    225c: 79 09                        	jns	0x2267 <trusted_x86_x86_sim_xdp+0x2267>
    225e: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
    2267: 85 c0                        	testl	%eax, %eax
    2269: 74 3c                        	je	0x22a7 <trusted_x86_x86_sim_xdp+0x22a7>
    226b: 48 8d b4 24 f4 00 00 00      	leaq	0xf4(%rsp), %rsi
    2273: c7 84 24 f4 00 00 00 2d 00 00 00     	movl	$0x2d, 0xf4(%rsp)
    227e: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2285 <trusted_x86_x86_sim_xdp+0x2285>
		0000000000002281:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2285: e8 00 00 00 00               	callq	0x228a <trusted_x86_x86_sim_xdp+0x228a>
		0000000000002286:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    228a: 41 be e9 03 00 00            	movl	$0x3e9, %r14d           # imm = 0x3E9
    2290: 48 85 c0                     	testq	%rax, %rax
    2293: 0f 84 fc de ff ff            	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
    2299: 48 89 c1                     	movq	%rax, %rcx
    229c: 48 8b 09                     	movq	(%rcx), %rcx
    229f: 48 ff c1                     	incq	%rcx
    22a2: e9 eb de ff ff               	jmp	0x192 <trusted_x86_x86_sim_xdp+0x192>
    22a7: 4c 8b 64 24 18               	movq	0x18(%rsp), %r12
    22ac: 48 8b 04 24                  	movq	(%rsp), %rax
    22b0: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    22b4: 4c 01 e0                     	addq	%r12, %rax
    22b7: 4c 8b 74 24 40               	movq	0x40(%rsp), %r14
    22bc: 48 8b 8c 24 00 01 00 00      	movq	0x100(%rsp), %rcx
    22c4: 31 d2                        	xorl	%edx, %edx
    22c6: 48 39 c1                     	cmpq	%rax, %rcx
    22c9: 48 0f 43 d0                  	cmovaeq	%rax, %rdx
    22cd: 48 29 d1                     	subq	%rdx, %rcx
    22d0: 48 81 f9 ff ff 00 00         	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    22d7: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    22dc: 48 0f 42 c1                  	cmovbq	%rcx, %rax
    22e0: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
    22e8: 49 c1 ec 03                  	shrq	$0x3, %r12
    22ec: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
    22f2: 83 ca 02                     	orl	$0x2, %edx
    22f5: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
    22f9: e9 3b f6 ff ff               	jmp	0x1939 <trusted_x86_x86_sim_xdp+0x1939>
    22fe: 85 c0                        	testl	%eax, %eax
    2300: 0f 85 53 de ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2306: 48 8b 14 24                  	movq	(%rsp), %rdx
    230a: 48 89 d0                     	movq	%rdx, %rax
    230d: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    2311: c4 c2 f9 f7 c6               	shlxq	%rax, %r14, %rax
    2316: 4c 89 f9                     	movq	%r15, %rcx
    2319: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    2320: 48 89 d1                     	movq	%rdx, %rcx
    2323: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    2327: 48 01 c6                     	addq	%rax, %rsi
    232a: 48 89 b4 24 b8 00 00 00      	movq	%rsi, 0xb8(%rsp)
    2332: 0f 84 2d de ff ff            	je	0x165 <trusted_x86_x86_sim_xdp+0x165>
    2338: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    233d: 4c 89 ef                     	movq	%r13, %rdi
    2340: e8 00 00 00 00               	callq	0x2345 <trusted_x86_x86_sim_xdp+0x2345>
		0000000000002341:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2345: 48 89 c5                     	movq	%rax, %rbp
    2348: 85 ed                        	testl	%ebp, %ebp
    234a: 79 0f                        	jns	0x235b <trusted_x86_x86_sim_xdp+0x235b>
    234c: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    2351: 4c 89 ef                     	movq	%r13, %rdi
    2354: 31 f6                        	xorl	%esi, %esi
    2356: e8 00 00 00 00               	callq	0x235b <trusted_x86_x86_sim_xdp+0x235b>
		0000000000002357:  R_X86_64_PLT32	memset-0x4
    235b: 85 ed                        	testl	%ebp, %ebp
    235d: 48 8b 04 24                  	movq	(%rsp), %rax
    2361: 0f 85 33 e2 ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    2367: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    236b: 0f b7 c0                     	movzwl	%ax, %eax
    236e: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    2373: 0f 87 0e 0f 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    2379: 48 8b 0c 24                  	movq	(%rsp), %rcx
    237d: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    2381: 0f b7 c9                     	movzwl	%cx, %ecx
    2384: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    238a: 0f 87 f7 0e 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    2390: 48 8b 14 24                  	movq	(%rsp), %rdx
    2394: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    2398: 0f b7 d2                     	movzwl	%dx, %edx
    239b: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    23a1: 0f 87 e0 0e 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    23a7: 48 8b 3c 24                  	movq	(%rsp), %rdi
    23ab: 48 89 fe                     	movq	%rdi, %rsi
    23ae: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    23b2: 40 0f b6 f6                  	movzbl	%sil, %esi
    23b6: 4c 01 ee                     	addq	%r13, %rsi
    23b9: 48 8b 36                     	movq	(%rsi), %rsi
    23bc: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
    23c4: 48 89 fe                     	movq	%rdi, %rsi
    23c7: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    23cb: 40 0f b6 f6                  	movzbl	%sil, %esi
    23cf: 4c 01 ee                     	addq	%r13, %rsi
    23d2: 48 8b 36                     	movq	(%rsi), %rsi
    23d5: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    23dd: 48 89 fe                     	movq	%rdi, %rsi
    23e0: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    23e4: 40 0f b6 f6                  	movzbl	%sil, %esi
    23e8: 4c 01 ee                     	addq	%r13, %rsi
    23eb: 8b 36                        	movl	(%rsi), %esi
    23ed: c1 e6 03                     	shll	$0x3, %esi
    23f0: 89 b4 24 e0 00 00 00         	movl	%esi, 0xe0(%rsp)
    23f7: 48 89 fe                     	movq	%rdi, %rsi
    23fa: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    23fe: 40 0f b6 f6                  	movzbl	%sil, %esi
    2402: 4c 01 ee                     	addq	%r13, %rsi
    2405: 0f b7 36                     	movzwl	(%rsi), %esi
    2408: 66 89 b4 24 e8 00 00 00      	movw	%si, 0xe8(%rsp)
    2410: 4c 01 e9                     	addq	%r13, %rcx
    2413: 8b 09                        	movl	(%rcx), %ecx
    2415: 89 8c 24 e4 00 00 00         	movl	%ecx, 0xe4(%rsp)
    241c: 4c 01 ea                     	addq	%r13, %rdx
    241f: 8b 0a                        	movl	(%rdx), %ecx
    2421: 89 8c 24 dc 00 00 00         	movl	%ecx, 0xdc(%rsp)
    2428: 4c 01 e8                     	addq	%r13, %rax
    242b: 48 8b 00                     	movq	(%rax), %rax
    242e: 48 89 84 24 d0 00 00 00      	movq	%rax, 0xd0(%rsp)
    2436: 48 89 f8                     	movq	%rdi, %rax
    2439: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    243d: 0f b6 c0                     	movzbl	%al, %eax
    2440: 4c 01 e8                     	addq	%r13, %rax
    2443: 48 8b 30                     	movq	(%rax), %rsi
    2446: ba 04 00 00 00               	movl	$0x4, %edx
    244b: 48 8d bc 24 d8 00 00 00      	leaq	0xd8(%rsp), %rdi
    2453: e8 00 00 00 00               	callq	0x2458 <trusted_x86_x86_sim_xdp+0x2458>
		0000000000002454:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2458: 85 c0                        	testl	%eax, %eax
    245a: 79 0b                        	jns	0x2467 <trusted_x86_x86_sim_xdp+0x2467>
    245c: c7 84 24 d8 00 00 00 00 00 00 00     	movl	$0x0, 0xd8(%rsp)
    2467: 85 c0                        	testl	%eax, %eax
    2469: 48 8b 04 24                  	movq	(%rsp), %rax
    246d: 0f 85 27 e1 ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    2473: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    2477: 4c 8b b4 24 b8 00 00 00      	movq	0xb8(%rsp), %r14
    247f: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    2487: 84 c0                        	testb	%al, %al
    2489: 74 1f                        	je	0x24aa <trusted_x86_x86_sim_xdp+0x24aa>
    248b: 89 c9                        	movl	%ecx, %ecx
    248d: 4c 01 f1                     	addq	%r14, %rcx
    2490: 48 89 8c 24 c0 00 00 00      	movq	%rcx, 0xc0(%rsp)
    2498: 8b 94 24 c8 00 00 00         	movl	0xc8(%rsp), %edx
    249f: 4c 01 f2                     	addq	%r14, %rdx
    24a2: 48 89 94 24 c8 00 00 00      	movq	%rdx, 0xc8(%rsp)
    24aa: 44 8b a4 24 d8 00 00 00      	movl	0xd8(%rsp), %r12d
    24b2: 48 8b 54 24 30               	movq	0x30(%rsp), %rdx
    24b7: 89 d6                        	movl	%edx, %esi
    24b9: 29 ce                        	subl	%ecx, %esi
    24bb: 48 89 b4 24 b0 00 00 00      	movq	%rsi, 0xb0(%rsp)
    24c3: 41 81 fc 6d 61 74 69         	cmpl	$0x6974616d, %r12d      # imm = 0x6974616D
    24ca: 7f 1a                        	jg	0x24e6 <trusted_x86_x86_sim_xdp+0x24e6>
    24cc: 41 81 fc 76 74 61 62         	cmpl	$0x62617476, %r12d      # imm = 0x62617476
    24d3: 0f 85 e8 00 00 00            	jne	0x25c1 <trusted_x86_x86_sim_xdp+0x25c1>
    24d9: c7 44 24 28 01 00 00 00      	movl	$0x1, 0x28(%rsp)
    24e1: e9 c6 00 00 00               	jmp	0x25ac <trusted_x86_x86_sim_xdp+0x25ac>
    24e6: 41 81 fc 6e 61 74 69         	cmpl	$0x6974616e, %r12d      # imm = 0x6974616E
    24ed: 74 12                        	je	0x2501 <trusted_x86_x86_sim_xdp+0x2501>
    24ef: 41 81 fc 6e 6d 65 74         	cmpl	$0x74656d6e, %r12d      # imm = 0x74656D6E
    24f6: 0f 85 a7 01 00 00            	jne	0x26a3 <trusted_x86_x86_sim_xdp+0x26a3>
    24fc: 48 8b 54 24 30               	movq	0x30(%rsp), %rdx
    2501: 48 8b b4 24 d0 00 00 00      	movq	0xd0(%rsp), %rsi
    2509: 89 f7                        	movl	%esi, %edi
    250b: 4c 01 f7                     	addq	%r14, %rdi
    250e: 84 c0                        	testb	%al, %al
    2510: 44 8b a4 24 e4 00 00 00      	movl	0xe4(%rsp), %r12d
    2518: 48 0f 44 fe                  	cmoveq	%rsi, %rdi
    251c: 48 39 fa                     	cmpq	%rdi, %rdx
    251f: 75 59                        	jne	0x257a <trusted_x86_x86_sim_xdp+0x257a>
    2521: 8b b4 24 dc 00 00 00         	movl	0xdc(%rsp), %esi
    2528: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    252d: ba 08 00 00 00               	movl	$0x8, %edx
    2532: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2537: e8 00 00 00 00               	callq	0x253c <trusted_x86_x86_sim_xdp+0x253c>
		0000000000002538:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    253c: 85 c0                        	testl	%eax, %eax
    253e: 79 09                        	jns	0x2549 <trusted_x86_x86_sim_xdp+0x2549>
    2540: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
    2549: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    2551: 85 c0                        	testl	%eax, %eax
    2553: 75 25                        	jne	0x257a <trusted_x86_x86_sim_xdp+0x257a>
    2555: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    255a: 48 39 c8                     	cmpq	%rcx, %rax
    255d: 72 1b                        	jb	0x257a <trusted_x86_x86_sim_xdp+0x257a>
    255f: 48 3b 84 24 c8 00 00 00      	cmpq	0xc8(%rsp), %rax
    2567: 73 11                        	jae	0x257a <trusted_x86_x86_sim_xdp+0x257a>
    2569: 89 c2                        	movl	%eax, %edx
    256b: 29 ca                        	subl	%ecx, %edx
    256d: 48 89 94 24 b0 00 00 00      	movq	%rdx, 0xb0(%rsp)
    2575: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    257a: 0f b7 84 24 e8 00 00 00      	movzwl	0xe8(%rsp), %eax
    2582: 48 01 c8                     	addq	%rcx, %rax
    2585: 48 39 44 24 30               	cmpq	%rax, 0x30(%rsp)
    258a: 0f 83 2d 01 00 00            	jae	0x26bd <trusted_x86_x86_sim_xdp+0x26bd>
    2590: 48 83 c0 fc                  	addq	$-0x4, %rax
    2594: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    259a: 83 c9 03                     	orl	$0x3, %ecx
    259d: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    25a1: 48 39 44 24 30               	cmpq	%rax, 0x30(%rsp)
    25a6: 0f 83 5c 01 00 00            	jae	0x2708 <trusted_x86_x86_sim_xdp+0x2708>
    25ac: c7 84 24 e0 00 00 00 08 00 00 00     	movl	$0x8, 0xe0(%rsp)
    25b7: b8 08 00 00 00               	movl	$0x8, %eax
    25bc: e9 61 01 00 00               	jmp	0x2722 <trusted_x86_x86_sim_xdp+0x2722>
    25c1: 41 81 fc 49 6e 74 65         	cmpl	$0x65746e49, %r12d      # imm = 0x65746E49
    25c8: 0f 85 d5 00 00 00            	jne	0x26a3 <trusted_x86_x86_sim_xdp+0x26a3>
    25ce: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    25d3: 48 3b 44 24 10               	cmpq	0x10(%rsp), %rax
    25d8: 0f 82 78 0a 00 00            	jb	0x3056 <trusted_x86_x86_sim_xdp+0x3056>
    25de: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    25e3: 48 03 44 24 10               	addq	0x10(%rsp), %rax
    25e8: 48 39 44 24 38               	cmpq	%rax, 0x38(%rsp)
    25ed: 0f 83 63 0a 00 00            	jae	0x3056 <trusted_x86_x86_sim_xdp+0x3056>
    25f3: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
    25f8: 48 83 c6 b0                  	addq	$-0x50, %rsi
    25fc: ba 60 00 00 00               	movl	$0x60, %edx
    2601: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2606: e8 00 00 00 00               	callq	0x260b <trusted_x86_x86_sim_xdp+0x260b>
		0000000000002607:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    260b: 85 c0                        	testl	%eax, %eax
    260d: 79 64                        	jns	0x2673 <trusted_x86_x86_sim_xdp+0x2673>
    260f: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
    2614: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    261c: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    2624: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    262c: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    2634: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    263c: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    2644: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    264c: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    2654: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    265c: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    2664: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    266c: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    2673: 85 c0                        	testl	%eax, %eax
    2675: 0f 85 db 09 00 00            	jne	0x3056 <trusted_x86_x86_sim_xdp+0x3056>
    267b: 4c 89 f8                     	movq	%r15, %rax
    267e: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    2685: 0f 84 4f 09 00 00            	je	0x2fda <trusted_x86_x86_sim_xdp+0x2fda>
    268b: 48 8b 04 24                  	movq	(%rsp), %rax
    268f: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    2693: 0f 84 4d 09 00 00            	je	0x2fe6 <trusted_x86_x86_sim_xdp+0x2fe6>
    2699: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    269e: e9 48 09 00 00               	jmp	0x2feb <trusted_x86_x86_sim_xdp+0x2feb>
    26a3: 8b 84 24 e0 00 00 00         	movl	0xe0(%rsp), %eax
    26aa: c7 44 24 28 00 00 00 00      	movl	$0x0, 0x28(%rsp)
    26b2: 85 c0                        	testl	%eax, %eax
    26b4: 75 6c                        	jne	0x2722 <trusted_x86_x86_sim_xdp+0x2722>
    26b6: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    26bb: eb 50                        	jmp	0x270d <trusted_x86_x86_sim_xdp+0x270d>
    26bd: 8b 84 24 e0 00 00 00         	movl	0xe0(%rsp), %eax
    26c4: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    26c9: 48 8b 54 24 38               	movq	0x38(%rsp), %rdx
    26ce: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    26d2: 48 83 c6 30                  	addq	$0x30, %rsi
    26d6: 48 89 74 24 40               	movq	%rsi, 0x40(%rsp)
    26db: 48 39 ca                     	cmpq	%rcx, %rdx
    26de: 0f 82 6f 02 00 00            	jb	0x2953 <trusted_x86_x86_sim_xdp+0x2953>
    26e4: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    26ea: 83 c9 03                     	orl	$0x3, %ecx
    26ed: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    26f1: 48 8b 4c 24 38               	movq	0x38(%rsp), %rcx
    26f6: 48 3b 4c 24 40               	cmpq	0x40(%rsp), %rcx
    26fb: 0f 83 4d 02 00 00            	jae	0x294e <trusted_x86_x86_sim_xdp+0x294e>
    2701: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    2706: eb 05                        	jmp	0x270d <trusted_x86_x86_sim_xdp+0x270d>
    2708: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    270d: c7 84 24 e0 00 00 00 10 00 00 00     	movl	$0x10, 0xe0(%rsp)
    2718: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    271d: b8 10 00 00 00               	movl	$0x10, %eax
    2722: 89 c6                        	movl	%eax, %esi
    2724: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    2729: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    272e: 48 83 c6 f0                  	addq	$-0x10, %rsi
    2732: ba 10 00 00 00               	movl	$0x10, %edx
    2737: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    273c: e8 00 00 00 00               	callq	0x2741 <trusted_x86_x86_sim_xdp+0x2741>
		000000000000273d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2741: 85 c0                        	testl	%eax, %eax
    2743: 79 14                        	jns	0x2759 <trusted_x86_x86_sim_xdp+0x2759>
    2745: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    274a: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    2752: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    2759: 83 bc 24 e0 00 00 00 10      	cmpl	$0x10, 0xe0(%rsp)
    2761: 72 0a                        	jb	0x276d <trusted_x86_x86_sim_xdp+0x276d>
    2763: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2768: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    276d: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    2772: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    2777: 4c 89 f8                     	movq	%r15, %rax
    277a: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    2780: 83 f9 7e                     	cmpl	$0x7e, %ecx
    2783: 0f 87 77 e2 ff ff            	ja	0xa00 <trusted_x86_x86_sim_xdp+0xa00>
    2789: 4c 89 f8                     	movq	%r15, %rax
    278c: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    2793: 8b 54 24 28                  	movl	0x28(%rsp), %edx
    2797: 48 8b b4 24 b0 00 00 00      	movq	0xb0(%rsp), %rsi
    279f: 8d 79 01                     	leal	0x1(%rcx), %edi
    27a2: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    27aa: 41 89 38                     	movl	%edi, (%r8)
    27ad: c1 e1 03                     	shll	$0x3, %ecx
    27b0: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    27b3: 48 8b bc 24 a0 01 00 00      	movq	0x1a0(%rsp), %rdi
    27bb: 48 01 cf                     	addq	%rcx, %rdi
    27be: 4c 89 37                     	movq	%r14, (%rdi)
    27c1: 48 c1 e6 20                  	shlq	$0x20, %rsi
    27c5: 44 89 e7                     	movl	%r12d, %edi
    27c8: 48 09 f7                     	orq	%rsi, %rdi
    27cb: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    27cf: 48 09 d7                     	orq	%rdx, %rdi
    27d2: 48 8b 94 24 98 01 00 00      	movq	0x198(%rsp), %rdx
    27da: 48 01 ca                     	addq	%rcx, %rdx
    27dd: 48 89 3a                     	movq	%rdi, (%rdx)
    27e0: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    27e8: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    27ec: c6 02 05                     	movb	$0x5, (%rdx)
    27ef: 48 8b 94 24 40 01 00 00      	movq	0x140(%rsp), %rdx
    27f7: 48 01 ca                     	addq	%rcx, %rdx
    27fa: 88 02                        	movb	%al, (%rdx)
    27fc: 48 8b 84 24 a8 01 00 00      	movq	0x1a8(%rsp), %rax
    2804: 48 01 c8                     	addq	%rcx, %rax
    2807: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    280d: 48 03 8c 24 90 01 00 00      	addq	0x190(%rsp), %rcx
    2815: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    281a: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    281f: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    2827: 48 89 01                     	movq	%rax, (%rcx)
    282a: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    282f: 48 8b 8c 24 68 01 00 00      	movq	0x168(%rsp), %rcx
    2837: 48 89 01                     	movq	%rax, (%rcx)
    283a: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    283f: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    2847: 48 89 01                     	movq	%rax, (%rcx)
    284a: 48 8b 84 24 60 01 00 00      	movq	0x160(%rsp), %rax
    2852: c6 00 01                     	movb	$0x1, (%rax)
    2855: c7 44 24 48 2a 00 00 00      	movl	$0x2a, 0x48(%rsp)
    285d: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2864 <trusted_x86_x86_sim_xdp+0x2864>
		0000000000002860:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2864: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    2869: e8 00 00 00 00               	callq	0x286e <trusted_x86_x86_sim_xdp+0x286e>
		000000000000286a:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    286e: 48 85 c0                     	testq	%rax, %rax
    2871: 74 0c                        	je	0x287f <trusted_x86_x86_sim_xdp+0x287f>
    2873: 48 89 c1                     	movq	%rax, %rcx
    2876: 48 8b 09                     	movq	(%rcx), %rcx
    2879: 48 ff c1                     	incq	%rcx
    287c: 48 89 08                     	movq	%rcx, (%rax)
    287f: 4c 89 f8                     	movq	%r15, %rax
    2882: 4c 8b a0 d0 0e 00 00         	movq	0xed0(%rax), %r12
    2889: 4d 85 e4                     	testq	%r12, %r12
    288c: 0f 84 f4 11 00 00            	je	0x3a86 <trusted_x86_x86_sim_xdp+0x3a86>
    2892: 4c 3b a4 24 88 01 00 00      	cmpq	0x188(%rsp), %r12
    289a: 0f 83 01 e7 ff ff            	jae	0xfa1 <trusted_x86_x86_sim_xdp+0xfa1>
    28a0: 49 81 fc 00 10 00 00         	cmpq	$0x1000, %r12           # imm = 0x1000
    28a7: 0f 82 15 e7 ff ff            	jb	0xfc2 <trusted_x86_x86_sim_xdp+0xfc2>
    28ad: 4c 89 f8                     	movq	%r15, %rax
    28b0: 8b 00                        	movl	(%rax), %eax
    28b2: c7 44 24 48 60 00 00 00      	movl	$0x60, 0x48(%rsp)
    28ba: 0f 38 f1 44 24 4c            	movbel	%eax, 0x4c(%rsp)
    28c0: 4c 0f 38 f1 64 24 50         	movbeq	%r12, 0x50(%rsp)
    28c7: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    28cc: e8 00 00 00 00               	callq	0x28d1 <trusted_x86_x86_sim_xdp+0x28d1>
		00000000000028cd:  R_X86_64_PLT32	.text+0x5c
    28d1: 48 85 c0                     	testq	%rax, %rax
    28d4: 0f 84 c4 11 00 00            	je	0x3a9e <trusted_x86_x86_sim_xdp+0x3a9e>
    28da: 48 89 c1                     	movq	%rax, %rcx
    28dd: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    28e1: 48 89 e9                     	movq	%rbp, %rcx
    28e4: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    28ee: 48 21 d1                     	andq	%rdx, %rcx
    28f1: 48 8b 94 24 58 01 00 00      	movq	0x158(%rsp), %rdx
    28f9: 48 89 0a                     	movq	%rcx, (%rdx)
    28fc: 48 8b 00                     	movq	(%rax), %rax
    28ff: 48 8b 94 24 50 01 00 00      	movq	0x150(%rsp), %rdx
    2907: 48 89 02                     	movq	%rax, (%rdx)
    290a: 48 c1 ed 38                  	shrq	$0x38, %rbp
    290e: 49 29 cc                     	subq	%rcx, %r12
    2911: 48 8b 8c 24 48 01 00 00      	movq	0x148(%rsp), %rcx
    2919: 4c 89 21                     	movq	%r12, (%rcx)
    291c: 48 83 fd 01                  	cmpq	$0x1, %rbp
    2920: 0f 85 6c 03 00 00            	jne	0x2c92 <trusted_x86_x86_sim_xdp+0x2c92>
    2926: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    292b: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2932 <trusted_x86_x86_sim_xdp+0x2932>
		000000000000292e:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    2932: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2937: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x293e <trusted_x86_x86_sim_xdp+0x293e>
		000000000000293a:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    293e: 0f 85 a1 02 00 00            	jne	0x2be5 <trusted_x86_x86_sim_xdp+0x2be5>
    2944: e8 00 00 00 00               	callq	0x2949 <trusted_x86_x86_sim_xdp+0x2949>
		0000000000002945:  R_X86_64_PLT32	.text+0x5c
    2949: e9 9c 02 00 00               	jmp	0x2bea <trusted_x86_x86_sim_xdp+0x2bea>
    294e: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    2953: 48 8d 14 01                  	leaq	(%rcx,%rax), %rdx
    2957: 48 89 54 24 28               	movq	%rdx, 0x28(%rsp)
    295c: 48 8d 34 01                  	leaq	(%rcx,%rax), %rsi
    2960: 48 83 c6 f8                  	addq	$-0x8, %rsi
    2964: ba 30 00 00 00               	movl	$0x30, %edx
    2969: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    296e: e8 00 00 00 00               	callq	0x2973 <trusted_x86_x86_sim_xdp+0x2973>
		000000000000296f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2973: 85 c0                        	testl	%eax, %eax
    2975: 79 34                        	jns	0x29ab <trusted_x86_x86_sim_xdp+0x29ab>
    2977: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    297c: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    2984: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    298c: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    2994: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    299c: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    29a4: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    29ab: 48 bd 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %rbp # imm = 0xFF00000000000000
    29b5: 4c 89 f8                     	movq	%r15, %rax
    29b8: 8b 00                        	movl	(%rax), %eax
    29ba: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    29c2: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    29c8: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    29cd: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    29d2: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    29d9: e8 00 00 00 00               	callq	0x29de <trusted_x86_x86_sim_xdp+0x29de>
		00000000000029da:  R_X86_64_PLT32	.text+0x5c
    29de: 48 85 c0                     	testq	%rax, %rax
    29e1: 74 20                        	je	0x2a03 <trusted_x86_x86_sim_xdp+0x2a03>
    29e3: 48 8b 40 08                  	movq	0x8(%rax), %rax
    29e7: 48 21 e8                     	andq	%rbp, %rax
    29ea: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    29f4: 48 39 c8                     	cmpq	%rcx, %rax
    29f7: 75 0a                        	jne	0x2a03 <trusted_x86_x86_sim_xdp+0x2a03>
    29f9: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    29fe: e9 8f 01 00 00               	jmp	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2a03: 4c 89 f8                     	movq	%r15, %rax
    2a06: 8b 00                        	movl	(%rax), %eax
    2a08: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    2a10: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    2a16: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    2a1b: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    2a22: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2a27: e8 00 00 00 00               	callq	0x2a2c <trusted_x86_x86_sim_xdp+0x2a2c>
		0000000000002a28:  R_X86_64_PLT32	.text+0x5c
    2a2c: 48 85 c0                     	testq	%rax, %rax
    2a2f: 74 24                        	je	0x2a55 <trusted_x86_x86_sim_xdp+0x2a55>
    2a31: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2a35: 48 21 e8                     	andq	%rbp, %rax
    2a38: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2a42: 48 39 c8                     	cmpq	%rcx, %rax
    2a45: 75 0e                        	jne	0x2a55 <trusted_x86_x86_sim_xdp+0x2a55>
    2a47: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    2a4c: 48 83 c0 08                  	addq	$0x8, %rax
    2a50: e9 3d 01 00 00               	jmp	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2a55: 4c 89 f8                     	movq	%r15, %rax
    2a58: 8b 00                        	movl	(%rax), %eax
    2a5a: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    2a62: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    2a68: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    2a6d: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    2a74: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2a79: e8 00 00 00 00               	callq	0x2a7e <trusted_x86_x86_sim_xdp+0x2a7e>
		0000000000002a7a:  R_X86_64_PLT32	.text+0x5c
    2a7e: 48 85 c0                     	testq	%rax, %rax
    2a81: 74 24                        	je	0x2aa7 <trusted_x86_x86_sim_xdp+0x2aa7>
    2a83: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2a87: 48 21 e8                     	andq	%rbp, %rax
    2a8a: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2a94: 48 39 c8                     	cmpq	%rcx, %rax
    2a97: 75 0e                        	jne	0x2aa7 <trusted_x86_x86_sim_xdp+0x2aa7>
    2a99: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    2a9e: 48 83 c0 10                  	addq	$0x10, %rax
    2aa2: e9 eb 00 00 00               	jmp	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2aa7: 4c 89 f8                     	movq	%r15, %rax
    2aaa: 8b 00                        	movl	(%rax), %eax
    2aac: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    2ab4: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    2aba: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    2abf: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    2ac6: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2acb: e8 00 00 00 00               	callq	0x2ad0 <trusted_x86_x86_sim_xdp+0x2ad0>
		0000000000002acc:  R_X86_64_PLT32	.text+0x5c
    2ad0: 48 85 c0                     	testq	%rax, %rax
    2ad3: 74 24                        	je	0x2af9 <trusted_x86_x86_sim_xdp+0x2af9>
    2ad5: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2ad9: 48 21 e8                     	andq	%rbp, %rax
    2adc: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2ae6: 48 39 c8                     	cmpq	%rcx, %rax
    2ae9: 75 0e                        	jne	0x2af9 <trusted_x86_x86_sim_xdp+0x2af9>
    2aeb: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    2af0: 48 83 c0 18                  	addq	$0x18, %rax
    2af4: e9 99 00 00 00               	jmp	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2af9: 4c 89 f8                     	movq	%r15, %rax
    2afc: 8b 00                        	movl	(%rax), %eax
    2afe: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    2b06: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    2b0c: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    2b11: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    2b18: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2b1d: e8 00 00 00 00               	callq	0x2b22 <trusted_x86_x86_sim_xdp+0x2b22>
		0000000000002b1e:  R_X86_64_PLT32	.text+0x5c
    2b22: 48 85 c0                     	testq	%rax, %rax
    2b25: 74 21                        	je	0x2b48 <trusted_x86_x86_sim_xdp+0x2b48>
    2b27: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2b2b: 48 21 e8                     	andq	%rbp, %rax
    2b2e: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    2b38: 48 39 c8                     	cmpq	%rcx, %rax
    2b3b: 75 0b                        	jne	0x2b48 <trusted_x86_x86_sim_xdp+0x2b48>
    2b3d: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    2b42: 48 83 c0 20                  	addq	$0x20, %rax
    2b46: eb 4a                        	jmp	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2b48: 4c 89 f8                     	movq	%r15, %rax
    2b4b: 8b 00                        	movl	(%rax), %eax
    2b4d: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    2b55: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    2b5b: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    2b60: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    2b67: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    2b6c: e8 00 00 00 00               	callq	0x2b71 <trusted_x86_x86_sim_xdp+0x2b71>
		0000000000002b6d:  R_X86_64_PLT32	.text+0x5c
    2b71: 48 85 c0                     	testq	%rax, %rax
    2b74: 74 3f                        	je	0x2bb5 <trusted_x86_x86_sim_xdp+0x2bb5>
    2b76: 48 23 68 08                  	andq	0x8(%rax), %rbp
    2b7a: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    2b84: 48 39 c5                     	cmpq	%rax, %rbp
    2b87: 75 2c                        	jne	0x2bb5 <trusted_x86_x86_sim_xdp+0x2bb5>
    2b89: 48 8b 44 24 28               	movq	0x28(%rsp), %rax
    2b8e: 48 83 c0 28                  	addq	$0x28, %rax
    2b92: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    2b97: 89 c1                        	movl	%eax, %ecx
    2b99: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    2b9f: 83 c9 03                     	orl	$0x3, %ecx
    2ba2: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    2ba6: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2bab: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    2bb0: e9 79 fb ff ff               	jmp	0x272e <trusted_x86_x86_sim_xdp+0x272e>
    2bb5: c7 44 24 18 2e 00 00 00      	movl	$0x2e, 0x18(%rsp)
    2bbd: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2bc4 <trusted_x86_x86_sim_xdp+0x2bc4>
		0000000000002bc0:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2bc4: 48 8d 74 24 18               	leaq	0x18(%rsp), %rsi
    2bc9: e8 00 00 00 00               	callq	0x2bce <trusted_x86_x86_sim_xdp+0x2bce>
		0000000000002bca:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2bce: 48 85 c0                     	testq	%rax, %rax
    2bd1: 0f 84 0a f2 ff ff            	je	0x1de1 <trusted_x86_x86_sim_xdp+0x1de1>
    2bd7: 48 89 c1                     	movq	%rax, %rcx
    2bda: 48 8b 09                     	movq	(%rcx), %rcx
    2bdd: 48 ff c1                     	incq	%rcx
    2be0: e9 f9 f1 ff ff               	jmp	0x1dde <trusted_x86_x86_sim_xdp+0x1dde>
    2be5: e8 00 00 00 00               	callq	0x2bea <trusted_x86_x86_sim_xdp+0x2bea>
		0000000000002be6:  R_X86_64_PLT32	.text+0x10c
    2bea: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2bef: 45 31 f6                     	xorl	%r14d, %r14d
    2bf2: bd 01 00 00 00               	movl	$0x1, %ebp
    2bf7: 48 85 c0                     	testq	%rax, %rax
    2bfa: 0f 84 97 d5 ff ff            	je	0x197 <trusted_x86_x86_sim_xdp+0x197>
    2c00: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2c05: 48 8b 00                     	movq	(%rax), %rax
    2c08: 4c 39 e0                     	cmpq	%r12, %rax
    2c0b: 77 0e                        	ja	0x2c1b <trusted_x86_x86_sim_xdp+0x2c1b>
    2c0d: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2c12: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2c16: 4c 39 e0                     	cmpq	%r12, %rax
    2c19: 73 24                        	jae	0x2c3f <trusted_x86_x86_sim_xdp+0x2c3f>
    2c1b: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2c20: 48 8b 40 10                  	movq	0x10(%rax), %rax
    2c24: 4c 39 e0                     	cmpq	%r12, %rax
    2c27: 0f 87 6a d5 ff ff            	ja	0x197 <trusted_x86_x86_sim_xdp+0x197>
    2c2d: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2c32: 48 8b 40 18                  	movq	0x18(%rax), %rax
    2c36: 4c 39 e0                     	cmpq	%r12, %rax
    2c39: 0f 82 58 d5 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    2c3f: 4c 89 f8                     	movq	%r15, %rax
    2c42: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    2c48: 48 8b 4c 24 10               	movq	0x10(%rsp), %rcx
    2c4d: 8b 49 20                     	movl	0x20(%rcx), %ecx
    2c50: 0f a3 c8                     	btl	%ecx, %eax
    2c53: 0f 82 3e d5 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    2c59: 48 8d b4 24 b8 00 00 00      	leaq	0xb8(%rsp), %rsi
    2c61: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
    2c6c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2c73 <trusted_x86_x86_sim_xdp+0x2c73>
		0000000000002c6f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2c73: e8 00 00 00 00               	callq	0x2c78 <trusted_x86_x86_sim_xdp+0x2c78>
		0000000000002c74:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2c78: 48 85 c0                     	testq	%rax, %rax
    2c7b: 74 0c                        	je	0x2c89 <trusted_x86_x86_sim_xdp+0x2c89>
    2c7d: 48 89 c1                     	movq	%rax, %rcx
    2c80: 48 8b 09                     	movq	(%rcx), %rcx
    2c83: 48 ff c1                     	incq	%rcx
    2c86: 48 89 08                     	movq	%rcx, (%rax)
    2c89: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    2c8e: 0f b7 68 20                  	movzwl	0x20(%rax), %ebp
    2c92: 45 31 f6                     	xorl	%r14d, %r14d
    2c95: 83 fd 02                     	cmpl	$0x2, %ebp
    2c98: 0f 85 f9 d4 ff ff            	jne	0x197 <trusted_x86_x86_sim_xdp+0x197>
    2c9e: c7 44 24 48 29 00 00 00      	movl	$0x29, 0x48(%rsp)
    2ca6: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2cad <trusted_x86_x86_sim_xdp+0x2cad>
		0000000000002ca9:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2cad: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    2cb2: e8 00 00 00 00               	callq	0x2cb7 <trusted_x86_x86_sim_xdp+0x2cb7>
		0000000000002cb3:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2cb7: 48 85 c0                     	testq	%rax, %rax
    2cba: 74 0c                        	je	0x2cc8 <trusted_x86_x86_sim_xdp+0x2cc8>
    2cbc: 48 89 c1                     	movq	%rax, %rcx
    2cbf: 48 8b 09                     	movq	(%rcx), %rcx
    2cc2: 48 ff c1                     	incq	%rcx
    2cc5: 48 89 08                     	movq	%rcx, (%rax)
    2cc8: 4c 89 f8                     	movq	%r15, %rax
    2ccb: 48 8b 80 d0 0e 00 00         	movq	0xed0(%rax), %rax
    2cd2: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    2cd7: 4c 89 f8                     	movq	%r15, %rax
    2cda: 48 8b 80 d8 0e 00 00         	movq	0xed8(%rax), %rax
    2ce1: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    2ce6: 48 8b 04 24                  	movq	(%rsp), %rax
    2cea: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    2cee: 4c 89 f9                     	movq	%r15, %rcx
    2cf1: 48 8b 89 e0 0e 00 00         	movq	0xee0(%rcx), %rcx
    2cf8: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    2cfd: 4c 89 f9                     	movq	%r15, %rcx
    2d00: c4 62 fb f7 b1 18 0f 00 00   	shrxq	%rax, 0xf18(%rcx), %r14
    2d09: 4c 89 f8                     	movq	%r15, %rax
    2d0c: 48 8b a8 10 0f 00 00         	movq	0xf10(%rax), %rbp
    2d13: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    2d1d: 48 21 c5                     	andq	%rax, %rbp
    2d20: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2d24: ba 01 00 00 00               	movl	$0x1, %edx
    2d29: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2d2e: e8 00 00 00 00               	callq	0x2d33 <trusted_x86_x86_sim_xdp+0x2d33>
		0000000000002d2f:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2d33: 85 c0                        	testl	%eax, %eax
    2d35: 79 05                        	jns	0x2d3c <trusted_x86_x86_sim_xdp+0x2d3c>
    2d37: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2d3c: 85 c0                        	testl	%eax, %eax
    2d3e: 0f 85 15 d4 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2d44: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2d49: 8d 48 01                     	leal	0x1(%rax), %ecx
    2d4c: f6 c1 fe                     	testb	$-0x2, %cl
    2d4f: 0f 84 3d 03 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2d55: 89 c0                        	movl	%eax, %eax
    2d57: 49 29 c6                     	subq	%rax, %r14
    2d5a: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2d5e: ba 01 00 00 00               	movl	$0x1, %edx
    2d63: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2d68: e8 00 00 00 00               	callq	0x2d6d <trusted_x86_x86_sim_xdp+0x2d6d>
		0000000000002d69:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2d6d: 85 c0                        	testl	%eax, %eax
    2d6f: 79 05                        	jns	0x2d76 <trusted_x86_x86_sim_xdp+0x2d76>
    2d71: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2d76: 85 c0                        	testl	%eax, %eax
    2d78: 0f 85 db d3 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2d7e: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2d83: 8d 48 01                     	leal	0x1(%rax), %ecx
    2d86: f6 c1 fe                     	testb	$-0x2, %cl
    2d89: 0f 84 03 03 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2d8f: 89 c0                        	movl	%eax, %eax
    2d91: 49 29 c6                     	subq	%rax, %r14
    2d94: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2d98: ba 01 00 00 00               	movl	$0x1, %edx
    2d9d: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2da2: e8 00 00 00 00               	callq	0x2da7 <trusted_x86_x86_sim_xdp+0x2da7>
		0000000000002da3:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2da7: 85 c0                        	testl	%eax, %eax
    2da9: 79 05                        	jns	0x2db0 <trusted_x86_x86_sim_xdp+0x2db0>
    2dab: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2db0: 85 c0                        	testl	%eax, %eax
    2db2: 0f 85 a1 d3 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2db8: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2dbd: 8d 48 01                     	leal	0x1(%rax), %ecx
    2dc0: f6 c1 fe                     	testb	$-0x2, %cl
    2dc3: 0f 84 c9 02 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2dc9: 89 c0                        	movl	%eax, %eax
    2dcb: 49 29 c6                     	subq	%rax, %r14
    2dce: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2dd2: ba 01 00 00 00               	movl	$0x1, %edx
    2dd7: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2ddc: e8 00 00 00 00               	callq	0x2de1 <trusted_x86_x86_sim_xdp+0x2de1>
		0000000000002ddd:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2de1: 85 c0                        	testl	%eax, %eax
    2de3: 79 05                        	jns	0x2dea <trusted_x86_x86_sim_xdp+0x2dea>
    2de5: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2dea: 85 c0                        	testl	%eax, %eax
    2dec: 0f 85 67 d3 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2df2: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2df7: 8d 48 01                     	leal	0x1(%rax), %ecx
    2dfa: f6 c1 fe                     	testb	$-0x2, %cl
    2dfd: 0f 84 8f 02 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2e03: 89 c0                        	movl	%eax, %eax
    2e05: 49 29 c6                     	subq	%rax, %r14
    2e08: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2e0c: ba 01 00 00 00               	movl	$0x1, %edx
    2e11: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2e16: e8 00 00 00 00               	callq	0x2e1b <trusted_x86_x86_sim_xdp+0x2e1b>
		0000000000002e17:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2e1b: 85 c0                        	testl	%eax, %eax
    2e1d: 79 05                        	jns	0x2e24 <trusted_x86_x86_sim_xdp+0x2e24>
    2e1f: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2e24: 85 c0                        	testl	%eax, %eax
    2e26: 0f 85 2d d3 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2e2c: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2e31: 8d 48 01                     	leal	0x1(%rax), %ecx
    2e34: f6 c1 fe                     	testb	$-0x2, %cl
    2e37: 0f 84 55 02 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2e3d: 89 c0                        	movl	%eax, %eax
    2e3f: 49 29 c6                     	subq	%rax, %r14
    2e42: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2e46: ba 01 00 00 00               	movl	$0x1, %edx
    2e4b: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2e50: e8 00 00 00 00               	callq	0x2e55 <trusted_x86_x86_sim_xdp+0x2e55>
		0000000000002e51:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2e55: 85 c0                        	testl	%eax, %eax
    2e57: 79 05                        	jns	0x2e5e <trusted_x86_x86_sim_xdp+0x2e5e>
    2e59: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2e5e: 85 c0                        	testl	%eax, %eax
    2e60: 0f 85 f3 d2 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2e66: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2e6b: 8d 48 01                     	leal	0x1(%rax), %ecx
    2e6e: f6 c1 fe                     	testb	$-0x2, %cl
    2e71: 0f 84 1b 02 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2e77: 89 c0                        	movl	%eax, %eax
    2e79: 49 29 c6                     	subq	%rax, %r14
    2e7c: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2e80: ba 01 00 00 00               	movl	$0x1, %edx
    2e85: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2e8a: e8 00 00 00 00               	callq	0x2e8f <trusted_x86_x86_sim_xdp+0x2e8f>
		0000000000002e8b:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2e8f: 85 c0                        	testl	%eax, %eax
    2e91: 79 05                        	jns	0x2e98 <trusted_x86_x86_sim_xdp+0x2e98>
    2e93: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2e98: 85 c0                        	testl	%eax, %eax
    2e9a: 0f 85 b9 d2 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2ea0: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2ea5: 8d 48 01                     	leal	0x1(%rax), %ecx
    2ea8: f6 c1 fe                     	testb	$-0x2, %cl
    2eab: 0f 84 e1 01 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2eb1: 89 c0                        	movl	%eax, %eax
    2eb3: 49 29 c6                     	subq	%rax, %r14
    2eb6: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2eba: ba 01 00 00 00               	movl	$0x1, %edx
    2ebf: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2ec4: e8 00 00 00 00               	callq	0x2ec9 <trusted_x86_x86_sim_xdp+0x2ec9>
		0000000000002ec5:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2ec9: 85 c0                        	testl	%eax, %eax
    2ecb: 79 05                        	jns	0x2ed2 <trusted_x86_x86_sim_xdp+0x2ed2>
    2ecd: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2ed2: 85 c0                        	testl	%eax, %eax
    2ed4: 0f 85 7f d2 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2eda: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2edf: 8d 48 01                     	leal	0x1(%rax), %ecx
    2ee2: f6 c1 fe                     	testb	$-0x2, %cl
    2ee5: 0f 84 a7 01 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2eeb: 89 c0                        	movl	%eax, %eax
    2eed: 49 29 c6                     	subq	%rax, %r14
    2ef0: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2ef4: ba 01 00 00 00               	movl	$0x1, %edx
    2ef9: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2efe: e8 00 00 00 00               	callq	0x2f03 <trusted_x86_x86_sim_xdp+0x2f03>
		0000000000002eff:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2f03: 85 c0                        	testl	%eax, %eax
    2f05: 79 05                        	jns	0x2f0c <trusted_x86_x86_sim_xdp+0x2f0c>
    2f07: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2f0c: 85 c0                        	testl	%eax, %eax
    2f0e: 0f 85 45 d2 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2f14: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2f19: 8d 48 01                     	leal	0x1(%rax), %ecx
    2f1c: f6 c1 fe                     	testb	$-0x2, %cl
    2f1f: 0f 84 6d 01 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2f25: 89 c0                        	movl	%eax, %eax
    2f27: 49 29 c6                     	subq	%rax, %r14
    2f2a: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2f2e: ba 01 00 00 00               	movl	$0x1, %edx
    2f33: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2f38: e8 00 00 00 00               	callq	0x2f3d <trusted_x86_x86_sim_xdp+0x2f3d>
		0000000000002f39:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2f3d: 85 c0                        	testl	%eax, %eax
    2f3f: 79 05                        	jns	0x2f46 <trusted_x86_x86_sim_xdp+0x2f46>
    2f41: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2f46: 85 c0                        	testl	%eax, %eax
    2f48: 0f 85 0b d2 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2f4e: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2f53: 8d 48 01                     	leal	0x1(%rax), %ecx
    2f56: f6 c1 fe                     	testb	$-0x2, %cl
    2f59: 0f 84 33 01 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2f5f: 89 c0                        	movl	%eax, %eax
    2f61: 49 29 c6                     	subq	%rax, %r14
    2f64: 49 8d 34 2e                  	leaq	(%r14,%rbp), %rsi
    2f68: ba 01 00 00 00               	movl	$0x1, %edx
    2f6d: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2f72: e8 00 00 00 00               	callq	0x2f77 <trusted_x86_x86_sim_xdp+0x2f77>
		0000000000002f73:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2f77: 85 c0                        	testl	%eax, %eax
    2f79: 79 05                        	jns	0x2f80 <trusted_x86_x86_sim_xdp+0x2f80>
    2f7b: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2f80: 85 c0                        	testl	%eax, %eax
    2f82: 0f 85 d1 d1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2f88: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2f8d: 8d 48 01                     	leal	0x1(%rax), %ecx
    2f90: f6 c1 fe                     	testb	$-0x2, %cl
    2f93: 0f 84 f9 00 00 00            	je	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2f99: 89 c0                        	movl	%eax, %eax
    2f9b: 49 29 c6                     	subq	%rax, %r14
    2f9e: 4c 01 f5                     	addq	%r14, %rbp
    2fa1: ba 01 00 00 00               	movl	$0x1, %edx
    2fa6: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    2fab: 48 89 ee                     	movq	%rbp, %rsi
    2fae: e8 00 00 00 00               	callq	0x2fb3 <trusted_x86_x86_sim_xdp+0x2fb3>
		0000000000002faf:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2fb3: 85 c0                        	testl	%eax, %eax
    2fb5: 79 05                        	jns	0x2fbc <trusted_x86_x86_sim_xdp+0x2fbc>
    2fb7: c6 44 24 48 00               	movb	$0x0, 0x48(%rsp)
    2fbc: 85 c0                        	testl	%eax, %eax
    2fbe: 0f 85 95 d1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2fc4: 0f b6 44 24 48               	movzbl	0x48(%rsp), %eax
    2fc9: 8d 48 01                     	leal	0x1(%rax), %ecx
    2fcc: f6 c1 fe                     	testb	$-0x2, %cl
    2fcf: 0f 85 84 d1 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    2fd5: e9 b8 00 00 00               	jmp	0x3092 <trusted_x86_x86_sim_xdp+0x3092>
    2fda: 4c 89 f8                     	movq	%r15, %rax
    2fdd: 48 8b 80 00 0f 00 00         	movq	0xf00(%rax), %rax
    2fe4: eb 05                        	jmp	0x2feb <trusted_x86_x86_sim_xdp+0x2feb>
    2fe6: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    2feb: 48 89 84 24 00 01 00 00      	movq	%rax, 0x100(%rsp)
    2ff3: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    2ffb: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
    3003: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
    3008: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    3010: 48 89 4c 24 38               	movq	%rcx, 0x38(%rsp)
    3015: 48 8b 8c 24 a0 00 00 00      	movq	0xa0(%rsp), %rcx
    301d: 48 89 4c 24 30               	movq	%rcx, 0x30(%rsp)
    3022: 48 8b 0c 24                  	movq	(%rsp), %rcx
    3026: 0f b6 71 1c                  	movzbl	0x1c(%rcx), %esi
    302a: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    302f: 48 01 c6                     	addq	%rax, %rsi
    3032: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    3037: ba 08 00 00 00               	movl	$0x8, %edx
    303c: e8 00 00 00 00               	callq	0x3041 <trusted_x86_x86_sim_xdp+0x3041>
		000000000000303d:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3041: 85 c0                        	testl	%eax, %eax
    3043: 79 09                        	jns	0x304e <trusted_x86_x86_sim_xdp+0x304e>
    3045: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
    304e: 85 c0                        	testl	%eax, %eax
    3050: 0f 84 3e 02 00 00            	je	0x3294 <trusted_x86_x86_sim_xdp+0x3294>
    3056: 48 8d b4 24 f4 00 00 00      	leaq	0xf4(%rsp), %rsi
    305e: c7 84 24 f4 00 00 00 2d 00 00 00     	movl	$0x2d, 0xf4(%rsp)
    3069: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3070 <trusted_x86_x86_sim_xdp+0x3070>
		000000000000306c:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3070: e8 00 00 00 00               	callq	0x3075 <trusted_x86_x86_sim_xdp+0x3075>
		0000000000003071:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3075: 41 be e9 03 00 00            	movl	$0x3e9, %r14d           # imm = 0x3E9
    307b: 48 85 c0                     	testq	%rax, %rax
    307e: 0f 84 11 d1 ff ff            	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
    3084: 48 89 c1                     	movq	%rax, %rcx
    3087: 48 8b 09                     	movq	(%rcx), %rcx
    308a: 48 ff c1                     	incq	%rcx
    308d: e9 00 d1 ff ff               	jmp	0x192 <trusted_x86_x86_sim_xdp+0x192>
    3092: 85 c0                        	testl	%eax, %eax
    3094: 0f 85 bf d0 ff ff            	jne	0x159 <trusted_x86_x86_sim_xdp+0x159>
    309a: 48 8b 14 24                  	movq	(%rsp), %rdx
    309e: 48 89 d0                     	movq	%rdx, %rax
    30a1: 0f b6 40 20                  	movzbl	0x20(%rax), %eax
    30a5: c4 c2 f9 f7 c6               	shlxq	%rax, %r14, %rax
    30aa: 4c 89 f9                     	movq	%r15, %rcx
    30ad: 48 03 81 20 0f 00 00         	addq	0xf20(%rcx), %rax
    30b4: 48 89 d1                     	movq	%rdx, %rcx
    30b7: 0f b6 71 1b                  	movzbl	0x1b(%rcx), %esi
    30bb: 48 01 c6                     	addq	%rax, %rsi
    30be: 48 89 b4 24 b8 00 00 00      	movq	%rsi, 0xb8(%rsp)
    30c6: 0f 84 99 d0 ff ff            	je	0x165 <trusted_x86_x86_sim_xdp+0x165>
    30cc: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    30d1: 4c 89 ef                     	movq	%r13, %rdi
    30d4: e8 00 00 00 00               	callq	0x30d9 <trusted_x86_x86_sim_xdp+0x30d9>
		00000000000030d5:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    30d9: 48 89 c5                     	movq	%rax, %rbp
    30dc: 85 ed                        	testl	%ebp, %ebp
    30de: 79 0f                        	jns	0x30ef <trusted_x86_x86_sim_xdp+0x30ef>
    30e0: ba 00 02 00 00               	movl	$0x200, %edx            # imm = 0x200
    30e5: 4c 89 ef                     	movq	%r13, %rdi
    30e8: 31 f6                        	xorl	%esi, %esi
    30ea: e8 00 00 00 00               	callq	0x30ef <trusted_x86_x86_sim_xdp+0x30ef>
		00000000000030eb:  R_X86_64_PLT32	memset-0x4
    30ef: 85 ed                        	testl	%ebp, %ebp
    30f1: 48 8b 04 24                  	movq	(%rsp), %rax
    30f5: 0f 85 9f d4 ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    30fb: 0f b7 40 10                  	movzwl	0x10(%rax), %eax
    30ff: 0f b7 c0                     	movzwl	%ax, %eax
    3102: 3d f8 01 00 00               	cmpl	$0x1f8, %eax            # imm = 0x1F8
    3107: 0f 87 7a 01 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    310d: 48 8b 0c 24                  	movq	(%rsp), %rcx
    3111: 0f b7 49 12                  	movzwl	0x12(%rcx), %ecx
    3115: 0f b7 c9                     	movzwl	%cx, %ecx
    3118: 81 f9 fc 01 00 00            	cmpl	$0x1fc, %ecx            # imm = 0x1FC
    311e: 0f 87 63 01 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    3124: 48 8b 14 24                  	movq	(%rsp), %rdx
    3128: 0f b7 52 14                  	movzwl	0x14(%rdx), %edx
    312c: 0f b7 d2                     	movzwl	%dx, %edx
    312f: 81 fa f8 01 00 00            	cmpl	$0x1f8, %edx            # imm = 0x1F8
    3135: 0f 87 4c 01 00 00            	ja	0x3287 <trusted_x86_x86_sim_xdp+0x3287>
    313b: 48 8b 3c 24                  	movq	(%rsp), %rdi
    313f: 48 89 fe                     	movq	%rdi, %rsi
    3142: 0f b6 76 17                  	movzbl	0x17(%rsi), %esi
    3146: 40 0f b6 f6                  	movzbl	%sil, %esi
    314a: 4c 01 ee                     	addq	%r13, %rsi
    314d: 48 8b 36                     	movq	(%rsi), %rsi
    3150: 48 89 b4 24 c0 00 00 00      	movq	%rsi, 0xc0(%rsp)
    3158: 48 89 fe                     	movq	%rdi, %rsi
    315b: 0f b6 76 18                  	movzbl	0x18(%rsi), %esi
    315f: 40 0f b6 f6                  	movzbl	%sil, %esi
    3163: 4c 01 ee                     	addq	%r13, %rsi
    3166: 48 8b 36                     	movq	(%rsi), %rsi
    3169: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    3171: 48 89 fe                     	movq	%rdi, %rsi
    3174: 0f b6 76 1a                  	movzbl	0x1a(%rsi), %esi
    3178: 40 0f b6 f6                  	movzbl	%sil, %esi
    317c: 4c 01 ee                     	addq	%r13, %rsi
    317f: 8b 36                        	movl	(%rsi), %esi
    3181: c1 e6 03                     	shll	$0x3, %esi
    3184: 89 b4 24 e0 00 00 00         	movl	%esi, 0xe0(%rsp)
    318b: 48 89 fe                     	movq	%rdi, %rsi
    318e: 0f b6 76 19                  	movzbl	0x19(%rsi), %esi
    3192: 40 0f b6 f6                  	movzbl	%sil, %esi
    3196: 4c 01 ee                     	addq	%r13, %rsi
    3199: 0f b7 36                     	movzwl	(%rsi), %esi
    319c: 66 89 b4 24 e8 00 00 00      	movw	%si, 0xe8(%rsp)
    31a4: 4c 01 e9                     	addq	%r13, %rcx
    31a7: 8b 09                        	movl	(%rcx), %ecx
    31a9: 89 8c 24 e4 00 00 00         	movl	%ecx, 0xe4(%rsp)
    31b0: 4c 01 ea                     	addq	%r13, %rdx
    31b3: 8b 0a                        	movl	(%rdx), %ecx
    31b5: 89 8c 24 dc 00 00 00         	movl	%ecx, 0xdc(%rsp)
    31bc: 4c 01 e8                     	addq	%r13, %rax
    31bf: 48 8b 00                     	movq	(%rax), %rax
    31c2: 48 89 84 24 d0 00 00 00      	movq	%rax, 0xd0(%rsp)
    31ca: 48 89 f8                     	movq	%rdi, %rax
    31cd: 0f b6 40 16                  	movzbl	0x16(%rax), %eax
    31d1: 0f b6 c0                     	movzbl	%al, %eax
    31d4: 4c 01 e8                     	addq	%r13, %rax
    31d7: 48 8b 30                     	movq	(%rax), %rsi
    31da: ba 04 00 00 00               	movl	$0x4, %edx
    31df: 48 8d bc 24 d8 00 00 00      	leaq	0xd8(%rsp), %rdi
    31e7: e8 00 00 00 00               	callq	0x31ec <trusted_x86_x86_sim_xdp+0x31ec>
		00000000000031e8:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    31ec: 85 c0                        	testl	%eax, %eax
    31ee: 79 0b                        	jns	0x31fb <trusted_x86_x86_sim_xdp+0x31fb>
    31f0: c7 84 24 d8 00 00 00 00 00 00 00     	movl	$0x0, 0xd8(%rsp)
    31fb: 85 c0                        	testl	%eax, %eax
    31fd: 48 8b 04 24                  	movq	(%rsp), %rax
    3201: 0f 85 93 d3 ff ff            	jne	0x59a <trusted_x86_x86_sim_xdp+0x59a>
    3207: 0f b6 40 21                  	movzbl	0x21(%rax), %eax
    320b: 48 8b 94 24 b8 00 00 00      	movq	0xb8(%rsp), %rdx
    3213: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    321b: 48 89 94 24 b0 00 00 00      	movq	%rdx, 0xb0(%rsp)
    3223: 84 c0                        	testb	%al, %al
    3225: 74 27                        	je	0x324e <trusted_x86_x86_sim_xdp+0x324e>
    3227: 89 c9                        	movl	%ecx, %ecx
    3229: 48 8b 94 24 b0 00 00 00      	movq	0xb0(%rsp), %rdx
    3231: 48 01 d1                     	addq	%rdx, %rcx
    3234: 48 89 8c 24 c0 00 00 00      	movq	%rcx, 0xc0(%rsp)
    323c: 8b b4 24 c8 00 00 00         	movl	0xc8(%rsp), %esi
    3243: 48 01 d6                     	addq	%rdx, %rsi
    3246: 48 89 b4 24 c8 00 00 00      	movq	%rsi, 0xc8(%rsp)
    324e: 44 8b b4 24 d8 00 00 00      	movl	0xd8(%rsp), %r14d
    3256: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
    325b: 89 f7                        	movl	%esi, %edi
    325d: 29 cf                        	subl	%ecx, %edi
    325f: 48 89 7c 24 40               	movq	%rdi, 0x40(%rsp)
    3264: 41 81 fe 6d 61 74 69         	cmpl	$0x6974616d, %r14d      # imm = 0x6974616D
    326b: 7f 7e                        	jg	0x32eb <trusted_x86_x86_sim_xdp+0x32eb>
    326d: 41 81 fe 76 74 61 62         	cmpl	$0x62617476, %r14d      # imm = 0x62617476
    3274: 0f 85 52 01 00 00            	jne	0x33cc <trusted_x86_x86_sim_xdp+0x33cc>
    327a: c7 44 24 28 01 00 00 00      	movl	$0x1, 0x28(%rsp)
    3282: e9 30 01 00 00               	jmp	0x33b7 <trusted_x86_x86_sim_xdp+0x33b7>
    3287: 31 ed                        	xorl	%ebp, %ebp
    3289: 41 be 01 00 00 00            	movl	$0x1, %r14d
    328f: e9 03 cf ff ff               	jmp	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3294: 4c 8b 64 24 18               	movq	0x18(%rsp), %r12
    3299: 48 8b 04 24                  	movq	(%rsp), %rax
    329d: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    32a1: 4c 01 e0                     	addq	%r12, %rax
    32a4: 4c 8b 74 24 40               	movq	0x40(%rsp), %r14
    32a9: 48 8b 8c 24 00 01 00 00      	movq	0x100(%rsp), %rcx
    32b1: 31 d2                        	xorl	%edx, %edx
    32b3: 48 39 c1                     	cmpq	%rax, %rcx
    32b6: 48 0f 43 d0                  	cmovaeq	%rax, %rdx
    32ba: 48 29 d1                     	subq	%rdx, %rcx
    32bd: 48 81 f9 ff ff 00 00         	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    32c4: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    32c9: 48 0f 42 c1                  	cmovbq	%rcx, %rax
    32cd: 48 89 84 24 b0 00 00 00      	movq	%rax, 0xb0(%rsp)
    32d5: 49 c1 ec 03                  	shrq	$0x3, %r12
    32d9: 81 e2 00 ff ff ff            	andl	$0xffffff00, %edx       # imm = 0xFFFFFF00
    32df: 83 ca 02                     	orl	$0x2, %edx
    32e2: 89 54 24 28                  	movl	%edx, 0x28(%rsp)
    32e6: e9 8c f4 ff ff               	jmp	0x2777 <trusted_x86_x86_sim_xdp+0x2777>
    32eb: 41 81 fe 6e 61 74 69         	cmpl	$0x6974616e, %r14d      # imm = 0x6974616E
    32f2: 74 1a                        	je	0x330e <trusted_x86_x86_sim_xdp+0x330e>
    32f4: 41 81 fe 6e 6d 65 74         	cmpl	$0x74656d6e, %r14d      # imm = 0x74656D6E
    32fb: 0f 85 f2 02 00 00            	jne	0x35f3 <trusted_x86_x86_sim_xdp+0x35f3>
    3301: 48 8b 74 24 38               	movq	0x38(%rsp), %rsi
    3306: 48 8b 94 24 b0 00 00 00      	movq	0xb0(%rsp), %rdx
    330e: 48 8b bc 24 d0 00 00 00      	movq	0xd0(%rsp), %rdi
    3316: 41 89 f8                     	movl	%edi, %r8d
    3319: 49 01 d0                     	addq	%rdx, %r8
    331c: 84 c0                        	testb	%al, %al
    331e: 44 8b b4 24 e4 00 00 00      	movl	0xe4(%rsp), %r14d
    3326: 4c 0f 44 c7                  	cmoveq	%rdi, %r8
    332a: 4c 39 c6                     	cmpq	%r8, %rsi
    332d: 75 56                        	jne	0x3385 <trusted_x86_x86_sim_xdp+0x3385>
    332f: 8b b4 24 dc 00 00 00         	movl	0xdc(%rsp), %esi
    3336: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    333b: ba 08 00 00 00               	movl	$0x8, %edx
    3340: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3345: e8 00 00 00 00               	callq	0x334a <trusted_x86_x86_sim_xdp+0x334a>
		0000000000003346:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    334a: 85 c0                        	testl	%eax, %eax
    334c: 79 09                        	jns	0x3357 <trusted_x86_x86_sim_xdp+0x3357>
    334e: 48 c7 44 24 48 00 00 00 00   	movq	$0x0, 0x48(%rsp)
    3357: 48 8b 8c 24 c0 00 00 00      	movq	0xc0(%rsp), %rcx
    335f: 85 c0                        	testl	%eax, %eax
    3361: 75 22                        	jne	0x3385 <trusted_x86_x86_sim_xdp+0x3385>
    3363: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    3368: 48 39 c8                     	cmpq	%rcx, %rax
    336b: 72 18                        	jb	0x3385 <trusted_x86_x86_sim_xdp+0x3385>
    336d: 48 3b 84 24 c8 00 00 00      	cmpq	0xc8(%rsp), %rax
    3375: 73 0e                        	jae	0x3385 <trusted_x86_x86_sim_xdp+0x3385>
    3377: 89 c2                        	movl	%eax, %edx
    3379: 29 ca                        	subl	%ecx, %edx
    337b: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
    3380: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    3385: 0f b7 84 24 e8 00 00 00      	movzwl	0xe8(%rsp), %eax
    338d: 48 01 c8                     	addq	%rcx, %rax
    3390: 48 39 44 24 38               	cmpq	%rax, 0x38(%rsp)
    3395: 0f 83 13 01 00 00            	jae	0x34ae <trusted_x86_x86_sim_xdp+0x34ae>
    339b: 48 83 c0 fc                  	addq	$-0x4, %rax
    339f: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    33a5: 83 c9 03                     	orl	$0x3, %ecx
    33a8: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    33ac: 48 39 44 24 38               	cmpq	%rax, 0x38(%rsp)
    33b1: 0f 83 35 02 00 00            	jae	0x35ec <trusted_x86_x86_sim_xdp+0x35ec>
    33b7: c7 84 24 e0 00 00 00 08 00 00 00     	movl	$0x8, 0xe0(%rsp)
    33c2: b8 08 00 00 00               	movl	$0x8, %eax
    33c7: e9 54 02 00 00               	jmp	0x3620 <trusted_x86_x86_sim_xdp+0x3620>
    33cc: 41 81 fe 49 6e 74 65         	cmpl	$0x65746e49, %r14d      # imm = 0x65746E49
    33d3: 0f 85 1a 02 00 00            	jne	0x35f3 <trusted_x86_x86_sim_xdp+0x35f3>
    33d9: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    33de: 48 3b 44 24 10               	cmpq	0x10(%rsp), %rax
    33e3: 0f 82 b7 02 00 00            	jb	0x36a0 <trusted_x86_x86_sim_xdp+0x36a0>
    33e9: b8 00 10 00 00               	movl	$0x1000, %eax           # imm = 0x1000
    33ee: 48 03 44 24 10               	addq	0x10(%rsp), %rax
    33f3: 48 39 44 24 30               	cmpq	%rax, 0x30(%rsp)
    33f8: 0f 83 a2 02 00 00            	jae	0x36a0 <trusted_x86_x86_sim_xdp+0x36a0>
    33fe: 48 8b 74 24 30               	movq	0x30(%rsp), %rsi
    3403: 48 83 c6 b0                  	addq	$-0x50, %rsi
    3407: ba 60 00 00 00               	movl	$0x60, %edx
    340c: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3411: e8 00 00 00 00               	callq	0x3416 <trusted_x86_x86_sim_xdp+0x3416>
		0000000000003412:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3416: 85 c0                        	testl	%eax, %eax
    3418: 79 64                        	jns	0x347e <trusted_x86_x86_sim_xdp+0x347e>
    341a: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
    341f: 48 c7 41 58 00 00 00 00      	movq	$0x0, 0x58(%rcx)
    3427: 48 c7 41 50 00 00 00 00      	movq	$0x0, 0x50(%rcx)
    342f: 48 c7 41 48 00 00 00 00      	movq	$0x0, 0x48(%rcx)
    3437: 48 c7 41 40 00 00 00 00      	movq	$0x0, 0x40(%rcx)
    343f: 48 c7 41 38 00 00 00 00      	movq	$0x0, 0x38(%rcx)
    3447: 48 c7 41 30 00 00 00 00      	movq	$0x0, 0x30(%rcx)
    344f: 48 c7 41 28 00 00 00 00      	movq	$0x0, 0x28(%rcx)
    3457: 48 c7 41 20 00 00 00 00      	movq	$0x0, 0x20(%rcx)
    345f: 48 c7 41 18 00 00 00 00      	movq	$0x0, 0x18(%rcx)
    3467: 48 c7 41 10 00 00 00 00      	movq	$0x0, 0x10(%rcx)
    346f: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    3477: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    347e: 85 c0                        	testl	%eax, %eax
    3480: 0f 85 1a 02 00 00            	jne	0x36a0 <trusted_x86_x86_sim_xdp+0x36a0>
    3486: 4c 89 f8                     	movq	%r15, %rax
    3489: 83 b8 c0 02 00 00 00         	cmpl	$0x0, 0x2c0(%rax)
    3490: 0f 84 9b 01 00 00            	je	0x3631 <trusted_x86_x86_sim_xdp+0x3631>
    3496: 48 8b 04 24                  	movq	(%rsp), %rax
    349a: 80 78 1f 00                  	cmpb	$0x0, 0x1f(%rax)
    349e: 0f 84 99 01 00 00            	je	0x363d <trusted_x86_x86_sim_xdp+0x363d>
    34a4: 4c 8b 6c 24 58               	movq	0x58(%rsp), %r13
    34a9: e9 94 01 00 00               	jmp	0x3642 <trusted_x86_x86_sim_xdp+0x3642>
    34ae: 44 8b a4 24 e0 00 00 00      	movl	0xe0(%rsp), %r12d
    34b6: 4c 8b 6c 24 10               	movq	0x10(%rsp), %r13
    34bb: 4b 8d 04 2c                  	leaq	(%r12,%r13), %rax
    34bf: 48 83 c0 30                  	addq	$0x30, %rax
    34c3: 48 89 04 24                  	movq	%rax, (%rsp)
    34c7: 4c 39 6c 24 30               	cmpq	%r13, 0x30(%rsp)
    34cc: 72 24                        	jb	0x34f2 <trusted_x86_x86_sim_xdp+0x34f2>
    34ce: 41 81 e5 00 ff ff ff         	andl	$0xffffff00, %r13d      # imm = 0xFFFFFF00
    34d5: 41 83 cd 03                  	orl	$0x3, %r13d
    34d9: 44 89 6c 24 28               	movl	%r13d, 0x28(%rsp)
    34de: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    34e3: 48 3b 04 24                  	cmpq	(%rsp), %rax
    34e7: 0f 82 1e 01 00 00            	jb	0x360b <trusted_x86_x86_sim_xdp+0x360b>
    34ed: 4c 8b 6c 24 10               	movq	0x10(%rsp), %r13
    34f2: 4b 8d 34 2c                  	leaq	(%r12,%r13), %rsi
    34f6: 48 83 c6 f8                  	addq	$-0x8, %rsi
    34fa: ba 30 00 00 00               	movl	$0x30, %edx
    34ff: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3504: e8 00 00 00 00               	callq	0x3509 <trusted_x86_x86_sim_xdp+0x3509>
		0000000000003505:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3509: 85 c0                        	testl	%eax, %eax
    350b: 79 34                        	jns	0x3541 <trusted_x86_x86_sim_xdp+0x3541>
    350d: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    3512: 48 c7 40 28 00 00 00 00      	movq	$0x0, 0x28(%rax)
    351a: 48 c7 40 20 00 00 00 00      	movq	$0x0, 0x20(%rax)
    3522: 48 c7 40 18 00 00 00 00      	movq	$0x0, 0x18(%rax)
    352a: 48 c7 40 10 00 00 00 00      	movq	$0x0, 0x10(%rax)
    3532: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    353a: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    3541: 4d 01 e5                     	addq	%r12, %r13
    3544: 48 bd 00 00 00 00 00 00 00 ff	movabsq	$-0x100000000000000, %rbp # imm = 0xFF00000000000000
    354e: 4c 89 f8                     	movq	%r15, %rax
    3551: 8b 00                        	movl	(%rax), %eax
    3553: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    355b: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    3561: 4c 8d 64 24 18               	leaq	0x18(%rsp), %r12
    3566: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    356b: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    3572: 4c 89 e7                     	movq	%r12, %rdi
    3575: e8 00 00 00 00               	callq	0x357a <trusted_x86_x86_sim_xdp+0x357a>
		0000000000003576:  R_X86_64_PLT32	.text+0x5c
    357a: 48 85 c0                     	testq	%rax, %rax
    357d: 74 1a                        	je	0x3599 <trusted_x86_x86_sim_xdp+0x3599>
    357f: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3583: 48 21 e8                     	andq	%rbp, %rax
    3586: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    3590: 48 39 c8                     	cmpq	%rcx, %rax
    3593: 0f 84 bb 02 00 00            	je	0x3854 <trusted_x86_x86_sim_xdp+0x3854>
    3599: 4c 89 f8                     	movq	%r15, %rax
    359c: 8b 00                        	movl	(%rax), %eax
    359e: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    35a6: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    35ac: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    35b1: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    35b8: 4c 89 e7                     	movq	%r12, %rdi
    35bb: e8 00 00 00 00               	callq	0x35c0 <trusted_x86_x86_sim_xdp+0x35c0>
		00000000000035bc:  R_X86_64_PLT32	.text+0x5c
    35c0: 48 85 c0                     	testq	%rax, %rax
    35c3: 0f 84 13 01 00 00            	je	0x36dc <trusted_x86_x86_sim_xdp+0x36dc>
    35c9: 48 8b 40 08                  	movq	0x8(%rax), %rax
    35cd: 48 21 e8                     	andq	%rbp, %rax
    35d0: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    35da: 48 39 c8                     	cmpq	%rcx, %rax
    35dd: 0f 85 f9 00 00 00            	jne	0x36dc <trusted_x86_x86_sim_xdp+0x36dc>
    35e3: 49 83 c5 08                  	addq	$0x8, %r13
    35e7: e9 68 02 00 00               	jmp	0x3854 <trusted_x86_x86_sim_xdp+0x3854>
    35ec: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    35f1: eb 18                        	jmp	0x360b <trusted_x86_x86_sim_xdp+0x360b>
    35f3: 8b 84 24 e0 00 00 00         	movl	0xe0(%rsp), %eax
    35fa: c7 44 24 28 00 00 00 00      	movl	$0x0, 0x28(%rsp)
    3602: 85 c0                        	testl	%eax, %eax
    3604: 75 1a                        	jne	0x3620 <trusted_x86_x86_sim_xdp+0x3620>
    3606: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    360b: c7 84 24 e0 00 00 00 10 00 00 00     	movl	$0x10, 0xe0(%rsp)
    3616: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    361b: b8 10 00 00 00               	movl	$0x10, %eax
    3620: 89 c6                        	movl	%eax, %esi
    3622: 48 03 74 24 10               	addq	0x10(%rsp), %rsi
    3627: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    362c: e9 35 02 00 00               	jmp	0x3866 <trusted_x86_x86_sim_xdp+0x3866>
    3631: 4c 89 f8                     	movq	%r15, %rax
    3634: 4c 8b a8 00 0f 00 00         	movq	0xf00(%rax), %r13
    363b: eb 05                        	jmp	0x3642 <trusted_x86_x86_sim_xdp+0x3642>
    363d: 4c 8b 6c 24 60               	movq	0x60(%rsp), %r13
    3642: 4c 8b a4 24 80 00 00 00      	movq	0x80(%rsp), %r12
    364a: 48 8b 84 24 90 00 00 00      	movq	0x90(%rsp), %rax
    3652: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    3657: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
    365f: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    3664: 48 8b 84 24 a0 00 00 00      	movq	0xa0(%rsp), %rax
    366c: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    3671: 48 8b 04 24                  	movq	(%rsp), %rax
    3675: 0f b6 70 1c                  	movzbl	0x1c(%rax), %esi
    3679: 4c 01 e6                     	addq	%r12, %rsi
    367c: 48 8d 7c 24 18               	leaq	0x18(%rsp), %rdi
    3681: ba 08 00 00 00               	movl	$0x8, %edx
    3686: e8 00 00 00 00               	callq	0x368b <trusted_x86_x86_sim_xdp+0x368b>
		0000000000003687:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    368b: 85 c0                        	testl	%eax, %eax
    368d: 79 09                        	jns	0x3698 <trusted_x86_x86_sim_xdp+0x3698>
    368f: 48 c7 44 24 18 00 00 00 00   	movq	$0x0, 0x18(%rsp)
    3698: 85 c0                        	testl	%eax, %eax
    369a: 0f 84 87 00 00 00            	je	0x3727 <trusted_x86_x86_sim_xdp+0x3727>
    36a0: 48 8d b4 24 f4 00 00 00      	leaq	0xf4(%rsp), %rsi
    36a8: c7 84 24 f4 00 00 00 2d 00 00 00     	movl	$0x2d, 0xf4(%rsp)
    36b3: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x36ba <trusted_x86_x86_sim_xdp+0x36ba>
		00000000000036b6:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    36ba: e8 00 00 00 00               	callq	0x36bf <trusted_x86_x86_sim_xdp+0x36bf>
		00000000000036bb:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    36bf: 41 be e9 03 00 00            	movl	$0x3e9, %r14d           # imm = 0x3E9
    36c5: 48 85 c0                     	testq	%rax, %rax
    36c8: 0f 84 c7 ca ff ff            	je	0x195 <trusted_x86_x86_sim_xdp+0x195>
    36ce: 48 89 c1                     	movq	%rax, %rcx
    36d1: 48 8b 09                     	movq	(%rcx), %rcx
    36d4: 48 ff c1                     	incq	%rcx
    36d7: e9 b6 ca ff ff               	jmp	0x192 <trusted_x86_x86_sim_xdp+0x192>
    36dc: 4c 89 f8                     	movq	%r15, %rax
    36df: 8b 00                        	movl	(%rax), %eax
    36e1: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    36e9: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    36ef: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    36f4: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    36fb: 4c 89 e7                     	movq	%r12, %rdi
    36fe: e8 00 00 00 00               	callq	0x3703 <trusted_x86_x86_sim_xdp+0x3703>
		00000000000036ff:  R_X86_64_PLT32	.text+0x5c
    3703: 48 85 c0                     	testq	%rax, %rax
    3706: 74 6e                        	je	0x3776 <trusted_x86_x86_sim_xdp+0x3776>
    3708: 48 8b 40 08                  	movq	0x8(%rax), %rax
    370c: 48 21 e8                     	andq	%rbp, %rax
    370f: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    3719: 48 39 c8                     	cmpq	%rcx, %rax
    371c: 75 58                        	jne	0x3776 <trusted_x86_x86_sim_xdp+0x3776>
    371e: 49 83 c5 10                  	addq	$0x10, %r13
    3722: e9 2d 01 00 00               	jmp	0x3854 <trusted_x86_x86_sim_xdp+0x3854>
    3727: 4c 8b 74 24 18               	movq	0x18(%rsp), %r14
    372c: 48 8b 04 24                  	movq	(%rsp), %rax
    3730: 0f b6 40 1d                  	movzbl	0x1d(%rax), %eax
    3734: 4c 01 f0                     	addq	%r14, %rax
    3737: 31 c9                        	xorl	%ecx, %ecx
    3739: 49 39 c5                     	cmpq	%rax, %r13
    373c: 48 0f 43 c8                  	cmovaeq	%rax, %rcx
    3740: 49 29 cd                     	subq	%rcx, %r13
    3743: 49 81 fd ff ff 00 00         	cmpq	$0xffff, %r13           # imm = 0xFFFF
    374a: b8 ff ff 00 00               	movl	$0xffff, %eax           # imm = 0xFFFF
    374f: 49 0f 42 c5                  	cmovbq	%r13, %rax
    3753: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
    3758: 49 c1 ee 03                  	shrq	$0x3, %r14
    375c: 81 e1 00 ff ff ff            	andl	$0xffffff00, %ecx       # imm = 0xFFFFFF00
    3762: 83 c9 02                     	orl	$0x2, %ecx
    3765: 89 4c 24 28                  	movl	%ecx, 0x28(%rsp)
    3769: 4c 89 a4 24 b0 00 00 00      	movq	%r12, 0xb0(%rsp)
    3771: e9 39 01 00 00               	jmp	0x38af <trusted_x86_x86_sim_xdp+0x38af>
    3776: 4c 89 f8                     	movq	%r15, %rax
    3779: 8b 00                        	movl	(%rax), %eax
    377b: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    3783: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    3789: 48 8b 44 24 60               	movq	0x60(%rsp), %rax
    378e: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    3795: 4c 89 e7                     	movq	%r12, %rdi
    3798: e8 00 00 00 00               	callq	0x379d <trusted_x86_x86_sim_xdp+0x379d>
		0000000000003799:  R_X86_64_PLT32	.text+0x5c
    379d: 48 85 c0                     	testq	%rax, %rax
    37a0: 74 1f                        	je	0x37c1 <trusted_x86_x86_sim_xdp+0x37c1>
    37a2: 48 8b 40 08                  	movq	0x8(%rax), %rax
    37a6: 48 21 e8                     	andq	%rbp, %rax
    37a9: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    37b3: 48 39 c8                     	cmpq	%rcx, %rax
    37b6: 75 09                        	jne	0x37c1 <trusted_x86_x86_sim_xdp+0x37c1>
    37b8: 49 83 c5 18                  	addq	$0x18, %r13
    37bc: e9 93 00 00 00               	jmp	0x3854 <trusted_x86_x86_sim_xdp+0x3854>
    37c1: 4c 89 f8                     	movq	%r15, %rax
    37c4: 8b 00                        	movl	(%rax), %eax
    37c6: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    37ce: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    37d4: 48 8b 44 24 68               	movq	0x68(%rsp), %rax
    37d9: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    37e0: 4c 89 e7                     	movq	%r12, %rdi
    37e3: e8 00 00 00 00               	callq	0x37e8 <trusted_x86_x86_sim_xdp+0x37e8>
		00000000000037e4:  R_X86_64_PLT32	.text+0x5c
    37e8: 48 85 c0                     	testq	%rax, %rax
    37eb: 74 1c                        	je	0x3809 <trusted_x86_x86_sim_xdp+0x3809>
    37ed: 48 8b 40 08                  	movq	0x8(%rax), %rax
    37f1: 48 21 e8                     	andq	%rbp, %rax
    37f4: 48 b9 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    37fe: 48 39 c8                     	cmpq	%rcx, %rax
    3801: 75 06                        	jne	0x3809 <trusted_x86_x86_sim_xdp+0x3809>
    3803: 49 83 c5 20                  	addq	$0x20, %r13
    3807: eb 4b                        	jmp	0x3854 <trusted_x86_x86_sim_xdp+0x3854>
    3809: 4c 89 f8                     	movq	%r15, %rax
    380c: 8b 00                        	movl	(%rax), %eax
    380e: c7 44 24 18 60 00 00 00      	movl	$0x60, 0x18(%rsp)
    3816: 0f 38 f1 44 24 1c            	movbel	%eax, 0x1c(%rsp)
    381c: 48 8b 44 24 70               	movq	0x70(%rsp), %rax
    3821: 48 0f 38 f1 44 24 20         	movbeq	%rax, 0x20(%rsp)
    3828: 4c 89 e7                     	movq	%r12, %rdi
    382b: e8 00 00 00 00               	callq	0x3830 <trusted_x86_x86_sim_xdp+0x3830>
		000000000000382c:  R_X86_64_PLT32	.text+0x5c
    3830: 48 85 c0                     	testq	%rax, %rax
    3833: 0f 84 7d 02 00 00            	je	0x3ab6 <trusted_x86_x86_sim_xdp+0x3ab6>
    3839: 48 23 68 08                  	andq	0x8(%rax), %rbp
    383d: 48 b8 00 00 00 00 00 00 00 02	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    3847: 48 39 c5                     	cmpq	%rax, %rbp
    384a: 0f 85 66 02 00 00            	jne	0x3ab6 <trusted_x86_x86_sim_xdp+0x3ab6>
    3850: 49 83 c5 28                  	addq	$0x28, %r13
    3854: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
    385c: 4c 89 6c 24 10               	movq	%r13, 0x10(%rsp)
    3861: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    3866: 48 83 c6 f0                  	addq	$-0x10, %rsi
    386a: ba 10 00 00 00               	movl	$0x10, %edx
    386f: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3874: e8 00 00 00 00               	callq	0x3879 <trusted_x86_x86_sim_xdp+0x3879>
		0000000000003875:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3879: 85 c0                        	testl	%eax, %eax
    387b: 79 14                        	jns	0x3891 <trusted_x86_x86_sim_xdp+0x3891>
    387d: 48 8d 44 24 48               	leaq	0x48(%rsp), %rax
    3882: 48 c7 40 08 00 00 00 00      	movq	$0x0, 0x8(%rax)
    388a: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    3891: 83 bc 24 e0 00 00 00 10      	cmpl	$0x10, 0xe0(%rsp)
    3899: 72 0a                        	jb	0x38a5 <trusted_x86_x86_sim_xdp+0x38a5>
    389b: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    38a0: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    38a5: 48 8b 44 24 50               	movq	0x50(%rsp), %rax
    38aa: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    38af: 4c 89 f8                     	movq	%r15, %rax
    38b2: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    38b8: 83 f9 7e                     	cmpl	$0x7e, %ecx
    38bb: 0f 87 3f d1 ff ff            	ja	0xa00 <trusted_x86_x86_sim_xdp+0xa00>
    38c1: 4c 89 f8                     	movq	%r15, %rax
    38c4: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    38cb: 8b 54 24 28                  	movl	0x28(%rsp), %edx
    38cf: 48 8b 74 24 40               	movq	0x40(%rsp), %rsi
    38d4: 4c 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %r8
    38dc: 8d 79 01                     	leal	0x1(%rcx), %edi
    38df: 41 89 38                     	movl	%edi, (%r8)
    38e2: c1 e1 03                     	shll	$0x3, %ecx
    38e5: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    38e8: 4c 8b 84 24 a0 01 00 00      	movq	0x1a0(%rsp), %r8
    38f0: 49 01 c8                     	addq	%rcx, %r8
    38f3: 48 8b bc 24 b0 00 00 00      	movq	0xb0(%rsp), %rdi
    38fb: 49 89 38                     	movq	%rdi, (%r8)
    38fe: 48 c1 e6 20                  	shlq	$0x20, %rsi
    3902: 44 89 f7                     	movl	%r14d, %edi
    3905: 48 09 f7                     	orq	%rsi, %rdi
    3908: 48 c1 e2 3c                  	shlq	$0x3c, %rdx
    390c: 48 09 d7                     	orq	%rdx, %rdi
    390f: 48 8b 94 24 98 01 00 00      	movq	0x198(%rsp), %rdx
    3917: 48 01 ca                     	addq	%rcx, %rdx
    391a: 48 89 3a                     	movq	%rdi, (%rdx)
    391d: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    3925: 48 01 ca                     	addq	%rcx, %rdx
    3928: c6 02 05                     	movb	$0x5, (%rdx)
    392b: 48 8b 94 24 40 01 00 00      	movq	0x140(%rsp), %rdx
    3933: 48 01 ca                     	addq	%rcx, %rdx
    3936: 88 02                        	movb	%al, (%rdx)
    3938: 48 8b 84 24 a8 01 00 00      	movq	0x1a8(%rsp), %rax
    3940: 48 01 c8                     	addq	%rcx, %rax
    3943: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    3949: 48 8b 84 24 90 01 00 00      	movq	0x190(%rsp), %rax
    3951: 48 01 c8                     	addq	%rcx, %rax
    3954: 66 c7 00 00 00               	movw	$0x0, (%rax)
    3959: 48 8b 44 24 38               	movq	0x38(%rsp), %rax
    395e: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    3966: 48 89 01                     	movq	%rax, (%rcx)
    3969: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    396e: 48 8b 8c 24 68 01 00 00      	movq	0x168(%rsp), %rcx
    3976: 48 89 01                     	movq	%rax, (%rcx)
    3979: 48 8b 44 24 30               	movq	0x30(%rsp), %rax
    397e: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    3986: 48 89 01                     	movq	%rax, (%rcx)
    3989: 48 8b 84 24 60 01 00 00      	movq	0x160(%rsp), %rax
    3991: c6 00 01                     	movb	$0x1, (%rax)
    3994: c7 44 24 48 2a 00 00 00      	movl	$0x2a, 0x48(%rsp)
    399c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x39a3 <trusted_x86_x86_sim_xdp+0x39a3>
		000000000000399f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    39a3: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    39a8: e8 00 00 00 00               	callq	0x39ad <trusted_x86_x86_sim_xdp+0x39ad>
		00000000000039a9:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    39ad: 48 85 c0                     	testq	%rax, %rax
    39b0: 74 0c                        	je	0x39be <trusted_x86_x86_sim_xdp+0x39be>
    39b2: 48 89 c1                     	movq	%rax, %rcx
    39b5: 48 8b 09                     	movq	(%rcx), %rcx
    39b8: 48 ff c1                     	incq	%rcx
    39bb: 48 89 08                     	movq	%rcx, (%rax)
    39be: 4c 89 f8                     	movq	%r15, %rax
    39c1: 4c 8b a8 d0 0e 00 00         	movq	0xed0(%rax), %r13
    39c8: 4d 85 ed                     	testq	%r13, %r13
    39cb: 0f 84 b5 00 00 00            	je	0x3a86 <trusted_x86_x86_sim_xdp+0x3a86>
    39d1: 4c 3b ac 24 88 01 00 00      	cmpq	0x188(%rsp), %r13
    39d9: 0f 83 c2 d5 ff ff            	jae	0xfa1 <trusted_x86_x86_sim_xdp+0xfa1>
    39df: 49 81 fd 00 10 00 00         	cmpq	$0x1000, %r13           # imm = 0x1000
    39e6: 0f 82 d6 d5 ff ff            	jb	0xfc2 <trusted_x86_x86_sim_xdp+0xfc2>
    39ec: 4c 89 f8                     	movq	%r15, %rax
    39ef: 8b 00                        	movl	(%rax), %eax
    39f1: c7 44 24 48 60 00 00 00      	movl	$0x60, 0x48(%rsp)
    39f9: 0f 38 f1 44 24 4c            	movbel	%eax, 0x4c(%rsp)
    39ff: 4c 0f 38 f1 6c 24 50         	movbeq	%r13, 0x50(%rsp)
    3a06: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3a0b: e8 00 00 00 00               	callq	0x3a10 <trusted_x86_x86_sim_xdp+0x3a10>
		0000000000003a0c:  R_X86_64_PLT32	.text+0x5c
    3a10: 48 85 c0                     	testq	%rax, %rax
    3a13: 0f 84 85 00 00 00            	je	0x3a9e <trusted_x86_x86_sim_xdp+0x3a9e>
    3a19: 48 89 c1                     	movq	%rax, %rcx
    3a1c: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    3a20: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    3a2a: 48 21 e9                     	andq	%rbp, %rcx
    3a2d: 48 8b 94 24 58 01 00 00      	movq	0x158(%rsp), %rdx
    3a35: 48 89 0a                     	movq	%rcx, (%rdx)
    3a38: 48 c1 ed 38                  	shrq	$0x38, %rbp
    3a3c: 48 8b 00                     	movq	(%rax), %rax
    3a3f: 48 8b 94 24 50 01 00 00      	movq	0x150(%rsp), %rdx
    3a47: 48 89 02                     	movq	%rax, (%rdx)
    3a4a: 49 29 cd                     	subq	%rcx, %r13
    3a4d: 48 8b 8c 24 48 01 00 00      	movq	0x148(%rsp), %rcx
    3a55: 4c 89 29                     	movq	%r13, (%rcx)
    3a58: 45 31 f6                     	xorl	%r14d, %r14d
    3a5b: 48 83 fd 01                  	cmpq	$0x1, %rbp
    3a5f: 0f 85 32 c7 ff ff            	jne	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3a65: 48 89 44 24 48               	movq	%rax, 0x48(%rsp)
    3a6a: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3a71 <trusted_x86_x86_sim_xdp+0x3a71>
		0000000000003a6d:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3a71: 48 8d 7c 24 48               	leaq	0x48(%rsp), %rdi
    3a76: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3a7d <trusted_x86_x86_sim_xdp+0x3a7d>
		0000000000003a79:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3a7d: 75 70                        	jne	0x3aef <trusted_x86_x86_sim_xdp+0x3aef>
    3a7f: e8 00 00 00 00               	callq	0x3a84 <trusted_x86_x86_sim_xdp+0x3a84>
		0000000000003a80:  R_X86_64_PLT32	.text+0x5c
    3a84: eb 6e                        	jmp	0x3af4 <trusted_x86_x86_sim_xdp+0x3af4>
    3a86: 49 8d 87 28 0f 00 00         	leaq	0xf28(%r15), %rax
    3a8d: c7 00 01 00 00 00            	movl	$0x1, (%rax)
    3a93: 41 be ad 0f 00 00            	movl	$0xfad, %r14d           # imm = 0xFAD
    3a99: e9 f7 c6 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
    3a9e: 49 8d 87 28 0f 00 00         	leaq	0xf28(%r15), %rax
    3aa5: c7 00 0c 00 00 00            	movl	$0xc, (%rax)
    3aab: 41 be ac 0f 00 00            	movl	$0xfac, %r14d           # imm = 0xFAC
    3ab1: e9 df c6 ff ff               	jmp	0x195 <trusted_x86_x86_sim_xdp+0x195>
    3ab6: c7 44 24 18 2e 00 00 00      	movl	$0x2e, 0x18(%rsp)
    3abe: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3ac5 <trusted_x86_x86_sim_xdp+0x3ac5>
		0000000000003ac1:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3ac5: 4c 89 e6                     	movq	%r12, %rsi
    3ac8: e8 00 00 00 00               	callq	0x3acd <trusted_x86_x86_sim_xdp+0x3acd>
		0000000000003ac9:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3acd: 48 85 c0                     	testq	%rax, %rax
    3ad0: 74 0c                        	je	0x3ade <trusted_x86_x86_sim_xdp+0x3ade>
    3ad2: 48 89 c1                     	movq	%rax, %rcx
    3ad5: 48 8b 09                     	movq	(%rcx), %rcx
    3ad8: 48 ff c1                     	incq	%rcx
    3adb: 48 89 08                     	movq	%rcx, (%rax)
    3ade: c7 44 24 28 03 00 00 00      	movl	$0x3, 0x28(%rsp)
    3ae6: 48 8b 04 24                  	movq	(%rsp), %rax
    3aea: e9 ff e2 ff ff               	jmp	0x1dee <trusted_x86_x86_sim_xdp+0x1dee>
    3aef: e8 00 00 00 00               	callq	0x3af4 <trusted_x86_x86_sim_xdp+0x3af4>
		0000000000003af0:  R_X86_64_PLT32	.text+0x10c
    3af4: 49 89 c4                     	movq	%rax, %r12
    3af7: bd 01 00 00 00               	movl	$0x1, %ebp
    3afc: 48 85 c0                     	testq	%rax, %rax
    3aff: 0f 84 92 c6 ff ff            	je	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3b05: 4c 89 e0                     	movq	%r12, %rax
    3b08: 48 8b 00                     	movq	(%rax), %rax
    3b0b: 4c 39 e8                     	cmpq	%r13, %rax
    3b0e: 77 0c                        	ja	0x3b1c <trusted_x86_x86_sim_xdp+0x3b1c>
    3b10: 4c 89 e0                     	movq	%r12, %rax
    3b13: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3b17: 4c 39 e8                     	cmpq	%r13, %rax
    3b1a: 73 20                        	jae	0x3b3c <trusted_x86_x86_sim_xdp+0x3b3c>
    3b1c: 4c 89 e0                     	movq	%r12, %rax
    3b1f: 48 8b 40 10                  	movq	0x10(%rax), %rax
    3b23: 4c 39 e8                     	cmpq	%r13, %rax
    3b26: 0f 87 6b c6 ff ff            	ja	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3b2c: 4c 89 e0                     	movq	%r12, %rax
    3b2f: 48 8b 40 18                  	movq	0x18(%rax), %rax
    3b33: 4c 39 e8                     	cmpq	%r13, %rax
    3b36: 0f 82 5b c6 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3b3c: 4c 89 f8                     	movq	%r15, %rax
    3b3f: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    3b45: 4c 89 e1                     	movq	%r12, %rcx
    3b48: 8b 49 20                     	movl	0x20(%rcx), %ecx
    3b4b: 0f a3 c8                     	btl	%ecx, %eax
    3b4e: 0f 82 43 c6 ff ff            	jb	0x197 <trusted_x86_x86_sim_xdp+0x197>
    3b54: 48 8d b4 24 b8 00 00 00      	leaq	0xb8(%rsp), %rsi
    3b5c: c7 84 24 b8 00 00 00 00 00 00 00     	movl	$0x0, 0xb8(%rsp)
    3b67: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3b6e <trusted_x86_x86_sim_xdp+0x3b6e>
		0000000000003b6a:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3b6e: e8 00 00 00 00               	callq	0x3b73 <trusted_x86_x86_sim_xdp+0x3b73>
		0000000000003b6f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3b73: 48 85 c0                     	testq	%rax, %rax
    3b76: 74 0c                        	je	0x3b84 <trusted_x86_x86_sim_xdp+0x3b84>
    3b78: 48 89 c1                     	movq	%rax, %rcx
    3b7b: 48 8b 09                     	movq	(%rcx), %rcx
    3b7e: 48 ff c1                     	incq	%rcx
    3b81: 48 89 08                     	movq	%rcx, (%rax)
    3b84: 41 0f b7 6c 24 20            	movzwl	0x20(%r12), %ebp
    3b8a: e9 08 c6 ff ff               	jmp	0x197 <trusted_x86_x86_sim_xdp+0x197>
