
/var/tmp/kprog-tmp/perf/helper-sharing/3/checked-simulator.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__kprog_array_lookup>:
       0: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x7 <__kprog_array_lookup+0x7>
		0000000000000003:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
       7: 74 33                        	je	0x3c <__kprog_array_lookup+0x3c>
       9: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x10 <__kprog_array_lookup+0x10>
		000000000000000c:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
      10: 74 2f                        	je	0x41 <__kprog_array_lookup+0x41>
      12: 48 3b 3d 00 00 00 00         	cmpq	(%rip), %rdi            # 0x19 <__kprog_array_lookup+0x19>
		0000000000000015:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
      19: 74 2e                        	je	0x49 <__kprog_array_lookup+0x49>
      1b: 8b 06                        	movl	(%rsi), %eax
      1d: 3b 47 44                     	cmpl	0x44(%rdi), %eax
      20: 73 2f                        	jae	0x51 <__kprog_array_lookup+0x51>
      22: 8b 8f 20 01 00 00            	movl	0x120(%rdi), %ecx
      28: 23 87 24 01 00 00            	andl	0x124(%rdi), %eax
      2e: 48 0f af c1                  	imulq	%rcx, %rax
      32: 48 01 f8                     	addq	%rdi, %rax
      35: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
      3b: c3                           	retq
      3c: 48 89 f7                     	movq	%rsi, %rdi
      3f: eb 1f                        	jmp	0x60 <__kprog_lpm_key_16>
      41: 48 89 f7                     	movq	%rsi, %rdi
      44: e9 c7 00 00 00               	jmp	0x110 <__kprog_hash_key_8>
      49: 48 89 f7                     	movq	%rsi, %rdi
      4c: e9 6f 01 00 00               	jmp	0x1c0 <__kprog_hash_key_16>
      51: 31 c0                        	xorl	%eax, %eax
      53: c3                           	retq
      54: 66 66 66 2e 0f 1f 84 00 00 00 00 00  	nopw	%cs:(%rax,%rax)

0000000000000060 <__kprog_lpm_key_16>:
      60: 8b 07                        	movl	(%rdi), %eax
      62: 83 f8 60                     	cmpl	$0x60, %eax
      65: 76 03                        	jbe	0x6a <__kprog_lpm_key_16+0xa>
      67: 31 c0                        	xorl	%eax, %eax
      69: c3                           	retq
      6a: 48 8b 0d 00 00 00 00         	movq	(%rip), %rcx            # 0x71 <__kprog_lpm_key_16+0x11>
		000000000000006d:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
      71: 48 8b 91 20 01 00 00         	movq	0x120(%rcx), %rdx
      78: 31 c9                        	xorl	%ecx, %ecx
      7a: eb 3f                        	jmp	0xbb <__kprog_lpm_key_16+0x5b>
      7c: 0f 1f 40 00                  	nopl	(%rax)
      80: 49 0f c8                     	bswapq	%r8
      83: 41 89 f1                     	movl	%esi, %r9d
      86: 41 f6 d9                     	negb	%r9b
      89: c4 42 b3 f7 c0               	shrxq	%r9, %r8, %r8
      8e: 4d 85 c0                     	testq	%r8, %r8
      91: 75 6e                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      93: f6 42 14 01                  	testb	$0x1, 0x14(%rdx)
      97: 48 0f 44 ca                  	cmoveq	%rdx, %rcx
      9b: 41 89 f0                     	movl	%esi, %r8d
      9e: 41 c1 e8 03                  	shrl	$0x3, %r8d
      a2: 46 0f b6 44 07 04            	movzbl	0x4(%rdi,%r8), %r8d
      a8: 40 f6 d6                     	notb	%sil
      ab: 40 80 e6 07                  	andb	$0x7, %sil
      af: c4 c2 4b f7 f0               	shrxl	%esi, %r8d, %esi
      b4: 83 e6 01                     	andl	$0x1, %esi
      b7: 48 8b 14 f2                  	movq	(%rdx,%rsi,8), %rdx
      bb: 48 85 d2                     	testq	%rdx, %rdx
      be: 74 41                        	je	0x101 <__kprog_lpm_key_16+0xa1>
      c0: 8b 72 10                     	movl	0x10(%rdx), %esi
      c3: 39 c6                        	cmpl	%eax, %esi
      c5: 77 3a                        	ja	0x101 <__kprog_lpm_key_16+0xa1>
      c7: 48 85 f6                     	testq	%rsi, %rsi
      ca: 74 c7                        	je	0x93 <__kprog_lpm_key_16+0x33>
      cc: 4c 8b 47 04                  	movq	0x4(%rdi), %r8
      d0: 4c 33 42 18                  	xorq	0x18(%rdx), %r8
      d4: 83 fe 40                     	cmpl	$0x40, %esi
      d7: 76 a7                        	jbe	0x80 <__kprog_lpm_key_16+0x20>
      d9: 4d 85 c0                     	testq	%r8, %r8
      dc: 75 23                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      de: 44 8b 42 20                  	movl	0x20(%rdx), %r8d
      e2: 44 33 47 0c                  	xorl	0xc(%rdi), %r8d
      e6: 41 0f c8                     	bswapl	%r8d
      e9: 41 89 f1                     	movl	%esi, %r9d
      ec: 41 f6 d9                     	negb	%r9b
      ef: c4 42 33 f7 c0               	shrxl	%r9d, %r8d, %r8d
      f4: 45 85 c0                     	testl	%r8d, %r8d
      f7: 75 08                        	jne	0x101 <__kprog_lpm_key_16+0xa1>
      f9: 83 fe 60                     	cmpl	$0x60, %esi
      fc: 75 95                        	jne	0x93 <__kprog_lpm_key_16+0x33>
      fe: 48 89 d1                     	movq	%rdx, %rcx
     101: 48 8d 41 24                  	leaq	0x24(%rcx), %rax
     105: 48 85 c9                     	testq	%rcx, %rcx
     108: 48 0f 44 c1                  	cmoveq	%rcx, %rax
     10c: c3                           	retq
     10d: 0f 1f 00                     	nopl	(%rax)

0000000000000110 <__kprog_hash_key_8>:
     110: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x117 <__kprog_hash_key_8+0x7>
		0000000000000113:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     117: ba f7 be ad de               	movl	$0xdeadbef7, %edx       # imm = 0xDEADBEF7
     11c: 03 90 40 03 00 00            	addl	0x340(%rax), %edx
     122: 8b 37                        	movl	(%rdi), %esi
     124: 01 d6                        	addl	%edx, %esi
     126: 8b 4f 04                     	movl	0x4(%rdi), %ecx
     129: 01 d1                        	addl	%edx, %ecx
     12b: 31 ca                        	xorl	%ecx, %edx
     12d: c4 63 7b f0 c1 12            	rorxl	$0x12, %ecx, %r8d
     133: 44 29 c2                     	subl	%r8d, %edx
     136: 31 d6                        	xorl	%edx, %esi
     138: c4 63 7b f0 c2 15            	rorxl	$0x15, %edx, %r8d
     13e: 44 29 c6                     	subl	%r8d, %esi
     141: 31 f1                        	xorl	%esi, %ecx
     143: c4 63 7b f0 c6 07            	rorxl	$0x7, %esi, %r8d
     149: 44 29 c1                     	subl	%r8d, %ecx
     14c: 31 ca                        	xorl	%ecx, %edx
     14e: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
     154: 44 29 c2                     	subl	%r8d, %edx
     157: 31 d6                        	xorl	%edx, %esi
     159: c4 63 7b f0 c2 1c            	rorxl	$0x1c, %edx, %r8d
     15f: 44 29 c6                     	subl	%r8d, %esi
     162: 31 f1                        	xorl	%esi, %ecx
     164: c4 e3 7b f0 f6 12            	rorxl	$0x12, %esi, %esi
     16a: 29 f1                        	subl	%esi, %ecx
     16c: c4 e3 7b f0 f1 08            	rorxl	$0x8, %ecx, %esi
     172: 31 d1                        	xorl	%edx, %ecx
     174: 29 f1                        	subl	%esi, %ecx
     176: 8b 90 38 03 00 00            	movl	0x338(%rax), %edx
     17c: ff ca                        	decl	%edx
     17e: 21 ca                        	andl	%ecx, %edx
     180: 48 8b b0 c0 01 00 00         	movq	0x1c0(%rax), %rsi
     187: 49 89 d0                     	movq	%rdx, %r8
     18a: 49 c1 e0 04                  	shlq	$0x4, %r8
     18e: eb 08                        	jmp	0x198 <__kprog_hash_key_8+0x88>
     190: 48 d1 e8                     	shrq	%rax
     193: 48 39 d0                     	cmpq	%rdx, %rax
     196: 74 22                        	je	0x1ba <__kprog_hash_key_8+0xaa>
     198: 4a 8b 04 06                  	movq	(%rsi,%r8), %rax
     19c: eb 05                        	jmp	0x1a3 <__kprog_hash_key_8+0x93>
     19e: 66 90                        	nop
     1a0: 48 8b 00                     	movq	(%rax), %rax
     1a3: a8 01                        	testb	$0x1, %al
     1a5: 75 e9                        	jne	0x190 <__kprog_hash_key_8+0x80>
     1a7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
     1aa: 75 f4                        	jne	0x1a0 <__kprog_hash_key_8+0x90>
     1ac: 4c 8b 48 30                  	movq	0x30(%rax), %r9
     1b0: 4c 3b 0f                     	cmpq	(%rdi), %r9
     1b3: 75 eb                        	jne	0x1a0 <__kprog_hash_key_8+0x90>
     1b5: 48 83 c0 38                  	addq	$0x38, %rax
     1b9: c3                           	retq
     1ba: 31 c0                        	xorl	%eax, %eax
     1bc: c3                           	retq
     1bd: 0f 1f 00                     	nopl	(%rax)

00000000000001c0 <__kprog_hash_key_16>:
     1c0: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1c7 <__kprog_hash_key_16+0x7>
		00000000000001c3:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
     1c7: 8b 88 40 03 00 00            	movl	0x340(%rax), %ecx
     1cd: 8d 91 ff be ad de            	leal	-0x21524101(%rcx), %edx
     1d3: 03 57 04                     	addl	0x4(%rdi), %edx
     1d6: 8b 37                        	movl	(%rdi), %esi
     1d8: 44 8b 47 08                  	movl	0x8(%rdi), %r8d
     1dc: 44 01 c1                     	addl	%r8d, %ecx
     1df: 81 c1 ff be ad de            	addl	$0xdeadbeff, %ecx       # imm = 0xDEADBEFF
     1e5: 44 29 c6                     	subl	%r8d, %esi
     1e8: c4 63 7b f0 c1 1c            	rorxl	$0x1c, %ecx, %r8d
     1ee: 41 31 f0                     	xorl	%esi, %r8d
     1f1: 01 d1                        	addl	%edx, %ecx
     1f3: 44 29 c2                     	subl	%r8d, %edx
     1f6: c4 c3 7b f0 f0 1a            	rorxl	$0x1a, %r8d, %esi
     1fc: 31 d6                        	xorl	%edx, %esi
     1fe: 41 01 c8                     	addl	%ecx, %r8d
     201: 29 f1                        	subl	%esi, %ecx
     203: c4 63 7b f0 ce 18            	rorxl	$0x18, %esi, %r9d
     209: 41 31 c9                     	xorl	%ecx, %r9d
     20c: 44 01 c6                     	addl	%r8d, %esi
     20f: 45 29 c8                     	subl	%r9d, %r8d
     212: c4 c3 7b f0 d1 10            	rorxl	$0x10, %r9d, %edx
     218: 44 31 c2                     	xorl	%r8d, %edx
     21b: 41 01 f1                     	addl	%esi, %r9d
     21e: 29 d6                        	subl	%edx, %esi
     220: c4 e3 7b f0 ca 0d            	rorxl	$0xd, %edx, %ecx
     226: 31 f1                        	xorl	%esi, %ecx
     228: 44 01 ca                     	addl	%r9d, %edx
     22b: 41 29 c9                     	subl	%ecx, %r9d
     22e: c4 e3 7b f0 f1 1c            	rorxl	$0x1c, %ecx, %esi
     234: 44 31 ce                     	xorl	%r9d, %esi
     237: 01 d1                        	addl	%edx, %ecx
     239: 03 57 0c                     	addl	0xc(%rdi), %edx
     23c: 31 ce                        	xorl	%ecx, %esi
     23e: c4 63 7b f0 c1 12            	rorxl	$0x12, %ecx, %r8d
     244: 44 29 c6                     	subl	%r8d, %esi
     247: 31 f2                        	xorl	%esi, %edx
     249: c4 63 7b f0 c6 15            	rorxl	$0x15, %esi, %r8d
     24f: 44 29 c2                     	subl	%r8d, %edx
     252: 31 d1                        	xorl	%edx, %ecx
     254: c4 63 7b f0 c2 07            	rorxl	$0x7, %edx, %r8d
     25a: 44 29 c1                     	subl	%r8d, %ecx
     25d: 31 ce                        	xorl	%ecx, %esi
     25f: c4 63 7b f0 c1 10            	rorxl	$0x10, %ecx, %r8d
     265: 44 29 c6                     	subl	%r8d, %esi
     268: 31 f2                        	xorl	%esi, %edx
     26a: c4 63 7b f0 c6 1c            	rorxl	$0x1c, %esi, %r8d
     270: 44 29 c2                     	subl	%r8d, %edx
     273: 31 d1                        	xorl	%edx, %ecx
     275: c4 e3 7b f0 d2 12            	rorxl	$0x12, %edx, %edx
     27b: 29 d1                        	subl	%edx, %ecx
     27d: c4 e3 7b f0 d1 08            	rorxl	$0x8, %ecx, %edx
     283: 31 f1                        	xorl	%esi, %ecx
     285: 29 d1                        	subl	%edx, %ecx
     287: 8b 90 38 03 00 00            	movl	0x338(%rax), %edx
     28d: ff ca                        	decl	%edx
     28f: 21 ca                        	andl	%ecx, %edx
     291: 48 8b b0 c0 01 00 00         	movq	0x1c0(%rax), %rsi
     298: 49 89 d0                     	movq	%rdx, %r8
     29b: 49 c1 e0 04                  	shlq	$0x4, %r8
     29f: eb 17                        	jmp	0x2b8 <__kprog_hash_key_16+0xf8>
     2a1: 66 66 66 66 66 66 2e 0f 1f 84 00 00 00 00 00 	nopw	%cs:(%rax,%rax)
     2b0: 48 d1 e8                     	shrq	%rax
     2b3: 48 39 d0                     	cmpq	%rdx, %rax
     2b6: 74 2c                        	je	0x2e4 <__kprog_hash_key_16+0x124>
     2b8: 4a 8b 04 06                  	movq	(%rsi,%r8), %rax
     2bc: eb 05                        	jmp	0x2c3 <__kprog_hash_key_16+0x103>
     2be: 66 90                        	nop
     2c0: 48 8b 00                     	movq	(%rax), %rax
     2c3: a8 01                        	testb	$0x1, %al
     2c5: 75 e9                        	jne	0x2b0 <__kprog_hash_key_16+0xf0>
     2c7: 39 48 28                     	cmpl	%ecx, 0x28(%rax)
     2ca: 75 f4                        	jne	0x2c0 <__kprog_hash_key_16+0x100>
     2cc: 4c 8b 48 30                  	movq	0x30(%rax), %r9
     2d0: 4c 3b 0f                     	cmpq	(%rdi), %r9
     2d3: 75 eb                        	jne	0x2c0 <__kprog_hash_key_16+0x100>
     2d5: 4c 8b 48 38                  	movq	0x38(%rax), %r9
     2d9: 4c 3b 4f 08                  	cmpq	0x8(%rdi), %r9
     2dd: 75 e1                        	jne	0x2c0 <__kprog_hash_key_16+0x100>
     2df: 48 83 c0 40                  	addq	$0x40, %rax
     2e3: c3                           	retq
     2e4: 31 c0                        	xorl	%eax, %eax
     2e6: c3                           	retq
     2e7: 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)

00000000000002f0 <__kprog_probe_read_user>:
     2f0: 41 57                        	pushq	%r15
     2f2: 41 56                        	pushq	%r14
     2f4: 53                           	pushq	%rbx
     2f5: 49 89 fe                     	movq	%rdi, %r14
     2f8: 89 f3                        	movl	%esi, %ebx
     2fa: 48 89 d6                     	movq	%rdx, %rsi
     2fd: 48 89 da                     	movq	%rbx, %rdx
     300: e8 00 00 00 00               	callq	0x305 <__kprog_probe_read_user+0x15>
		0000000000000301:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     305: 49 89 c7                     	movq	%rax, %r15
     308: 45 85 ff                     	testl	%r15d, %r15d
     30b: 79 0d                        	jns	0x31a <__kprog_probe_read_user+0x2a>
     30d: 4c 89 f7                     	movq	%r14, %rdi
     310: 31 f6                        	xorl	%esi, %esi
     312: 48 89 da                     	movq	%rbx, %rdx
     315: e8 00 00 00 00               	callq	0x31a <__kprog_probe_read_user+0x2a>
		0000000000000316:  R_X86_64_PLT32	memset-0x4
     31a: 49 63 c7                     	movslq	%r15d, %rax
     31d: 5b                           	popq	%rbx
     31e: 41 5e                        	popq	%r14
     320: 41 5f                        	popq	%r15
     322: c3                           	retq
     323: 66 66 66 66 2e 0f 1f 84 00 00 00 00 00       	nopw	%cs:(%rax,%rax)

0000000000000330 <__kprog_probe_read_kernel>:
     330: 41 57                        	pushq	%r15
     332: 41 56                        	pushq	%r14
     334: 53                           	pushq	%rbx
     335: 49 89 fe                     	movq	%rdi, %r14
     338: 89 f3                        	movl	%esi, %ebx
     33a: 48 89 d6                     	movq	%rdx, %rsi
     33d: 48 89 da                     	movq	%rbx, %rdx
     340: e8 00 00 00 00               	callq	0x345 <__kprog_probe_read_kernel+0x15>
		0000000000000341:  R_X86_64_PLT32	copy_from_kernel_nofault-0x4
     345: 49 89 c7                     	movq	%rax, %r15
     348: 45 85 ff                     	testl	%r15d, %r15d
     34b: 79 0d                        	jns	0x35a <__kprog_probe_read_kernel+0x2a>
     34d: 4c 89 f7                     	movq	%r14, %rdi
     350: 31 f6                        	xorl	%esi, %esi
     352: 48 89 da                     	movq	%rbx, %rdx
     355: e8 00 00 00 00               	callq	0x35a <__kprog_probe_read_kernel+0x2a>
		0000000000000356:  R_X86_64_PLT32	memset-0x4
     35a: 49 63 c7                     	movslq	%r15d, %rax
     35d: 5b                           	popq	%rbx
     35e: 41 5e                        	popq	%r14
     360: 41 5f                        	popq	%r15
     362: c3                           	retq

Disassembly of section perf_event:

0000000000000000 <trusted_x86_x86_sim_xdp>:
       0: 55                           	pushq	%rbp
       1: 41 57                        	pushq	%r15
       3: 41 56                        	pushq	%r14
       5: 41 55                        	pushq	%r13
       7: 41 54                        	pushq	%r12
       9: 53                           	pushq	%rbx
       a: 48 81 ec f8 01 00 00         	subq	$0x1f8, %rsp            # imm = 0x1F8
      11: 49 89 fc                     	movq	%rdi, %r12
      14: 48 8d 9c 24 a8 00 00 00      	leaq	0xa8(%rsp), %rbx
      1c: c7 84 24 a8 00 00 00 00 00 00 00     	movl	$0x0, 0xa8(%rsp)
      27: 48 c7 84 24 40 01 00 00 00 00 00 00  	movq	$0x0, 0x140(%rsp)
      33: 48 c7 84 24 48 01 00 00 00 00 00 00  	movq	$0x0, 0x148(%rsp)
      3f: 48 c7 84 24 50 01 00 00 00 00 00 00  	movq	$0x0, 0x150(%rsp)
      4b: 48 c7 84 24 58 01 00 00 00 00 00 00  	movq	$0x0, 0x158(%rsp)
      57: 48 c7 84 24 60 01 00 00 00 00 00 00  	movq	$0x0, 0x160(%rsp)
      63: 48 c7 84 24 68 01 00 00 00 00 00 00  	movq	$0x0, 0x168(%rsp)
      6f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x76 <trusted_x86_x86_sim_xdp+0x76>
		0000000000000072:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
      76: 48 89 de                     	movq	%rbx, %rsi
      79: e8 00 00 00 00               	callq	0x7e <trusted_x86_x86_sim_xdp+0x7e>
		000000000000007a:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      7e: 48 85 c0                     	testq	%rax, %rax
      81: 0f 84 df 33 00 00            	je	0x3466 <trusted_x86_x86_sim_xdp+0x3466>
      87: 49 89 c6                     	movq	%rax, %r14
      8a: c7 84 24 a8 00 00 00 05 00 00 00     	movl	$0x5, 0xa8(%rsp)
      95: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x9c <trusted_x86_x86_sim_xdp+0x9c>
		0000000000000098:  R_X86_64_REX_GOTPCRELX	metrics-0x4
      9c: 48 89 de                     	movq	%rbx, %rsi
      9f: e8 00 00 00 00               	callq	0xa4 <trusted_x86_x86_sim_xdp+0xa4>
		00000000000000a0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      a4: 48 85 c0                     	testq	%rax, %rax
      a7: 74 0c                        	je	0xb5 <trusted_x86_x86_sim_xdp+0xb5>
      a9: 48 89 c1                     	movq	%rax, %rcx
      ac: 48 8b 09                     	movq	(%rcx), %rcx
      af: 48 ff c1                     	incq	%rcx
      b2: 48 89 08                     	movq	%rcx, (%rax)
      b5: 4c 89 f0                     	movq	%r14, %rax
      b8: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
      be: 83 f9 7f                     	cmpl	$0x7f, %ecx
      c1: 72 3c                        	jb	0xff <trusted_x86_x86_sim_xdp+0xff>
      c3: c7 84 24 a8 00 00 00 02 00 00 00     	movl	$0x2, 0xa8(%rsp)
      ce: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xd5 <trusted_x86_x86_sim_xdp+0xd5>
		00000000000000d1:  R_X86_64_REX_GOTPCRELX	metrics-0x4
      d5: 48 89 de                     	movq	%rbx, %rsi
      d8: e8 00 00 00 00               	callq	0xdd <trusted_x86_x86_sim_xdp+0xdd>
		00000000000000d9:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
      dd: 41 bd 02 00 00 00            	movl	$0x2, %r13d
      e3: 48 85 c0                     	testq	%rax, %rax
      e6: 0f 84 cf 07 00 00            	je	0x8bb <trusted_x86_x86_sim_xdp+0x8bb>
      ec: 48 89 c1                     	movq	%rax, %rcx
      ef: 48 8b 09                     	movq	(%rcx), %rcx
      f2: 48 ff c1                     	incq	%rcx
      f5: 48 89 08                     	movq	%rcx, (%rax)
      f8: 31 ed                        	xorl	%ebp, %ebp
      fa: e9 c7 32 00 00               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
      ff: 4c 89 f0                     	movq	%r14, %rax
     102: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
     109: 4c 89 f2                     	movq	%r14, %rdx
     10c: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
     113: 4c 89 f6                     	movq	%r14, %rsi
     116: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
     11d: 8d 79 01                     	leal	0x1(%rcx), %edi
     120: 4d 8d ae c0 02 00 00         	leaq	0x2c0(%r14), %r13
     127: 4d 89 e8                     	movq	%r13, %r8
     12a: 41 89 38                     	movl	%edi, (%r8)
     12d: c1 e1 03                     	shll	$0x3, %ecx
     130: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
     133: 49 8d 3c 0e                  	leaq	(%r14,%rcx), %rdi
     137: 48 81 c7 d0 02 00 00         	addq	$0x2d0, %rdi            # imm = 0x2D0
     13e: 48 89 17                     	movq	%rdx, (%rdi)
     141: 49 8d 94 0e d8 02 00 00      	leaq	0x2d8(%r14,%rcx), %rdx
     149: 48 89 32                     	movq	%rsi, (%rdx)
     14c: 49 8d 94 0e e0 02 00 00      	leaq	0x2e0(%r14,%rcx), %rdx
     154: c6 02 03                     	movb	$0x3, (%rdx)
     157: 49 8d 94 0e e1 02 00 00      	leaq	0x2e1(%r14,%rcx), %rdx
     15f: 88 02                        	movb	%al, (%rdx)
     161: 49 8d 84 0e e2 02 00 00      	leaq	0x2e2(%r14,%rcx), %rax
     169: c7 00 00 00 00 00            	movl	$0x0, (%rax)
     16f: 49 8d 84 0e e6 02 00 00      	leaq	0x2e6(%r14,%rcx), %rax
     177: 66 c7 00 00 00               	movw	$0x0, (%rax)
     17c: c7 44 24 50 00 00 00 00      	movl	$0x0, 0x50(%rsp)
     184: 4c 89 f0                     	movq	%r14, %rax
     187: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
     18e: 48 89 84 24 a0 00 00 00      	movq	%rax, 0xa0(%rsp)
     196: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
     19b: 4c 89 f0                     	movq	%r14, %rax
     19e: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
     1a5: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
     1ac: 48 8d 6c 24 58               	leaq	0x58(%rsp), %rbp
     1b1: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
     1b6: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1bd <trusted_x86_x86_sim_xdp+0x1bd>
		00000000000001b9:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
     1bd: 48 89 ef                     	movq	%rbp, %rdi
     1c0: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1c7 <trusted_x86_x86_sim_xdp+0x1c7>
		00000000000001c3:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     1c7: 75 16                        	jne	0x1df <trusted_x86_x86_sim_xdp+0x1df>
     1c9: e8 00 00 00 00               	callq	0x1ce <trusted_x86_x86_sim_xdp+0x1ce>
		00000000000001ca:  R_X86_64_PLT32	.text+0x5c
     1ce: ba 08 00 00 00               	movl	$0x8, %edx
     1d3: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
     1d8: 48 85 c0                     	testq	%rax, %rax
     1db: 75 35                        	jne	0x212 <trusted_x86_x86_sim_xdp+0x212>
     1dd: eb 52                        	jmp	0x231 <trusted_x86_x86_sim_xdp+0x231>
     1df: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1e6 <trusted_x86_x86_sim_xdp+0x1e6>
		00000000000001e2:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     1e6: 75 16                        	jne	0x1fe <trusted_x86_x86_sim_xdp+0x1fe>
     1e8: e8 00 00 00 00               	callq	0x1ed <trusted_x86_x86_sim_xdp+0x1ed>
		00000000000001e9:  R_X86_64_PLT32	.text+0x10c
     1ed: ba 08 00 00 00               	movl	$0x8, %edx
     1f2: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
     1f7: 48 85 c0                     	testq	%rax, %rax
     1fa: 75 16                        	jne	0x212 <trusted_x86_x86_sim_xdp+0x212>
     1fc: eb 33                        	jmp	0x231 <trusted_x86_x86_sim_xdp+0x231>
     1fe: e8 00 00 00 00               	callq	0x203 <trusted_x86_x86_sim_xdp+0x203>
		00000000000001ff:  R_X86_64_PLT32	.text+0x1bc
     203: ba 08 00 00 00               	movl	$0x8, %edx
     208: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
     20d: 48 85 c0                     	testq	%rax, %rax
     210: 74 1f                        	je	0x231 <trusted_x86_x86_sim_xdp+0x231>
     212: 48 89 c1                     	movq	%rax, %rcx
     215: 0f b7 49 06                  	movzwl	0x6(%rcx), %ecx
     219: 0f b7 c9                     	movzwl	%cx, %ecx
     21c: 83 c1 f8                     	addl	$-0x8, %ecx
     21f: f7 c1 f0 ff 00 00            	testl	$0xfff0, %ecx           # imm = 0xFFF0
     225: 74 1d                        	je	0x244 <trusted_x86_x86_sim_xdp+0x244>
     227: b9 a1 0f 00 00               	movl	$0xfa1, %ecx            # imm = 0xFA1
     22c: ba 33 00 00 00               	movl	$0x33, %edx
     231: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
     238: 89 10                        	movl	%edx, (%rax)
     23a: 31 ed                        	xorl	%ebp, %ebp
     23c: 41 89 cd                     	movl	%ecx, %r13d
     23f: e9 82 31 00 00               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
     244: 48 89 44 24 20               	movq	%rax, 0x20(%rsp)
     249: 83 e1 0f                     	andl	$0xf, %ecx
     24c: 48 8d 05 00 00 00 00         	leaq	(%rip), %rax            # 0x253 <trusted_x86_x86_sim_xdp+0x253>
		000000000000024f:  R_X86_64_PC32	.data.rel.ro-0x4
     253: 48 8b 3c c8                  	movq	(%rax,%rcx,8), %rdi
     257: 48 8d b4 24 a0 00 00 00      	leaq	0xa0(%rsp), %rsi
     25f: e8 00 00 00 00               	callq	0x264 <trusted_x86_x86_sim_xdp+0x264>
		0000000000000260:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     264: 48 85 c0                     	testq	%rax, %rax
     267: 0f 84 e7 23 00 00            	je	0x2654 <trusted_x86_x86_sim_xdp+0x2654>
     26d: 4c 89 64 24 70               	movq	%r12, 0x70(%rsp)
     272: 48 8b 4c 24 20               	movq	0x20(%rsp), %rcx
     277: 48 89 ca                     	movq	%rcx, %rdx
     27a: 44 8b 22                     	movl	(%rdx), %r12d
     27d: 44 89 64 24 54               	movl	%r12d, 0x54(%rsp)
     282: 4c 89 f2                     	movq	%r14, %rdx
     285: 48 8b 92 18 0f 00 00         	movq	0xf18(%rdx), %rdx
     28c: 48 89 54 24 48               	movq	%rdx, 0x48(%rsp)
     291: 44 0f b7 79 04               	movzwl	0x4(%rcx), %r15d
     296: 45 85 ff                     	testl	%r15d, %r15d
     299: 0f 84 90 04 00 00            	je	0x72f <trusted_x86_x86_sim_xdp+0x72f>
     29f: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
     2a4: 45 01 e7                     	addl	%r12d, %r15d
     2a7: 43 8d 0c 27                  	leal	(%r15,%r12), %ecx
     2ab: d1 e9                        	shrl	%ecx
     2ad: 89 4c 24 2c                  	movl	%ecx, 0x2c(%rsp)
     2b1: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     2b6: 48 89 44 24 40               	movq	%rax, 0x40(%rsp)
     2bb: 48 89 c7                     	movq	%rax, %rdi
     2be: e8 00 00 00 00               	callq	0x2c3 <trusted_x86_x86_sim_xdp+0x2c3>
		00000000000002bf:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     2c3: 41 bd a3 0f 00 00            	movl	$0xfa3, %r13d           # imm = 0xFA3
     2c9: be 09 00 00 00               	movl	$0x9, %esi
     2ce: 48 85 c0                     	testq	%rax, %rax
     2d1: 0f 84 df 30 00 00            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
     2d7: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     2db: 8d 69 01                     	leal	0x1(%rcx), %ebp
     2de: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     2e3: 0f b7 00                     	movzwl	(%rax), %eax
     2e6: 48 39 c2                     	cmpq	%rax, %rdx
     2e9: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     2ed: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     2f1: 44 39 fd                     	cmpl	%r15d, %ebp
     2f4: 0f 83 3f 04 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     2fa: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     2fe: d1 e8                        	shrl	%eax
     300: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     304: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     309: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     30e: e8 00 00 00 00               	callq	0x313 <trusted_x86_x86_sim_xdp+0x313>
		000000000000030f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     313: 48 85 c0                     	testq	%rax, %rax
     316: 0f 84 95 30 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     31c: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     320: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     324: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     329: 0f b7 00                     	movzwl	(%rax), %eax
     32c: 48 39 c2                     	cmpq	%rax, %rdx
     32f: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     333: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     337: 45 39 fc                     	cmpl	%r15d, %r12d
     33a: 0f 83 f4 03 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     340: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     344: d1 e8                        	shrl	%eax
     346: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     34a: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     34f: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     354: e8 00 00 00 00               	callq	0x359 <trusted_x86_x86_sim_xdp+0x359>
		0000000000000355:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     359: 48 85 c0                     	testq	%rax, %rax
     35c: 0f 84 4f 30 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     362: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     366: 8d 69 01                     	leal	0x1(%rcx), %ebp
     369: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     36e: 0f b7 00                     	movzwl	(%rax), %eax
     371: 48 39 c2                     	cmpq	%rax, %rdx
     374: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     378: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     37c: 44 39 fd                     	cmpl	%r15d, %ebp
     37f: be 09 00 00 00               	movl	$0x9, %esi
     384: 0f 83 af 03 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     38a: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     38e: d1 e8                        	shrl	%eax
     390: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     394: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     399: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     39e: e8 00 00 00 00               	callq	0x3a3 <trusted_x86_x86_sim_xdp+0x3a3>
		000000000000039f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     3a3: 48 85 c0                     	testq	%rax, %rax
     3a6: 0f 84 05 30 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     3ac: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     3b0: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     3b4: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     3b9: 0f b7 00                     	movzwl	(%rax), %eax
     3bc: 48 39 c2                     	cmpq	%rax, %rdx
     3bf: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     3c3: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     3c7: 45 39 fc                     	cmpl	%r15d, %r12d
     3ca: 0f 83 64 03 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     3d0: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     3d4: d1 e8                        	shrl	%eax
     3d6: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     3da: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     3df: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     3e4: e8 00 00 00 00               	callq	0x3e9 <trusted_x86_x86_sim_xdp+0x3e9>
		00000000000003e5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     3e9: 48 85 c0                     	testq	%rax, %rax
     3ec: 0f 84 bf 2f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     3f2: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     3f6: 8d 69 01                     	leal	0x1(%rcx), %ebp
     3f9: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     3fe: 0f b7 00                     	movzwl	(%rax), %eax
     401: 48 39 c2                     	cmpq	%rax, %rdx
     404: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     408: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     40c: 44 39 fd                     	cmpl	%r15d, %ebp
     40f: be 09 00 00 00               	movl	$0x9, %esi
     414: 0f 83 1f 03 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     41a: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     41e: d1 e8                        	shrl	%eax
     420: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     424: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     429: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     42e: e8 00 00 00 00               	callq	0x433 <trusted_x86_x86_sim_xdp+0x433>
		000000000000042f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     433: 48 85 c0                     	testq	%rax, %rax
     436: 0f 84 75 2f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     43c: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     440: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     444: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     449: 0f b7 00                     	movzwl	(%rax), %eax
     44c: 48 39 c2                     	cmpq	%rax, %rdx
     44f: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     453: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     457: 45 39 fc                     	cmpl	%r15d, %r12d
     45a: 0f 83 d4 02 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     460: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     464: d1 e8                        	shrl	%eax
     466: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     46a: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     46f: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     474: e8 00 00 00 00               	callq	0x479 <trusted_x86_x86_sim_xdp+0x479>
		0000000000000475:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     479: 48 85 c0                     	testq	%rax, %rax
     47c: 0f 84 2f 2f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     482: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     486: 8d 69 01                     	leal	0x1(%rcx), %ebp
     489: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     48e: 0f b7 00                     	movzwl	(%rax), %eax
     491: 48 39 c2                     	cmpq	%rax, %rdx
     494: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     498: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     49c: 44 39 fd                     	cmpl	%r15d, %ebp
     49f: be 09 00 00 00               	movl	$0x9, %esi
     4a4: 0f 83 8f 02 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     4aa: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     4ae: d1 e8                        	shrl	%eax
     4b0: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     4b4: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     4b9: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     4be: e8 00 00 00 00               	callq	0x4c3 <trusted_x86_x86_sim_xdp+0x4c3>
		00000000000004bf:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     4c3: 48 85 c0                     	testq	%rax, %rax
     4c6: 0f 84 e5 2e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     4cc: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     4d0: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     4d4: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     4d9: 0f b7 00                     	movzwl	(%rax), %eax
     4dc: 48 39 c2                     	cmpq	%rax, %rdx
     4df: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     4e3: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     4e7: 45 39 fc                     	cmpl	%r15d, %r12d
     4ea: 0f 83 44 02 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     4f0: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     4f4: d1 e8                        	shrl	%eax
     4f6: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     4fa: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     4ff: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     504: e8 00 00 00 00               	callq	0x509 <trusted_x86_x86_sim_xdp+0x509>
		0000000000000505:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     509: 48 85 c0                     	testq	%rax, %rax
     50c: 0f 84 9f 2e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     512: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     516: 8d 69 01                     	leal	0x1(%rcx), %ebp
     519: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     51e: 0f b7 00                     	movzwl	(%rax), %eax
     521: 48 39 c2                     	cmpq	%rax, %rdx
     524: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     528: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     52c: 44 39 fd                     	cmpl	%r15d, %ebp
     52f: be 09 00 00 00               	movl	$0x9, %esi
     534: 0f 83 ff 01 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     53a: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     53e: d1 e8                        	shrl	%eax
     540: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     544: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     549: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     54e: e8 00 00 00 00               	callq	0x553 <trusted_x86_x86_sim_xdp+0x553>
		000000000000054f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     553: 48 85 c0                     	testq	%rax, %rax
     556: 0f 84 55 2e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     55c: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     560: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     564: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     569: 0f b7 00                     	movzwl	(%rax), %eax
     56c: 48 39 c2                     	cmpq	%rax, %rdx
     56f: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     573: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     577: 45 39 fc                     	cmpl	%r15d, %r12d
     57a: 0f 83 b4 01 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     580: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     584: d1 e8                        	shrl	%eax
     586: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     58a: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     58f: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     594: e8 00 00 00 00               	callq	0x599 <trusted_x86_x86_sim_xdp+0x599>
		0000000000000595:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     599: 48 85 c0                     	testq	%rax, %rax
     59c: 0f 84 0f 2e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     5a2: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     5a6: 8d 69 01                     	leal	0x1(%rcx), %ebp
     5a9: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     5ae: 0f b7 00                     	movzwl	(%rax), %eax
     5b1: 48 39 c2                     	cmpq	%rax, %rdx
     5b4: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     5b8: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     5bc: 44 39 fd                     	cmpl	%r15d, %ebp
     5bf: be 09 00 00 00               	movl	$0x9, %esi
     5c4: 0f 83 6f 01 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     5ca: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     5ce: d1 e8                        	shrl	%eax
     5d0: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     5d4: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     5d9: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     5de: e8 00 00 00 00               	callq	0x5e3 <trusted_x86_x86_sim_xdp+0x5e3>
		00000000000005df:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     5e3: 48 85 c0                     	testq	%rax, %rax
     5e6: 0f 84 c5 2d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     5ec: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     5f0: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     5f4: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     5f9: 0f b7 00                     	movzwl	(%rax), %eax
     5fc: 48 39 c2                     	cmpq	%rax, %rdx
     5ff: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     603: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     607: 45 39 fc                     	cmpl	%r15d, %r12d
     60a: 0f 83 24 01 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     610: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     614: d1 e8                        	shrl	%eax
     616: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     61a: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     61f: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     624: e8 00 00 00 00               	callq	0x629 <trusted_x86_x86_sim_xdp+0x629>
		0000000000000625:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     629: 48 85 c0                     	testq	%rax, %rax
     62c: 0f 84 7f 2d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     632: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     636: 8d 69 01                     	leal	0x1(%rcx), %ebp
     639: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     63e: 0f b7 00                     	movzwl	(%rax), %eax
     641: 48 39 c2                     	cmpq	%rax, %rdx
     644: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     648: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     64c: 44 39 fd                     	cmpl	%r15d, %ebp
     64f: be 09 00 00 00               	movl	$0x9, %esi
     654: 0f 83 df 00 00 00            	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     65a: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     65e: d1 e8                        	shrl	%eax
     660: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     664: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     669: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     66e: e8 00 00 00 00               	callq	0x673 <trusted_x86_x86_sim_xdp+0x673>
		000000000000066f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     673: 48 85 c0                     	testq	%rax, %rax
     676: 0f 84 35 2d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     67c: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     680: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
     684: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     689: 0f b7 00                     	movzwl	(%rax), %eax
     68c: 48 39 c2                     	cmpq	%rax, %rdx
     68f: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
     693: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     697: 45 39 fc                     	cmpl	%r15d, %r12d
     69a: 0f 83 94 00 00 00            	jae	0x734 <trusted_x86_x86_sim_xdp+0x734>
     6a0: 43 8d 04 3c                  	leal	(%r12,%r15), %eax
     6a4: d1 e8                        	shrl	%eax
     6a6: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     6aa: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     6af: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     6b4: e8 00 00 00 00               	callq	0x6b9 <trusted_x86_x86_sim_xdp+0x6b9>
		00000000000006b5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     6b9: 48 85 c0                     	testq	%rax, %rax
     6bc: 0f 84 ef 2c 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     6c2: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     6c6: 8d 69 01                     	leal	0x1(%rcx), %ebp
     6c9: 0f b7 54 24 48               	movzwl	0x48(%rsp), %edx
     6ce: 0f b7 00                     	movzwl	(%rax), %eax
     6d1: 48 39 c2                     	cmpq	%rax, %rdx
     6d4: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
     6d8: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     6dc: 44 39 fd                     	cmpl	%r15d, %ebp
     6df: be 09 00 00 00               	movl	$0x9, %esi
     6e4: 73 53                        	jae	0x739 <trusted_x86_x86_sim_xdp+0x739>
     6e6: 41 8d 04 2f                  	leal	(%r15,%rbp), %eax
     6ea: d1 e8                        	shrl	%eax
     6ec: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
     6f0: 48 8b 7c 24 40               	movq	0x40(%rsp), %rdi
     6f5: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     6fa: e8 00 00 00 00               	callq	0x6ff <trusted_x86_x86_sim_xdp+0x6ff>
		00000000000006fb:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     6ff: 48 85 c0                     	testq	%rax, %rax
     702: 0f 84 a9 2c 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     708: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
     70c: 8d 51 01                     	leal	0x1(%rcx), %edx
     70f: 0f b7 74 24 48               	movzwl	0x48(%rsp), %esi
     714: 0f b7 00                     	movzwl	(%rax), %eax
     717: 48 39 c6                     	cmpq	%rax, %rsi
     71a: 0f 42 d5                     	cmovbl	%ebp, %edx
     71d: 44 0f 42 f9                  	cmovbl	%ecx, %r15d
     721: 44 39 fa                     	cmpl	%r15d, %edx
     724: 0f 83 39 1f 00 00            	jae	0x2663 <trusted_x86_x86_sim_xdp+0x2663>
     72a: e9 82 2c 00 00               	jmp	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
     72f: 45 89 e7                     	movl	%r12d, %r15d
     732: eb 1d                        	jmp	0x751 <trusted_x86_x86_sim_xdp+0x751>
     734: be 09 00 00 00               	movl	$0x9, %esi
     739: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
     73e: 45 85 ff                     	testl	%r15d, %r15d
     741: 0f 84 6f 2c 00 00            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
     747: 48 8d 6c 24 58               	leaq	0x58(%rsp), %rbp
     74c: 4c 8b 6c 24 08               	movq	0x8(%rsp), %r13
     751: 41 ff cf                     	decl	%r15d
     754: 48 8d 74 24 54               	leaq	0x54(%rsp), %rsi
     759: 44 89 7c 24 54               	movl	%r15d, 0x54(%rsp)
     75e: 48 89 c7                     	movq	%rax, %rdi
     761: e8 00 00 00 00               	callq	0x766 <trusted_x86_x86_sim_xdp+0x766>
		0000000000000762:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     766: 48 85 c0                     	testq	%rax, %rax
     769: 0f 84 bc 1e 00 00            	je	0x262b <trusted_x86_x86_sim_xdp+0x262b>
     76f: 0f b7 4c 24 48               	movzwl	0x48(%rsp), %ecx
     774: 48 89 c2                     	movq	%rax, %rdx
     777: 0f b7 12                     	movzwl	(%rdx), %edx
     77a: 29 d1                        	subl	%edx, %ecx
     77c: 8b 54 24 54                  	movl	0x54(%rsp), %edx
     780: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
     785: 8b 36                        	movl	(%rsi), %esi
     787: 44 8d a1 00 00 01 00         	leal	0x10000(%rcx), %r12d
     78e: 39 d6                        	cmpl	%edx, %esi
     790: 44 0f 46 e1                  	cmovbel	%ecx, %r12d
     794: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
     798: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
     79c: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
     7a1: 75 10                        	jne	0x7b3 <trusted_x86_x86_sim_xdp+0x7b3>
     7a3: be 0d 00 00 00               	movl	$0xd, %esi
     7a8: 41 bd a5 0f 00 00            	movl	$0xfa5, %r13d           # imm = 0xFA5
     7ae: e9 03 2c 00 00               	jmp	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
     7b3: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
     7b8: 75 2e                        	jne	0x7e8 <trusted_x86_x86_sim_xdp+0x7e8>
     7ba: c7 44 24 2c 07 00 00 00      	movl	$0x7, 0x2c(%rsp)
     7c2: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
     7c7: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x7ce <trusted_x86_x86_sim_xdp+0x7ce>
		00000000000007ca:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     7ce: e8 00 00 00 00               	callq	0x7d3 <trusted_x86_x86_sim_xdp+0x7d3>
		00000000000007cf:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     7d3: 48 85 c0                     	testq	%rax, %rax
     7d6: 74 0c                        	je	0x7e4 <trusted_x86_x86_sim_xdp+0x7e4>
     7d8: 48 89 c1                     	movq	%rax, %rcx
     7db: 48 8b 09                     	movq	(%rcx), %rcx
     7de: 48 ff c1                     	incq	%rcx
     7e1: 48 89 08                     	movq	%rcx, (%rax)
     7e4: 8b 44 24 50                  	movl	0x50(%rsp), %eax
     7e8: 4c 89 6c 24 08               	movq	%r13, 0x8(%rsp)
     7ed: 49 8d 8e d0 0e 00 00         	leaq	0xed0(%r14), %rcx
     7f4: 48 89 4c 24 20               	movq	%rcx, 0x20(%rsp)
     7f9: 49 8d 8e e0 0e 00 00         	leaq	0xee0(%r14), %rcx
     800: 48 89 4c 24 48               	movq	%rcx, 0x48(%rsp)
     805: 4d 8d be d8 0e 00 00         	leaq	0xed8(%r14), %r15
     80c: 49 8d 96 e8 0e 00 00         	leaq	0xee8(%r14), %rdx
     813: 48 89 94 24 98 01 00 00      	movq	%rdx, 0x198(%rsp)
     81b: 4d 8d ae f0 0e 00 00         	leaq	0xef0(%r14), %r13
     822: 49 8d b6 f8 0e 00 00         	leaq	0xef8(%r14), %rsi
     829: 49 8d 96 08 0f 00 00         	leaq	0xf08(%r14), %rdx
     830: 66 85 c0                     	testw	%ax, %ax
     833: 78 4e                        	js	0x883 <trusted_x86_x86_sim_xdp+0x883>
     835: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
     83d: 4c 89 ac 24 90 00 00 00      	movq	%r13, 0x90(%rsp)
     845: 4c 89 7c 24 78               	movq	%r15, 0x78(%rsp)
     84a: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
     84f: 48 8d 7c 24 50               	leaq	0x50(%rsp), %rdi
     854: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x85b <trusted_x86_x86_sim_xdp+0x85b>
		0000000000000857:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
     85b: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x862 <trusted_x86_x86_sim_xdp+0x862>
		000000000000085e:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     862: 48 89 8c 24 80 01 00 00      	movq	%rcx, 0x180(%rsp)
     86a: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
     872: 48 89 b4 24 88 01 00 00      	movq	%rsi, 0x188(%rsp)
     87a: 75 46                        	jne	0x8c2 <trusted_x86_x86_sim_xdp+0x8c2>
     87c: e8 00 00 00 00               	callq	0x881 <trusted_x86_x86_sim_xdp+0x881>
		000000000000087d:  R_X86_64_PLT32	.text+0x5c
     881: eb 61                        	jmp	0x8e4 <trusted_x86_x86_sim_xdp+0x8e4>
     883: 4c 89 ac 24 78 01 00 00      	movq	%r13, 0x178(%rsp)
     88b: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
     890: ff c8                        	decl	%eax
     892: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
     897: 45 31 ed                     	xorl	%r13d, %r13d
     89a: 83 f8 03                     	cmpl	$0x3, %eax
     89d: 0f 87 f6 2c 00 00            	ja	0x3599 <trusted_x86_x86_sim_xdp+0x3599>
     8a3: 48 89 8c 24 80 01 00 00      	movq	%rcx, 0x180(%rsp)
     8ab: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x8b2 <trusted_x86_x86_sim_xdp+0x8b2>
		00000000000008ae:  R_X86_64_PC32	.rodata-0x4
     8b2: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
     8b6: 48 01 c8                     	addq	%rcx, %rax
     8b9: ff e0                        	jmpq	*%rax
     8bb: 31 ed                        	xorl	%ebp, %ebp
     8bd: e9 04 2b 00 00               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
     8c2: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x8c9 <trusted_x86_x86_sim_xdp+0x8c9>
		00000000000008c5:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     8c9: 75 07                        	jne	0x8d2 <trusted_x86_x86_sim_xdp+0x8d2>
     8cb: e8 00 00 00 00               	callq	0x8d0 <trusted_x86_x86_sim_xdp+0x8d0>
		00000000000008cc:  R_X86_64_PLT32	.text+0x10c
     8d0: eb 12                        	jmp	0x8e4 <trusted_x86_x86_sim_xdp+0x8e4>
     8d2: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x8d9 <trusted_x86_x86_sim_xdp+0x8d9>
		00000000000008d5:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
     8d9: 0f 85 5f 02 00 00            	jne	0xb3e <trusted_x86_x86_sim_xdp+0xb3e>
     8df: e8 00 00 00 00               	callq	0x8e4 <trusted_x86_x86_sim_xdp+0x8e4>
		00000000000008e0:  R_X86_64_PLT32	.text+0x1bc
     8e4: 48 85 c0                     	testq	%rax, %rax
     8e7: 0f 84 d2 2e 00 00            	je	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
     8ed: 4c 89 ac 24 78 01 00 00      	movq	%r13, 0x178(%rsp)
     8f5: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
     8fd: 48 89 8c 24 80 00 00 00      	movq	%rcx, 0x80(%rsp)
     905: 48 89 c1                     	movq	%rax, %rcx
     908: 44 8b 69 04                  	movl	0x4(%rcx), %r13d
     90c: 48 89 c1                     	movq	%rax, %rcx
     90f: 0f b6 51 02                  	movzbl	0x2(%rcx), %edx
     913: 85 d2                        	testl	%edx, %edx
     915: 74 28                        	je	0x93f <trusted_x86_x86_sim_xdp+0x93f>
     917: 89 d6                        	movl	%edx, %esi
     919: 83 e6 7f                     	andl	$0x7f, %esi
     91c: 49 c1 e4 20                  	shlq	$0x20, %r12
     920: 48 c1 e6 20                  	shlq	$0x20, %rsi
     924: 48 8b 4c 24 40               	movq	0x40(%rsp), %rcx
     929: 49 39 f4                     	cmpq	%rsi, %r12
     92c: 7c 16                        	jl	0x944 <trusted_x86_x86_sim_xdp+0x944>
     92e: f7 d2                        	notl	%edx
     930: c1 ea 03                     	shrl	$0x3, %edx
     933: 83 e2 10                     	andl	$0x10, %edx
     936: 41 01 d5                     	addl	%edx, %r13d
     939: 41 83 c5 f8                  	addl	$-0x8, %r13d
     93d: eb 05                        	jmp	0x944 <trusted_x86_x86_sim_xdp+0x944>
     93f: 48 8b 4c 24 40               	movq	0x40(%rsp), %rcx
     944: 4c 8b 64 24 48               	movq	0x48(%rsp), %r12
     949: 48 89 c2                     	movq	%rax, %rdx
     94c: 0f b6 12                     	movzbl	(%rdx), %edx
     94f: 44 89 ee                     	movl	%r13d, %esi
     952: 83 e6 f8                     	andl	$-0x8, %esi
     955: 84 d2                        	testb	%dl, %dl
     957: 41 0f 49 f5                  	cmovnsl	%r13d, %esi
     95b: 89 d7                        	movl	%edx, %edi
     95d: 83 e7 7f                     	andl	$0x7f, %edi
     960: 44 8d 47 ff                  	leal	-0x1(%rdi), %r8d
     964: 41 83 f8 04                  	cmpl	$0x4, %r8d
     968: 0f 87 76 02 00 00            	ja	0xbe4 <trusted_x86_x86_sim_xdp+0xbe4>
     96e: 40 0f b6 ff                  	movzbl	%dil, %edi
     972: 31 ed                        	xorl	%ebp, %ebp
     974: ff cf                        	decl	%edi
     976: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0x97d <trusted_x86_x86_sim_xdp+0x97d>
		0000000000000979:  R_X86_64_PC32	.rodata+0xc
     97d: 4d 63 0c b8                  	movslq	(%r8,%rdi,4), %r9
     981: 4d 01 c1                     	addq	%r8, %r9
     984: 4c 89 e7                     	movq	%r12, %rdi
     987: 41 ff e1                     	jmpq	*%r9
     98a: 31 ff                        	xorl	%edi, %edi
     98c: e9 5f 02 00 00               	jmp	0xbf0 <trusted_x86_x86_sim_xdp+0xbf0>
     991: 48 89 b4 24 88 01 00 00      	movq	%rsi, 0x188(%rsp)
     999: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
     9a1: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
     9a9: 48 89 84 24 90 00 00 00      	movq	%rax, 0x90(%rsp)
     9b1: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
     9b9: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
     9be: 4c 89 7c 24 78               	movq	%r15, 0x78(%rsp)
     9c3: 4c 89 f8                     	movq	%r15, %rax
     9c6: 48 8b 30                     	movq	(%rax), %rsi
     9c9: 48 83 c6 28                  	addq	$0x28, %rsi
     9cd: ba 90 00 00 00               	movl	$0x90, %edx
     9d2: 48 89 df                     	movq	%rbx, %rdi
     9d5: e8 00 00 00 00               	callq	0x9da <trusted_x86_x86_sim_xdp+0x9da>
		00000000000009d6:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     9da: 49 89 c4                     	movq	%rax, %r12
     9dd: 45 85 e4                     	testl	%r12d, %r12d
     9e0: 79 0f                        	jns	0x9f1 <trusted_x86_x86_sim_xdp+0x9f1>
     9e2: ba 90 00 00 00               	movl	$0x90, %edx
     9e7: 48 89 df                     	movq	%rbx, %rdi
     9ea: 31 f6                        	xorl	%esi, %esi
     9ec: e8 00 00 00 00               	callq	0x9f1 <trusted_x86_x86_sim_xdp+0x9f1>
		00000000000009ed:  R_X86_64_PLT32	memset-0x4
     9f1: 45 85 e4                     	testl	%r12d, %r12d
     9f4: 4c 8b 64 24 20               	movq	0x20(%rsp), %r12
     9f9: 0f 85 5d 03 00 00            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
     9ff: 48 8b 84 24 10 01 00 00      	movq	0x110(%rsp), %rax
     a07: 4c 8b ac 24 98 01 00 00      	movq	0x198(%rsp), %r13
     a0f: 4c 89 e9                     	movq	%r13, %rcx
     a12: 48 89 01                     	movq	%rax, (%rcx)
     a15: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
     a1d: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
     a25: 48 89 01                     	movq	%rax, (%rcx)
     a28: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
     a30: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
     a38: 48 89 01                     	movq	%rax, (%rcx)
     a3b: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
     a43: 49 8d 8e 00 0f 00 00         	leaq	0xf00(%r14), %rcx
     a4a: 48 89 01                     	movq	%rax, (%rcx)
     a4d: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
     a55: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
     a5d: 48 89 01                     	movq	%rax, (%rcx)
     a60: 48 8b 84 24 f8 00 00 00      	movq	0xf8(%rsp), %rax
     a68: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
     a70: 48 89 01                     	movq	%rax, (%rcx)
     a73: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
     a7b: 4c 89 f9                     	movq	%r15, %rcx
     a7e: 48 89 01                     	movq	%rax, (%rcx)
     a81: 48 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %rax
     a89: 4c 89 e1                     	movq	%r12, %rcx
     a8c: 48 89 01                     	movq	%rax, (%rcx)
     a8f: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
     a96: 31 c9                        	xorl	%ecx, %ecx
     a98: e9 0a 03 00 00               	jmp	0xda7 <trusted_x86_x86_sim_xdp+0xda7>
     a9d: 48 89 b4 24 88 01 00 00      	movq	%rsi, 0x188(%rsp)
     aa5: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
     aad: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
     ab5: 48 89 84 24 90 00 00 00      	movq	%rax, 0x90(%rsp)
     abd: 4c 89 7c 24 78               	movq	%r15, 0x78(%rsp)
     ac2: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
     aca: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
     acf: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
     ad4: 48 8b 30                     	movq	(%rax), %rsi
     ad7: ba 10 00 00 00               	movl	$0x10, %edx
     adc: 48 89 ef                     	movq	%rbp, %rdi
     adf: e8 00 00 00 00               	callq	0xae4 <trusted_x86_x86_sim_xdp+0xae4>
		0000000000000ae0:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     ae4: 85 c0                        	testl	%eax, %eax
     ae6: 79 10                        	jns	0xaf8 <trusted_x86_x86_sim_xdp+0xaf8>
     ae8: 48 c7 45 08 00 00 00 00      	movq	$0x0, 0x8(%rbp)
     af0: 48 c7 45 00 00 00 00 00      	movq	$0x0, (%rbp)
     af8: 85 c0                        	testl	%eax, %eax
     afa: 4c 8b 64 24 20               	movq	0x20(%rsp), %r12
     aff: 0f 85 57 02 00 00            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
     b05: 4c 89 f0                     	movq	%r14, %rax
     b08: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
     b0f: 48 83 c0 10                  	addq	$0x10, %rax
     b13: 4c 89 f9                     	movq	%r15, %rcx
     b16: 48 89 01                     	movq	%rax, (%rcx)
     b19: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
     b1e: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
     b26: 48 89 01                     	movq	%rax, (%rcx)
     b29: 48 8b 6c 24 60               	movq	0x60(%rsp), %rbp
     b2e: 4c 89 e0                     	movq	%r12, %rax
     b31: 4c 8b ac 24 98 01 00 00      	movq	0x198(%rsp), %r13
     b39: e9 5d 02 00 00               	jmp	0xd9b <trusted_x86_x86_sim_xdp+0xd9b>
     b3e: 8b 4c 24 50                  	movl	0x50(%rsp), %ecx
     b42: 3b 48 44                     	cmpl	0x44(%rax), %ecx
     b45: 0f 83 74 2c 00 00            	jae	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
     b4b: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
     b51: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
     b57: 48 0f af ca                  	imulq	%rdx, %rcx
     b5b: 48 01 c8                     	addq	%rcx, %rax
     b5e: 48 05 30 01 00 00            	addq	$0x130, %rax            # imm = 0x130
     b64: e9 84 fd ff ff               	jmp	0x8ed <trusted_x86_x86_sim_xdp+0x8ed>
     b69: 48 89 b4 24 88 01 00 00      	movq	%rsi, 0x188(%rsp)
     b71: 48 89 b4 24 88 00 00 00      	movq	%rsi, 0x88(%rsp)
     b79: 48 8b 84 24 78 01 00 00      	movq	0x178(%rsp), %rax
     b81: 48 89 84 24 90 00 00 00      	movq	%rax, 0x90(%rsp)
     b89: 48 89 94 24 90 01 00 00      	movq	%rdx, 0x190(%rsp)
     b91: 48 89 54 24 40               	movq	%rdx, 0x40(%rsp)
     b96: 4c 89 7c 24 78               	movq	%r15, 0x78(%rsp)
     b9b: 4c 89 f8                     	movq	%r15, %rax
     b9e: 48 8b 00                     	movq	(%rax), %rax
     ba1: 4c 8b 64 24 20               	movq	0x20(%rsp), %r12
     ba6: 4c 89 e1                     	movq	%r12, %rcx
     ba9: 8b 09                        	movl	(%rcx), %ecx
     bab: 83 e1 0f                     	andl	$0xf, %ecx
     bae: 31 d2                        	xorl	%edx, %edx
     bb0: 83 f9 0b                     	cmpl	$0xb, %ecx
     bb3: 0f 93 c2                     	setae	%dl
     bb6: 48 8d 2c d0                  	leaq	(%rax,%rdx,8), %rbp
     bba: 48 83 c5 08                  	addq	$0x8, %rbp
     bbe: 4c 8b ac 24 98 01 00 00      	movq	0x198(%rsp), %r13
     bc6: e9 6b 01 00 00               	jmp	0xd36 <trusted_x86_x86_sim_xdp+0xd36>
     bcb: 44 89 ea                     	movl	%r13d, %edx
     bce: 83 e2 0f                     	andl	$0xf, %edx
     bd1: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0xbd8 <trusted_x86_x86_sim_xdp+0xbd8>
		0000000000000bd4:  R_X86_64_PC32	.rodata+0x20
     bd8: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
     bdc: 48 01 f7                     	addq	%rsi, %rdi
     bdf: 48 89 ca                     	movq	%rcx, %rdx
     be2: ff e7                        	jmpq	*%rdi
     be4: 31 ed                        	xorl	%ebp, %ebp
     be6: eb 64                        	jmp	0xc4c <trusted_x86_x86_sim_xdp+0xc4c>
     be8: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
     bed: 48 8b 3f                     	movq	(%rdi), %rdi
     bf0: 48 63 ee                     	movslq	%esi, %rbp
     bf3: 48 01 fd                     	addq	%rdi, %rbp
     bf6: 84 d2                        	testb	%dl, %dl
     bf8: 79 52                        	jns	0xc4c <trusted_x86_x86_sim_xdp+0xc4c>
     bfa: 4c 89 bc 24 70 01 00 00      	movq	%r15, 0x170(%rsp)
     c02: 49 89 c7                     	movq	%rax, %r15
     c05: ba 08 00 00 00               	movl	$0x8, %edx
     c0a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     c0f: 48 89 ee                     	movq	%rbp, %rsi
     c12: e8 00 00 00 00               	callq	0xc17 <trusted_x86_x86_sim_xdp+0xc17>
		0000000000000c13:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     c17: 85 c0                        	testl	%eax, %eax
     c19: 79 09                        	jns	0xc24 <trusted_x86_x86_sim_xdp+0xc24>
     c1b: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
     c24: 85 c0                        	testl	%eax, %eax
     c26: 74 04                        	je	0xc2c <trusted_x86_x86_sim_xdp+0xc2c>
     c28: 31 ed                        	xorl	%ebp, %ebp
     c2a: eb 10                        	jmp	0xc3c <trusted_x86_x86_sim_xdp+0xc3c>
     c2c: 41 c1 e5 03                  	shll	$0x3, %r13d
     c30: 41 83 e5 38                  	andl	$0x38, %r13d
     c34: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
     c39: 4c 89 ed                     	movq	%r13, %rbp
     c3c: 4c 89 f8                     	movq	%r15, %rax
     c3f: 48 8b 4c 24 40               	movq	0x40(%rsp), %rcx
     c44: 4c 8b bc 24 70 01 00 00      	movq	0x170(%rsp), %r15
     c4c: 48 89 c2                     	movq	%rax, %rdx
     c4f: 0f b6 52 01                  	movzbl	0x1(%rdx), %edx
     c53: 48 89 c6                     	movq	%rax, %rsi
     c56: 44 8b 6e 08                  	movl	0x8(%rsi), %r13d
     c5a: 44 89 ee                     	movl	%r13d, %esi
     c5d: 83 e6 f8                     	andl	$-0x8, %esi
     c60: 84 d2                        	testb	%dl, %dl
     c62: 41 0f 49 f5                  	cmovnsl	%r13d, %esi
     c66: 89 d7                        	movl	%edx, %edi
     c68: 83 e7 7f                     	andl	$0x7f, %edi
     c6b: 44 8d 47 ff                  	leal	-0x1(%rdi), %r8d
     c6f: 41 83 f8 04                  	cmpl	$0x4, %r8d
     c73: 0f 87 a1 00 00 00            	ja	0xd1a <trusted_x86_x86_sim_xdp+0xd1a>
     c79: 40 0f b6 ff                  	movzbl	%dil, %edi
     c7d: ff cf                        	decl	%edi
     c7f: 4c 8d 05 00 00 00 00         	leaq	(%rip), %r8             # 0xc86 <trusted_x86_x86_sim_xdp+0xc86>
		0000000000000c82:  R_X86_64_PC32	.rodata+0x60
     c86: 4d 63 0c b8                  	movslq	(%r8,%rdi,4), %r9
     c8a: 4d 01 c1                     	addq	%r8, %r9
     c8d: 4c 89 e7                     	movq	%r12, %rdi
     c90: 49 89 e8                     	movq	%rbp, %r8
     c93: 41 ff e1                     	jmpq	*%r9
     c96: 48 8b 7c 24 78               	movq	0x78(%rsp), %rdi
     c9b: 4c 8b 07                     	movq	(%rdi), %r8
     c9e: 48 63 f6                     	movslq	%esi, %rsi
     ca1: 4c 01 c6                     	addq	%r8, %rsi
     ca4: 84 d2                        	testb	%dl, %dl
     ca6: 78 20                        	js	0xcc8 <trusted_x86_x86_sim_xdp+0xcc8>
     ca8: 4c 8b ac 24 80 00 00 00      	movq	0x80(%rsp), %r13
     cb0: 48 85 f6                     	testq	%rsi, %rsi
     cb3: 74 6d                        	je	0xd22 <trusted_x86_x86_sim_xdp+0xd22>
     cb5: ba 08 00 00 00               	movl	$0x8, %edx
     cba: 4c 89 e7                     	movq	%r12, %rdi
     cbd: e8 00 00 00 00               	callq	0xcc2 <trusted_x86_x86_sim_xdp+0xcc2>
		0000000000000cbe:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     cc2: 85 c0                        	testl	%eax, %eax
     cc4: 78 63                        	js	0xd29 <trusted_x86_x86_sim_xdp+0xd29>
     cc6: eb 69                        	jmp	0xd31 <trusted_x86_x86_sim_xdp+0xd31>
     cc8: 4c 89 bc 24 70 01 00 00      	movq	%r15, 0x170(%rsp)
     cd0: 49 89 c7                     	movq	%rax, %r15
     cd3: ba 08 00 00 00               	movl	$0x8, %edx
     cd8: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
     cdd: e8 00 00 00 00               	callq	0xce2 <trusted_x86_x86_sim_xdp+0xce2>
		0000000000000cde:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     ce2: 85 c0                        	testl	%eax, %eax
     ce4: 79 09                        	jns	0xcef <trusted_x86_x86_sim_xdp+0xcef>
     ce6: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
     cef: 85 c0                        	testl	%eax, %eax
     cf1: 4c 89 f8                     	movq	%r15, %rax
     cf4: 0f 84 ef 01 00 00            	je	0xee9 <trusted_x86_x86_sim_xdp+0xee9>
     cfa: 4c 8b bc 24 70 01 00 00      	movq	0x170(%rsp), %r15
     d02: eb 16                        	jmp	0xd1a <trusted_x86_x86_sim_xdp+0xd1a>
     d04: 44 89 ea                     	movl	%r13d, %edx
     d07: 83 e2 0f                     	andl	$0xf, %edx
     d0a: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0xd11 <trusted_x86_x86_sim_xdp+0xd11>
		0000000000000d0d:  R_X86_64_PC32	.rodata+0x74
     d11: 48 63 14 96                  	movslq	(%rsi,%rdx,4), %rdx
     d15: 48 01 f2                     	addq	%rsi, %rdx
     d18: ff e2                        	jmpq	*%rdx
     d1a: 4c 8b ac 24 80 00 00 00      	movq	0x80(%rsp), %r13
     d22: 0f b6 00                     	movzbl	(%rax), %eax
     d25: 3c 03                        	cmpb	$0x3, %al
     d27: 75 08                        	jne	0xd31 <trusted_x86_x86_sim_xdp+0xd31>
     d29: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
     d31: 4c 8b 64 24 20               	movq	0x20(%rsp), %r12
     d36: 48 85 ed                     	testq	%rbp, %rbp
     d39: 74 21                        	je	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
     d3b: 48 8d 75 f8                  	leaq	-0x8(%rbp), %rsi
     d3f: ba 08 00 00 00               	movl	$0x8, %edx
     d44: 4c 89 e7                     	movq	%r12, %rdi
     d47: e8 00 00 00 00               	callq	0xd4c <trusted_x86_x86_sim_xdp+0xd4c>
		0000000000000d48:  R_X86_64_PLT32	copy_from_user_nofault-0x4
     d4c: 85 c0                        	testl	%eax, %eax
     d4e: 79 08                        	jns	0xd58 <trusted_x86_x86_sim_xdp+0xd58>
     d50: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
     d58: 85 c0                        	testl	%eax, %eax
     d5a: 74 3c                        	je	0xd98 <trusted_x86_x86_sim_xdp+0xd98>
     d5c: c7 44 24 58 0e 00 00 00      	movl	$0xe, 0x58(%rsp)
     d64: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xd6b <trusted_x86_x86_sim_xdp+0xd6b>
		0000000000000d67:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     d6b: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
     d70: e8 00 00 00 00               	callq	0xd75 <trusted_x86_x86_sim_xdp+0xd75>
		0000000000000d71:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     d75: 48 85 c0                     	testq	%rax, %rax
     d78: 74 0c                        	je	0xd86 <trusted_x86_x86_sim_xdp+0xd86>
     d7a: 48 89 c1                     	movq	%rax, %rcx
     d7d: 48 8b 09                     	movq	(%rcx), %rcx
     d80: 48 ff c1                     	incq	%rcx
     d83: 48 89 08                     	movq	%rcx, (%rax)
     d86: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
     d8b: 41 bd a7 0f 00 00            	movl	$0xfa7, %r13d           # imm = 0xFA7
     d91: 31 ed                        	xorl	%ebp, %ebp
     d93: e9 2e 26 00 00               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
     d98: 4c 89 f8                     	movq	%r15, %rax
     d9b: 48 89 28                     	movq	%rbp, (%rax)
     d9e: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
     da5: b1 01                        	movb	$0x1, %cl
     da7: 88 08                        	movb	%cl, (%rax)
     da9: 4c 89 ac 24 80 00 00 00      	movq	%r13, 0x80(%rsp)
     db1: c7 44 24 58 06 00 00 00      	movl	$0x6, 0x58(%rsp)
     db9: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xdc0 <trusted_x86_x86_sim_xdp+0xdc0>
		0000000000000dbc:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     dc0: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
     dc5: e8 00 00 00 00               	callq	0xdca <trusted_x86_x86_sim_xdp+0xdca>
		0000000000000dc6:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     dca: 48 85 c0                     	testq	%rax, %rax
     dcd: 74 0c                        	je	0xddb <trusted_x86_x86_sim_xdp+0xddb>
     dcf: 48 89 c1                     	movq	%rax, %rcx
     dd2: 48 8b 09                     	movq	(%rcx), %rcx
     dd5: 48 ff c1                     	incq	%rcx
     dd8: 48 89 08                     	movq	%rcx, (%rax)
     ddb: 4d 8b 2c 24                  	movq	(%r12), %r13
     ddf: 4d 85 ed                     	testq	%r13, %r13
     de2: 0f 84 46 2d 00 00            	je	0x3b2e <trusted_x86_x86_sim_xdp+0x3b2e>
     de8: 4c 89 e8                     	movq	%r13, %rax
     deb: 48 c1 e8 38                  	shrq	$0x38, %rax
     def: 74 18                        	je	0xe09 <trusted_x86_x86_sim_xdp+0xe09>
     df1: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
     df8: c7 00 0b 00 00 00            	movl	$0xb, (%rax)
     dfe: 41 bd ab 0f 00 00            	movl	$0xfab, %r13d           # imm = 0xFAB
     e04: e9 38 2d 00 00               	jmp	0x3b41 <trusted_x86_x86_sim_xdp+0x3b41>
     e09: 49 81 fd ff 0f 00 00         	cmpq	$0xfff, %r13            # imm = 0xFFF
     e10: 77 18                        	ja	0xe2a <trusted_x86_x86_sim_xdp+0xe2a>
     e12: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
     e19: c7 00 31 00 00 00            	movl	$0x31, (%rax)
     e1f: 41 bd ae 0f 00 00            	movl	$0xfae, %r13d           # imm = 0xFAE
     e25: e9 17 2d 00 00               	jmp	0x3b41 <trusted_x86_x86_sim_xdp+0x3b41>
     e2a: 4c 89 f0                     	movq	%r14, %rax
     e2d: 8b 00                        	movl	(%rax), %eax
     e2f: c7 84 24 a8 00 00 00 60 00 00 00     	movl	$0x60, 0xa8(%rsp)
     e3a: 0f 38 f1 84 24 ac 00 00 00   	movbel	%eax, 0xac(%rsp)
     e43: 4c 0f 38 f1 ac 24 b0 00 00 00	movbeq	%r13, 0xb0(%rsp)
     e4d: 48 89 df                     	movq	%rbx, %rdi
     e50: e8 00 00 00 00               	callq	0xe55 <trusted_x86_x86_sim_xdp+0xe55>
		0000000000000e51:  R_X86_64_PLT32	.text+0x5c
     e55: 48 85 c0                     	testq	%rax, %rax
     e58: 0f 84 ef 2c 00 00            	je	0x3b4d <trusted_x86_x86_sim_xdp+0x3b4d>
     e5e: 4c 89 bc 24 70 01 00 00      	movq	%r15, 0x170(%rsp)
     e66: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
     e70: 48 89 c1                     	movq	%rax, %rcx
     e73: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
     e77: 48 89 e9                     	movq	%rbp, %rcx
     e7a: 48 21 d1                     	andq	%rdx, %rcx
     e7d: 49 8d 96 20 0f 00 00         	leaq	0xf20(%r14), %rdx
     e84: 48 89 94 24 b0 01 00 00      	movq	%rdx, 0x1b0(%rsp)
     e8c: 48 89 0a                     	movq	%rcx, (%rdx)
     e8f: 48 c1 ed 38                  	shrq	$0x38, %rbp
     e93: 48 8b 00                     	movq	(%rax), %rax
     e96: 49 8d 96 10 0f 00 00         	leaq	0xf10(%r14), %rdx
     e9d: 48 89 94 24 a0 01 00 00      	movq	%rdx, 0x1a0(%rsp)
     ea5: 48 89 02                     	movq	%rax, (%rdx)
     ea8: 49 29 cd                     	subq	%rcx, %r13
     eab: 49 8d 8e 18 0f 00 00         	leaq	0xf18(%r14), %rcx
     eb2: 48 89 8c 24 a8 01 00 00      	movq	%rcx, 0x1a8(%rsp)
     eba: 4c 89 29                     	movq	%r13, (%rcx)
     ebd: 48 83 fd 01                  	cmpq	$0x1, %rbp
     ec1: 0f 85 bf 00 00 00            	jne	0xf86 <trusted_x86_x86_sim_xdp+0xf86>
     ec7: 48 89 84 24 a8 00 00 00      	movq	%rax, 0xa8(%rsp)
     ecf: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0xed6 <trusted_x86_x86_sim_xdp+0xed6>
		0000000000000ed2:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
     ed6: 48 89 df                     	movq	%rbx, %rdi
     ed9: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0xee0 <trusted_x86_x86_sim_xdp+0xee0>
		0000000000000edc:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
     ee0: 75 24                        	jne	0xf06 <trusted_x86_x86_sim_xdp+0xf06>
     ee2: e8 00 00 00 00               	callq	0xee7 <trusted_x86_x86_sim_xdp+0xee7>
		0000000000000ee3:  R_X86_64_PLT32	.text+0x5c
     ee7: eb 22                        	jmp	0xf0b <trusted_x86_x86_sim_xdp+0xf0b>
     ee9: 41 c1 e5 03                  	shll	$0x3, %r13d
     eed: 41 83 e5 38                  	andl	$0x38, %r13d
     ef1: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
     ef6: 4c 89 ee                     	movq	%r13, %rsi
     ef9: 4c 8b bc 24 70 01 00 00      	movq	0x170(%rsp), %r15
     f01: e9 a2 fd ff ff               	jmp	0xca8 <trusted_x86_x86_sim_xdp+0xca8>
     f06: e8 00 00 00 00               	callq	0xf0b <trusted_x86_x86_sim_xdp+0xf0b>
		0000000000000f07:  R_X86_64_PLT32	.text+0x10c
     f0b: 49 89 c4                     	movq	%rax, %r12
     f0e: 48 85 c0                     	testq	%rax, %rax
     f11: 74 7f                        	je	0xf92 <trusted_x86_x86_sim_xdp+0xf92>
     f13: 4c 89 e0                     	movq	%r12, %rax
     f16: 48 8b 00                     	movq	(%rax), %rax
     f19: 4c 39 e8                     	cmpq	%r13, %rax
     f1c: 77 0c                        	ja	0xf2a <trusted_x86_x86_sim_xdp+0xf2a>
     f1e: 4c 89 e0                     	movq	%r12, %rax
     f21: 48 8b 40 08                  	movq	0x8(%rax), %rax
     f25: 4c 39 e8                     	cmpq	%r13, %rax
     f28: 73 18                        	jae	0xf42 <trusted_x86_x86_sim_xdp+0xf42>
     f2a: 4c 89 e0                     	movq	%r12, %rax
     f2d: 48 8b 40 10                  	movq	0x10(%rax), %rax
     f31: 4c 39 e8                     	cmpq	%r13, %rax
     f34: 77 5c                        	ja	0xf92 <trusted_x86_x86_sim_xdp+0xf92>
     f36: 4c 89 e0                     	movq	%r12, %rax
     f39: 48 8b 40 18                  	movq	0x18(%rax), %rax
     f3d: 4c 39 e8                     	cmpq	%r13, %rax
     f40: 72 50                        	jb	0xf92 <trusted_x86_x86_sim_xdp+0xf92>
     f42: 4c 89 f0                     	movq	%r14, %rax
     f45: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
     f4b: 4c 89 e1                     	movq	%r12, %rcx
     f4e: 8b 49 20                     	movl	0x20(%rcx), %ecx
     f51: 0f a3 c8                     	btl	%ecx, %eax
     f54: 72 3c                        	jb	0xf92 <trusted_x86_x86_sim_xdp+0xf92>
     f56: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
     f5e: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xf65 <trusted_x86_x86_sim_xdp+0xf65>
		0000000000000f61:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     f65: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
     f6a: e8 00 00 00 00               	callq	0xf6f <trusted_x86_x86_sim_xdp+0xf6f>
		0000000000000f6b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     f6f: 48 85 c0                     	testq	%rax, %rax
     f72: 74 0c                        	je	0xf80 <trusted_x86_x86_sim_xdp+0xf80>
     f74: 48 89 c1                     	movq	%rax, %rcx
     f77: 48 8b 09                     	movq	(%rcx), %rcx
     f7a: 48 ff c1                     	incq	%rcx
     f7d: 48 89 08                     	movq	%rcx, (%rax)
     f80: 41 0f b7 6c 24 20            	movzwl	0x20(%r12), %ebp
     f86: 45 31 ed                     	xorl	%r13d, %r13d
     f89: 83 fd 01                     	cmpl	$0x1, %ebp
     f8c: 0f 85 b1 2b 00 00            	jne	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
     f92: 48 8b 44 24 20               	movq	0x20(%rsp), %rax
     f97: 48 89 84 24 98 00 00 00      	movq	%rax, 0x98(%rsp)
     f9f: c7 84 24 a8 00 00 00 05 00 00 00     	movl	$0x5, 0xa8(%rsp)
     faa: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0xfb1 <trusted_x86_x86_sim_xdp+0xfb1>
		0000000000000fad:  R_X86_64_REX_GOTPCRELX	metrics-0x4
     fb1: 48 89 de                     	movq	%rbx, %rsi
     fb4: e8 00 00 00 00               	callq	0xfb9 <trusted_x86_x86_sim_xdp+0xfb9>
		0000000000000fb5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
     fb9: 48 85 c0                     	testq	%rax, %rax
     fbc: 74 0c                        	je	0xfca <trusted_x86_x86_sim_xdp+0xfca>
     fbe: 48 89 c1                     	movq	%rax, %rcx
     fc1: 48 8b 09                     	movq	(%rcx), %rcx
     fc4: 48 ff c1                     	incq	%rcx
     fc7: 48 89 08                     	movq	%rcx, (%rax)
     fca: 4c 89 f0                     	movq	%r14, %rax
     fcd: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
     fd3: 83 f9 7e                     	cmpl	$0x7e, %ecx
     fd6: 0f 87 2b 0f 00 00            	ja	0x1f07 <trusted_x86_x86_sim_xdp+0x1f07>
     fdc: 4d 8d ae d0 02 00 00         	leaq	0x2d0(%r14), %r13
     fe3: 4d 8d a6 d8 02 00 00         	leaq	0x2d8(%r14), %r12
     fea: 4d 8d be e0 02 00 00         	leaq	0x2e0(%r14), %r15
     ff1: 4d 8d 9e e1 02 00 00         	leaq	0x2e1(%r14), %r11
     ff8: 4d 8d 96 e2 02 00 00         	leaq	0x2e2(%r14), %r10
     fff: 4d 8d 8e e6 02 00 00         	leaq	0x2e6(%r14), %r9
    1006: 4c 89 f0                     	movq	%r14, %rax
    1009: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    1010: 4c 89 f2                     	movq	%r14, %rdx
    1013: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    101a: 4c 89 f6                     	movq	%r14, %rsi
    101d: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    1024: 8d 79 01                     	leal	0x1(%rcx), %edi
    1027: 4c 8b 44 24 08               	movq	0x8(%rsp), %r8
    102c: 41 89 38                     	movl	%edi, (%r8)
    102f: c1 e1 03                     	shll	$0x3, %ecx
    1032: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    1035: 4c 89 ac 24 c8 01 00 00      	movq	%r13, 0x1c8(%rsp)
    103d: 4a 8d 3c 29                  	leaq	(%rcx,%r13), %rdi
    1041: 48 89 17                     	movq	%rdx, (%rdi)
    1044: 4c 89 a4 24 d0 01 00 00      	movq	%r12, 0x1d0(%rsp)
    104c: 49 8d 14 0c                  	leaq	(%r12,%rcx), %rdx
    1050: 48 89 32                     	movq	%rsi, (%rdx)
    1053: 4c 89 bc 24 d8 01 00 00      	movq	%r15, 0x1d8(%rsp)
    105b: 49 8d 14 0f                  	leaq	(%r15,%rcx), %rdx
    105f: c6 02 03                     	movb	$0x3, (%rdx)
    1062: 4c 89 9c 24 e0 01 00 00      	movq	%r11, 0x1e0(%rsp)
    106a: 49 8d 14 0b                  	leaq	(%r11,%rcx), %rdx
    106e: 88 02                        	movb	%al, (%rdx)
    1070: 4c 89 94 24 e8 01 00 00      	movq	%r10, 0x1e8(%rsp)
    1078: 49 8d 04 0a                  	leaq	(%r10,%rcx), %rax
    107c: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    1082: 4c 89 8c 24 f0 01 00 00      	movq	%r9, 0x1f0(%rsp)
    108a: 4c 01 c9                     	addq	%r9, %rcx
    108d: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    1092: c7 44 24 50 00 00 00 00      	movl	$0x0, 0x50(%rsp)
    109a: 4c 89 f0                     	movq	%r14, %rax
    109d: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    10a4: 48 89 84 24 a0 00 00 00      	movq	%rax, 0xa0(%rsp)
    10ac: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    10b1: 4c 89 f0                     	movq	%r14, %rax
    10b4: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    10bb: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    10c2: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
    10c7: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x10ce <trusted_x86_x86_sim_xdp+0x10ce>
		00000000000010ca:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    10ce: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x10d5 <trusted_x86_x86_sim_xdp+0x10d5>
		00000000000010d1:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    10d5: 75 0f                        	jne	0x10e6 <trusted_x86_x86_sim_xdp+0x10e6>
    10d7: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    10dc: e8 00 00 00 00               	callq	0x10e1 <trusted_x86_x86_sim_xdp+0x10e1>
		00000000000010dd:  R_X86_64_PLT32	.text+0x5c
    10e1: e9 91 00 00 00               	jmp	0x1177 <trusted_x86_x86_sim_xdp+0x1177>
    10e6: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x10ed <trusted_x86_x86_sim_xdp+0x10ed>
		00000000000010e9:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    10ed: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    10f2: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x10f9 <trusted_x86_x86_sim_xdp+0x10f9>
		00000000000010f5:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    10f9: 75 77                        	jne	0x1172 <trusted_x86_x86_sim_xdp+0x1172>
    10fb: e8 00 00 00 00               	callq	0x1100 <trusted_x86_x86_sim_xdp+0x1100>
		00000000000010fc:  R_X86_64_PLT32	.text+0x10c
    1100: eb 75                        	jmp	0x1177 <trusted_x86_x86_sim_xdp+0x1177>
    1102: 48 8b 94 24 90 00 00 00      	movq	0x90(%rsp), %rdx
    110a: eb 26                        	jmp	0x1132 <trusted_x86_x86_sim_xdp+0x1132>
    110c: 48 8b 8c 24 90 00 00 00      	movq	0x90(%rsp), %rcx
    1114: eb 40                        	jmp	0x1156 <trusted_x86_x86_sim_xdp+0x1156>
    1116: 48 8b 94 24 88 00 00 00      	movq	0x88(%rsp), %rdx
    111e: eb 12                        	jmp	0x1132 <trusted_x86_x86_sim_xdp+0x1132>
    1120: 48 8b 8c 24 88 00 00 00      	movq	0x88(%rsp), %rcx
    1128: eb 2c                        	jmp	0x1156 <trusted_x86_x86_sim_xdp+0x1156>
    112a: 48 8b 94 24 80 00 00 00      	movq	0x80(%rsp), %rdx
    1132: 44 89 ee                     	movl	%r13d, %esi
    1135: 81 e6 00 00 00 80            	andl	$0x80000000, %esi       # imm = 0x80000000
    113b: 41 c1 ed 04                  	shrl	$0x4, %r13d
    113f: 42 8d 34 ee                  	leal	(%rsi,%r13,8), %esi
    1143: 48 63 ee                     	movslq	%esi, %rbp
    1146: 48 03 2a                     	addq	(%rdx), %rbp
    1149: e9 fe fa ff ff               	jmp	0xc4c <trusted_x86_x86_sim_xdp+0xc4c>
    114e: 48 8b 8c 24 80 00 00 00      	movq	0x80(%rsp), %rcx
    1156: 44 89 ea                     	movl	%r13d, %edx
    1159: 81 e2 00 00 00 80            	andl	$0x80000000, %edx       # imm = 0x80000000
    115f: 41 c1 ed 04                  	shrl	$0x4, %r13d
    1163: 42 8d 14 ea                  	leal	(%rdx,%r13,8), %edx
    1167: 48 63 f2                     	movslq	%edx, %rsi
    116a: 48 03 31                     	addq	(%rcx), %rsi
    116d: e9 36 fb ff ff               	jmp	0xca8 <trusted_x86_x86_sim_xdp+0xca8>
    1172: e8 00 00 00 00               	callq	0x1177 <trusted_x86_x86_sim_xdp+0x1177>
		0000000000001173:  R_X86_64_PLT32	.text+0x1bc
    1177: 49 89 c4                     	movq	%rax, %r12
    117a: 48 85 c0                     	testq	%rax, %rax
    117d: 0f 84 b8 14 00 00            	je	0x263b <trusted_x86_x86_sim_xdp+0x263b>
    1183: 4c 89 e0                     	movq	%r12, %rax
    1186: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    118a: 0f b7 c0                     	movzwl	%ax, %eax
    118d: 83 c0 f8                     	addl	$-0x8, %eax
    1190: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    1195: 74 0a                        	je	0x11a1 <trusted_x86_x86_sim_xdp+0x11a1>
    1197: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    119c: e9 86 f0 ff ff               	jmp	0x227 <trusted_x86_x86_sim_xdp+0x227>
    11a1: 83 e0 0f                     	andl	$0xf, %eax
    11a4: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x11ab <trusted_x86_x86_sim_xdp+0x11ab>
		00000000000011a7:  R_X86_64_PC32	.data.rel.ro-0x4
    11ab: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    11af: 48 8d b4 24 a0 00 00 00      	leaq	0xa0(%rsp), %rsi
    11b7: e8 00 00 00 00               	callq	0x11bc <trusted_x86_x86_sim_xdp+0x11bc>
		00000000000011b8:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    11bc: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    11c1: 48 85 c0                     	testq	%rax, %rax
    11c4: 0f 84 85 14 00 00            	je	0x264f <trusted_x86_x86_sim_xdp+0x264f>
    11ca: 4c 89 e1                     	movq	%r12, %rcx
    11cd: 4c 89 e0                     	movq	%r12, %rax
    11d0: 8b 28                        	movl	(%rax), %ebp
    11d2: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    11d6: 4c 89 f0                     	movq	%r14, %rax
    11d9: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    11e0: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    11e5: 4c 89 e0                     	movq	%r12, %rax
    11e8: 0f b7 48 04                  	movzwl	0x4(%rax), %ecx
    11ec: 85 c9                        	testl	%ecx, %ecx
    11ee: 0f 84 64 05 00 00            	je	0x1758 <trusted_x86_x86_sim_xdp+0x1758>
    11f4: 48 89 c8                     	movq	%rcx, %rax
    11f7: 01 e8                        	addl	%ebp, %eax
    11f9: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    11fe: 01 e8                        	addl	%ebp, %eax
    1200: d1 e8                        	shrl	%eax
    1202: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1206: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    120b: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1210: e8 00 00 00 00               	callq	0x1215 <trusted_x86_x86_sim_xdp+0x1215>
		0000000000001211:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1215: 41 bd a3 0f 00 00            	movl	$0xfa3, %r13d           # imm = 0xFA3
    121b: 48 85 c0                     	testq	%rax, %rax
    121e: 0f 84 8d 21 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1224: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1228: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    122c: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    1231: 0f b7 00                     	movzwl	(%rax), %eax
    1234: 48 39 c2                     	cmpq	%rax, %rdx
    1237: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    123b: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1240: 0f 42 d1                     	cmovbl	%ecx, %edx
    1243: 48 89 d0                     	movq	%rdx, %rax
    1246: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    124b: 41 39 d7                     	cmpl	%edx, %r15d
    124e: 0f 83 ef 04 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    1254: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1259: 44 01 f8                     	addl	%r15d, %eax
    125c: d1 e8                        	shrl	%eax
    125e: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1262: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1267: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    126c: e8 00 00 00 00               	callq	0x1271 <trusted_x86_x86_sim_xdp+0x1271>
		000000000000126d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1271: 48 85 c0                     	testq	%rax, %rax
    1274: 0f 84 37 21 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    127a: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    127e: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1281: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    1286: 0f b7 00                     	movzwl	(%rax), %eax
    1289: 48 39 c2                     	cmpq	%rax, %rdx
    128c: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    1290: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1295: 0f 42 d1                     	cmovbl	%ecx, %edx
    1298: 48 89 d0                     	movq	%rdx, %rax
    129b: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    12a0: 39 d5                        	cmpl	%edx, %ebp
    12a2: 0f 83 9b 04 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    12a8: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    12ad: 01 e8                        	addl	%ebp, %eax
    12af: d1 e8                        	shrl	%eax
    12b1: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    12b5: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    12ba: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    12bf: e8 00 00 00 00               	callq	0x12c4 <trusted_x86_x86_sim_xdp+0x12c4>
		00000000000012c0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    12c4: 48 85 c0                     	testq	%rax, %rax
    12c7: 0f 84 e4 20 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    12cd: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    12d1: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    12d5: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    12da: 0f b7 00                     	movzwl	(%rax), %eax
    12dd: 48 39 c2                     	cmpq	%rax, %rdx
    12e0: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    12e4: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    12e9: 0f 42 d1                     	cmovbl	%ecx, %edx
    12ec: 48 89 d0                     	movq	%rdx, %rax
    12ef: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    12f4: 41 39 d7                     	cmpl	%edx, %r15d
    12f7: 0f 83 46 04 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    12fd: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1302: 44 01 f8                     	addl	%r15d, %eax
    1305: d1 e8                        	shrl	%eax
    1307: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    130b: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1310: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1315: e8 00 00 00 00               	callq	0x131a <trusted_x86_x86_sim_xdp+0x131a>
		0000000000001316:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    131a: 48 85 c0                     	testq	%rax, %rax
    131d: 0f 84 8e 20 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1323: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1327: 8d 69 01                     	leal	0x1(%rcx), %ebp
    132a: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    132f: 0f b7 00                     	movzwl	(%rax), %eax
    1332: 48 39 c2                     	cmpq	%rax, %rdx
    1335: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    1339: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    133e: 0f 42 d1                     	cmovbl	%ecx, %edx
    1341: 48 89 d0                     	movq	%rdx, %rax
    1344: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1349: 39 d5                        	cmpl	%edx, %ebp
    134b: 0f 83 f2 03 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    1351: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1356: 01 e8                        	addl	%ebp, %eax
    1358: d1 e8                        	shrl	%eax
    135a: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    135e: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1363: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1368: e8 00 00 00 00               	callq	0x136d <trusted_x86_x86_sim_xdp+0x136d>
		0000000000001369:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    136d: 48 85 c0                     	testq	%rax, %rax
    1370: 0f 84 3b 20 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1376: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    137a: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    137e: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    1383: 0f b7 00                     	movzwl	(%rax), %eax
    1386: 48 39 c2                     	cmpq	%rax, %rdx
    1389: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    138d: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1392: 0f 42 d1                     	cmovbl	%ecx, %edx
    1395: 48 89 d0                     	movq	%rdx, %rax
    1398: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    139d: 41 39 d7                     	cmpl	%edx, %r15d
    13a0: 0f 83 9d 03 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    13a6: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    13ab: 44 01 f8                     	addl	%r15d, %eax
    13ae: d1 e8                        	shrl	%eax
    13b0: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    13b4: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    13b9: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    13be: e8 00 00 00 00               	callq	0x13c3 <trusted_x86_x86_sim_xdp+0x13c3>
		00000000000013bf:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    13c3: 48 85 c0                     	testq	%rax, %rax
    13c6: 0f 84 e5 1f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    13cc: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    13d0: 8d 69 01                     	leal	0x1(%rcx), %ebp
    13d3: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    13d8: 0f b7 00                     	movzwl	(%rax), %eax
    13db: 48 39 c2                     	cmpq	%rax, %rdx
    13de: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    13e2: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    13e7: 0f 42 d1                     	cmovbl	%ecx, %edx
    13ea: 48 89 d0                     	movq	%rdx, %rax
    13ed: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    13f2: 39 d5                        	cmpl	%edx, %ebp
    13f4: 0f 83 49 03 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    13fa: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    13ff: 01 e8                        	addl	%ebp, %eax
    1401: d1 e8                        	shrl	%eax
    1403: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1407: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    140c: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1411: e8 00 00 00 00               	callq	0x1416 <trusted_x86_x86_sim_xdp+0x1416>
		0000000000001412:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1416: 48 85 c0                     	testq	%rax, %rax
    1419: 0f 84 92 1f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    141f: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1423: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    1427: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    142c: 0f b7 00                     	movzwl	(%rax), %eax
    142f: 48 39 c2                     	cmpq	%rax, %rdx
    1432: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    1436: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    143b: 0f 42 d1                     	cmovbl	%ecx, %edx
    143e: 48 89 d0                     	movq	%rdx, %rax
    1441: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1446: 41 39 d7                     	cmpl	%edx, %r15d
    1449: 0f 83 f4 02 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    144f: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1454: 44 01 f8                     	addl	%r15d, %eax
    1457: d1 e8                        	shrl	%eax
    1459: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    145d: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1462: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1467: e8 00 00 00 00               	callq	0x146c <trusted_x86_x86_sim_xdp+0x146c>
		0000000000001468:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    146c: 48 85 c0                     	testq	%rax, %rax
    146f: 0f 84 3c 1f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1475: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1479: 8d 69 01                     	leal	0x1(%rcx), %ebp
    147c: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    1481: 0f b7 00                     	movzwl	(%rax), %eax
    1484: 48 39 c2                     	cmpq	%rax, %rdx
    1487: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    148b: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1490: 0f 42 d1                     	cmovbl	%ecx, %edx
    1493: 48 89 d0                     	movq	%rdx, %rax
    1496: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    149b: 39 d5                        	cmpl	%edx, %ebp
    149d: 0f 83 a0 02 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    14a3: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    14a8: 01 e8                        	addl	%ebp, %eax
    14aa: d1 e8                        	shrl	%eax
    14ac: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    14b0: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    14b5: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    14ba: e8 00 00 00 00               	callq	0x14bf <trusted_x86_x86_sim_xdp+0x14bf>
		00000000000014bb:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    14bf: 48 85 c0                     	testq	%rax, %rax
    14c2: 0f 84 e9 1e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    14c8: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    14cc: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    14d0: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    14d5: 0f b7 00                     	movzwl	(%rax), %eax
    14d8: 48 39 c2                     	cmpq	%rax, %rdx
    14db: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    14df: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    14e4: 0f 42 d1                     	cmovbl	%ecx, %edx
    14e7: 48 89 d0                     	movq	%rdx, %rax
    14ea: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    14ef: 41 39 d7                     	cmpl	%edx, %r15d
    14f2: 0f 83 4b 02 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    14f8: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    14fd: 44 01 f8                     	addl	%r15d, %eax
    1500: d1 e8                        	shrl	%eax
    1502: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1506: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    150b: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1510: e8 00 00 00 00               	callq	0x1515 <trusted_x86_x86_sim_xdp+0x1515>
		0000000000001511:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1515: 48 85 c0                     	testq	%rax, %rax
    1518: 0f 84 93 1e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    151e: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1522: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1525: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    152a: 0f b7 00                     	movzwl	(%rax), %eax
    152d: 48 39 c2                     	cmpq	%rax, %rdx
    1530: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    1534: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1539: 0f 42 d1                     	cmovbl	%ecx, %edx
    153c: 48 89 d0                     	movq	%rdx, %rax
    153f: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1544: 39 d5                        	cmpl	%edx, %ebp
    1546: 0f 83 f7 01 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    154c: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    1551: 01 e8                        	addl	%ebp, %eax
    1553: d1 e8                        	shrl	%eax
    1555: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1559: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    155e: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1563: e8 00 00 00 00               	callq	0x1568 <trusted_x86_x86_sim_xdp+0x1568>
		0000000000001564:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1568: 48 85 c0                     	testq	%rax, %rax
    156b: 0f 84 40 1e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1571: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1575: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    1579: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    157e: 0f b7 00                     	movzwl	(%rax), %eax
    1581: 48 39 c2                     	cmpq	%rax, %rdx
    1584: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    1588: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    158d: 0f 42 d1                     	cmovbl	%ecx, %edx
    1590: 48 89 d0                     	movq	%rdx, %rax
    1593: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1598: 41 39 d7                     	cmpl	%edx, %r15d
    159b: 0f 83 a2 01 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    15a1: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    15a6: 44 01 f8                     	addl	%r15d, %eax
    15a9: d1 e8                        	shrl	%eax
    15ab: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    15af: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    15b4: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    15b9: e8 00 00 00 00               	callq	0x15be <trusted_x86_x86_sim_xdp+0x15be>
		00000000000015ba:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    15be: 48 85 c0                     	testq	%rax, %rax
    15c1: 0f 84 ea 1d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    15c7: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    15cb: 8d 69 01                     	leal	0x1(%rcx), %ebp
    15ce: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    15d3: 0f b7 00                     	movzwl	(%rax), %eax
    15d6: 48 39 c2                     	cmpq	%rax, %rdx
    15d9: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    15dd: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    15e2: 0f 42 d1                     	cmovbl	%ecx, %edx
    15e5: 48 89 d0                     	movq	%rdx, %rax
    15e8: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    15ed: 39 d5                        	cmpl	%edx, %ebp
    15ef: 0f 83 4e 01 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    15f5: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    15fa: 01 e8                        	addl	%ebp, %eax
    15fc: d1 e8                        	shrl	%eax
    15fe: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1602: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1607: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    160c: e8 00 00 00 00               	callq	0x1611 <trusted_x86_x86_sim_xdp+0x1611>
		000000000000160d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1611: 48 85 c0                     	testq	%rax, %rax
    1614: 0f 84 97 1d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    161a: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    161e: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    1622: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    1627: 0f b7 00                     	movzwl	(%rax), %eax
    162a: 48 39 c2                     	cmpq	%rax, %rdx
    162d: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    1631: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    1636: 0f 42 d1                     	cmovbl	%ecx, %edx
    1639: 48 89 d0                     	movq	%rdx, %rax
    163c: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1641: 41 39 d7                     	cmpl	%edx, %r15d
    1644: 0f 83 f9 00 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    164a: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    164f: 44 01 f8                     	addl	%r15d, %eax
    1652: d1 e8                        	shrl	%eax
    1654: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    1658: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    165d: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1662: e8 00 00 00 00               	callq	0x1667 <trusted_x86_x86_sim_xdp+0x1667>
		0000000000001663:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1667: 48 85 c0                     	testq	%rax, %rax
    166a: 0f 84 41 1d 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1670: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1674: 8d 69 01                     	leal	0x1(%rcx), %ebp
    1677: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    167c: 0f b7 00                     	movzwl	(%rax), %eax
    167f: 48 39 c2                     	cmpq	%rax, %rdx
    1682: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    1686: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    168b: 0f 42 d1                     	cmovbl	%ecx, %edx
    168e: 48 89 d0                     	movq	%rdx, %rax
    1691: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    1696: 39 d5                        	cmpl	%edx, %ebp
    1698: 0f 83 a5 00 00 00            	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    169e: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    16a3: 01 e8                        	addl	%ebp, %eax
    16a5: d1 e8                        	shrl	%eax
    16a7: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    16ab: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    16b0: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    16b5: e8 00 00 00 00               	callq	0x16ba <trusted_x86_x86_sim_xdp+0x16ba>
		00000000000016b6:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    16ba: 48 85 c0                     	testq	%rax, %rax
    16bd: 0f 84 ee 1c 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    16c3: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    16c7: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    16cb: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    16d0: 0f b7 00                     	movzwl	(%rax), %eax
    16d3: 48 39 c2                     	cmpq	%rax, %rdx
    16d6: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    16da: 48 8b 54 24 10               	movq	0x10(%rsp), %rdx
    16df: 0f 42 d1                     	cmovbl	%ecx, %edx
    16e2: 48 89 d0                     	movq	%rdx, %rax
    16e5: 48 89 54 24 10               	movq	%rdx, 0x10(%rsp)
    16ea: 41 39 d7                     	cmpl	%edx, %r15d
    16ed: 73 54                        	jae	0x1743 <trusted_x86_x86_sim_xdp+0x1743>
    16ef: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    16f4: 44 01 f8                     	addl	%r15d, %eax
    16f7: d1 e8                        	shrl	%eax
    16f9: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    16fd: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1702: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    1707: e8 00 00 00 00               	callq	0x170c <trusted_x86_x86_sim_xdp+0x170c>
		0000000000001708:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    170c: 48 85 c0                     	testq	%rax, %rax
    170f: 0f 84 9c 1c 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1715: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    1719: 8d 51 01                     	leal	0x1(%rcx), %edx
    171c: 0f b7 74 24 30               	movzwl	0x30(%rsp), %esi
    1721: 0f b7 00                     	movzwl	(%rax), %eax
    1724: 48 39 c6                     	cmpq	%rax, %rsi
    1727: 41 0f 42 d7                  	cmovbl	%r15d, %edx
    172b: 48 8b 74 24 10               	movq	0x10(%rsp), %rsi
    1730: 0f 42 f1                     	cmovbl	%ecx, %esi
    1733: 48 89 f0                     	movq	%rsi, %rax
    1736: 48 89 74 24 10               	movq	%rsi, 0x10(%rsp)
    173b: 39 f2                        	cmpl	%esi, %edx
    173d: 0f 82 6e 1c 00 00            	jb	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    1743: 83 7c 24 10 00               	cmpl	$0x0, 0x10(%rsp)
    1748: be 09 00 00 00               	movl	$0x9, %esi
    174d: 0f 84 63 1c 00 00            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    1753: 48 8b 6c 24 10               	movq	0x10(%rsp), %rbp
    1758: ff cd                        	decl	%ebp
    175a: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    175e: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    1763: 48 8d 74 24 54               	leaq	0x54(%rsp), %rsi
    1768: e8 00 00 00 00               	callq	0x176d <trusted_x86_x86_sim_xdp+0x176d>
		0000000000001769:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    176d: 48 85 c0                     	testq	%rax, %rax
    1770: 0f 84 b5 0e 00 00            	je	0x262b <trusted_x86_x86_sim_xdp+0x262b>
    1776: 0f b7 4c 24 30               	movzwl	0x30(%rsp), %ecx
    177b: 48 89 c2                     	movq	%rax, %rdx
    177e: 0f b7 12                     	movzwl	(%rdx), %edx
    1781: 29 d1                        	subl	%edx, %ecx
    1783: 8b 54 24 54                  	movl	0x54(%rsp), %edx
    1787: 41 8b 34 24                  	movl	(%r12), %esi
    178b: 8d a9 00 00 01 00            	leal	0x10000(%rcx), %ebp
    1791: 39 d6                        	cmpl	%edx, %esi
    1793: 0f 46 e9                     	cmovbel	%ecx, %ebp
    1796: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    179a: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
    179e: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    17a3: 0f 84 fa ef ff ff            	je	0x7a3 <trusted_x86_x86_sim_xdp+0x7a3>
    17a9: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    17ae: 75 2e                        	jne	0x17de <trusted_x86_x86_sim_xdp+0x17de>
    17b0: c7 44 24 2c 07 00 00 00      	movl	$0x7, 0x2c(%rsp)
    17b8: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    17bd: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x17c4 <trusted_x86_x86_sim_xdp+0x17c4>
		00000000000017c0:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    17c4: e8 00 00 00 00               	callq	0x17c9 <trusted_x86_x86_sim_xdp+0x17c9>
		00000000000017c5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    17c9: 48 85 c0                     	testq	%rax, %rax
    17cc: 74 0c                        	je	0x17da <trusted_x86_x86_sim_xdp+0x17da>
    17ce: 48 89 c1                     	movq	%rax, %rcx
    17d1: 48 8b 09                     	movq	(%rcx), %rcx
    17d4: 48 ff c1                     	incq	%rcx
    17d7: 48 89 08                     	movq	%rcx, (%rax)
    17da: 8b 44 24 50                  	movl	0x50(%rsp), %eax
    17de: 48 8d 4c 24 48               	leaq	0x48(%rsp), %rcx
    17e3: 48 89 8c 24 c0 01 00 00      	movq	%rcx, 0x1c0(%rsp)
    17eb: 48 8d 8c 24 80 00 00 00      	leaq	0x80(%rsp), %rcx
    17f3: 48 89 4c 24 10               	movq	%rcx, 0x10(%rsp)
    17f8: 66 85 c0                     	testw	%ax, %ax
    17fb: 78 1c                        	js	0x1819 <trusted_x86_x86_sim_xdp+0x1819>
    17fd: 48 8d 7c 24 50               	leaq	0x50(%rsp), %rdi
    1802: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1809 <trusted_x86_x86_sim_xdp+0x1809>
		0000000000001805:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    1809: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1810 <trusted_x86_x86_sim_xdp+0x1810>
		000000000000180c:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1810: 75 36                        	jne	0x1848 <trusted_x86_x86_sim_xdp+0x1848>
    1812: e8 00 00 00 00               	callq	0x1817 <trusted_x86_x86_sim_xdp+0x1817>
		0000000000001813:  R_X86_64_PLT32	.text+0x5c
    1817: eb 51                        	jmp	0x186a <trusted_x86_x86_sim_xdp+0x186a>
    1819: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    181e: ff c8                        	decl	%eax
    1820: 83 f8 03                     	cmpl	$0x3, %eax
    1823: 0f 87 6b 1d 00 00            	ja	0x3594 <trusted_x86_x86_sim_xdp+0x3594>
    1829: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x1830 <trusted_x86_x86_sim_xdp+0x1830>
		000000000000182c:  R_X86_64_PC32	.rodata+0xb4
    1830: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    1834: 48 01 c8                     	addq	%rcx, %rax
    1837: ff e0                        	jmpq	*%rax
    1839: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    183e: 31 ed                        	xorl	%ebp, %ebp
    1840: 45 31 ed                     	xorl	%r13d, %r13d
    1843: e9 7e 1b 00 00               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
    1848: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x184f <trusted_x86_x86_sim_xdp+0x184f>
		000000000000184b:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    184f: 75 07                        	jne	0x1858 <trusted_x86_x86_sim_xdp+0x1858>
    1851: e8 00 00 00 00               	callq	0x1856 <trusted_x86_x86_sim_xdp+0x1856>
		0000000000001852:  R_X86_64_PLT32	.text+0x10c
    1856: eb 12                        	jmp	0x186a <trusted_x86_x86_sim_xdp+0x186a>
    1858: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x185f <trusted_x86_x86_sim_xdp+0x185f>
		000000000000185b:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    185f: 0f 85 ed 01 00 00            	jne	0x1a52 <trusted_x86_x86_sim_xdp+0x1a52>
    1865: e8 00 00 00 00               	callq	0x186a <trusted_x86_x86_sim_xdp+0x186a>
		0000000000001866:  R_X86_64_PLT32	.text+0x1bc
    186a: 49 89 c4                     	movq	%rax, %r12
    186d: 48 85 c0                     	testq	%rax, %rax
    1870: 48 8b b4 24 78 01 00 00      	movq	0x178(%rsp), %rsi
    1878: 0f 84 41 1f 00 00            	je	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    187e: 48 89 b4 24 78 01 00 00      	movq	%rsi, 0x178(%rsp)
    1886: 4c 89 e0                     	movq	%r12, %rax
    1889: 44 8b 68 04                  	movl	0x4(%rax), %r13d
    188d: 4c 89 e0                     	movq	%r12, %rax
    1890: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    1894: 85 c0                        	testl	%eax, %eax
    1896: 74 21                        	je	0x18b9 <trusted_x86_x86_sim_xdp+0x18b9>
    1898: 89 c1                        	movl	%eax, %ecx
    189a: 83 e1 7f                     	andl	$0x7f, %ecx
    189d: 48 c1 e5 20                  	shlq	$0x20, %rbp
    18a1: 48 c1 e1 20                  	shlq	$0x20, %rcx
    18a5: 48 39 cd                     	cmpq	%rcx, %rbp
    18a8: 7c 0f                        	jl	0x18b9 <trusted_x86_x86_sim_xdp+0x18b9>
    18aa: f7 d0                        	notl	%eax
    18ac: c1 e8 03                     	shrl	$0x3, %eax
    18af: 83 e0 10                     	andl	$0x10, %eax
    18b2: 41 01 c5                     	addl	%eax, %r13d
    18b5: 41 83 c5 f8                  	addl	$-0x8, %r13d
    18b9: 4c 89 e0                     	movq	%r12, %rax
    18bc: 0f b6 00                     	movzbl	(%rax), %eax
    18bf: 44 89 e9                     	movl	%r13d, %ecx
    18c2: 83 e1 f8                     	andl	$-0x8, %ecx
    18c5: 84 c0                        	testb	%al, %al
    18c7: 41 0f 49 cd                  	cmovnsl	%r13d, %ecx
    18cb: 89 c2                        	movl	%eax, %edx
    18cd: 83 e2 7f                     	andl	$0x7f, %edx
    18d0: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    18d3: 83 fe 04                     	cmpl	$0x4, %esi
    18d6: 0f 87 33 02 00 00            	ja	0x1b0f <trusted_x86_x86_sim_xdp+0x1b0f>
    18dc: 0f b6 d2                     	movzbl	%dl, %edx
    18df: 31 ed                        	xorl	%ebp, %ebp
    18e1: ff ca                        	decl	%edx
    18e3: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x18ea <trusted_x86_x86_sim_xdp+0x18ea>
		00000000000018e6:  R_X86_64_PC32	.rodata+0xc4
    18ea: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    18ee: 48 01 f7                     	addq	%rsi, %rdi
    18f1: 48 8d 54 24 48               	leaq	0x48(%rsp), %rdx
    18f6: ff e7                        	jmpq	*%rdi
    18f8: 31 d2                        	xorl	%edx, %edx
    18fa: e9 bd 01 00 00               	jmp	0x1abc <trusted_x86_x86_sim_xdp+0x1abc>
    18ff: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    1904: 48 8b 30                     	movq	(%rax), %rsi
    1907: 48 83 c6 28                  	addq	$0x28, %rsi
    190b: ba 90 00 00 00               	movl	$0x90, %edx
    1910: 48 89 df                     	movq	%rbx, %rdi
    1913: e8 00 00 00 00               	callq	0x1918 <trusted_x86_x86_sim_xdp+0x1918>
		0000000000001914:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1918: 49 89 c4                     	movq	%rax, %r12
    191b: 45 85 e4                     	testl	%r12d, %r12d
    191e: 79 0f                        	jns	0x192f <trusted_x86_x86_sim_xdp+0x192f>
    1920: ba 90 00 00 00               	movl	$0x90, %edx
    1925: 48 89 df                     	movq	%rbx, %rdi
    1928: 31 f6                        	xorl	%esi, %esi
    192a: e8 00 00 00 00               	callq	0x192f <trusted_x86_x86_sim_xdp+0x192f>
		000000000000192b:  R_X86_64_PLT32	memset-0x4
    192f: 45 85 e4                     	testl	%r12d, %r12d
    1932: 48 8b 94 24 70 01 00 00      	movq	0x170(%rsp), %rdx
    193a: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    193f: 0f 85 17 f4 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    1945: 48 8b 84 24 10 01 00 00      	movq	0x110(%rsp), %rax
    194d: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    1955: 48 89 01                     	movq	%rax, (%rcx)
    1958: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
    1960: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    1968: 48 89 01                     	movq	%rax, (%rcx)
    196b: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    1973: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    197b: 48 89 01                     	movq	%rax, (%rcx)
    197e: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    1986: 49 8d 8e 00 0f 00 00         	leaq	0xf00(%r14), %rcx
    198d: 48 89 01                     	movq	%rax, (%rcx)
    1990: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    1998: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    19a0: 48 89 01                     	movq	%rax, (%rcx)
    19a3: 48 8b 84 24 f8 00 00 00      	movq	0xf8(%rsp), %rax
    19ab: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    19b3: 48 89 01                     	movq	%rax, (%rcx)
    19b6: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    19be: 48 89 d1                     	movq	%rdx, %rcx
    19c1: 48 89 01                     	movq	%rax, (%rcx)
    19c4: 48 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %rax
    19cc: 48 89 f1                     	movq	%rsi, %rcx
    19cf: 48 89 01                     	movq	%rax, (%rcx)
    19d2: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    19d9: 31 c9                        	xorl	%ecx, %ecx
    19db: e9 62 02 00 00               	jmp	0x1c42 <trusted_x86_x86_sim_xdp+0x1c42>
    19e0: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    19e5: 48 8b 30                     	movq	(%rax), %rsi
    19e8: ba 10 00 00 00               	movl	$0x10, %edx
    19ed: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    19f2: e8 00 00 00 00               	callq	0x19f7 <trusted_x86_x86_sim_xdp+0x19f7>
		00000000000019f3:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    19f7: 85 c0                        	testl	%eax, %eax
    19f9: 79 14                        	jns	0x1a0f <trusted_x86_x86_sim_xdp+0x1a0f>
    19fb: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    1a00: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    1a08: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    1a0f: 85 c0                        	testl	%eax, %eax
    1a11: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
    1a19: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    1a1e: 0f 85 38 f3 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    1a24: 4c 89 f0                     	movq	%r14, %rax
    1a27: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    1a2e: 48 83 c0 10                  	addq	$0x10, %rax
    1a32: 48 89 01                     	movq	%rax, (%rcx)
    1a35: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    1a3a: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    1a42: 48 89 01                     	movq	%rax, (%rcx)
    1a45: 48 8b 6c 24 60               	movq	0x60(%rsp), %rbp
    1a4a: 48 89 d0                     	movq	%rdx, %rax
    1a4d: e9 e4 01 00 00               	jmp	0x1c36 <trusted_x86_x86_sim_xdp+0x1c36>
    1a52: 8b 4c 24 50                  	movl	0x50(%rsp), %ecx
    1a56: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    1a59: 48 8b b4 24 78 01 00 00      	movq	0x178(%rsp), %rsi
    1a61: 0f 83 58 1d 00 00            	jae	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    1a67: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    1a6d: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    1a73: 48 0f af ca                  	imulq	%rdx, %rcx
    1a77: 4c 8d 24 08                  	leaq	(%rax,%rcx), %r12
    1a7b: 49 81 c4 30 01 00 00         	addq	$0x130, %r12            # imm = 0x130
    1a82: e9 f7 fd ff ff               	jmp	0x187e <trusted_x86_x86_sim_xdp+0x187e>
    1a87: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    1a8c: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    1a94: 48 8b 00                     	movq	(%rax), %rax
    1a97: 8b 09                        	movl	(%rcx), %ecx
    1a99: 83 e1 0f                     	andl	$0xf, %ecx
    1a9c: 31 d2                        	xorl	%edx, %edx
    1a9e: 83 f9 0b                     	cmpl	$0xb, %ecx
    1aa1: 0f 93 c2                     	setae	%dl
    1aa4: 48 8d 2c d0                  	leaq	(%rax,%rdx,8), %rbp
    1aa8: 48 83 c5 08                  	addq	$0x8, %rbp
    1aac: e9 47 01 00 00               	jmp	0x1bf8 <trusted_x86_x86_sim_xdp+0x1bf8>
    1ab1: 48 8d 54 24 78               	leaq	0x78(%rsp), %rdx
    1ab6: 48 8b 12                     	movq	(%rdx), %rdx
    1ab9: 48 8b 12                     	movq	(%rdx), %rdx
    1abc: 48 63 e9                     	movslq	%ecx, %rbp
    1abf: 48 01 d5                     	addq	%rdx, %rbp
    1ac2: 84 c0                        	testb	%al, %al
    1ac4: 79 4b                        	jns	0x1b11 <trusted_x86_x86_sim_xdp+0x1b11>
    1ac6: ba 08 00 00 00               	movl	$0x8, %edx
    1acb: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1ad0: 48 89 ee                     	movq	%rbp, %rsi
    1ad3: e8 00 00 00 00               	callq	0x1ad8 <trusted_x86_x86_sim_xdp+0x1ad8>
		0000000000001ad4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1ad8: 85 c0                        	testl	%eax, %eax
    1ada: 79 09                        	jns	0x1ae5 <trusted_x86_x86_sim_xdp+0x1ae5>
    1adc: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    1ae5: 85 c0                        	testl	%eax, %eax
    1ae7: 0f 84 62 02 00 00            	je	0x1d4f <trusted_x86_x86_sim_xdp+0x1d4f>
    1aed: 31 ed                        	xorl	%ebp, %ebp
    1aef: eb 20                        	jmp	0x1b11 <trusted_x86_x86_sim_xdp+0x1b11>
    1af1: 44 89 e8                     	movl	%r13d, %eax
    1af4: 83 e0 0f                     	andl	$0xf, %eax
    1af7: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x1afe <trusted_x86_x86_sim_xdp+0x1afe>
		0000000000001afa:  R_X86_64_PC32	.rodata+0xd8
    1afe: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    1b02: 48 01 ca                     	addq	%rcx, %rdx
    1b05: 48 8d 84 24 80 00 00 00      	leaq	0x80(%rsp), %rax
    1b0d: ff e2                        	jmpq	*%rdx
    1b0f: 31 ed                        	xorl	%ebp, %ebp
    1b11: 4c 89 e0                     	movq	%r12, %rax
    1b14: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    1b18: 4c 89 e1                     	movq	%r12, %rcx
    1b1b: 44 8b 69 08                  	movl	0x8(%rcx), %r13d
    1b1f: 44 89 e9                     	movl	%r13d, %ecx
    1b22: 83 e1 f8                     	andl	$-0x8, %ecx
    1b25: 84 c0                        	testb	%al, %al
    1b27: 41 0f 49 cd                  	cmovnsl	%r13d, %ecx
    1b2b: 89 c2                        	movl	%eax, %edx
    1b2d: 83 e2 7f                     	andl	$0x7f, %edx
    1b30: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    1b33: 83 fe 04                     	cmpl	$0x4, %esi
    1b36: 0f 87 a7 00 00 00            	ja	0x1be3 <trusted_x86_x86_sim_xdp+0x1be3>
    1b3c: 0f b6 d2                     	movzbl	%dl, %edx
    1b3f: ff ca                        	decl	%edx
    1b41: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x1b48 <trusted_x86_x86_sim_xdp+0x1b48>
		0000000000001b44:  R_X86_64_PC32	.rodata+0x118
    1b48: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    1b4c: 48 01 f7                     	addq	%rsi, %rdi
    1b4f: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    1b54: 48 89 ea                     	movq	%rbp, %rdx
    1b57: ff e7                        	jmpq	*%rdi
    1b59: 48 8d 74 24 78               	leaq	0x78(%rsp), %rsi
    1b5e: 48 8b 16                     	movq	(%rsi), %rdx
    1b61: 48 8b 12                     	movq	(%rdx), %rdx
    1b64: 48 63 f1                     	movslq	%ecx, %rsi
    1b67: 48 01 d6                     	addq	%rdx, %rsi
    1b6a: 84 c0                        	testb	%al, %al
    1b6c: 78 25                        	js	0x1b93 <trusted_x86_x86_sim_xdp+0x1b93>
    1b6e: 48 85 f6                     	testq	%rsi, %rsi
    1b71: 74 70                        	je	0x1be3 <trusted_x86_x86_sim_xdp+0x1be3>
    1b73: 4c 8b 64 24 48               	movq	0x48(%rsp), %r12
    1b78: ba 08 00 00 00               	movl	$0x8, %edx
    1b7d: 4c 89 e7                     	movq	%r12, %rdi
    1b80: e8 00 00 00 00               	callq	0x1b85 <trusted_x86_x86_sim_xdp+0x1b85>
		0000000000001b81:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1b85: 85 c0                        	testl	%eax, %eax
    1b87: 79 6f                        	jns	0x1bf8 <trusted_x86_x86_sim_xdp+0x1bf8>
    1b89: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    1b91: eb 65                        	jmp	0x1bf8 <trusted_x86_x86_sim_xdp+0x1bf8>
    1b93: ba 08 00 00 00               	movl	$0x8, %edx
    1b98: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1b9d: e8 00 00 00 00               	callq	0x1ba2 <trusted_x86_x86_sim_xdp+0x1ba2>
		0000000000001b9e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1ba2: 85 c0                        	testl	%eax, %eax
    1ba4: 79 09                        	jns	0x1baf <trusted_x86_x86_sim_xdp+0x1baf>
    1ba6: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    1baf: 85 c0                        	testl	%eax, %eax
    1bb1: 75 30                        	jne	0x1be3 <trusted_x86_x86_sim_xdp+0x1be3>
    1bb3: 41 c1 e5 03                  	shll	$0x3, %r13d
    1bb7: 41 83 e5 38                  	andl	$0x38, %r13d
    1bbb: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
    1bc0: 4c 89 ee                     	movq	%r13, %rsi
    1bc3: eb a9                        	jmp	0x1b6e <trusted_x86_x86_sim_xdp+0x1b6e>
    1bc5: 44 89 e8                     	movl	%r13d, %eax
    1bc8: 83 e0 0f                     	andl	$0xf, %eax
    1bcb: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x1bd2 <trusted_x86_x86_sim_xdp+0x1bd2>
		0000000000001bce:  R_X86_64_PC32	.rodata+0x12c
    1bd2: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    1bd6: 48 01 ca                     	addq	%rcx, %rdx
    1bd9: 48 8d 84 24 80 00 00 00      	leaq	0x80(%rsp), %rax
    1be1: ff e2                        	jmpq	*%rdx
    1be3: 41 0f b6 04 24               	movzbl	(%r12), %eax
    1be8: 3c 03                        	cmpb	$0x3, %al
    1bea: 75 0c                        	jne	0x1bf8 <trusted_x86_x86_sim_xdp+0x1bf8>
    1bec: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    1bf1: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    1bf8: 48 85 ed                     	testq	%rbp, %rbp
    1bfb: 0f 84 5b f1 ff ff            	je	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    1c01: 4c 8b a4 24 98 00 00 00      	movq	0x98(%rsp), %r12
    1c09: 48 8d 75 f8                  	leaq	-0x8(%rbp), %rsi
    1c0d: ba 08 00 00 00               	movl	$0x8, %edx
    1c12: 4c 89 e7                     	movq	%r12, %rdi
    1c15: e8 00 00 00 00               	callq	0x1c1a <trusted_x86_x86_sim_xdp+0x1c1a>
		0000000000001c16:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    1c1a: 85 c0                        	testl	%eax, %eax
    1c1c: 79 08                        	jns	0x1c26 <trusted_x86_x86_sim_xdp+0x1c26>
    1c1e: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    1c26: 85 c0                        	testl	%eax, %eax
    1c28: 48 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %rax
    1c30: 0f 85 26 f1 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    1c36: 48 89 28                     	movq	%rbp, (%rax)
    1c39: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    1c40: b1 01                        	movb	$0x1, %cl
    1c42: 88 08                        	movb	%cl, (%rax)
    1c44: c7 44 24 58 06 00 00 00      	movl	$0x6, 0x58(%rsp)
    1c4c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1c53 <trusted_x86_x86_sim_xdp+0x1c53>
		0000000000001c4f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1c53: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    1c58: e8 00 00 00 00               	callq	0x1c5d <trusted_x86_x86_sim_xdp+0x1c5d>
		0000000000001c59:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1c5d: 48 85 c0                     	testq	%rax, %rax
    1c60: 74 0c                        	je	0x1c6e <trusted_x86_x86_sim_xdp+0x1c6e>
    1c62: 48 89 c1                     	movq	%rax, %rcx
    1c65: 48 8b 09                     	movq	(%rcx), %rcx
    1c68: 48 ff c1                     	incq	%rcx
    1c6b: 48 89 08                     	movq	%rcx, (%rax)
    1c6e: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
    1c76: 4c 8b 28                     	movq	(%rax), %r13
    1c79: 4d 85 ed                     	testq	%r13, %r13
    1c7c: 0f 84 ac 1e 00 00            	je	0x3b2e <trusted_x86_x86_sim_xdp+0x3b2e>
    1c82: 48 b8 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1c8c: 48 ff c0                     	incq	%rax
    1c8f: 48 89 84 24 b8 01 00 00      	movq	%rax, 0x1b8(%rsp)
    1c97: 49 39 c5                     	cmpq	%rax, %r13
    1c9a: 0f 83 51 f1 ff ff            	jae	0xdf1 <trusted_x86_x86_sim_xdp+0xdf1>
    1ca0: 49 81 fd 00 10 00 00         	cmpq	$0x1000, %r13           # imm = 0x1000
    1ca7: 0f 82 65 f1 ff ff            	jb	0xe12 <trusted_x86_x86_sim_xdp+0xe12>
    1cad: 4c 89 f0                     	movq	%r14, %rax
    1cb0: 8b 00                        	movl	(%rax), %eax
    1cb2: c7 84 24 a8 00 00 00 60 00 00 00     	movl	$0x60, 0xa8(%rsp)
    1cbd: 0f 38 f1 84 24 ac 00 00 00   	movbel	%eax, 0xac(%rsp)
    1cc6: 4c 0f 38 f1 ac 24 b0 00 00 00	movbeq	%r13, 0xb0(%rsp)
    1cd0: 48 89 df                     	movq	%rbx, %rdi
    1cd3: e8 00 00 00 00               	callq	0x1cd8 <trusted_x86_x86_sim_xdp+0x1cd8>
		0000000000001cd4:  R_X86_64_PLT32	.text+0x5c
    1cd8: 48 85 c0                     	testq	%rax, %rax
    1cdb: 0f 84 6c 1e 00 00            	je	0x3b4d <trusted_x86_x86_sim_xdp+0x3b4d>
    1ce1: 48 89 c1                     	movq	%rax, %rcx
    1ce4: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    1ce8: 48 89 e9                     	movq	%rbp, %rcx
    1ceb: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    1cf5: 48 21 d1                     	andq	%rdx, %rcx
    1cf8: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    1d00: 48 89 0a                     	movq	%rcx, (%rdx)
    1d03: 48 8b 00                     	movq	(%rax), %rax
    1d06: 48 8b 94 24 a0 01 00 00      	movq	0x1a0(%rsp), %rdx
    1d0e: 48 89 02                     	movq	%rax, (%rdx)
    1d11: 48 c1 ed 38                  	shrq	$0x38, %rbp
    1d15: 49 29 cd                     	subq	%rcx, %r13
    1d18: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
    1d20: 4c 89 29                     	movq	%r13, (%rcx)
    1d23: 48 83 fd 01                  	cmpq	$0x1, %rbp
    1d27: 0f 85 b7 00 00 00            	jne	0x1de4 <trusted_x86_x86_sim_xdp+0x1de4>
    1d2d: 48 89 84 24 a8 00 00 00      	movq	%rax, 0xa8(%rsp)
    1d35: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1d3c <trusted_x86_x86_sim_xdp+0x1d3c>
		0000000000001d38:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1d3c: 48 89 df                     	movq	%rbx, %rdi
    1d3f: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1d46 <trusted_x86_x86_sim_xdp+0x1d46>
		0000000000001d42:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1d46: 75 1c                        	jne	0x1d64 <trusted_x86_x86_sim_xdp+0x1d64>
    1d48: e8 00 00 00 00               	callq	0x1d4d <trusted_x86_x86_sim_xdp+0x1d4d>
		0000000000001d49:  R_X86_64_PLT32	.text+0x5c
    1d4d: eb 1a                        	jmp	0x1d69 <trusted_x86_x86_sim_xdp+0x1d69>
    1d4f: 41 c1 e5 03                  	shll	$0x3, %r13d
    1d53: 41 83 e5 38                  	andl	$0x38, %r13d
    1d57: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
    1d5c: 4c 89 ed                     	movq	%r13, %rbp
    1d5f: e9 ad fd ff ff               	jmp	0x1b11 <trusted_x86_x86_sim_xdp+0x1b11>
    1d64: e8 00 00 00 00               	callq	0x1d69 <trusted_x86_x86_sim_xdp+0x1d69>
		0000000000001d65:  R_X86_64_PLT32	.text+0x10c
    1d69: 49 89 c4                     	movq	%rax, %r12
    1d6c: 48 85 c0                     	testq	%rax, %rax
    1d6f: 74 7f                        	je	0x1df0 <trusted_x86_x86_sim_xdp+0x1df0>
    1d71: 4c 89 e0                     	movq	%r12, %rax
    1d74: 48 8b 00                     	movq	(%rax), %rax
    1d77: 4c 39 e8                     	cmpq	%r13, %rax
    1d7a: 77 0c                        	ja	0x1d88 <trusted_x86_x86_sim_xdp+0x1d88>
    1d7c: 4c 89 e0                     	movq	%r12, %rax
    1d7f: 48 8b 40 08                  	movq	0x8(%rax), %rax
    1d83: 4c 39 e8                     	cmpq	%r13, %rax
    1d86: 73 18                        	jae	0x1da0 <trusted_x86_x86_sim_xdp+0x1da0>
    1d88: 4c 89 e0                     	movq	%r12, %rax
    1d8b: 48 8b 40 10                  	movq	0x10(%rax), %rax
    1d8f: 4c 39 e8                     	cmpq	%r13, %rax
    1d92: 77 5c                        	ja	0x1df0 <trusted_x86_x86_sim_xdp+0x1df0>
    1d94: 4c 89 e0                     	movq	%r12, %rax
    1d97: 48 8b 40 18                  	movq	0x18(%rax), %rax
    1d9b: 4c 39 e8                     	cmpq	%r13, %rax
    1d9e: 72 50                        	jb	0x1df0 <trusted_x86_x86_sim_xdp+0x1df0>
    1da0: 4c 89 f0                     	movq	%r14, %rax
    1da3: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    1da9: 4c 89 e1                     	movq	%r12, %rcx
    1dac: 8b 49 20                     	movl	0x20(%rcx), %ecx
    1daf: 0f a3 c8                     	btl	%ecx, %eax
    1db2: 72 3c                        	jb	0x1df0 <trusted_x86_x86_sim_xdp+0x1df0>
    1db4: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
    1dbc: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1dc3 <trusted_x86_x86_sim_xdp+0x1dc3>
		0000000000001dbf:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1dc3: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    1dc8: e8 00 00 00 00               	callq	0x1dcd <trusted_x86_x86_sim_xdp+0x1dcd>
		0000000000001dc9:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1dcd: 48 85 c0                     	testq	%rax, %rax
    1dd0: 74 0c                        	je	0x1dde <trusted_x86_x86_sim_xdp+0x1dde>
    1dd2: 48 89 c1                     	movq	%rax, %rcx
    1dd5: 48 8b 09                     	movq	(%rcx), %rcx
    1dd8: 48 ff c1                     	incq	%rcx
    1ddb: 48 89 08                     	movq	%rcx, (%rax)
    1dde: 41 0f b7 6c 24 20            	movzwl	0x20(%r12), %ebp
    1de4: 45 31 ed                     	xorl	%r13d, %r13d
    1de7: 83 fd 01                     	cmpl	$0x1, %ebp
    1dea: 0f 85 53 1d 00 00            	jne	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    1df0: c7 84 24 a8 00 00 00 05 00 00 00     	movl	$0x5, 0xa8(%rsp)
    1dfb: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x1e02 <trusted_x86_x86_sim_xdp+0x1e02>
		0000000000001dfe:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    1e02: 48 89 de                     	movq	%rbx, %rsi
    1e05: e8 00 00 00 00               	callq	0x1e0a <trusted_x86_x86_sim_xdp+0x1e0a>
		0000000000001e06:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1e0a: 48 85 c0                     	testq	%rax, %rax
    1e0d: 74 0c                        	je	0x1e1b <trusted_x86_x86_sim_xdp+0x1e1b>
    1e0f: 48 89 c1                     	movq	%rax, %rcx
    1e12: 48 8b 09                     	movq	(%rcx), %rcx
    1e15: 48 ff c1                     	incq	%rcx
    1e18: 48 89 08                     	movq	%rcx, (%rax)
    1e1b: 4c 89 f0                     	movq	%r14, %rax
    1e1e: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    1e24: 83 f9 7e                     	cmpl	$0x7e, %ecx
    1e27: 0f 87 da 00 00 00            	ja	0x1f07 <trusted_x86_x86_sim_xdp+0x1f07>
    1e2d: 4c 89 f0                     	movq	%r14, %rax
    1e30: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    1e37: 4c 89 f2                     	movq	%r14, %rdx
    1e3a: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    1e41: 4c 89 f6                     	movq	%r14, %rsi
    1e44: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    1e4b: 8d 79 01                     	leal	0x1(%rcx), %edi
    1e4e: 4c 8b 44 24 08               	movq	0x8(%rsp), %r8
    1e53: 41 89 38                     	movl	%edi, (%r8)
    1e56: c1 e1 03                     	shll	$0x3, %ecx
    1e59: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    1e5c: 48 8b bc 24 c8 01 00 00      	movq	0x1c8(%rsp), %rdi
    1e64: 48 01 cf                     	addq	%rcx, %rdi
    1e67: 48 89 17                     	movq	%rdx, (%rdi)
    1e6a: 48 8b 94 24 d0 01 00 00      	movq	0x1d0(%rsp), %rdx
    1e72: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    1e76: 48 89 32                     	movq	%rsi, (%rdx)
    1e79: 48 8b 94 24 d8 01 00 00      	movq	0x1d8(%rsp), %rdx
    1e81: 48 8d 14 0a                  	leaq	(%rdx,%rcx), %rdx
    1e85: c6 02 03                     	movb	$0x3, (%rdx)
    1e88: 48 8b 94 24 e0 01 00 00      	movq	0x1e0(%rsp), %rdx
    1e90: 48 01 ca                     	addq	%rcx, %rdx
    1e93: 88 02                        	movb	%al, (%rdx)
    1e95: 48 8b 84 24 e8 01 00 00      	movq	0x1e8(%rsp), %rax
    1e9d: 48 01 c8                     	addq	%rcx, %rax
    1ea0: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    1ea6: 48 03 8c 24 f0 01 00 00      	addq	0x1f0(%rsp), %rcx
    1eae: 66 c7 01 00 00               	movw	$0x0, (%rcx)
    1eb3: c7 44 24 50 00 00 00 00      	movl	$0x0, 0x50(%rsp)
    1ebb: 4c 89 f0                     	movq	%r14, %rax
    1ebe: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    1ec5: 48 89 84 24 a0 00 00 00      	movq	%rax, 0xa0(%rsp)
    1ecd: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    1ed2: 4c 89 f0                     	movq	%r14, %rax
    1ed5: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    1edc: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    1ee3: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
    1ee8: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1eef <trusted_x86_x86_sim_xdp+0x1eef>
		0000000000001eeb:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    1eef: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1ef6 <trusted_x86_x86_sim_xdp+0x1ef6>
		0000000000001ef2:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    1ef6: 75 19                        	jne	0x1f11 <trusted_x86_x86_sim_xdp+0x1f11>
    1ef8: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1efd: e8 00 00 00 00               	callq	0x1f02 <trusted_x86_x86_sim_xdp+0x1f02>
		0000000000001efe:  R_X86_64_PLT32	.text+0x5c
    1f02: e9 9b 00 00 00               	jmp	0x1fa2 <trusted_x86_x86_sim_xdp+0x1fa2>
    1f07: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    1f0c: e9 b2 e1 ff ff               	jmp	0xc3 <trusted_x86_x86_sim_xdp+0xc3>
    1f11: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x1f18 <trusted_x86_x86_sim_xdp+0x1f18>
		0000000000001f14:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    1f18: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    1f1d: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x1f24 <trusted_x86_x86_sim_xdp+0x1f24>
		0000000000001f20:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    1f24: 75 77                        	jne	0x1f9d <trusted_x86_x86_sim_xdp+0x1f9d>
    1f26: e8 00 00 00 00               	callq	0x1f2b <trusted_x86_x86_sim_xdp+0x1f2b>
		0000000000001f27:  R_X86_64_PLT32	.text+0x10c
    1f2b: eb 75                        	jmp	0x1fa2 <trusted_x86_x86_sim_xdp+0x1fa2>
    1f2d: 48 8d 84 24 88 00 00 00      	leaq	0x88(%rsp), %rax
    1f35: eb 19                        	jmp	0x1f50 <trusted_x86_x86_sim_xdp+0x1f50>
    1f37: 48 8d 84 24 88 00 00 00      	leaq	0x88(%rsp), %rax
    1f3f: eb 3d                        	jmp	0x1f7e <trusted_x86_x86_sim_xdp+0x1f7e>
    1f41: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    1f49: eb 05                        	jmp	0x1f50 <trusted_x86_x86_sim_xdp+0x1f50>
    1f4b: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
    1f50: 48 8b 00                     	movq	(%rax), %rax
    1f53: 44 89 e9                     	movl	%r13d, %ecx
    1f56: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    1f5c: 41 c1 ed 04                  	shrl	$0x4, %r13d
    1f60: 42 8d 0c e9                  	leal	(%rcx,%r13,8), %ecx
    1f64: 48 63 e9                     	movslq	%ecx, %rbp
    1f67: 48 03 28                     	addq	(%rax), %rbp
    1f6a: e9 a2 fb ff ff               	jmp	0x1b11 <trusted_x86_x86_sim_xdp+0x1b11>
    1f6f: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    1f77: eb 05                        	jmp	0x1f7e <trusted_x86_x86_sim_xdp+0x1f7e>
    1f79: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
    1f7e: 48 8b 00                     	movq	(%rax), %rax
    1f81: 44 89 e9                     	movl	%r13d, %ecx
    1f84: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    1f8a: 41 c1 ed 04                  	shrl	$0x4, %r13d
    1f8e: 42 8d 0c e9                  	leal	(%rcx,%r13,8), %ecx
    1f92: 48 63 f1                     	movslq	%ecx, %rsi
    1f95: 48 03 30                     	addq	(%rax), %rsi
    1f98: e9 d1 fb ff ff               	jmp	0x1b6e <trusted_x86_x86_sim_xdp+0x1b6e>
    1f9d: e8 00 00 00 00               	callq	0x1fa2 <trusted_x86_x86_sim_xdp+0x1fa2>
		0000000000001f9e:  R_X86_64_PLT32	.text+0x1bc
    1fa2: 49 89 c4                     	movq	%rax, %r12
    1fa5: 48 85 c0                     	testq	%rax, %rax
    1fa8: 0f 84 8d 06 00 00            	je	0x263b <trusted_x86_x86_sim_xdp+0x263b>
    1fae: 4c 89 e0                     	movq	%r12, %rax
    1fb1: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    1fb5: 0f b7 c0                     	movzwl	%ax, %eax
    1fb8: 83 c0 f8                     	addl	$-0x8, %eax
    1fbb: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    1fc0: 0f 85 d1 f1 ff ff            	jne	0x1197 <trusted_x86_x86_sim_xdp+0x1197>
    1fc6: 83 e0 0f                     	andl	$0xf, %eax
    1fc9: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x1fd0 <trusted_x86_x86_sim_xdp+0x1fd0>
		0000000000001fcc:  R_X86_64_PC32	.data.rel.ro-0x4
    1fd0: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    1fd4: 48 8d b4 24 a0 00 00 00      	leaq	0xa0(%rsp), %rsi
    1fdc: e8 00 00 00 00               	callq	0x1fe1 <trusted_x86_x86_sim_xdp+0x1fe1>
		0000000000001fdd:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    1fe1: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    1fe6: 48 85 c0                     	testq	%rax, %rax
    1fe9: 0f 84 60 06 00 00            	je	0x264f <trusted_x86_x86_sim_xdp+0x264f>
    1fef: 4c 89 e1                     	movq	%r12, %rcx
    1ff2: 4c 89 e0                     	movq	%r12, %rax
    1ff5: 8b 28                        	movl	(%rax), %ebp
    1ff7: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    1ffb: 4c 89 f0                     	movq	%r14, %rax
    1ffe: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    2005: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    200a: 4c 89 e0                     	movq	%r12, %rax
    200d: 0f b7 48 04                  	movzwl	0x4(%rax), %ecx
    2011: 85 c9                        	testl	%ecx, %ecx
    2013: 0f 84 64 05 00 00            	je	0x257d <trusted_x86_x86_sim_xdp+0x257d>
    2019: 48 89 c8                     	movq	%rcx, %rax
    201c: 01 e8                        	addl	%ebp, %eax
    201e: 48 89 44 24 18               	movq	%rax, 0x18(%rsp)
    2023: 01 e8                        	addl	%ebp, %eax
    2025: d1 e8                        	shrl	%eax
    2027: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    202b: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2030: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2035: e8 00 00 00 00               	callq	0x203a <trusted_x86_x86_sim_xdp+0x203a>
		0000000000002036:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    203a: 41 bd a3 0f 00 00            	movl	$0xfa3, %r13d           # imm = 0xFA3
    2040: 48 85 c0                     	testq	%rax, %rax
    2043: 0f 84 68 13 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2049: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    204d: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    2051: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2056: 0f b7 00                     	movzwl	(%rax), %eax
    2059: 48 39 c2                     	cmpq	%rax, %rdx
    205c: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    2060: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2065: 0f 42 d1                     	cmovbl	%ecx, %edx
    2068: 48 89 d0                     	movq	%rdx, %rax
    206b: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2070: 41 39 d7                     	cmpl	%edx, %r15d
    2073: 0f 83 ef 04 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2079: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    207e: 44 01 f8                     	addl	%r15d, %eax
    2081: d1 e8                        	shrl	%eax
    2083: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2087: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    208c: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2091: e8 00 00 00 00               	callq	0x2096 <trusted_x86_x86_sim_xdp+0x2096>
		0000000000002092:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2096: 48 85 c0                     	testq	%rax, %rax
    2099: 0f 84 12 13 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    209f: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    20a3: 8d 69 01                     	leal	0x1(%rcx), %ebp
    20a6: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    20ab: 0f b7 00                     	movzwl	(%rax), %eax
    20ae: 48 39 c2                     	cmpq	%rax, %rdx
    20b1: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    20b5: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    20ba: 0f 42 d1                     	cmovbl	%ecx, %edx
    20bd: 48 89 d0                     	movq	%rdx, %rax
    20c0: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    20c5: 39 d5                        	cmpl	%edx, %ebp
    20c7: 0f 83 9b 04 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    20cd: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    20d2: 01 e8                        	addl	%ebp, %eax
    20d4: d1 e8                        	shrl	%eax
    20d6: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    20da: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    20df: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    20e4: e8 00 00 00 00               	callq	0x20e9 <trusted_x86_x86_sim_xdp+0x20e9>
		00000000000020e5:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    20e9: 48 85 c0                     	testq	%rax, %rax
    20ec: 0f 84 bf 12 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    20f2: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    20f6: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    20fa: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    20ff: 0f b7 00                     	movzwl	(%rax), %eax
    2102: 48 39 c2                     	cmpq	%rax, %rdx
    2105: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    2109: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    210e: 0f 42 d1                     	cmovbl	%ecx, %edx
    2111: 48 89 d0                     	movq	%rdx, %rax
    2114: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2119: 41 39 d7                     	cmpl	%edx, %r15d
    211c: 0f 83 46 04 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2122: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2127: 44 01 f8                     	addl	%r15d, %eax
    212a: d1 e8                        	shrl	%eax
    212c: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2130: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2135: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    213a: e8 00 00 00 00               	callq	0x213f <trusted_x86_x86_sim_xdp+0x213f>
		000000000000213b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    213f: 48 85 c0                     	testq	%rax, %rax
    2142: 0f 84 69 12 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2148: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    214c: 8d 69 01                     	leal	0x1(%rcx), %ebp
    214f: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2154: 0f b7 00                     	movzwl	(%rax), %eax
    2157: 48 39 c2                     	cmpq	%rax, %rdx
    215a: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    215e: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2163: 0f 42 d1                     	cmovbl	%ecx, %edx
    2166: 48 89 d0                     	movq	%rdx, %rax
    2169: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    216e: 39 d5                        	cmpl	%edx, %ebp
    2170: 0f 83 f2 03 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2176: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    217b: 01 e8                        	addl	%ebp, %eax
    217d: d1 e8                        	shrl	%eax
    217f: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2183: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2188: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    218d: e8 00 00 00 00               	callq	0x2192 <trusted_x86_x86_sim_xdp+0x2192>
		000000000000218e:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2192: 48 85 c0                     	testq	%rax, %rax
    2195: 0f 84 16 12 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    219b: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    219f: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    21a3: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    21a8: 0f b7 00                     	movzwl	(%rax), %eax
    21ab: 48 39 c2                     	cmpq	%rax, %rdx
    21ae: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    21b2: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    21b7: 0f 42 d1                     	cmovbl	%ecx, %edx
    21ba: 48 89 d0                     	movq	%rdx, %rax
    21bd: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    21c2: 41 39 d7                     	cmpl	%edx, %r15d
    21c5: 0f 83 9d 03 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    21cb: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    21d0: 44 01 f8                     	addl	%r15d, %eax
    21d3: d1 e8                        	shrl	%eax
    21d5: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    21d9: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    21de: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    21e3: e8 00 00 00 00               	callq	0x21e8 <trusted_x86_x86_sim_xdp+0x21e8>
		00000000000021e4:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    21e8: 48 85 c0                     	testq	%rax, %rax
    21eb: 0f 84 c0 11 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    21f1: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    21f5: 8d 69 01                     	leal	0x1(%rcx), %ebp
    21f8: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    21fd: 0f b7 00                     	movzwl	(%rax), %eax
    2200: 48 39 c2                     	cmpq	%rax, %rdx
    2203: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    2207: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    220c: 0f 42 d1                     	cmovbl	%ecx, %edx
    220f: 48 89 d0                     	movq	%rdx, %rax
    2212: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2217: 39 d5                        	cmpl	%edx, %ebp
    2219: 0f 83 49 03 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    221f: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2224: 01 e8                        	addl	%ebp, %eax
    2226: d1 e8                        	shrl	%eax
    2228: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    222c: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2231: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2236: e8 00 00 00 00               	callq	0x223b <trusted_x86_x86_sim_xdp+0x223b>
		0000000000002237:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    223b: 48 85 c0                     	testq	%rax, %rax
    223e: 0f 84 6d 11 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2244: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2248: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    224c: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2251: 0f b7 00                     	movzwl	(%rax), %eax
    2254: 48 39 c2                     	cmpq	%rax, %rdx
    2257: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    225b: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2260: 0f 42 d1                     	cmovbl	%ecx, %edx
    2263: 48 89 d0                     	movq	%rdx, %rax
    2266: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    226b: 41 39 d7                     	cmpl	%edx, %r15d
    226e: 0f 83 f4 02 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2274: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2279: 44 01 f8                     	addl	%r15d, %eax
    227c: d1 e8                        	shrl	%eax
    227e: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2282: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2287: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    228c: e8 00 00 00 00               	callq	0x2291 <trusted_x86_x86_sim_xdp+0x2291>
		000000000000228d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2291: 48 85 c0                     	testq	%rax, %rax
    2294: 0f 84 17 11 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    229a: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    229e: 8d 69 01                     	leal	0x1(%rcx), %ebp
    22a1: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    22a6: 0f b7 00                     	movzwl	(%rax), %eax
    22a9: 48 39 c2                     	cmpq	%rax, %rdx
    22ac: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    22b0: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    22b5: 0f 42 d1                     	cmovbl	%ecx, %edx
    22b8: 48 89 d0                     	movq	%rdx, %rax
    22bb: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    22c0: 39 d5                        	cmpl	%edx, %ebp
    22c2: 0f 83 a0 02 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    22c8: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    22cd: 01 e8                        	addl	%ebp, %eax
    22cf: d1 e8                        	shrl	%eax
    22d1: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    22d5: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    22da: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    22df: e8 00 00 00 00               	callq	0x22e4 <trusted_x86_x86_sim_xdp+0x22e4>
		00000000000022e0:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    22e4: 48 85 c0                     	testq	%rax, %rax
    22e7: 0f 84 c4 10 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    22ed: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    22f1: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    22f5: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    22fa: 0f b7 00                     	movzwl	(%rax), %eax
    22fd: 48 39 c2                     	cmpq	%rax, %rdx
    2300: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    2304: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2309: 0f 42 d1                     	cmovbl	%ecx, %edx
    230c: 48 89 d0                     	movq	%rdx, %rax
    230f: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2314: 41 39 d7                     	cmpl	%edx, %r15d
    2317: 0f 83 4b 02 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    231d: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2322: 44 01 f8                     	addl	%r15d, %eax
    2325: d1 e8                        	shrl	%eax
    2327: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    232b: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2330: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2335: e8 00 00 00 00               	callq	0x233a <trusted_x86_x86_sim_xdp+0x233a>
		0000000000002336:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    233a: 48 85 c0                     	testq	%rax, %rax
    233d: 0f 84 6e 10 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2343: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2347: 8d 69 01                     	leal	0x1(%rcx), %ebp
    234a: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    234f: 0f b7 00                     	movzwl	(%rax), %eax
    2352: 48 39 c2                     	cmpq	%rax, %rdx
    2355: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    2359: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    235e: 0f 42 d1                     	cmovbl	%ecx, %edx
    2361: 48 89 d0                     	movq	%rdx, %rax
    2364: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2369: 39 d5                        	cmpl	%edx, %ebp
    236b: 0f 83 f7 01 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2371: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2376: 01 e8                        	addl	%ebp, %eax
    2378: d1 e8                        	shrl	%eax
    237a: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    237e: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2383: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2388: e8 00 00 00 00               	callq	0x238d <trusted_x86_x86_sim_xdp+0x238d>
		0000000000002389:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    238d: 48 85 c0                     	testq	%rax, %rax
    2390: 0f 84 1b 10 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2396: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    239a: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    239e: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    23a3: 0f b7 00                     	movzwl	(%rax), %eax
    23a6: 48 39 c2                     	cmpq	%rax, %rdx
    23a9: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    23ad: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    23b2: 0f 42 d1                     	cmovbl	%ecx, %edx
    23b5: 48 89 d0                     	movq	%rdx, %rax
    23b8: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    23bd: 41 39 d7                     	cmpl	%edx, %r15d
    23c0: 0f 83 a2 01 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    23c6: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    23cb: 44 01 f8                     	addl	%r15d, %eax
    23ce: d1 e8                        	shrl	%eax
    23d0: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    23d4: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    23d9: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    23de: e8 00 00 00 00               	callq	0x23e3 <trusted_x86_x86_sim_xdp+0x23e3>
		00000000000023df:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    23e3: 48 85 c0                     	testq	%rax, %rax
    23e6: 0f 84 c5 0f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    23ec: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    23f0: 8d 69 01                     	leal	0x1(%rcx), %ebp
    23f3: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    23f8: 0f b7 00                     	movzwl	(%rax), %eax
    23fb: 48 39 c2                     	cmpq	%rax, %rdx
    23fe: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    2402: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2407: 0f 42 d1                     	cmovbl	%ecx, %edx
    240a: 48 89 d0                     	movq	%rdx, %rax
    240d: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2412: 39 d5                        	cmpl	%edx, %ebp
    2414: 0f 83 4e 01 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    241a: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    241f: 01 e8                        	addl	%ebp, %eax
    2421: d1 e8                        	shrl	%eax
    2423: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2427: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    242c: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2431: e8 00 00 00 00               	callq	0x2436 <trusted_x86_x86_sim_xdp+0x2436>
		0000000000002432:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2436: 48 85 c0                     	testq	%rax, %rax
    2439: 0f 84 72 0f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    243f: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2443: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    2447: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    244c: 0f b7 00                     	movzwl	(%rax), %eax
    244f: 48 39 c2                     	cmpq	%rax, %rdx
    2452: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    2456: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    245b: 0f 42 d1                     	cmovbl	%ecx, %edx
    245e: 48 89 d0                     	movq	%rdx, %rax
    2461: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    2466: 41 39 d7                     	cmpl	%edx, %r15d
    2469: 0f 83 f9 00 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    246f: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2474: 44 01 f8                     	addl	%r15d, %eax
    2477: d1 e8                        	shrl	%eax
    2479: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    247d: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2482: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2487: e8 00 00 00 00               	callq	0x248c <trusted_x86_x86_sim_xdp+0x248c>
		0000000000002488:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    248c: 48 85 c0                     	testq	%rax, %rax
    248f: 0f 84 1c 0f 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2495: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2499: 8d 69 01                     	leal	0x1(%rcx), %ebp
    249c: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    24a1: 0f b7 00                     	movzwl	(%rax), %eax
    24a4: 48 39 c2                     	cmpq	%rax, %rdx
    24a7: 41 0f 42 ef                  	cmovbl	%r15d, %ebp
    24ab: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    24b0: 0f 42 d1                     	cmovbl	%ecx, %edx
    24b3: 48 89 d0                     	movq	%rdx, %rax
    24b6: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    24bb: 39 d5                        	cmpl	%edx, %ebp
    24bd: 0f 83 a5 00 00 00            	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    24c3: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    24c8: 01 e8                        	addl	%ebp, %eax
    24ca: d1 e8                        	shrl	%eax
    24cc: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    24d0: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    24d5: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    24da: e8 00 00 00 00               	callq	0x24df <trusted_x86_x86_sim_xdp+0x24df>
		00000000000024db:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    24df: 48 85 c0                     	testq	%rax, %rax
    24e2: 0f 84 c9 0e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    24e8: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    24ec: 44 8d 79 01                  	leal	0x1(%rcx), %r15d
    24f0: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    24f5: 0f b7 00                     	movzwl	(%rax), %eax
    24f8: 48 39 c2                     	cmpq	%rax, %rdx
    24fb: 44 0f 42 fd                  	cmovbl	%ebp, %r15d
    24ff: 48 8b 54 24 18               	movq	0x18(%rsp), %rdx
    2504: 0f 42 d1                     	cmovbl	%ecx, %edx
    2507: 48 89 d0                     	movq	%rdx, %rax
    250a: 48 89 54 24 18               	movq	%rdx, 0x18(%rsp)
    250f: 41 39 d7                     	cmpl	%edx, %r15d
    2512: 73 54                        	jae	0x2568 <trusted_x86_x86_sim_xdp+0x2568>
    2514: 48 8b 44 24 18               	movq	0x18(%rsp), %rax
    2519: 44 01 f8                     	addl	%r15d, %eax
    251c: d1 e8                        	shrl	%eax
    251e: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2522: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2527: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    252c: e8 00 00 00 00               	callq	0x2531 <trusted_x86_x86_sim_xdp+0x2531>
		000000000000252d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2531: 48 85 c0                     	testq	%rax, %rax
    2534: 0f 84 77 0e 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    253a: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    253e: 8d 51 01                     	leal	0x1(%rcx), %edx
    2541: 0f b7 74 24 30               	movzwl	0x30(%rsp), %esi
    2546: 0f b7 00                     	movzwl	(%rax), %eax
    2549: 48 39 c6                     	cmpq	%rax, %rsi
    254c: 41 0f 42 d7                  	cmovbl	%r15d, %edx
    2550: 48 8b 74 24 18               	movq	0x18(%rsp), %rsi
    2555: 0f 42 f1                     	cmovbl	%ecx, %esi
    2558: 48 89 f0                     	movq	%rsi, %rax
    255b: 48 89 74 24 18               	movq	%rsi, 0x18(%rsp)
    2560: 39 f2                        	cmpl	%esi, %edx
    2562: 0f 82 49 0e 00 00            	jb	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2568: 83 7c 24 18 00               	cmpl	$0x0, 0x18(%rsp)
    256d: be 09 00 00 00               	movl	$0x9, %esi
    2572: 0f 84 3e 0e 00 00            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    2578: 48 8b 6c 24 18               	movq	0x18(%rsp), %rbp
    257d: ff cd                        	decl	%ebp
    257f: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    2583: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2588: 48 8d 74 24 54               	leaq	0x54(%rsp), %rsi
    258d: e8 00 00 00 00               	callq	0x2592 <trusted_x86_x86_sim_xdp+0x2592>
		000000000000258e:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2592: 48 85 c0                     	testq	%rax, %rax
    2595: 0f 84 90 00 00 00            	je	0x262b <trusted_x86_x86_sim_xdp+0x262b>
    259b: 0f b7 4c 24 30               	movzwl	0x30(%rsp), %ecx
    25a0: 48 89 c2                     	movq	%rax, %rdx
    25a3: 0f b7 12                     	movzwl	(%rdx), %edx
    25a6: 29 d1                        	subl	%edx, %ecx
    25a8: 8b 54 24 54                  	movl	0x54(%rsp), %edx
    25ac: 41 8b 34 24                  	movl	(%r12), %esi
    25b0: 8d a9 00 00 01 00            	leal	0x10000(%rcx), %ebp
    25b6: 39 d6                        	cmpl	%edx, %esi
    25b8: 0f 46 e9                     	cmovbel	%ecx, %ebp
    25bb: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    25bf: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
    25c3: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    25c8: 0f 84 d5 e1 ff ff            	je	0x7a3 <trusted_x86_x86_sim_xdp+0x7a3>
    25ce: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    25d3: 75 2e                        	jne	0x2603 <trusted_x86_x86_sim_xdp+0x2603>
    25d5: c7 44 24 2c 07 00 00 00      	movl	$0x7, 0x2c(%rsp)
    25dd: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    25e2: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x25e9 <trusted_x86_x86_sim_xdp+0x25e9>
		00000000000025e5:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    25e9: e8 00 00 00 00               	callq	0x25ee <trusted_x86_x86_sim_xdp+0x25ee>
		00000000000025ea:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    25ee: 48 85 c0                     	testq	%rax, %rax
    25f1: 74 0c                        	je	0x25ff <trusted_x86_x86_sim_xdp+0x25ff>
    25f3: 48 89 c1                     	movq	%rax, %rcx
    25f6: 48 8b 09                     	movq	(%rcx), %rcx
    25f9: 48 ff c1                     	incq	%rcx
    25fc: 48 89 08                     	movq	%rcx, (%rax)
    25ff: 8b 44 24 50                  	movl	0x50(%rsp), %eax
    2603: 66 85 c0                     	testw	%ax, %ax
    2606: 78 73                        	js	0x267b <trusted_x86_x86_sim_xdp+0x267b>
    2608: 48 8d 7c 24 50               	leaq	0x50(%rsp), %rdi
    260d: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2614 <trusted_x86_x86_sim_xdp+0x2614>
		0000000000002610:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    2614: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x261b <trusted_x86_x86_sim_xdp+0x261b>
		0000000000002617:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    261b: 0f 85 a4 00 00 00            	jne	0x26c5 <trusted_x86_x86_sim_xdp+0x26c5>
    2621: e8 00 00 00 00               	callq	0x2626 <trusted_x86_x86_sim_xdp+0x2626>
		0000000000002622:  R_X86_64_PLT32	.text+0x5c
    2626: e9 bc 00 00 00               	jmp	0x26e7 <trusted_x86_x86_sim_xdp+0x26e7>
    262b: be 0a 00 00 00               	movl	$0xa, %esi
    2630: 41 bd a4 0f 00 00            	movl	$0xfa4, %r13d           # imm = 0xFA4
    2636: e9 7b 0d 00 00               	jmp	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    263b: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    2640: b9 a0 0f 00 00               	movl	$0xfa0, %ecx            # imm = 0xFA0
    2645: ba 08 00 00 00               	movl	$0x8, %edx
    264a: e9 e2 db ff ff               	jmp	0x231 <trusted_x86_x86_sim_xdp+0x231>
    264f: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    2654: b9 a2 0f 00 00               	movl	$0xfa2, %ecx            # imm = 0xFA2
    2659: ba 32 00 00 00               	movl	$0x32, %edx
    265e: e9 ce db ff ff               	jmp	0x231 <trusted_x86_x86_sim_xdp+0x231>
    2663: 48 8b 44 24 40               	movq	0x40(%rsp), %rax
    2668: be 09 00 00 00               	movl	$0x9, %esi
    266d: 45 85 ff                     	testl	%r15d, %r15d
    2670: 0f 85 d1 e0 ff ff            	jne	0x747 <trusted_x86_x86_sim_xdp+0x747>
    2676: e9 3b 0d 00 00               	jmp	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    267b: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    2680: ff c8                        	decl	%eax
    2682: 83 f8 03                     	cmpl	$0x3, %eax
    2685: 0f 87 09 0f 00 00            	ja	0x3594 <trusted_x86_x86_sim_xdp+0x3594>
    268b: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2692 <trusted_x86_x86_sim_xdp+0x2692>
		000000000000268e:  R_X86_64_PC32	.rodata+0x16c
    2692: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    2696: 48 01 c8                     	addq	%rcx, %rax
    2699: ff e0                        	jmpq	*%rax
    269b: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    26a0: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    26a8: 48 8b 00                     	movq	(%rax), %rax
    26ab: 8b 09                        	movl	(%rcx), %ecx
    26ad: 83 e1 0f                     	andl	$0xf, %ecx
    26b0: 31 d2                        	xorl	%edx, %edx
    26b2: 83 f9 0b                     	cmpl	$0xb, %ecx
    26b5: 0f 93 c2                     	setae	%dl
    26b8: 48 8d 2c d0                  	leaq	(%rax,%rdx,8), %rbp
    26bc: 48 83 c5 08                  	addq	$0x8, %rbp
    26c0: e9 86 03 00 00               	jmp	0x2a4b <trusted_x86_x86_sim_xdp+0x2a4b>
    26c5: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x26cc <trusted_x86_x86_sim_xdp+0x26cc>
		00000000000026c8:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    26cc: 75 07                        	jne	0x26d5 <trusted_x86_x86_sim_xdp+0x26d5>
    26ce: e8 00 00 00 00               	callq	0x26d3 <trusted_x86_x86_sim_xdp+0x26d3>
		00000000000026cf:  R_X86_64_PLT32	.text+0x10c
    26d3: eb 12                        	jmp	0x26e7 <trusted_x86_x86_sim_xdp+0x26e7>
    26d5: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x26dc <trusted_x86_x86_sim_xdp+0x26dc>
		00000000000026d8:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    26dc: 0f 85 ed 01 00 00            	jne	0x28cf <trusted_x86_x86_sim_xdp+0x28cf>
    26e2: e8 00 00 00 00               	callq	0x26e7 <trusted_x86_x86_sim_xdp+0x26e7>
		00000000000026e3:  R_X86_64_PLT32	.text+0x1bc
    26e7: 49 89 c4                     	movq	%rax, %r12
    26ea: 48 85 c0                     	testq	%rax, %rax
    26ed: 48 8b b4 24 78 01 00 00      	movq	0x178(%rsp), %rsi
    26f5: 0f 84 c4 10 00 00            	je	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    26fb: 48 89 b4 24 78 01 00 00      	movq	%rsi, 0x178(%rsp)
    2703: 4c 89 e0                     	movq	%r12, %rax
    2706: 44 8b 68 04                  	movl	0x4(%rax), %r13d
    270a: 4c 89 e0                     	movq	%r12, %rax
    270d: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    2711: 85 c0                        	testl	%eax, %eax
    2713: 74 21                        	je	0x2736 <trusted_x86_x86_sim_xdp+0x2736>
    2715: 89 c1                        	movl	%eax, %ecx
    2717: 83 e1 7f                     	andl	$0x7f, %ecx
    271a: 48 c1 e5 20                  	shlq	$0x20, %rbp
    271e: 48 c1 e1 20                  	shlq	$0x20, %rcx
    2722: 48 39 cd                     	cmpq	%rcx, %rbp
    2725: 7c 0f                        	jl	0x2736 <trusted_x86_x86_sim_xdp+0x2736>
    2727: f7 d0                        	notl	%eax
    2729: c1 e8 03                     	shrl	$0x3, %eax
    272c: 83 e0 10                     	andl	$0x10, %eax
    272f: 41 01 c5                     	addl	%eax, %r13d
    2732: 41 83 c5 f8                  	addl	$-0x8, %r13d
    2736: 4c 89 e0                     	movq	%r12, %rax
    2739: 0f b6 00                     	movzbl	(%rax), %eax
    273c: 44 89 e9                     	movl	%r13d, %ecx
    273f: 83 e1 f8                     	andl	$-0x8, %ecx
    2742: 84 c0                        	testb	%al, %al
    2744: 41 0f 49 cd                  	cmovnsl	%r13d, %ecx
    2748: 89 c2                        	movl	%eax, %edx
    274a: 83 e2 7f                     	andl	$0x7f, %edx
    274d: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    2750: 83 fe 04                     	cmpl	$0x4, %esi
    2753: 0f 87 09 02 00 00            	ja	0x2962 <trusted_x86_x86_sim_xdp+0x2962>
    2759: 0f b6 d2                     	movzbl	%dl, %edx
    275c: 31 ed                        	xorl	%ebp, %ebp
    275e: ff ca                        	decl	%edx
    2760: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x2767 <trusted_x86_x86_sim_xdp+0x2767>
		0000000000002763:  R_X86_64_PC32	.rodata+0x17c
    2767: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    276b: 48 01 f7                     	addq	%rsi, %rdi
    276e: 48 8d 54 24 48               	leaq	0x48(%rsp), %rdx
    2773: ff e7                        	jmpq	*%rdi
    2775: 31 d2                        	xorl	%edx, %edx
    2777: e9 93 01 00 00               	jmp	0x290f <trusted_x86_x86_sim_xdp+0x290f>
    277c: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    2781: 48 8b 30                     	movq	(%rax), %rsi
    2784: 48 83 c6 28                  	addq	$0x28, %rsi
    2788: ba 90 00 00 00               	movl	$0x90, %edx
    278d: 48 89 df                     	movq	%rbx, %rdi
    2790: e8 00 00 00 00               	callq	0x2795 <trusted_x86_x86_sim_xdp+0x2795>
		0000000000002791:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2795: 49 89 c4                     	movq	%rax, %r12
    2798: 45 85 e4                     	testl	%r12d, %r12d
    279b: 79 0f                        	jns	0x27ac <trusted_x86_x86_sim_xdp+0x27ac>
    279d: ba 90 00 00 00               	movl	$0x90, %edx
    27a2: 48 89 df                     	movq	%rbx, %rdi
    27a5: 31 f6                        	xorl	%esi, %esi
    27a7: e8 00 00 00 00               	callq	0x27ac <trusted_x86_x86_sim_xdp+0x27ac>
		00000000000027a8:  R_X86_64_PLT32	memset-0x4
    27ac: 45 85 e4                     	testl	%r12d, %r12d
    27af: 48 8b 94 24 70 01 00 00      	movq	0x170(%rsp), %rdx
    27b7: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    27bc: 0f 85 9a e5 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    27c2: 48 8b 84 24 10 01 00 00      	movq	0x110(%rsp), %rax
    27ca: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    27d2: 48 89 01                     	movq	%rax, (%rcx)
    27d5: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
    27dd: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    27e5: 48 89 01                     	movq	%rax, (%rcx)
    27e8: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    27f0: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    27f8: 48 89 01                     	movq	%rax, (%rcx)
    27fb: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    2803: 49 8d 8e 00 0f 00 00         	leaq	0xf00(%r14), %rcx
    280a: 48 89 01                     	movq	%rax, (%rcx)
    280d: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    2815: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    281d: 48 89 01                     	movq	%rax, (%rcx)
    2820: 48 8b 84 24 f8 00 00 00      	movq	0xf8(%rsp), %rax
    2828: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    2830: 48 89 01                     	movq	%rax, (%rcx)
    2833: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    283b: 48 89 d1                     	movq	%rdx, %rcx
    283e: 48 89 01                     	movq	%rax, (%rcx)
    2841: 48 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %rax
    2849: 48 89 f1                     	movq	%rsi, %rcx
    284c: 48 89 01                     	movq	%rax, (%rcx)
    284f: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    2856: 31 c9                        	xorl	%ecx, %ecx
    2858: e9 38 02 00 00               	jmp	0x2a95 <trusted_x86_x86_sim_xdp+0x2a95>
    285d: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2862: 48 8b 30                     	movq	(%rax), %rsi
    2865: ba 10 00 00 00               	movl	$0x10, %edx
    286a: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    286f: e8 00 00 00 00               	callq	0x2874 <trusted_x86_x86_sim_xdp+0x2874>
		0000000000002870:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2874: 85 c0                        	testl	%eax, %eax
    2876: 79 14                        	jns	0x288c <trusted_x86_x86_sim_xdp+0x288c>
    2878: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    287d: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    2885: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    288c: 85 c0                        	testl	%eax, %eax
    288e: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
    2896: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    289b: 0f 85 bb e4 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    28a1: 4c 89 f0                     	movq	%r14, %rax
    28a4: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    28ab: 48 83 c0 10                  	addq	$0x10, %rax
    28af: 48 89 01                     	movq	%rax, (%rcx)
    28b2: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    28b7: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    28bf: 48 89 01                     	movq	%rax, (%rcx)
    28c2: 48 8b 6c 24 60               	movq	0x60(%rsp), %rbp
    28c7: 48 89 d0                     	movq	%rdx, %rax
    28ca: e9 ba 01 00 00               	jmp	0x2a89 <trusted_x86_x86_sim_xdp+0x2a89>
    28cf: 8b 4c 24 50                  	movl	0x50(%rsp), %ecx
    28d3: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    28d6: 48 8b b4 24 78 01 00 00      	movq	0x178(%rsp), %rsi
    28de: 0f 83 db 0e 00 00            	jae	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    28e4: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    28ea: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    28f0: 48 0f af ca                  	imulq	%rdx, %rcx
    28f4: 4c 8d 24 08                  	leaq	(%rax,%rcx), %r12
    28f8: 49 81 c4 30 01 00 00         	addq	$0x130, %r12            # imm = 0x130
    28ff: e9 f7 fd ff ff               	jmp	0x26fb <trusted_x86_x86_sim_xdp+0x26fb>
    2904: 48 8d 54 24 78               	leaq	0x78(%rsp), %rdx
    2909: 48 8b 12                     	movq	(%rdx), %rdx
    290c: 48 8b 12                     	movq	(%rdx), %rdx
    290f: 48 63 e9                     	movslq	%ecx, %rbp
    2912: 48 01 d5                     	addq	%rdx, %rbp
    2915: 84 c0                        	testb	%al, %al
    2917: 79 4b                        	jns	0x2964 <trusted_x86_x86_sim_xdp+0x2964>
    2919: ba 08 00 00 00               	movl	$0x8, %edx
    291e: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2923: 48 89 ee                     	movq	%rbp, %rsi
    2926: e8 00 00 00 00               	callq	0x292b <trusted_x86_x86_sim_xdp+0x292b>
		0000000000002927:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    292b: 85 c0                        	testl	%eax, %eax
    292d: 79 09                        	jns	0x2938 <trusted_x86_x86_sim_xdp+0x2938>
    292f: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    2938: 85 c0                        	testl	%eax, %eax
    293a: 0f 84 52 02 00 00            	je	0x2b92 <trusted_x86_x86_sim_xdp+0x2b92>
    2940: 31 ed                        	xorl	%ebp, %ebp
    2942: eb 20                        	jmp	0x2964 <trusted_x86_x86_sim_xdp+0x2964>
    2944: 44 89 e8                     	movl	%r13d, %eax
    2947: 83 e0 0f                     	andl	$0xf, %eax
    294a: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2951 <trusted_x86_x86_sim_xdp+0x2951>
		000000000000294d:  R_X86_64_PC32	.rodata+0x190
    2951: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    2955: 48 01 ca                     	addq	%rcx, %rdx
    2958: 48 8d 84 24 80 00 00 00      	leaq	0x80(%rsp), %rax
    2960: ff e2                        	jmpq	*%rdx
    2962: 31 ed                        	xorl	%ebp, %ebp
    2964: 4c 89 e0                     	movq	%r12, %rax
    2967: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    296b: 4c 89 e1                     	movq	%r12, %rcx
    296e: 44 8b 69 08                  	movl	0x8(%rcx), %r13d
    2972: 44 89 e9                     	movl	%r13d, %ecx
    2975: 83 e1 f8                     	andl	$-0x8, %ecx
    2978: 84 c0                        	testb	%al, %al
    297a: 41 0f 49 cd                  	cmovnsl	%r13d, %ecx
    297e: 89 c2                        	movl	%eax, %edx
    2980: 83 e2 7f                     	andl	$0x7f, %edx
    2983: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    2986: 83 fe 04                     	cmpl	$0x4, %esi
    2989: 0f 87 a7 00 00 00            	ja	0x2a36 <trusted_x86_x86_sim_xdp+0x2a36>
    298f: 0f b6 d2                     	movzbl	%dl, %edx
    2992: ff ca                        	decl	%edx
    2994: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x299b <trusted_x86_x86_sim_xdp+0x299b>
		0000000000002997:  R_X86_64_PC32	.rodata+0x1d0
    299b: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    299f: 48 01 f7                     	addq	%rsi, %rdi
    29a2: 48 8d 74 24 48               	leaq	0x48(%rsp), %rsi
    29a7: 48 89 ea                     	movq	%rbp, %rdx
    29aa: ff e7                        	jmpq	*%rdi
    29ac: 48 8d 74 24 78               	leaq	0x78(%rsp), %rsi
    29b1: 48 8b 16                     	movq	(%rsi), %rdx
    29b4: 48 8b 12                     	movq	(%rdx), %rdx
    29b7: 48 63 f1                     	movslq	%ecx, %rsi
    29ba: 48 01 d6                     	addq	%rdx, %rsi
    29bd: 84 c0                        	testb	%al, %al
    29bf: 78 25                        	js	0x29e6 <trusted_x86_x86_sim_xdp+0x29e6>
    29c1: 48 85 f6                     	testq	%rsi, %rsi
    29c4: 74 70                        	je	0x2a36 <trusted_x86_x86_sim_xdp+0x2a36>
    29c6: 4c 8b 64 24 48               	movq	0x48(%rsp), %r12
    29cb: ba 08 00 00 00               	movl	$0x8, %edx
    29d0: 4c 89 e7                     	movq	%r12, %rdi
    29d3: e8 00 00 00 00               	callq	0x29d8 <trusted_x86_x86_sim_xdp+0x29d8>
		00000000000029d4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    29d8: 85 c0                        	testl	%eax, %eax
    29da: 79 6f                        	jns	0x2a4b <trusted_x86_x86_sim_xdp+0x2a4b>
    29dc: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    29e4: eb 65                        	jmp	0x2a4b <trusted_x86_x86_sim_xdp+0x2a4b>
    29e6: ba 08 00 00 00               	movl	$0x8, %edx
    29eb: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    29f0: e8 00 00 00 00               	callq	0x29f5 <trusted_x86_x86_sim_xdp+0x29f5>
		00000000000029f1:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    29f5: 85 c0                        	testl	%eax, %eax
    29f7: 79 09                        	jns	0x2a02 <trusted_x86_x86_sim_xdp+0x2a02>
    29f9: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    2a02: 85 c0                        	testl	%eax, %eax
    2a04: 75 30                        	jne	0x2a36 <trusted_x86_x86_sim_xdp+0x2a36>
    2a06: 41 c1 e5 03                  	shll	$0x3, %r13d
    2a0a: 41 83 e5 38                  	andl	$0x38, %r13d
    2a0e: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
    2a13: 4c 89 ee                     	movq	%r13, %rsi
    2a16: eb a9                        	jmp	0x29c1 <trusted_x86_x86_sim_xdp+0x29c1>
    2a18: 44 89 e8                     	movl	%r13d, %eax
    2a1b: 83 e0 0f                     	andl	$0xf, %eax
    2a1e: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2a25 <trusted_x86_x86_sim_xdp+0x2a25>
		0000000000002a21:  R_X86_64_PC32	.rodata+0x1e4
    2a25: 48 63 14 81                  	movslq	(%rcx,%rax,4), %rdx
    2a29: 48 01 ca                     	addq	%rcx, %rdx
    2a2c: 48 8d 84 24 80 00 00 00      	leaq	0x80(%rsp), %rax
    2a34: ff e2                        	jmpq	*%rdx
    2a36: 41 0f b6 04 24               	movzbl	(%r12), %eax
    2a3b: 3c 03                        	cmpb	$0x3, %al
    2a3d: 75 0c                        	jne	0x2a4b <trusted_x86_x86_sim_xdp+0x2a4b>
    2a3f: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    2a44: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    2a4b: 48 85 ed                     	testq	%rbp, %rbp
    2a4e: 0f 84 08 e3 ff ff            	je	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    2a54: 4c 8b a4 24 98 00 00 00      	movq	0x98(%rsp), %r12
    2a5c: 48 8d 75 f8                  	leaq	-0x8(%rbp), %rsi
    2a60: ba 08 00 00 00               	movl	$0x8, %edx
    2a65: 4c 89 e7                     	movq	%r12, %rdi
    2a68: e8 00 00 00 00               	callq	0x2a6d <trusted_x86_x86_sim_xdp+0x2a6d>
		0000000000002a69:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    2a6d: 85 c0                        	testl	%eax, %eax
    2a6f: 79 08                        	jns	0x2a79 <trusted_x86_x86_sim_xdp+0x2a79>
    2a71: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    2a79: 85 c0                        	testl	%eax, %eax
    2a7b: 48 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %rax
    2a83: 0f 85 d3 e2 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    2a89: 48 89 28                     	movq	%rbp, (%rax)
    2a8c: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    2a93: b1 01                        	movb	$0x1, %cl
    2a95: 88 08                        	movb	%cl, (%rax)
    2a97: c7 44 24 58 06 00 00 00      	movl	$0x6, 0x58(%rsp)
    2a9f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2aa6 <trusted_x86_x86_sim_xdp+0x2aa6>
		0000000000002aa2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2aa6: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    2aab: e8 00 00 00 00               	callq	0x2ab0 <trusted_x86_x86_sim_xdp+0x2ab0>
		0000000000002aac:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2ab0: 48 85 c0                     	testq	%rax, %rax
    2ab3: 74 0c                        	je	0x2ac1 <trusted_x86_x86_sim_xdp+0x2ac1>
    2ab5: 48 89 c1                     	movq	%rax, %rcx
    2ab8: 48 8b 09                     	movq	(%rcx), %rcx
    2abb: 48 ff c1                     	incq	%rcx
    2abe: 48 89 08                     	movq	%rcx, (%rax)
    2ac1: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
    2ac9: 4c 8b 28                     	movq	(%rax), %r13
    2acc: 4d 85 ed                     	testq	%r13, %r13
    2acf: 0f 84 59 10 00 00            	je	0x3b2e <trusted_x86_x86_sim_xdp+0x3b2e>
    2ad5: 4c 3b ac 24 b8 01 00 00      	cmpq	0x1b8(%rsp), %r13
    2add: 0f 83 0e e3 ff ff            	jae	0xdf1 <trusted_x86_x86_sim_xdp+0xdf1>
    2ae3: 49 81 fd 00 10 00 00         	cmpq	$0x1000, %r13           # imm = 0x1000
    2aea: 0f 82 22 e3 ff ff            	jb	0xe12 <trusted_x86_x86_sim_xdp+0xe12>
    2af0: 4c 89 f0                     	movq	%r14, %rax
    2af3: 8b 00                        	movl	(%rax), %eax
    2af5: c7 84 24 a8 00 00 00 60 00 00 00     	movl	$0x60, 0xa8(%rsp)
    2b00: 0f 38 f1 84 24 ac 00 00 00   	movbel	%eax, 0xac(%rsp)
    2b09: 4c 0f 38 f1 ac 24 b0 00 00 00	movbeq	%r13, 0xb0(%rsp)
    2b13: 48 89 df                     	movq	%rbx, %rdi
    2b16: e8 00 00 00 00               	callq	0x2b1b <trusted_x86_x86_sim_xdp+0x2b1b>
		0000000000002b17:  R_X86_64_PLT32	.text+0x5c
    2b1b: 48 85 c0                     	testq	%rax, %rax
    2b1e: 0f 84 29 10 00 00            	je	0x3b4d <trusted_x86_x86_sim_xdp+0x3b4d>
    2b24: 48 89 c1                     	movq	%rax, %rcx
    2b27: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    2b2b: 48 89 e9                     	movq	%rbp, %rcx
    2b2e: 48 ba ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    2b38: 48 21 d1                     	andq	%rdx, %rcx
    2b3b: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    2b43: 48 89 0a                     	movq	%rcx, (%rdx)
    2b46: 48 8b 00                     	movq	(%rax), %rax
    2b49: 48 8b 94 24 a0 01 00 00      	movq	0x1a0(%rsp), %rdx
    2b51: 48 89 02                     	movq	%rax, (%rdx)
    2b54: 48 c1 ed 38                  	shrq	$0x38, %rbp
    2b58: 49 29 cd                     	subq	%rcx, %r13
    2b5b: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
    2b63: 4c 89 29                     	movq	%r13, (%rcx)
    2b66: 48 83 fd 01                  	cmpq	$0x1, %rbp
    2b6a: 0f 85 b7 00 00 00            	jne	0x2c27 <trusted_x86_x86_sim_xdp+0x2c27>
    2b70: 48 89 84 24 a8 00 00 00      	movq	%rax, 0xa8(%rsp)
    2b78: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2b7f <trusted_x86_x86_sim_xdp+0x2b7f>
		0000000000002b7b:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    2b7f: 48 89 df                     	movq	%rbx, %rdi
    2b82: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2b89 <trusted_x86_x86_sim_xdp+0x2b89>
		0000000000002b85:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2b89: 75 1c                        	jne	0x2ba7 <trusted_x86_x86_sim_xdp+0x2ba7>
    2b8b: e8 00 00 00 00               	callq	0x2b90 <trusted_x86_x86_sim_xdp+0x2b90>
		0000000000002b8c:  R_X86_64_PLT32	.text+0x5c
    2b90: eb 1a                        	jmp	0x2bac <trusted_x86_x86_sim_xdp+0x2bac>
    2b92: 41 c1 e5 03                  	shll	$0x3, %r13d
    2b96: 41 83 e5 38                  	andl	$0x38, %r13d
    2b9a: 4c 03 6c 24 58               	addq	0x58(%rsp), %r13
    2b9f: 4c 89 ed                     	movq	%r13, %rbp
    2ba2: e9 bd fd ff ff               	jmp	0x2964 <trusted_x86_x86_sim_xdp+0x2964>
    2ba7: e8 00 00 00 00               	callq	0x2bac <trusted_x86_x86_sim_xdp+0x2bac>
		0000000000002ba8:  R_X86_64_PLT32	.text+0x10c
    2bac: 49 89 c4                     	movq	%rax, %r12
    2baf: 48 85 c0                     	testq	%rax, %rax
    2bb2: 74 7f                        	je	0x2c33 <trusted_x86_x86_sim_xdp+0x2c33>
    2bb4: 4c 89 e0                     	movq	%r12, %rax
    2bb7: 48 8b 00                     	movq	(%rax), %rax
    2bba: 4c 39 e8                     	cmpq	%r13, %rax
    2bbd: 77 0c                        	ja	0x2bcb <trusted_x86_x86_sim_xdp+0x2bcb>
    2bbf: 4c 89 e0                     	movq	%r12, %rax
    2bc2: 48 8b 40 08                  	movq	0x8(%rax), %rax
    2bc6: 4c 39 e8                     	cmpq	%r13, %rax
    2bc9: 73 18                        	jae	0x2be3 <trusted_x86_x86_sim_xdp+0x2be3>
    2bcb: 4c 89 e0                     	movq	%r12, %rax
    2bce: 48 8b 40 10                  	movq	0x10(%rax), %rax
    2bd2: 4c 39 e8                     	cmpq	%r13, %rax
    2bd5: 77 5c                        	ja	0x2c33 <trusted_x86_x86_sim_xdp+0x2c33>
    2bd7: 4c 89 e0                     	movq	%r12, %rax
    2bda: 48 8b 40 18                  	movq	0x18(%rax), %rax
    2bde: 4c 39 e8                     	cmpq	%r13, %rax
    2be1: 72 50                        	jb	0x2c33 <trusted_x86_x86_sim_xdp+0x2c33>
    2be3: 4c 89 f0                     	movq	%r14, %rax
    2be6: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    2bec: 4c 89 e1                     	movq	%r12, %rcx
    2bef: 8b 49 20                     	movl	0x20(%rcx), %ecx
    2bf2: 0f a3 c8                     	btl	%ecx, %eax
    2bf5: 72 3c                        	jb	0x2c33 <trusted_x86_x86_sim_xdp+0x2c33>
    2bf7: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
    2bff: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2c06 <trusted_x86_x86_sim_xdp+0x2c06>
		0000000000002c02:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2c06: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    2c0b: e8 00 00 00 00               	callq	0x2c10 <trusted_x86_x86_sim_xdp+0x2c10>
		0000000000002c0c:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2c10: 48 85 c0                     	testq	%rax, %rax
    2c13: 74 0c                        	je	0x2c21 <trusted_x86_x86_sim_xdp+0x2c21>
    2c15: 48 89 c1                     	movq	%rax, %rcx
    2c18: 48 8b 09                     	movq	(%rcx), %rcx
    2c1b: 48 ff c1                     	incq	%rcx
    2c1e: 48 89 08                     	movq	%rcx, (%rax)
    2c21: 41 0f b7 6c 24 20            	movzwl	0x20(%r12), %ebp
    2c27: 45 31 ed                     	xorl	%r13d, %r13d
    2c2a: 83 fd 01                     	cmpl	$0x1, %ebp
    2c2d: 0f 85 10 0f 00 00            	jne	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    2c33: c7 84 24 a8 00 00 00 05 00 00 00     	movl	$0x5, 0xa8(%rsp)
    2c3e: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x2c45 <trusted_x86_x86_sim_xdp+0x2c45>
		0000000000002c41:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    2c45: 48 89 de                     	movq	%rbx, %rsi
    2c48: e8 00 00 00 00               	callq	0x2c4d <trusted_x86_x86_sim_xdp+0x2c4d>
		0000000000002c49:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2c4d: 48 85 c0                     	testq	%rax, %rax
    2c50: 74 0c                        	je	0x2c5e <trusted_x86_x86_sim_xdp+0x2c5e>
    2c52: 48 89 c1                     	movq	%rax, %rcx
    2c55: 48 8b 09                     	movq	(%rcx), %rcx
    2c58: 48 ff c1                     	incq	%rcx
    2c5b: 48 89 08                     	movq	%rcx, (%rax)
    2c5e: 4c 89 f0                     	movq	%r14, %rax
    2c61: 8b 88 c0 02 00 00            	movl	0x2c0(%rax), %ecx
    2c67: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    2c6c: 83 f9 7e                     	cmpl	$0x7e, %ecx
    2c6f: 0f 87 4e d4 ff ff            	ja	0xc3 <trusted_x86_x86_sim_xdp+0xc3>
    2c75: 4c 89 f0                     	movq	%r14, %rax
    2c78: 0f b6 80 30 0f 00 00         	movzbl	0xf30(%rax), %eax
    2c7f: 4c 89 f2                     	movq	%r14, %rdx
    2c82: 48 8b 92 10 0f 00 00         	movq	0xf10(%rdx), %rdx
    2c89: 4c 89 f6                     	movq	%r14, %rsi
    2c8c: 48 8b b6 18 0f 00 00         	movq	0xf18(%rsi), %rsi
    2c93: 8d 79 01                     	leal	0x1(%rcx), %edi
    2c96: 4c 8b 44 24 08               	movq	0x8(%rsp), %r8
    2c9b: 41 89 38                     	movl	%edi, (%r8)
    2c9e: c1 e1 03                     	shll	$0x3, %ecx
    2ca1: 8d 0c 49                     	leal	(%rcx,%rcx,2), %ecx
    2ca4: 48 8b bc 24 c8 01 00 00      	movq	0x1c8(%rsp), %rdi
    2cac: 48 01 cf                     	addq	%rcx, %rdi
    2caf: 48 89 17                     	movq	%rdx, (%rdi)
    2cb2: 48 8b 94 24 d0 01 00 00      	movq	0x1d0(%rsp), %rdx
    2cba: 48 01 ca                     	addq	%rcx, %rdx
    2cbd: 48 89 32                     	movq	%rsi, (%rdx)
    2cc0: 48 8b 94 24 d8 01 00 00      	movq	0x1d8(%rsp), %rdx
    2cc8: 48 01 ca                     	addq	%rcx, %rdx
    2ccb: c6 02 03                     	movb	$0x3, (%rdx)
    2cce: 48 8b 94 24 e0 01 00 00      	movq	0x1e0(%rsp), %rdx
    2cd6: 48 01 ca                     	addq	%rcx, %rdx
    2cd9: 88 02                        	movb	%al, (%rdx)
    2cdb: 48 8b 84 24 e8 01 00 00      	movq	0x1e8(%rsp), %rax
    2ce3: 48 01 c8                     	addq	%rcx, %rax
    2ce6: c7 00 00 00 00 00            	movl	$0x0, (%rax)
    2cec: 48 8b 84 24 f0 01 00 00      	movq	0x1f0(%rsp), %rax
    2cf4: 48 01 c8                     	addq	%rcx, %rax
    2cf7: 66 c7 00 00 00               	movw	$0x0, (%rax)
    2cfc: c7 44 24 50 00 00 00 00      	movl	$0x0, 0x50(%rsp)
    2d04: 4c 89 f0                     	movq	%r14, %rax
    2d07: 48 8b 80 10 0f 00 00         	movq	0xf10(%rax), %rax
    2d0e: 48 89 84 24 a0 00 00 00      	movq	%rax, 0xa0(%rsp)
    2d16: 48 89 44 24 58               	movq	%rax, 0x58(%rsp)
    2d1b: 4c 89 f0                     	movq	%r14, %rax
    2d1e: 48 c7 c1 00 00 ff ff         	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
    2d25: 48 23 88 18 0f 00 00         	andq	0xf18(%rax), %rcx
    2d2c: 48 89 4c 24 60               	movq	%rcx, 0x60(%rsp)
    2d31: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2d38 <trusted_x86_x86_sim_xdp+0x2d38>
		0000000000002d34:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2d38: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2d3f <trusted_x86_x86_sim_xdp+0x2d3f>
		0000000000002d3b:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    2d3f: 75 0f                        	jne	0x2d50 <trusted_x86_x86_sim_xdp+0x2d50>
    2d41: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2d46: e8 00 00 00 00               	callq	0x2d4b <trusted_x86_x86_sim_xdp+0x2d4b>
		0000000000002d47:  R_X86_64_PLT32	.text+0x5c
    2d4b: e9 91 00 00 00               	jmp	0x2de1 <trusted_x86_x86_sim_xdp+0x2de1>
    2d50: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x2d57 <trusted_x86_x86_sim_xdp+0x2d57>
		0000000000002d53:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    2d57: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    2d5c: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x2d63 <trusted_x86_x86_sim_xdp+0x2d63>
		0000000000002d5f:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    2d63: 75 77                        	jne	0x2ddc <trusted_x86_x86_sim_xdp+0x2ddc>
    2d65: e8 00 00 00 00               	callq	0x2d6a <trusted_x86_x86_sim_xdp+0x2d6a>
		0000000000002d66:  R_X86_64_PLT32	.text+0x10c
    2d6a: eb 75                        	jmp	0x2de1 <trusted_x86_x86_sim_xdp+0x2de1>
    2d6c: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    2d74: eb 0f                        	jmp	0x2d85 <trusted_x86_x86_sim_xdp+0x2d85>
    2d76: 48 8d 84 24 88 00 00 00      	leaq	0x88(%rsp), %rax
    2d7e: eb 05                        	jmp	0x2d85 <trusted_x86_x86_sim_xdp+0x2d85>
    2d80: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
    2d85: 48 8b 00                     	movq	(%rax), %rax
    2d88: 44 89 e9                     	movl	%r13d, %ecx
    2d8b: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    2d91: 41 c1 ed 04                  	shrl	$0x4, %r13d
    2d95: 42 8d 0c e9                  	leal	(%rcx,%r13,8), %ecx
    2d99: 48 63 e9                     	movslq	%ecx, %rbp
    2d9c: 48 03 28                     	addq	(%rax), %rbp
    2d9f: e9 c0 fb ff ff               	jmp	0x2964 <trusted_x86_x86_sim_xdp+0x2964>
    2da4: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    2dac: eb 0f                        	jmp	0x2dbd <trusted_x86_x86_sim_xdp+0x2dbd>
    2dae: 48 8d 84 24 88 00 00 00      	leaq	0x88(%rsp), %rax
    2db6: eb 05                        	jmp	0x2dbd <trusted_x86_x86_sim_xdp+0x2dbd>
    2db8: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
    2dbd: 48 8b 00                     	movq	(%rax), %rax
    2dc0: 44 89 e9                     	movl	%r13d, %ecx
    2dc3: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    2dc9: 41 c1 ed 04                  	shrl	$0x4, %r13d
    2dcd: 42 8d 0c e9                  	leal	(%rcx,%r13,8), %ecx
    2dd1: 48 63 f1                     	movslq	%ecx, %rsi
    2dd4: 48 03 30                     	addq	(%rax), %rsi
    2dd7: e9 e5 fb ff ff               	jmp	0x29c1 <trusted_x86_x86_sim_xdp+0x29c1>
    2ddc: e8 00 00 00 00               	callq	0x2de1 <trusted_x86_x86_sim_xdp+0x2de1>
		0000000000002ddd:  R_X86_64_PLT32	.text+0x1bc
    2de1: 49 89 c7                     	movq	%rax, %r15
    2de4: 48 85 c0                     	testq	%rax, %rax
    2de7: 0f 84 53 f8 ff ff            	je	0x2640 <trusted_x86_x86_sim_xdp+0x2640>
    2ded: 4c 89 f8                     	movq	%r15, %rax
    2df0: 0f b7 40 06                  	movzwl	0x6(%rax), %eax
    2df4: 0f b7 c0                     	movzwl	%ax, %eax
    2df7: 83 c0 f8                     	addl	$-0x8, %eax
    2dfa: b9 a1 0f 00 00               	movl	$0xfa1, %ecx            # imm = 0xFA1
    2dff: ba 33 00 00 00               	movl	$0x33, %edx
    2e04: a9 f0 ff 00 00               	testl	$0xfff0, %eax           # imm = 0xFFF0
    2e09: 0f 85 22 d4 ff ff            	jne	0x231 <trusted_x86_x86_sim_xdp+0x231>
    2e0f: 83 e0 0f                     	andl	$0xf, %eax
    2e12: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x2e19 <trusted_x86_x86_sim_xdp+0x2e19>
		0000000000002e15:  R_X86_64_PC32	.data.rel.ro-0x4
    2e19: 48 8b 3c c1                  	movq	(%rcx,%rax,8), %rdi
    2e1d: 48 8d b4 24 a0 00 00 00      	leaq	0xa0(%rsp), %rsi
    2e25: e8 00 00 00 00               	callq	0x2e2a <trusted_x86_x86_sim_xdp+0x2e2a>
		0000000000002e26:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2e2a: 48 89 44 24 38               	movq	%rax, 0x38(%rsp)
    2e2f: 48 85 c0                     	testq	%rax, %rax
    2e32: 0f 84 1c f8 ff ff            	je	0x2654 <trusted_x86_x86_sim_xdp+0x2654>
    2e38: 4c 89 f9                     	movq	%r15, %rcx
    2e3b: 4c 89 f8                     	movq	%r15, %rax
    2e3e: 8b 28                        	movl	(%rax), %ebp
    2e40: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    2e44: 4c 89 f0                     	movq	%r14, %rax
    2e47: 48 8b 80 18 0f 00 00         	movq	0xf18(%rax), %rax
    2e4e: 48 89 44 24 30               	movq	%rax, 0x30(%rsp)
    2e53: 4c 89 f8                     	movq	%r15, %rax
    2e56: 0f b7 48 04                  	movzwl	0x4(%rax), %ecx
    2e5a: 85 c9                        	testl	%ecx, %ecx
    2e5c: 0f 84 30 06 00 00            	je	0x3492 <trusted_x86_x86_sim_xdp+0x3492>
    2e62: 48 89 c8                     	movq	%rcx, %rax
    2e65: 01 e8                        	addl	%ebp, %eax
    2e67: 48 89 44 24 08               	movq	%rax, 0x8(%rsp)
    2e6c: 01 e8                        	addl	%ebp, %eax
    2e6e: d1 e8                        	shrl	%eax
    2e70: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2e74: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2e79: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2e7e: e8 00 00 00 00               	callq	0x2e83 <trusted_x86_x86_sim_xdp+0x2e83>
		0000000000002e7f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2e83: 41 bd a3 0f 00 00            	movl	$0xfa3, %r13d           # imm = 0xFA3
    2e89: 48 85 c0                     	testq	%rax, %rax
    2e8c: 0f 84 1f 05 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2e92: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2e96: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    2e9a: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2e9f: 0f b7 00                     	movzwl	(%rax), %eax
    2ea2: 48 39 c2                     	cmpq	%rax, %rdx
    2ea5: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    2ea9: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    2eae: 0f 42 d1                     	cmovbl	%ecx, %edx
    2eb1: 48 89 d0                     	movq	%rdx, %rax
    2eb4: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    2eb9: 41 39 d4                     	cmpl	%edx, %r12d
    2ebc: 0f 83 bb 05 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    2ec2: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    2ec7: 44 01 e0                     	addl	%r12d, %eax
    2eca: d1 e8                        	shrl	%eax
    2ecc: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2ed0: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2ed5: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2eda: e8 00 00 00 00               	callq	0x2edf <trusted_x86_x86_sim_xdp+0x2edf>
		0000000000002edb:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2edf: 48 85 c0                     	testq	%rax, %rax
    2ee2: 0f 84 c9 04 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2ee8: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2eec: 8d 69 01                     	leal	0x1(%rcx), %ebp
    2eef: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2ef4: 0f b7 00                     	movzwl	(%rax), %eax
    2ef7: 48 39 c2                     	cmpq	%rax, %rdx
    2efa: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    2efe: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    2f03: 0f 42 d1                     	cmovbl	%ecx, %edx
    2f06: 48 89 d0                     	movq	%rdx, %rax
    2f09: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    2f0e: 39 d5                        	cmpl	%edx, %ebp
    2f10: 0f 83 67 05 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    2f16: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    2f1b: 01 e8                        	addl	%ebp, %eax
    2f1d: d1 e8                        	shrl	%eax
    2f1f: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2f23: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2f28: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2f2d: e8 00 00 00 00               	callq	0x2f32 <trusted_x86_x86_sim_xdp+0x2f32>
		0000000000002f2e:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2f32: 48 85 c0                     	testq	%rax, %rax
    2f35: 0f 84 76 04 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2f3b: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2f3f: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    2f43: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2f48: 0f b7 00                     	movzwl	(%rax), %eax
    2f4b: 48 39 c2                     	cmpq	%rax, %rdx
    2f4e: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    2f52: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    2f57: 0f 42 d1                     	cmovbl	%ecx, %edx
    2f5a: 48 89 d0                     	movq	%rdx, %rax
    2f5d: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    2f62: 41 39 d4                     	cmpl	%edx, %r12d
    2f65: 0f 83 12 05 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    2f6b: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    2f70: 44 01 e0                     	addl	%r12d, %eax
    2f73: d1 e8                        	shrl	%eax
    2f75: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2f79: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2f7e: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2f83: e8 00 00 00 00               	callq	0x2f88 <trusted_x86_x86_sim_xdp+0x2f88>
		0000000000002f84:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2f88: 48 85 c0                     	testq	%rax, %rax
    2f8b: 0f 84 20 04 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2f91: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2f95: 8d 69 01                     	leal	0x1(%rcx), %ebp
    2f98: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2f9d: 0f b7 00                     	movzwl	(%rax), %eax
    2fa0: 48 39 c2                     	cmpq	%rax, %rdx
    2fa3: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    2fa7: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    2fac: 0f 42 d1                     	cmovbl	%ecx, %edx
    2faf: 48 89 d0                     	movq	%rdx, %rax
    2fb2: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    2fb7: 39 d5                        	cmpl	%edx, %ebp
    2fb9: 0f 83 be 04 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    2fbf: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    2fc4: 01 e8                        	addl	%ebp, %eax
    2fc6: d1 e8                        	shrl	%eax
    2fc8: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    2fcc: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    2fd1: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    2fd6: e8 00 00 00 00               	callq	0x2fdb <trusted_x86_x86_sim_xdp+0x2fdb>
		0000000000002fd7:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    2fdb: 48 85 c0                     	testq	%rax, %rax
    2fde: 0f 84 cd 03 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    2fe4: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    2fe8: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    2fec: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    2ff1: 0f b7 00                     	movzwl	(%rax), %eax
    2ff4: 48 39 c2                     	cmpq	%rax, %rdx
    2ff7: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    2ffb: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    3000: 0f 42 d1                     	cmovbl	%ecx, %edx
    3003: 48 89 d0                     	movq	%rdx, %rax
    3006: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    300b: 41 39 d4                     	cmpl	%edx, %r12d
    300e: 0f 83 69 04 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3014: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3019: 44 01 e0                     	addl	%r12d, %eax
    301c: d1 e8                        	shrl	%eax
    301e: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    3022: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3027: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    302c: e8 00 00 00 00               	callq	0x3031 <trusted_x86_x86_sim_xdp+0x3031>
		000000000000302d:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3031: 48 85 c0                     	testq	%rax, %rax
    3034: 0f 84 77 03 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    303a: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    303e: 8d 69 01                     	leal	0x1(%rcx), %ebp
    3041: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    3046: 0f b7 00                     	movzwl	(%rax), %eax
    3049: 48 39 c2                     	cmpq	%rax, %rdx
    304c: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    3050: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    3055: 0f 42 d1                     	cmovbl	%ecx, %edx
    3058: 48 89 d0                     	movq	%rdx, %rax
    305b: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    3060: 39 d5                        	cmpl	%edx, %ebp
    3062: 0f 83 15 04 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3068: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    306d: 01 e8                        	addl	%ebp, %eax
    306f: d1 e8                        	shrl	%eax
    3071: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    3075: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    307a: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    307f: e8 00 00 00 00               	callq	0x3084 <trusted_x86_x86_sim_xdp+0x3084>
		0000000000003080:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3084: 48 85 c0                     	testq	%rax, %rax
    3087: 0f 84 24 03 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    308d: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    3091: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3095: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    309a: 0f b7 00                     	movzwl	(%rax), %eax
    309d: 48 39 c2                     	cmpq	%rax, %rdx
    30a0: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    30a4: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    30a9: 0f 42 d1                     	cmovbl	%ecx, %edx
    30ac: 48 89 d0                     	movq	%rdx, %rax
    30af: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    30b4: 41 39 d4                     	cmpl	%edx, %r12d
    30b7: 0f 83 c0 03 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    30bd: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    30c2: 44 01 e0                     	addl	%r12d, %eax
    30c5: d1 e8                        	shrl	%eax
    30c7: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    30cb: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    30d0: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    30d5: e8 00 00 00 00               	callq	0x30da <trusted_x86_x86_sim_xdp+0x30da>
		00000000000030d6:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    30da: 48 85 c0                     	testq	%rax, %rax
    30dd: 0f 84 ce 02 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    30e3: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    30e7: 8d 69 01                     	leal	0x1(%rcx), %ebp
    30ea: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    30ef: 0f b7 00                     	movzwl	(%rax), %eax
    30f2: 48 39 c2                     	cmpq	%rax, %rdx
    30f5: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    30f9: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    30fe: 0f 42 d1                     	cmovbl	%ecx, %edx
    3101: 48 89 d0                     	movq	%rdx, %rax
    3104: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    3109: 39 d5                        	cmpl	%edx, %ebp
    310b: 0f 83 6c 03 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3111: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3116: 01 e8                        	addl	%ebp, %eax
    3118: d1 e8                        	shrl	%eax
    311a: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    311e: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3123: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    3128: e8 00 00 00 00               	callq	0x312d <trusted_x86_x86_sim_xdp+0x312d>
		0000000000003129:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    312d: 48 85 c0                     	testq	%rax, %rax
    3130: 0f 84 7b 02 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    3136: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    313a: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    313e: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    3143: 0f b7 00                     	movzwl	(%rax), %eax
    3146: 48 39 c2                     	cmpq	%rax, %rdx
    3149: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    314d: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    3152: 0f 42 d1                     	cmovbl	%ecx, %edx
    3155: 48 89 d0                     	movq	%rdx, %rax
    3158: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    315d: 41 39 d4                     	cmpl	%edx, %r12d
    3160: 0f 83 17 03 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3166: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    316b: 44 01 e0                     	addl	%r12d, %eax
    316e: d1 e8                        	shrl	%eax
    3170: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    3174: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3179: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    317e: e8 00 00 00 00               	callq	0x3183 <trusted_x86_x86_sim_xdp+0x3183>
		000000000000317f:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3183: 48 85 c0                     	testq	%rax, %rax
    3186: 0f 84 25 02 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    318c: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    3190: 8d 69 01                     	leal	0x1(%rcx), %ebp
    3193: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    3198: 0f b7 00                     	movzwl	(%rax), %eax
    319b: 48 39 c2                     	cmpq	%rax, %rdx
    319e: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    31a2: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    31a7: 0f 42 d1                     	cmovbl	%ecx, %edx
    31aa: 48 89 d0                     	movq	%rdx, %rax
    31ad: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    31b2: 39 d5                        	cmpl	%edx, %ebp
    31b4: 0f 83 c3 02 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    31ba: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    31bf: 01 e8                        	addl	%ebp, %eax
    31c1: d1 e8                        	shrl	%eax
    31c3: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    31c7: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    31cc: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    31d1: e8 00 00 00 00               	callq	0x31d6 <trusted_x86_x86_sim_xdp+0x31d6>
		00000000000031d2:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    31d6: 48 85 c0                     	testq	%rax, %rax
    31d9: 0f 84 d2 01 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    31df: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    31e3: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    31e7: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    31ec: 0f b7 00                     	movzwl	(%rax), %eax
    31ef: 48 39 c2                     	cmpq	%rax, %rdx
    31f2: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    31f6: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    31fb: 0f 42 d1                     	cmovbl	%ecx, %edx
    31fe: 48 89 d0                     	movq	%rdx, %rax
    3201: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    3206: 41 39 d4                     	cmpl	%edx, %r12d
    3209: 0f 83 6e 02 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    320f: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3214: 44 01 e0                     	addl	%r12d, %eax
    3217: d1 e8                        	shrl	%eax
    3219: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    321d: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3222: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    3227: e8 00 00 00 00               	callq	0x322c <trusted_x86_x86_sim_xdp+0x322c>
		0000000000003228:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    322c: 48 85 c0                     	testq	%rax, %rax
    322f: 0f 84 7c 01 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    3235: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    3239: 8d 69 01                     	leal	0x1(%rcx), %ebp
    323c: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    3241: 0f b7 00                     	movzwl	(%rax), %eax
    3244: 48 39 c2                     	cmpq	%rax, %rdx
    3247: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    324b: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    3250: 0f 42 d1                     	cmovbl	%ecx, %edx
    3253: 48 89 d0                     	movq	%rdx, %rax
    3256: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    325b: 39 d5                        	cmpl	%edx, %ebp
    325d: 0f 83 1a 02 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3263: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3268: 01 e8                        	addl	%ebp, %eax
    326a: d1 e8                        	shrl	%eax
    326c: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    3270: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3275: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    327a: e8 00 00 00 00               	callq	0x327f <trusted_x86_x86_sim_xdp+0x327f>
		000000000000327b:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    327f: 48 85 c0                     	testq	%rax, %rax
    3282: 0f 84 29 01 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    3288: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    328c: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3290: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    3295: 0f b7 00                     	movzwl	(%rax), %eax
    3298: 48 39 c2                     	cmpq	%rax, %rdx
    329b: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    329f: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    32a4: 0f 42 d1                     	cmovbl	%ecx, %edx
    32a7: 48 89 d0                     	movq	%rdx, %rax
    32aa: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    32af: 41 39 d4                     	cmpl	%edx, %r12d
    32b2: 0f 83 c5 01 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    32b8: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    32bd: 44 01 e0                     	addl	%r12d, %eax
    32c0: d1 e8                        	shrl	%eax
    32c2: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    32c6: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    32cb: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    32d0: e8 00 00 00 00               	callq	0x32d5 <trusted_x86_x86_sim_xdp+0x32d5>
		00000000000032d1:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    32d5: 48 85 c0                     	testq	%rax, %rax
    32d8: 0f 84 d3 00 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    32de: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    32e2: 8d 69 01                     	leal	0x1(%rcx), %ebp
    32e5: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    32ea: 0f b7 00                     	movzwl	(%rax), %eax
    32ed: 48 39 c2                     	cmpq	%rax, %rdx
    32f0: 41 0f 42 ec                  	cmovbl	%r12d, %ebp
    32f4: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    32f9: 0f 42 d1                     	cmovbl	%ecx, %edx
    32fc: 48 89 d0                     	movq	%rdx, %rax
    32ff: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    3304: 39 d5                        	cmpl	%edx, %ebp
    3306: 0f 83 71 01 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    330c: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3311: 01 e8                        	addl	%ebp, %eax
    3313: d1 e8                        	shrl	%eax
    3315: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    3319: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    331e: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    3323: e8 00 00 00 00               	callq	0x3328 <trusted_x86_x86_sim_xdp+0x3328>
		0000000000003324:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3328: 48 85 c0                     	testq	%rax, %rax
    332b: 0f 84 80 00 00 00            	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    3331: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    3335: 44 8d 61 01                  	leal	0x1(%rcx), %r12d
    3339: 0f b7 54 24 30               	movzwl	0x30(%rsp), %edx
    333e: 0f b7 00                     	movzwl	(%rax), %eax
    3341: 48 39 c2                     	cmpq	%rax, %rdx
    3344: 44 0f 42 e5                  	cmovbl	%ebp, %r12d
    3348: 48 8b 54 24 08               	movq	0x8(%rsp), %rdx
    334d: 0f 42 d1                     	cmovbl	%ecx, %edx
    3350: 48 89 d0                     	movq	%rdx, %rax
    3353: 48 89 54 24 08               	movq	%rdx, 0x8(%rsp)
    3358: 41 39 d4                     	cmpl	%edx, %r12d
    335b: 0f 83 1c 01 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    3361: 48 8b 44 24 08               	movq	0x8(%rsp), %rax
    3366: 44 01 e0                     	addl	%r12d, %eax
    3369: d1 e8                        	shrl	%eax
    336b: 89 44 24 2c                  	movl	%eax, 0x2c(%rsp)
    336f: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    3374: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    3379: e8 00 00 00 00               	callq	0x337e <trusted_x86_x86_sim_xdp+0x337e>
		000000000000337a:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    337e: 48 85 c0                     	testq	%rax, %rax
    3381: 74 2e                        	je	0x33b1 <trusted_x86_x86_sim_xdp+0x33b1>
    3383: 8b 4c 24 2c                  	movl	0x2c(%rsp), %ecx
    3387: 8d 51 01                     	leal	0x1(%rcx), %edx
    338a: 0f b7 74 24 30               	movzwl	0x30(%rsp), %esi
    338f: 0f b7 00                     	movzwl	(%rax), %eax
    3392: 48 39 c6                     	cmpq	%rax, %rsi
    3395: 41 0f 42 d4                  	cmovbl	%r12d, %edx
    3399: 48 8b 74 24 08               	movq	0x8(%rsp), %rsi
    339e: 0f 42 f1                     	cmovbl	%ecx, %esi
    33a1: 48 89 f0                     	movq	%rsi, %rax
    33a4: 48 89 74 24 08               	movq	%rsi, 0x8(%rsp)
    33a9: 39 f2                        	cmpl	%esi, %edx
    33ab: 0f 83 cc 00 00 00            	jae	0x347d <trusted_x86_x86_sim_xdp+0x347d>
    33b1: be 09 00 00 00               	movl	$0x9, %esi
    33b6: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
    33bd: 89 30                        	movl	%esi, (%rax)
    33bf: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    33c4: 31 ed                        	xorl	%ebp, %ebp
    33c6: 49 81 c6 2c 0f 00 00         	addq	$0xf2c, %r14            # imm = 0xF2C
    33cd: 45 89 2e                     	movl	%r13d, (%r14)
    33d0: c7 84 24 a8 00 00 00 00 00 00 00     	movl	$0x0, 0xa8(%rsp)
    33db: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x33e2 <trusted_x86_x86_sim_xdp+0x33e2>
		00000000000033de:  R_X86_64_REX_GOTPCRELX	per_cpu_records-0x4
    33e2: 48 89 de                     	movq	%rbx, %rsi
    33e5: e8 00 00 00 00               	callq	0x33ea <trusted_x86_x86_sim_xdp+0x33ea>
		00000000000033e6:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    33ea: 48 85 c0                     	testq	%rax, %rax
    33ed: 74 64                        	je	0x3453 <trusted_x86_x86_sim_xdp+0x3453>
    33ef: 48 89 c1                     	movq	%rax, %rcx
    33f2: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
    33f9: 80 f9 1d                     	cmpb	$0x1d, %cl
    33fc: 72 49                        	jb	0x3447 <trusted_x86_x86_sim_xdp+0x3447>
    33fe: 49 89 c6                     	movq	%rax, %r14
    3401: 48 05 2c 0f 00 00            	addq	$0xf2c, %rax            # imm = 0xF2C
    3407: c7 00 05 00 00 00            	movl	$0x5, (%rax)
    340d: c7 84 24 a8 00 00 00 44 00 00 00     	movl	$0x44, 0xa8(%rsp)
    3418: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x341f <trusted_x86_x86_sim_xdp+0x341f>
		000000000000341b:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    341f: 48 89 de                     	movq	%rbx, %rsi
    3422: e8 00 00 00 00               	callq	0x3427 <trusted_x86_x86_sim_xdp+0x3427>
		0000000000003423:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3427: 48 85 c0                     	testq	%rax, %rax
    342a: 74 0c                        	je	0x3438 <trusted_x86_x86_sim_xdp+0x3438>
    342c: 48 89 c1                     	movq	%rax, %rcx
    342f: 48 8b 09                     	movq	(%rcx), %rcx
    3432: 48 ff c1                     	incq	%rcx
    3435: 48 89 08                     	movq	%rcx, (%rax)
    3438: 4c 89 f0                     	movq	%r14, %rax
    343b: 4c 89 f1                     	movq	%r14, %rcx
    343e: 0f b6 89 84 13 00 00         	movzbl	0x1384(%rcx), %ecx
    3445: 31 ed                        	xorl	%ebp, %ebp
    3447: fe c1                        	incb	%cl
    3449: 48 05 84 13 00 00            	addq	$0x1384, %rax           # imm = 0x1384
    344f: 88 08                        	movb	%cl, (%rax)
    3451: eb 02                        	jmp	0x3455 <trusted_x86_x86_sim_xdp+0x3455>
    3453: 31 ed                        	xorl	%ebp, %ebp
    3455: 48 8b 35 00 00 00 00         	movq	(%rip), %rsi            # 0x345c <trusted_x86_x86_sim_xdp+0x345c>
		0000000000003458:  R_X86_64_REX_GOTPCRELX	perf_progs-0x4
    345c: 4c 89 e7                     	movq	%r12, %rdi
    345f: 89 ea                        	movl	%ebp, %edx
    3461: e8 00 00 00 00               	callq	0x3466 <trusted_x86_x86_sim_xdp+0x3466>
		0000000000003462:  R_X86_64_PLT32	bpf_tail_call-0x4
    3466: b8 ff ff ff ff               	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    346b: 48 81 c4 f8 01 00 00         	addq	$0x1f8, %rsp            # imm = 0x1F8
    3472: 5b                           	popq	%rbx
    3473: 41 5c                        	popq	%r12
    3475: 41 5d                        	popq	%r13
    3477: 41 5e                        	popq	%r14
    3479: 41 5f                        	popq	%r15
    347b: 5d                           	popq	%rbp
    347c: c3                           	retq
    347d: 83 7c 24 08 00               	cmpl	$0x0, 0x8(%rsp)
    3482: be 09 00 00 00               	movl	$0x9, %esi
    3487: 0f 84 29 ff ff ff            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    348d: 48 8b 6c 24 08               	movq	0x8(%rsp), %rbp
    3492: ff cd                        	decl	%ebp
    3494: 89 6c 24 54                  	movl	%ebp, 0x54(%rsp)
    3498: 48 8b 7c 24 38               	movq	0x38(%rsp), %rdi
    349d: 48 8d 74 24 54               	leaq	0x54(%rsp), %rsi
    34a2: e8 00 00 00 00               	callq	0x34a7 <trusted_x86_x86_sim_xdp+0x34a7>
		00000000000034a3:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    34a7: be 0a 00 00 00               	movl	$0xa, %esi
    34ac: 41 bd a4 0f 00 00            	movl	$0xfa4, %r13d           # imm = 0xFA4
    34b2: 48 85 c0                     	testq	%rax, %rax
    34b5: 0f 84 fb fe ff ff            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    34bb: 0f b7 4c 24 30               	movzwl	0x30(%rsp), %ecx
    34c0: 48 89 c2                     	movq	%rax, %rdx
    34c3: 0f b7 12                     	movzwl	(%rdx), %edx
    34c6: 29 d1                        	subl	%edx, %ecx
    34c8: 8b 54 24 54                  	movl	0x54(%rsp), %edx
    34cc: 8d a9 00 00 01 00            	leal	0x10000(%rcx), %ebp
    34d2: 41 8b 37                     	movl	(%r15), %esi
    34d5: 39 d6                        	cmpl	%edx, %esi
    34d7: 0f 46 e9                     	cmovbel	%ecx, %ebp
    34da: 0f b7 40 02                  	movzwl	0x2(%rax), %eax
    34de: 89 44 24 50                  	movl	%eax, 0x50(%rsp)
    34e2: be 0d 00 00 00               	movl	$0xd, %esi
    34e7: 41 bd a5 0f 00 00            	movl	$0xfa5, %r13d           # imm = 0xFA5
    34ed: 3d 00 80 00 00               	cmpl	$0x8000, %eax           # imm = 0x8000
    34f2: 0f 84 be fe ff ff            	je	0x33b6 <trusted_x86_x86_sim_xdp+0x33b6>
    34f8: 3d 01 80 00 00               	cmpl	$0x8001, %eax           # imm = 0x8001
    34fd: 75 2e                        	jne	0x352d <trusted_x86_x86_sim_xdp+0x352d>
    34ff: c7 44 24 2c 07 00 00 00      	movl	$0x7, 0x2c(%rsp)
    3507: 48 8d 74 24 2c               	leaq	0x2c(%rsp), %rsi
    350c: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3513 <trusted_x86_x86_sim_xdp+0x3513>
		000000000000350f:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3513: e8 00 00 00 00               	callq	0x3518 <trusted_x86_x86_sim_xdp+0x3518>
		0000000000003514:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3518: 48 85 c0                     	testq	%rax, %rax
    351b: 74 0c                        	je	0x3529 <trusted_x86_x86_sim_xdp+0x3529>
    351d: 48 89 c1                     	movq	%rax, %rcx
    3520: 48 8b 09                     	movq	(%rcx), %rcx
    3523: 48 ff c1                     	incq	%rcx
    3526: 48 89 08                     	movq	%rcx, (%rax)
    3529: 8b 44 24 50                  	movl	0x50(%rsp), %eax
    352d: 66 85 c0                     	testw	%ax, %ax
    3530: 78 1c                        	js	0x354e <trusted_x86_x86_sim_xdp+0x354e>
    3532: 48 8d 7c 24 50               	leaq	0x50(%rsp), %rdi
    3537: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x353e <trusted_x86_x86_sim_xdp+0x353e>
		000000000000353a:  R_X86_64_REX_GOTPCRELX	unwind_info_array-0x4
    353e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3545 <trusted_x86_x86_sim_xdp+0x3545>
		0000000000003541:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3545: 75 5f                        	jne	0x35a6 <trusted_x86_x86_sim_xdp+0x35a6>
    3547: e8 00 00 00 00               	callq	0x354c <trusted_x86_x86_sim_xdp+0x354c>
		0000000000003548:  R_X86_64_PLT32	.text+0x5c
    354c: eb 7a                        	jmp	0x35c8 <trusted_x86_x86_sim_xdp+0x35c8>
    354e: 25 ff 7f ff ff               	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
    3553: ff c8                        	decl	%eax
    3555: 83 f8 03                     	cmpl	$0x3, %eax
    3558: 77 3a                        	ja	0x3594 <trusted_x86_x86_sim_xdp+0x3594>
    355a: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x3561 <trusted_x86_x86_sim_xdp+0x3561>
		000000000000355d:  R_X86_64_PC32	.rodata+0x224
    3561: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    3565: 48 01 c8                     	addq	%rcx, %rax
    3568: ff e0                        	jmpq	*%rax
    356a: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    356f: 48 8b 8c 24 98 00 00 00      	movq	0x98(%rsp), %rcx
    3577: 48 8b 00                     	movq	(%rax), %rax
    357a: 8b 09                        	movl	(%rcx), %ecx
    357c: 83 e1 0f                     	andl	$0xf, %ecx
    357f: 31 d2                        	xorl	%edx, %edx
    3581: 83 f9 0b                     	cmpl	$0xb, %ecx
    3584: 0f 93 c2                     	setae	%dl
    3587: 4c 8d 2c d0                  	leaq	(%rax,%rdx,8), %r13
    358b: 49 83 c5 08                  	addq	$0x8, %r13
    358f: e9 57 04 00 00               	jmp	0x39eb <trusted_x86_x86_sim_xdp+0x39eb>
    3594: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    3599: 41 bd 01 00 00 00            	movl	$0x1, %r13d
    359f: 31 ed                        	xorl	%ebp, %ebp
    35a1: e9 20 fe ff ff               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
    35a6: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x35ad <trusted_x86_x86_sim_xdp+0x35ad>
		00000000000035a9:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    35ad: 75 07                        	jne	0x35b6 <trusted_x86_x86_sim_xdp+0x35b6>
    35af: e8 00 00 00 00               	callq	0x35b4 <trusted_x86_x86_sim_xdp+0x35b4>
		00000000000035b0:  R_X86_64_PLT32	.text+0x10c
    35b4: eb 12                        	jmp	0x35c8 <trusted_x86_x86_sim_xdp+0x35c8>
    35b6: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x35bd <trusted_x86_x86_sim_xdp+0x35bd>
		00000000000035b9:  R_X86_64_REX_GOTPCRELX	stack_delta_page_to_info-0x4
    35bd: 0f 85 d3 01 00 00            	jne	0x3796 <trusted_x86_x86_sim_xdp+0x3796>
    35c3: e8 00 00 00 00               	callq	0x35c8 <trusted_x86_x86_sim_xdp+0x35c8>
		00000000000035c4:  R_X86_64_PLT32	.text+0x1bc
    35c8: 49 89 c4                     	movq	%rax, %r12
    35cb: 48 85 c0                     	testq	%rax, %rax
    35ce: 0f 84 eb 01 00 00            	je	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    35d4: 4c 89 e0                     	movq	%r12, %rax
    35d7: 44 8b 78 04                  	movl	0x4(%rax), %r15d
    35db: 4c 89 e0                     	movq	%r12, %rax
    35de: 0f b6 40 02                  	movzbl	0x2(%rax), %eax
    35e2: 85 c0                        	testl	%eax, %eax
    35e4: 74 21                        	je	0x3607 <trusted_x86_x86_sim_xdp+0x3607>
    35e6: 89 c1                        	movl	%eax, %ecx
    35e8: 83 e1 7f                     	andl	$0x7f, %ecx
    35eb: 48 c1 e5 20                  	shlq	$0x20, %rbp
    35ef: 48 c1 e1 20                  	shlq	$0x20, %rcx
    35f3: 48 39 cd                     	cmpq	%rcx, %rbp
    35f6: 7c 0f                        	jl	0x3607 <trusted_x86_x86_sim_xdp+0x3607>
    35f8: f7 d0                        	notl	%eax
    35fa: c1 e8 03                     	shrl	$0x3, %eax
    35fd: 83 e0 10                     	andl	$0x10, %eax
    3600: 41 01 c7                     	addl	%eax, %r15d
    3603: 41 83 c7 f8                  	addl	$-0x8, %r15d
    3607: 4c 89 e0                     	movq	%r12, %rax
    360a: 0f b6 00                     	movzbl	(%rax), %eax
    360d: 44 89 f9                     	movl	%r15d, %ecx
    3610: 83 e1 f8                     	andl	$-0x8, %ecx
    3613: 84 c0                        	testb	%al, %al
    3615: 41 0f 49 cf                  	cmovnsl	%r15d, %ecx
    3619: 89 c2                        	movl	%eax, %edx
    361b: 83 e2 7f                     	andl	$0x7f, %edx
    361e: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    3621: 83 fe 04                     	cmpl	$0x4, %esi
    3624: 0f 87 38 02 00 00            	ja	0x3862 <trusted_x86_x86_sim_xdp+0x3862>
    362a: 0f b6 d2                     	movzbl	%dl, %edx
    362d: 45 31 ed                     	xorl	%r13d, %r13d
    3630: ff ca                        	decl	%edx
    3632: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x3639 <trusted_x86_x86_sim_xdp+0x3639>
		0000000000003635:  R_X86_64_PC32	.rodata+0x234
    3639: 48 63 14 96                  	movslq	(%rsi,%rdx,4), %rdx
    363d: 48 01 f2                     	addq	%rsi, %rdx
    3640: ff e2                        	jmpq	*%rdx
    3642: 31 d2                        	xorl	%edx, %edx
    3644: e9 cd 01 00 00               	jmp	0x3816 <trusted_x86_x86_sim_xdp+0x3816>
    3649: 48 8b 44 24 78               	movq	0x78(%rsp), %rax
    364e: 48 8b 30                     	movq	(%rax), %rsi
    3651: 48 83 c6 28                  	addq	$0x28, %rsi
    3655: ba 90 00 00 00               	movl	$0x90, %edx
    365a: 48 89 df                     	movq	%rbx, %rdi
    365d: e8 00 00 00 00               	callq	0x3662 <trusted_x86_x86_sim_xdp+0x3662>
		000000000000365e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3662: 49 89 c4                     	movq	%rax, %r12
    3665: 45 85 e4                     	testl	%r12d, %r12d
    3668: 79 0f                        	jns	0x3679 <trusted_x86_x86_sim_xdp+0x3679>
    366a: ba 90 00 00 00               	movl	$0x90, %edx
    366f: 48 89 df                     	movq	%rbx, %rdi
    3672: 31 f6                        	xorl	%esi, %esi
    3674: e8 00 00 00 00               	callq	0x3679 <trusted_x86_x86_sim_xdp+0x3679>
		0000000000003675:  R_X86_64_PLT32	memset-0x4
    3679: 45 85 e4                     	testl	%r12d, %r12d
    367c: 48 8b 94 24 70 01 00 00      	movq	0x170(%rsp), %rdx
    3684: 48 8b 74 24 20               	movq	0x20(%rsp), %rsi
    3689: 0f 85 cd d6 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    368f: 48 8b 84 24 10 01 00 00      	movq	0x110(%rsp), %rax
    3697: 48 8b 8c 24 98 01 00 00      	movq	0x198(%rsp), %rcx
    369f: 48 89 01                     	movq	%rax, (%rcx)
    36a2: 48 8b 84 24 b0 00 00 00      	movq	0xb0(%rsp), %rax
    36aa: 48 8b 8c 24 78 01 00 00      	movq	0x178(%rsp), %rcx
    36b2: 48 89 01                     	movq	%rax, (%rcx)
    36b5: 48 8b 84 24 c0 00 00 00      	movq	0xc0(%rsp), %rax
    36bd: 48 8b 8c 24 88 01 00 00      	movq	0x188(%rsp), %rcx
    36c5: 48 89 01                     	movq	%rax, (%rcx)
    36c8: 48 8b 84 24 d0 00 00 00      	movq	0xd0(%rsp), %rax
    36d0: 49 8d 8e 00 0f 00 00         	leaq	0xf00(%r14), %rcx
    36d7: 48 89 01                     	movq	%rax, (%rcx)
    36da: 48 8b 84 24 e0 00 00 00      	movq	0xe0(%rsp), %rax
    36e2: 48 8b 8c 24 90 01 00 00      	movq	0x190(%rsp), %rcx
    36ea: 48 89 01                     	movq	%rax, (%rcx)
    36ed: 48 8b 84 24 f8 00 00 00      	movq	0xf8(%rsp), %rax
    36f5: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    36fd: 48 89 01                     	movq	%rax, (%rcx)
    3700: 48 8b 84 24 20 01 00 00      	movq	0x120(%rsp), %rax
    3708: 48 89 02                     	movq	%rax, (%rdx)
    370b: 48 8b 84 24 28 01 00 00      	movq	0x128(%rsp), %rax
    3713: 48 89 06                     	movq	%rax, (%rsi)
    3716: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    371d: 31 c9                        	xorl	%ecx, %ecx
    371f: e9 11 03 00 00               	jmp	0x3a35 <trusted_x86_x86_sim_xdp+0x3a35>
    3724: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    3729: 48 8b 30                     	movq	(%rax), %rsi
    372c: ba 10 00 00 00               	movl	$0x10, %edx
    3731: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    3736: e8 00 00 00 00               	callq	0x373b <trusted_x86_x86_sim_xdp+0x373b>
		0000000000003737:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    373b: 85 c0                        	testl	%eax, %eax
    373d: 79 14                        	jns	0x3753 <trusted_x86_x86_sim_xdp+0x3753>
    373f: 48 8d 4c 24 58               	leaq	0x58(%rsp), %rcx
    3744: 48 c7 41 08 00 00 00 00      	movq	$0x0, 0x8(%rcx)
    374c: 48 c7 01 00 00 00 00         	movq	$0x0, (%rcx)
    3753: 85 c0                        	testl	%eax, %eax
    3755: 48 8b 8c 24 70 01 00 00      	movq	0x170(%rsp), %rcx
    375d: 48 8b 54 24 20               	movq	0x20(%rsp), %rdx
    3762: 0f 85 f4 d5 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    3768: 4c 89 f0                     	movq	%r14, %rax
    376b: 48 8b 80 e0 0e 00 00         	movq	0xee0(%rax), %rax
    3772: 48 83 c0 10                  	addq	$0x10, %rax
    3776: 48 89 01                     	movq	%rax, (%rcx)
    3779: 48 8b 44 24 58               	movq	0x58(%rsp), %rax
    377e: 48 8b 8c 24 80 01 00 00      	movq	0x180(%rsp), %rcx
    3786: 48 89 01                     	movq	%rax, (%rcx)
    3789: 4c 8b 6c 24 60               	movq	0x60(%rsp), %r13
    378e: 48 89 d0                     	movq	%rdx, %rax
    3791: e9 93 02 00 00               	jmp	0x3a29 <trusted_x86_x86_sim_xdp+0x3a29>
    3796: 8b 4c 24 50                  	movl	0x50(%rsp), %ecx
    379a: 3b 48 44                     	cmpl	0x44(%rax), %ecx
    379d: 73 20                        	jae	0x37bf <trusted_x86_x86_sim_xdp+0x37bf>
    379f: 8b 90 20 01 00 00            	movl	0x120(%rax), %edx
    37a5: 23 88 24 01 00 00            	andl	0x124(%rax), %ecx
    37ab: 48 0f af ca                  	imulq	%rdx, %rcx
    37af: 4c 8d 24 08                  	leaq	(%rax,%rcx), %r12
    37b3: 49 81 c4 30 01 00 00         	addq	$0x130, %r12            # imm = 0x130
    37ba: e9 15 fe ff ff               	jmp	0x35d4 <trusted_x86_x86_sim_xdp+0x35d4>
    37bf: c7 44 24 58 55 00 00 00      	movl	$0x55, 0x58(%rsp)
    37c7: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x37ce <trusted_x86_x86_sim_xdp+0x37ce>
		00000000000037ca:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    37ce: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    37d3: e8 00 00 00 00               	callq	0x37d8 <trusted_x86_x86_sim_xdp+0x37d8>
		00000000000037d4:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    37d8: 48 85 c0                     	testq	%rax, %rax
    37db: 74 0c                        	je	0x37e9 <trusted_x86_x86_sim_xdp+0x37e9>
    37dd: 48 89 c1                     	movq	%rax, %rcx
    37e0: 48 8b 09                     	movq	(%rcx), %rcx
    37e3: 48 ff c1                     	incq	%rcx
    37e6: 48 89 08                     	movq	%rcx, (%rax)
    37e9: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    37ee: 41 bd af 0f 00 00            	movl	$0xfaf, %r13d           # imm = 0xFAF
    37f4: 31 ed                        	xorl	%ebp, %ebp
    37f6: e9 cb fb ff ff               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
    37fb: 48 8d 54 24 78               	leaq	0x78(%rsp), %rdx
    3800: 48 89 94 24 c0 01 00 00      	movq	%rdx, 0x1c0(%rsp)
    3808: 48 8b 94 24 c0 01 00 00      	movq	0x1c0(%rsp), %rdx
    3810: 48 8b 12                     	movq	(%rdx), %rdx
    3813: 48 8b 12                     	movq	(%rdx), %rdx
    3816: 4c 63 e9                     	movslq	%ecx, %r13
    3819: 49 01 d5                     	addq	%rdx, %r13
    381c: 84 c0                        	testb	%al, %al
    381e: 79 45                        	jns	0x3865 <trusted_x86_x86_sim_xdp+0x3865>
    3820: ba 08 00 00 00               	movl	$0x8, %edx
    3825: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    382a: 4c 89 ee                     	movq	%r13, %rsi
    382d: e8 00 00 00 00               	callq	0x3832 <trusted_x86_x86_sim_xdp+0x3832>
		000000000000382e:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3832: 85 c0                        	testl	%eax, %eax
    3834: 79 09                        	jns	0x383f <trusted_x86_x86_sim_xdp+0x383f>
    3836: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    383f: 85 c0                        	testl	%eax, %eax
    3841: 0f 84 dc 00 00 00            	je	0x3923 <trusted_x86_x86_sim_xdp+0x3923>
    3847: 45 31 ed                     	xorl	%r13d, %r13d
    384a: eb 19                        	jmp	0x3865 <trusted_x86_x86_sim_xdp+0x3865>
    384c: 44 89 f8                     	movl	%r15d, %eax
    384f: 83 e0 0f                     	andl	$0xf, %eax
    3852: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x3859 <trusted_x86_x86_sim_xdp+0x3859>
		0000000000003855:  R_X86_64_PC32	.rodata+0x248
    3859: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    385d: 48 01 c8                     	addq	%rcx, %rax
    3860: ff e0                        	jmpq	*%rax
    3862: 45 31 ed                     	xorl	%r13d, %r13d
    3865: 4c 89 e0                     	movq	%r12, %rax
    3868: 0f b6 40 01                  	movzbl	0x1(%rax), %eax
    386c: 4c 89 e1                     	movq	%r12, %rcx
    386f: 44 8b 79 08                  	movl	0x8(%rcx), %r15d
    3873: 44 89 f9                     	movl	%r15d, %ecx
    3876: 83 e1 f8                     	andl	$-0x8, %ecx
    3879: 84 c0                        	testb	%al, %al
    387b: 41 0f 49 cf                  	cmovnsl	%r15d, %ecx
    387f: 89 c2                        	movl	%eax, %edx
    3881: 83 e2 7f                     	andl	$0x7f, %edx
    3884: 8d 72 ff                     	leal	-0x1(%rdx), %esi
    3887: 83 fe 04                     	cmpl	$0x4, %esi
    388a: 0f 87 46 01 00 00            	ja	0x39d6 <trusted_x86_x86_sim_xdp+0x39d6>
    3890: 0f b6 d2                     	movzbl	%dl, %edx
    3893: ff ca                        	decl	%edx
    3895: 48 8d 35 00 00 00 00         	leaq	(%rip), %rsi            # 0x389c <trusted_x86_x86_sim_xdp+0x389c>
		0000000000003898:  R_X86_64_PC32	.rodata+0x288
    389c: 48 63 3c 96                  	movslq	(%rsi,%rdx,4), %rdi
    38a0: 48 01 f7                     	addq	%rsi, %rdi
    38a3: 4c 89 ea                     	movq	%r13, %rdx
    38a6: ff e7                        	jmpq	*%rdi
    38a8: 48 8b 54 24 78               	movq	0x78(%rsp), %rdx
    38ad: eb 0a                        	jmp	0x38b9 <trusted_x86_x86_sim_xdp+0x38b9>
    38af: 48 8b 54 24 48               	movq	0x48(%rsp), %rdx
    38b4: 48 89 54 24 78               	movq	%rdx, 0x78(%rsp)
    38b9: 48 8b 12                     	movq	(%rdx), %rdx
    38bc: 48 63 f1                     	movslq	%ecx, %rsi
    38bf: 48 01 d6                     	addq	%rdx, %rsi
    38c2: 84 c0                        	testb	%al, %al
    38c4: 0f 89 e7 00 00 00            	jns	0x39b1 <trusted_x86_x86_sim_xdp+0x39b1>
    38ca: ba 08 00 00 00               	movl	$0x8, %edx
    38cf: 48 8d 7c 24 58               	leaq	0x58(%rsp), %rdi
    38d4: e8 00 00 00 00               	callq	0x38d9 <trusted_x86_x86_sim_xdp+0x38d9>
		00000000000038d5:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    38d9: 85 c0                        	testl	%eax, %eax
    38db: 79 09                        	jns	0x38e6 <trusted_x86_x86_sim_xdp+0x38e6>
    38dd: 48 c7 44 24 58 00 00 00 00   	movq	$0x0, 0x58(%rsp)
    38e6: 85 c0                        	testl	%eax, %eax
    38e8: 0f 85 e8 00 00 00            	jne	0x39d6 <trusted_x86_x86_sim_xdp+0x39d6>
    38ee: 41 c1 e7 03                  	shll	$0x3, %r15d
    38f2: 41 83 e7 38                  	andl	$0x38, %r15d
    38f6: 4c 03 7c 24 58               	addq	0x58(%rsp), %r15
    38fb: 4c 89 fe                     	movq	%r15, %rsi
    38fe: e9 ae 00 00 00               	jmp	0x39b1 <trusted_x86_x86_sim_xdp+0x39b1>
    3903: 44 89 f8                     	movl	%r15d, %eax
    3906: 83 e0 0f                     	andl	$0xf, %eax
    3909: 48 8d 0d 00 00 00 00         	leaq	(%rip), %rcx            # 0x3910 <trusted_x86_x86_sim_xdp+0x3910>
		000000000000390c:  R_X86_64_PC32	.rodata+0x29c
    3910: 48 63 04 81                  	movslq	(%rcx,%rax,4), %rax
    3914: 48 01 c8                     	addq	%rcx, %rax
    3917: ff e0                        	jmpq	*%rax
    3919: 48 8b 84 24 80 00 00 00      	movq	0x80(%rsp), %rax
    3921: eb 77                        	jmp	0x399a <trusted_x86_x86_sim_xdp+0x399a>
    3923: 41 c1 e7 03                  	shll	$0x3, %r15d
    3927: 41 83 e7 38                  	andl	$0x38, %r15d
    392b: 4c 03 7c 24 58               	addq	0x58(%rsp), %r15
    3930: 4d 89 fd                     	movq	%r15, %r13
    3933: e9 2d ff ff ff               	jmp	0x3865 <trusted_x86_x86_sim_xdp+0x3865>
    3938: 48 8d 84 24 90 00 00 00      	leaq	0x90(%rsp), %rax
    3940: eb 0f                        	jmp	0x3951 <trusted_x86_x86_sim_xdp+0x3951>
    3942: 48 8d 84 24 88 00 00 00      	leaq	0x88(%rsp), %rax
    394a: eb 05                        	jmp	0x3951 <trusted_x86_x86_sim_xdp+0x3951>
    394c: 48 8d 44 24 40               	leaq	0x40(%rsp), %rax
    3951: 48 89 44 24 10               	movq	%rax, 0x10(%rsp)
    3956: 48 8b 44 24 10               	movq	0x10(%rsp), %rax
    395b: 48 8b 00                     	movq	(%rax), %rax
    395e: 44 89 f9                     	movl	%r15d, %ecx
    3961: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    3967: 41 c1 ef 04                  	shrl	$0x4, %r15d
    396b: 42 8d 0c f9                  	leal	(%rcx,%r15,8), %ecx
    396f: 4c 63 e9                     	movslq	%ecx, %r13
    3972: 4c 03 28                     	addq	(%rax), %r13
    3975: e9 eb fe ff ff               	jmp	0x3865 <trusted_x86_x86_sim_xdp+0x3865>
    397a: b8 0d 00 00 00               	movl	$0xd, %eax
    397f: eb 0c                        	jmp	0x398d <trusted_x86_x86_sim_xdp+0x398d>
    3981: b8 0c 00 00 00               	movl	$0xc, %eax
    3986: eb 05                        	jmp	0x398d <trusted_x86_x86_sim_xdp+0x398d>
    3988: b8 03 00 00 00               	movl	$0x3, %eax
    398d: 48 8b 44 c4 28               	movq	0x28(%rsp,%rax,8), %rax
    3992: 48 89 84 24 80 00 00 00      	movq	%rax, 0x80(%rsp)
    399a: 44 89 f9                     	movl	%r15d, %ecx
    399d: 81 e1 00 00 00 80            	andl	$0x80000000, %ecx       # imm = 0x80000000
    39a3: 41 c1 ef 04                  	shrl	$0x4, %r15d
    39a7: 42 8d 0c f9                  	leal	(%rcx,%r15,8), %ecx
    39ab: 48 63 f1                     	movslq	%ecx, %rsi
    39ae: 48 03 30                     	addq	(%rax), %rsi
    39b1: 48 85 f6                     	testq	%rsi, %rsi
    39b4: 74 20                        	je	0x39d6 <trusted_x86_x86_sim_xdp+0x39d6>
    39b6: 4c 8b 64 24 48               	movq	0x48(%rsp), %r12
    39bb: ba 08 00 00 00               	movl	$0x8, %edx
    39c0: 4c 89 e7                     	movq	%r12, %rdi
    39c3: e8 00 00 00 00               	callq	0x39c8 <trusted_x86_x86_sim_xdp+0x39c8>
		00000000000039c4:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    39c8: 85 c0                        	testl	%eax, %eax
    39ca: 79 1f                        	jns	0x39eb <trusted_x86_x86_sim_xdp+0x39eb>
    39cc: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    39d4: eb 15                        	jmp	0x39eb <trusted_x86_x86_sim_xdp+0x39eb>
    39d6: 41 0f b6 04 24               	movzbl	(%r12), %eax
    39db: 3c 03                        	cmpb	$0x3, %al
    39dd: 75 0c                        	jne	0x39eb <trusted_x86_x86_sim_xdp+0x39eb>
    39df: 48 8b 44 24 48               	movq	0x48(%rsp), %rax
    39e4: 48 c7 00 00 00 00 00         	movq	$0x0, (%rax)
    39eb: 4d 85 ed                     	testq	%r13, %r13
    39ee: 0f 84 68 d3 ff ff            	je	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    39f4: 4c 8b a4 24 98 00 00 00      	movq	0x98(%rsp), %r12
    39fc: 49 8d 75 f8                  	leaq	-0x8(%r13), %rsi
    3a00: ba 08 00 00 00               	movl	$0x8, %edx
    3a05: 4c 89 e7                     	movq	%r12, %rdi
    3a08: e8 00 00 00 00               	callq	0x3a0d <trusted_x86_x86_sim_xdp+0x3a0d>
		0000000000003a09:  R_X86_64_PLT32	copy_from_user_nofault-0x4
    3a0d: 85 c0                        	testl	%eax, %eax
    3a0f: 79 08                        	jns	0x3a19 <trusted_x86_x86_sim_xdp+0x3a19>
    3a11: 49 c7 04 24 00 00 00 00      	movq	$0x0, (%r12)
    3a19: 85 c0                        	testl	%eax, %eax
    3a1b: 48 8b 84 24 70 01 00 00      	movq	0x170(%rsp), %rax
    3a23: 0f 85 33 d3 ff ff            	jne	0xd5c <trusted_x86_x86_sim_xdp+0xd5c>
    3a29: 4c 89 28                     	movq	%r13, (%rax)
    3a2c: 49 8d 86 30 0f 00 00         	leaq	0xf30(%r14), %rax
    3a33: b1 01                        	movb	$0x1, %cl
    3a35: 88 08                        	movb	%cl, (%rax)
    3a37: c7 44 24 58 06 00 00 00      	movl	$0x6, 0x58(%rsp)
    3a3f: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3a46 <trusted_x86_x86_sim_xdp+0x3a46>
		0000000000003a42:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3a46: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    3a4b: e8 00 00 00 00               	callq	0x3a50 <trusted_x86_x86_sim_xdp+0x3a50>
		0000000000003a4c:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3a50: 48 85 c0                     	testq	%rax, %rax
    3a53: 74 0c                        	je	0x3a61 <trusted_x86_x86_sim_xdp+0x3a61>
    3a55: 48 89 c1                     	movq	%rax, %rcx
    3a58: 48 8b 09                     	movq	(%rcx), %rcx
    3a5b: 48 ff c1                     	incq	%rcx
    3a5e: 48 89 08                     	movq	%rcx, (%rax)
    3a61: 48 8b 84 24 98 00 00 00      	movq	0x98(%rsp), %rax
    3a69: 4c 8b 38                     	movq	(%rax), %r15
    3a6c: 4d 85 ff                     	testq	%r15, %r15
    3a6f: 0f 84 b9 00 00 00            	je	0x3b2e <trusted_x86_x86_sim_xdp+0x3b2e>
    3a75: 4c 3b bc 24 b8 01 00 00      	cmpq	0x1b8(%rsp), %r15
    3a7d: 0f 83 6e d3 ff ff            	jae	0xdf1 <trusted_x86_x86_sim_xdp+0xdf1>
    3a83: 49 81 ff 00 10 00 00         	cmpq	$0x1000, %r15           # imm = 0x1000
    3a8a: 0f 82 82 d3 ff ff            	jb	0xe12 <trusted_x86_x86_sim_xdp+0xe12>
    3a90: 4c 89 f0                     	movq	%r14, %rax
    3a93: 8b 00                        	movl	(%rax), %eax
    3a95: c7 84 24 a8 00 00 00 60 00 00 00     	movl	$0x60, 0xa8(%rsp)
    3aa0: 0f 38 f1 84 24 ac 00 00 00   	movbel	%eax, 0xac(%rsp)
    3aa9: 4c 0f 38 f1 bc 24 b0 00 00 00	movbeq	%r15, 0xb0(%rsp)
    3ab3: 48 89 df                     	movq	%rbx, %rdi
    3ab6: e8 00 00 00 00               	callq	0x3abb <trusted_x86_x86_sim_xdp+0x3abb>
		0000000000003ab7:  R_X86_64_PLT32	.text+0x5c
    3abb: 48 85 c0                     	testq	%rax, %rax
    3abe: 0f 84 89 00 00 00            	je	0x3b4d <trusted_x86_x86_sim_xdp+0x3b4d>
    3ac4: 48 89 c1                     	movq	%rax, %rcx
    3ac7: 48 8b 69 08                  	movq	0x8(%rcx), %rbp
    3acb: 48 b9 ff ff ff ff ff ff ff 00	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    3ad5: 48 21 e9                     	andq	%rbp, %rcx
    3ad8: 48 8b 94 24 b0 01 00 00      	movq	0x1b0(%rsp), %rdx
    3ae0: 48 89 0a                     	movq	%rcx, (%rdx)
    3ae3: 48 8b 00                     	movq	(%rax), %rax
    3ae6: 48 8b 94 24 a0 01 00 00      	movq	0x1a0(%rsp), %rdx
    3aee: 48 89 02                     	movq	%rax, (%rdx)
    3af1: 48 c1 ed 38                  	shrq	$0x38, %rbp
    3af5: 49 29 cf                     	subq	%rcx, %r15
    3af8: 48 8b 8c 24 a8 01 00 00      	movq	0x1a8(%rsp), %rcx
    3b00: 4c 89 39                     	movq	%r15, (%rcx)
    3b03: 45 31 ed                     	xorl	%r13d, %r13d
    3b06: 48 83 fd 01                  	cmpq	$0x1, %rbp
    3b0a: 75 37                        	jne	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    3b0c: 48 89 84 24 a8 00 00 00      	movq	%rax, 0xa8(%rsp)
    3b14: 48 8b 05 00 00 00 00         	movq	(%rip), %rax            # 0x3b1b <trusted_x86_x86_sim_xdp+0x3b1b>
		0000000000003b17:  R_X86_64_REX_GOTPCRELX	interpreter_offsets-0x4
    3b1b: 48 89 df                     	movq	%rbx, %rdi
    3b1e: 48 3b 05 00 00 00 00         	cmpq	(%rip), %rax            # 0x3b25 <trusted_x86_x86_sim_xdp+0x3b25>
		0000000000003b21:  R_X86_64_REX_GOTPCRELX	pid_page_to_mapping_info-0x4
    3b25: 75 3b                        	jne	0x3b62 <trusted_x86_x86_sim_xdp+0x3b62>
    3b27: e8 00 00 00 00               	callq	0x3b2c <trusted_x86_x86_sim_xdp+0x3b2c>
		0000000000003b28:  R_X86_64_PLT32	.text+0x5c
    3b2c: eb 39                        	jmp	0x3b67 <trusted_x86_x86_sim_xdp+0x3b67>
    3b2e: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
    3b35: c7 00 01 00 00 00            	movl	$0x1, (%rax)
    3b3b: 41 bd ad 0f 00 00            	movl	$0xfad, %r13d           # imm = 0xFAD
    3b41: 31 ed                        	xorl	%ebp, %ebp
    3b43: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    3b48: e9 79 f8 ff ff               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
    3b4d: 49 8d 86 28 0f 00 00         	leaq	0xf28(%r14), %rax
    3b54: c7 00 0c 00 00 00            	movl	$0xc, (%rax)
    3b5a: 41 bd ac 0f 00 00            	movl	$0xfac, %r13d           # imm = 0xFAC
    3b60: eb df                        	jmp	0x3b41 <trusted_x86_x86_sim_xdp+0x3b41>
    3b62: e8 00 00 00 00               	callq	0x3b67 <trusted_x86_x86_sim_xdp+0x3b67>
		0000000000003b63:  R_X86_64_PLT32	.text+0x10c
    3b67: 49 89 c4                     	movq	%rax, %r12
    3b6a: bd 01 00 00 00               	movl	$0x1, %ebp
    3b6f: 48 85 c0                     	testq	%rax, %rax
    3b72: 74 cf                        	je	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    3b74: 4c 89 e0                     	movq	%r12, %rax
    3b77: 48 8b 00                     	movq	(%rax), %rax
    3b7a: 4c 39 f8                     	cmpq	%r15, %rax
    3b7d: 77 0c                        	ja	0x3b8b <trusted_x86_x86_sim_xdp+0x3b8b>
    3b7f: 4c 89 e0                     	movq	%r12, %rax
    3b82: 48 8b 40 08                  	movq	0x8(%rax), %rax
    3b86: 4c 39 f8                     	cmpq	%r15, %rax
    3b89: 73 18                        	jae	0x3ba3 <trusted_x86_x86_sim_xdp+0x3ba3>
    3b8b: 4c 89 e0                     	movq	%r12, %rax
    3b8e: 48 8b 40 10                  	movq	0x10(%rax), %rax
    3b92: 4c 39 f8                     	cmpq	%r15, %rax
    3b95: 77 ac                        	ja	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    3b97: 4c 89 e0                     	movq	%r12, %rax
    3b9a: 48 8b 40 18                  	movq	0x18(%rax), %rax
    3b9e: 4c 39 f8                     	cmpq	%r15, %rax
    3ba1: 72 a0                        	jb	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    3ba3: 4c 89 f0                     	movq	%r14, %rax
    3ba6: 8b 80 80 13 00 00            	movl	0x1380(%rax), %eax
    3bac: 4c 89 e1                     	movq	%r12, %rcx
    3baf: 8b 49 20                     	movl	0x20(%rcx), %ecx
    3bb2: 0f a3 c8                     	btl	%ecx, %eax
    3bb5: 72 8c                        	jb	0x3b43 <trusted_x86_x86_sim_xdp+0x3b43>
    3bb7: c7 44 24 58 00 00 00 00      	movl	$0x0, 0x58(%rsp)
    3bbf: 48 8b 3d 00 00 00 00         	movq	(%rip), %rdi            # 0x3bc6 <trusted_x86_x86_sim_xdp+0x3bc6>
		0000000000003bc2:  R_X86_64_REX_GOTPCRELX	metrics-0x4
    3bc6: 48 8d 74 24 58               	leaq	0x58(%rsp), %rsi
    3bcb: e8 00 00 00 00               	callq	0x3bd0 <trusted_x86_x86_sim_xdp+0x3bd0>
		0000000000003bcc:  R_X86_64_PLT32	bpf_map_lookup_elem-0x4
    3bd0: 48 85 c0                     	testq	%rax, %rax
    3bd3: 74 0c                        	je	0x3be1 <trusted_x86_x86_sim_xdp+0x3be1>
    3bd5: 48 89 c1                     	movq	%rax, %rcx
    3bd8: 48 8b 09                     	movq	(%rcx), %rcx
    3bdb: 48 ff c1                     	incq	%rcx
    3bde: 48 89 08                     	movq	%rcx, (%rax)
    3be1: 41 0f b7 6c 24 20            	movzwl	0x20(%r12), %ebp
    3be7: 4c 8b 64 24 70               	movq	0x70(%rsp), %r12
    3bec: e9 d5 f7 ff ff               	jmp	0x33c6 <trusted_x86_x86_sim_xdp+0x33c6>
