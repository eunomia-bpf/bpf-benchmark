#include "/workspaces/repository/kprog/x86/micro-prog/native_hash.h"
__KPROG_HASH_CODE
static __attribute__((noinline)) void *__kprog_hash_key_4(void *map,const void *key) { return __kprog_hash_lookup(map,key,4,448,824,832,16,0,0,0,40,48); }
extern unsigned char __kprog_hash_map_0[] __asm__("data");
extern unsigned char __kprog_hash_map_1[] __asm__("start");
__attribute__((always_inline))
void *__kprog_array_lookup(void *map, const void *key) {
    if (map == __kprog_hash_map_0 || map == __kprog_hash_map_1) return __kprog_hash_key_4(map,key);

    unsigned index = *(const unsigned *)key;
    if (index >= *(const unsigned *)((const char *)map + 68))
        return (void *)0;
    unsigned stride = *(const unsigned *)((const char *)map + 288);
    unsigned mask = *(const unsigned *)((const char *)map + 292);
    return (char *)map + 304 + (unsigned long)stride * (index & mask);
}
