
build-arm64/exclusive-bound/full-current/full-suite/paired_stlxr_failure.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	f90003e1 	str	x1, [sp]
   c:	910003e2 	mov	x2, sp
  10:	c85ffc41 	ldaxr	x1, [x2]
  14:	c800fc41 	stlxr	w0, x1, [x2]
  18:	34000060 	cbz	w0, 24 <entry+0x24>
  1c:	d2800003 	mov	x3, #0x0                   	// #0
  20:	b9400060 	ldr	w0, [x3]
  24:	910043ff 	add	sp, sp, #0x10
  28:	52800040 	mov	w0, #0x2                   	// #2
  2c:	d65f03c0 	ret
