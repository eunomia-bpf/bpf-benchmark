dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/init 0755 0 0
file /cases /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/cases 0755 0 0
file /bound-probe /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/bpf_arm64_native_lab.ko 0755 0 0
file /native-link /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/native-link 0755 0 0
file /companion.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/companion.bpf.o 0755 0 0
file /proofs/unpaired_stxr_failure.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_failure.manifest.json 0755 0 0
file /proofs/paired_stlxr_failure.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stlxr_failure.bpf.o 0755 0 0
file /proofs/unpaired_stlxr_failure.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stlxr_failure.native.o 0755 0 0
file /proofs/paired_stxr_failure.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_failure.bpf.o 0755 0 0
file /proofs/unpaired_stxr_failure.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_failure.bpf.o 0755 0 0
file /proofs/unpaired_stxr_failure.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_failure.native.o 0755 0 0
file /proofs/unpaired_stxr_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_control.manifest.json 0755 0 0
file /proofs/paired_stxr_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_control.bpf.o 0755 0 0
file /proofs/unpaired_stlxr_failure.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stlxr_failure.bpf.o 0755 0 0
file /proofs/paired_stlxr_failure.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stlxr_failure.manifest.json 0755 0 0
file /proofs/paired_stlxr_failure.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stlxr_failure.native.o 0755 0 0
file /proofs/paired_stxr_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_control.manifest.json 0755 0 0
file /proofs/paired_stxr_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_control.native.o 0755 0 0
file /proofs/unpaired_stxr_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_control.native.o 0755 0 0
file /proofs/unpaired_stlxr_failure.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stlxr_failure.manifest.json 0755 0 0
file /proofs/paired_stxr_failure.native.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_failure.native.o 0755 0 0
file /proofs/paired_stxr_failure.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/paired_stxr_failure.manifest.json 0755 0 0
file /proofs/unpaired_stxr_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-run/fixtures/unpaired_stxr_control.bpf.o 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
