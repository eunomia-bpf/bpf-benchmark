
/workspaces/repository/kprog/fidelity/build-arm64/exclusive-bound/before/full-suite/unpaired_stxr_control.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	f90003e1 	str	x1, [sp]
   c:	910003e2 	mov	x2, sp
  10:	c8007c41 	stxr	w0, x1, [x2]
  14:	910043ff 	add	sp, sp, #0x10
  18:	52800040 	mov	w0, #0x2                   	// #2
  1c:	d65f03c0 	ret
