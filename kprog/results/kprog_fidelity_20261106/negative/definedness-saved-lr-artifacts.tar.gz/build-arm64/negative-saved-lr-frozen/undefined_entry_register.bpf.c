#define ARM64_SIM_RET_CASES_c 
#define ARM64_SIM_RET_CASES_14 
#include "/workspaces/repository/kprog/fidelity/build-arm64/negative-saved-lr-frozen/snapshot/kprog/arm64/arm64_sim_local_bpf.h"

SEC("xdp")
int undefined_entry_register_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: cbz x1, 10 <entry+0x10> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x0, 0x10, arm64_l_10);
arm64_l_4:
	/* 0x4: ldr x1, [x0, #8] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 8ULL);
arm64_l_8:
	/* 0x8: ldrb w0, [x1] */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_8, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_c:
	/* 0xc: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_c);
arm64_l_10:
	/* 0x10: mov w0, #0x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_14:
	/* 0x14: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_14);
	return 0;
}

ARM64_SIM_LICENSE();
