
build-arm64/negative-saved-lr-frozen/helper_clobbered_register.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
   4:	aa0003f3 	mov	x19, x0
   8:	d2800001 	mov	x1, #0x0                   	// #0
   c:	94000000 	bl	0 <bpf_get_current_uid_gid>
			c: R_AARCH64_CALL26	bpf_get_current_uid_gid
  10:	b4000081 	cbz	x1, 20 <entry+0x20>
  14:	f9400661 	ldr	x1, [x19, #8]
  18:	39400020 	ldrb	w0, [x1]
  1c:	14000002 	b	24 <entry+0x24>
  20:	52800040 	mov	w0, #0x2                   	// #2
  24:	a8c17bf3 	ldp	x19, x30, [sp], #16
  28:	d65f03c0 	ret
