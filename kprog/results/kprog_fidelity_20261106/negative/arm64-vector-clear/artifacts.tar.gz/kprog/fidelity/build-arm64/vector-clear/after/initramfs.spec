dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/negative-bound-init 0755 0 0
file /cases /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/after/cases 0755 0 0
file /bound-probe /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/tv/build-arm64/bpf_arm64_native_lab.ko 0755 0 0
file /companion.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/negative-companion.bpf.o 0755 0 0
file /native-link /workspaces/repository/kprog/x86/native_lab/native_link/target/aarch64-unknown-linux-gnu/release/native-link 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
file /proofs/scalar_vector_load_clear_high.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/after/scalar_vector_load_clear_high.bpf.o 0755 0 0
file /proofs/scalar_vector_load_clear_high.native.o /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/after/scalar_vector_load_clear_high.native.o 0755 0 0
file /proofs/scalar_vector_load_clear_high.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/vector-clear/after/scalar_vector_load_clear_high.manifest.json 0755 0 0
