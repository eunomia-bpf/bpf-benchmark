#define ARM64_SIM_RET_CASES_4 
#include "../arm64_sim_local_bpf.h"

SEC("xdp")
int partial_movk_low_return_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: movk x0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(0), 2ULL);
arm64_l_4:
	/* 0x4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_4);
	return 0;
}

ARM64_SIM_LICENSE();
