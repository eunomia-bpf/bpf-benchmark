#define ARM64_SIM_RET_CASES_4 
#include "../arm64_sim_local_bpf.h"

SEC("xdp")
int unused_nv_flags_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: csel x0, x0, x0, nv */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CSEL, ARM64_X0, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_COND_AL, 0);
arm64_l_4:
	/* 0x4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_4);
	return 0;
}

ARM64_SIM_LICENSE();
