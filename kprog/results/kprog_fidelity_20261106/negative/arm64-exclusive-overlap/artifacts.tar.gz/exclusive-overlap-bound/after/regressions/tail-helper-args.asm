
/workspaces/repository/kprog/fidelity/build-arm64/exclusive-overlap-bound/after/regressions/tail-helper-args.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d2800028 	mov	x8, #0x1                   	// #1
   4:	d61f0100 	br	x8
