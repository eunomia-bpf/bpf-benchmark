#define ARM64_SIM_RET_CASES_c 
#include "../arm64_sim_local_bpf.h"

SEC("xdp")
int tbz_defined_bit_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: movk x1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOVK, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MOVK(0), 2ULL);
arm64_l_4:
	/* 0x4: tbz w1, #0, 8 <entry+0x8> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x4, 0x8, arm64_l_8);
arm64_l_8:
	/* 0x8: mov w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_c:
	/* 0xc: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_c);
	return 0;
}

ARM64_SIM_LICENSE();
