#define ARM64_SIM_RET_CASES_14 
#include "../arm64_sim_local_bpf.h"

SEC("xdp")
int join_both_writes_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: cbz x0, c <entry+0xc> */
	ARM64_SIM_A64_CBZ(ARM64_X0, 0x0, 0xc, arm64_l_c);
arm64_l_4:
	/* 0x4: mov w1, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_8:
	/* 0x8: b 10 <entry+0x10> */
	ARM64_SIM_A64_JMP(0x8, 0x10, arm64_l_10);
arm64_l_c:
	/* 0xc: mov w1, #0x3 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 3ULL);
arm64_l_10:
	/* 0x10: mov w0, w1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_14:
	/* 0x14: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_14);
	return 0;
}

ARM64_SIM_LICENSE();
