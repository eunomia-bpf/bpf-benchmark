
/workspaces/repository/kprog/fidelity/build-arm64/exclusive-overlap-bound/after/regressions/partial-movk-low-return.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800040 	movk	x0, #0x2
   4:	d65f03c0 	ret
