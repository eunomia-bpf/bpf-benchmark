
/workspaces/repository/kprog/fidelity/build-arm64/exclusive-overlap-bound/after/regressions/callee-save-across-helper.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
   4:	aa0003f3 	mov	x19, x0
   8:	94000000 	bl	0 <bpf_get_current_uid_gid>
			8: R_AARCH64_CALL26	bpf_get_current_uid_gid
   c:	aa1303e0 	mov	x0, x19
  10:	a8c17bf3 	ldp	x19, x30, [sp], #16
  14:	d65f03c0 	ret
