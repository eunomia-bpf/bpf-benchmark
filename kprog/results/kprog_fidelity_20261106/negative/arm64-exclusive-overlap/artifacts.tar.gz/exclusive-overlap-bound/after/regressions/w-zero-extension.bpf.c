#define ARM64_SIM_RET_CASES_8 
#include "../arm64_sim_local_bpf.h"

SEC("xdp")
int w_zero_extension_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: mov w1, w0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X1, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 0);
arm64_l_4:
	/* 0x4: mov x0, x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_8:
	/* 0x8: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_8);
	return 0;
}

ARM64_SIM_LICENSE();
