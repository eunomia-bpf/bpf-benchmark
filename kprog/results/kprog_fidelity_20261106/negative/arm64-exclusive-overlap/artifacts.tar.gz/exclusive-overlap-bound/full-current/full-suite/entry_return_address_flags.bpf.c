#define ARM64_SIM_RET_CASES_14 
#include "/workspaces/repository/kprog/fidelity/build-arm64/exclusive-overlap-bound/full-current/full-suite/snapshot/kprog/arm64/arm64_sim_local_bpf.h"

SEC("xdp")
int entry_return_address_flags_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: mov w0, #0x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, 0, 2ULL);
arm64_l_4:
	/* 0x4: cmp x30, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_8:
	/* 0x8: b.eq 14 <entry+0x14> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x8, 0x14, arm64_l_14);
arm64_l_c:
	/* 0xc: mov x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0ULL);
arm64_l_10:
	/* 0x10: ldr w0, [x1] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_32, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 0ULL);
arm64_l_14:
	/* 0x14: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_14);
	return 0;
}

ARM64_SIM_LICENSE();
