#define ARM64_SIM_RET_CASES_14 
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 16LL
#define ARM64_SIM_STACK_BYTES 16U
#define ARM64_SIM_RETURN_CASES \
	case 0x10ULL: goto arm64_l_10;
#include "/workspaces/repository/kprog/fidelity/build-arm64/exclusive-overlap-bound/full-current/full-suite/snapshot/kprog/arm64/arm64_sim_local_bpf.h"

SEC("xdp")
int invalid_helper_argument_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_4:
	/* 0x4: mov x0, #0x1 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 1ULL);
arm64_l_8:
	/* 0x8: mov x1, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0ULL);
arm64_l_c:
	/* 0xc: bl 0 <bpf_map_lookup_elem> */
	ARM64_SIM_A64_LINK(0x10ULL);
	ARM64_SIM_BPF_CALL_bpf_map_lookup_elem();
arm64_l_10:
	/* 0x10: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_14:
	/* 0x14: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_14);
	return 0;
}

ARM64_SIM_LICENSE();
