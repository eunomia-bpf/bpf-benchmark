dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/init 0755 0 0
file /cases /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/cases 0755 0 0
file /bound-probe /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/bpf_arm64_native_lab.ko 0755 0 0
file /native-link /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/native-link 0755 0 0
file /companion.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/companion.bpf.o 0755 0 0
file /proofs/ldp_first_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_first_alias_post.native.o 0755 0 0
file /proofs/ldr_x_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_post.manifest.json 0755 0 0
file /proofs/ldp_second_alias_pre.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_second_alias_pre.manifest.json 0755 0 0
file /proofs/ldrh_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrh_alias_post.manifest.json 0755 0 0
file /proofs/stp_first_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_first_alias_post.bpf.o 0755 0 0
file /proofs/ldr_w_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_w_alias_post.native.o 0755 0 0
file /proofs/ldr_distinct_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_distinct_control.manifest.json 0755 0 0
file /proofs/ldp_second_alias_pre.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_second_alias_pre.bpf.o 0755 0 0
file /proofs/ldp_distinct_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_distinct_control.bpf.o 0755 0 0
file /proofs/sp_zr_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/sp_zr_control.manifest.json 0755 0 0
file /proofs/str_distinct_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_distinct_control.manifest.json 0755 0 0
file /proofs/sp_zr_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/sp_zr_control.native.o 0755 0 0
file /proofs/ldr_x_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_post.bpf.o 0755 0 0
file /proofs/ldp_distinct_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_distinct_control.native.o 0755 0 0
file /proofs/ldr_x_alias_pre.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_pre.native.o 0755 0 0
file /proofs/ldr_x_alias_pre.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_pre.bpf.o 0755 0 0
file /proofs/ldrb_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrb_alias_post.native.o 0755 0 0
file /proofs/stp_distinct_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_distinct_control.bpf.o 0755 0 0
file /proofs/ldr_x_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_post.native.o 0755 0 0
file /proofs/str_x_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_x_alias_post.bpf.o 0755 0 0
file /proofs/ldr_distinct_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_distinct_control.native.o 0755 0 0
file /proofs/ldp_first_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_first_alias_post.manifest.json 0755 0 0
file /proofs/ldr_w_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_w_alias_post.bpf.o 0755 0 0
file /proofs/ldrh_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrh_alias_post.bpf.o 0755 0 0
file /proofs/ldr_x_alias_pre.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_x_alias_pre.manifest.json 0755 0 0
file /proofs/ldr_distinct_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_distinct_control.bpf.o 0755 0 0
file /proofs/str_w_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_w_alias_post.manifest.json 0755 0 0
file /proofs/ldp_first_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_first_alias_post.bpf.o 0755 0 0
file /proofs/ldp_distinct_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_distinct_control.manifest.json 0755 0 0
file /proofs/str_w_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_w_alias_post.bpf.o 0755 0 0
file /proofs/stp_first_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_first_alias_post.native.o 0755 0 0
file /proofs/stp_second_alias_pre.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_second_alias_pre.manifest.json 0755 0 0
file /proofs/stp_second_alias_pre.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_second_alias_pre.native.o 0755 0 0
file /proofs/ldrb_alias_post.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrb_alias_post.bpf.o 0755 0 0
file /proofs/ldr_w_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldr_w_alias_post.manifest.json 0755 0 0
file /proofs/stp_second_alias_pre.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_second_alias_pre.bpf.o 0755 0 0
file /proofs/stp_first_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_first_alias_post.manifest.json 0755 0 0
file /proofs/stp_distinct_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_distinct_control.manifest.json 0755 0 0
file /proofs/str_w_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_w_alias_post.native.o 0755 0 0
file /proofs/stp_distinct_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/stp_distinct_control.native.o 0755 0 0
file /proofs/ldp_second_alias_pre.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldp_second_alias_pre.native.o 0755 0 0
file /proofs/ldrb_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrb_alias_post.manifest.json 0755 0 0
file /proofs/str_distinct_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_distinct_control.native.o 0755 0 0
file /proofs/str_distinct_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_distinct_control.bpf.o 0755 0 0
file /proofs/str_x_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_x_alias_post.native.o 0755 0 0
file /proofs/ldrh_alias_post.native.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/ldrh_alias_post.native.o 0755 0 0
file /proofs/sp_zr_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/sp_zr_control.bpf.o 0755 0 0
file /proofs/str_x_alias_post.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/before/full-run/fixtures/str_x_alias_post.manifest.json 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
