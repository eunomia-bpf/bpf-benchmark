
/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/after/full-suite/ldr_x_alias_pre.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	d2800043 	mov	x3, #0x2                   	// #2
   8:	a9000fe3 	stp	x3, x3, [sp]
   c:	a9010fe3 	stp	x3, x3, [sp, #16]
  10:	910003e1 	mov	x1, sp
  14:	d2800042 	mov	x2, #0x2                   	// #2
  18:	f8408c21 	ldr	x1, [x1, #8]!
  1c:	910083ff 	add	sp, sp, #0x20
  20:	52800040 	mov	w0, #0x2                   	// #2
  24:	d65f03c0 	ret
