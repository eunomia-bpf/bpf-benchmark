
/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/after/regressions/helper-string-suffix.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9be7bf3 	stp	x19, x30, [sp, #-32]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	910043e0 	add	x0, sp, #0x10
   c:	d2800101 	mov	x1, #0x8                   	// #8
  10:	d2800002 	mov	x2, #0x0                   	// #0
  14:	94000000 	bl	0 <bpf_probe_read_kernel_str>
			14: R_AARCH64_CALL26	bpf_probe_read_kernel_str
  18:	f9400be0 	ldr	x0, [sp, #16]
  1c:	a8c27bf3 	ldp	x19, x30, [sp], #32
  20:	d65f03c0 	ret
