
/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/after/regressions/postindex-old-sp-aligned.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	52800041 	mov	w1, #0x2                   	// #2
   8:	f90003e1 	str	x1, [sp]
   c:	384017e0 	ldrb	w0, [sp], #1
  10:	d10007ff 	sub	sp, sp, #0x1
  14:	910043ff 	add	sp, sp, #0x10
  18:	d65f03c0 	ret
