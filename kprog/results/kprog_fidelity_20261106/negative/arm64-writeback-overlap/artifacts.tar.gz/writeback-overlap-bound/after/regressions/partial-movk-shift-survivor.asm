
/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/after/regressions/partial-movk-shift-survivor.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800041 	movk	x1, #0x2
   4:	d350fc20 	lsr	x0, x1, #16
   8:	d65f03c0 	ret
