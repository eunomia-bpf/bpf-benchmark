
/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/after/regressions/helper-defined-output.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9be7bf3 	stp	x19, x30, [sp, #-32]!
   4:	f9000be1 	str	x1, [sp, #16]
   8:	910043e0 	add	x0, sp, #0x10
   c:	d2800101 	mov	x1, #0x8                   	// #8
  10:	94000000 	bl	0 <bpf_get_current_comm>
			10: R_AARCH64_CALL26	bpf_get_current_comm
  14:	f9400be0 	ldr	x0, [sp, #16]
  18:	a8c27bf3 	ldp	x19, x30, [sp], #32
  1c:	d65f03c0 	ret
