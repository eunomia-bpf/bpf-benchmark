
build-arm64/writeback-overlap-bound/full-current/full-suite/undefined_entry_register.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	b4000081 	cbz	x1, 10 <entry+0x10>
   4:	f9400401 	ldr	x1, [x0, #8]
   8:	39400020 	ldrb	w0, [x1]
   c:	d65f03c0 	ret
  10:	52800040 	mov	w0, #0x2                   	// #2
  14:	d65f03c0 	ret
