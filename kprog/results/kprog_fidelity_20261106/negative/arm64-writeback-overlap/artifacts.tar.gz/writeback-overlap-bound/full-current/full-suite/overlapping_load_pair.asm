
build-arm64/writeback-overlap-bound/full-current/full-suite/overlapping_load_pair.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	a90007e1 	stp	x1, x1, [sp]
   c:	a94007e1 	ldp	x1, x1, [sp]
  10:	910043ff 	add	sp, sp, #0x10
  14:	2a0103e0 	mov	w0, w1
  18:	d65f03c0 	ret
