#define ARM64_SIM_RET_CASES_4 
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_STACK_BIAS 0LL
#define ARM64_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/fidelity/build-arm64/writeback-overlap-bound/full-current/full-suite/snapshot/kprog/arm64/arm64_sim_local_bpf.h"

SEC("xdp")
int stack_oob_arm64_sim_xdp(struct xdp_md *ctx)
{
	ARM64_SIM_ENTRY_XDP(ctx);
arm64_l_0:
	/* 0x0: ldr x0, [sp, #1024] */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, 0), 1024ULL);
arm64_l_4:
	/* 0x4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_4);
	return 0;
}

ARM64_SIM_LICENSE();
