#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int helper_clobbered_register_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: push   rbx */
	X86_SIM_L_EXEC_PUSH(X86_RBX, X86_WIDTH_64);
x86_l_1:
	/* 0x1: mov    rbx,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RDI, X86_WIDTH_64);
x86_l_4:
	/* 0x4: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_6:
	/* 0x6: call   b <entry+0xb> */
	X86_SIM_BPF_CALL_ID(X86_SIM_HELPER_bpf_get_current_uid_gid);
x86_l_b:
	/* 0xb: test   rsi,rsi */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RSI, X86_RSI, X86_WIDTH_64);
x86_l_e:
	/* 0xe: je     19 <entry+0x19> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe, 0x19, x86_l_19);
x86_l_10:
	/* 0x10: mov    rax,QWORD PTR [rbx+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_14:
	/* 0x14: movzx  eax,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_17:
	/* 0x17: jmp    1e <entry+0x1e> */
	X86_SIM_X86_JMP(0x17, 0x1e, x86_l_1e);
x86_l_19:
	/* 0x19: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1e:
	/* 0x1e: pop    rbx */
	X86_SIM_L_EXEC_POP(X86_RBX, X86_WIDTH_64);
x86_l_1f:
	/* 0x1f: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
