#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 8U
#include "/workspaces/repository/kprog/fidelity/build-x86/divide-fault/snapshot/kprog/x86/x86_sim_local_bpf.h"

SEC("xdp")
int immediate_push_branch_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_5:
	/* 0x5: push   0x1 */
	X86_SIM_L_EXEC_PUSH_OP(X86_REG_NONE, X86_WIDTH_64, X86_PUSHPOP_AUX_IMM, 1ULL);
x86_l_7:
	/* 0x7: pop    rcx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_64, 0, 0);
x86_l_8:
	/* 0x8: test   rcx,rcx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RCX, X86_RCX, X86_WIDTH_64);
x86_l_b:
	/* 0xb: je     11 <entry+0x11> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb, 0x11, x86_l_11);
x86_l_d:
	/* 0xd: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_f:
	/* 0xf: mov    eax,DWORD PTR [rdx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11:
	/* 0x11: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
