
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_zr.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	a90007e1 	stp	x1, x1, [sp]
   c:	a9407fff 	ldp	xzr, xzr, [sp]
  10:	52800040 	mov	w0, #0x2                   	// #2
  14:	910043ff 	add	sp, sp, #0x10
  18:	d65f03c0 	ret
