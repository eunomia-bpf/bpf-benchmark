
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_distinct_control.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	a90007e1 	stp	x1, x1, [sp]
   c:	a9400be1 	ldp	x1, x2, [sp]
  10:	2a0203e0 	mov	w0, w2
  14:	910043ff 	add	sp, sp, #0x10
  18:	d65f03c0 	ret
