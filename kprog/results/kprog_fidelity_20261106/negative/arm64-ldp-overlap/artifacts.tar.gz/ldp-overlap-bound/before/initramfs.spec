dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/init 0755 0 0
file /cases /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/cases 0755 0 0
file /bound-probe /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/bpf_arm64_native_lab.ko 0755 0 0
file /native-link /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/native-link 0755 0 0
file /companion.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/companion.bpf.o 0755 0 0
file /proofs/ldp_same_w_used.native.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_w_used.native.o 0755 0 0
file /proofs/ldp_same_x_overwritten.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_overwritten.bpf.o 0755 0 0
file /proofs/ldp_same_x_used.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_used.bpf.o 0755 0 0
file /proofs/ldp_distinct_control.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_distinct_control.bpf.o 0755 0 0
file /proofs/ldp_distinct_control.native.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_distinct_control.native.o 0755 0 0
file /proofs/ldp_same_w_used.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_w_used.bpf.o 0755 0 0
file /proofs/ldp_same_x_overwritten.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_overwritten.manifest.json 0755 0 0
file /proofs/ldp_same_w_used.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_w_used.manifest.json 0755 0 0
file /proofs/ldp_same_zr.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_zr.manifest.json 0755 0 0
file /proofs/ldp_same_zr.native.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_zr.native.o 0755 0 0
file /proofs/ldp_same_zr.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_zr.bpf.o 0755 0 0
file /proofs/ldp_same_x_overwritten.native.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_overwritten.native.o 0755 0 0
file /proofs/ldp_distinct_control.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_distinct_control.manifest.json 0755 0 0
file /proofs/ldp_same_x_used.native.o /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_used.native.o 0755 0 0
file /proofs/ldp_same_x_used.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/before/fixtures/ldp_same_x_used.manifest.json 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
