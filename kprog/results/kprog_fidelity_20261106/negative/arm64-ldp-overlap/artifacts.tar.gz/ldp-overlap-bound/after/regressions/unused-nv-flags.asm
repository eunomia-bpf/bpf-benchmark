
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/after/regressions/unused-nv-flags.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	9a80f000 	csel	x0, x0, x0, nv
   4:	d65f03c0 	ret
