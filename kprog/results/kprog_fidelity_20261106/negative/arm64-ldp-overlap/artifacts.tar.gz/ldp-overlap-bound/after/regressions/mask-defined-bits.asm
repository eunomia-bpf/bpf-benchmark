
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/after/regressions/mask-defined-bits.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2800041 	movk	x1, #0x2
   4:	92403c20 	and	x0, x1, #0xffff
   8:	d65f03c0 	ret
