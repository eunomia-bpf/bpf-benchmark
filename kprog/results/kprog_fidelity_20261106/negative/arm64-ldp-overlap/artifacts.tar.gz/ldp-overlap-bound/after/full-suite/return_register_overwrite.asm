
build-arm64/ldp-overlap-bound/after/full-suite/return_register_overwrite.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d280001e 	mov	x30, #0x0                   	// #0
   4:	52800040 	mov	w0, #0x2                   	// #2
   8:	d65f03c0 	ret
