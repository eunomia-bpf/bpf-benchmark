
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/after/regressions/opaque-selected-stack.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	f90003e1 	str	x1, [sp]
   8:	f90007e2 	str	x2, [sp, #8]
   c:	910003e3 	mov	x3, sp
  10:	910023e4 	add	x4, sp, #0x8
  14:	f100001f 	cmp	x0, #0x0
  18:	9a840065 	csel	x5, x3, x4, eq	// eq = none
  1c:	f94000a0 	ldr	x0, [x5]
  20:	910083ff 	add	sp, sp, #0x20
  24:	d65f03c0 	ret
