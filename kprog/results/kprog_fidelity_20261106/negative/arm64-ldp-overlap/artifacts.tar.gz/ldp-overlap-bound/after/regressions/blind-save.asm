
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/after/regressions/blind-save.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	a9bf7bf3 	stp	x19, x30, [sp, #-16]!
   4:	52800040 	mov	w0, #0x2                   	// #2
   8:	a8c17bf3 	ldp	x19, x30, [sp], #16
   c:	d65f03c0 	ret
