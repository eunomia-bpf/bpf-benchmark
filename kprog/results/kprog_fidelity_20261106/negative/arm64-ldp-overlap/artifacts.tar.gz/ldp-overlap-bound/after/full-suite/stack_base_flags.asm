
build-arm64/ldp-overlap-bound/after/full-suite/stack_base_flags.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800040 	mov	w0, #0x2                   	// #2
   4:	d10043ff 	sub	sp, sp, #0x10
   8:	910043ff 	add	sp, sp, #0x10
   c:	f10003ff 	cmp	sp, #0x0
  10:	54000060 	b.eq	1c <entry+0x1c>  // b.none
  14:	d2800001 	mov	x1, #0x0                   	// #0
  18:	b9400020 	ldr	w0, [x1]
  1c:	d65f03c0 	ret
