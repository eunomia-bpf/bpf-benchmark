
/workspaces/repository/kprog/fidelity/build-arm64/ldp-overlap-bound/after/regressions/misaligned-sp-aligned-effective-address.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	52844441 	mov	w1, #0x2222                	// #8738
   8:	f90003e1 	str	x1, [sp]
   c:	910007ff 	add	sp, sp, #0x1
  10:	385fffe0 	ldrb	w0, [sp, #-1]!
  14:	910043ff 	add	sp, sp, #0x10
  18:	d65f03c0 	ret
