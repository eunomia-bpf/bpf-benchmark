
build-arm64/negative-abi/helper_clobbered_register.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	aa0003f3 	mov	x19, x0
   4:	aa1e03f4 	mov	x20, x30
   8:	d2800001 	mov	x1, #0x0                   	// #0
   c:	94000000 	bl	0 <bpf_get_current_uid_gid>
			c: R_AARCH64_CALL26	bpf_get_current_uid_gid
  10:	aa1403fe 	mov	x30, x20
  14:	b4000081 	cbz	x1, 24 <entry+0x24>
  18:	f9400661 	ldr	x1, [x19, #8]
  1c:	39400020 	ldrb	w0, [x1]
  20:	d65f03c0 	ret
  24:	52800040 	mov	w0, #0x2                   	// #2
  28:	d65f03c0 	ret
