
build-x86/negative-abi/helper_clobbered_register.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 89 fb                                        	mov    rbx,rdi
   3:	31 f6                                           	xor    esi,esi
   5:	e8 00 00 00 00                                  	call   a <entry+0xa>
			6: R_X86_64_PLT32	bpf_get_current_uid_gid-0x4
   a:	48 85 f6                                        	test   rsi,rsi
   d:	74 08                                           	je     17 <entry+0x17>
   f:	48 8b 43 08                                     	mov    rax,QWORD PTR [rbx+0x8]
  13:	0f b6 00                                        	movzx  eax,BYTE PTR [rax]
  16:	c3                                              	ret
  17:	b8 02 00 00 00                                  	mov    eax,0x2
  1c:	c3                                              	ret
