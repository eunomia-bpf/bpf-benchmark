
/workspaces/.agent-state/kprog-lanes/V/sp-alignment/unaligned-address.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	52844441 	mov	w1, #0x2222                	// #8738
   8:	f90003e1 	str	x1, [sp]
   c:	910007e2 	add	x2, sp, #0x1
  10:	39400040 	ldrb	w0, [x2]
  14:	910043ff 	add	sp, sp, #0x10
  18:	d65f03c0 	ret
