dir /dev 0755 0 0
dir /proc 0755 0 0
dir /sys 0755 0 0
dir /lib 0755 0 0
dir /proofs 0755 0 0
nod /dev/console 0600 0 0 c 5 1
file /init /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/init 0755 0 0
file /cases /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/cases 0755 0 0
file /bound-probe /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/bound-probe 0755 0 0
file /module.ko /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/bpf_arm64_native_lab.ko 0755 0 0
file /native-link /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/native-link 0755 0 0
file /companion.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/companion.bpf.o 0755 0 0
file /proofs/stack_base_flags.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_base_flags.native.o 0755 0 0
file /proofs/past_data_end_read.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_read.native.o 0755 0 0
file /proofs/uninitialized_stack.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/uninitialized_stack.manifest.json 0755 0 0
file /proofs/return_register_overwrite.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/return_register_overwrite.manifest.json 0755 0 0
file /proofs/nullable_map_dereference.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/nullable_map_dereference.native.o 0755 0 0
file /proofs/uninitialized_stack.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/uninitialized_stack.native.o 0755 0 0
file /proofs/past_data_end_write.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_write.manifest.json 0755 0 0
file /proofs/return_register_overwrite.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/return_register_overwrite.native.o 0755 0 0
file /proofs/stack_oob.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_oob.manifest.json 0755 0 0
file /proofs/map_value_oob.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/map_value_oob.bpf.o 0755 0 0
file /proofs/invalid_helper_argument.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/invalid_helper_argument.manifest.json 0755 0 0
file /proofs/map_value_oob.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/map_value_oob.manifest.json 0755 0 0
file /proofs/nullable_map_dereference.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/nullable_map_dereference.manifest.json 0755 0 0
file /proofs/invalid_helper_argument.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/invalid_helper_argument.native.o 0755 0 0
file /proofs/unbounded_loop.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/unbounded_loop.manifest.json 0755 0 0
file /proofs/past_data_end_read.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_read.manifest.json 0755 0 0
file /proofs/entry_return_address_flags.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/entry_return_address_flags.bpf.o 0755 0 0
file /proofs/return_register_overwrite.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/return_register_overwrite.bpf.o 0755 0 0
file /proofs/missing_data_end_check.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/missing_data_end_check.manifest.json 0755 0 0
file /proofs/past_data_end_read.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_read.bpf.o 0755 0 0
file /proofs/entry_return_address_flags.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/entry_return_address_flags.native.o 0755 0 0
file /proofs/past_data_end_write.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_write.native.o 0755 0 0
file /proofs/stack_oob.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_oob.bpf.o 0755 0 0
file /proofs/nullable_map_dereference.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/nullable_map_dereference.bpf.o 0755 0 0
file /proofs/missing_data_end_check.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/missing_data_end_check.native.o 0755 0 0
file /proofs/unbounded_loop.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/unbounded_loop.native.o 0755 0 0
file /proofs/stack_base_flags.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_base_flags.manifest.json 0755 0 0
file /proofs/uninitialized_stack.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/uninitialized_stack.bpf.o 0755 0 0
file /proofs/unbounded_loop.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/unbounded_loop.bpf.o 0755 0 0
file /proofs/past_data_end_write.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/past_data_end_write.bpf.o 0755 0 0
file /proofs/entry_return_address_flags.manifest.json /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/entry_return_address_flags.manifest.json 0755 0 0
file /proofs/invalid_helper_argument.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/invalid_helper_argument.bpf.o 0755 0 0
file /proofs/missing_data_end_check.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/missing_data_end_check.bpf.o 0755 0 0
file /proofs/stack_base_flags.bpf.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_base_flags.bpf.o 0755 0 0
file /proofs/map_value_oob.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/map_value_oob.native.o 0755 0 0
file /proofs/stack_oob.native.o /workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/full-run/fixtures/stack_oob.native.o 0755 0 0
file /lib/libc.so.6 /usr/aarch64-linux-gnu/lib/libc.so.6 0755 0 0
file /lib/ld-linux-aarch64.so.1 /usr/aarch64-linux-gnu/lib/ld-linux-aarch64.so.1 0755 0 0
file /lib/libgcc_s.so.1 /usr/aarch64-linux-gnu/lib/libgcc_s.so.1 0755 0 0
file /lib/libelf.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libelf-0.190.so 0755 0 0
file /lib/libz.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libz.so.1.3 0755 0 0
file /lib/libzstd.so.1 /workspaces/repository/.cache/aarch64-sysroot/usr/lib/aarch64-linux-gnu/libzstd.so.1.5.5 0755 0 0
