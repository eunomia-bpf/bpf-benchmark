
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/partial-movk-high-shift.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f2e00041 	movk	x1, #0x2, lsl #48
   4:	d370fc20 	lsr	x0, x1, #48
   8:	d65f03c0 	ret
