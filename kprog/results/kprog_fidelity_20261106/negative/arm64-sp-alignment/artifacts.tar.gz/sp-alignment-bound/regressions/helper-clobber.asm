
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/helper-clobber.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	f81f0ffe 	str	x30, [sp, #-16]!
   4:	d2800001 	mov	x1, #0x0                   	// #0
   8:	94000000 	bl	0 <bpf_get_current_uid_gid>
			8: R_AARCH64_CALL26	bpf_get_current_uid_gid
   c:	b4000021 	cbz	x1, 10 <entry+0x10>
  10:	f84107fe 	ldr	x30, [sp], #16
  14:	d65f03c0 	ret
