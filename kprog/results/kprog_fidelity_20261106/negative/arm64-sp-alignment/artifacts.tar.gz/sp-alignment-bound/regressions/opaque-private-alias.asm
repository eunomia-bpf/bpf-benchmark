
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/opaque-private-alias.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	910003e2 	mov	x2, sp
   8:	f9000041 	str	x1, [x2]
   c:	52800040 	mov	w0, #0x2                   	// #2
  10:	910043ff 	add	sp, sp, #0x10
  14:	d65f03c0 	ret
