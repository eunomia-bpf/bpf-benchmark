
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/w-zero-extension.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	2a0003e1 	mov	w1, w0
   4:	aa0103e0 	mov	x0, x1
   8:	d65f03c0 	ret
