
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/self-compare.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	eb01003f 	cmp	x1, x1
   4:	1a9f17e0 	cset	w0, eq	// eq = none
   8:	d65f03c0 	ret
