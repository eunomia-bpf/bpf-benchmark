
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/return-sp-unbalanced.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	52800040 	mov	w0, #0x2                   	// #2
   8:	d65f03c0 	ret
