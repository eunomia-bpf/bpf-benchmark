
/workspaces/repository/kprog/fidelity/build-arm64/sp-alignment-bound/regressions/preindex-old-sp-aligned.proof.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	52800041 	mov	w1, #0x2                   	// #2
   4:	f81f8fe1 	str	x1, [sp, #-8]!
   8:	910023ff 	add	sp, sp, #0x8
   c:	52800040 	mov	w0, #0x2                   	// #2
  10:	d65f03c0 	ret
