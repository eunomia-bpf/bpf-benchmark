
/workspaces/repository/kprog/fidelity/build-x86/divide-positive/div8_valid.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 00 02 00 00                            	mov    rax,0x200
   7:	ba 00 00 00 00                                  	mov    edx,0x0
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	f6 f1                                           	div    cl
  13:	66 3d 49 01                                     	cmp    ax,0x149
  17:	75 06                                           	jne    1f <entry+0x1f>
  19:	b8 02 00 00 00                                  	mov    eax,0x2
  1e:	c3                                              	ret
  1f:	b8 00 00 00 00                                  	mov    eax,0x0
  24:	c3                                              	ret
