
/workspaces/repository/kprog/fidelity/build-x86/divide-positive/div32_valid.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 c7 c0 06 00 00 00                            	mov    rax,0x6
   7:	ba 01 00 00 00                                  	mov    edx,0x1
   c:	b9 07 00 00 00                                  	mov    ecx,0x7
  11:	f7 f1                                           	div    ecx
  13:	3d 25 49 92 24                                  	cmp    eax,0x24924925
  18:	75 0b                                           	jne    25 <entry+0x25>
  1a:	83 fa 03                                        	cmp    edx,0x3
  1d:	75 06                                           	jne    25 <entry+0x25>
  1f:	b8 02 00 00 00                                  	mov    eax,0x2
  24:	c3                                              	ret
  25:	b8 00 00 00 00                                  	mov    eax,0x0
  2a:	c3                                              	ret
