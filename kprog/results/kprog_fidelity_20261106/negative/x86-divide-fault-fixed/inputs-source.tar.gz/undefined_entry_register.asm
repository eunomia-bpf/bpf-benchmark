
build-x86/divide-fault-fixed/undefined_entry_register.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 85 c0                                        	test   rax,rax
   3:	74 08                                           	je     d <entry+0xd>
   5:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
   9:	0f b6 00                                        	movzx  eax,BYTE PTR [rax]
   c:	c3                                              	ret
   d:	b8 02 00 00 00                                  	mov    eax,0x2
  12:	c3                                              	ret
