
build-arm64/negative-numeric-final/writeback_store_overlap.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800042 	mov	x2, #0x2                   	// #2
   8:	a9000be2 	stp	x2, x2, [sp]
   c:	910003e1 	mov	x1, sp
  10:	f8008421 	str	x1, [x1], #8
  14:	910043ff 	add	sp, sp, #0x10
  18:	52800040 	mov	w0, #0x2                   	// #2
  1c:	d65f03c0 	ret
