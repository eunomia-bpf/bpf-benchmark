
build-arm64/negative-current-choice/scalar_vector_load_clear_high.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10083ff 	sub	sp, sp, #0x20
   4:	d2800021 	mov	x1, #0x1                   	// #1
   8:	f90003ff 	str	xzr, [sp]
   c:	f90007e1 	str	x1, [sp, #8]
  10:	3dc003e0 	ldr	q0, [sp]
  14:	fd4003e0 	ldr	d0, [sp]
  18:	3d8007e0 	str	q0, [sp, #16]
  1c:	f9400fe1 	ldr	x1, [sp, #24]
  20:	b5000061 	cbnz	x1, 2c <entry+0x2c>
  24:	d2800000 	mov	x0, #0x0                   	// #0
  28:	f9400000 	ldr	x0, [x0]
  2c:	910083ff 	add	sp, sp, #0x20
  30:	52800040 	mov	w0, #0x2                   	// #2
  34:	d65f03c0 	ret
