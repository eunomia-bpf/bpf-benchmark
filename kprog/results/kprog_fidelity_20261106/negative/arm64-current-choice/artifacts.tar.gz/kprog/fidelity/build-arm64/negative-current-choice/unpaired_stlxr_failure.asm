
build-arm64/negative-current-choice/unpaired_stlxr_failure.native.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	d10043ff 	sub	sp, sp, #0x10
   4:	d2800041 	mov	x1, #0x2                   	// #2
   8:	f90003e1 	str	x1, [sp]
   c:	910003e2 	mov	x2, sp
  10:	c800fc41 	stlxr	w0, x1, [x2]
  14:	34000060 	cbz	w0, 20 <entry+0x20>
  18:	d2800003 	mov	x3, #0x0                   	// #0
  1c:	b9400060 	ldr	w0, [x3]
  20:	910043ff 	add	sp, sp, #0x10
  24:	52800040 	mov	w0, #0x2                   	// #2
  28:	d65f03c0 	ret
