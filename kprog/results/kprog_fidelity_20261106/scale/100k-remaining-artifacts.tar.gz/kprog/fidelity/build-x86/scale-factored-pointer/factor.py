from pathlib import Path
from collections import Counter
import re
import sys
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
s=source.read_text();first=s.index('SEC(');prefix=s[:first];body=s[first:]
all_forms=sorted(set(re.findall(r'^\s*(X86_SIM_L_EXEC_(?:MOV_LOAD|ALU_REG|IMUL_IMM|ALU_IMM)\([^\n]+\));',body,re.M)))
forms=[f for f in all_forms if f.startswith(('X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R10, X86_RSI,','X86_SIM_L_EXEC_ALU_REG(X86_R8, X86_R10,','X86_SIM_L_EXEC_ALU_IMM(X86_R8,','X86_SIM_L_EXEC_IMUL_IMM(X86_R8,'))]
if not forms:raise RuntimeError('no selected forms')
prototypes=[];helpers=[]
for index,form in enumerate(forms):
    regs=sorted(set(re.findall(r'\bX86_R(?:AX|CX|DX|BX|SP|BP|SI|DI|8|9|10|11|12|13|14|15)\b',form)))
    if not set(regs)<={'X86_R8','X86_R10','X86_RSI'}:raise RuntimeError('unsupported cell closure '+form)
    names=[r[4:].lower() for r in regs]
    name='fidelity_step_'+str(index)
    params=[p for n in names for p in ['union x86_sim_gpr *'+n,'__u8 *'+n+'_tag']]+['__u8 *cf','__u8 *zf','__u8 *sf','__u8 *of']
    args=','.join(params)
    copyin=''.join('__x86_'+n+'=*'+n+';__x86_'+n+'_tag=*'+n+'_tag;' for n in names)
    copyout=''.join('*'+n+'=__x86_'+n+';*'+n+'_tag=__x86_'+n+'_tag;' for n in names)
    prototypes.append('__attribute__((always_inline)) void '+name+'('+args+');')
    helpers.append('__attribute__((always_inline)) void '+name+'('+args+') { X86_SIM_L_DECLARE_STATE(); X86_SIM_L_DECLARE_STACK(); const __u8 __x86_sim_abi_kind=KPROG_ABI_KIND_XDP;'+copyin+'__x86_cf=*cf;__x86_zf=*zf;__x86_sf=*sf;__x86_of=*of;'+form+';'+copyout+'*cf=__x86_cf;*zf=__x86_zf;*sf=__x86_sf;*of=__x86_of; }')
    passed=[p for n in names for p in ['&__x86_'+n,'&__x86_'+n+'_tag']]+['&__x86_cf','&__x86_zf','&__x86_sf','&__x86_of']
    body=body.replace(form+';',name+'('+','.join(passed)+');')
counts=Counter(re.findall(r'\bx86_l_[a-f0-9]+\b',body))
body=re.sub(r'^(x86_l_[a-f0-9]+):\n',lambda m: '' if counts[m[1]]==1 else m[0],body,flags=re.M)
(out/'program.bpf.c').write_text(prefix+'\n'.join(prototypes)+'\n'+body)
(out/'steps.c').write_text(prefix+'\n'.join(helpers)+'\n')
(out/'forms.txt').write_text('\n'.join(forms)+'\n')
(out/'entry.txt').write_text(re.search(r'int (\w+)\(',body)[1]+'\n')
print(source,len(forms),'factored forms')
