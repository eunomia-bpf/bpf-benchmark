
/workspaces/repository/kprog/fidelity/build-x86/scale/n1000_ptr_direct.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 8b 37                                        	mov    rsi,QWORD PTR [rdi]
   3:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
   7:	48 8d 46 10                                     	lea    rax,[rsi+0x10]
   b:	48 39 d0                                        	cmp    rax,rdx
   e:	0f 87 be 0f 00 00                               	ja     fd2 <bad>
  14:	44 0f b6 4e 08                                  	movzx  r9d,BYTE PTR [rsi+0x8]
  19:	41 b8 07 00 00 00                               	mov    r8d,0x7
  1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  24:	4d 01 d0                                        	add    r8,r10
  27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  2c:	4d 01 d0                                        	add    r8,r10
  2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  34:	4d 01 d0                                        	add    r8,r10
  37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  3c:	4d 01 d0                                        	add    r8,r10
  3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  44:	4d 01 d0                                        	add    r8,r10
  47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  4c:	4d 01 d0                                        	add    r8,r10
  4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  54:	4d 01 d0                                        	add    r8,r10
  57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  5c:	4d 01 d0                                        	add    r8,r10
  5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  64:	4d 01 d0                                        	add    r8,r10
  67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  6c:	4d 01 d0                                        	add    r8,r10
  6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  74:	4d 01 d0                                        	add    r8,r10
  77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  7c:	4d 01 d0                                        	add    r8,r10
  7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  84:	4d 01 d0                                        	add    r8,r10
  87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  8c:	4d 01 d0                                        	add    r8,r10
  8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  94:	4d 01 d0                                        	add    r8,r10
  97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  9c:	4d 01 d0                                        	add    r8,r10
  9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  a4:	4d 01 d0                                        	add    r8,r10
  a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  ac:	4d 01 d0                                        	add    r8,r10
  af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  b4:	4d 01 d0                                        	add    r8,r10
  b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  bc:	4d 01 d0                                        	add    r8,r10
  bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  c4:	4d 01 d0                                        	add    r8,r10
  c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  cc:	4d 01 d0                                        	add    r8,r10
  cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  d4:	4d 01 d0                                        	add    r8,r10
  d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  dc:	4d 01 d0                                        	add    r8,r10
  df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  e4:	4d 01 d0                                        	add    r8,r10
  e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  ec:	4d 01 d0                                        	add    r8,r10
  ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  f4:	4d 01 d0                                        	add    r8,r10
  f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  fc:	4d 01 d0                                        	add    r8,r10
  ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 104:	4d 01 d0                                        	add    r8,r10
 107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 10c:	4d 01 d0                                        	add    r8,r10
 10f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 114:	4d 01 d0                                        	add    r8,r10
 117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 11c:	4d 01 d0                                        	add    r8,r10
 11f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 124:	4d 01 d0                                        	add    r8,r10
 127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 12c:	4d 01 d0                                        	add    r8,r10
 12f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 134:	4d 01 d0                                        	add    r8,r10
 137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 13c:	4d 01 d0                                        	add    r8,r10
 13f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 144:	4d 01 d0                                        	add    r8,r10
 147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 14c:	4d 01 d0                                        	add    r8,r10
 14f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 154:	4d 01 d0                                        	add    r8,r10
 157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 15c:	4d 01 d0                                        	add    r8,r10
 15f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 164:	4d 01 d0                                        	add    r8,r10
 167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 16c:	4d 01 d0                                        	add    r8,r10
 16f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 174:	4d 01 d0                                        	add    r8,r10
 177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 17c:	4d 01 d0                                        	add    r8,r10
 17f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 184:	4d 01 d0                                        	add    r8,r10
 187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 18c:	4d 01 d0                                        	add    r8,r10
 18f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 194:	4d 01 d0                                        	add    r8,r10
 197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 19c:	4d 01 d0                                        	add    r8,r10
 19f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 1a4:	4d 01 d0                                        	add    r8,r10
 1a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 1ac:	4d 01 d0                                        	add    r8,r10
 1af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 1b4:	4d 01 d0                                        	add    r8,r10
 1b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 1bc:	4d 01 d0                                        	add    r8,r10
 1bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 1c4:	4d 01 d0                                        	add    r8,r10
 1c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 1cc:	4d 01 d0                                        	add    r8,r10
 1cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 1d4:	4d 01 d0                                        	add    r8,r10
 1d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 1dc:	4d 01 d0                                        	add    r8,r10
 1df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 1e4:	4d 01 d0                                        	add    r8,r10
 1e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 1ec:	4d 01 d0                                        	add    r8,r10
 1ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 1f4:	4d 01 d0                                        	add    r8,r10
 1f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 1fc:	4d 01 d0                                        	add    r8,r10
 1ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 204:	4d 01 d0                                        	add    r8,r10
 207:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 20c:	4d 01 d0                                        	add    r8,r10
 20f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 214:	4d 01 d0                                        	add    r8,r10
 217:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 21c:	4d 01 d0                                        	add    r8,r10
 21f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 224:	4d 01 d0                                        	add    r8,r10
 227:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 22c:	4d 01 d0                                        	add    r8,r10
 22f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 234:	4d 01 d0                                        	add    r8,r10
 237:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 23c:	4d 01 d0                                        	add    r8,r10
 23f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 244:	4d 01 d0                                        	add    r8,r10
 247:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 24c:	4d 01 d0                                        	add    r8,r10
 24f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 254:	4d 01 d0                                        	add    r8,r10
 257:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 25c:	4d 01 d0                                        	add    r8,r10
 25f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 264:	4d 01 d0                                        	add    r8,r10
 267:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 26c:	4d 01 d0                                        	add    r8,r10
 26f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 274:	4d 01 d0                                        	add    r8,r10
 277:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 27c:	4d 01 d0                                        	add    r8,r10
 27f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 284:	4d 01 d0                                        	add    r8,r10
 287:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 28c:	4d 01 d0                                        	add    r8,r10
 28f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 294:	4d 01 d0                                        	add    r8,r10
 297:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 29c:	4d 01 d0                                        	add    r8,r10
 29f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 2a4:	4d 01 d0                                        	add    r8,r10
 2a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 2ac:	4d 01 d0                                        	add    r8,r10
 2af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 2b4:	4d 01 d0                                        	add    r8,r10
 2b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 2bc:	4d 01 d0                                        	add    r8,r10
 2bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 2c4:	4d 01 d0                                        	add    r8,r10
 2c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 2cc:	4d 01 d0                                        	add    r8,r10
 2cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 2d4:	4d 01 d0                                        	add    r8,r10
 2d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 2dc:	4d 01 d0                                        	add    r8,r10
 2df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 2e4:	4d 01 d0                                        	add    r8,r10
 2e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 2ec:	4d 01 d0                                        	add    r8,r10
 2ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 2f4:	4d 01 d0                                        	add    r8,r10
 2f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 2fc:	4d 01 d0                                        	add    r8,r10
 2ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 304:	4d 01 d0                                        	add    r8,r10
 307:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 30c:	4d 01 d0                                        	add    r8,r10
 30f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 314:	4d 01 d0                                        	add    r8,r10
 317:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 31c:	4d 01 d0                                        	add    r8,r10
 31f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 324:	4d 01 d0                                        	add    r8,r10
 327:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 32c:	4d 01 d0                                        	add    r8,r10
 32f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 334:	4d 01 d0                                        	add    r8,r10
 337:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 33c:	4d 01 d0                                        	add    r8,r10
 33f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 344:	4d 01 d0                                        	add    r8,r10
 347:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 34c:	4d 01 d0                                        	add    r8,r10
 34f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 354:	4d 01 d0                                        	add    r8,r10
 357:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 35c:	4d 01 d0                                        	add    r8,r10
 35f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 364:	4d 01 d0                                        	add    r8,r10
 367:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 36c:	4d 01 d0                                        	add    r8,r10
 36f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 374:	4d 01 d0                                        	add    r8,r10
 377:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 37c:	4d 01 d0                                        	add    r8,r10
 37f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 384:	4d 01 d0                                        	add    r8,r10
 387:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 38c:	4d 01 d0                                        	add    r8,r10
 38f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 394:	4d 01 d0                                        	add    r8,r10
 397:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 39c:	4d 01 d0                                        	add    r8,r10
 39f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 3a4:	4d 01 d0                                        	add    r8,r10
 3a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 3ac:	4d 01 d0                                        	add    r8,r10
 3af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 3b4:	4d 01 d0                                        	add    r8,r10
 3b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 3bc:	4d 01 d0                                        	add    r8,r10
 3bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 3c4:	4d 01 d0                                        	add    r8,r10
 3c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 3cc:	4d 01 d0                                        	add    r8,r10
 3cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 3d4:	4d 01 d0                                        	add    r8,r10
 3d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 3dc:	4d 01 d0                                        	add    r8,r10
 3df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 3e4:	4d 01 d0                                        	add    r8,r10
 3e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 3ec:	4d 01 d0                                        	add    r8,r10
 3ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 3f4:	4d 01 d0                                        	add    r8,r10
 3f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 3fc:	4d 01 d0                                        	add    r8,r10
 3ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 404:	4d 01 d0                                        	add    r8,r10
 407:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 40c:	4d 01 d0                                        	add    r8,r10
 40f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 414:	4d 01 d0                                        	add    r8,r10
 417:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 41c:	4d 01 d0                                        	add    r8,r10
 41f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 424:	4d 01 d0                                        	add    r8,r10
 427:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 42c:	4d 01 d0                                        	add    r8,r10
 42f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 434:	4d 01 d0                                        	add    r8,r10
 437:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 43c:	4d 01 d0                                        	add    r8,r10
 43f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 444:	4d 01 d0                                        	add    r8,r10
 447:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 44c:	4d 01 d0                                        	add    r8,r10
 44f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 454:	4d 01 d0                                        	add    r8,r10
 457:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 45c:	4d 01 d0                                        	add    r8,r10
 45f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 464:	4d 01 d0                                        	add    r8,r10
 467:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 46c:	4d 01 d0                                        	add    r8,r10
 46f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 474:	4d 01 d0                                        	add    r8,r10
 477:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 47c:	4d 01 d0                                        	add    r8,r10
 47f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 484:	4d 01 d0                                        	add    r8,r10
 487:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 48c:	4d 01 d0                                        	add    r8,r10
 48f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 494:	4d 01 d0                                        	add    r8,r10
 497:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 49c:	4d 01 d0                                        	add    r8,r10
 49f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 4a4:	4d 01 d0                                        	add    r8,r10
 4a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 4ac:	4d 01 d0                                        	add    r8,r10
 4af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 4b4:	4d 01 d0                                        	add    r8,r10
 4b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 4bc:	4d 01 d0                                        	add    r8,r10
 4bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 4c4:	4d 01 d0                                        	add    r8,r10
 4c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 4cc:	4d 01 d0                                        	add    r8,r10
 4cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 4d4:	4d 01 d0                                        	add    r8,r10
 4d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 4dc:	4d 01 d0                                        	add    r8,r10
 4df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 4e4:	4d 01 d0                                        	add    r8,r10
 4e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 4ec:	4d 01 d0                                        	add    r8,r10
 4ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 4f4:	4d 01 d0                                        	add    r8,r10
 4f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 4fc:	4d 01 d0                                        	add    r8,r10
 4ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 504:	4d 01 d0                                        	add    r8,r10
 507:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 50c:	4d 01 d0                                        	add    r8,r10
 50f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 514:	4d 01 d0                                        	add    r8,r10
 517:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 51c:	4d 01 d0                                        	add    r8,r10
 51f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 524:	4d 01 d0                                        	add    r8,r10
 527:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 52c:	4d 01 d0                                        	add    r8,r10
 52f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 534:	4d 01 d0                                        	add    r8,r10
 537:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 53c:	4d 01 d0                                        	add    r8,r10
 53f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 544:	4d 01 d0                                        	add    r8,r10
 547:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 54c:	4d 01 d0                                        	add    r8,r10
 54f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 554:	4d 01 d0                                        	add    r8,r10
 557:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 55c:	4d 01 d0                                        	add    r8,r10
 55f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 564:	4d 01 d0                                        	add    r8,r10
 567:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 56c:	4d 01 d0                                        	add    r8,r10
 56f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 574:	4d 01 d0                                        	add    r8,r10
 577:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 57c:	4d 01 d0                                        	add    r8,r10
 57f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 584:	4d 01 d0                                        	add    r8,r10
 587:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 58c:	4d 01 d0                                        	add    r8,r10
 58f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 594:	4d 01 d0                                        	add    r8,r10
 597:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 59c:	4d 01 d0                                        	add    r8,r10
 59f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 5a4:	4d 01 d0                                        	add    r8,r10
 5a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 5ac:	4d 01 d0                                        	add    r8,r10
 5af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 5b4:	4d 01 d0                                        	add    r8,r10
 5b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 5bc:	4d 01 d0                                        	add    r8,r10
 5bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 5c4:	4d 01 d0                                        	add    r8,r10
 5c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 5cc:	4d 01 d0                                        	add    r8,r10
 5cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 5d4:	4d 01 d0                                        	add    r8,r10
 5d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 5dc:	4d 01 d0                                        	add    r8,r10
 5df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 5e4:	4d 01 d0                                        	add    r8,r10
 5e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 5ec:	4d 01 d0                                        	add    r8,r10
 5ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 5f4:	4d 01 d0                                        	add    r8,r10
 5f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 5fc:	4d 01 d0                                        	add    r8,r10
 5ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 604:	4d 01 d0                                        	add    r8,r10
 607:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 60c:	4d 01 d0                                        	add    r8,r10
 60f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 614:	4d 01 d0                                        	add    r8,r10
 617:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 61c:	4d 01 d0                                        	add    r8,r10
 61f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 624:	4d 01 d0                                        	add    r8,r10
 627:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 62c:	4d 01 d0                                        	add    r8,r10
 62f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 634:	4d 01 d0                                        	add    r8,r10
 637:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 63c:	4d 01 d0                                        	add    r8,r10
 63f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 644:	4d 01 d0                                        	add    r8,r10
 647:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 64c:	4d 01 d0                                        	add    r8,r10
 64f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 654:	4d 01 d0                                        	add    r8,r10
 657:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 65c:	4d 01 d0                                        	add    r8,r10
 65f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 664:	4d 01 d0                                        	add    r8,r10
 667:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 66c:	4d 01 d0                                        	add    r8,r10
 66f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 674:	4d 01 d0                                        	add    r8,r10
 677:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 67c:	4d 01 d0                                        	add    r8,r10
 67f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 684:	4d 01 d0                                        	add    r8,r10
 687:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 68c:	4d 01 d0                                        	add    r8,r10
 68f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 694:	4d 01 d0                                        	add    r8,r10
 697:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 69c:	4d 01 d0                                        	add    r8,r10
 69f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 6a4:	4d 01 d0                                        	add    r8,r10
 6a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 6ac:	4d 01 d0                                        	add    r8,r10
 6af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 6b4:	4d 01 d0                                        	add    r8,r10
 6b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 6bc:	4d 01 d0                                        	add    r8,r10
 6bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 6c4:	4d 01 d0                                        	add    r8,r10
 6c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 6cc:	4d 01 d0                                        	add    r8,r10
 6cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 6d4:	4d 01 d0                                        	add    r8,r10
 6d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 6dc:	4d 01 d0                                        	add    r8,r10
 6df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 6e4:	4d 01 d0                                        	add    r8,r10
 6e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 6ec:	4d 01 d0                                        	add    r8,r10
 6ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 6f4:	4d 01 d0                                        	add    r8,r10
 6f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 6fc:	4d 01 d0                                        	add    r8,r10
 6ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 704:	4d 01 d0                                        	add    r8,r10
 707:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 70c:	4d 01 d0                                        	add    r8,r10
 70f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 714:	4d 01 d0                                        	add    r8,r10
 717:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 71c:	4d 01 d0                                        	add    r8,r10
 71f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 724:	4d 01 d0                                        	add    r8,r10
 727:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 72c:	4d 01 d0                                        	add    r8,r10
 72f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 734:	4d 01 d0                                        	add    r8,r10
 737:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 73c:	4d 01 d0                                        	add    r8,r10
 73f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 744:	4d 01 d0                                        	add    r8,r10
 747:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 74c:	4d 01 d0                                        	add    r8,r10
 74f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 754:	4d 01 d0                                        	add    r8,r10
 757:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 75c:	4d 01 d0                                        	add    r8,r10
 75f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 764:	4d 01 d0                                        	add    r8,r10
 767:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 76c:	4d 01 d0                                        	add    r8,r10
 76f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 774:	4d 01 d0                                        	add    r8,r10
 777:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 77c:	4d 01 d0                                        	add    r8,r10
 77f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 784:	4d 01 d0                                        	add    r8,r10
 787:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 78c:	4d 01 d0                                        	add    r8,r10
 78f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 794:	4d 01 d0                                        	add    r8,r10
 797:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 79c:	4d 01 d0                                        	add    r8,r10
 79f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 7a4:	4d 01 d0                                        	add    r8,r10
 7a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 7ac:	4d 01 d0                                        	add    r8,r10
 7af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 7b4:	4d 01 d0                                        	add    r8,r10
 7b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 7bc:	4d 01 d0                                        	add    r8,r10
 7bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 7c4:	4d 01 d0                                        	add    r8,r10
 7c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 7cc:	4d 01 d0                                        	add    r8,r10
 7cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 7d4:	4d 01 d0                                        	add    r8,r10
 7d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 7dc:	4d 01 d0                                        	add    r8,r10
 7df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 7e4:	4d 01 d0                                        	add    r8,r10
 7e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 7ec:	4d 01 d0                                        	add    r8,r10
 7ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 7f4:	4d 01 d0                                        	add    r8,r10
 7f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 7fc:	4d 01 d0                                        	add    r8,r10
 7ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 804:	4d 01 d0                                        	add    r8,r10
 807:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 80c:	4d 01 d0                                        	add    r8,r10
 80f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 814:	4d 01 d0                                        	add    r8,r10
 817:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 81c:	4d 01 d0                                        	add    r8,r10
 81f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 824:	4d 01 d0                                        	add    r8,r10
 827:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 82c:	4d 01 d0                                        	add    r8,r10
 82f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 834:	4d 01 d0                                        	add    r8,r10
 837:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 83c:	4d 01 d0                                        	add    r8,r10
 83f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 844:	4d 01 d0                                        	add    r8,r10
 847:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 84c:	4d 01 d0                                        	add    r8,r10
 84f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 854:	4d 01 d0                                        	add    r8,r10
 857:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 85c:	4d 01 d0                                        	add    r8,r10
 85f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 864:	4d 01 d0                                        	add    r8,r10
 867:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 86c:	4d 01 d0                                        	add    r8,r10
 86f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 874:	4d 01 d0                                        	add    r8,r10
 877:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 87c:	4d 01 d0                                        	add    r8,r10
 87f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 884:	4d 01 d0                                        	add    r8,r10
 887:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 88c:	4d 01 d0                                        	add    r8,r10
 88f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 894:	4d 01 d0                                        	add    r8,r10
 897:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 89c:	4d 01 d0                                        	add    r8,r10
 89f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 8a4:	4d 01 d0                                        	add    r8,r10
 8a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 8ac:	4d 01 d0                                        	add    r8,r10
 8af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 8b4:	4d 01 d0                                        	add    r8,r10
 8b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 8bc:	4d 01 d0                                        	add    r8,r10
 8bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 8c4:	4d 01 d0                                        	add    r8,r10
 8c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 8cc:	4d 01 d0                                        	add    r8,r10
 8cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 8d4:	4d 01 d0                                        	add    r8,r10
 8d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 8dc:	4d 01 d0                                        	add    r8,r10
 8df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 8e4:	4d 01 d0                                        	add    r8,r10
 8e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 8ec:	4d 01 d0                                        	add    r8,r10
 8ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 8f4:	4d 01 d0                                        	add    r8,r10
 8f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 8fc:	4d 01 d0                                        	add    r8,r10
 8ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 904:	4d 01 d0                                        	add    r8,r10
 907:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 90c:	4d 01 d0                                        	add    r8,r10
 90f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 914:	4d 01 d0                                        	add    r8,r10
 917:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 91c:	4d 01 d0                                        	add    r8,r10
 91f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 924:	4d 01 d0                                        	add    r8,r10
 927:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 92c:	4d 01 d0                                        	add    r8,r10
 92f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 934:	4d 01 d0                                        	add    r8,r10
 937:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 93c:	4d 01 d0                                        	add    r8,r10
 93f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 944:	4d 01 d0                                        	add    r8,r10
 947:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 94c:	4d 01 d0                                        	add    r8,r10
 94f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 954:	4d 01 d0                                        	add    r8,r10
 957:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 95c:	4d 01 d0                                        	add    r8,r10
 95f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 964:	4d 01 d0                                        	add    r8,r10
 967:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 96c:	4d 01 d0                                        	add    r8,r10
 96f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 974:	4d 01 d0                                        	add    r8,r10
 977:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 97c:	4d 01 d0                                        	add    r8,r10
 97f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 984:	4d 01 d0                                        	add    r8,r10
 987:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 98c:	4d 01 d0                                        	add    r8,r10
 98f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 994:	4d 01 d0                                        	add    r8,r10
 997:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 99c:	4d 01 d0                                        	add    r8,r10
 99f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 9a4:	4d 01 d0                                        	add    r8,r10
 9a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 9ac:	4d 01 d0                                        	add    r8,r10
 9af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 9b4:	4d 01 d0                                        	add    r8,r10
 9b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 9bc:	4d 01 d0                                        	add    r8,r10
 9bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 9c4:	4d 01 d0                                        	add    r8,r10
 9c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 9cc:	4d 01 d0                                        	add    r8,r10
 9cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 9d4:	4d 01 d0                                        	add    r8,r10
 9d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 9dc:	4d 01 d0                                        	add    r8,r10
 9df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 9e4:	4d 01 d0                                        	add    r8,r10
 9e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 9ec:	4d 01 d0                                        	add    r8,r10
 9ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 9f4:	4d 01 d0                                        	add    r8,r10
 9f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 9fc:	4d 01 d0                                        	add    r8,r10
 9ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 a04:	4d 01 d0                                        	add    r8,r10
 a07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 a0c:	4d 01 d0                                        	add    r8,r10
 a0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 a14:	4d 01 d0                                        	add    r8,r10
 a17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 a1c:	4d 01 d0                                        	add    r8,r10
 a1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 a24:	4d 01 d0                                        	add    r8,r10
 a27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 a2c:	4d 01 d0                                        	add    r8,r10
 a2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 a34:	4d 01 d0                                        	add    r8,r10
 a37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 a3c:	4d 01 d0                                        	add    r8,r10
 a3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 a44:	4d 01 d0                                        	add    r8,r10
 a47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 a4c:	4d 01 d0                                        	add    r8,r10
 a4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 a54:	4d 01 d0                                        	add    r8,r10
 a57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 a5c:	4d 01 d0                                        	add    r8,r10
 a5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 a64:	4d 01 d0                                        	add    r8,r10
 a67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 a6c:	4d 01 d0                                        	add    r8,r10
 a6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 a74:	4d 01 d0                                        	add    r8,r10
 a77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 a7c:	4d 01 d0                                        	add    r8,r10
 a7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 a84:	4d 01 d0                                        	add    r8,r10
 a87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 a8c:	4d 01 d0                                        	add    r8,r10
 a8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 a94:	4d 01 d0                                        	add    r8,r10
 a97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 a9c:	4d 01 d0                                        	add    r8,r10
 a9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 aa4:	4d 01 d0                                        	add    r8,r10
 aa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 aac:	4d 01 d0                                        	add    r8,r10
 aaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 ab4:	4d 01 d0                                        	add    r8,r10
 ab7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 abc:	4d 01 d0                                        	add    r8,r10
 abf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 ac4:	4d 01 d0                                        	add    r8,r10
 ac7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 acc:	4d 01 d0                                        	add    r8,r10
 acf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 ad4:	4d 01 d0                                        	add    r8,r10
 ad7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 adc:	4d 01 d0                                        	add    r8,r10
 adf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ae4:	4d 01 d0                                        	add    r8,r10
 ae7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 aec:	4d 01 d0                                        	add    r8,r10
 aef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 af4:	4d 01 d0                                        	add    r8,r10
 af7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 afc:	4d 01 d0                                        	add    r8,r10
 aff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 b04:	4d 01 d0                                        	add    r8,r10
 b07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 b0c:	4d 01 d0                                        	add    r8,r10
 b0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 b14:	4d 01 d0                                        	add    r8,r10
 b17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 b1c:	4d 01 d0                                        	add    r8,r10
 b1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 b24:	4d 01 d0                                        	add    r8,r10
 b27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 b2c:	4d 01 d0                                        	add    r8,r10
 b2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 b34:	4d 01 d0                                        	add    r8,r10
 b37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 b3c:	4d 01 d0                                        	add    r8,r10
 b3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 b44:	4d 01 d0                                        	add    r8,r10
 b47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 b4c:	4d 01 d0                                        	add    r8,r10
 b4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 b54:	4d 01 d0                                        	add    r8,r10
 b57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 b5c:	4d 01 d0                                        	add    r8,r10
 b5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 b64:	4d 01 d0                                        	add    r8,r10
 b67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 b6c:	4d 01 d0                                        	add    r8,r10
 b6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 b74:	4d 01 d0                                        	add    r8,r10
 b77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 b7c:	4d 01 d0                                        	add    r8,r10
 b7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 b84:	4d 01 d0                                        	add    r8,r10
 b87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 b8c:	4d 01 d0                                        	add    r8,r10
 b8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 b94:	4d 01 d0                                        	add    r8,r10
 b97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 b9c:	4d 01 d0                                        	add    r8,r10
 b9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ba4:	4d 01 d0                                        	add    r8,r10
 ba7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 bac:	4d 01 d0                                        	add    r8,r10
 baf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 bb4:	4d 01 d0                                        	add    r8,r10
 bb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 bbc:	4d 01 d0                                        	add    r8,r10
 bbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 bc4:	4d 01 d0                                        	add    r8,r10
 bc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 bcc:	4d 01 d0                                        	add    r8,r10
 bcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 bd4:	4d 01 d0                                        	add    r8,r10
 bd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 bdc:	4d 01 d0                                        	add    r8,r10
 bdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 be4:	4d 01 d0                                        	add    r8,r10
 be7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 bec:	4d 01 d0                                        	add    r8,r10
 bef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 bf4:	4d 01 d0                                        	add    r8,r10
 bf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 bfc:	4d 01 d0                                        	add    r8,r10
 bff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 c04:	4d 01 d0                                        	add    r8,r10
 c07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 c0c:	4d 01 d0                                        	add    r8,r10
 c0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 c14:	4d 01 d0                                        	add    r8,r10
 c17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 c1c:	4d 01 d0                                        	add    r8,r10
 c1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 c24:	4d 01 d0                                        	add    r8,r10
 c27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 c2c:	4d 01 d0                                        	add    r8,r10
 c2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 c34:	4d 01 d0                                        	add    r8,r10
 c37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 c3c:	4d 01 d0                                        	add    r8,r10
 c3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 c44:	4d 01 d0                                        	add    r8,r10
 c47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 c4c:	4d 01 d0                                        	add    r8,r10
 c4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 c54:	4d 01 d0                                        	add    r8,r10
 c57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 c5c:	4d 01 d0                                        	add    r8,r10
 c5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 c64:	4d 01 d0                                        	add    r8,r10
 c67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 c6c:	4d 01 d0                                        	add    r8,r10
 c6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 c74:	4d 01 d0                                        	add    r8,r10
 c77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 c7c:	4d 01 d0                                        	add    r8,r10
 c7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 c84:	4d 01 d0                                        	add    r8,r10
 c87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 c8c:	4d 01 d0                                        	add    r8,r10
 c8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 c94:	4d 01 d0                                        	add    r8,r10
 c97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 c9c:	4d 01 d0                                        	add    r8,r10
 c9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ca4:	4d 01 d0                                        	add    r8,r10
 ca7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 cac:	4d 01 d0                                        	add    r8,r10
 caf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 cb4:	4d 01 d0                                        	add    r8,r10
 cb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 cbc:	4d 01 d0                                        	add    r8,r10
 cbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 cc4:	4d 01 d0                                        	add    r8,r10
 cc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 ccc:	4d 01 d0                                        	add    r8,r10
 ccf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 cd4:	4d 01 d0                                        	add    r8,r10
 cd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 cdc:	4d 01 d0                                        	add    r8,r10
 cdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ce4:	4d 01 d0                                        	add    r8,r10
 ce7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 cec:	4d 01 d0                                        	add    r8,r10
 cef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 cf4:	4d 01 d0                                        	add    r8,r10
 cf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 cfc:	4d 01 d0                                        	add    r8,r10
 cff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 d04:	4d 01 d0                                        	add    r8,r10
 d07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 d0c:	4d 01 d0                                        	add    r8,r10
 d0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 d14:	4d 01 d0                                        	add    r8,r10
 d17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 d1c:	4d 01 d0                                        	add    r8,r10
 d1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 d24:	4d 01 d0                                        	add    r8,r10
 d27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 d2c:	4d 01 d0                                        	add    r8,r10
 d2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 d34:	4d 01 d0                                        	add    r8,r10
 d37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 d3c:	4d 01 d0                                        	add    r8,r10
 d3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 d44:	4d 01 d0                                        	add    r8,r10
 d47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 d4c:	4d 01 d0                                        	add    r8,r10
 d4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 d54:	4d 01 d0                                        	add    r8,r10
 d57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 d5c:	4d 01 d0                                        	add    r8,r10
 d5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 d64:	4d 01 d0                                        	add    r8,r10
 d67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 d6c:	4d 01 d0                                        	add    r8,r10
 d6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 d74:	4d 01 d0                                        	add    r8,r10
 d77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 d7c:	4d 01 d0                                        	add    r8,r10
 d7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 d84:	4d 01 d0                                        	add    r8,r10
 d87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 d8c:	4d 01 d0                                        	add    r8,r10
 d8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 d94:	4d 01 d0                                        	add    r8,r10
 d97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 d9c:	4d 01 d0                                        	add    r8,r10
 d9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 da4:	4d 01 d0                                        	add    r8,r10
 da7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 dac:	4d 01 d0                                        	add    r8,r10
 daf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 db4:	4d 01 d0                                        	add    r8,r10
 db7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 dbc:	4d 01 d0                                        	add    r8,r10
 dbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 dc4:	4d 01 d0                                        	add    r8,r10
 dc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 dcc:	4d 01 d0                                        	add    r8,r10
 dcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 dd4:	4d 01 d0                                        	add    r8,r10
 dd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 ddc:	4d 01 d0                                        	add    r8,r10
 ddf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 de4:	4d 01 d0                                        	add    r8,r10
 de7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 dec:	4d 01 d0                                        	add    r8,r10
 def:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 df4:	4d 01 d0                                        	add    r8,r10
 df7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 dfc:	4d 01 d0                                        	add    r8,r10
 dff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 e04:	4d 01 d0                                        	add    r8,r10
 e07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 e0c:	4d 01 d0                                        	add    r8,r10
 e0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 e14:	4d 01 d0                                        	add    r8,r10
 e17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 e1c:	4d 01 d0                                        	add    r8,r10
 e1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 e24:	4d 01 d0                                        	add    r8,r10
 e27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 e2c:	4d 01 d0                                        	add    r8,r10
 e2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 e34:	4d 01 d0                                        	add    r8,r10
 e37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 e3c:	4d 01 d0                                        	add    r8,r10
 e3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 e44:	4d 01 d0                                        	add    r8,r10
 e47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 e4c:	4d 01 d0                                        	add    r8,r10
 e4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 e54:	4d 01 d0                                        	add    r8,r10
 e57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 e5c:	4d 01 d0                                        	add    r8,r10
 e5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 e64:	4d 01 d0                                        	add    r8,r10
 e67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 e6c:	4d 01 d0                                        	add    r8,r10
 e6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 e74:	4d 01 d0                                        	add    r8,r10
 e77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 e7c:	4d 01 d0                                        	add    r8,r10
 e7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 e84:	4d 01 d0                                        	add    r8,r10
 e87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 e8c:	4d 01 d0                                        	add    r8,r10
 e8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 e94:	4d 01 d0                                        	add    r8,r10
 e97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 e9c:	4d 01 d0                                        	add    r8,r10
 e9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ea4:	4d 01 d0                                        	add    r8,r10
 ea7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 eac:	4d 01 d0                                        	add    r8,r10
 eaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 eb4:	4d 01 d0                                        	add    r8,r10
 eb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 ebc:	4d 01 d0                                        	add    r8,r10
 ebf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 ec4:	4d 01 d0                                        	add    r8,r10
 ec7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 ecc:	4d 01 d0                                        	add    r8,r10
 ecf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 ed4:	4d 01 d0                                        	add    r8,r10
 ed7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 edc:	4d 01 d0                                        	add    r8,r10
 edf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 ee4:	4d 01 d0                                        	add    r8,r10
 ee7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 eec:	4d 01 d0                                        	add    r8,r10
 eef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 ef4:	4d 01 d0                                        	add    r8,r10
 ef7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 efc:	4d 01 d0                                        	add    r8,r10
 eff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 f04:	4d 01 d0                                        	add    r8,r10
 f07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 f0c:	4d 01 d0                                        	add    r8,r10
 f0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 f14:	4d 01 d0                                        	add    r8,r10
 f17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 f1c:	4d 01 d0                                        	add    r8,r10
 f1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 f24:	4d 01 d0                                        	add    r8,r10
 f27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 f2c:	4d 01 d0                                        	add    r8,r10
 f2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 f34:	4d 01 d0                                        	add    r8,r10
 f37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 f3c:	4d 01 d0                                        	add    r8,r10
 f3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 f44:	4d 01 d0                                        	add    r8,r10
 f47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 f4c:	4d 01 d0                                        	add    r8,r10
 f4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 f54:	4d 01 d0                                        	add    r8,r10
 f57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 f5c:	4d 01 d0                                        	add    r8,r10
 f5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 f64:	4d 01 d0                                        	add    r8,r10
 f67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 f6c:	4d 01 d0                                        	add    r8,r10
 f6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 f74:	4d 01 d0                                        	add    r8,r10
 f77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 f7c:	4d 01 d0                                        	add    r8,r10
 f7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 f84:	4d 01 d0                                        	add    r8,r10
 f87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 f8c:	4d 01 d0                                        	add    r8,r10
 f8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 f94:	4d 01 d0                                        	add    r8,r10
 f97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 f9c:	4d 01 d0                                        	add    r8,r10
 f9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 fa4:	4d 01 d0                                        	add    r8,r10
 fa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 fac:	4d 01 d0                                        	add    r8,r10
 faf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 fb4:	4d 01 d0                                        	add    r8,r10
 fb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 fbc:	4d 01 d0                                        	add    r8,r10
 fbf:	41 f6 c1 01                                     	test   r9b,0x1
 fc3:	74 04                                           	je     fc9 <join_0>
 fc5:	49 83 f0 01                                     	xor    r8,0x1

0000000000000fc9 <join_0>:
 fc9:	4c 89 06                                        	mov    QWORD PTR [rsi],r8
 fcc:	b8 02 00 00 00                                  	mov    eax,0x2
 fd1:	c3                                              	ret

0000000000000fd2 <bad>:
 fd2:	31 c0                                           	xor    eax,eax
 fd4:	c3                                              	ret
