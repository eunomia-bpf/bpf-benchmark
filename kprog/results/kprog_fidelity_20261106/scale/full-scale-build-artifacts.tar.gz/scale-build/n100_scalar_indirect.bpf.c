#include "/workspaces/repository/kprog/fidelity/build-x86/scale/snapshot/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

SEC("xdp")
int n100_scalar_indirect_x86_sim_xdp(struct xdp_md *ctx)
{
	X86_SIM_ENTRY_XDP(ctx);
x86_l_0:
	/* 0x0: mov    rsi,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3:
	/* 0x3: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_7:
	/* 0x7: lea    rax,[rsi+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_b:
	/* 0xb: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_e:
	/* 0xe: ja     1db <bad> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe, 0x1db, x86_l_1db);
x86_l_14:
	/* 0x14: movzx  r9d,BYTE PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
x86_l_19:
	/* 0x19: mov    r8d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 7ULL);
x86_l_1f:
	/* 0x1f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_23:
	/* 0x23: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_27:
	/* 0x27: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_2b:
	/* 0x2b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_2f:
	/* 0x2f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_33:
	/* 0x33: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_37:
	/* 0x37: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_3b:
	/* 0x3b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_3f:
	/* 0x3f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_43:
	/* 0x43: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_47:
	/* 0x47: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_4b:
	/* 0x4b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_4f:
	/* 0x4f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_53:
	/* 0x53: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_57:
	/* 0x57: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_5b:
	/* 0x5b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_5f:
	/* 0x5f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_63:
	/* 0x63: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_67:
	/* 0x67: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_6b:
	/* 0x6b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_6f:
	/* 0x6f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_73:
	/* 0x73: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_77:
	/* 0x77: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_7b:
	/* 0x7b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_7f:
	/* 0x7f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_83:
	/* 0x83: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_87:
	/* 0x87: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_8b:
	/* 0x8b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_8f:
	/* 0x8f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_93:
	/* 0x93: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_97:
	/* 0x97: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_9b:
	/* 0x9b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_9f:
	/* 0x9f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_a3:
	/* 0xa3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_a7:
	/* 0xa7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_ab:
	/* 0xab: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_af:
	/* 0xaf: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_b3:
	/* 0xb3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_b7:
	/* 0xb7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_bb:
	/* 0xbb: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_bf:
	/* 0xbf: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_c3:
	/* 0xc3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_c7:
	/* 0xc7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_cb:
	/* 0xcb: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_cf:
	/* 0xcf: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_d3:
	/* 0xd3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_d7:
	/* 0xd7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_db:
	/* 0xdb: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_df:
	/* 0xdf: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_e3:
	/* 0xe3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_e7:
	/* 0xe7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_eb:
	/* 0xeb: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_ef:
	/* 0xef: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_f3:
	/* 0xf3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_f7:
	/* 0xf7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_fb:
	/* 0xfb: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_ff:
	/* 0xff: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_103:
	/* 0x103: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_107:
	/* 0x107: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_10b:
	/* 0x10b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_10f:
	/* 0x10f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_113:
	/* 0x113: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_117:
	/* 0x117: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_11b:
	/* 0x11b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_11f:
	/* 0x11f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_123:
	/* 0x123: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_127:
	/* 0x127: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_12b:
	/* 0x12b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_12f:
	/* 0x12f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_133:
	/* 0x133: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_137:
	/* 0x137: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_13b:
	/* 0x13b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_13f:
	/* 0x13f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_143:
	/* 0x143: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_147:
	/* 0x147: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_14b:
	/* 0x14b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_14f:
	/* 0x14f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_153:
	/* 0x153: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_157:
	/* 0x157: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_15b:
	/* 0x15b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_15f:
	/* 0x15f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_163:
	/* 0x163: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_167:
	/* 0x167: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_16b:
	/* 0x16b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_16f:
	/* 0x16f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_173:
	/* 0x173: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_177:
	/* 0x177: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_17b:
	/* 0x17b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_17f:
	/* 0x17f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_183:
	/* 0x183: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_187:
	/* 0x187: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_18b:
	/* 0x18b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_18f:
	/* 0x18f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_193:
	/* 0x193: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_197:
	/* 0x197: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_19b:
	/* 0x19b: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_19f:
	/* 0x19f: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_1a3:
	/* 0x1a3: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_1a7:
	/* 0x1a7: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_1ab:
	/* 0x1ab: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_1af:
	/* 0x1af: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
x86_l_1b3:
	/* 0x1b3: jne    1be <choose_0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1b3, 0x1be, x86_l_1be);
x86_l_1b5:
	/* 0x1b5: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x1c8ULL);
x86_l_1bc:
	/* 0x1bc: jmp    1c5 <dispatch_0> */
	X86_SIM_X86_JMP(0x1bc, 0x1c5, x86_l_1c5);
x86_l_1be:
	/* 0x1be: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x1ceULL);
x86_l_1c5:
	/* 0x1c5: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x1c8ULL: goto x86_l_1c8;
			case 0x1ceULL: goto x86_l_1ce;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c8:
	/* 0x1c8: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_1cc:
	/* 0x1cc: jmp    1d2 <join_0> */
	X86_SIM_X86_JMP(0x1cc, 0x1d2, x86_l_1d2);
x86_l_1ce:
	/* 0x1ce: add    r8,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 2ULL);
x86_l_1d2:
	/* 0x1d2: mov    QWORD PTR [rsi],r8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1d5:
	/* 0x1d5: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1da:
	/* 0x1da: ret */
	X86_SIM_X86_RET();
x86_l_1db:
	/* 0x1db: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1dd:
	/* 0x1dd: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
